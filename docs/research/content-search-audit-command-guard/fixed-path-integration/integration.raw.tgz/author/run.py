import shutil,concurrent.futures,hashlib,json,os,signal,subprocess,tempfile,time
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
root=Path(tempfile.mkdtemp(prefix="nks-command-guard-"))
(out/"workspace.txt").write_text(str(root)+"\n")
guard=root/"command-guard.mjs"
shutil.copy2(repo/"scripts/eval-content-audit-command-guard.mjs",guard)
(root/"canonical-path.txt").write_text(str(guard.resolve()))
(root/"timeout-hook.mjs").write_text("setTimeout(() => {}, 10000);\n")

def run(case):
 work=root/case
 work.mkdir()
 writer=work/"write-marker.mjs"
 writer.write_text('import {writeFileSync} from "node:fs"; writeFileSync(process.argv[2], "executed\\n", {flag:"wx"});\n')
 target=(guard.resolve() if case=="canonical" else guard) if case in ["valid","canonical"] else guard if case=="valid" else (root/"missing-hook.mjs" if case=="missing" else root/"timeout-hook.mjs")
 settings={"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"rtk","args":["proxy","node",str(target)],"timeout":1 if case=="timeout" else 5,"onFailure":"block"}]}]}}
 config=out/(case+".settings.json")
 config.write_text(json.dumps(settings,indent=2)+"\n")
 wrapped="rtk proxy node "+str(writer)+" "+str(work/"wrapped-marker")
 unwrapped="node "+str(writer)+" "+str(work/"unwrapped-marker")
 commands=[unwrapped,wrapped] if case in ["valid","canonical"] else [wrapped]
 prompt="Controlled isolated PreToolUse hook integration test. Use Bash only. Execute each exact command below once, as separate Bash calls in order. Do not prepend or rewrite commands. After a denial do not retry, repair the hook, or find another way to execute that command; continue only to the next listed command, if any. Do not inspect or alter any files yourself. Then report each observed tool outcome briefly. The marker files are disposable test artifacts.\n"+"\n".join(str(i+1)+". "+c for i,c in enumerate(commands))+"\n"
 (out/(case+".prompt.txt")).write_text(prompt)
 args=["rtk","proxy","claude","--print","--setting-sources","project","--settings",str(config),"--strict-mcp-config","--permission-mode","dontAsk","--tools","Bash","--allowedTools","Bash","--no-session-persistence","--max-turns","5","--output-format","stream-json","--verbose"]
 start=time.time()
 with (out/(case+".events.jsonl")).open("w") as stdout,(out/(case+".stderr.txt")).open("w") as stderr:
  process=subprocess.Popen(args,cwd=work,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,text=True,start_new_session=True)
  try: process.communicate(prompt,timeout=90)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL)
   process.communicate()
 result={"case":case,"command":args,"cwd":str(work),"durationSeconds":time.time()-start,"exitCode":process.returncode,"claudeVersion":"2.1.325","guardSha256":hashlib.sha256(guard.read_bytes()).hexdigest(),"settingsSha256":hashlib.sha256(config.read_bytes()).hexdigest(),"markers":{n:(work/n).exists() for n in ["wrapped-marker","unwrapped-marker"]},"writerSha256":hashlib.sha256(writer.read_bytes()).hexdigest()}
 for line in (out/(case+".events.jsonl")).read_text().splitlines():
  try: event=json.loads(line)
  except json.JSONDecodeError: continue
  if event.get("type")=="result":
   result.update(costUsd=event.get("total_cost_usd"),resultError=event.get("is_error"),resultSubtype=event.get("subtype"))
   (out/(case+".response.txt")).write_text(event.get("result", ""))
 (out/(case+".execution.json")).write_text(json.dumps(result,indent=2)+"\n")
 print(json.dumps(result),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
 list(executor.map(run,["valid","canonical"]))
