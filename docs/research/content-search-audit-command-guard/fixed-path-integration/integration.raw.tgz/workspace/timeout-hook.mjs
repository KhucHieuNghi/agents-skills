setTimeout(() => {}, 10000);
