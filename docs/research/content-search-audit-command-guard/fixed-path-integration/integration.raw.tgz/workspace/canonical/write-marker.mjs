import {writeFileSync} from "node:fs"; writeFileSync(process.argv[2], "executed\n", {flag:"wx"});
