# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T04:49:16\.908Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run c868cf58\-6cf4\-41f7\-8dd3\-b17c3723d742\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 3 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 2 | 13 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | pending | Snapshot review incomplete | 26 |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | image\-only\-text |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | document\-text |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| c3121196a81f1f266656db8779c45b2b01a67afa26102301ae5b9f49a597e94d | a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500 | local\-file | 2026\-11\-16T04:46:21\.228Z | 0 full elapsed days | [evidence/a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500\.txt](evidence/a33335ab4285e33072f3187d744fbf26087b703cdc65ecc44fd146f082498500.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| document\-manifest | e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | Swift PDFKit PDFPage\.string, visually cross\-checked | 2026\-11\-16T04:46:50Z | 0 full elapsed days | [evidence/document\-manifest\.json](evidence/document-manifest.json) | 23e83061626058d3716c90dde4f7dbc331f36855f97f7982cb1ab824cfb3a031 | PDFKit native text extraction\. Both pages checked against local page rasterizations\.; Text derivative omits layout, PDF tags and non\-text objects\. |
| document\-content | e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | Swift PDFKit PDFPage\.string, visually cross\-checked | 2026\-11\-16T04:46:50Z | 0 full elapsed days | [evidence/document\-content\.txt](evidence/document-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | PDFKit native text extraction\. Both pages checked against local page rasterizations\.; Text derivative omits layout, PDF tags and non\-text objects\. |
| document\-text | e75a3911ce0d1d3b76aa53d38cbfad6093599f75b53c15facb7aa9d1aaca3637 | Swift PDFKit PDFPage\.string, visually cross\-checked | 2026\-11\-16T04:46:50Z | 0 full elapsed days | [evidence/document\-text\.txt](evidence/document-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | PDFKit native text extraction\. Both pages checked against local page rasterizations\.; Text derivative omits layout, PDF tags and non\-text objects\. |
| image\-only\-manifest | d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | PDFKit page rasterization and Tesseract OCR, visually cross\-checked | 2026\-11\-16T04:47:12\.826Z | 0 full elapsed days | [evidence/image\-only\-manifest\.json](evidence/image-only-manifest.json) | f2542360cd3bb635e6959d3d699bb570479059a10233a362e35379fd88225076 | OCR of the only page; terminal output newline removed\.; PDFKit native extraction returned no text\. OCR creates a local audit derivative and does not add native accessible text to the PDF\.; Page image and OCR were compared visually\. |
| image\-only\-content | d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | PDFKit page rasterization and Tesseract OCR, visually cross\-checked | 2026\-11\-16T04:47:12\.826Z | 0 full elapsed days | [evidence/image\-only\-content\.txt](evidence/image-only-content.txt) | 193fd559ef35601ea85c2cb3916b46c0b606315c5a0391a5a2cdd504a6feeaaa | OCR of the only page; terminal output newline removed\.; PDFKit native extraction returned no text\. OCR creates a local audit derivative and does not add native accessible text to the PDF\.; Page image and OCR were compared visually\. |
| image\-only\-text | d5d3659bb3347a1701885c1dd9b663f1535498f2be3945714a242faa714e301c | PDFKit page rasterization and Tesseract OCR, visually cross\-checked | 2026\-11\-16T04:47:12\.826Z | 0 full elapsed days | [evidence/image\-only\-text\.txt](evidence/image-only-text.txt) | 193fd559ef35601ea85c2cb3916b46c0b606315c5a0391a5a2cdd504a6feeaaa | OCR of the only page; terminal output newline removed\.; PDFKit native extraction returned no text\. OCR creates a local audit derivative and does not add native accessible text to the PDF\.; Page image and OCR were compared visually\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
