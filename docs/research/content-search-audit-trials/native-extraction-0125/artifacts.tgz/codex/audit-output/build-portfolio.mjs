import fs from "node:fs";
import {createHash} from "node:crypto";

const dir = "audit-output";
const evidence = fs.readFileSync(dir + "/reviewed/evidence.jsonl", "utf8").trim().split("\n").map(JSON.parse);
const dep = ["html-source-main-text", "document-content", "image-only-content", "locale-context", "export-entity"];
const time = new Date().toISOString();
const value = {
  scope: "All three declared local fixtures",
  items: [
    {file:"render.html", purpose:"English renewal support task", evidence:"Static main gives both steps; ready callback removes the second in code. Browser capture unavailable."},
    {file:"document.pdf", purpose:"English and Vietnamese export policy reference", evidence:"Both pages give the same cap; English states current VN scope, Vietnamese states no extra charge. Owner allows differing emphasis."},
    {file:"image-only.pdf", purpose:"English OCR test fixture", evidence:"Single sentence about OCR; no renewal or export policy content."}
  ]
};
const artifact = "evidence/local-portfolio-map.json";
const record = JSON.stringify(value, null, 2) + "\n";
const reviews = [];
const added = [];
const artifacts = {};
for (const [key, source] of [["renewal","html-source-main-text"],["export","document-content"],["ocr","image-only-content"]]) {
  const itemId = evidence.find(e => e.evidenceId === source).itemId;
  const evidenceId = key + "-portfolio-map";
  const path = artifact.replace(".json", "-" + key + ".json");
  artifacts[path] = record;
  added.push({evidenceId,itemId,kind:"inventory-map",value,artifact:path,encoding:"json",method:"Cross-item review of recovered and raw content",locator:"All three declared fixtures, local inventory",collectedAt:time,snapshotHash:createHash("sha256").update(record).digest("hex"),redaction:"none; authorized local content",limitations:["Local scope only; browser capture and audience demand data unavailable."],sourceEvidenceIds:dep});
  const contentId = key === "renewal" ? evidence.find(e => e.itemId === itemId && e.kind === "content").evidenceId : source;
  reviews.push({itemId,ruleId:"portfolio-duplication",status:"pass",reason:"The three fixtures have distinct purposes. Within the export PDF, the shared cap is legitimate language overlap and the pages add compatible, complementary details. Search cannibalization is unmeasured.",evidenceIds:[contentId,evidenceId],reviewer:"Codex",reviewedAt:time});
  if (key === "export") reviews.push({itemId,ruleId:"portfolio-contradictions",status:"pass",reason:"The export pages agree on the cap and contain compatible scope and cost qualifiers. The other two fixtures address different subjects.",evidenceIds:[contentId,evidenceId,"export-entity"],reviewer:"Codex",reviewedAt:time});
}
fs.writeFileSync(dir + "/portfolio-bundle.json", JSON.stringify({reviews,evidence:added,artifacts},null,2) + "\n");
