import AppKit
import PDFKit
let path = CommandLine.arguments[1]
guard let doc = PDFDocument(url: URL(fileURLWithPath: path)) else { fatalError("Cannot open PDF") }
for index in 0..<doc.pageCount {
    guard let page = doc.page(at: index) else { fatalError("Cannot open page") }
    let thumbnail = page.thumbnail(of: NSSize(width: 1800, height: 1800), for: .mediaBox)
    guard let tiff = thumbnail.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff), let png = bitmap.representation(using: .png, properties: [:]) else { fatalError("Cannot rasterize page") }
    try png.write(to: URL(fileURLWithPath: "audit-output/capture/document-page-\(index + 1).png"))
}
