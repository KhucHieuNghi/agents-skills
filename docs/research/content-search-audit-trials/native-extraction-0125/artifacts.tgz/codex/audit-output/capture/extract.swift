import Foundation
import PDFKit
let encoder = JSONEncoder()
encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
struct Page: Codable { let page: Int; let text: String? }
struct Capture: Codable { let source: String; let collectedAt: String; let pageCount: Int; let pages: [Page] }
for path in CommandLine.arguments.dropFirst() {
    guard let doc = PDFDocument(url: URL(fileURLWithPath: path)) else { fatalError("Cannot open PDF: \(path)") }
    let pages = (0..<doc.pageCount).map { Page(page: $0 + 1, text: doc.page(at: $0)?.string) }
    let capture = Capture(source: path, collectedAt: ISO8601DateFormatter().string(from: Date()), pageCount: doc.pageCount, pages: pages)
    let data = try encoder.encode(capture)
    try data.write(to: URL(fileURLWithPath: "audit-output/capture/" + URL(fileURLWithPath: path).lastPathComponent + ".json"), options: .withoutOverwriting)
}
