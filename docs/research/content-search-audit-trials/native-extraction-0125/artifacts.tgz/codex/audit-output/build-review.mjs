import fs from "node:fs";
import {createHash} from "node:crypto";
import {basename} from "node:path";

const root = "audit-output";
const capture = root + "/capture/";
const sha = value => createHash("sha256").update(value).digest("hex");
const read = path => fs.readFileSync(path, "utf8");
const lines = path => read(path).trim().split("\n").map(line => JSON.parse(line));
const items = Object.fromEntries(lines(root + "/initial/inventory.jsonl").map(item => [basename(item.path), item.itemId]));
const [raw] = lines(root + "/initial/evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "Codex";
const bundle = () => ({reviews: [], artifacts: {}, evidence: []});
const add = (b, name, itemId, kind, value, locator, method, limitations, sourceEvidenceIds = [], collectedAt = now) => {
  const encoding = typeof value === "string" ? "utf8" : "json";
  const artifact = "evidence/" + name + (encoding === "json" ? ".json" : ".txt");
  const bytes = encoding === "json" ? JSON.stringify(value, null, 2) + "\n" : value;
  b.artifacts[artifact] = bytes;
  b.evidence.push({evidenceId: name, itemId, kind, value, locator, method, limitations, sourceEvidenceIds, collectedAt, encoding, artifact, snapshotHash: sha(bytes), redaction: "none; authorized local evidence"});
  return name;
};
const save = (name, b) => fs.writeFileSync(root + "/" + name + ".json", JSON.stringify(b, null, 2) + "\n");

const recovery = bundle();
recovery.collectionRecoveries = [];
for (const [file, key] of [["document.pdf", "document"], ["image-only.pdf", "image-only"]]) {
  const input = JSON.parse(read(capture + file + ".json"));
  const source = fs.readFileSync(input.source);
  const isOcr = key === "image-only";
  const method = isOcr ? "PDFKit page rasterization and Tesseract OCR, visually cross-checked" : "Swift PDFKit PDFPage.string, visually cross-checked";
  const version = isOcr ? "Tesseract 5.5.1 with PDFKit 1.0 (1451.3.3)" : "PDFKit 1.0 (1451.3.3) on macOS 26.3 (25D125)";
  const collectedAt = isOcr ? fs.statSync(capture + "image-only-ocr.txt").mtime.toISOString() : input.collectedAt;
  const pages = isOcr ? [{page: 1, text: read(capture + "image-only-ocr.txt").trimEnd()}] : input.pages;
  const limitations = isOcr
    ? ["OCR of the only page; terminal output newline removed.", "PDFKit native extraction returned no text. OCR creates a local audit derivative and does not add native accessible text to the PDF.", "Page image and OCR were compared visually."]
    : ["PDFKit native text extraction. Both pages checked against local page rasterizations.", "Text derivative omits layout, PDF tags and non-text objects."];
  const manifest = {schemaVersion: 1, sourceSha256: sha(source), sourceByteLength: source.length, extractor: {name: method, version}, pageCount: input.pageCount, pages, coverage: "complete", limitations};
  const itemId = items[file];
  const locator = input.source + (isOcr ? " page 1, OCR" : " pages 1–2, native text");
  const m = add(recovery, key + "-manifest", itemId, "extraction-provenance", manifest, locator, method, limitations, [], collectedAt);
  const value = pages.map(p => p.text).join("\f");
  const c = add(recovery, key + "-content", itemId, "content", value, locator, method, limitations, [m], collectedAt);
  const t = add(recovery, key + "-text", itemId, "extracted-text", value, locator, method, limitations, [c], collectedAt);
  recovery.collectionRecoveries.push({itemId, manifestEvidenceId: m, contentEvidenceId: c, textEvidenceId: t, reviewer, reviewedAt: now, reason: isOcr ? "Verified the entire one-page raster against OCR and retained the native extraction miss." : "Verified both native page extracts and their reading order against the two rasterized pages."});
}
save("recovery-bundle", recovery);

const b = bundle();
b.findings = [];
const h = items["render.html"], d = items["document.pdf"], i = items["image-only.pdf"];
const doc = "document-content", image = "image-only-content";
const user = (name, itemId, kind, value, limitations = ["Owner-supplied audit context."]) => add(b, name, itemId, kind, value, "Current audit request, owner-supplied context", "Task-statement capture", limitations);
const task = user("renewal-task", h, "audience-context", "Approved renewal task requires opening Billing and selecting Disable renewal. The owner confirms document.documentElement.dataset.auditReady === true means the content has finished rendering.");
const question = user("renewal-question", h, "question-set", "Owner-declared task, restated as a question: How do I disable renewal? Approved actions: open Billing and select Disable renewal.");
const policy = user("export-policy", d, "claim-sources", "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge.", ["Owner-approved comparison basis for this audit; independent product behavior unverified."]);
const entity = add(b, "export-entity", d, "entity-record", {market: "VN", plans: "current", perExportMaximum: 5000, additionalCharge: "none"}, "Owner context, approved export policy", "Structured transcription of supplied policy", ["Comparison scoped to current VN plans."], [policy]);
const locale = user("locale-context", d, "audit-context", "English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.");
const exportAudience = add(b, "export-audience", d, "audience-context", "Inferred task: readers of the export policy need the per-export limit and possible extra charge for current VN plans.", "document.pdf pages 1–2 and owner-approved policy", "Auditor interpretation", ["Audience inferred from the fixture and policy; no usage data."], [doc, policy]);
const browser = add(b, "chrome-attempt", h, "collection-attempt", {surface:"local Chrome headless isolated profile",exitCode:134,signal:6,stdoutBytes:0,stderrBytes:0,readySignalObserved:false}, "Local Chrome attempt on targets/render.html", "Shell execution with fresh profile and host resolver blocked", ["Chrome exited via SIGABRT without diagnostic output. Cause unverified. No DOM captured."], [raw.evidenceId], fs.statSync(capture + "chrome.stderr").mtime.toISOString());
const htmlText = add(b, "html-source-main-text", h, "extracted-text", raw.value.match(/<main[^>]*>([^<]+)<\/main>/)[1], "targets/render.html line 1, static main element", "Inert source extraction", ["Source markup text only; browser output unavailable."], [raw.evidenceId]);
const nativeMiss = add(b, "image-only-native-attempt", i, "collection-attempt", JSON.parse(read(capture + "image-only.pdf.json")), "targets/image-only.pdf page 1", "Swift PDFKit PDFPage.string", ["No native text returned; raster and OCR subsequently showed visible text."], ["image-only-manifest"], JSON.parse(read(capture + "image-only.pdf.json")).collectedAt);
const media = add(b, "image-only-media", i, "media-inventory", {page:1,figureObject:"12 0 obj",figureDictionary:"<< /Type /StructElem /S /Figure /P 11 0 R /Pg 2 0 R /K 0 >>",embeddedAlternativeInFigure:false,nativeTextReturned:false,rasterSha256:sha(fs.readFileSync(capture + "image-only-page-1.png"))}, "targets/image-only.pdf page 1, structure element object 12; capture/image-only-page-1.png", "Visual raster review and PDF structure dictionary inspection", ["No Alt or ActualText in the Figure dictionary or other inspected PDF strings. No assistive-technology session was run."], [image, nativeMiss]);
const review = (itemId, ruleId, status, reason, evidenceIds) => b.reviews.push({itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now});
const rawId = raw.evidenceId;
const renewalRules = ["quality-task-fit", "aio-retrievable-facts", "aeo-question-coverage", "aeo-answer-context"];
const support = [rawId, htmlText, task, question, browser];
for (const rule of renewalRules) review(h, rule, "fail", "Source-level defect: the readiness callback replaces the complete initial instructions with only the first action, then sets the owner-confirmed ready signal. Local browser output remains unverified.", support);
review(h, "seo-rendering", "unknown", "Chrome exited without DOM output. Source inspection establishes the replacement in code; the local rendered state remains unverified.", [rawId, task, browser]);
review(h, "seo-structured-data", "unknown", "No structured data in the inspected raw markup. No rendered capture or feature eligibility evidence.", [rawId, browser]);
review(h, "quality-accessible-media", "not-applicable", "The inspected fixture contains text and script and declares no informative media; the source callback only changes text.", [rawId]);
review(h, "seo-metadata", "unknown", "The source title labels the controlled fixture. Production search presentation intent and browser capture are unavailable.", [rawId, task]);
review(d, "quality-task-fit", "pass", "The two-page document supplies the 5000-record per-export cap, current VN-plan scope, and no-extra-charge qualifier across its two pages.", [doc, exportAudience, locale]);
review(d, "quality-claims", "pass", "The stated maximum, current VN scope and no-extra-charge claim agree with the owner-approved comparison policy at document level.", [doc, policy, locale]);
review(d, "quality-freshness", "pass", "The English page explicitly scopes the cap to current VN plans. The wording agrees with owner-approved current policy at review time.", [doc, policy]);
review(d, "aio-entity-consistency", "pass", "Both pages state the same per-export maximum. Current VN scope and no-extra-charge details are compatible with the approved entity record; the owner allows different language emphasis.", [doc, entity, locale]);
review(d, "aio-retrievable-facts", "pass", "The cap and complementary qualifiers are recoverable from the native text across both pages.", [doc, exportAudience, policy]);
review(d, "aeo-answer-evidence", "pass", "The export limit and qualifiers are supported by the approved owner policy across the document. A standalone excerpt should retain the VN plan scope.", [doc, policy, locale]);
review(d, "quality-accessible-media", "not-applicable", "Review of both rasterized pages found text only and no informative graphics needing an equivalent. This check does not address PDF reading-order tags.", [doc, "document-manifest"]);
review(i, "quality-accessible-media", "fail", "The only visible sentence is embedded in a figure. Native extraction returned no text, and the figure structure element supplies neither an alternate description nor replacement text. External OCR recovers the content for this audit only.", [image, media, nativeMiss]);
review(i, "quality-task-fit", "unknown", "OCR recovered the complete visible sentence, but a separate intended audience task for this fixture was not supplied.", [image, media]);
for (const [itemId, evidence, source] of [[d, doc, "document-manifest"], [i, image, "image-only-manifest"]]) {
  review(itemId, "seo-rendering", "not-applicable", "The supplied local PDF was reviewed as static pages; this rule addresses script-driven source-to-DOM changes. Engine treatment remains unmeasured.", [evidence, source]);
  review(itemId, "seo-canonical", "unknown", "Public HTTP Link headers, canonical targets and publication intent were not supplied.", [evidence]);
}
b.findings.push({
  findingId:"renewal-ready-callback-drops-step", affectedItemIds:[h], ruleIds:renewalRules, dimensions:["quality","aio","aeo"], evidenceIds:support,
  classification:"observed", severity:"high", confidence:"high", title:"Renewal source callback removes the required final step",
  remediation:"Preserve both approved actions in the main element when the ready signal is set.",
  verification:"In an authorized isolated local browser, wait for the owner-confirmed ready signal and capture main text. Verify that opening Billing and selecting Disable renewal are both present in order.",
  ownerRole:"Fixture maintainer",effort:"small",action:"update",actionReason:"The ready-state code removes the action needed to complete renewal disablement."
},{
  findingId:"image-only-missing-text-equivalent",affectedItemIds:[i],ruleIds:["quality-accessible-media"],dimensions:["quality"],evidenceIds:[image,media,nativeMiss],
  classification:"observed",severity:"medium",confidence:"high",title:"The image-only PDF has no text equivalent for its informative figure",
  remediation:"If used as accessible content, supply selectable text or an equivalent through the figure tag; preserve the authored image-only control when it is needed as a test fixture.",
  verification:"Inspect the resulting figure tag or native accessible text and confirm the full visible sentence is exposed in reading order.",
  ownerRole:"PDF author",effort:"small",action:"update",actionReason:"The OCR-derived audit text does not provide a text equivalent inside the distributed PDF."
});
save("semantic-bundle", b);
