import fs from "node:fs"; import crypto from "node:crypto";
const [W, T] = process.argv.slice(2);
const h = s => crypto.createHash("sha256").update(s).digest("hex");
const now = new Date().toISOString();
const R="c725e76a066d8dbd9cfe8e2f0f928c1779960d87772445a79b247e0c7bd2d9c5", D="a85afde16cd261e6d9bdff9d6aae78af4f7ff72e27d40e9e422a8f797dbe0d6a";
const contentEv = "ddb8e49ed794f0aa431c39ea9f3b87655a80183caccc56fb5c660ce3eacc7ace";
const artifacts = {}, evidence = [];
function add(id,itemId,kind,method,locator,limitations,value,enc,src){
  const art = enc==="json" ? JSON.stringify(value) : value;
  const path = `evidence/${id}.${enc==="json"?"json":"txt"}`;
  artifacts[path]=art;
  evidence.push({evidenceId:id,itemId,kind,method,collectedAt:now,locator,snapshotHash:h(art),byteLength:Buffer.byteLength(art),redaction:"none; controlled authored fixture",limitations,sourceEvidenceIds:src,artifact:path,encoding:enc,value});
}
const dom = fs.readFileSync(`${W}/work/out/render.dom.html`,"utf8");
add("ev-render-dom",R,"rendered-dom","chrome-headless-dump-dom",`file://${T}/render.html (Google Chrome 157.0.8103.51, fresh temporary profile, virtual-time-budget 3000ms, default sandbox)`,["Single headless capture after dataset.auditReady === 'true' was observed in the dumped DOM; repeatability, other browsers and viewports not tested","Local file capture; no HTTP response or index state"],dom,"utf8",[contentEv]);
const taskCtx = "Owner-approved renewal task (supplied in the audit request): opening Billing and selecting Disable renewal.";
add("ev-render-task",R,"claim-sources","user-task-statement","audit request, approved renewal task",["Owner statement is an approved comparison basis, not independently verified platform behavior"],taskCtx,"utf8",[]);
const pdf = JSON.parse(fs.readFileSync(`${W}/work/out/document.pdfkit.json`,"utf8"));
const text = pdf.pages.map(p=>p.text).join("\f");
const bytes = fs.readFileSync(`${T}/document.pdf`);
const manifest = {schemaVersion:1,sourceSha256:h(bytes),sourceByteLength:bytes.length,extractor:{name:"macOS PDFKit PDFPage.string (Swift)",version:"Darwin 25.3.0 system framework"},pageCount:pdf.pageCount,pages:pdf.pages,coverage:"complete",limitations:["Text-layer extraction only; no OCR; reading order and visual rendering not verified","Page count and text fidelity are the extractor's assertions"]};
add("ev-doc-manifest",D,"extraction-provenance","pdfkit-text-layer",`${T}/document.pdf`,manifest.limitations,manifest,"json",[]);
add("ev-doc-content",D,"content","pdfkit-text-layer",`${T}/document.pdf`,manifest.limitations,text,"utf8",["ev-doc-manifest"]);
add("ev-doc-text",D,"extracted-text","pdfkit-text-layer",`${T}/document.pdf`,manifest.limitations,text,"utf8",["ev-doc-content"]);
add("ev-doc-policy",D,"claim-sources","user-task-statement","audit request, approved export policy",["Owner statement is an approved comparison basis, not independently verified platform behavior"],"Approved export policy (supplied in the audit request): current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.","utf8",[]);
const rv = (itemId,ruleId,status,reason,evidenceIds)=>({itemId,ruleId,status,reason,evidenceIds,reviewer:"Claude Code audit host (Sonnet 5.5)",reviewedAt:now});
const reviews=[
 rv(R,"seo-rendering","fail","Raw HTML text of #task is 'Open Billing. Select Disable renewal.'; after the ready signal in Chrome the rendered DOM text is 'Open Billing.' The inline script removes the second sentence.",[contentEv,"ev-render-dom"]),
 rv(R,"quality-claims","fail","The rendered page omits 'Select Disable renewal', which the owner-approved task requires after opening Billing.",[contentEv,"ev-render-dom","ev-render-task"]),
 rv(D,"quality-claims","pass","Page 1 states a single export contains at most 5000 records and applies to current VN plans; page 2 (Vietnamese) states 5000 records per export and no additional payment. Both agree with the owner-approved policy. The English page not mentioning charges is an emphasis difference the owner said is acceptable.",["ev-doc-content","ev-doc-policy"]),
];
const findings=[{findingId:"F-001",title:"Rendered render.html drops the 'Select Disable renewal' step present in the raw HTML",affectedItemIds:[R],ruleIds:["seo-rendering","quality-claims"],dimensions:["seo","quality"],evidenceIds:[contentEv,"ev-render-dom","ev-render-task"],classification:"observed",severity:"medium",confidence:"high",remediation:"Make the rendered state keep the full approved instruction ('Open Billing. Select Disable renewal.') or change the source so raw and rendered text agree on the intended steps.",verification:"Re-capture the DOM in a fresh isolated browser profile after dataset.auditReady === 'true' and confirm #task contains both sentences.",ownerRole:"Content engineer",effort:"low",description:"One headless Chrome capture; repeatability across browsers/viewports is untested and the cause is script code in the page, read as text."}];
fs.writeFileSync(`${W}/work/bundle.json`,JSON.stringify({reviews,evidence,artifacts,findings,collectionRecoveries:[{itemId:D,manifestEvidenceId:"ev-doc-manifest",contentEvidenceId:"ev-doc-content",textEvidenceId:"ev-doc-text",reviewer:"Claude Code audit host (Sonnet 5.5)",reviewedAt:now,reason:"PDFKit returned non-empty text for both pages (2/2); text-layer only, reading order unverified."}]},null,1));
