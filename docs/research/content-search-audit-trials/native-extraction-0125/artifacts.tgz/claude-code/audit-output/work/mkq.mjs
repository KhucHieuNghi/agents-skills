import fs from "node:fs";
const L=(f,n)=>fs.readFileSync(f,"utf8").split("\n")[n-1];
const rep=fs.readFileSync("audit-output/audit-narrative.md","utf8").split("\n");
const q=[];
const add=(id,src,sl,quote,locator)=>{const i=rep.findIndex(l=>l.includes(quote)&&l.includes(locator));if(i<0)throw new Error("no "+id);q.push({quoteId:id,source:src,sourceLabel:src,sourceHash:"",startLine:sl,endLine:sl,reportStartLine:i+1,reportEndLine:i+1,normalization:"exact",quote});};
import crypto from "node:crypto";
const items=[
["q1","targets/render.html",1,"Open Billing. Select Disable renewal.","render.html:1"],
["q2","audit-output/run-2-reviewed/evidence/ev-render-dom.txt",2,'<main id="task">Open Billing.</main>',"ev-render-dom.txt:2"],
["q3","audit-output/run-2-reviewed/evidence/ev-doc-content.txt",2,"A single export contains at most 5000 records.","ev-doc-content.txt:2"],
["q4","audit-output/run-2-reviewed/evidence/ev-doc-content.txt",3,"Applies to current VN plans.","ev-doc-content.txt:3"],
["q5","audit-output/run-2-reviewed/evidence/ev-doc-content.txt",4,"Mỗi lần xuất tối đa 5000 bản ghi.","ev-doc-content.txt:4"],
["q6","audit-output/run-2-reviewed/evidence/ev-doc-content.txt",5,"Không cần thanh toán thêm.","ev-doc-content.txt:5"]];
for(const [id,s,n,qt,loc] of items){ if(!L(s,n).includes(qt)) throw new Error("src "+id); add(id,s,n,qt,loc); q.at(-1).sourceHash=crypto.createHash("sha256").update(fs.readFileSync(s)).digest("hex");}
fs.writeFileSync("audit-output/quote-ledger.json",JSON.stringify({root:process.cwd(),report:"audit-output/audit-narrative.md",reportHash:crypto.createHash("sha256").update(fs.readFileSync("audit-output/audit-narrative.md")).digest("hex"),quotes:q},null,1));
