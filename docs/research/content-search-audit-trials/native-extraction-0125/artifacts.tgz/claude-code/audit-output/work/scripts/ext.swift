import PDFKit
import Foundation
let p = CommandLine.arguments[1]
guard let d = PDFDocument(url: URL(fileURLWithPath: p)) else { print("{\"error\":\"cannot open\"}"); exit(2) }
var pages: [[String:Any]] = []
for i in 0..<d.pageCount { pages.append(["page": i+1, "text": d.page(at: i)?.string ?? ""]) }
let o: [String:Any] = ["pageCount": d.pageCount, "pages": pages, "locked": d.isLocked]
let data = try! JSONSerialization.data(withJSONObject: o, options: [.sortedKeys])
print(String(data: data, encoding: .utf8)!)
