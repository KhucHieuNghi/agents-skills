// Builds the quote ledger from the final report. Usage: node build-quotes.mjs ROOT OUT.json
// Ledgered lines have the form: - **file.md:N** — `quote`
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const sha = (b) => createHash("sha256").update(b).digest("hex");
const reportBytes = readFileSync(path.join(root, "report.md"));
const quotes = [];
reportBytes
  .toString("utf8")
  .split("\n")
  .forEach((line, index) => {
    const m = /^- \*\*(\d\d-[a-z-]+\.md):(\d+)\*\* — `(.*)`$/.exec(line);
    if (!m) return;
    const [, file, n, quote] = m;
    const source = `targets/${file}`;
    quotes.push({
      quoteId: `q${String(quotes.length + 1).padStart(2, "0")}-${file}-${n}`,
      source,
      sourceLabel: file,
      sourceHash: sha(readFileSync(path.join(root, source))),
      startLine: Number(n),
      endLine: Number(n),
      reportStartLine: index + 1,
      reportEndLine: index + 1,
      normalization: "exact",
      quote,
    });
  });
writeFileSync(
  out,
  JSON.stringify(
    { root, report: "report.md", reportHash: sha(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(JSON.stringify({ ledgered: quotes.length }));
