// Builds the declared-inventory config for the audit run. Usage: node make-config.mjs WORKDIR OUT.json
import { readdirSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const targets = path.join(root, "targets");
const locale = { "05-huong-dan.md": "vi", "07-locale.md": "vi" };
const inputs = readdirSync(targets)
  .filter((f) => f.endsWith(".md"))
  .sort()
  .map((f) => ({
    path: path.join(targets, f),
    source: "export",
    ...(locale[f] ? { locale: locale[f] } : {}),
  }));
// Declared in-scope underlying items of dossier 09; only URL strings were supplied.
inputs.push({
  uri: "https://docs.example.invalid/guide.pdf",
  source: "declared-url",
  type: "pdf",
});
inputs.push({
  uri: "https://docs.example.invalid/video",
  source: "declared-url",
});
writeFileSync(
  out,
  JSON.stringify(
    { inputs, localRoots: [targets], inventoryComplete: true, mode: "full" },
    null,
    2,
  ) + "\n",
);
