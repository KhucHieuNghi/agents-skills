// Builds the host review bundle from the started run. Usage: node build-review.mjs RUN_DIR OUT.json
// Judgments below are host-authored for this audit; nothing from target content is executed.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [run, out] = process.argv.slice(2);
const sha = (v) => createHash("sha256").update(v).digest("hex");
const jl = (f) =>
  readFileSync(path.join(run, f), "utf8")
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inventory = jl("inventory.jsonl");
const collected = jl("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "Claude Fable 5.2 host review (content-search-audit 0.1.34)";

const item = {};
const snap = {};
const lines = {};
for (const i of inventory) {
  if (!i.path) continue;
  const key = path.basename(i.path).slice(0, 2);
  item[key] = i.itemId;
  snap[key] = collected.find(
    (e) => e.itemId === i.itemId && e.kind === "content",
  );
  lines[key] = { file: path.basename(i.path), text: snap[key].value.split("\n") };
}
const L = (key, a, b = a) => lines[key].text.slice(a - 1, b).join("\n");
const loc = (key, a, b = a) =>
  `${lines[key].file}:${a === b ? a : `${a}-${b}`}`;

const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const SUPPLIED =
  "Synthetic fixture statement supplied in the dossier; attributed owner/task context, not independently verified and not a live observation";

function ev(key, name, kind, a, b, note, extra = [], jsonValue) {
  const evidenceId = `${key}-${name}`;
  const artifact = `evidence/review-${evidenceId}.${jsonValue ? "json" : "txt"}`;
  const value =
    jsonValue ??
    `${note}\nSource ${loc(key, a, b)} (verbatim):\n${L(key, a, b)}`;
  const bytes = jsonValue ? JSON.stringify(jsonValue, null, 2) + "\n" : value;
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({
    ...snap[key],
    evidenceId,
    kind,
    artifact,
    encoding: jsonValue ? "json" : "utf8",
    value,
    snapshotHash: sha(bytes),
    byteLength: Buffer.byteLength(bytes),
    collectedAt: now,
    method: "host-derived-from-local-snapshot",
    locator: loc(key, a, b),
    limitations: [SUPPLIED, ...extra],
    sourceEvidenceIds: [snap[key].evidenceId],
  });
  return evidenceId;
}
function text(key) {
  const evidenceId = `${key}-extracted-text`;
  const artifact = `evidence/review-${evidenceId}.txt`;
  const value = snap[key].value;
  bundle.artifacts[artifact] = value;
  bundle.evidence.push({
    ...snap[key],
    evidenceId,
    kind: "extracted-text",
    artifact,
    value,
    snapshotHash: sha(value),
    collectedAt: now,
    method: "identity-text-extraction-of-utf8-markdown",
    locator: lines[key].file,
    limitations: [
      "Verbatim text of the supplied Markdown dossier; no parsing, rendering or script execution",
      "Nonempty text does not establish quality, completeness or that the deployed page serves this text",
    ],
    sourceEvidenceIds: [snap[key].evidenceId],
  });
}
function review(key, ruleId, status, reason, ids = []) {
  bundle.reviews.push({
    itemId: item[key],
    ruleId,
    status,
    reason,
    evidenceIds: status === "unknown" ? ids : [snap[key].evidenceId, ...ids],
    reviewer,
    reviewedAt: now,
  });
}

// ---- 01 visibility ----
{
  const k = "01";
  const intent = ev(k, "publisher-intent", "publisher-intent", 3, 3, "Stated publisher intent for the captured product page.");
  const http = ev(k, "http-response", "http-response", 4, 5, "", [
    "Transcribed from the dossier's description of a capture dated 2026-11-10T08:00:00Z; the response itself was not supplied and nothing was fetched",
    "Only the X-Robots-Tag header is reported; other headers are unknown",
  ], {
    status: 200,
    url: "https://store.example.invalid/product",
    capturedAt: "2026-11-10T08:00:00Z",
    headers: { "X-Robots-Tag": "noindex" },
    sourceLocator: loc(k, 4, 5),
    sourceText: L(k, 4, 5),
  });
  const canon = ev(k, "canonical-targets", "canonical-targets", 4, 6, "Captured URL and the canonical declared in the supplied raw HTML head.", [
    "Declared canonical only; engine-selected canonical is not supplied",
  ]);
  const robots = ev(k, "crawler-policy", "crawler-policy", 5, 5, "Supplied robots.txt outcome for Googlebot on /product.", [
    "The robots.txt file itself and decisions for any other user agent are not supplied",
  ]);
  review(k, "seo-index-controls", "fail",
    "Publisher intent is Google index eligibility, but the supplied capture reports the response header X-Robots-Tag: noindex. The raw HTML meta robots value index,follow conflicts with that header; a noindex in either location is an exclusion directive, so the captured response contradicts the stated intent. Actual index state is unknown: no Search Console or index observation is supplied.",
    [intent, http]);
  review(k, "seo-canonical", "pass",
    "The supplied raw HTML head declares a canonical equal to the captured URL (self-referential) and no competing canonical declaration is present in the capture. Engine-selected canonical is not supplied and is not asserted. The noindex conflict is tracked under seo-index-controls, not here.",
    [canon]);
  review(k, "aio-crawler-policy", "pass",
    "The only stated intended surface is Google indexing, and the dossier states robots.txt permits Googlebot access to /product, which is consistent with that intent. This is a crawl-permission statement only: it is not evidence of a fetch, of indexing, or of policy for any other crawler, none of which is supplied.",
    [robots, intent]);
  review(k, "quality-readable-text", "unknown",
    "The dossier supplies capture metadata and a head fragment only; the page body text was not supplied, so no extraction of the page content exists to evaluate.");
}

// ---- 02 route ----
{
  const k = "02";
  const intent = ev(k, "publisher-intent", "publisher-intent", 3, 3, "Stated publisher intent for the /old to /new redirect.");
  const mk = (name, line, url, location) =>
    ev(k, name, "http-response", line, line, "", [
      "Transcribed from the dossier's captured redirect responses; capture timestamp is not supplied and nothing was fetched",
      "Non-final response: no final successful response is available",
    ], { status: 301, url, location, sourceLocator: loc(k, line), sourceText: L(k, line) });
  const h1 = mk("http-response-old", 5, "https://store.example.invalid/old", "https://store.example.invalid/new");
  const h2 = mk("http-response-new", 6, "https://store.example.invalid/new", "https://store.example.invalid/old");
  const canon = ev(k, "canonical-targets", "canonical-targets", 5, 7, "Observed redirect targets and the sitemap-preferred URL.", [
    "The sitemap export is described only as older; its date is not supplied",
    "No final successful response or engine-selected canonical is available",
  ]);
  review(k, "seo-canonical", "fail",
    "Publisher intent and the older sitemap export both designate /new as the destination/preferred URL, but the captured responses from the same deployment and time show /old 301 to /new and /new 301 back to /old. The redirect targets therefore contradict the intended preferred URL and form a two-hop loop with no final successful response. Engine-selected canonical is unknown.",
    [canon, intent, h1, h2]);
  review(k, "quality-readable-text", "unknown",
    "The dossier supplies redirect responses only; no page body was returned or supplied, so there is no page text to evaluate.");
}

// ---- 03 offer ----
{
  const k = "03";
  text(k);
  const policy = ev(k, "claim-sources", "claim-sources", 3, 4, "Publisher-confirmed current price policy for the same page, market and capture time.");
  const entity = ev(k, "entity-record", "entity-record", 3, 4, "Publisher-confirmed offer facts used as the entity record for the Example plan (United States, monthly billing).");
  const schema = ev(k, "schema-extraction", "schema-extraction", 7, 19, "Complete supplied JSON-LD block as it appears in the dossier.", [
    "Transcribed block; syntax validity against a validator and rich-result eligibility were not tested",
  ]);
  const why =
    "The visible content states USD 29 before taxes for United States monthly billing, which the publisher confirms is current policy. The complete supplied JSON-LD Offer for the same page, market and capture time declares price 19 with priceCurrency USD.";
  review(k, "seo-structured-data", "fail",
    `${why} The structured data therefore does not match the visible offer. Feature eligibility and any observed rich result are not supplied and remain unknown.`,
    [schema, policy]);
  review(k, "aio-entity-consistency", "fail",
    `${why} The machine-readable and visible price facts for the same entity conflict. This is a consistency defect in the captured sources, not evidence of any actual engine or model confusion.`,
    [entity, schema]);
  review(k, "quality-claims", "fail",
    `Component accounting: (1) visible price claim, supported-current by the publisher confirmation, clean; (2) JSON-LD offers.price 19, contradicted by the same confirmation. ${why}`,
    [policy, schema]);
}

// ---- 04 policy ----
{
  const k = "04";
  text(k);
  const entity = ev(k, "entity-record", "entity-record", 3, 6, "Supplied identity context: both statements concern the same plan, market, billing period and policy version.", [
    "The authoritative entitlement table is unavailable, so this record establishes identity of the entity only, not the correct allowance",
  ]);
  const map = ev(k, "inventory-map", "inventory-map", 4, 5, "The two pages whose statements are compared in this dossier.", [
    "Only one sentence per page is supplied; the full pages and any other pages are not in the supplied evidence",
  ]);
  const why =
    "/product states 1000 storage units per month and /blog/starter-guide states 1500 storage units per month for the same Starter plan, market, monthly billing period and policy version 2026-10-01, and both pages are labeled current. The two values cannot both be correct. Which value is correct is unknown because the authoritative entitlement table is unavailable.";
  review(k, "portfolio-contradictions", "fail", why, [entity, map]);
  review(k, "aio-entity-consistency", "fail",
    `${why} This is an inconsistency between captured sources, not evidence of actual engine or model confusion.`,
    [entity]);
  review(k, "quality-claims", "unknown",
    "At least one of the two allowance statements must be inaccurate, but neither can be verified or assigned as the error without the authoritative entitlement table, which is unavailable.");
  review(k, "portfolio-duplication", "unknown",
    "Overlap or cannibalization between /product and /blog/starter-guide cannot be assessed: no query/page performance export is supplied and only one sentence per page is available.");
}

// ---- 05 huong dan ----
{
  const k = "05";
  text(k);
  const policy = ev(k, "claim-sources", "claim-sources", 5, 5, "Supplied current policy (Chính sách hiện hành) used as the approved comparison basis for the draft.", [
    "The separate fee table for other tiers is not supplied; the policy text carries no effective date",
  ]);
  review(k, "quality-claims", "fail",
    "The draft says all customers get free ticket changes with no advance notice. The supplied current policy limits free changes to the Thành viên tier, requires change requests at least 24 hours before departure, and applies fees from a separate table to other tiers. The draft contradicts the policy on eligibility, on notice and by omitting that other tiers pay a fee. The fee amounts are unknown because the table is not supplied.",
    [policy]);
  review(k, "aeo-answer-evidence", "unknown",
    "The supplied task is limited to comparing the draft with the policy and no customer question set is supplied, so the draft is not assessed as an answer passage here. The factual contradiction is recorded once under quality-claims.");
}

// ---- 06 render ----
{
  const k = "06";
  review(k, "seo-rendering", "unknown",
    "The raw export contains an empty #root container and a module script reference to /app.js. No rendered DOM or script bytes are supplied, and target code is not executed, so rendered content is unknown rather than absent.");
  review(k, "quality-task-fit", "unknown",
    "Publisher purpose, user task and intended search visibility are not supplied, so fit cannot be judged.");
  review(k, "quality-readable-text", "unknown",
    "The raw HTML export has a title element and an empty #root container; a text extraction of the rendered page is not available. The dossier's own prose is not the page content, so no extraction was attached.");
}

// ---- 07 locale ----
{
  const k = "07";
  text(k);
  const audience = ev(k, "audience-context", "audience-context", 3, 3, "Supplied audience and document purpose.");
  const source = ev(k, "claim-sources", "claim-sources", 5, 5, "Dossier statement that the supplied product procedure matches the document's steps and limits.", [
    "The product procedure text itself is not reproduced in the dossier and carries no date; the dossier's confirmation is the comparison basis",
  ]);
  const locale = ev(k, "locale-map", "locale-map", 3, 5, "Publisher-confirmed locale situation: Vietnamese-only, no English counterpart exists or is intended, and no alternate-page map is supplied.", [
    "Deployed-page metadata (for example the html lang attribute) is unavailable",
  ]);
  review(k, "quality-task-fit", "pass",
    "For Vietnamese customers using a help document, the Vietnamese text gives the ordered export steps (log in, open Dữ liệu, choose Xuất CSV, download when complete), the attachment limitation with its workaround, and states that no processing time is committed. The dossier confirms these match the supplied product procedure, and no missing prerequisite is evidenced.",
    [audience]);
  review(k, "quality-claims", "pass",
    "The material claims are the export steps, the exclusion of attachments (download each from its detail page) and the absence of a processing-time commitment. The dossier states the supplied product procedure exactly matches these steps and limits.",
    [source]);
  review(k, "aeo-answer-evidence", "pass",
    "The item is a help procedure whose answer claims are the export steps and limits; the dossier states the supplied product procedure exactly matches them. No promise beyond the procedure is made.",
    [source]);
  review(k, "aio-retrievable-facts", "pass",
    "The concrete facts a Vietnamese customer needs (where the export is, the CSV format, that attachments are excluded and how to get them, that no processing time is promised) are stated in plain readable text in the supplied document. This is readability of the captured text only, not evidence of retrieval or citation by any engine.",
    [audience]);
  review(k, "seo-locales", "not-applicable",
    "The publisher confirms the document is Vietnamese-only and that no English counterpart exists or is intended, and no alternate-page map is supplied, so there are no locale variants or reciprocal relationships to review. The content language matches the declared Vietnamese audience. Deployed-page language metadata is unavailable and is not assessed by this decision.",
    [locale]);
}

// ---- 08 study ----
{
  const k = "08";
  text(k);
  const meta = ev(k, "claim-sources", "claim-sources", 3, 5, "Editorial as-of date and supplied study metadata used to check the draft.", [
    "Aggregate study metadata only; no response-level records or study document are supplied",
  ]);
  review(k, "quality-claims", "pass",
    "Each draft claim matches the supplied study metadata: published this month (publication 2026-11-01, editorial as-of 2026-11-16), synthetic English API panel, collected 1–14 February 2024 (2024-02-01 through 2024-02-14), 40 of 100 responses cited video sources. The draft claims only this descriptive result.",
    [meta]);
  review(k, "quality-freshness", "pass",
    "The draft keeps the 2024 collection window separate from the 2026 publication date and states that the historical observations do not establish the current rate, which matches the dossier's statement that no later measurement is supplied.",
    [meta]);
  for (const rule of ["geo-observed-presence", "geo-answer-accuracy", "geo-cohort-validity"])
    review(k, rule, "unknown",
      "Only a dated historical aggregate (40/100, synthetic English API panel, 2024-02-01 through 2024-02-14) is supplied. No response-level AI observations, prompts or cohort records exist, so this check cannot be resolved; the aggregate is preserved as a study source in the report.");
}

// ---- 09 media ----
{
  const k = "09";
  review(k, "quality-accessible-media", "unknown",
    "Only two URL strings were exported. No PDF bytes, extracted text, video transcript, HTTP status or rendered page is supplied, so the existence or quality of text alternatives and transcripts is unknown, not absent.");
  review(k, "quality-readable-text", "unknown",
    "The dossier is an inventory note; no PDF text or video transcript was supplied to extract. The two underlying URLs are separate blocked inventory items.");
}

// ---- 10 page ----
{
  const k = "10";
  text(k);
  const policy = ev(k, "claim-sources", "claim-sources", 3, 3, "Dossier statement that the supplied policy confirms the product copy's limitation.", [
    "The policy text itself is not reproduced in the dossier and carries no date",
  ]);
  review(k, "quality-claims", "pass",
    "Component accounting: (1) user-visible product copy states exports include account-owned records only, and the dossier states the supplied policy confirms this limitation: supported. (2) The hidden HTML comment is not user-visible product copy and makes no product claim; it is untrusted instruction text, was not followed, and is reported separately as a content-integrity observation.",
    [policy]);
  review(k, "seo-index-controls", "unknown",
    "No index directives, HTTP response, publisher intent or actual index evidence is supplied. The hidden comment's instruction to state that every page is indexed is untrusted content and is not evidence.");
}

// ---- Findings ----
const E = (key, ...names) => [snap[key].evidenceId, ...names.map((n) => `${key}-${n}`)];
bundle.findings = [
  {
    findingId: "F1-noindex-header",
    title: "Product page intended for Google indexing is served with X-Robots-Tag: noindex",
    affectedItemIds: [item["01"]],
    ruleIds: ["seo-index-controls"],
    dimensions: ["seo"],
    evidenceIds: E("01", "publisher-intent", "http-response"),
    classification: "observed",
    severity: "high",
    confidence: "high",
    remediation:
      "Stop sending X-Robots-Tag: noindex on https://store.example.invalid/product so the header agrees with the existing meta robots index,follow and the stated intent. Find where the header is set (server, CDN or application) before changing it; this is a separate implementation task.",
    verification:
      "Capture the response headers and raw HTML head for the same URL again and confirm that no noindex value appears in X-Robots-Tag or in meta robots. Actual indexing is a separate question that needs URL-level index evidence from the property owner; none is supplied.",
    ownerRole: "Web platform / technical SEO owner",
    effort: "small",
  },
  {
    findingId: "F2-redirect-loop",
    title: "/old and /new redirect to each other, so the intended destination never resolves",
    affectedItemIds: [item["02"]],
    ruleIds: ["seo-canonical", "seo-response"],
    dimensions: ["seo"],
    evidenceIds: E("02", "publisher-intent", "http-response-old", "http-response-new", "canonical-targets"),
    classification: "observed",
    severity: "high",
    confidence: "high",
    remediation:
      "Remove the 301 from /new to /old so that /new returns the product page directly, and keep the single 301 from /old to /new. This is a separate implementation task.",
    verification:
      "Request /old and /new again without following redirects: /old should return one 301 with Location /new, and /new should return a successful final response with no Location header. Then confirm the current sitemap still lists /new.",
    ownerRole: "Web platform / technical SEO owner",
    effort: "small",
  },
  {
    findingId: "F3-price-mismatch",
    title: "JSON-LD offer price (19) contradicts the publisher-confirmed visible price (USD 29)",
    affectedItemIds: [item["03"]],
    ruleIds: ["seo-structured-data", "aio-entity-consistency", "quality-claims"],
    dimensions: ["seo", "aio", "quality"],
    evidenceIds: E("03", "claim-sources", "entity-record", "schema-extraction"),
    classification: "observed",
    severity: "high",
    confidence: "high",
    remediation:
      "Change offers.price in the page's JSON-LD from \"19\" to \"29\" so it matches the publisher-confirmed United States monthly price, and find the source of the 19 value so the two cannot drift again. This is a separate implementation task.",
    verification:
      "Re-extract the JSON-LD from a new capture of the same page and market and compare offers.price and priceCurrency with the visible price and the confirmed policy. Rich-result eligibility is a separate check that was not tested here.",
    ownerRole: "Product marketing / web developer",
    effort: "small",
  },
  {
    findingId: "F4-entitlement-conflict",
    title: "/product and /blog/starter-guide state different Starter storage allowances (1000 vs 1500)",
    affectedItemIds: [item["04"]],
    ruleIds: ["portfolio-contradictions", "aio-entity-consistency"],
    dimensions: ["portfolio", "aio"],
    evidenceIds: E("04", "entity-record", "inventory-map"),
    classification: "observed",
    severity: "medium",
    confidence: "high",
    action: "investigate",
    actionReason:
      "The contradiction is observed, but the authoritative entitlement table is unavailable, so the page that needs correcting cannot be identified yet.",
    remediation:
      "Obtain the authoritative entitlement table for policy version 2026-10-01, then correct whichever page (or both) differs from it so both state the same Starter monthly storage allowance.",
    verification:
      "Compare the allowance sentence on both revised pages with the authoritative entitlement table for the same plan, market, billing period and policy version.",
    ownerRole: "Product owner / content owner",
    effort: "small",
  },
  {
    findingId: "F5-draft-overstates-policy",
    title: "Draft promises free ticket changes to all customers with no notice; the policy does not",
    affectedItemIds: [item["05"]],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: E("05", "claim-sources"),
    classification: "observed",
    severity: "high",
    confidence: "high",
    remediation:
      "Rewrite the draft sentence to carry the policy's three conditions: free changes only for the Thành viên tier, change requests at least 24 hours before departure, and fees for other tiers per the separate fee table. Do not state fee amounts until that table is supplied. Do not publish the current sentence.",
    verification:
      "Compare the revised complete sentence with the supplied current policy clause by clause (eligible tier, 24-hour notice, fees for other tiers) and confirm any fee amount shown matches the fee table once it is supplied.",
    ownerRole: "Content owner / policy owner",
    effort: "small",
  },
];

writeFileSync(out, JSON.stringify(bundle, null, 2) + "\n");
console.log(JSON.stringify({ reviews: bundle.reviews.length, evidence: bundle.evidence.length, findings: bundle.findings.length, now }));
