// Prints a compact view of a run directory. Usage: node inspect.mjs RUN_DIR
import { readFileSync } from "node:fs";
import path from "node:path";

const run = process.argv[2];
const jl = (f) =>
  readFileSync(path.join(run, f), "utf8")
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inv = jl("inventory.jsonl");
for (const i of inv) console.log(JSON.stringify(i));
const ev = jl("evidence.jsonl");
console.log("--- evidence", ev.length);
for (const e of ev)
  console.log(
    e.itemId.slice(0, 8),
    e.evidenceId,
    e.kind,
    e.artifact,
    e.encoding,
    String(e.locator).slice(-30),
  );
console.log(JSON.stringify(ev[0]).slice(0, 1500));
const checks = jl("checks.jsonl");
const m = {};
for (const c of checks) {
  const k = c.itemId.slice(0, 8) + " " + c.status;
  m[k] = (m[k] || 0) + 1;
}
console.log(m);
console.log(JSON.stringify(checks[0]));
for (const c of checks.filter((c) => c.status !== "unknown"))
  console.log(JSON.stringify(c).slice(0, 500));
console.log(readFileSync(path.join(run, "findings.json"), "utf8").slice(0, 800));
console.log(readFileSync(path.join(run, "run.json"), "utf8").slice(0, 1800));
