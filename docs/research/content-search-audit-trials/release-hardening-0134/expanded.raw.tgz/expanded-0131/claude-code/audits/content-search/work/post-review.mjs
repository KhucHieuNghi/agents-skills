// Summarises a reviewed run and writes study-source report options.
// Usage: node post-review.mjs RUN_DIR STUDY_FILE OPTIONS_OUT.json
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [run, studyFile, out] = process.argv.slice(2);
const jl = (f) =>
  readFileSync(path.join(run, f), "utf8")
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inv = jl("inventory.jsonl");
const checks = jl("checks.jsonl");
const name = (id) => {
  const i = inv.find((x) => x.itemId === id);
  return i.path ? path.basename(i.path) : i.uri;
};
const tally = {};
for (const c of checks) tally[c.status] = (tally[c.status] || 0) + 1;
console.log("checks", checks.length, tally);
for (const i of inv) {
  const mine = checks.filter((c) => c.itemId === i.itemId);
  const t = {};
  for (const c of mine) t[c.status] = (t[c.status] || 0) + 1;
  console.log(name(i.itemId), i.itemId.slice(0, 8), i.state, JSON.stringify(t));
  for (const c of mine.filter((c) => c.status !== "unknown"))
    console.log("   ", c.ruleId, c.status);
}
const findings = JSON.parse(readFileSync(path.join(run, "findings.json"), "utf8"));
console.log("findings", (findings.findings ?? findings).length);

const sourceText = readFileSync(studyFile, "utf8");
const lines = sourceText.split(/\r?\n/);
const options = {
  studySources: [
    {
      sourceId: "dossier-08-study-aggregate",
      kind: "historical-study",
      locator: "targets/08-study.md",
      sourceText,
      sourceHash: createHash("sha256").update(sourceText).digest("hex"),
      synthetic: true,
      scope:
        "Synthetic English API panel; 100 responses; collection 2024-02-01 through 2024-02-14; publication 2026-11-01; engine, model, prompts and brand are not supplied",
      limitations: [
        "Synthetic fixture aggregate; not live performance and not a current rate",
        "Aggregate only: no response-level records, prompts, cohort definition or study document are supplied",
        "API panel result; no inference to consumer interfaces, other languages or later periods",
      ],
      passages: [4, 5].map((n) => ({
        startLine: n,
        endLine: n,
        quote: lines[n - 1],
      })),
    },
  ],
};
writeFileSync(out, JSON.stringify(options, null, 2) + "\n");
