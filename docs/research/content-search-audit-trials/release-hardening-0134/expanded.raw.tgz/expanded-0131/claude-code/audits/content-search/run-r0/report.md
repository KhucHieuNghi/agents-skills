# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-18T04:01:07\.907Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 5d68730e\-e6fd\-486e\-bcc8\-a0cead91ba3f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |
| fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| bb14a9308b46abf050f3b7df42a790cd220dcb80484063762e3a37c092d4da73 | 50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3 | local\-file | 2026\-11\-18T04:01:07\.880Z | 0 full elapsed days | [evidence/50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3\.txt](evidence/50f54266688d6f4cbbf2e3fbf48dda3ce78b61aad6286ecb62a73cc8d5387da3.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f1b3373cec9ccb17ebe5f58bf7bb0bd0bf1ddb1cf13895e09a9e8bd2d1790357 | 696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c | local\-file | 2026\-11\-18T04:01:07\.882Z | 0 full elapsed days | [evidence/696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c\.txt](evidence/696071b91970e59bb70c44e9b61bfc5970f36a74580f8bd0892985debe2d189c.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 97717d7d78536fc566405936448404074b4453e3496ced0988304e2d0483700f | 76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6 | local\-file | 2026\-11\-18T04:01:07\.882Z | 0 full elapsed days | [evidence/76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6\.txt](evidence/76385f44f308e53d568243a8ef9ac4ade4645681f1d451ff104b8b4ea6f0e4c6.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1994afd3f62c84b0da3e94f50025e292fa1edb7c712d75a54bc95ad7d0180863 | c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18 | local\-file | 2026\-11\-18T04:01:07\.883Z | 0 full elapsed days | [evidence/c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18\.txt](evidence/c0bb5f58f6d49baa90dc1ad674700e6abb4823667be5f7a49326098266186f18.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e0bb9c5a1424b10acb9b3e00c353b8f3ab3286557d4cbbe97e8f3ab31c30174a | c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c | local\-file | 2026\-11\-18T04:01:07\.884Z | 0 full elapsed days | [evidence/c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c\.txt](evidence/c4128dcf0783abaf5c81b4996ed93a6fdc75a74a721c4bba9d0197ee22cf785c.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 694904aa0eecbd34f0d77adde5a5b0b4a7f4fbbe4b809d215403ca62103d070f | c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9 | local\-file | 2026\-11\-18T04:01:07\.884Z | 0 full elapsed days | [evidence/c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9\.txt](evidence/c9e1115879ee971dfb9078f1286f06bfde373a11f681751f64bf73b963dd60a9.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1c13a5f990cfae0a6b0723260cee9ea9168830558f4b8a80a06a3d83654f8c8a | ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45 | local\-file | 2026\-11\-18T04:01:07\.885Z | 0 full elapsed days | [evidence/ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45\.txt](evidence/ddf206c8634968c145f7864cab3fc63b950d902106d1c3260b995f8b7e93ac45.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e28204873c57a3ac0a97ef87ae575a732b48bd44dd6dc2e5b9c7ba3d3f82fd2c | e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51 | local\-file | 2026\-11\-18T04:01:07\.886Z | 0 full elapsed days | [evidence/e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51\.txt](evidence/e27fd5c0bb8fc13f3cd6be1ced4d92e7a1cd648502e88f3a0f99cfee0389ac51.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6df0c0bac1d77006409a5e5b1cdfe0c9c599788ad95851f31cb6c20768d7979e | e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d | local\-file | 2026\-11\-18T04:01:07\.886Z | 0 full elapsed days | [evidence/e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d\.txt](evidence/e979bd5ff45ccb3b0f9589652fc3224a8ba0ba4948ec68733480d7ada322550d.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7d286eb403d72b854ba52ff53e07ef651426019585c3327f474799451526dace | fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4 | local\-file | 2026\-11\-18T04:01:07\.887Z | 0 full elapsed days | [evidence/fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4\.txt](evidence/fb16958d9e1d58d97e10a78291669aec543b682bed012a912e6d6a6a725b7ee4.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
