# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-18T04:00:59\.457Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run bc346f4e\-a5b5\-4123\-84c7\-4d1b79270d0f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |
| efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 5cddccc0c634507cab344e43aa838d8d9bfdd73c47335d8039496be772fb4ea7 | 0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1 | local\-file | 2026\-11\-18T04:00:59\.425Z | 0 full elapsed days | [evidence/0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1\.txt](evidence/0186ce574eb1e397dc62021ca56bfcdbc163e1b3d231e89fca3ffff2bc8038d1.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d2ef90a43e63114d524480e5023348e8a1e9ed04c7c1fc3d34ca857404edf736 | 1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf | local\-file | 2026\-11\-18T04:00:59\.427Z | 0 full elapsed days | [evidence/1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf\.txt](evidence/1bb6cf19370966128795410d3fd75e123ea6381b178ba6fce1c2a6fbe9d753bf.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ea4b14bb8a96bfa5a1b27d09968bdceaf24e03e56c246c2500f286f202c361e9 | 3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747 | local\-file | 2026\-11\-18T04:00:59\.428Z | 0 full elapsed days | [evidence/3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747\.txt](evidence/3d0d0ddbcd9f148b43ac9ddba304a841bf8ee4d2303ccfde40cc91d5999b3747.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 19cefb6b3480ad91bc111f9dd3c708d7851bf9b967bc6d9b0b7859526920916f | 721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4 | local\-file | 2026\-11\-18T04:00:59\.429Z | 0 full elapsed days | [evidence/721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4\.txt](evidence/721ab81878ee0b78bb63393893e1277b104c1d0580fe933153c2f65878d5fea4.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ef442bf38b3817e852b38a8f8643431a912cd03e32e22f4e16e11923490e6d8f | 91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7 | local\-file | 2026\-11\-18T04:00:59\.430Z | 0 full elapsed days | [evidence/91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7\.txt](evidence/91bf5a71c26c51c8122ff501e395a49c0725bafb322d93fd770ccd42c4cc23a7.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 46d69b7fba716bd98916ddc2ca5a7b2c4ba89c3e52896ca6e2065cf6ec07fa38 | b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12 | local\-file | 2026\-11\-18T04:00:59\.431Z | 0 full elapsed days | [evidence/b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12\.txt](evidence/b2c2831af07530524288295fcdd79aaa2927a087ceb219e5ee7a7ccbe1c11e12.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5dabaf97122773e33d868e13bcb888014194c90adce7889e83eaa8fdf9c09a88 | b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb | local\-file | 2026\-11\-18T04:00:59\.432Z | 0 full elapsed days | [evidence/b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb\.txt](evidence/b3dff45049e919a2ac09cbb16f05fe55d942540fa82a3501f0d5503fd7cf2dbb.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2a84281181c9b8d8762b99673c063193342744518cb13d4ee271515c1f6a6ae9 | b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd | local\-file | 2026\-11\-18T04:00:59\.432Z | 0 full elapsed days | [evidence/b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd\.txt](evidence/b96714799185ba640d6ae045fcab7d959032e30c7511a9d3a0fa985a5c2ba8dd.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b004a4da4b9cc0770ec507c91c3780dd28ed7ee8559b3146856348d8a99f08a8 | e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6 | local\-file | 2026\-11\-18T04:00:59\.433Z | 0 full elapsed days | [evidence/e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6\.txt](evidence/e9485e8dc77d2123c86a78ce6908dce4d4c4b8d47aaa29f8aeaa99e70827bed6.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cee994d229a862c276d85c00dae24270f704333a51948c1cc18e252e04ec5e60 | efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808 | local\-file | 2026\-11\-18T04:00:59\.434Z | 0 full elapsed days | [evidence/efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808\.txt](evidence/efb103a0d44dbbff379cb4e956e22c46f462586ff77a997c50e5a6b006db9808.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
