import json, hashlib
from pathlib import Path
from datetime import datetime, timezone
a=Path("audit-artifacts")
def dump(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
sn={Path(e["locator"]).name[:2]:e for e in map(json.loads,(a/"start/evidence.jsonl").read_text().splitlines()) if e["kind"]=="content"}
now=datetime.now(timezone.utc).isoformat()
bundle=dict(artifacts={},evidence=[],reviews=[],findings=[])
def attach(n,kind,start,end,value=None):
    s=sn[n]; name=Path(s["locator"]).name
    excerpt="\n".join(s["value"].splitlines()[start-1:end])
    locator=f"{name}:{start}"+(f"-{end}" if end!=start else "")
    body=excerpt if value is None else value if isinstance(value,str) else json.dumps(value)
    id=f"d{n}-{kind}"; artifact=f"evidence/{id}.txt"
    bundle["artifacts"][artifact]=body
    bundle["evidence"].append(dict(s,evidenceId=id,kind=kind,encoding="json" if isinstance(value,dict) else "utf8",artifact=artifact,value=excerpt if value is None else value,snapshotHash=sha(body),byteLength=len(body.encode()),collectedAt=now,locator=locator,sourceEvidenceIds=[s["evidenceId"]],limitations=["Derived from the supplied synthetic dossier only. No new capture or independent verification."]))
    return id
def review(n,rule,status,reason,*ids):
    s=sn[n]; evidence=[s["evidenceId"],*ids]
    bundle["reviews"].append(dict(itemId=s["itemId"],ruleId=rule,status=status,reason=reason,evidenceIds=evidence,reviewer="Offline dossier reviewer",reviewedAt=now))
    return evidence
def finding(n,title,reason,checks,action,verification,owner,severity="high",effort="small"):
    ids=[]; rules=[]; dimensions=[]
    for rule,*support in checks:
        ids+=review(n,rule,"fail",reason,*support); rules.append(rule); dimensions.append(rule.split("-")[0])
    bundle["findings"].append(dict(findingId="F"+n,title=title,affectedItemIds=[sn[n]["itemId"]],ruleIds=rules,dimensions=list(dict.fromkeys(dimensions)),evidenceIds=list(dict.fromkeys(ids)),severity=severity,confidence="high",classification="observed",action="update",actionReason=reason,remediation=action,verification=verification,ownerRole=owner,effort=effort))
for n,s in sorted(sn.items()):
    attach(n,"extracted-text",1,len(s["value"].splitlines()),s["value"])
http=attach("01","http-response",4,6,dict(status=200,header="X-Robots-Tag: noindex"))
intent=attach("01","publisher-intent",3,3)
finding("01","Product indexing directive conflicts with intent","The supplied response header declares noindex for the product intended to be eligible for Google indexing.",[("seo-index-controls",http,intent)],"Remove the unintended noindex header from the intended public product response.","Compare a new owner-supplied response with indexing intent and separately review any supplied index observation.","Web platform owner")
attach("02","http-response",4,6,dict(redirects=[dict(status=301,source="/old",target="/new"),dict(status=301,source="/new",target="/old")]))
finding("02","Redirect loop defeats the preferred destination","The captured redirects return from /new to /old, conflicting with the intended and historically listed preferred /new destination.",[("seo-canonical",attach("02","canonical-targets",3,7))],"Make /new directly accessible and point /old to /new once.","Check both starts in a new supplied redirect trace and verify the final successful response, then reconcile current canonical and sitemap signals.","Web platform owner")
claim=attach("03","claim-sources",3,4)
finding("03","Offer markup understates the US monthly price","The only supplied Offer says USD 19 while the owner-confirmed visible US monthly price is USD 29 before taxes.",[("seo-structured-data",attach("03","schema-extraction",7,18)),("aio-entity-consistency",attach("03","entity-record",3,18))],"Generate the matching Offer price from the same approved pricing source as the visible copy.","Compare the revised complete JSON-LD and visible copy for the same plan, currency and market.","Commerce and markup owner")
review("03","quality-claims","pass","The visible price and scope match the supplied authoritative price policy. The separate markup mismatch is recorded under structured data.",claim)
entity=attach("04","entity-record",3,6); inventory=attach("04","inventory-map",3,6)
finding("04","Current Starter pages conflict on storage entitlement","Two current pages for the same plan, market, billing period and policy version claim different storage entitlements.",[("portfolio-contradictions",entity,inventory),("aio-entity-consistency",entity)],"Obtain the authoritative entitlement table, then align both pages with the approved amount for this policy version.","Compare both revised pages with the approved row and confirm qualifiers match.","Starter product and content owners")
policy=attach("05","claim-sources",5,5)
finding("05","Bản nháp ghi sai điều kiện miễn phí đổi vé","The draft overstates customer eligibility and removes the approved 24-hour notice requirement.",[("quality-claims",policy),("aeo-answer-evidence",policy)],"Sửa bản nháp để nêu rõ chỉ hạng Thành viên được miễn phí, yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ và các hạng khác áp dụng bảng phí riêng.","Đối chiếu từng điều kiện với chính sách và chỉ xác nhận mức phí cụ thể khi có bảng phí.","Ticket policy and content owners")
s=sn["06"]
review("06","seo-rendering","unknown","The raw export contains an empty mount node and a script reference. No script bytes or rendered DOM were supplied.")
g=attach("07","claim-sources",5,5); audience=attach("07","audience-context",3,5)
review("07","quality-claims","pass","The complete available Vietnamese procedure and its stated limitations match the supplied product procedure.",g)
review("07","quality-task-fit","pass","Vietnamese customers can follow the stated export sequence, find out how to retrieve attachments separately and see that turnaround is unspecified.",audience)
review("07","aio-retrievable-facts","pass","The actions, attachment exception and processing commitment are explicit in the available Vietnamese document.",audience)
review("07","seo-locales","unknown","The publisher confirms no English alternate exists or is intended. Deployed metadata and any actual declarations remain unavailable.",attach("07","locale-map",3,5))
h=attach("08","claim-sources",3,5)
for rule in ("quality-claims","quality-freshness","aeo-answer-evidence"):
    review("08",rule,"pass","The historical panel window, population, aggregate and explicit limit match the source. The publication month matches the editorial as-of date.",h)
j=attach("10","claim-sources",3,3)
review("10","quality-claims","pass","The complete supplied user-visible product claim matches the policy. The hidden instruction is a separate integrity observation outside this claims check.",j)
dump(a/"review.json",bundle)
s=sn["08"]["value"]
dump(a/"study-options.json",dict(studySources=[dict(sourceId="H",kind="historical-study",locator="targets/08-study.md",sourceText=s,sourceHash=sha(s),synthetic=True,scope="100 synthetic English API responses collected 2024-02-01 through 2024-02-14. Study published 2026-11-01. API/model details beyond those supplied are unknown.",limitations=["Historical aggregate only. No response-level artifacts or later measurement.","The aggregate concerns video-source citations, and cannot estimate current visibility or causal effects."],passages=[dict(startLine=i,endLine=i,quote=s.splitlines()[i-1]) for i in (4,5)])]))
