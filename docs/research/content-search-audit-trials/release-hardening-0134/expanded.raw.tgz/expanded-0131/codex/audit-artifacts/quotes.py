import hashlib,json,re
from pathlib import Path
root=Path.cwd()
a=root/"audit-artifacts"
out=[]; ledger=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for line in (a/"report.in").read_text().splitlines():
    if not line.startswith("@@"):
        out.append(line)
        continue
    n, span=line[2:].split(":")
    source,= (root/"targets").glob(n+"-*.md")
    i,j=map(int,(span+"-"+span if "-" not in span else span).split("-"))
    quote=" ".join(source.read_text().splitlines()[i-1:j])
    out.append(f"    {source.name}:{span} — {quote}")
    ledger.append(dict(quoteId=f"{n}-{span}",source=str(source.relative_to(root)),sourceLabel=source.name,sourceHash=sha(source),startLine=i,endLine=j,reportStartLine=len(out),reportEndLine=len(out),normalization="whitespace",quote=quote))
    out.append("")
report=root/"report.md"
report.write_text("\n".join(out)+"\n")
(a/"quotes.json").write_text(json.dumps(dict(root=str(root),report="report.md",reportHash=sha(report),quotes=ledger),ensure_ascii=False,indent=2))
