# NKSkills public pilot

The campaign collected and reviewed all 12 allowed URLs. The root returned a 308 to the English home, giving 10 distinct HTML destinations and one plain-text font attribution notice. The original run exited normally at its one-page budget. The validated recovery reused the root capture and made 10 new page captures. The original six unvisited targets remain visible in the original receipt. The continued frontier is empty at maxPages 30 and maxDepth 5. Zero count or depth continuations are needed.

**Coverage is partial.** 12 declared, 12 collected, 0 fully audited, 12 pending, 0 failed collection, 0 blocked, 0 unsupported collection and 0 excluded campaign items. Of 312 item checks, 99 resolved as pass or fail, 4 were inapplicable and 209 remain unknown. Zero planned checks are missing. One of four global portfolio checks resolved.

The discovery source retains 10 rendering gaps and one unsupported discovery extraction for the plain-text notice, which the campaign successfully captured and inspected. The union also records three missing sources (CMS, orphan inventory and rendered navigation), unconfirmed scope and an incomplete-source marker. Its 98 excluded external link occurrences represent 25 unique destination URLs. The pilot did not collect them. The sitemap URL appeared in captured robots text and remained outside the declared static navigation traversal.

## Documentation finding

Four guide snapshots repeat the same version reproducibility issue. The build blocks clone the default branch, enter the repository, install dependencies and build without a revision checkout. Each then uses a directory name labeled with 1.1.0. The printed digest checks the bundle built from that checkout. Add the owner-approved tag or full commit and an explicit checkout to all four guides, and keep the digest check. Verify the revised source blocks against the release record and verify version and digest in a separately authorized disposable build.

- https://nkskills.getgroove.me/en/guides/claude-code/ · [7a055351d3845e3626596c377823837f4be91ff77a3c809565b9db3dd50ba40d.txt:2-4](reviewed/parts/000001/evidence/7a055351d3845e3626596c377823837f4be91ff77a3c809565b9db3dd50ba40d.txt)

  ```sh
cd agents-skills
npm ci
npm run build
  ```

- https://nkskills.getgroove.me/en/guides/codex/ · [dc4b66450c7333e076aba848617e4a08a8bb33531bd4b51f5fbd987362212aa4.txt:2-4](reviewed/parts/000001/evidence/dc4b66450c7333e076aba848617e4a08a8bb33531bd4b51f5fbd987362212aa4.txt)

  ```sh
cd agents-skills
npm ci
npm run build
  ```

- https://nkskills.getgroove.me/vi/guides/claude-code/ · [a81e5fb299c6e423c597ae76d2ec13b19b831ef1cbacbe74aed83538ecd86908.txt:2-4](reviewed/parts/000001/evidence/a81e5fb299c6e423c597ae76d2ec13b19b831ef1cbacbe74aed83538ecd86908.txt)

  ```sh
cd agents-skills
npm ci
npm run build
  ```

- https://nkskills.getgroove.me/vi/guides/codex/ · [fa8e54c8ac86f8bdf64aed60c66822daa55a07c59a060bbca365cc89a91b0c8c.txt:2-4](reviewed/parts/000001/evidence/fa8e54c8ac86f8bdf64aed60c66822daa55a07c59a060bbca365cc89a91b0c8c.txt)

  ```sh
cd agents-skills
npm ci
npm run build
  ```

## Source observations

The five EN/VI pairs have matching language declarations, self-canonicals and reciprocal alternatives in source. Their English x-defaults point to the corresponding English destinations. The packages, prerequisites and release caveats agree on the reviewed EN/VI pairs. The home and catalog pages in both languages use AIO without spelling it out. Expanding it on first use would clarify the audit offer. The captured guide variants use the relevant host targets and invocation syntax. The observed HTML links and fragment identifiers connect the primary onboarding journey. The live prompt picker and copy behavior remain unmeasured.

## Evidence needed

- Supply a publisher inventory including CMS and known orphan URLs, plus authorized rendered snapshots or a navigation export to resolve the discovery gaps. Supply the referenced font notices or a publisher map if plain-text references need coverage.
- Supply versioned manifests, release verification records, publisher crawler/indexing intent and real English/Vietnamese customer questions to resolve factual and answer-quality checks.
- For visibility measurement, use dated Search Console/Bing exports and normalized crawler logs if available. Build a versioned EN/VI prompt cohort around customer questions on onboarding, install prerequisites and release status. Capture search-enabled surfaces independently by product, locale and date, with exact prompts, responses, cited URLs and capture failures. Keep Google AI Overviews separate. Evaluate mentions, citations and factual accuracy against approved release evidence. Use attributed analytics exports to evaluate conversions.
- Rankings, actual indexing, crawler activity, AI citations, Google AI Overviews and conversions remain unknown. This pilot collected public HTTP, robots and inert source evidence.

See the [customer report](customer-report/report.html), [validated coverage](customer-report/coverage.json), [global receipt](global-receipt/review-result.json) and [continued source](continued/source.json).
