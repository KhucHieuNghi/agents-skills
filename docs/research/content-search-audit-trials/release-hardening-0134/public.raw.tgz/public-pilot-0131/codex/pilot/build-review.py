from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from urllib.parse import urlsplit, urljoin, unquote
import json
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    from snapshot_view import View

root=Path('pilot')
part='parts/000001'
source=root/'collected'/part
def read(p): return json.loads(p.read_text())
def rows(p): return [json.loads(x) for x in p.read_text().splitlines()]
def save(p,value): p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def digest(s): return sha256(s.encode()).hexdigest()
now=datetime.now(timezone.utc).isoformat(timespec='milliseconds')
reviewer='Codex | NKSkills public pilot'
index=read(root/'collection-index/index.json')
items=rows(source/'inventory.jsonl')
ev=rows(source/'evidence.jsonl')
origin='https://nkskills.getgroove.me'
owner='Pilot brief supplied by the user. NKSkills composes versioned skill workflows for Codex and Claude Code for English and Vietnamese audiences. AIO means AI search optimization. No provider, analytics or AI response evidence supplied.'
bundle={'reviews':[],'evidence':[],'artifacts':{},'findings':read(source/'findings.json')}
role_notes={
'home':'Introduce versioned workflows and route readers to the catalog, solution and host guides. Static content distinguishes technical release from evaluation candidates, shows the handoff and explains prerequisites. Prompt picker interaction is unobserved.',
'catalog':'Compare packaged releases, evaluation candidates and pinned upstream entries. The catalog gives versions, short revisions, license labels and source links. Upstream source claims were not independently checked.',
'solution':'Decide whether to run codebase onboarding. The page identifies the three components, the valid repository index requirement and the human-review limit for 1.1.0.',
'codex':'Build and install an appropriate package for Codex. The guide gives host-specific targets, separate candidate digests and invocation tokens, with CodeGraph requirements scoped to onboarding.',
'claude-code':'Build and install an appropriate package for Claude Code. The guide gives host-specific targets, separate candidate digests and invocation tokens, with CodeGraph requirements scoped to onboarding.',
'license':'Look up font attribution. The plain-text notice names three fonts, their licensors and full-notice filenames. Those separately named files were outside static hyperlink traversal.'
}
class Page(View):
    def __init__(self):
        super().__init__()
        self.ids=set()
        self.links=[]
        self.h1=[]
        self.in_h1=False
    def handle_starttag(self,t,a):
        super().handle_starttag(t,a)
        d=dict(a)
        if 'id' in d: self.ids.add(d['id'])
        if t in ('a','area') and 'href' in d: self.links.append(d['href'])
        if t=='h1': self.in_h1=True
    def handle_endtag(self,t):
        super().handle_endtag(t)
        if t=='h1': self.in_h1=False
    def handle_data(self,d):
        super().handle_data(d)
        if self.in_h1 and d.strip(): self.h1.append(d.strip())
pages={}
for item in items:
    iid=item['itemId']
    c=next(e for e in ev if e['itemId']==iid and e['kind']=='content')
    http=next(e for e in ev if e['itemId']==iid and e['kind']=='http-response')
    raw=(source/c['artifact']).read_text()
    path=urlsplit(item['uri']).path
    role='license' if path.endswith('.txt') else 'catalog' if '/catalog/' in path else 'solution' if '/solutions/' in path else path.strip('/').split('/')[-1] if '/guides/' in path else 'home'
    page=Page()
    html=role!='license'
    if html: page.feed(raw)
    pages[item['uri']]=(c,http,raw,role,page,html)
for uri,(c,http,raw,role,page,html) in pages.items():
    iid=c['itemId']
    def add(kind,value,locator='Captured source inspection',deps=None):
        if not isinstance(value,str): value=json.dumps(value,ensure_ascii=False,indent=2)
        eid=kind+'-'+iid
        artifact=f'evidence/{eid}.txt'
        bundle['artifacts'][artifact]=value
        bundle['evidence'].append(dict(evidenceId=eid,itemId=iid,kind=kind,value=value,method='attributed static source review',locator=locator,collectedAt=now,snapshotHash=digest(value),artifact=artifact,encoding='utf8',sourceEvidenceIds=deps or [c['evidenceId']],redaction='None',limitations=['Owner context is attributed. Source inspection does not establish rendered behavior, independent factual verification or search performance.']))
        return eid
    def review(rule,status,reason,*ids):
        bundle['reviews'].append(dict(itemId=iid,ruleId=rule,status=status,reason=reason,evidenceIds=list(dict.fromkeys([c['evidenceId'],*ids])),reviewer=reviewer,reviewedAt=now))
    audience=add('audience-context',owner+'\nInferred page task from captured source: '+role_notes[role],'User task statement and captured page')
    extracted='\n'.join(s for _,s in page.text) if html else raw
    add('extracted-text',extracted,c['artifact']+' (inert source text, including title and navigation)')
    media=[(n,t,d) for n,t,d in page.meta if t in ('img','iframe','video','audio')]
    mid=add('media-inventory',{'surface':'raw HTML' if html else 'text/plain','media':media,'scope':'Static source. Home workflow figures include a textual four-step equivalent.'})
    review('quality-accessible-media','pass' if html else 'not-applicable','The source logo is redundant with adjacent NKSkills text. '+('The workflow diagram also has a four-step textual equivalent. ' if role=='home' else '')+'Rendered media remain outside this assessment.' if html else 'The captured license notice is a plain-text document with no embedded media.',mid)
    guide=role in ('codex','claude-code')
    clone_line=next((i for i,s in enumerate(raw.splitlines(),1) if 'git clone' in s),None)
    task_reason=role_notes[role]
    if guide:
        task_reason += f' The build block beginning at source line {clone_line} clones the moving default branch and gives a version-labeled output path. It omits any checkout of a release tag or commit before the build, leaving the stated 1.1.0 workflow unreproducible from these instructions alone as the branch moves. The printed digest checks the built artifact at install time.'
        bundle['findings'].append(dict(findingId='pin-build-source-'+iid[:12],title='Version-labeled onboarding build lacks a source revision pin',affectedItemIds=[iid],ruleIds=['quality-task-fit'],dimensions=['quality'],evidenceIds=[c['evidenceId'],audience],severity='medium',confidence='high',classification='observed',action='update',actionReason='A reader repeating the documented workflow needs a stable input revision.',remediation='Add the owner-verified release tag or full commit and explicit checkout step before building codebase onboarding. Keep the existing digest verification.',verification='Compare all four source build blocks with the approved release revision. In a separately authorized disposable build, verify the resulting manifest version and printed digest before installation.',ownerRole='Documentation maintainer',effort='small'))
    review('quality-task-fit','fail' if guide else 'pass',task_reason,audience)
    review('aio-retrievable-facts','unknown' if guide else 'pass',role_notes[role]+(' A branch pin for the version-specific setup is missing. Validate the documented build path and digest with release evidence.' if guide else ' These facts are present as readable source text. Retrieval by any named engine was unmeasured.'),audience)
    if html:
        metadata=[(n,t,d) for n,t,d in page.meta if t in ('title','meta','html','link') and ('property' not in d or d['property']=='og:title')]
        canonical=next(d['href'] for _,t,d in metadata if t=='link' and d.get('rel')=='canonical')
        alts={d['hreflang']:d['href'] for _,t,d in metadata if t=='link' and 'hreflang' in d}
        deps=list(dict.fromkeys(pages[u][0]['evidenceId'] for u in alts.values()))
        lid=add('locale-map',{'canonical':canonical,'alternates':alts,'paired':{u:[d for _,t,d in pages[u][4].meta if t=='html' or (t=='link' and d.get('rel') in ('canonical','alternate'))] for u in alts.values()}},deps=[c['evidenceId'],*deps] if c['evidenceId'] not in deps else deps)
        cid=add('canonical-targets',{'declared':canonical,'requested':uri,'final':c['locator'],'finalStatus':http['value']['status'],'targetContent':pages[canonical][0]['artifact']},deps=list(dict.fromkeys([c['evidenceId'],http['evidenceId'],pages[canonical][0]['evidenceId']])))
        review('seo-canonical','pass','The source canonical equals the observed final locale URL and the campaign captured its HTTP 200 representation. Engine selection is unknown.',cid)
        review('seo-locales','pass','The captured English and Vietnamese sources have matching language and self-canonical, reciprocal en and vi alternatives and an English x-default. Engine selection is unmeasured.',lid)
        review('seo-metadata','pass','The source title, description and headings align with the localized primary page task. H1: '+ ' '.join(page.h1)+'. Secondary sections are assessed in the content review.',audience)
    else:
        review('seo-metadata','not-applicable','The HTTP content type is text/plain. HTML title, description and heading markup are inapplicable in this representation.',http['evidenceId'])
        review('seo-locales','unknown','No observed HTTP locale alternate. Confirm whether the publisher intends a localized license file.',http['evidenceId'])
        review('seo-canonical','unknown','No canonical HTTP Link header was observed. Preferred variant policy for the license notice was not supplied.',http['evidenceId'])
    graph=[]
    for href in page.links:
        dest=urljoin(c['locator'],href)
        target,_,frag=dest.partition('#')
        if urlsplit(target).netloc==urlsplit(origin).netloc:
            graph.append({'sourceHref':href,'target':target,'status':pages[target][1]['value']['status'] if target in pages else None,'fragmentInSource':unquote(frag) in pages[target][4].ids if frag and target in pages else None})
    graphid=add('link-graph',graph, deps=list(dict.fromkeys([c['evidenceId'],*[pages[g['target']][1]['evidenceId'] for g in graph if g['target'] in pages]])))
    if html:
        bounded=all(g['status']==200 and g['fragmentInSource'] is not False for g in graph)
        review('seo-internal-links','pass' if bounded else 'unknown','Source anchors evaluated against the collected internal targets and static IDs. Rendered navigation and site-wide orphan discovery remain open.',graphid)
    else:
        review('seo-internal-links','unknown','The static HTML link extractor does not cover the plain-text filenames. The notice itself was captured and read.',graphid)
    for rule,why in {
        'quality-claims':'Material claims and cited sources were identified. External manifests, license texts, build records and independent corroboration were not supplied or followed.',
        'quality-freshness':'Version labels and release caveats were compared across locales. Current release truth and change dates need owner-approved release records.',
        'seo-index-controls':'No observed X-Robots-Tag or HTML robots meta in this snapshot. Publisher indexing and snippet intent and engine status are unknown.',
        'seo-structured-data':'No JSON-LD was observed in the captured HTML. Feature applicability and rendered structured data were not established.' if html else 'The plain-text file has no HTML structured data surface.',
        'seo-rendering':'No browser or script execution was in scope. Source text and navigation remain independently reviewable.',
        'aio-crawler-policy':'Captured robots policy allows the anonymous helper; publisher intent for different AI search, training and user-triggered agents is unknown.',
        'aio-entity-consistency':'Observed cross-page version and release wording was compared. No authoritative entity record was supplied to adjudicate all product and license claims.',
        'aeo-question-coverage':'Page-native tasks and FAQs were inspected. No genuine customer question set was supplied.',
        'aeo-answer-context':role_notes[role]+' Real question coverage and complete answer applicability remain unknown without a supplied question set.',
        'aeo-answer-evidence':'The captured pages provide source references and caveats. Independent claim records remain unavailable within this origin-only scope.',
        'geo-observed-presence':'No actual response-level mentions or citations supplied.',
        'geo-answer-accuracy':'No AI responses or corresponding approved claim evidence supplied.',
        'geo-cohort-validity':'No dated response observations or versioned prompt cohort supplied.',
        'portfolio-task-gaps':'Mapped purpose: '+role_notes[role]+' Customer demand and full-site task coverage remain unknown.',
        'portfolio-duplication':'English/Vietnamese counterparts and host-specific tasks were compared in the global review.',
        'portfolio-contradictions':'Observed versions and caveats were compared in the global review. Full authoritative adjudication remains open.',
        'portfolio-journey-links':'Static target checks were recorded. Rendered interactions, external handoff and unprovided navigation remain unresolved.'
    }.items():
        if not html and rule in ('seo-rendering','seo-structured-data'):
            review(rule,'not-applicable',why if rule!='seo-rendering' else 'The captured resource is text/plain with no document scripts or interactive elements.',http['evidenceId'])
        else:
            review(rule,'unknown',why)
keys={k:index[k] for k in ('schemaVersion','campaignId','sourceManifestHash')}
save(root/'part-review.json',{**keys,'parts':[{'path':part,'sourceSnapshotHash':index['partSnapshotHashes'][part],'bundle':bundle}]})
save(root/'page-map.json',[{'uri':uri,'final':c['locator'],'itemId':c['itemId'],'contentEvidenceId':c['evidenceId'],'role':role,'note':role_notes[role]} for uri,(c,http,raw,role,page,html) in pages.items()])
