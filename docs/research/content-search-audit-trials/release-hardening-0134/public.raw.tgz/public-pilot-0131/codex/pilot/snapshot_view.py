from html.parser import HTMLParser
from pathlib import Path
import json,sys
class View(HTMLParser):
 def __init__(self):
  super().__init__()
  self.skip=None
  self.text=[]
  self.meta=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t in ('html','title','meta','link','img','video','audio','iframe','script','template','noscript'):
   if t!='link' or d.get('rel') in ('canonical','alternate'):
    self.meta.append((self.getpos()[0],t,d))
  if t in ('script','style','template'): self.skip=t
 def handle_endtag(self,t):
  if self.skip==t:self.skip=None
 def handle_data(self,d):
  if not self.skip and d.strip():self.text.append((self.getpos()[0],d.strip()))
root=Path('pilot/collected/parts/000001')
for line in (root/'evidence.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e['kind']!='content': continue
 print('\n',e['locator'],e['artifact'])
 raw=(root/e['artifact']).read_text()
 v=View()
 if '<html' in raw.lower():
  v.feed(raw)
  for x in v.meta: print(x)
  for n,s in v.text: print(n,s)
 else: print(raw)
