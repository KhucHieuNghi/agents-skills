// Inert text inspection of collected content snapshots. Nothing from the target is executed.
// usage: inspect.mjs PART_DIR MODE [uriSubstring]   MODE: head | text | links | robots
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
const [part, mode, filter] = process.argv.slice(2);
const jl = (f) => readFileSync(join(part, f), 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const inv = jl('inventory.jsonl').sort((a, b) => a.uri.localeCompare(b.uri));
const ev = jl('evidence.jsonl');
const decode = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#x27;/g, "'");
for (const item of inv) {
  if (filter && !item.uri.endsWith(filter)) continue;
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === 'content');
  const html = content.value;
  console.log(`\n===== ${item.uri}  item=${item.itemId.slice(0, 8)} content=${content.evidenceId.slice(0, 8)} bytes=${Buffer.byteLength(html)} lines=${html.split('\n').length}`);
  if (mode === 'robots') {
    for (const e of mine.filter((x) => x.kind === 'crawler-policy')) console.log(JSON.stringify(e.value, null, 1).slice(0, 2500), '\nLIMITS', e.limitations);
    const h = mine.find((x) => x.kind === 'http-response');
    console.log('HTTP', JSON.stringify(h.value, null, 1).slice(0, 1500));
    continue;
  }
  if (mode === 'head') {
    console.log('HTML tag:', (html.match(/<html[^>]*>/i) || [''])[0]);
    const head = (html.match(/<head[\s\S]*?<\/head>/i) || [''])[0];
    for (const m of head.matchAll(/<(title)[^>]*>[\s\S]*?<\/title>|<(meta|link|base)\b[^>]*>/gi)) console.log('  ', m[0].slice(0, 400));
    for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) console.log('  SCRIPT attrs=[' + m[1].trim() + '] inlineBytes=' + m[2].length + (/(ld\+json)/.test(m[1]) ? '\n    ' + m[2].slice(0, 3000) : m[2].length ? '\n    ' + m[2].slice(0, 300).replace(/\s+/g, ' ') : ''));
    for (const m of html.matchAll(/<(iframe|template|noscript|form|img|svg|video|audio|picture|canvas)\b[^>]*>/gi)) console.log('  EL', m[0].slice(0, 250));
    for (const m of html.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)) console.log('  H' + m[1], decode(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()));
    continue;
  }
  if (mode === 'links') {
    const seen = new Map();
    for (const m of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
      const href = (m[1].match(/href="([^"]*)"/i) || [])[1];
      const text = decode(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
      const rest = m[1].replace(/href="[^"]*"/i, '').replace(/class="[^"]*"/i, '').trim();
      const k = href + ' | ' + text.slice(0, 70) + ' | ' + rest;
      seen.set(k, (seen.get(k) || 0) + 1);
    }
    for (const [k, n] of seen) console.log('  ', n, k);
    continue;
  }
  if (mode === 'text') {
    let body = (html.match(/<body[\s\S]*<\/body>/i) || [html])[0];
    body = body.replace(/<script\b[\s\S]*?<\/script>/gi, ' [script] ').replace(/<style\b[\s\S]*?<\/style>/gi, ' ');
    body = body.replace(/<\/(p|div|li|h[1-6]|section|tr|header|footer|nav|article|pre|dd|dt|summary|details|figcaption|td|th)>/gi, '\n').replace(/<br\s*\/?>/gi, '\n');
    body = body.replace(/<a\b[^>]*href="([^"]*)"[^>]*>/gi, ' [a:$1] ').replace(/<[^>]+>/g, ' ');
    console.log(decode(body).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n'));
  }
}
