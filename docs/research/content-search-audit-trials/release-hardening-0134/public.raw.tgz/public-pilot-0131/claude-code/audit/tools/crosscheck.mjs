// Cross-page inert checks over collected snapshots: fragment targets, internal link matrix, locale annotations, robots decisions.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
const [part, ...greps] = process.argv.slice(2);
const jl = (f) => readFileSync(join(part, f), 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const inv = jl('inventory.jsonl').sort((a, b) => a.uri.localeCompare(b.uri));
const ev = jl('evidence.jsonl');
const pages = new Map();
for (const item of inv) {
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const http = mine.find((e) => e.kind === 'http-response').value;
  pages.set(item.uri, { item, html: mine.find((e) => e.kind === 'content').value, http, policies: mine.filter((e) => e.kind === 'crawler-policy') });
}
if (greps.length) {
  for (const [uri, p] of pages) for (const g of greps) {
    let i = -1;
    while ((i = p.html.indexOf(g, i + 1)) !== -1) console.log(uri, '@' + i, JSON.stringify(p.html.slice(Math.max(0, i - 220), i + g.length + 260)));
  }
  process.exit(0);
}
const ids = new Map();
for (const [uri, p] of pages) ids.set(uri, new Set([...p.html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1])));
console.log('--- fragment and internal target checks');
for (const [uri, p] of pages) {
  const base = p.http.finalUrl || uri;
  const out = new Map();
  for (const m of p.html.matchAll(/<a\b[^>]*\shref="([^"]*)"[^>]*>/gi)) {
    let u; try { u = new URL(m[1], base); } catch { console.log('BAD HREF', uri, m[1]); continue; }
    if (u.origin !== 'https://nkskills.getgroove.me') continue;
    const target = u.origin + u.pathname;
    const frag = decodeURIComponent(u.hash.slice(1));
    const known = pages.has(target);
    const fragOk = !frag ? '' : known ? (ids.get(target).has(frag) ? 'frag-ok' : 'FRAG-MISSING') : 'frag-unknown';
    out.set(`${target}${u.hash} ${known ? 'in-inventory' : 'NOT-IN-INVENTORY'} ${fragOk}`, 1);
  }
  console.log(uri); for (const k of out.keys()) console.log('    ', k);
}
console.log('--- inbound internal link counts (distinct source pages)');
for (const [target] of pages) {
  const from = [];
  for (const [uri, p] of pages) {
    const base = p.http.finalUrl || uri;
    for (const m of p.html.matchAll(/<a\b[^>]*\shref="([^"]*)"[^>]*>/gi)) { try { const u = new URL(m[1], base); if (u.origin + u.pathname === target && uri !== target) { from.push(uri.replace('https://nkskills.getgroove.me', '')); break; } } catch {} }
  }
  console.log(target, from.length, from.join(' '));
}
console.log('--- locale annotations');
for (const [uri, p] of pages) {
  const lang = (p.html.match(/<html[^>]*\slang="([^"]*)"/i) || [])[1];
  const canon = (p.html.match(/<link rel="canonical" href="([^"]*)"/i) || [])[1];
  const alts = [...p.html.matchAll(/<link rel="alternate" hreflang="([^"]*)" href="([^"]*)"/gi)].map((m) => m[1] + '=' + m[2].replace('https://nkskills.getgroove.me', ''));
  const robotsMeta = [...p.html.matchAll(/<meta[^>]*name="(robots|googlebot)"[^>]*>/gi)].map((m) => m[0]);
  console.log(uri.replace('https://nkskills.getgroove.me', ''), '| lang', lang, '| canonical', canon, '|', alts.join(' '), '| robotsMeta', robotsMeta.length, '| final', p.http.finalUrl, '| headers', JSON.stringify(p.http.headers));
}
console.log('--- robots policy records');
const seen = new Set();
for (const [uri, p] of pages) for (const e of p.policies) {
  const v = e.value; const key = JSON.stringify([v.status, v.policyText ?? v.body ?? v.text]);
  console.log(uri.replace('https://nkskills.getgroove.me', ''), Object.keys(v).join(','), JSON.stringify(v.decision ?? v.selectedDecision ?? null));
  if (!seen.has(key)) { seen.add(key); console.log(JSON.stringify(v, null, 1).slice(0, 3000)); }
}
