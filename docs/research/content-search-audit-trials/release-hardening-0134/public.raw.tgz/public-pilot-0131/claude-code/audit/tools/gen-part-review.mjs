// Generates the campaign-review-parts bundle: derived, attributed evidence plus per-item judgments.
// Snapshots are read as inert text. Nothing from the target is executed and nothing is fetched.
// usage: gen-part-review.mjs CAMPAIGN_DIR INDEX_DIR OUT_BUNDLE.json OUT_FACTS.json
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

const [campaignDir, indexDir, outBundle, outFacts] = process.argv.slice(2);
const sha = (s) => createHash('sha256').update(s).digest('hex');
const ORIGIN = 'https://nkskills.getgroove.me';
const PART = 'parts/000001';
const partDir = join(campaignDir, PART);
const jl = (f) => readFileSync(join(partDir, f), 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const inventory = jl('inventory.jsonl');
const evidence = jl('evidence.jsonl');
const manifestBytes = readFileSync(join(campaignDir, 'campaign.json'));
const manifest = JSON.parse(manifestBytes);
const index = JSON.parse(readFileSync(join(indexDir, 'index.json'), 'utf8'));
const now = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 host agent running the content-search-audit skill (automated reviewer; not a human reviewer and not the site owner)';
const short = (u) => u.replace(ORIGIN, '') || '/';
const decode = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;|&#x27;/g, "'");
const nfc = (s) => s.normalize('NFC');

// ---------- load pages
const pages = new Map();
for (const item of inventory) {
  const mine = evidence.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === 'content');
  const http = mine.find((e) => e.kind === 'http-response');
  const policies = mine.filter((e) => e.kind === 'crawler-policy');
  if (!content || !http || !policies.length) throw new Error('missing base evidence ' + item.uri);
  const html = content.value;
  const isHtml = /text\/html/.test(http.value.headers['content-type'] || '');
  const finalUrl = http.value.redirects?.length ? new URL(((html.match(/<link rel="canonical" href="([^"]*)"/i) || [])[1]) || item.uri).href : item.uri;
  pages.set(item.uri, { item, content, http, policies, html, isHtml, finalUrl });
}
const P = (path) => { const p = pages.get(ORIGIN + path); if (!p) throw new Error('no page ' + path); return p; };
const kindOf = (uri) => {
  const s = short(uri);
  if (s === '/' || s === '/en/' || s === '/vi/') return 'home';
  if (s.endsWith('/catalog/')) return 'catalog';
  if (s.includes('/solutions/')) return 'solution';
  if (s.includes('/guides/')) return 'guide';
  return 'license-text';
};

// ---------- per page derived facts
function extractText(p) {
  if (!p.isHtml) return p.html;
  let body = (p.html.match(/<body[\s\S]*<\/body>/i) || [p.html])[0];
  body = body.replace(/<script\b[\s\S]*?<\/script>/gi, ' ').replace(/<style\b[\s\S]*?<\/style>/gi, ' ');
  body = body.replace(/<\/(p|div|li|h[1-6]|section|tr|header|footer|nav|article|pre|dd|dt|summary|details|figcaption|td|th|template)>/gi, '\n').replace(/<br\s*\/?>/gi, '\n');
  body = body.replace(/<[^>]+>/g, ' ');
  return decode(body).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n') + '\n';
}
for (const p of pages.values()) {
  p.text = extractText(p);
  p.flat = nfc(p.text.replace(/\s+/g, ' '));
  p.kind = kindOf(p.item.uri);
  p.lang = (p.html.match(/<html[^>]*\slang="([^"]*)"/i) || [])[1] || null;
  p.title = decode((p.html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '') || null;
  p.description = decode((p.html.match(/<meta name="description" content="([^"]*)"/i) || [])[1] || '') || null;
  p.h1 = [...p.html.matchAll(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi)].map((m) => decode(m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()));
  p.canonical = (p.html.match(/<link rel="canonical" href="([^"]*)"/i) || [])[1] || null;
  p.ogUrl = (p.html.match(/<meta property="og:url" content="([^"]*)"/i) || [])[1] || null;
  p.alternates = [...p.html.matchAll(/<link rel="alternate" hreflang="([^"]*)" href="([^"]*)"/gi)].map((m) => ({ hreflang: m[1], href: m[2] }));
  p.robotsMeta = [...p.html.matchAll(/<meta[^>]*name="(robots|googlebot)"[^>]*>/gi)].map((m) => m[0]);
  p.ids = new Set([...p.html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
  p.scripts = [...p.html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].map((m) => ({ src: (m[1].match(/src="([^"]*)"/) || [])[1] || null, type: (m[1].match(/type="([^"]*)"/) || [])[1] || null, inlineBytes: m[2].length }));
  p.anchors = [];
  for (const m of p.html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const href = (m[1].match(/\shref="([^"]*)"/i) || [])[1];
    if (href === undefined) continue;
    let u; try { u = new URL(decode(href), p.finalUrl); } catch { p.anchors.push({ href, unresolved: true }); continue; }
    p.anchors.push({ href: decode(href), resolved: u.href, origin: u.origin, target: u.origin + u.pathname, fragment: decodeURIComponent(u.hash.slice(1)), text: decode(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()), ariaLabel: (m[1].match(/aria-label="([^"]*)"/) || [])[1] || null });
  }
}
// "/" is a 308 alias of /en/
const root = P('/'); const en = P('/en/');
if (root.content.snapshotHash !== en.content.snapshotHash) throw new Error('root and /en/ bodies differ; revisit alias judgments');
if (root.http.value.redirects?.[0]?.status !== 308) throw new Error('unexpected root redirect');

// ---------- verified snippets (must occur in the extracted text of the named page)
const need = (p, snippet) => { if (!p.flat.includes(nfc(snippet))) throw new Error(`snippet not found in ${p.item.uri}: ${snippet}`); return snippet; };
const S = {
  enCount: 'Solution Skills 01 technical release 01 evaluation candidate',
  viCount: 'Solution Skills 01 bản kỹ thuật 01 ứng viên đánh giá',
  enCard3: 'EVALUATION CANDIDATE Content search audit',
  viCard3: 'ỨNG VIÊN ĐÁNH GIÁ Content search audit',
  card3Version: 'NK / SOLUTION 003 v0.1.32',
  catCount: '03 Solution Skills',
  catUp: '15 Upstream Skills',
  enCat1: '01 / TECHNICAL RELEASE Codebase onboarding 1.1.0',
  enCat2: '02 / EVALUATION CANDIDATE Problem presentation 0.1.0',
  enCat3: '03 / EVALUATION CANDIDATE Content search audit 0.1.32',
  viCat1: '01 / BẢN PHÁT HÀNH KỸ THUẬT Codebase onboarding 1.1.0',
  viCat2: '02 / ỨNG VIÊN ĐÁNH GIÁ Problem presentation 0.1.0',
  viCat3: '03 / ỨNG VIÊN ĐÁNH GIÁ Content search audit 0.1.32',
  viEyebrow: 'NKSKILLS / DANH MỤ Những skill',
  prereq: 'codegraph, rtk',
  guideAudit: '06 / CONTENT SEARCH AUDIT · 0.1.32',
  enSolPrereq: 'You need the Solution Skill, codegraph, rtk, and a valid CodeGraph index at the repository root.',
  enGuideLinkLabel: 'Read archive and digest verification',
  viGuideLinkLabel: 'Xem quy trình kiểm tra archive và digest',
};
for (const path of ['/', '/en/']) { need(P(path), '02 ' + S.enCount); need(P(path), S.enCard3); need(P(path), S.card3Version); need(P(path), 'TECHNICAL RELEASE Codebase onboarding'); need(P(path), 'EVALUATION CANDIDATE Problem presentation'); }
need(P('/vi/'), '02 ' + S.viCount); need(P('/vi/'), S.viCard3); need(P('/vi/'), S.card3Version); need(P('/vi/'), 'BẢN PHÁT HÀNH KỸ THUẬT Codebase onboarding'); need(P('/vi/'), 'ỨNG VIÊN ĐÁNH GIÁ Problem presentation');
for (const k of ['catCount', 'catUp', 'enCat1', 'enCat2', 'enCat3']) need(P('/en/catalog/'), S[k]);
for (const k of ['catCount', 'catUp', 'viCat1', 'viCat2', 'viCat3', 'viEyebrow']) need(P('/vi/catalog/'), S[k]);
for (const path of ['/en/guides/codex/', '/en/guides/claude-code/']) { need(P(path), S.prereq); need(P(path), S.guideAudit); need(P(path), S.enGuideLinkLabel); }
for (const path of ['/vi/guides/codex/', '/vi/guides/claude-code/']) { need(P(path), S.prereq); need(P(path), S.guideAudit); need(P(path), S.viGuideLinkLabel); }
need(P('/en/solutions/codebase-onboarding/'), S.enSolPrereq);
if (P('/vi/').flat.includes('NKSKILLS / DANH MỤ ') ) throw new Error('unexpected truncated eyebrow on vi home');

// ---------- cross-page computations
const linkGraph = (p) => {
  const internal = new Map(); const external = new Set();
  for (const a of p.anchors) {
    if (a.unresolved) continue;
    if (a.origin !== ORIGIN) { external.add(a.resolved); continue; }
    const t = pages.get(a.target);
    const key = a.target + '#' + a.fragment;
    if (!internal.has(key)) internal.set(key, { target: a.target, fragment: a.fragment || null, inInventory: Boolean(t), capturedStatus: t ? t.http.value.status : null, fragmentResolvedInTargetSnapshot: a.fragment ? (t ? t.ids.has(a.fragment) : null) : null, anchorTexts: [] });
    const row = internal.get(key); const label = a.text || a.ariaLabel || '';
    if (label && !row.anchorTexts.includes(label)) row.anchorTexts.push(label);
  }
  const inbound = [...pages.values()].filter((q) => q !== p && q.anchors.some((a) => a.target === p.item.uri)).map((q) => q.item.uri).sort();
  return { page: p.item.uri, surface: 'raw HTML source anchors (a[href]) only; scripts not executed', internalTargets: [...internal.values()], externalTargets: { count: external.size, note: 'Outside the single allowed origin; not fetched, reachability unverified', urls: [...external].sort() }, inboundFromCollectedPages: inbound };
};
for (const p of pages.values()) p.graph = linkGraph(p);
const brokenInternal = [...pages.values()].flatMap((p) => p.graph.internalTargets.filter((t) => !t.inInventory || t.capturedStatus !== 200 || t.fragmentResolvedInTargetSnapshot === false).map((t) => p.item.uri + ' -> ' + t.target));
if (brokenInternal.length) throw new Error('unexpected unresolved internal targets: ' + brokenInternal.join(', '));

const localeMap = (p) => {
  if (!p.isHtml) return { page: p.item.uri, htmlLang: null, alternates: [], note: 'text/plain resource; no HTML locale annotations. Retained response headers: ' + Object.keys(p.http.value.headers).join(', ') };
  const self = p.finalUrl;
  const rows = p.alternates.map((a) => {
    const t = pages.get(a.href);
    return { ...a, targetInInventory: Boolean(t), targetStatus: t ? t.http.value.status : null, targetHtmlLang: t ? t.lang : null, targetListsSameAlternateSet: t ? JSON.stringify(t.alternates) === JSON.stringify(p.alternates) : null, targetCanonicalIsSelf: t ? t.canonical === a.href : null };
  });
  const selfRow = rows.find((r) => r.href === self);
  return { page: p.item.uri, effectiveUrl: self, htmlLang: p.lang, canonical: p.canonical, alternates: rows, selfReferenceHreflang: selfRow ? selfRow.hreflang : null, allReciprocal: rows.every((r) => r.targetInInventory && r.targetStatus === 200 && r.targetListsSameAlternateSet && r.targetCanonicalIsSelf), langMatches: rows.filter((r) => r.hreflang !== 'x-default').every((r) => r.targetHtmlLang === r.hreflang) };
};
for (const p of pages.values()) { p.locale = localeMap(p); if (p.isHtml && !(p.locale.allReciprocal && p.locale.langMatches && p.locale.selfReferenceHreflang === p.lang && p.alternates.length === 3)) throw new Error('locale annotations not clean for ' + p.item.uri); }

const canonicalTargets = (p) => {
  if (!p.isHtml) return { page: p.item.uri, declaredCanonical: null, note: 'text/plain resource; no HTML canonical element. Retained response headers: ' + Object.keys(p.http.value.headers).join(', ') + ' (selected subset; a Link header cannot be ruled out from this record alone)' };
  const t = pages.get(p.canonical);
  return { page: p.item.uri, requestedUrl: p.item.uri, redirects: p.http.value.redirects ?? [], effectiveUrl: p.finalUrl, declaredCanonical: p.canonical, canonicalEqualsEffectiveUrl: p.canonical === p.finalUrl, ogUrl: p.ogUrl, ogUrlEqualsCanonical: p.ogUrl === p.canonical, canonicalTargetInInventory: Boolean(t), canonicalTargetStatus: t ? t.http.value.status : null, canonicalTargetDeclaresItself: t ? t.canonical === p.canonical : null, hreflangSelfEntryEqualsCanonical: p.alternates.some((a) => a.href === p.canonical && a.hreflang === p.lang) };
};
for (const p of pages.values()) { p.canon = canonicalTargets(p); if (p.isHtml && !(p.canon.canonicalEqualsEffectiveUrl && p.canon.ogUrlEqualsCanonical && p.canon.canonicalTargetStatus === 200 && p.canon.canonicalTargetDeclaresItself && p.canon.hreflangSelfEntryEqualsCanonical)) throw new Error('canonical signals not clean for ' + p.item.uri); }

const mediaInventory = (p) => {
  if (!p.isHtml) return { page: p.item.uri, elements: [], note: 'text/plain resource; no media elements' };
  const els = [];
  for (const m of p.html.matchAll(/<(img|svg|video|audio|picture|canvas|iframe|object|embed)\b[^>]*>/gi)) els.push({ element: m[1].toLowerCase(), tag: m[0] });
  const brandLink = (p.html.match(/<a class="brand"[^>]*>/) || [])[0] || null;
  const figures = [...p.html.matchAll(/<figure\b[^>]*>/gi)].length;
  const roleImg = [...p.html.matchAll(/<[a-z0-9]+\b[^>]*role="img"[^>]*>/gi)].map((m) => m[0]);
  const describedBy = roleImg.map((t) => (t.match(/aria-describedby="([^"]*)"/) || [])[1]).filter(Boolean);
  const figcaptions = [...p.html.matchAll(/<figcaption[^>]*>([\s\S]*?)<\/figcaption>/gi)].map((m) => decode(m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()));
  const ariaHiddenVisuals = [...p.html.matchAll(/<div class="work-visual[^"]*" aria-hidden="true">/g)].map((m) => m[0]);
  return { page: p.item.uri, surface: 'raw HTML source; CSS/background imagery and rendered state not inspected', elements: els, brandLinkTag: brandLink, figureCount: figures, roleImgElements: roleImg, ariaDescribedByIdsPresent: describedBy.map((id) => ({ id, present: p.ids.has(id) })), figcaptions, ariaHiddenDecorativeVisuals: ariaHiddenVisuals, ogImage: (p.html.match(/<meta property="og:image" content="([^"]*)"/) || [])[1] || null, ogImageNote: 'Referenced in metadata only; image file not collected' };
};
for (const p of pages.values()) {
  p.media = mediaInventory(p);
  if (p.isHtml) {
    const imgs = p.media.elements; if (imgs.length !== 1 || imgs[0].element !== 'img' || !/alt=""/.test(imgs[0].tag) || !/aria-label="/.test(p.media.brandLinkTag || '')) throw new Error('unexpected media set on ' + p.item.uri);
    if (p.kind === 'home' && !(p.media.figureCount === 1 && p.media.roleImgElements.length === 1 && /aria-label="/.test(p.media.roleImgElements[0]) && p.media.ariaDescribedByIdsPresent.every((x) => x.present) && p.media.figcaptions.length === 1)) throw new Error('unexpected figure markup on ' + p.item.uri);
    if (p.kind !== 'home' && (p.media.figureCount || p.media.roleImgElements.length)) throw new Error('unexpected figure on ' + p.item.uri);
  }
}
const schemaExtraction = (p) => ({ page: p.item.uri, surface: p.isHtml ? 'raw HTML source only; rendered DOM not captured' : 'text/plain body', jsonLdScripts: [...p.html.matchAll(/<script\b[^>]*type="application\/ld\+json"[^>]*>/gi)].length, microdataItemscopeAttributes: [...p.html.matchAll(/\sitemscope\b/gi)].length, microdataItempropAttributes: [...p.html.matchAll(/\sitemprop=/gi)].length, rdfaTypeofOrVocabAttributes: [...p.html.matchAll(/\s(typeof|vocab)=/gi)].length, openGraphMetaProperties: [...p.html.matchAll(/<meta property="(og:[^"]*)"/gi)].map((m) => m[1]), externalScripts: p.scripts.filter((s) => s.src).map((s) => s.src) });
for (const p of pages.values()) { p.schema = schemaExtraction(p); if (p.schema.jsonLdScripts || p.schema.microdataItemscopeAttributes || p.schema.rdfaTypeofOrVocabAttributes) throw new Error('structured data present; revisit judgments ' + p.item.uri); }

const titles = new Map();
for (const p of pages.values()) if (p.isHtml && short(p.item.uri) !== '/') { if (titles.has(p.title)) throw new Error('duplicate title ' + p.title); titles.set(p.title, p.item.uri); if (!p.title || !p.description || p.h1.length !== 1) throw new Error('metadata shape ' + p.item.uri); }

// ---------- shared derived tables
const counterpart = (p) => { if (!p.isHtml) return null; const other = p.alternates.find((a) => a.hreflang !== 'x-default' && a.hreflang !== p.lang); return other ? other.href : null; };
const inventoryMap = [...pages.values()].sort((a, b) => a.item.uri.localeCompare(b.item.uri)).map((p) => ({ itemId: p.item.itemId, uri: p.item.uri, mediaType: p.http.value.headers['content-type'], htmlLang: p.lang, purpose: { home: 'Landing page: product model, workflows, install overview, starter prompt, FAQ', catalog: 'Catalog of Solution Skills and tracked upstream skills', solution: 'Solution detail: codebase onboarding 1.1.0', guide: 'Host-specific install and usage guide', 'license-text': 'Font license notice (plain text)' }[p.kind], host: p.kind === 'guide' ? (p.item.uri.includes('claude-code') ? 'Claude Code' : 'Codex') : null, localeCounterpart: counterpart(p), aliasOf: short(p.item.uri) === '/' ? ORIGIN + '/en/' : null, contentSha256: p.content.snapshotHash, title: p.title }));
const entityTable = {
  provenance: 'Derived by the auditing agent from statements observed in the 12 collected snapshots. NOT an owner-authoritative entity record: the repository catalog.yaml and release records named by the site are on github.com, outside the allowed origin, and were not fetched.',
  observedStatements: [
    { fact: 'Solution Skill count on home status strip', pages: ['/', '/en/'], text: '02 ' + S.enCount },
    { fact: 'Solution Skill count on home status strip', pages: ['/vi/'], text: '02 ' + S.viCount },
    { fact: 'Third workflow card on home', pages: ['/', '/en/'], text: S.card3Version + ' / ' + S.enCard3 },
    { fact: 'Third workflow card on home', pages: ['/vi/'], text: S.card3Version + ' / ' + S.viCard3 },
    { fact: 'Solution Skill count on catalog', pages: ['/en/catalog/', '/vi/catalog/'], text: S.catCount },
    { fact: 'Catalog Solution Skill entries (EN)', pages: ['/en/catalog/'], text: [S.enCat1, S.enCat2, S.enCat3].join(' | ') },
    { fact: 'Catalog Solution Skill entries (VI)', pages: ['/vi/catalog/'], text: [S.viCat1, S.viCat2, S.viCat3].join(' | ') },
    { fact: 'Upstream skill count on catalog', pages: ['/en/catalog/', '/vi/catalog/'], text: S.catUp },
    { fact: 'Guide section for the third Solution Skill', pages: ['/en/guides/codex/', '/en/guides/claude-code/', '/vi/guides/codex/', '/vi/guides/claude-code/'], text: S.guideAudit },
  ],
  comparison: { homeStripCount: 2, homeStripEvaluationCandidates: 1, homeWorkflowCards: 3, homeCardsLabelledEvaluationCandidate: 2, catalogCount: 3, catalogEntriesLabelledEvaluationCandidate: 2, conflict: 'Home status strip (2 Solution Skills, 1 evaluation candidate) disagrees with the three workflow cards on the same page and with the catalog (3 Solution Skills, 2 evaluation candidates), in both locales.', consistentAcrossSnapshots: ['codebase onboarding version 1.1.0 / technical release', 'problem presentation version 0.1.0 / evaluation candidate', 'content search audit version 0.1.32 / evaluation candidate', 'supported hosts: Codex and Claude Code', 'no direct-download archive; build from GitHub source', 'codebase onboarding has three components'] },
};
const AUDIENCE = `Supplied by the audit requester in the task statement for this run (recorded ${now}): "Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied."\n\nAuditor interpretation (inferred, not supplied): the intended readers are developers who use Codex or Claude Code and want to evaluate, install and invoke NKSkills workflows, reading in English or Vietnamese. No personas, user research, search queries, support themes or question set were supplied, so demand and question coverage cannot be assessed from this record.\n`;

// ---------- build evidence
const artifacts = {}; const newEvidence = []; const ids = new Map();
const allContentIds = [...pages.values()].map((p) => p.content.evidenceId).sort();
function add(p, kind, value, { json = true, sources, locator, limitations }) {
  const tag = p.item.itemId.slice(0, 12);
  const evidenceId = `derived-${kind}-${tag}`;
  const artifact = `evidence/${evidenceId}.${json ? 'json' : 'txt'}`;
  const bytes = json ? JSON.stringify(value, null, 2) + '\n' : value;
  artifacts[artifact] = bytes;
  newEvidence.push({ evidenceId, itemId: p.item.itemId, kind, value: json ? JSON.parse(bytes) : bytes, method: kind === 'audience-context' ? 'requester-task-statement' : 'host-derived-inert-text-analysis', locator, collectedAt: now, snapshotHash: sha(bytes), artifact, encoding: json ? 'json' : 'utf8', sourceEvidenceIds: [...new Set(sources)].sort(), redaction: 'None applied; derived from public snapshots and the requester task statement', limitations });
  ids.set(p.item.itemId + '|' + kind, evidenceId);
}
const L_DERIVED = ['Derived by regex over the captured raw source as inert text; not a DOM parser and not a rendered-browser observation', 'Describes the 2026-11-18 snapshots only; not live-site, index or AI-surface evidence'];
for (const p of pages.values()) {
  const own = [p.content.evidenceId, p.http.evidenceId];
  add(p, 'audience-context', AUDIENCE, { json: false, sources: [p.content.evidenceId], locator: 'requester task statement for this audit run (business context sentence)', limitations: ['Owner/requester-supplied context, not independently verified', 'Audience task is inferred by the auditor and labelled as such; no question set or user research supplied'] });
  add(p, 'extracted-text', p.text, { json: false, sources: [p.content.evidenceId], locator: p.item.uri + (p.isHtml ? ' (body text, tags removed)' : ' (plain-text body, unchanged)'), limitations: p.isHtml ? ['Regex tag-strip of the captured body by the host; script/style contents removed; block boundaries approximated', 'Includes text inside inert <template> elements and aria-hidden decorative blocks; link targets omitted; not rendered text'] : ['Identical to the captured text/plain body'] });
  add(p, 'link-graph', p.graph, { sources: [...own, ...p.graph.internalTargets.map((t) => pages.get(t.target).content.evidenceId), ...p.graph.inboundFromCollectedPages.map((u) => pages.get(u).content.evidenceId)], locator: p.item.uri + ' (a[href] in raw source; targets resolved against collected snapshots)', limitations: [...L_DERIVED, 'Static graph of 12 collected items; rendered navigation, orphan pages, CMS records and the sitemap named in robots.txt were not inspected', 'External targets were not fetched'] });
  add(p, 'locale-map', p.locale, { sources: [...own, ...p.alternates.map((a) => pages.get(a.href).content.evidenceId)], locator: p.item.uri + ' (html lang, canonical and hreflang link elements; counterpart snapshots compared)', limitations: [...L_DERIVED, 'Annotation consistency only; engine-selected language targeting is not observed'] });
  add(p, 'canonical-targets', p.canon, { sources: [...own, ...(p.canonical ? [pages.get(p.canonical).content.evidenceId, pages.get(p.canonical).http.evidenceId] : [])], locator: p.item.uri + ' (link rel=canonical, og:url, redirect record, target snapshot)', limitations: [...L_DERIVED, 'Declared signals only; publisher-intended variants and engine-selected canonical are unknown'] });
  add(p, 'media-inventory', p.media, { sources: [p.content.evidenceId], locator: p.item.uri + ' (media elements in raw source)', limitations: L_DERIVED });
  add(p, 'schema-extraction', p.schema, { sources: [p.content.evidenceId], locator: p.item.uri + ' (JSON-LD, microdata and RDFa markers in raw source)', limitations: [...L_DERIVED, 'Absence in raw source does not establish absence in rendered DOM'] });
  add(p, 'entity-record', entityTable, { sources: allContentIds, locator: 'Observed entity statements across the 12 collected snapshots (derived table)', limitations: ['Derived observed-statement table, not an owner-authoritative entity record', 'Supports detection of conflicts between pages; cannot establish which statement is correct'] });
  add(p, 'inventory-map', inventoryMap, { sources: allContentIds, locator: 'Declared campaign inventory (12 items) with observed locale, purpose and alias relationships', limitations: ['Purpose labels are auditor classifications', 'Covers the static-link inventory only; discovery scope is incomplete (no CMS export, rendered navigation or orphan-page source)'] });
}

// ---------- reviews
const reviews = [];
const E = (p, kinds) => kinds.flatMap((k) => ['content', 'http-response'].includes(k) ? [p[k === 'content' ? 'content' : 'http'].evidenceId] : k === 'crawler-policy' ? p.policies.map((x) => x.evidenceId) : [ids.get(p.item.itemId + '|' + k)]);
const rv = (p, ruleId, status, reason, kinds) => reviews.push({ itemId: p.item.itemId, ruleId, status, reason, evidenceIds: E(p, kinds), reviewer: REVIEWER, reviewedAt: now });
const policyNote = (p) => { const v = p.policies[p.policies.length - 1].value; return `Captured robots.txt (HTTP ${v.capture.status}) body: ${JSON.stringify(v.capture.body)}; collector decision: ${v.decision.reason}.`; };
const aliasNote = (p) => short(p.item.uri) === '/' ? ' This item is the root URL, which answered 308 to /en/; its body is byte-identical to the /en/ item (same SHA-256), so the judgment mirrors /en/.' : '';
const extScripts = (p) => p.scripts.filter((s) => s.src).map((s) => s.src.replace(/\/beacon\.min\.js\/.*/, '/beacon.min.js/…')).join(', ');

for (const p of pages.values()) {
  const s = short(p.item.uri); const vi = p.lang === 'vi'; const k = p.kind; const A = aliasNote(p);
  const homeOrGuide = k === 'home' || k === 'guide';
  // --- quality
  if (k === 'home') rv(p, 'quality-task-fit', 'pass', `Inferred task (not supplied by the owner): a Codex or Claude Code developer learns what NKSkills is, the status of each workflow and how to start. The static source states the model, shows three workflow cards with version, status and limits, gives a three-step install overview with links to both host guides, a starter prompt with its prerequisites, and a four-question FAQ. Caveats: the status-strip count conflicts with the cards (recorded under aio-entity-consistency, finding NKS-F1); the prompt picker's rendered behaviour was not inspected.${A}`, ['content', 'audience-context']);
  if (k === 'catalog') rv(p, 'quality-task-fit', 'pass', `Inferred task (not supplied): a developer checks which Solution Skills and upstream skills exist, with source, version, licence and status. The static source lists three Solution Skills with version and status, nine upstream entries and six security sources each with category, licence, short commit and a pinned source link, names catalog.yaml as the data source, and explains the versioning model.${vi ? ' Minor copy observation: the hero eyebrow reads "NKSKILLS / DANH MỤ" (the home page uses "DANH MỤC"); it looks truncated but does not block the task.' : ''} Licence and commit values themselves are unverified (see quality-claims).`, ['content', 'audience-context']);
  if (k === 'solution') rv(p, 'quality-task-fit', 'pass', 'Inferred task (not supplied): a developer evaluates the codebase-onboarding workflow before installing. The static source states the release status and what was and was not verified, the three components with their origin, the Quick-mode outputs, prerequisites and current limits, and links to both host guides, the manifest, the release record and the full technical setup.', ['content', 'audience-context']);
  if (k === 'guide') rv(p, 'quality-task-fit', 'fail', `Inferred task (not supplied): a developer installs and invokes NKSkills in ${p.item.uri.includes('claude-code') ? 'Claude Code' : 'Codex'}. Build, install, verification and invocation steps are ordered and complete for a reader who already has the tools. Gap: the prerequisite list names "${S.prereq}" and step 04 asks the reader to run their version/status commands, but the page neither says what these two tools are nor where to get or set them up. The only setup-related link in the page body is labelled "${vi ? S.viGuideLinkLabel : S.enGuideLinkLabel}" (to the GitHub technical guide, not fetched), which does not tell the reader that prerequisite setup is covered there. Low severity; see finding NKS-F3.`, ['content', 'audience-context']);
  if (k === 'license-text') rv(p, 'quality-task-fit', 'unknown', 'The notice names three fonts, their authors and the SIL Open Font License 1.1, and refers to full notices by bare file name (fraunces-OFL.txt, source-sans-3-OFL.txt, ibm-plex-mono-OFL.txt). Those files are not hyperlinks, were not part of the static-link inventory and were not collected, so whether a reader can reach the full licence texts is unresolved. Needed: an authorized capture of those three files or owner confirmation of their URLs.', ['content', 'audience-context']);
  rv(p, 'quality-claims', 'unknown', k === 'license-text' ? 'No dated authoritative source for the font authorship and licence statements was supplied or collected; the referenced full notices were not captured. Claims are unverified, not false.' : `No dated authoritative claim sources were supplied, and none are collectable in scope: versions, digests, licences, commit pins and verification-status statements point to github.com records (release record, manifests, catalog.yaml), which are outside the single allowed origin and were not fetched. Material claims are therefore unverified, not false.${k === 'home' ? ' The self-contradictory Solution Skill count is recorded under aio-entity-consistency.' : ''}`, ['content']);
  rv(p, 'quality-freshness', 'unknown', k === 'license-text' ? 'No date or version on the notice and no dated source supplied; currency cannot be assessed.' : 'The captured source carries no publication or last-updated date, and no dated authoritative release record was supplied. Whether the stated versions and statuses (1.1.0, 0.1.0, 0.1.32) are current cannot be assessed from snapshots alone.', ['content']);
  if (p.isHtml) rv(p, 'quality-accessible-media', 'pass', `Raw-source media inventory: one <img> (header brand mark, alt="" inside a link that carries aria-label and visible brand text, i.e. decorative)${k === 'home' ? '; one workflow <figure> whose role="img" element has an aria-label and an aria-describedby target present in the source, plus a figcaption; two illustrative card visuals marked aria-hidden="true"' : ''}. No video, audio, svg, iframe or canvas elements. Scope: raw source only; CSS imagery, the og:image file and rendered state were not inspected.${A}`, ['content', 'media-inventory']);
  else rv(p, 'quality-accessible-media', 'not-applicable', 'The captured response is text/plain (377 bytes) and contains no media, so text alternatives are not relevant to this item.', ['content', 'http-response', 'media-inventory']);
  // quality-readable-text is deterministic: recomputed by the helper from the added extracted-text evidence.
  // --- seo
  rv(p, 'seo-index-controls', 'unknown', `Publisher index and snippet intent was not supplied, so the comparison this rule requires cannot be made. Observed only: ${p.isHtml ? 'no robots or googlebot meta element in the raw source; ' : ''}no X-Robots-Tag among the retained response headers (${Object.keys(p.http.value.headers).join(', ')}; the collector retains a selected subset). ${policyNote(p)} None of this is index-status evidence.`, ['content', 'http-response', 'crawler-policy']);
  if (p.isHtml) rv(p, 'seo-canonical', 'pass', `Captured signals agree: ${s === '/' ? 'the root URL answers 308 to /en/ and the returned document declares canonical ' + p.canonical : 'link rel=canonical is ' + p.canonical + ', equal to the fetched URL'}; og:url matches; the canonical target was collected with HTTP 200 and declares itself canonical; the hreflang self entry equals the canonical. No conflicting canonical signal was found in the 12 snapshots. Not established: publisher-intended variants beyond those observed, sitemap membership (sitemap not collected) and which canonical any engine selected.`, ['content', 'canonical-targets']);
  else rv(p, 'seo-canonical', 'unknown', 'A text/plain resource cannot carry an HTML canonical element. No Link header appears among the retained response headers, but the collector retains only a selected subset and the publisher intent for this resource was not supplied, so applicability is unresolved.', ['content', 'http-response', 'canonical-targets']);
  if (p.isHtml) rv(p, 'seo-metadata', 'pass', `Title "${p.title}", H1 "${p.h1[0]}" and the meta description describe the page's actual subject in the page language; no title is shared with a different collected page${s === '/' ? ' (the root URL is a redirect alias of /en/)' : ''}.${homeOrGuide ? ' Caveat (optional improvement, not a failure): the description enumerates only codebase onboarding and problem presentation, although the page also covers Content search audit 0.1.32.' : ''} No universal length rule was applied; search-result display is not observed.`, ['content', 'audience-context']);
  else rv(p, 'seo-metadata', 'not-applicable', 'The captured response is text/plain: it has no title element, meta description or heading markup to review. Its first line ("NKSkills site font notices") names the subject.', ['content', 'http-response', 'audience-context']);
  rv(p, 'seo-internal-links', 'pass', p.isHtml ? `Raw-source anchors resolve to ${new Set(p.graph.internalTargets.map((t) => t.target)).size} distinct same-origin URLs, all of which are in the collected inventory with HTTP 200; every fragment used (${p.graph.internalTargets.filter((t) => t.fragment).length}) has a matching id in the target snapshot. ${s === '/' ? 'The root URL has no inbound links from collected pages (pages link to /en/ or /vi/ directly); it is the crawl seed and redirects.' : `The page is linked from ${p.graph.inboundFromCollectedPages.length} other collected pages.`} ${p.graph.externalTargets.count} external targets (github.com) were not fetched and are unverified. Scope: static graph of 12 items; rendered navigation and orphan pages not inspected.` : `The resource is linked from ${p.graph.inboundFromCollectedPages.length} collected pages (footer "Font licenses" link) and returned HTTP 200. As plain text it contains no hyperlinks; the three licence files it names are not link targets in the declared graph and were not checked.`, ['content', 'link-graph']);
  if (p.isHtml) rv(p, 'seo-structured-data', 'unknown', `The raw source contains no JSON-LD script, microdata or RDFa markers (Open Graph meta properties only), so there is nothing in the captured surface to compare with visible claims. The page loads external script(s) (${extScripts(p)}) that were not executed, so absence in the rendered DOM is not established. Needed: an authorized rendered-DOM capture or owner confirmation that no structured data is injected.`, ['content', 'schema-extraction']);
  else rv(p, 'seo-structured-data', 'not-applicable', 'A text/plain response cannot embed HTML structured data markup and contains none.', ['content', 'http-response', 'schema-extraction']);
  if (p.isHtml) rv(p, 'seo-locales', 'pass', `html lang="${p.lang}" matches the page language; the page lists hreflang en, vi and x-default (x-default points to the English URL) including a self reference; the ${vi ? 'English' : 'Vietnamese'} counterpart ${short(counterpart(p))} was collected with HTTP 200, lists the identical alternate set and is self-canonical, so the pair is reciprocal. ${vi ? 'Body copy is Vietnamese with English product terms and command text.' : 'Body copy is English.'}${k === 'home' ? ' The inert prompt <template> elements carry both languages on both locale pages without lang attributes (minor).' : ''}${s === '/' ? ' The root alias serves the English document.' : ''} Not established: language targeting as selected by any engine.`, ['content', 'locale-map']);
  else rv(p, 'seo-locales', 'unknown', 'The English plain-text notice is linked from both locale footers and has no declared language variants. Whether a Vietnamese variant is intended was not supplied; no Link header is among the retained headers (selected subset).', ['content', 'http-response', 'locale-map']);
  if (p.isHtml) rv(p, 'seo-rendering', 'unknown', `No rendered DOM exists for this item: browser use and script execution are outside the authorized scope of this pilot, and no capture was attempted. The raw source loads ${extScripts(p)}; ${k === 'home' ? 'the prompt picker script is expected to act on the inert <template> prompts, but its effect was not observed. ' : ''}Main content is present as static text in the raw source. Needed: an authorized rendered capture.`, ['content']);
  else rv(p, 'seo-rendering', 'not-applicable', 'The response is text/plain with no script; there is no script-dependent rendering to compare.', ['content', 'http-response']);
  // --- aio
  rv(p, 'aio-crawler-policy', 'unknown', `Publisher intent for search, AI-retrieval and training crawlers was not supplied. ${policyNote(p)} The captured file has a single "User-agent: *" group and no crawler-specific groups. This is a permission observation for the captured file only; it is not evidence that any crawler fetched, retrieved or cited the page.`, ['crawler-policy']);
  if (k === 'home') rv(p, 'aio-entity-consistency', 'fail', `The status strip reads "${vi ? '02 ' + S.viCount : '02 ' + S.enCount}", but the same page presents three workflow cards, two of them labelled evaluation candidate ("${S.card3Version}" / "${vi ? S.viCard3 : S.enCard3}"), and the catalog in the same locale states "${S.catCount}" with two evaluation candidates. The product count and candidate count are therefore inconsistent on the landing page. Which figure is authoritative is not established (repository catalog.yaml not in scope). See finding NKS-F1.${A}`, ['content', 'entity-record']);
  else rv(p, 'aio-entity-consistency', 'unknown', `No owner-authoritative entity record was supplied or collectable in scope (the repository catalog.yaml and release records are on github.com). ${k === 'license-text' ? 'The notice makes no product claims that overlap other collected pages.' : 'Product names, versions, statuses and host names on this page agree with the other collected snapshots (derived observed-statement table)'}${k === 'license-text' ? '' : ', but agreement between pages is not verification against an authoritative record.'}`, ['content', 'entity-record']);
  rv(p, 'aio-retrievable-facts', 'pass', k === 'license-text' ? 'Font names, authors and the licence (SIL Open Font License 1.1) are stated in plain text and readable without rendering.' : `The facts a reader needs from this page (${{ home: 'what NKSkills is, the three workflows with version and status, supported hosts, install path, starter prompt and its safeguards', catalog: 'each Solution Skill with version and status; each tracked upstream with category, licence, short commit and source link', solution: 'release status, verification limits, components, outputs and prerequisites', guide: 'prerequisites, build and install commands, invocation token and limits for each of the three packages' }[k]}) are present as static text with their surrounding context in the raw source, without needing script execution.${k === 'home' ? ' Caveat: the Solution Skill count is stated inconsistently (finding NKS-F1).' : ''} Readability of the captured text is not evidence of retrieval or citation by any AI surface.${A}`, ['content', 'audience-context']);
  // --- aeo
  rv(p, 'aeo-question-coverage', 'unknown', `No real question set (search queries, support or sales questions) was supplied.${k === 'home' ? ' The four FAQ questions on the page are publisher-authored and were not treated as user-demand evidence.' : ''} Question coverage cannot be mapped without one.`, ['content']);
  rv(p, 'aeo-answer-context', 'unknown', 'No real question set was supplied, so which passages are answers, and whether each stands on its own, cannot be assessed against user questions.', ['content']);
  rv(p, 'aeo-answer-evidence', 'unknown', 'No dated claim sources were supplied; supporting records are on github.com, outside the allowed origin. Source support for answer claims is unverified.', ['content']);
  // --- geo
  for (const r of ['geo-observed-presence', 'geo-answer-accuracy', 'geo-cohort-validity']) rv(p, r, 'unknown', 'No AI response observations were supplied or collected (no engine, surface, prompt cohort or response artifacts). Mentions, citations and answer accuracy are unmeasured, not zero.', []);
  // --- portfolio (local)
  rv(p, 'portfolio-task-gaps', 'unknown', 'No question set or demand evidence was supplied, and discovery scope is incomplete (no CMS export, rendered navigation or orphan-page source). Task gaps cannot be evidenced; any gap would be speculative.', ['content', 'inventory-map']);
  rv(p, 'portfolio-duplication', 'pass', s === '/' ? 'The root URL duplicates /en/ byte for byte, but it answers 308 to /en/ and the document declares /en/ canonical, so it is a redirect alias rather than competing content.' : k === 'guide' ? `The ${vi ? 'Vietnamese' : 'English'} Codex and Claude Code guides share most wording and differ in host name, --target value and invocation token ($ vs /). They serve distinct host audiences and each has its own locale counterpart, so they are legitimate variants; no consolidation is proposed.` : k === 'license-text' ? 'No other collected item covers the font licence notice.' : `The only overlapping item is the ${vi ? 'English' : 'Vietnamese'} counterpart ${short(counterpart(p))}, a declared locale variant${s === '/en/' ? ' (plus the root redirect alias)' : ''}. No other collected page serves the same task.`, ['content', 'inventory-map']);
  if (k === 'home') rv(p, 'portfolio-contradictions', 'fail', `Cross-page conflict: this page's status strip states two Solution Skills with one evaluation candidate, while ${vi ? '/vi/catalog/' : '/en/catalog/'} states "${S.catCount}" and lists three (two evaluation candidates), and all four guides document a third package ("${S.guideAudit}"). Not resolved against an authoritative record (catalog.yaml is outside the allowed origin). See finding NKS-F1.${A}`, ['content', 'entity-record', 'inventory-map']);
  else rv(p, 'portfolio-contradictions', 'pass', k === 'license-text' ? 'The notice makes no claim that conflicts with another collected page.' : `No material claim on this page conflicts with another collected snapshot: versions (1.1.0, 0.1.0, 0.1.32), release statuses, supported hosts, the build-from-source distribution status and the component count agree across the 12 items${k === 'catalog' ? '; the catalog count of three Solution Skills is contradicted only by the home status strip, which is recorded against the home items (NKS-F1)' : ''}, and the ${vi ? 'English' : 'Vietnamese'} counterpart makes the same claims. Scope: consistency among collected pages only; not verified against the repository records.`, ['content', 'entity-record', 'inventory-map']);
  if (k === 'home' || k === 'catalog') rv(p, 'portfolio-journey-links', 'fail', `The Content search audit ${k === 'home' ? 'card ("' + (vi ? 'Cài đặt và sử dụng' : 'Install and use') + '")' : 'entry'} links only to ${vi ? '/vi' : '/en'}/guides/codex/#content-search-audit. The ${vi ? 'Vietnamese' : 'English'} Claude Code guide contains the same section with the same id, but nothing on this page links to it for this workflow, so a Claude Code reader following the only call to action lands on Codex-specific commands (--target codex, $content-search-audit). Other journeys on the page resolve (codebase onboarding reaches both host guides via ${k === 'home' ? 'the install section' : 'the solution page'}). See finding NKS-F2.${A}`, ['content', 'link-graph', 'audience-context']);
  if (k === 'solution') rv(p, 'portfolio-journey-links', 'pass', 'The page offers both next steps a reader needs: "Use with Codex" and "Use with Claude Code" link to the collected host guides in the same locale; breadcrumb, catalog, language switch and the starter-prompt anchor resolve; manifest, release record and technical setup are linked externally (not fetched).', ['content', 'link-graph', 'audience-context']);
  if (k === 'guide') rv(p, 'portfolio-journey-links', 'pass', 'Next steps resolve in the static graph: the starter-prompt link (/#try-it), the breadcrumb to the home install section (#install), catalog, language switch and the release-limit links (external, not fetched). The guide does not link to the other host guide; that is not required for this host-specific task and is noted only as context for finding NKS-F2.', ['content', 'link-graph', 'audience-context']);
  if (k === 'license-text') rv(p, 'portfolio-journey-links', 'unknown', 'A plain-text notice has no navigation. Its stated next step (the full licence notices) is given as bare file names whose reachability was not checked because they are outside the static-link inventory.', ['content', 'link-graph', 'audience-context']);
}

// ---------- findings
const homes = ['/', '/en/', '/vi/'].map(P); const catalogs = ['/en/catalog/', '/vi/catalog/'].map(P); const guides = [...pages.values()].filter((p) => p.kind === 'guide');
const fe = (list, kinds) => list.flatMap((p) => E(p, kinds));
const findings = [
  { findingId: 'NKS-F1-solution-skill-count', title: 'Home status strip counts two Solution Skills and one evaluation candidate; the same page and the catalog show three and two', affectedItemIds: homes.map((p) => p.item.itemId), ruleIds: ['aio-entity-consistency', 'portfolio-contradictions'], dimensions: ['aio', 'portfolio'], evidenceIds: fe(homes, ['content', 'entity-record', 'inventory-map']), severity: 'medium', confidence: 'high', classification: 'observed', actionCondition: 'the owner confirms from the repository catalog that three Solution Skills (one technical release, two evaluation candidates) is the current, intended public count', remediation: 'Update the home status strip in both locales to match the catalog (three Solution Skills; one technical release; two evaluation candidates). Optionally also mention Content search audit in the home and guide meta descriptions, which currently enumerate only two workflows. If the catalog is the side that is wrong, correct the catalog and cards instead.', verification: 'Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and confirm the strip counts, the number of workflow cards and the catalog count agree in each locale.', ownerRole: 'Website content owner (role assumed; no owner was named for this pilot)', effort: 'small' },
  { findingId: 'NKS-F2-audit-cta-single-host', title: 'Content search audit call to action leads only to the Codex guide although the Claude Code guide has the same section', affectedItemIds: [...homes, ...catalogs].map((p) => p.item.itemId), ruleIds: ['portfolio-journey-links'], dimensions: ['portfolio'], evidenceIds: fe([...homes, ...catalogs], ['content', 'link-graph', 'audience-context']), severity: 'low', confidence: 'high', classification: 'observed', remediation: 'Give Claude Code readers a path from the Content search audit card and catalog entry, for example a second link to the Claude Code guide section (#content-search-audit) or a host choice like the one used for codebase onboarding. Related observation: Problem presentation cards link to the GitHub manifest or the catalog rather than to the on-site "Try Problem presentation" guide section.', verification: 'Re-capture the home and catalog pages in both locales and confirm that the Content search audit entry links to both host guides and that each fragment resolves to an id in the target page.', ownerRole: 'Website content owner (role assumed; no owner was named for this pilot)', effort: 'small' },
  { findingId: 'NKS-F3-guide-prerequisite-tools', title: 'Install guides require codegraph and rtk without saying what they are or where to set them up', affectedItemIds: guides.map((p) => p.item.itemId), ruleIds: ['quality-task-fit'], dimensions: ['quality'], evidenceIds: fe(guides, ['content', 'audience-context']), severity: 'low', confidence: 'medium', classification: 'observed', actionCondition: 'the linked GitHub technical guide (not fetched in this pilot) does cover codegraph and rtk setup', remediation: 'In the prerequisites section of all four guides, add one line describing codegraph and rtk and link the setup instructions, or relabel the existing technical-guide link so readers can tell it covers prerequisite setup (the solution page already uses "Read the full technical setup").', verification: 'Re-capture the four guides and confirm the prerequisites section names a setup source for both tools; separately confirm the linked document contains those steps.', ownerRole: 'Website content owner (role assumed; no owner was named for this pilot)', effort: 'small' },
];

const bundle = { schemaVersion: 1, campaignId: manifest.campaignId, sourceManifestHash: sha(manifestBytes), parts: [{ path: PART, sourceSnapshotHash: index.partSnapshotHashes[PART], bundle: { artifacts, evidence: newEvidence, reviews, findings } }] };
writeFileSync(outBundle, JSON.stringify(bundle, null, 2) + '\n', { flag: 'wx' });
const facts = { generatedAt: now, reviewer: REVIEWER, snippets: S, entityTable, inventoryMap, audience: AUDIENCE, perPage: [...pages.values()].map((p) => ({ uri: p.item.uri, itemId: p.item.itemId, kind: p.kind, lang: p.lang, title: p.title, description: p.description, h1: p.h1, contentEvidenceId: p.content.evidenceId, contentArtifact: p.content.artifact, graph: p.graph })) };
writeFileSync(outFacts, JSON.stringify(facts, null, 2) + '\n', { flag: 'wx' });
const tally = {}; for (const r of reviews) tally[r.status] = (tally[r.status] || 0) + 1;
console.log(JSON.stringify({ written: outBundle, generatedAt: now, evidenceRecords: newEvidence.length, reviews: reviews.length, byStatus: tally, findings: findings.length }));
