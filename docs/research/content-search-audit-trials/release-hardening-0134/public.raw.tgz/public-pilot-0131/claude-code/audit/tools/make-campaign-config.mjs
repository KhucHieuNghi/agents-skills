// Builds the campaign config from the discovery request and the discover helper's returned union.
import { readFileSync, writeFileSync } from 'node:fs';
const [requestPath, unionPath, outPath] = process.argv.slice(2);
const discovery = JSON.parse(readFileSync(requestPath, 'utf8'));
const union = JSON.parse(readFileSync(unionPath, 'utf8'));
const config = {
  inputs: union.inputs,
  localRoots: [],
  inventoryComplete: union.inventoryComplete,
  mode: 'full',
  brandName: 'NKSkills',
  network: {
    allowedOrigins: ['https://nkskills.getgroove.me'],
    maxBytes: 10485760,
    timeoutMs: 20000,
    maxRedirects: 5,
    retries: 1,
  },
  maxRunBytes: 100663296,
  discovery,
};
writeFileSync(outPath, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ written: outPath, inputs: config.inputs.length, inventoryComplete: config.inventoryComplete }));
