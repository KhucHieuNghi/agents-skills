// Builds the supplied-source discovery union request from the continued source receipt.
// The source record is embedded unchanged (including absolute provenance paths).
import { readFileSync, writeFileSync } from 'node:fs';
const [sourcePath, outPath] = process.argv.slice(2);
const source = JSON.parse(readFileSync(sourcePath, 'utf8'));
const config = {
  // cms-export and rendered-navigation are expected for the declared scope but were not supplied;
  // they stay as explicit missing-source queue entries.
  expectedSourceIds: ['internal-links', 'cms-export', 'rendered-navigation'],
  scopeComplete: false,
  sources: [source],
};
writeFileSync(outPath, JSON.stringify(config, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ written: outPath, records: source.records.length }));
