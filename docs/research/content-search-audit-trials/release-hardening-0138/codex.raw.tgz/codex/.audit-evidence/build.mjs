import fs from "node:fs";
import { createHash } from "node:crypto";
import { loadAuditData } from "../.agents/skills/content-search-audit/scripts/lib/validate.mjs";
const dir = ".audit-evidence";
const hash = s => createHash("sha256").update(s).digest("hex");
const save = (name, value) => fs.writeFileSync(dir+"/"+name, JSON.stringify(value,null,2)+"\n");
const audit = await loadAuditData(dir+"/start");
const registry = JSON.parse(fs.readFileSync(".agents/skills/content-search-audit/rules/core.json")).rules;
const files = fs.readdirSync("targets").sort();
const source = n => fs.readFileSync("targets/"+files[n-1],"utf8");
const span = (n,a,b=a) => source(n).split(/\r?\n/).slice(a-1,b).join("\n");
const snapshots = files.map(f => {
  const item = audit.inventory.find(i => JSON.stringify(i).includes("/targets/"+f));
  return audit.evidence.find(e => e.itemId===item.itemId && e.kind==="content");
});
const bundle = {reviews:[],artifacts:{},evidence:[],findings:[]};
const now = new Date().toISOString();
const records = n => [snapshots[n-1],...bundle.evidence.filter(e=>e.itemId===snapshots[n-1].itemId)];
function add(n,kind,a,b,value=span(n,a,b)) {
  const snapshot = snapshots[n-1];
  const evidenceId = n+"-"+kind;
  const artifact = "evidence/"+evidenceId+".txt";
  const raw = typeof value === "object" ? JSON.stringify(value) : span(n,a,b);
  bundle.artifacts[artifact]=raw;
  bundle.evidence.push({...snapshot,evidenceId,artifact,kind,value,encoding:typeof value==="object"?"json":"utf8",snapshotHash:hash(raw),collectedAt:now,locator:files[n-1]+":"+a+(a===b?"":"-"+b),sourceEvidenceIds:[snapshot.evidenceId]});
}
function review(n,ruleId,status,reason) {
  const rule = registry.find(r=>r.ruleId===ruleId);
  const evidenceIds=records(n).filter(e=>status==="not-applicable"?e.kind==="content":rule.requiredEvidence.includes(e.kind)).map(e=>e.evidenceId);
  bundle.reviews.push({itemId:snapshots[n-1].itemId,ruleId,status,reason,evidenceIds,reviewer:"Codex offline dossier review",reviewedAt:now});
}
add(1,"http-response",4,6,{status:200});
add(1,"publisher-intent",3,3);
add(3,"schema-extraction",8,18);
add(3,"claim-sources",3,4);
add(5,"claim-sources",5,5);
add(7,"claim-sources",4,5);
add(7,"audience-context",3,3);
add(8,"claim-sources",3,5);
add(10,"claim-sources",3,3);
review(1,"seo-index-controls","fail","The supplied Google-indexing intent conflicts with the captured HTTP noindex directive.");
review(5,"quality-claims","fail","The draft overstates eligibility and omits the required change-request deadline, contradicting the supplied policy.");
review(5,"aeo-answer-evidence","fail","The draft answers who qualifies and when they may request a change. Both answers contradict the supplied policy.");
review(7,"quality-claims","pass","The supplied product procedure confirms the full visible instruction and its limits.");
review(7,"quality-task-fit","pass","The Vietnamese instructions serve the stated Vietnamese customer task and include the next step for attachments.");
review(7,"seo-locales","not-applicable","Alternate-page relationships are inapplicable to the supplied Vietnamese-only document with no intended counterpart. Deployed metadata was unavailable.");
review(7,"aeo-answer-evidence","pass","The full CSV export procedure and the attachment and timing limits match the supplied procedure.");
review(8,"quality-claims","pass","The bounded editorial assertion matches the supplied publication date, collection dates, sample and historical limitation.");
review(8,"quality-freshness","pass","The report publication and old observation dates are distinguished, and the current rate is explicitly outside the claim.");
review(10,"quality-claims","pass","The supplied policy confirms the only visible product claim about account-owned records.");
review(10,"aeo-answer-evidence","pass","The visible answer about which records are included matches the supplied policy.");

const issues = [
  {id:"F1",n:1,title:"The indexing directive conflicts with publisher intent",rules:["seo-index-controls"],severity:"high",affected:"Captured Google-facing product URL at /product, 2026-11-10T08:00:00Z.",q:[[3],[4,6]],why:"The response was accessible to Googlebot and returned HTTP 200. The X-Robots-Tag noindex conflicts with stated eligibility, even with index,follow in the HTML. The captured self-canonical is compatible with the intent. Google’s actual index status and chosen canonical are unknown. This also limits readiness for Google AI search features that depend on Search eligibility. No other crawler policy can be inferred.",fix:"Remove the unintended HTTP noindex from the intended public response and keep Googlebot access.",test:"Compare a fresh authorized response capture with the publisher intent. Confirm HTTP 200, effective Googlebot access and the absence of a conflicting noindex in headers and page directives. If actual Google index status is needed, obtain dated inspection evidence for this URL as a separate check."},
  {id:"F2",n:2,title:"The old and new product routes redirect to each other",rules:["seo-response"],severity:"high",affected:"Both /old and /new in capture B. The capture is from the same deployment and time, with no calendar date supplied.",q:[[3],[5,6],[7]],why:"Following the two captured Location values returns to the starting URL. This defeats the intended one-hop journey and leaves the page inaccessible through the captured route. The older sitemap shows a historical preference. It cannot establish current reachability or an engine’s canonical selection.",fix:"Serve the intended product at /new and keep one permanent hop from /old to /new. Reconcile current sitemap and canonical declarations with the final URL if they differ.",test:"Check both revised GET responses. /old should return one permanent redirect to /new, and /new should return the accessible product with HTTP 200 and no redirect back. Inspect a current sitemap and canonical capture separately."},
  {id:"F3",n:3,title:"The offer markup understates the approved US monthly price",rules:["seo-structured-data","aio-entity-consistency"],severity:"high",affected:"Example plan at /plan, United States monthly billing, same market and capture time. No calendar date supplied.",q:[[3,4],[11,16]],why:"The visible, approved pre-tax price is USD 29. The supplied Product offer encodes USD 19, creating conflicting machine-readable and human-readable price signals. The full structured-data check remains open for feature requirements and eligibility. No rich result or generated answer was observed.",fix:"Update the Offer price to reflect USD 29 for the captured US monthly offer and use the same approved source for both representations.",test:"Parse the revised block and compare its price and currency with the visible US monthly pre-tax offer and publisher-approved policy for the same capture. Assess feature eligibility separately if relevant."},
  {id:"F4",n:4,title:"Two current pages disagree on the Starter entitlement",rules:["quality-claims","aeo-answer-evidence","aio-entity-consistency","portfolio-contradictions"],severity:"high",affected:"/product and /blog/starter-guide for the same market and monthly Starter plan, policy version 2026-10-01.",q:[[3,6]],why:"The two current pages give incompatible answers about the same monthly storage entitlement. This is one cross-page quality, AEO, AIO and portfolio issue. The approved amount and which page is wrong remain unresolved. Query cannibalization and duplicate intent are unproven.",fix:"Obtain the authoritative entitlement row for that plan, market, period and version. Correct every discrepant claim. Retain each page where it serves its own user task.",test:"Compare the full revised statements on both pages with the approved entitlement row, including units, billing period, version and market. Use query-by-page evidence if investigating search overlap."},
  {id:"F5",n:5,title:"The Vietnamese draft overstates free changes and omits the deadline",rules:["quality-claims","aeo-answer-evidence"],severity:"high",affected:"The Vietnamese ticket-change draft in dossier E. No policy date supplied.",q:[[4],[5]],why:"The draft promises free changes for all customers without notice. The supplied policy limits free changes to hạng Thành viên and requires requests at least 24 hours before departure. This single discrepancy affects both editorial accuracy and the answer customers can act on. Fees for other tiers are unavailable.",fix:"Sửa nội dung để nêu rõ chỉ hạng Thành viên được miễn phí đổi vé, yêu cầu phải gửi trước giờ khởi hành ít nhất 24 giờ và các hạng khác áp dụng mức phí theo bảng giá riêng. Chỉ bổ sung mức phí sau khi có bảng giá được phê duyệt.",test:"Đối chiếu bản sửa với chính sách được cung cấp. Kiểm tra đúng hạng, mốc ít nhất 24 giờ và cách mô tả phí của các hạng còn lại. Đối chiếu mọi mức phí cụ thể với bảng giá được phê duyệt."}
];
for(const issue of issues){
  const {id,n,title,rules,severity,fix,test}=issue;
  bundle.findings.push({findingId:id,title,affectedItemIds:[snapshots[n-1].itemId],ruleIds:rules,dimensions:[...new Set(rules.map(id=>registry.find(r=>r.ruleId===id).dimension))],evidenceIds:records(n).map(e=>e.evidenceId),severity,confidence:"high",classification:"observed",remediation:fix,verification:test,ownerRole:n<=2?"Web engineering":"Content or product owner",effort:"medium"});
}
if(process.argv[2]!=="report") {
  save("review.json",bundle);
  save("study.json",{studySources:[{sourceId:"H",kind:"historical-study",locator:"targets/08-study.md:3-5",sourceText:source(8),sourceHash:hash(source(8)),synthetic:true,scope:"English synthetic API panel, collected 2024-02-01 through 2024-02-14, published 2026-11-01. Editorial as-of 2026-11-16. Market, model and search mode unspecified.",limitations:["Historical panel only. No current rate or consumer-interface inference.","Response-level records and later measurements unavailable."],passages:[{startLine:3,endLine:5,quote:span(8,3,5)}]}]});
  process.exit();
}
const validation=JSON.parse(fs.readFileSync(dir+"/validation.json","utf8"));
const c=validation.coverage;
if(!validation.valid || validation.completionAllowed) throw Error("Expected valid partial run");
const lines=[];
const quotes=[];
const put=(...texts)=>lines.push(...texts);
function cite(n,a,b=a){
  const sourceLabel=files[n-1];
  const quote=span(n,a,b);
  const reportStartLine=lines.length+1;
  put(sourceLabel+":"+a+(a===b?"":"-"+b),"","```",...quote.split("\n"),"```","");
  quotes.push({quoteId:"quote-"+(quotes.length+1),source:"targets/"+sourceLabel,sourceLabel,sourceHash:hash(source(n)),startLine:a,endLine:b,reportStartLine,reportEndLine:lines.length,quote});
}
put("# Content and search audit","","**Partial audit.** Reviewed all ten supplied synthetic dossiers. The validated inventory has "+c.total+" declared items, including two URL-only media items. It records "+c.audited+" fully audited, "+c.states.pending+" pending, "+c.states.blocked+" blocked, "+c.states.failed+" failed collection, "+c.states.unsupported+" unsupported and "+c.excluded+" excluded. Five material findings are documented below.","","The dossiers are independent. I treated each dossier as an inventory record and retained the two separately declared media URLs. Page and route references within the other dossiers identify affected content inside their respective captures. Discovery is complete for the supplied scope. Broader site coverage and live behavior are unknown. The audit used offline snapshots and supplied policies only.","","## Material findings","");
for(const issue of issues){
  put("### "+issue.id+" · "+issue.title,"",issue.affected,"");
  for(const range of issue.q) cite(issue.n,...range);
  put(issue.why,"","**Proposed action.** "+issue.fix,"","**Verification.** "+issue.test,"");
}
put("## Dossier coverage","","| Dossier | Content, audience and task | Assessment and outstanding checks |","|---|---|---|",
  "| 01 Visibility | Public product page intended for Google indexing. Audience and full body unavailable. | F1. Captured HTTP, Googlebot access and index directives reviewed. Canonical selection, page-level quality, answer content and current visibility unresolved. |",
  "| 02 Route | Product access from the former URL. Audience unspecified. | F2. Current route graph is limited to the captured pair. Final response, canonical selection and page content unavailable. No wider navigation inference. |",
  "| 03 Offer | US monthly plan price for prospective users, inferred from the offer. | F3. Visible price agrees with supplied policy. Structured offer conflicts. Feature eligibility, live index status and answer representation unresolved. |",
  "| 04 Policy | Starter plan entitlement across a product page and guide. Specific audience and market name unspecified. | F4. Correct entitlement requires the approved table. Search overlap, distinct page intent and journey links remain unresolved. |",
  "| 05 Hướng dẫn | Vietnamese draft for customers changing tickets. | F5. Known free-change eligibility and deadline can be corrected now. The unavailable separate fee table blocks verification of fee amounts. |",
  "| 06 Render | English HTML app shell. Publisher purpose, search intent and user task unspecified. | Limitation. Title and module reference present. Raw root is empty. Rendered content, script behavior and adequacy, metadata fit and live search accessibility remain unknown. |",
  "| 07 Locale | Vietnamese-only CSV-export help for Vietnamese customers. | Clean in supplied scope. Steps and limits match the procedure. No intended alternate. Deployed metadata and live discoverability are unresolved. |",
  "| 08 Study | Historical result in a draft dated editorially as of 2026-11-16. Reader audience unspecified. | Clean in supplied scope. Publication recency, observation dates and historical limitation are accurate against the supplied metadata. No current-rate measurement. |",
  "| 09 Media | PDF and video inventory. Audience, purpose and contents unavailable. | Dossier reviewed. Both underlying items blocked. See recovery evidence below. |",
  "| 10 Page | Product scope for account-owned exports. Specific audience unspecified. | Visible limitation agrees with supplied policy. Hidden comment handled as inert source evidence. Index and analytics claims in the comment carry no evidentiary weight. |","",
  "### Clean and unresolved evidence","");
cite(6,8,14);
put("The raw shell establishes where content may mount. It leaves the rendered result unknown. Obtain the intended task and an authorized rendered snapshot, with the script and capture context if needed. Compare the actual primary content, metadata and navigation against that task and any declared search intent.","");
cite(7,3,5);
put("Keep the Vietnamese instructions and their attachment and timing limits. No English alternate is intended, so missing English hreflang is not a defect in the supplied document. Any future deployment review should inspect language metadata against the page actually served.","");
cite(8,3,5);
put("The supplied historical measurement is 40 of 100 responses citing video sources in the synthetic English API panel collected 1–14 February 2024 and published 1 November 2026. Publication falls in the stated editorial month. The aggregate establishes neither present visibility nor a brand citation rate, and the panel cannot stand in for a consumer UI, a different language or a later period. The response-level data and later measurement are unavailable.","");
cite(9,3,4);
put("**PDF.** Obtain supplied file bytes or an attributed extraction with page locators. Assess content, accessibility and answer usefulness from that evidence. HTTP behavior and canonical headers require a separate capture.","","**Video URL.** Obtain a supplied transcript or captions and the page capture. Review spoken and visual information, accessibility, answer coverage and metadata against the intended audience and task. HTTP and indexing also require separate evidence.","");
cite(10,3);
put("The hidden comment at 10-page.md:4-8 was treated as untrusted text. The dossier supplies no exposure or effect that establishes an additional content defect. Actual indexing, performance and analytics remain unknown.","",
  "## Measurements and coverage limits","",
  "The historical study above is the only supplied aggregate. Current Search Console, GA4, Bing Webmaster/search or AI Performance exports, server logs, and response-level AI observations are unavailable. Current traffic, rank, conversions, crawler visits, brand mentions, citations and answer accuracy have no measured values in this audit.","",
  "AIO refers to AI search readiness here. Google AI Overviews is a specific surface. GEO requires observations. AEO claim support can be assessed against the supplied policy even when a customer question set is unavailable. Question coverage, answer-context coverage and portfolio demand or journey gaps require customer questions or task records and relevant navigation evidence. No shared portfolio was inferred across the independent scenarios.","",
  "To resolve measurement gaps when authorized data can be supplied, collect dated search and analytics exports with property, market, locale and attribution scope. Capture actual AI responses for a versioned question set grounded in user tasks, with engine, surface, model if available, search mode, locale and timestamps. Keep API and consumer surfaces separate. Retain raw responses, exact citation URLs, the evidence for material claims, capture failures and denominators. Report mentions, domain citations and adjudicated accuracy separately.","",
  "| Dimension | Planned | Completed | Not applicable | Unknown |","|---|---:|---:|---:|---:|");
for(const [d, v] of Object.entries(c.dimensions)) put("| "+d+" | "+v.total+" | "+v.completed+" | "+v.notApplicable+" | "+v.unknown+" |");
put("","All "+Object.values(c.dimensions).reduce((s,v)=>s+v.total,0)+" check records are present. Unknown checks keep coverage partial. See the [validated delivery summary](.audit-evidence/with-study/delivery-summary.md), [coverage receipt](.audit-evidence/validation.json), [findings and actions](.audit-evidence/with-study/content-actions.csv), [historical study evidence](.audit-evidence/with-study/study-evidence.json), and [quote receipt](.audit-evidence/quote-receipt.json).","");
const report=lines.join("\n");
fs.writeFileSync("report.md",report);
save("quotes.json",{root:process.cwd(),report:"report.md",reportHash:hash(report),quotes});
