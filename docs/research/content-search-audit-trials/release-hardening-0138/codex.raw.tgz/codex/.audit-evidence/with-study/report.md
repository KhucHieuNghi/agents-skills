# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 1; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:49:19\.541Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run faca6964\-88f1\-4eb2\-87fb\-72a3c7acf8f3\. 5 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | The indexing directive conflicts with publisher intent | seo\-index\-controls | seo | high | high | observed | 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the unintended HTTP noindex from the intended public response and keep Googlebot access\. | Compare a fresh authorized response capture with the publisher intent\. Confirm HTTP 200, effective Googlebot access and the absence of a conflicting noindex in headers and page directives\. If actual Google index status is needed, obtain dated inspection evidence for this URL as a separate check\. | Web engineering | medium | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e, 1\-http\-response, 1\-publisher\-intent |
| F2 | The old and new product routes redirect to each other | seo\-response | seo | high | high | observed | 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Serve the intended product at /new and keep one permanent hop from /old to /new\. Reconcile current sitemap and canonical declarations with the final URL if they differ\. | Check both revised GET responses\. /old should return one permanent redirect to /new, and /new should return the accessible product with HTTP 200 and no redirect back\. Inspect a current sitemap and canonical capture separately\. | Web engineering | medium | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| F3 | The offer markup understates the approved US monthly price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | high | high | observed | d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Update the Offer price to reflect USD 29 for the captured US monthly offer and use the same approved source for both representations\. | Parse the revised block and compare its price and currency with the visible US monthly pre\-tax offer and publisher\-approved policy for the same capture\. Assess feature eligibility separately if relevant\. | Content or product owner | medium | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36, 3\-schema\-extraction, 3\-claim\-sources |
| F4 | Two current pages disagree on the Starter entitlement | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency, portfolio\-contradictions | quality, aeo, aio, portfolio | high | high | observed | 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Obtain the authoritative entitlement row for that plan, market, period and version\. Correct every discrepant claim\. Retain each page where it serves its own user task\. | Compare the full revised statements on both pages with the approved entitlement row, including units, billing period, version and market\. Use query\-by\-page evidence if investigating search overlap\. | Content or product owner | medium | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| F5 | The Vietnamese draft overstates free changes and omits the deadline | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Sửa nội dung để nêu rõ chỉ hạng Thành viên được miễn phí đổi vé, yêu cầu phải gửi trước giờ khởi hành ít nhất 24 giờ và các hạng khác áp dụng mức phí theo bảng giá riêng\. Chỉ bổ sung mức phí sau khi có bảng giá được phê duyệt\. | Đối chiếu bản sửa với chính sách được cung cấp\. Kiểm tra đúng hạng, mốc ít nhất 24 giờ và cách mô tả phí của các hạng còn lại\. Đối chiếu mọi mức phí cụ thể với bảng giá được phê duyệt\. | Content or product owner | medium | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c, 5\-claim\-sources |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 3 | 33 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 6 | 54 | 0 |
| seo | 96 | 2 | 93 | 1 |

## Supplied historical measurement evidence

Historical study sources are attached below\. Their quoted measurements are not current brand observations\. Hashes and exact passages bind supplied bytes, not authenticity, sampling validity or semantic interpretation\. No response\-level observations or performance forecasts are manufactured from aggregates\.

## Historical study source

| Field | Value |
| --- | --- |
| Source | H |
| Kind | historical\-study |
| Locator | targets/08\-study\.md:3\-5 |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | English synthetic API panel, collected 2024\-02\-01 through 2024\-02\-14, published 2026\-11\-01\. Editorial as\-of 2026\-11\-16\. Market, model and search mode unspecified\. |
| Source SHA\-256 | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f |
| Limitations | Historical panel only\. No current rate or consumer\-interface inference\.; Response\-level records and later measurements unavailable\. |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| H | 3–5 | Synthetic fixture\. Editorial as\-of date: 2026\-11\-16\. Draft: A report published this month describes a synthetic English API panel collected 1–14 February 2024\. In that panel, 40 of 100 responses cited video sources\. These historical observations do not establish the current rate\. Supplied study metadata: publication 2026\-11\-01; collection 2024\-02\-01 through 2024\-02\-14; 40/100 responses, English synthetic API\. No later measurement is supplied\. |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | pending | Snapshot review incomplete | 26 |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | pending | Snapshot review incomplete | 26 |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | pending | Snapshot review incomplete | 26 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | pending | Snapshot review incomplete | 26 |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | pending | Snapshot review incomplete | 26 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | quality\-task\-fit | quality | pass | The Vietnamese instructions serve the stated Vietnamese customer task and include the next step for attachments\. | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49, 7\-audience\-context |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | quality\-claims | quality | pass | The supplied product procedure confirms the full visible instruction and its limits\. | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49, 7\-claim\-sources |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-locales | seo | not\-applicable | Alternate\-page relationships are inapplicable to the supplied Vietnamese\-only document with no intended counterpart\. Deployed metadata was unavailable\. | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | aeo\-answer\-evidence | aeo | pass | The full CSV export procedure and the attachment and timing limits match the supplied procedure\. | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49, 7\-claim\-sources |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | quality\-claims | quality | pass | The supplied policy confirms the only visible product claim about account\-owned records\. | 10\-claim\-sources, 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | aeo\-answer\-evidence | aeo | pass | The visible answer about which records are included matches the supplied policy\. | 10\-claim\-sources, 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 1\-http\-response |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-index\-controls | seo | fail | The supplied Google\-indexing intent conflicts with the captured HTTP noindex directive\. | 1\-http\-response, 1\-publisher\-intent, e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | quality\-claims | quality | pass | The bounded editorial assertion matches the supplied publication date, collection dates, sample and historical limitation\. | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21, 8\-claim\-sources |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | quality\-freshness | quality | pass | The report publication and old observation dates are distinguished, and the current rate is explicitly outside the claim\. | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21, 8\-claim\-sources |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | quality\-claims | quality | fail | The draft overstates eligibility and omits the required change\-request deadline, contradicting the supplied policy\. | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c, 5\-claim\-sources |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | aeo\-answer\-evidence | aeo | fail | The draft answers who qualifies and when they may request a change\. Both answers contradict the supplied policy\. | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c, 5\-claim\-sources |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1381ec02b73b436982d3029934cbadd561db6909fee2ba76bb93c3ba052d5041 | 12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8 | local\-file | 2026\-11\-18T05:46:40\.334Z | 0 full elapsed days | [evidence/12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8\.txt](evidence/12180af7cf01328e8a7e5a9aef5a63387296f33e25abf7acb5d6c550ecb511a8.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5711418625ec5bf9c7aee71016191d22050cf1e5b032f260ef2f05f929d23a49 | 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | local\-file | 2026\-11\-18T05:46:40\.335Z | 0 full elapsed days | [evidence/55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab\.txt](evidence/55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 953760d26f28ed48837a9a33bc9509213bf99d70a5ad21511b4bbf66077a966e | 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | local\-file | 2026\-11\-18T05:46:40\.336Z | 0 full elapsed days | [evidence/5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609\.txt](evidence/5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0f4f7d623acb23d8237a4741b5b022bbee4099b42ce2978c7fb14055e712323e | 6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3 | local\-file | 2026\-11\-18T05:46:40\.338Z | 0 full elapsed days | [evidence/6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3\.txt](evidence/6380dc52202d706933bf1cb94c295aabfab7f66513d4000c04c703360117ddc3.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e7882311974b6a2e5725b2c0b28a3ab6dfbe90d6544724bee7bf988900a3084e | 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | local\-file | 2026\-11\-18T05:46:40\.339Z | 0 full elapsed days | [evidence/63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53\.txt](evidence/63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 625413a964c3bebf46a19d99f514a5bfb405dce24d0fe5bd4eb81332d26afe21 | 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | local\-file | 2026\-11\-18T05:46:40\.341Z | 0 full elapsed days | [evidence/653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2\.txt](evidence/653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1d87606784cc3b8096014a142d7b10993b48359997b925bdb6aa352691427f4c | 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | local\-file | 2026\-11\-18T05:46:40\.343Z | 0 full elapsed days | [evidence/69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca\.txt](evidence/69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1502530e792a9d47641980468d5a334ab40f19f63c20492bb445e2f9bd8cf928 | 710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b | local\-file | 2026\-11\-18T05:46:40\.344Z | 0 full elapsed days | [evidence/710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b\.txt](evidence/710d9b250a642c03d4344b2027f92473d5af1839253f9b4739178aaaa3b6396b.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5f62274f4daedf5104eba6add8de3909fc131fc75c17147cea9ed70fdf58d7a4 | 788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098 | local\-file | 2026\-11\-18T05:46:40\.345Z | 0 full elapsed days | [evidence/788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098\.txt](evidence/788ea52e53d05086fbe2e17212a74f774bd7dbccd1ed5c03d8c2abcddd115098.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 56c7982606b64a8afca1c4396f91ac25151e2014914dcfdcef4968d6cf3eca36 | d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | local\-file | 2026\-11\-18T05:46:40\.347Z | 0 full elapsed days | [evidence/d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26\.txt](evidence/d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1\-http\-response | 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/1\-http\-response\.txt](evidence/1-http-response.txt) | 7cd85494eb375cc958155aca095fd0bae01e24f777c4ce4059e2edb82324618c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1\-publisher\-intent | 63bfa951c01269652938b1d2cdc851770ef91ecd97fa764e945dabde0be04d53 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/1\-publisher\-intent\.txt](evidence/1-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3\-schema\-extraction | d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/3\-schema\-extraction\.txt](evidence/3-schema-extraction.txt) | 0c522356b25041d496d85210dae7c21b789759cc375e8c170bfa026ccf25c81d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3\-claim\-sources | d397ccbc77bbca373ca457c37e53ef928626e6105ff73e40624522de5be36e26 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/3\-claim\-sources\.txt](evidence/3-claim-sources.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5\-claim\-sources | 69e7f390b03c3f18efa35d5998523da3d3fb8b5f565af37a80c7c130470243ca | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/5\-claim\-sources\.txt](evidence/5-claim-sources.txt) | 2af2411c2c3cfa27fc949c553e7fdf34b4268519a65ed45aedcb56db3539d9db | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7\-claim\-sources | 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/7\-claim\-sources\.txt](evidence/7-claim-sources.txt) | 7148637143c17a923c83788e641a724c8f19a65bf61ef2cc1df2a894b4ac510a | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7\-audience\-context | 55fc35d6fc9684e2fa4925a765f14e6498746c35cbc88540400a43f8a9e427ab | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/7\-audience\-context\.txt](evidence/7-audience-context.txt) | 58e51d0700fe2112fa585b218c15b7b68b099d280cdcfa18e478501a33eb7c74 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8\-claim\-sources | 653ea0ced1f12cf6ba20ad71e2eac423f6309b765fedc462d3ed2376edea84b2 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/8\-claim\-sources\.txt](evidence/8-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 10\-claim\-sources | 5b3c1522db99dad1eb61001089630d7ebe18660c9429a247191576c18af48609 | local\-file | 2026\-11\-18T05:48:59\.692Z | 0 full elapsed days | [evidence/10\-claim\-sources\.txt](evidence/10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
