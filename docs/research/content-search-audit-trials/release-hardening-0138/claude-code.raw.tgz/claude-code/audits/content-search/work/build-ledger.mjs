import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const [root, out] = process.argv.slice(2);
const h = (b) => createHash("sha256").update(b).digest("hex");
const rep = readFileSync(`${root}/report.md`);
const quotes = [];
rep.toString("utf8").split("\n").forEach((line, i) => {
  const m = line.match(/^- (\d\d-[a-z-]+\.md):(\d+)(?:-(\d+))? · `(.+)`$/);
  if (!m) return;
  quotes.push({ quoteId: `q${quotes.length + 1}`, source: `targets/${m[1]}`, sourceLabel: m[1], sourceHash: h(readFileSync(`${root}/targets/${m[1]}`)), startLine: +m[2], endLine: +(m[3] ?? m[2]), reportStartLine: i + 1, reportEndLine: i + 1, normalization: "exact", quote: m[4] });
});
writeFileSync(out, JSON.stringify({ root, report: "report.md", reportHash: h(rep), quotes }, null, 2));
console.log(quotes.length);
