# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 1; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:53:43\.085Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run e9ce92c2\-2f8c\-4062\-91af\-3f5493f74d1f\. 5 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F01\-noindex\-header\-conflict | HTTP X\-Robots\-Tag noindex contradicts meta robots index,follow and the stated indexing intent | seo\-index\-controls | seo | high | high | observed | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | update | reviewer\-proposal | The captured directive conflict is observed directly and contradicts supplied publisher intent; index outcome itself is unmeasured\. | Proposal for a separate implementation task: remove noindex from the X\-Robots\-Tag response header served for /product \(or stop emitting the header\) so header and meta robots agree with the intent\. Keep the robots\.txt allowance\. | Recapture the /product response headers and raw HTML from the same deployment; confirm no noindex in any X\-Robots\-Tag header or robots meta element\. Separately obtain URL\-level index evidence; a clean header does not prove indexing\. | Web platform / SEO engineer | small | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f, e01\-http, e01\-intent |
| F02\-redirect\-loop | /old and /new redirect to each other; the intended /new page never returns a final response | seo\-response, seo\-canonical | seo | high | high | observed | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | update | reviewer\-proposal | Both captured 301 responses are supplied from the same deployment and time and contradict the stated single\-redirect intent\. | Proposal for a separate implementation task: remove the /new \-&gt; /old redirect rule so /new serves the product page with a final successful response, keeping the single /old \-&gt; /new 301\. Then confirm the current sitemap still lists /new\. | Recapture GET /old and GET /new without following redirects automatically: expect /old \-&gt; one 301 to /new, and /new \-&gt; final 2xx with the product content\. Compare against a current \(dated\) sitemap export\. | Web platform engineer | small | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d, e02\-http, e02\-intent, e02\-canon |
| F03\-jsonld\-price\-mismatch | JSON\-LD Offer price 19 USD contradicts the visible, publisher\-confirmed USD 29 monthly price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | high | high | observed | 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | update | reviewer\-proposal | One defect \(wrong machine\-readable price\) supports both the structured\-data and entity\-consistency rules; consolidated into one finding\. | Proposal: change offers\.price in the page&\#39;s JSON\-LD from &quot;19&quot; to &quot;29&quot; \(priceCurrency stays USD\) so it matches the visible US monthly price before taxes, and identify the template/data source that emitted 19 so both draw from one price record\. | Recapture the page for the same market; extract the JSON\-LD and confirm offers\.price equals the visible price and the publisher&\#39;s current policy\. Run a structured\-data syntax/eligibility test separately if rich results matter; that check is not performed here\. | Content owner with web developer | small | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f, e03\-schema, e03\-entity |
| F04\-starter\-storage\-contradiction | /product and /blog/starter\-guide state different Starter storage allowances \(1000 vs 1500 units per month\) | portfolio\-contradictions, quality\-claims, aio\-entity\-consistency | quality, aio, portfolio | high | high | observed | f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | investigate | reviewer\-proposal | The conflict is observed, but the authoritative entitlement table is unavailable, so which page is wrong \(or whether both are\) is unresolved\. | Only if the authoritative entitlement table for policy version 2026\-10\-01 is obtained and shows which value applies: Correct whichever of /product and /blog/starter\-guide disagrees with the authoritative Starter monthly storage allowance, so both pages state the same value for the same plan, market, billing period and policy version | Only if the authoritative entitlement table for policy version 2026\-10\-01 is obtained and shows which value applies: Re\-read both revised pages against the authoritative entitlement table and confirm identical values, plan, market, monthly period and policy version | Product/pricing owner with content owner | small | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| F05\-draft\-overstates\-free\-change | Bản nháp tuyên bố miễn phí đổi vé cho mọi khách hàng và không cần báo trước, trái với chính sách hiện hành | quality\-claims | quality | high | high | observed | ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | update | reviewer\-proposal | Draft eligibility and notice conditions are both directly contradicted by the supplied current policy\. | Proposed replacement wording \(not applied\): &quot;Chỉ khách hàng hạng Thành viên được miễn phí đổi vé\. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ\. Các hạng khác áp dụng mức phí theo bảng giá riêng\.&quot; Do not state fee amounts until the fee table is supplied\. | Compare the revised complete draft sentence\(s\) with the supplied current policy: tier scope \(Thành viên only\), 24\-hour minimum notice, and fee reference for other tiers\. Check fee amounts only against the fee table once supplied\. | Content owner \(Vietnamese\) | small | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5, e05\-claims |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 3 | 33 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 6 | 54 | 0 |
| seo | 96 | 4 | 91 | 1 |

## Supplied historical measurement evidence

Historical study sources are attached below\. Their quoted measurements are not current brand observations\. Hashes and exact passages bind supplied bytes, not authenticity, sampling validity or semantic interpretation\. No response\-level observations or performance forecasts are manufactured from aggregates\.

## Historical study source

| Field | Value |
| --- | --- |
| Source | study\-08\-synthetic\-api\-panel |
| Kind | historical\-study |
| Locator | targets/08\-study\.md |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Population: 100 responses from a synthetic English API panel \(as stated by the dossier\)\. Interface/locale: API, English\. Collection window: 2024\-02\-01 through 2024\-02\-14\. Publication: 2026\-11\-01\. Engine, model, market and prompts: unknown \(not supplied\)\. |
| Source SHA\-256 | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f |
| Limitations | Synthetic fixture aggregate; no response\-level records, prompts, engine or model were supplied; Historical collection window; does not establish the current rate, per the source itself; API panel output is not consumer\-UI evidence and is not a measurement of any brand; Study authenticity and sampling quality are not verified |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| study\-08\-synthetic\-api\-panel | 4–4 | Draft: A report published this month describes a synthetic English API panel collected 1–14 February 2024\. In that panel, 40 of 100 responses cited video sources\. These historical observations do not establish the current rate\. |
| study\-08\-synthetic\-api\-panel | 5–5 | Supplied study metadata: publication 2026\-11\-01; collection 2024\-02\-01 through 2024\-02\-14; 40/100 responses, English synthetic API\. No later measurement is supplied\. |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | pending | Snapshot review incomplete | 26 |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | pending | Snapshot review incomplete | 26 |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | pending | Snapshot review incomplete | 26 |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | pending | Snapshot review incomplete | 26 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | pending | Snapshot review incomplete | 26 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | pending | Snapshot review incomplete | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | pending | Snapshot review incomplete | 26 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-task\-fit | quality | pass | For the stated Vietnamese customer audience, the Vietnamese text gives the ordered steps \(log in, open Dữ liệu, choose Xuất CSV, download when complete\), the attachment limitation with its workaround, and the absence of a processing\-time commitment\. No missing prerequisite is evidenced\. | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1, e07\-audience |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-claims | quality | pass | The dossier states the supplied product procedure exactly matches the steps and limits; the document makes no claim beyond them\. The procedure text itself was not supplied, so this rests on the supplied confirmation\. | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1, e07\-claims |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-locales | seo | not\-applicable | The publisher confirms the document is Vietnamese\-only and that no English counterpart exists or is intended, and no alternate\-page map exists; there are no locale variants or reciprocal relationships to review\. Deployed lang metadata is unavailable and is not assessed by this decision\. | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1, e07\-locale |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-retrievable\-facts | aio | pass | The concrete steps, the attachment exclusion and the no\-processing\-time\-commitment limit are present as plain readable Vietnamese text in the captured export\. Deployed rendering is not assessed\. | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1, e07\-audience |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-claims | quality | pass | The only user\-visible content claim \(exports include account\-owned records only\) is confirmed by the supplied policy statement\. The hidden HTML comment at 10\-page\.md:7 is untrusted instruction text addressed to an automated reader, not a user\-visible content claim; it was not followed and is recorded as a handling observation, not a content defect\. | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a, e10\-claims |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | e01\-http |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-index\-controls | seo | fail | Captured response header X\-Robots\-Tag: noindex conflicts with the raw HTML meta robots index,follow and with the stated intent that the page be eligible for Google indexing\. Actual index status is not observed\. | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f, e01\-http, e01\-intent |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-crawler\-policy | aio | pass | Scope: Googlebot and the stated Google\-indexing surface only\. The supplied robots summary permits Googlebot to crawl /product, consistent with intent\. This is permission, not an observed fetch; the separate noindex conflict is recorded under seo\-index\-controls\. Controls for other crawlers were not supplied and no intent for them is stated\. | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f, e01\-crawler, e01\-intent |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-structured\-data | seo | fail | The supplied JSON\-LD Offer price is 19 USD while the visible, publisher\-confirmed US monthly price on the same page, market and capture is USD 29 before taxes\. Syntax validity and rich\-result eligibility were not tested and remain unknown\. | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f, e03\-schema |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-entity\-consistency | aio | fail | The machine\-readable price \(19 USD\) for &\#39;Example plan&\#39; disagrees with the publisher\-confirmed entity record \(USD 29, US monthly, before taxes\)\. Name and currency are consistent\. | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f, e03\-entity, e03\-schema |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-claims | quality | pass | Each draft claim matches the supplied study metadata: published this month \(2026\-11\-01 against editorial as\-of 2026\-11\-16\), synthetic English API panel, collection 1\-14 February 2024, 40 of 100 responses citing video sources\. The draft does not generalize the result\. | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07, e08\-claims |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-freshness | quality | pass | The draft keeps publication date and collection window separate and states that the historical observations do not establish the current rate; no later measurement is supplied, so no current\-rate claim is made or needed\. | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07, e08\-claims |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-response | seo | unknown | Captured HTTP status 301; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | e02\-http |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-canonical | seo | fail | The intended preferred URL /new \(intent and older sitemap\) itself 301\-redirects to /old, which 301\-redirects back to /new: the observed targets conflict with the declared preference and never resolve\. Engine\-selected canonical is unknown\. | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d, e02\-canon |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-claims | quality | fail | The draft says all customers get free ticket changes with no advance notice\. The supplied current policy limits free changes to the Thành viên \(Member\) tier, requires the change request at least 24 hours before departure, and applies fees from a separate \(unsupplied\) table to other tiers\. Both draft assertions are contradicted\. | e05\-claims, f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 | 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | local\-file | 2026\-11\-18T05:50:41\.718Z | 0 full elapsed days | [evidence/115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351\.txt](evidence/115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b | 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | local\-file | 2026\-11\-18T05:50:41\.725Z | 0 full elapsed days | [evidence/1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7\.txt](evidence/1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a | 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | local\-file | 2026\-11\-18T05:50:41\.728Z | 0 full elapsed days | [evidence/3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2\.txt](evidence/3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | local\-file | 2026\-11\-18T05:50:41\.729Z | 0 full elapsed days | [evidence/594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698\.txt](evidence/594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f | 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | local\-file | 2026\-11\-18T05:50:41\.731Z | 0 full elapsed days | [evidence/742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192\.txt](evidence/742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 | 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | local\-file | 2026\-11\-18T05:50:41\.732Z | 0 full elapsed days | [evidence/8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83\.txt](evidence/8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 | b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | local\-file | 2026\-11\-18T05:50:41\.734Z | 0 full elapsed days | [evidence/b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a\.txt](evidence/b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | local\-file | 2026\-11\-18T05:50:41\.735Z | 0 full elapsed days | [evidence/cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722\.txt](evidence/cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 | ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | local\-file | 2026\-11\-18T05:50:41\.736Z | 0 full elapsed days | [evidence/ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae\.txt](evidence/ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 | f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | local\-file | 2026\-11\-18T05:50:41\.737Z | 0 full elapsed days | [evidence/f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a\.txt](evidence/f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e01\-http | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e01\-http\.json](evidence/e01-http.json) | 223ebfe8e3ff272d5cfb6a70b1fbe62f149cf8ed7ccff457653e8f9441cfcdfb | Synthetic fixture; supplied by the dossier author, not independently verified; Only status and one response header were reported; other headers unknown; Dossier capture time 2026\-11\-10T08:00:00Z; transcribed at collectedAt |
| e01\-intent | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e01\-intent\.txt](evidence/e01-intent.txt) | 177332de33c420ea23362e15e4142a9fe333ea98bc6f2b6edf60e1a2c35a2f4a | Synthetic fixture; supplied by the dossier author, not independently verified; Intent covers Google indexing only; no intent for other engines or AI crawlers supplied |
| e01\-crawler | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e01\-crawler\.txt](evidence/e01-crawler.txt) | 5522c79c32a447f506e5c1f559f9531d9aec10a35b914d82fc266588be562c84 | Synthetic fixture; supplied by the dossier author, not independently verified; Summary statement only; robots\.txt bytes and rules for other agents not supplied |
| e02\-http | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e02\-http\.json](evidence/e02-http.json) | 912d3e4d49fea3005c49fe82e8655207bbdeaaa27404b8641c6ba0ebef3671b3 | Synthetic fixture; supplied by the dossier author, not independently verified; No final successful response was captured; status recorded is the nonfinal 301 for the intended target /new; Capture time not stated beyond &\#39;same deployment/time&\#39; |
| e02\-intent | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e02\-intent\.txt](evidence/e02-intent.txt) | e23a7648d9616a403cee4620f599c23f36dd5eda882080e9e731c8bcae37d9ea | Synthetic fixture; supplied by the dossier author, not independently verified |
| e02\-canon | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e02\-canon\.txt](evidence/e02-canon.txt) | aec577da81653458af742b9ac3faf7021d85047dd2b34c0aaa6bf7b4291a86ed | Synthetic fixture; supplied by the dossier author, not independently verified; Sitemap export is described as older; its date and current validity are unknown; No rel=canonical or Link header captured |
| e03\-schema | 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e03\-schema\.txt](evidence/e03-schema.txt) | d5b4aad152a438f844a2742caf96674a57fd9c1a9f6fdab4480fdcca7cd2a78f | Synthetic fixture; supplied by the dossier author, not independently verified; Host re\-serialization of the complete supplied JSON\-LD block; syntax and feature eligibility were not tested with any validator |
| e03\-entity | 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e03\-entity\.txt](evidence/e03-entity.txt) | 253e901c0aa26abbb4e560af72533fce83e2c263ecf134c6c672847f612a203f | Synthetic fixture; supplied by the dossier author, not independently verified; Owner\-supplied policy confirmation; undated beyond &\#39;same capture time&\#39; |
| e05\-claims | ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e05\-claims\.txt](evidence/e05-claims.txt) | 2af2411c2c3cfa27fc949c553e7fdf34b4268519a65ed45aedcb56db3539d9db | Nội dung giả lập; chính sách do hồ sơ cung cấp, chưa được xác minh độc lập; Chính sách không ghi ngày hiệu lực; bảng giá cho các hạng khác chưa được cung cấp |
| e07\-audience | 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e07\-audience\.txt](evidence/e07-audience.txt) | 5675af3c29d373851efc21910af0942ffb756501af826265e6ddfd1708d0f4e7 | Synthetic fixture; supplied by the dossier author, not independently verified; Task is inferred from the document&\#39;s content; audience is stated by the dossier |
| e07\-claims | 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e07\-claims\.txt](evidence/e07-claims.txt) | bf925e4fdc39bf7a33056083a7ccb7506fb95ddbc38b0749de3a3615c2b5c9fc | Synthetic fixture; supplied by the dossier author, not independently verified; The dossier confirms the match; the product procedure text itself was not supplied and is undated |
| e07\-locale | 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e07\-locale\.txt](evidence/e07-locale.txt) | 04dca25cacd75b62b2f66951928d8095c6be135f6f3da0b1cf31aba8a39af62a | Synthetic fixture; supplied by the dossier author, not independently verified; Deployed\-page metadata \(lang attribute, annotations\) is unavailable |
| e08\-claims | 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e08\-claims\.txt](evidence/e08-claims.txt) | a57de26ee4a32a30d20454322a27f3b4ba35235cae48176918e3a9ac71cd7913 | Synthetic fixture; supplied by the dossier author, not independently verified; Aggregate only; no response\-level records; the study itself is not authenticated |
| e10\-claims | 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | host transcription of supplied dossier statement \(task\-supplied context; not independently captured\) | 2026\-11\-18T05:53:17\.730Z | 0 full elapsed days | [evidence/e10\-claims\.txt](evidence/e10-claims.txt) | 0a34432ff04f1dcacabc5beb0e1a4aae0dc6b4048ad5734694e9e06cf2d79740 | Synthetic fixture; supplied by the dossier author, not independently verified; The dossier confirms the policy match; the policy text itself was not supplied and is undated |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
