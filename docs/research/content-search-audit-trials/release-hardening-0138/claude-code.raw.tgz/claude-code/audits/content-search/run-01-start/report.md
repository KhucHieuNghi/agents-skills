# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:50:41\.782Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run c3532a84\-9f28\-4b5e\-8db2\-89317395079a\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |
| f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7faf3d0d121d09853e369c471f77aa2b6462ae0f98ca85b772330e757948e3d1 | 115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351 | local\-file | 2026\-11\-18T05:50:41\.718Z | 0 full elapsed days | [evidence/115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351\.txt](evidence/115e6fcc0895764d52ca5c07f31aafdb4ccb38e4b60f58c742d218e2b550d351.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| af5e498d13975d7c8c6f79cf573785739fbf27053651bfa70de8fe05d7bc5f9b | 1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7 | local\-file | 2026\-11\-18T05:50:41\.725Z | 0 full elapsed days | [evidence/1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7\.txt](evidence/1b29fa3070f7df293b1b2ca0e1571d04386338cc02e13941cc26593adc4a0fa7.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b216c7166f4b96df5d9a35f636edf1d34a93da9cf61f4af700b8ec9321551f8a | 3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2 | local\-file | 2026\-11\-18T05:50:41\.728Z | 0 full elapsed days | [evidence/3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2\.txt](evidence/3933323fd78aa3d026375eee748f11eec76deac84b5f578846eb70873831f6f2.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ae5c0797d4ebf5b1a5cdb5bcaebfda518cfad12963a150e5dd6226a426ed1e0f | 594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698 | local\-file | 2026\-11\-18T05:50:41\.729Z | 0 full elapsed days | [evidence/594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698\.txt](evidence/594b3e0142ac847d46ab5546a1853dd97c4887f0c9dfa68468d999a113a0e698.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 18fcf03297e01d6e3cb9c3ebdb98135f9d78531460b56f65ab4464849b71fb6f | 742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192 | local\-file | 2026\-11\-18T05:50:41\.731Z | 0 full elapsed days | [evidence/742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192\.txt](evidence/742f3d1ffb549c55e1baa6efe7a62f5d4e9685aae8aa6fb1d0caea88a3856192.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 14569ca2e797eabce2bb9c8756c6668b92803f4f8a4d68217b756e5b66ac5b07 | 8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83 | local\-file | 2026\-11\-18T05:50:41\.732Z | 0 full elapsed days | [evidence/8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83\.txt](evidence/8dca28e2ff563d7302c3cccb108e7b6cbf3460e6e714b641aa061247ae139b83.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d0f7c928924ba50d504f91f9eca267a76becc3bd4653213d04282b7e5e80a623 | b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a | local\-file | 2026\-11\-18T05:50:41\.734Z | 0 full elapsed days | [evidence/b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a\.txt](evidence/b1fe4f54856437b7c430acdf534b2cbbb92a588350212bc93edb4c007ffac42a.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5bd0c7d2685328f2da0b80c92e15b5a3c8c3e7e1a20ec05079f1b270c3917d2d | cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722 | local\-file | 2026\-11\-18T05:50:41\.735Z | 0 full elapsed days | [evidence/cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722\.txt](evidence/cf89a48b97cfe6e8fc3dc9edaad4bb1db7706cf79d5ec2fd533f1aa63f32a722.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f94818f556b08cc6ff9077fee8006e456dfab0b106ef8b7833e744dc2125b4c5 | ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae | local\-file | 2026\-11\-18T05:50:41\.736Z | 0 full elapsed days | [evidence/ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae\.txt](evidence/ee2e8a3994831e2934ac2d4bea6b04ad360830ab1de35ef05b73d9a84e8602ae.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0fa6001859e9566f79aa29464cb8293aa39378283cb0f2fd4fc1a66b9ee13865 | f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a | local\-file | 2026\-11\-18T05:50:41\.737Z | 0 full elapsed days | [evidence/f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a\.txt](evidence/f1644819ec5c3968eb92130e9c1d3edf7046da5b2301c39197c8f27018a0a56a.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
