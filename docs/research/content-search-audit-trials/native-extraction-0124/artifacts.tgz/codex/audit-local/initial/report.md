# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T04:39:01\.246Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run b292c51b\-3329\-4b74\-9804\-38e43c6932b8\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 2 |
| Pending | 1 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 0 | 15 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 7d0448ca7cabd9f66bb05984369b3350eaeb1374c7f304f731f0cf92c14ee7cc | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 8c0e142e703ce17afa27d124506db34ece5d60adc3b507b2aac860d93e4eaa94 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 37e15b03e3ba0a24e5086786bee541768935a446cce91469204787d60d3979ec | 5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e | local\-file | 2026\-11\-16T04:39:01\.234Z | 0 full elapsed days | [evidence/5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e\.txt](evidence/5ac78d87d0cff2bb779717b2c7f5ab335e72b37ee75faef6487c8882e906435e.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
