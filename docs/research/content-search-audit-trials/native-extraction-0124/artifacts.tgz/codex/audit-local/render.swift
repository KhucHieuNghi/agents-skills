import Foundation
import WebKit
import AppKit
let configuration = WKWebViewConfiguration()
configuration.websiteDataStore = .nonPersistent()
let browser = WKWebView(frame: NSRect(x: 0, y: 0, width: 900, height: 700), configuration: configuration)
let file = URL(fileURLWithPath: CommandLine.arguments[1]).standardizedFileURL
browser.loadFileURL(file, allowingReadAccessTo: file)
let timeout = Date().addingTimeInterval(10)
let timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { timer in
    if Date() > timeout {
        FileHandle.standardError.write(Data("Timed out waiting for owner-declared readiness signal\n".utf8))
        exit(2)
    }
    browser.evaluateJavaScript("document.documentElement.dataset.auditReady === \"true\" ? document.documentElement.outerHTML : null") { result, _ in
        if let html = result as? String {
            print(html)
            exit(0)
        }
    }
}
RunLoop.main.run()
