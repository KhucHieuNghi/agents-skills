import Foundation
import PDFKit
struct Page: Codable { let page: Int; let text: String }
for path in CommandLine.arguments.dropFirst() {
    guard let document = PDFDocument(url: URL(fileURLWithPath: path)) else { fatalError(path) }
    let pages = (0..<document.pageCount).map { Page(page: $0 + 1, text: document.page(at: $0)?.string ?? "") }
    let output = ["source": path, "pageCount": document.pageCount, "pages": try JSONSerialization.jsonObject(with: JSONEncoder().encode(pages))] as [String : Any]
    print(String(decoding: try JSONSerialization.data(withJSONObject: output), as: UTF8.self))
}
