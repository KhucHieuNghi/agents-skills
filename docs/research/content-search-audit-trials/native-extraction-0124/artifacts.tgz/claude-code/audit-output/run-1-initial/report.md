# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T04:38:45\.009Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 90c382ba\-80ec\-4ef5\-bcfa\-92f952be7e9f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 2 |
| Pending | 1 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 0 | 15 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 87829541198702141a5bee4ebc572f399affbedaef413a7fe064bc6da3f2e0dd | ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a | local\-file | 2026\-11\-16T04:38:44\.993Z | 0 full elapsed days | [evidence/ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a\.txt](evidence/ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
