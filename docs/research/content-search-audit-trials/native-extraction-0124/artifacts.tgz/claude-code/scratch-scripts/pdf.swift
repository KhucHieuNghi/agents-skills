import PDFKit
import Foundation
let u = URL(fileURLWithPath: CommandLine.arguments[1])
guard let d = PDFDocument(url: u) else { print("{\"error\":\"cannot open\"}"); exit(1) }
var pages: [String] = []
for i in 0..<d.pageCount { pages.append(d.page(at: i)?.string ?? "") }
let o: [String: Any] = ["pageCount": d.pageCount, "pages": pages]
let data = try! JSONSerialization.data(withJSONObject: o, options: [.sortedKeys])
print(String(data: data, encoding: .utf8)!)
