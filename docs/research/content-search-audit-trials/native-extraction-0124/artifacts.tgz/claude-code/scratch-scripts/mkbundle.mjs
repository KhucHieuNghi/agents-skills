import fs from 'node:fs'; import crypto from 'node:crypto';
const P='/private/var/folders/qz/snbf5txj0tjbkngsfl9gv6qh0000gn/T/nks-native-extraction-0124-h0frshnp/claude-code';
const W=P+'/audit-output/work';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const now=()=>new Date().toISOString();
const HTML='ba62c122f1bae60f9e464281f2e90787e7852cad9f80048b78a19b02357ee48a';
const DOC='e6c9fc18c87460aafbeb462dc6d81bcd824323b991c7302d331dad7499af3711';
const IMG='66de70959b5e51f591f2ab1c27cd0f9974bfae55b112c3832538125585a7ea5f';
const HTMLC=fs.readFileSync(P+'/audit-output/run-1-initial/evidence.jsonl','utf8').split(String.fromCharCode(10)).filter(Boolean).map(l=>JSON.parse(l)).find(e=>e.itemId===HTML&&e.kind==='content').evidenceId;
const evidence=[], artifacts={};
function add(id,itemId,kind,method,locator,text,limitations,src=[]){
  const artifact=`evidence/${id}.txt`; artifacts[artifact]=text;
  evidence.push({evidenceId:id,itemId,kind,method,collectedAt:now(),locator,snapshotHash:sha(Buffer.from(text,'utf8')),redaction:'none; authorized fixture content retained locally',limitations,sourceEvidenceIds:src,artifact,encoding:'utf8',value:text});
}
const pdf=(n)=>JSON.parse(fs.readFileSync(`${W}/${n}.pdfkit.json`,'utf8'));
const ocr=JSON.parse(fs.readFileSync(`${W}/image-only.ocr.json`,'utf8'));
const dom=fs.readFileSync(W+'/render.dom.html','utf8');
const ownerCtx='Owner-supplied task context (user statement, this audit request): Approved renewal task requires opening Billing and selecting Disable renewal. Approved export policy: current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.';
const lim=['Owner-supplied policy is an approved comparison basis, not independent verification of platform behavior'];
// HTML
add('ev-html-rendered-dom',HTML,'rendered-dom','chrome-headless-dump-dom',`file://${P}/targets/render.html`,dom,['Google Chrome headless, fresh isolated user-data-dir, virtual-time-budget 3000ms; dump taken with data-audit-ready="true" (owner-confirmed render-complete signal)','Single capture; no screenshot; local file, not public URL']);
add('ev-html-claim-sources',HTML,'claim-sources','user-task-statement','audit request text (owner context)',ownerCtx,lim);
// docs: recovery
function recov(prefix,itemId,file,pages,extractor,method,extraLim){
  const bytes=fs.readFileSync(`${P}/targets/${file}`);
  const text=pages.join('\f');
  const manifest=JSON.stringify({schemaVersion:1,sourceSha256:sha(bytes),sourceByteLength:bytes.length,extractor,pageCount:pages.length,pages:pages.map((t,i)=>({page:i+1,text:t})),coverage:'complete',limitations:extraLim});
  add(`${prefix}-manifest`,itemId,'extraction-provenance',method,`${P}/targets/${file}`,manifest,extraLim);
  const me=evidence[evidence.length-1]; me.encoding='json'; me.value=JSON.parse(manifest);
  add(`${prefix}-content`,itemId,'content',method,`${P}/targets/${file}`,text,extraLim,[`${prefix}-manifest`]);
  add(`${prefix}-text`,itemId,'extracted-text',method,`${P}/targets/${file}`,text,extraLim,[`${prefix}-content`]);
  return {itemId,manifestEvidenceId:`${prefix}-manifest`,contentEvidenceId:`${prefix}-content`,textEvidenceId:`${prefix}-text`};
}
const ver=process.env.MACOS_VER;
const r1=recov('ev-doc',DOC,'document.pdf',pdf('document').pages,{name:'macOS PDFKit PDFPage.string',version:'macOS '+ver},'pdfkit-text-layer',['Text-layer extraction; reading order and visual layout not verified','Per-page text taken from PDFPage.string']);
const r2=recov('ev-img',IMG,'image-only.pdf',ocr.pages,{name:'macOS Vision VNRecognizeTextRequest (accurate; en-US, vi-VT) over PDFKit-rendered page',version:'macOS '+ver},'vision-ocr',['OCR output, not a text layer: PDFKit text-layer extraction returned an empty string for page 1','OCR accuracy and reading order not independently verified','Page image content not otherwise inspected visually by the reviewer']);
const reviewer='Claude Code agent (Sonnet 5.5) acting for the audit owner';
add('ev-doc-claims',DOC,'claim-sources','user-task-statement','audit request text (owner context)',ownerCtx,lim);
const reviews=[
 {itemId:HTML,ruleId:'seo-rendering',status:'fail',reason:'Raw source text of main#task is "Open Billing. Select Disable renewal." but after the inline script runs in Chrome (data-audit-ready="true") the rendered text is "Open Billing." The script removes the "Select Disable renewal." step, so rendered output omits part of the approved task.',evidenceIds:['ev-html-rendered-dom',HTMLC],reviewer,reviewedAt:now()},
 {itemId:HTML,ruleId:'quality-claims',status:'fail',reason:'The owner-approved renewal task requires both opening Billing and selecting Disable renewal. The rendered page, the state users and render-capable crawlers see after readiness, instructs only "Open Billing." and drops the second required step; it is inconsistent with the approved task.',evidenceIds:['ev-html-claim-sources',HTMLC],reviewer,reviewedAt:now()},
 {itemId:DOC,ruleId:'quality-claims',status:'pass',reason:'Page 1 states a maximum of 5000 records per export for current VN plans; page 2 (Vietnamese) states a 5000-record maximum and no extra payment. Both match the owner-approved policy. The EN page not mentioning "no extra charge" is an accepted emphasis difference per the owner statement. Owner policy is attributed, not independently verified.',evidenceIds:['ev-doc-content','ev-doc-claims'],reviewer,reviewedAt:now()},
];

const b={reviews,evidence,artifacts,collectionRecoveries:[r1,r2].map(r=>({...r,reviewer,reviewedAt:now(),reason:r.itemId===DOC?'PDFKit text layer extracted for both pages (EN p1, VI p2); reading order unverified.':'PDFKit text layer is empty (1 page); OCR via Vision recovered one line of text. Empty text layer was not treated as empty content; OCR accuracy unverified.'}))};
fs.writeFileSync(P+'/audit-output/work/review-bundle.json',JSON.stringify(b,null,1));
console.log('written',evidence.length);
b.findings=[{findingId:'F-001',title:'Rendered render.html drops the approved "Select Disable renewal." step',affectedItemIds:[HTML],ruleIds:['seo-rendering','quality-claims'],dimensions:['seo','quality'],evidenceIds:['ev-html-rendered-dom','ev-html-claim-sources',HTMLC],classification:'observed',severity:'high',confidence:'high',
 remediation:'Make the rendered main#task text include both steps ("Open Billing. Select Disable renewal.") — remove the script that overwrites the text, or update it to preserve the second step. Proposal only; the fixture was not modified.',
 verification:'Reload in a fresh browser profile, wait for document.documentElement.dataset.auditReady === "true", and confirm main#task textContent contains "Select Disable renewal."',
 ownerRole:'Content/front-end owner',effort:'low',action:'update',actionReason:'Rendered text omits a step required by the owner-approved renewal task.'}];
fs.writeFileSync(P+'/audit-output/work/review-bundle.json',JSON.stringify(b,null,1));
