import PDFKit
import Vision
import AppKit
let d = PDFDocument(url: URL(fileURLWithPath: CommandLine.arguments[1]))!
var out: [String] = []
for i in 0..<d.pageCount {
  let p = d.page(at: i)!
  let b = p.bounds(for: .mediaBox)
  let img = p.thumbnail(of: NSSize(width: b.width*3, height: b.height*3), for: .mediaBox)
  guard let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else { out.append(""); continue }
  let r = VNRecognizeTextRequest(); r.recognitionLevel = .accurate; r.recognitionLanguages = ["en-US","vi-VT"]
  try? VNImageRequestHandler(cgImage: cg).perform([r])
  out.append((r.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n"))
}
print(String(data: try! JSONSerialization.data(withJSONObject: ["pages": out]), encoding: .utf8)!)
