from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from urllib.parse import urlparse
import json,re

p=Path(__file__).resolve().parent
part_name='parts/000001'
reviewer='Codex | NKSkills public static pilot'
owner='User-supplied pilot brief. NKSkills composes versioned skill workflows for Codex and Claude Code for English and Vietnamese audiences. Authorized evidence is same-origin public static navigation; AIO means AI search optimization. This establishes business framing and audience, with independent validation of release and host claims outside the supplied evidence.'
def now(): return datetime.now(timezone.utc).isoformat()
def digest(s): return sha256(s.encode()).hexdigest()
def read(f): return json.loads(f.read_text())
def rows(f): return [json.loads(l) for l in f.read_text().splitlines()]
def write(name,data):
    with (p/name).open('x') as f: json.dump(data,f,ensure_ascii=False,indent=2); f.write('\n')
def load(campaign,index):
    part=p/campaign/part_name
    idx=read(p/index/'index.json')
    collected=rows(part/'evidence.jsonl')
    content={r['itemId']:r for r in collected if r['kind']=='content'}
    keys={r['itemId']:urlparse(r['uri']).path for r in rows(part/'inventory.jsonl')}
    return part,idx,content,keys,collected
def scope(path):
    if path in ('/','/en/','/vi/'):
        return ('Discover products and host setup', 'Workflow model, three versioned product cards, build and digest overview, host setup and starter prompt, provenance, security sources and FAQ. The hero tally conflicts with the cards and catalog.')
    if 'catalog' in path:
        return ('Evaluate products and trace components', 'Three product cards, source revisions and license labels, six security entries within fifteen tracked upstreams, versioning policy, and host installation link for the audit candidate. The audit shortcut lands on Codex despite both hosts being listed.')
    if 'solutions' in path:
        return ('Evaluate codebase onboarding', 'Version 1.1.0 names three components, Quick mode output and source-evidence requirements, GitHub source setup, valid CodeGraph index, and limited behavior evaluation. Both host guides are linked.')
    if '/guides/' in path:
        host='Claude Code' if 'claude-code' in path else 'Codex'
        return ('Install and run in '+host, 'Prerequisites and source build, digest and target repository, '+host+' installation and invocation, separate Problem presentation evaluation and Content search audit installation, and human review. Archive distribution is qualified.')
    return ('Locate font attribution', 'Plain text identifies Fraunces, Source Sans 3 and IBM Plex Mono authors, OFL 1.1 labels and names of full notices. Adjacent filenames are plain prose without static HTML hyperlinks.')
def local():
    part,idx,content,keys,all_e=load('collection','collection-index')
    registry=read(p.parent/'.agents/skills/content-search-audit/rules/core.json')['rules']
    evidence=[]; artifacts={}; reviews=[]; findings=[]
    text=(p/'snapshot-reading.txt').read_text()
    segments={m.group(1):m.group(2) for m in re.finditer(r'^### (\w+) [^\n]+\n(.*?)(?=^### |\Z)',text,re.M|re.S)}
    bypath={v:k for k,v in keys.items()}
    stamp=now()
    def add(e,kind,value,locator,sources,limits):
        eid=e['itemId']+'-'+kind
        artifact='evidence/'+eid+'.txt'
        record=dict(e,evidenceId=eid,kind=kind,value=value,artifact=artifact,snapshotHash=digest(value),collectedAt=stamp,locator=locator,sourceEvidenceIds=sources,limitations=[limits])
        artifacts[artifact]=value
        evidence.append(record)
        return eid
    for item,path in keys.items():
        e=content[item]; src=e['evidenceId']; locator=e['locator']
        html=path!='/licenses/README.txt'
        home=path in ('/','/en/','/vi/')
        task,notes=scope(path)
        audience=add(e,'audience-context',owner+' Inferred task for this URL: '+task+'.','User pilot brief and '+locator,[src],'Task is inferred from page content; owner supplied audience is not query or demand data.')
        segment=segments[item]
        extracted='\n'.join(re.sub(r'\{href=[^}]*\}|^\[\d+ \w+\] ?', '', line).strip() for line in segment.splitlines() if not html or not re.match(r'^\d+ \w+ \{',line)).strip()
        add(e,'extracted-text',extracted,locator+' (source text derivation)',[src],'Inert local HTMLParser reads text and omits script, style, template and noscript bodies; plain text is preserved apart from surrounding whitespace. It does not establish rendered visibility.')
        locale_id=None
        if html:
            rel=path[3:] if path!='/' else '/'
            pair=['/en'+rel,'/vi'+rel]
            pair_e=[content[bypath[x]] for x in pair]
            canonical_lines=lambda key: '\n'.join(l for l in segments[key].splitlines() if re.match(r'^\d+ html |^\d+ link .*?(canonical|alternate)',l))
            locale_id=add(e,'locale-map','\n\n'.join(keys[x['itemId']]+'\n'+canonical_lines(x['itemId']) for x in pair_e),locator+' (source HTML head and paired locale snapshots)',list(dict.fromkeys([src]+[x['evidenceId'] for x in pair_e])),'Source annotations only. Does not verify displayed controls, locale detection, or engine selection.')
        for rule in registry:
            rid=rule['ruleId']
            if rid in ('seo-response','quality-readable-text'): continue
            status='unknown'; refs=[src]; reason=notes
            if rid=='seo-locales' and html:
                status='pass'; refs.append(locale_id)
                reason='Captured English and Vietnamese equivalents identify their own language, declare self-canonicals and reciprocal en/vi alternatives, and agree on the English x-default. The root request redirects to the English equivalent.' if path=='/' else 'Both snapshots use the expected html lang, self-canonical and reciprocal en/vi alternatives, with English x-default. Compared headings, purpose and material version labels in the paired main content.'
            elif rid=='seo-metadata' and html and not home:
                status='pass'; refs.append(audience)
                reason='The source title, description and primary heading describe the same page task and identify its subject and locale. '+notes
            elif rid=='seo-metadata':
                reason='Titles identify the host audience. Homepage descriptions summarize onboarding and Problem presentation while omitting the third displayed candidate; metadata intent is unconfirmed.' if home else 'The plain-text attribution notice has no HTML title, description or headings; its search presentation intent has not been supplied.'
            elif rid=='quality-task-fit':
                refs.append(audience)
                if home:
                    status='fail'
                    reason='The hero counts two Solution Skills and one evaluation candidate. The same captured page actually labels three Solution Skills, two as evaluation candidates. Readers comparing release options get inconsistent summaries.'
                    findings.append(dict(findingId='hero-release-tally-'+('root' if path=='/' else path.strip('/')),title='Homepage release tally conflicts with its three product cards'+(' (root redirect capture)' if path=='/' else ' ('+path+')'),affectedItemIds=[item],ruleIds=[rid],dimensions=['quality'],evidenceIds=refs,severity='medium',confidence='high',classification='observed',remediation='Generate the homepage tally from the same released catalog entries used for the cards, or remove the duplicate tally. Preserve the distinction between technical release and evaluation candidate.',verification='Compare the EN and VI hero tallies with their product cards and catalogs. Three entries are shown in this capture: one technical release and two evaluation candidates.',ownerRole='Website content maintainer',effort='Small'))
                else: reason=notes+' End-to-end task success and referenced external documents remain unverified.'
            elif rid=='aio-retrievable-facts':
                refs.append(audience)
                reason=notes+' These facts are present in source. Complete, accurate retrieval for the inferred task and any observed AI result remain unverified.'
            elif rid.startswith('geo-'):
                reason='No dated response observations or prompt cohort were supplied. The captured source cannot establish AI presence, cited URLs, answer accuracy or cohort validity.'
            elif rid in ('quality-claims','quality-freshness','aeo-answer-evidence'):
                reason=notes+' Release, package, license and host claims are publisher assertions; linked external artifacts and dated authoritative records were outside scope.'
            elif rid in ('aeo-question-coverage','aeo-answer-context'):
                reason=notes+' '+('The source FAQ answers host support, upstream updates, presentation readiness and prompt safeguards. ' if home else '')+'Customer queries and question-priority evidence were not supplied.'
            elif rid in ('seo-rendering','seo-structured-data','quality-accessible-media'):
                reason=('Source includes text and metadata; no inline JSON-LD was observed in the captured HTML. Runtime output, informative assets and feature eligibility were outside the capture.' if html else 'The captured plain-text notice has no HTML media or scripts. Any surrounding presentation or feature intent is outside the capture.')
            elif rid in ('seo-index-controls','aio-crawler-policy'):
                reason='Captured robots policy allowed this anonymous audit collector. Publisher intent and target-crawler or engine-level evidence were unavailable.'
                refs.extend(q['evidenceId'] for q in all_e if q['itemId']==item and q['kind'] in ('crawler-policy','http-response') and (rid=='seo-index-controls' or q['kind']=='crawler-policy'))
            elif rid in ('seo-internal-links','portfolio-journey-links'):
                reason=notes+' Static anchors were inspected. External destinations, rendered interaction and unseen portions of the navigation remain outside the evidence.'
            elif rid=='seo-canonical':
                if locale_id: refs.append(locale_id)
                reason='The page source and locale counterparts show the expected final HTML self-canonical. Publisher variant policy and engine-selected canonical are unavailable.' if html else 'Plain text has no HTML head; canonical target intent remains unconfirmed.'
            elif rid in ('aio-entity-consistency','portfolio-contradictions'):
                reason=notes+' The page corpus supports comparison of published versions and release status. Authoritative release records outside the corpus are unavailable.'
            elif rid.startswith('portfolio-'):
                reason=notes+' The paired pages serve the same task in different languages; the root is a redirect alias and the host guides support distinct installation targets. Demand and unseen routes remain unverified.'
            reviews.append(dict(itemId=item,ruleId=rid,status=status,reason=reason,evidenceIds=refs,reviewer=reviewer,reviewedAt=stamp))
    # One finding for the shared bilingual homepage defect, retaining evidence for all affected checks.
    first=findings[0]
    first.update(findingId='homepage-release-tally',title='Both homepage locales undercount Solution Skills and evaluation candidates',affectedItemIds=[x for f in findings for x in f['affectedItemIds']],evidenceIds=[x for f in findings for x in f['evidenceIds']])
    original_findings=read(part/'findings.json')
    write('part-review.json',dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],parts=[dict(path=part_name,sourceSnapshotHash=idx['partSnapshotHashes'][part_name],bundle=dict(reviews=reviews,evidence=evidence,artifacts=artifacts,findings=original_findings+[first]))]))
def global_review():
    part,idx,content,keys,_=load('reviewed','reviewed-index')
    refs=[dict(part=part_name,evidenceId=e['evidenceId']) for e in content.values()]
    stamp=now()
    context=[]
    def add(kind,value,locator,sources):
        eid='pilot-'+kind
        context.append(dict(evidenceId=eid,kind=kind,value=value,snapshotHash=digest(value),locator=locator,collectedAt=stamp,sourceReferences=sources))
        return eid
    matrix=add('inventory-map','\n'.join(path+' — '+scope(path)[0]+' — '+scope(path)[1] for path in sorted(keys.values())),'Reviewed campaign inventory and its 12 content captures',refs)
    aud=add('audience-context',owner,'User-provided pilot brief',[])
    ids=list(content)
    def review(rid,status,reason,context_ids):
        return dict(ruleId=rid,status=status,reason=reason,reviewer=reviewer,reviewedAt=stamp,itemIds=ids,evidenceReferences=refs,contextEvidenceIds=context_ids)
    reviews=[
        review('portfolio-duplication','pass','Across the declared 12 URLs, the root is a verified redirect alias and each EN/VI pair serves a named language. Shared guide steps are accompanied by host-specific targets and invocation syntax. Homepage, catalog, solution page and license notice serve distinct tasks. No actionable duplicate was established within this inventory.',[matrix]),
        review('portfolio-task-gaps','unknown','The task map covers release discovery, evaluation, installation for each host, and font attribution. The brief identifies EN and VI audiences; no observed audience questions or demand data were supplied to establish unmet tasks.',[matrix,aud]),
        review('portfolio-contradictions','unknown','The bilingual homepage release-tally inconsistency is persisted under local task fit. Both catalogs and all four guides show the same Content search audit candidate version. Authoritative release and policy records for remaining entity claims were unavailable.',[matrix]),
        review('portfolio-journey-links','unknown','Static paths connect home, catalog, onboarding and both host guides. Both the home and catalog audit shortcuts favor the Codex guide, whose target section exists. The parallel Claude Code section also exists. Rendered prompt controls, external handoffs and publisher intent for the audit shortcut remain unresolved.',[matrix,aud])
    ]
    write('global-review.json',dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],partSnapshotHashes=idx['partSnapshotHashes'],contextEvidence=context,reviews=reviews,findings=[]))
if __name__=='__main__':
    import sys
    {'local':local,'global':global_review}[sys.argv[1]]()
