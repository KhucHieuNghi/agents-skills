from html.parser import HTMLParser
from pathlib import Path
import json,sys

class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.hidden=[]
        self.lines=[]
        self.meta=[]
        self.buffer=[]
    def flush(self):
        text=' '.join(' '.join(self.buffer).split())
        if text:
            self.lines.append(text)
        self.buffer=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if self.hidden:
            return
        if tag in ('script','style','template','noscript'):
            self.hidden.append(tag)
            self.meta.append((self.getpos()[0],tag,a))
            return
        if tag in ('html','meta','link','img','svg','video','audio','iframe'):
            self.meta.append((self.getpos()[0],tag,a))
        if tag in blocks:
            self.flush()
            self.buffer.append(f'[{self.getpos()[0]} {tag}]')
        if tag=='a':
            self.buffer.append(f'{{href={a.get("href")}}}')
    def handle_endtag(self,tag):
        if self.hidden:
            if tag==self.hidden[-1]:
                self.hidden.pop()
            return
        if tag in blocks:
            self.flush()
    def handle_data(self,data):
        if not self.hidden and data.strip():
            self.buffer.append(data.strip())

blocks=set('title header main nav section div h1 h2 h3 h4 p li footer pre summary details tr br'.split())
for name in sys.argv[1:]:
    part=Path(name)
    for line in (part/'evidence.jsonl').read_text().splitlines():
        e=json.loads(line)
        if e['kind']!='content':
            continue
        raw=(part/e['artifact']).read_text()
        print('\n###',e['itemId'],e['locator'],e['artifact'])
        if not raw.lstrip().startswith('<'):
            print(raw)
            continue
        page=Page()
        page.feed(raw)
        page.flush()
        for ln,tag,a in page.meta:
            if tag!='link' or a.get('rel') in ('canonical','alternate'):
                print(ln,tag,a)
        print(*page.lines,sep='\n')
