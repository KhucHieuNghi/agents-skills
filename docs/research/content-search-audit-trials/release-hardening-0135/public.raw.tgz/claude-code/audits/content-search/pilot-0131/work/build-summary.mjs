// Writes the supplemental pilot summary and its quote ledger from validated local artifacts.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const [root] = process.argv.slice(2);
const sha = (v) => createHash('sha256').update(v).digest('hex');
const E = 'campaign-r2/parts/000001/evidence';
const F = {
  enHome: 'ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt',
  viHome: 'b828eaeefe1e0e1989d1f271c33b64bcd0a67859b50315299a688fd829ea725e.txt',
  enCat: '5a5d590c6c69906f4df8412778c40f2fc03c7f034660ae682cbc01a0a7d9d62d.txt',
  viCat: '2c8f3fe152e34776360d6f3626209e21f14c53231dff311a760b5cd37dc2c69d.txt',
};
const cov = JSON.parse(fs.readFileSync(path.join(root, 'report-r1/coverage.json'), 'utf8'));
const ic = cov.itemCoverage;
const d = ic.dimensions;
const Q = [
  ['Q1', 'enHome', '<span><strong>02</strong> Solution Skills</span>'],
  ['Q2', 'enHome', '<span><strong>01</strong> evaluation candidate</span>'],
  ['Q3', 'enHome', '<span>NK / SOLUTION 003</span><span>v0.1.32</span>'],
  ['Q4', 'enCat', '<a href="#solutions">03 <span>Solution Skills</span></a>'],
  ['Q5', 'viHome', '<span><strong>01</strong> ứng viên đánh giá</span>'],
  ['Q6', 'viCat', '<p class="eyebrow">NKSKILLS / DANH MỤ</p>'],
  ['Q7', 'enHome', '<a class="work-link" href="/en/guides/codex/#content-search-audit">Install and use ↗</a>'],
];
const ql = (id) => { const [, k, quote] = Q.find((x) => x[0] === id); return `- ${id} \`${quote}\` — ${F[k]}:1`; };
const lines = [
  '# NKSkills public pilot — supplemental summary (pilot-0131)',
  '',
  'This note supplements the helper-generated report in `report-r1/` (report.md, report.html, content-actions.csv, coverage.json). Counts below are copied from the validated `report-r1/coverage.json`. It does not replace that report.',
  '',
  '## Status',
  '',
  `Partial. ${ic.total} declared items; ${ic.audited} fully audited; ${ic.states.pending} pending, ${ic.states.failed} failed, ${ic.states.blocked} blocked, ${ic.states.unsupported} unsupported, ${ic.states.excluded} excluded. Collected: ${ic.collected} of ${ic.total}. Missing checks: ${ic.missingChecks}. Pending queue entries: ${ic.pendingQueue.length}. completionAllowed: ${cov.completionAllowed}. Unresolved global rule: ${cov.unresolvedRuleIds.join(', ')}.`,
  '',
  'All 12 snapshots were read and reviewed, but no item is fully audited because every item still has checks that the supplied evidence cannot resolve.',
  '',
  '| Dimension | Checks | Assessed pass/fail | Unknown | Not applicable |',
  '| --- | --- | --- | --- | --- |',
  ...['quality', 'seo', 'aio', 'aeo', 'geo', 'portfolio'].map((k) => `| ${k} | ${d[k].total} | ${d[k].completed} | ${d[k].unknown} | ${d[k].notApplicable} |`),
  '',
  '## Scope and discovery',
  '',
  '- Sole origin: https://nkskills.getgroove.me. Static a[href] navigation from `/`, maxPages=30, maxDepth=5, no browser and no script execution.',
  '- `initial-discovery/` validated first (1 capture, stopped at maxPages=1 with 6 unvisited pages queued), then continued with `discovery-resume` into `discovery-continued/`: 11 page captures, 12 inventory records (`/` and `/en/` are separate identities; `/` redirects 308 to `/en/`), frontier empty.',
  '- No count or depth budget remains pending: 11 of 30 pages were used and no unvisited-page entry is left. No further `discovery-resume` is needed for this static scope.',
  '- The discovery source is still `complete: false` and the campaign keeps scopeComplete=false. Open queue (13): 10 rendering-unreviewed pages (every HTML page), 1 page-extraction entry (README.txt is text/plain and was not parsed for links), source-incomplete, scope-unconfirmed.',
  '- External exclusions: 98 link edges to 25 distinct github.com URLs, recorded and not requested.',
  '- Not covered: rendered or script-generated navigation, CMS records, orphan pages, the sitemap that robots.txt declares (not a static-navigation source in this scope), and non-hyperlink resources (CSS, fonts, images, /scripts/prompt-picker.js, the three OFL notice files named in README.txt).',
  '',
  '## Supported findings',
  '',
  '### 1. Home summary counts two Solution Skills; page and catalog list three (medium, observed)',
  '',
  'Affected: `/`, `/en/`, `/vi/`. Rules: aio-entity-consistency, portfolio-contradictions. Finding IDs: home-solution-count-stale (local), global-home-solution-count-contradiction (same defect at portfolio level).',
  '',
  'English home, summary strip and third solution card:',
  ql('Q1'),
  ql('Q2'),
  ql('Q3'),
  '',
  'English catalog index:',
  ql('Q4'),
  '',
  'Vietnamese home, same strip:',
  ql('Q5'),
  '',
  'The home meta description also names only two workflows. Proposed action, only if the owner confirms Content search audit 0.1.32 counts as a Solution Skill: align the strip (and description) in both languages with the three listed workflows. Verify by re-capturing the home and catalog pages and comparing the counts.',
  '',
  '### 2. Content search audit entries link only to the Codex guide (low, observed)',
  '',
  'Affected: `/`, `/en/`, `/vi/`, `/en/catalog/`, `/vi/catalog/`. Rule: portfolio-journey-links. Finding IDs: content-search-audit-single-host-link (local), global-content-search-audit-single-host-journey (same defect at portfolio level).',
  '',
  ql('Q7'),
  '',
  'The Claude Code guides contain the same section id but are not linked from these entries, and the two host guides do not link to each other. Proposed action: add the Claude Code link or a host switch. No ranking effect is claimed.',
  '',
  '### 3. Vietnamese catalog hero label is truncated (low, observed)',
  '',
  'Affected: `/vi/catalog/`. Finding ID: vi-catalog-eyebrow-truncated. The navigation on the same page uses "Danh mục".',
  '',
  ql('Q6'),
  '',
  '## Clean results (narrow, raw-source judgments)',
  '',
  '- All 12 URLs returned HTTP 200 (`/` after one 308 redirect); extracted text is non-empty for all 12.',
  '- Canonical: the 11 HTML responses declare a self-referencing canonical equal to the final URL and og:url.',
  '- Locales: the five EN/VI pairs carry reciprocal hreflang (en, vi, x-default) and matching html lang; pairs match on heading count, internal link count, external targets, code blocks and version strings.',
  '- Internal links: every internal target is in the inventory and every fragment link resolves to an id in captured source.',
  '- Workflow names, versions (1.1.0, 0.1.0, 0.1.32), statuses, hosts and commands agree across pages and languages, apart from finding 1.',
  '',
  'Optional wording notes, not findings: home and guide meta descriptions do not mention Content search audit; English guides contain a stray comma ("open Codex, at that project"); Vietnamese pages keep the English aria-label "NKSkills home" on the logo link.',
  '',
  '## Unknown and why',
  '',
  '- Claims, freshness, answer evidence: the GitHub release records, manifests and catalog.yaml the pages cite are outside the allowed origin.',
  '- Index controls, AI crawler policy: robots.txt allows all agents and no robots meta or X-Robots-Tag was captured, but publisher intent was not supplied.',
  '- Rendering, structured data: no rendered DOM; raw source has no JSON-LD, microdata or RDFa.',
  '- AEO question coverage and context, portfolio task gaps: no question or query set supplied.',
  '- GEO (all three rules): no AI response observations. No Google AI Overviews measurements were supplied. Rankings, indexing, crawler logs, citations and conversions are unmeasured, not zero.',
  '',
  'Quotes Q1–Q7 are exact substrings of the cited content snapshots under `' + E + '/` (each HTML snapshot is a single line, so the locator is line 1); see `summary-quote-receipt.json`.',
  '',
];
const report = lines.join('\n');
const reportFile = path.join(root, 'pilot-summary.md');
fs.writeFileSync(reportFile, report, { flag: 'wx' });
const reportLines = report.split('\n');
const quotes = Q.map(([quoteId, k, quote]) => {
  const source = `${E}/${F[k]}`; const bytes = fs.readFileSync(path.join(root, source));
  const n = reportLines.findIndex((l) => l.startsWith(`- ${quoteId} `)) + 1;
  if (!n) throw new Error('Quote line missing for ' + quoteId);
  return { quoteId, source, sourceLabel: F[k], sourceHash: sha(bytes), startLine: 1, endLine: 1, reportStartLine: n, reportEndLine: n, normalization: 'exact', quote };
});
fs.writeFileSync(path.join(root, 'summary-quotes.json'), JSON.stringify({ root, report: 'pilot-summary.md', reportHash: sha(fs.readFileSync(reportFile)), quotes }, null, 2) + '\n', { flag: 'wx' });
console.log('written', quotes.length);
