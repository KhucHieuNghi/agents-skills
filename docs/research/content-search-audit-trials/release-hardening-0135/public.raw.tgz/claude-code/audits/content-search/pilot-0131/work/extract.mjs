// Inert text inspection of captured snapshots. Nothing from the target is executed.
import fs from 'node:fs';
const [part, mode = 'meta'] = process.argv.slice(2);
const L = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const inv = L(`${part}/inventory.jsonl`);
const ev = L(`${part}/evidence.jsonl`);
const dec = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
const attr = (tag, name) => { const m = tag.match(new RegExp(`\\s${name}=("([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i')); return m ? dec(m[2] ?? m[3] ?? m[4]) : null; };
const out = {};
for (const item of inv.sort((a, b) => a.uri.localeCompare(b.uri))) {
  const c = ev.find((e) => e.itemId === item.itemId && e.kind === 'content');
  const h = ev.find((e) => e.itemId === item.itemId && e.kind === 'http-response');
  const html = c.value;
  const isHtml = /<html/i.test(html);
  const tags = html.match(/<[^>]+>/g) || [];
  const meta = tags.filter((t) => /^<meta\b/i.test(t)).map((t) => ({ name: attr(t, 'name') ?? attr(t, 'property') ?? attr(t, 'http-equiv') ?? (attr(t, 'charset') ? 'charset' : null), content: attr(t, 'content') ?? attr(t, 'charset') }));
  const links = tags.filter((t) => /^<link\b/i.test(t)).map((t) => ({ rel: attr(t, 'rel'), hreflang: attr(t, 'hreflang'), href: attr(t, 'href') }));
  const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].map((m) => ({ type: attr('<s ' + m[1] + '>', 'type'), src: attr('<s ' + m[1] + '>', 'src'), inlineLength: m[2].length, inline: m[2].slice(0, 4000) }));
  const imgs = tags.filter((t) => /^<(img|svg|video|audio|picture|iframe|canvas|object)\b/i.test(t)).map((t) => ({ tag: t.match(/^<(\w+)/)[1], src: attr(t, 'src'), alt: attr(t, 'alt'), ariaHidden: attr(t, 'aria-hidden'), ariaLabel: attr(t, 'aria-label'), role: attr(t, 'role') }));
  const anchors = [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map((m) => ({ href: attr('<a ' + m[1] + '>', 'href'), text: dec(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()), ariaLabel: attr('<a ' + m[1] + '>', 'aria-label') }));
  const headings = [...html.matchAll(/<(h[1-6])\b[^>]*>([\s\S]*?)<\/\1>/gi)].map((m) => `${m[1]}: ${dec(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim())}`);
  const title = (html.match(/<title>([\s\S]*?)<\/title>/i) || [])[1];
  const lang = (html.match(/<html[^>]*\slang="([^"]*)"/i) || [])[1];
  let body = html;
  if (isHtml) {
    body = html.replace(/<head[\s\S]*?<\/head>/i, '').replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/<(\/)?(p|div|section|article|li|ul|ol|h[1-6]|header|footer|nav|main|aside|tr|table|pre|br|details|summary|figure|figcaption|dt|dd|dl|blockquote|button|label)\b[^>]*>/gi, '\n')
      .replace(/<a\b[^>]*href="([^"]*)"[^>]*>/gi, '[→$1 ').replace(/<\/a>/gi, ']').replace(/<[^>]+>/g, '');
    body = dec(body).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
  }
  out[item.uri] = { itemId: item.itemId, contentEvidenceId: c.evidenceId, snapshotHash: c.snapshotHash, collectedAt: c.collectedAt, http: { status: h.value.status, finalUrl: h.value.finalUrl, headers: h.value.headers, redirects: h.value.redirects }, lang, title: title && dec(title), meta, links: links.filter((l) => !/preload|stylesheet|icon/.test(l.rel || '')), otherLinkRels: [...new Set(links.map((l) => l.rel))], scripts, media: imgs, headings, anchors, body };
}
if (mode === 'meta') {
  for (const [u, o] of Object.entries(out)) { const { body, anchors, ...rest } = o; console.log('=====', u); console.log(JSON.stringify(rest, null, 1)); }
} else if (mode === 'anchors') {
  for (const [u, o] of Object.entries(out)) { console.log('=====', u); for (const a of o.anchors) console.log(`  ${a.href} | ${a.text}${a.ariaLabel ? ' | aria=' + a.ariaLabel : ''}`); }
} else if (mode === 'json') {
  console.log(JSON.stringify(out));
} else {
  const o = Object.entries(out).find(([u]) => u === mode);
  console.log(o[1].body);
}
