// Builds the attributed per-part review bundle from the collected campaign snapshots.
// Inert text inspection only: nothing from the target site is executed or fetched.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const [campaignDir, indexDir, outBundle, outFacts] = process.argv.slice(2);
const sha = (v) => createHash('sha256').update(v).digest('hex');
const L = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const PART = 'parts/000001';
const partDir = path.join(campaignDir, PART);
const inv = L(path.join(partDir, 'inventory.jsonl'));
const ev = L(path.join(partDir, 'evidence.jsonl'));
const manifestBytes = fs.readFileSync(path.join(campaignDir, 'campaign.json'));
const manifest = JSON.parse(manifestBytes);
const index = JSON.parse(fs.readFileSync(path.join(indexDir, 'index.json'), 'utf8'));
const NOW = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), AI host agent applying the packaged content-search-audit methods; not a human domain reviewer';
const B = 'https://nkskills.getgroove.me';
const KEYS = {
  [`${B}/`]: 'root', [`${B}/en/`]: 'enHome', [`${B}/vi/`]: 'viHome', [`${B}/en/catalog/`]: 'enCat', [`${B}/vi/catalog/`]: 'viCat',
  [`${B}/en/solutions/codebase-onboarding/`]: 'enSol', [`${B}/vi/solutions/codebase-onboarding/`]: 'viSol',
  [`${B}/en/guides/codex/`]: 'enCodex', [`${B}/en/guides/claude-code/`]: 'enClaude', [`${B}/vi/guides/codex/`]: 'viCodex', [`${B}/vi/guides/claude-code/`]: 'viClaude',
  [`${B}/licenses/README.txt`]: 'readme',
};
const dec = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
const attr = (tag, name) => { const m = tag.match(new RegExp(`\\s${name}=("([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i')); return m ? dec(m[2] ?? m[3] ?? m[4]) : null; };
const strip = (s) => dec(s.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();

const P = {}; // page facts by key
for (const item of inv) {
  const key = KEYS[item.uri];
  if (!key) throw new Error('Unmapped inventory item ' + item.uri);
  const of = (kind) => ev.filter((e) => e.itemId === item.itemId && e.kind === kind);
  const content = of('content'); const http = of('http-response'); const robots = of('crawler-policy');
  if (content.length !== 1 || http.length !== 1) throw new Error('Expected one content/http snapshot for ' + item.uri);
  const html = content[0].value; const h = http[0].value;
  const isHtml = /^text\/html/.test(h.headers['content-type'] || '');
  const tags = isHtml ? html.match(/<[^>]+>/g) || [] : [];
  const anchors = isHtml ? [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map((m) => ({ href: attr('<a ' + m[1] + '>', 'href'), text: strip(m[2]), offset: m.index })) : [];
  const finalUrl = h.url;
  for (const a of anchors) { try { const u = new URL(a.href, finalUrl); a.abs = u.href; a.page = u.origin + u.pathname + u.search; a.frag = u.hash.slice(1); a.internal = u.origin === B; } catch { a.abs = null; } }
  P[key] = {
    key, item, itemId: item.itemId, uri: item.uri, html, isHtml, finalUrl, http: h, httpId: http[0].evidenceId, contentId: content[0].evidenceId, contentAt: content[0].collectedAt,
    robotsIds: robots.map((r) => r.evidenceId), robots,
    lang: (html.match(/<html[^>]*\slang="([^"]*)"/i) || [])[1] ?? null,
    title: isHtml ? dec((html.match(/<title>([\s\S]*?)<\/title>/i) || [])[1] ?? '') : null,
    metas: tags.filter((t) => /^<meta\b/i.test(t)).map((t) => ({ name: attr(t, 'name') ?? attr(t, 'property') ?? attr(t, 'http-equiv'), content: attr(t, 'content') })).filter((m) => m.name),
    links: tags.filter((t) => /^<link\b/i.test(t)).map((t) => ({ rel: attr(t, 'rel'), hreflang: attr(t, 'hreflang'), href: attr(t, 'href') })),
    scripts: isHtml ? [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].map((m) => ({ type: attr('<s ' + m[1] + '>', 'type'), src: attr('<s ' + m[1] + '>', 'src'), inlineLength: m[2].length })) : [],
    headings: isHtml ? [...html.matchAll(/<(h[1-6])\b[^>]*>([\s\S]*?)<\/\1>/gi)].map((m) => `${m[1]}: ${strip(m[2])}`) : [],
    ids: new Set(isHtml ? [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]) : []),
    anchors,
    code: isHtml ? [...html.matchAll(/<pre\b[^>]*>([\s\S]*?)<\/pre>/gi)].map((m) => strip(m[1])) : [],
  };
}
const keys = Object.keys(P);
const byUri = Object.fromEntries(keys.map((k) => [P[k].uri, k]));
const htmlKeys = keys.filter((k) => P[k].isHtml);
const id8 = (k) => P[k].itemId.slice(0, 8);
// Exact-quote guard: every quoted snippet must be a substring of that item's content snapshot.
const q = (k, snippet) => { const i = P[k].html.indexOf(snippet); if (i < 0) throw new Error(`Quote not in ${k}: ${snippet}`); return `"${snippet}" (${P[k].uri} content snapshot, char offset ${i})`; };

// ---------- derived facts ----------
const visibleText = (k) => {
  const p = P[k]; if (!p.isHtml) return p.html;
  let body = p.html.replace(/<head[\s\S]*?<\/head>/i, '').replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<template[\s\S]*?<\/template>/gi, '')
    .replace(/<(\/)?(p|div|section|article|li|ul|ol|h[1-6]|header|footer|nav|main|aside|pre|br|details|summary|figure|figcaption|button|label|textarea|a|span|strong|code)\b[^>]*>/gi, (m) => (/^<\/?(a|span|strong|code)\b/i.test(m) ? ' ' : '\n'))
    .replace(/<[^>]+>/g, '');
  return dec(body).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n') + '\n';
};
const canonicalOf = (k) => P[k].links.find((l) => l.rel === 'canonical')?.href ?? null;
const alternates = (k) => P[k].links.filter((l) => l.rel === 'alternate' && l.hreflang);
const meta = (k, n) => P[k].metas.find((m) => m.name === n)?.content ?? null;
const inbound = (k) => {
  const target = P[k].uri; const rows = [];
  for (const s of htmlKeys) { const hits = P[s].anchors.filter((a) => a.internal && a.page === target); if (hits.length && s !== k) rows.push({ from: s, count: hits.length }); }
  return rows;
};
const fragmentIssues = (k) => {
  const out = [];
  for (const a of P[k].anchors) { if (!a.internal || !a.frag) continue; const t = byUri[a.page]; if (!t) { out.push(`${a.href}: target page not in captured inventory`); continue; } if (!P[t].ids.has(a.frag)) out.push(`${a.href}: no element id="${a.frag}" in captured source of ${a.page}`); }
  return out;
};
const internalTargets = (k) => [...new Set(P[k].anchors.filter((a) => a.internal).map((a) => a.page))];
const externalTargets = (k) => [...new Set(P[k].anchors.filter((a) => a.abs && !a.internal).map((a) => a.abs))];
const uncaptured = (k) => internalTargets(k).filter((u) => !byUri[u]);
const pairOf = { enHome: 'viHome', viHome: 'enHome', enCat: 'viCat', viCat: 'enCat', enSol: 'viSol', viSol: 'enSol', enCodex: 'viCodex', viCodex: 'enCodex', enClaude: 'viClaude', viClaude: 'enClaude', root: 'viHome' };
const versions = (k) => [...new Set(P[k].html.replace(/<head[\s\S]*?<\/head>/i, '').replace(/<script[\s\S]*?<\/script>/gi, '').match(/(?<![\d.])\d+\.\d+\.\d+(?![\d.])/g) || [])].sort();
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const parity = (a, b) => ({
  headingCount: [P[a].headings.length, P[b].headings.length],
  internalAnchorCount: [P[a].anchors.filter((x) => x.internal).length, P[b].anchors.filter((x) => x.internal).length],
  externalTargetsEqual: eq(externalTargets(a).sort(), externalTargets(b).sort()),
  codeBlocksEqual: eq(P[a].code, P[b].code), codeBlockCount: [P[a].code.length, P[b].code.length],
  versionStringsEqual: eq(versions(a), versions(b)), versionStrings: [versions(a), versions(b)],
});
const proofStrip = (k) => { const m = P[k].html.match(/<div class="proof-strip"[\s\S]*?<\/div>/); return m ? [...m[0].matchAll(/<span><strong>(\d+)<\/strong>\s*([^<]+)<\/span>/g)].map((x) => ({ n: x[1], label: x[2], raw: x[0] })) : []; };
const homeCards = (k) => [...P[k].html.matchAll(/<span>NK \/ SOLUTION (\d+)<\/span><span>(v[\d.]+)<\/span><\/div><span class="status-pill[^"]*">([^<]+)<\/span><h3>([^<]+)<\/h3>/g)].map((m) => ({ n: m[1], version: m[2], status: m[3], name: m[4] }));
const catalogChips = (k) => [...P[k].html.matchAll(/<a href="#(solutions|upstreams|security-upstreams|method)">(\d+) <span>([^<]+)<\/span><\/a>/g)].map((m) => ({ target: m[1], n: m[2], label: m[3], raw: m[0] }));
const catalogSolutions = (k) => P[k].headings.filter((h) => /^h3: .+ \d+\.\d+\.\d+$/.test(h)).map((h) => h.slice(4));
const treeLinks = (k) => P[k].anchors.filter((a) => a.abs && /github\.com\/[^/]+\/[^/]+\/tree\//.test(a.abs)).length;
const buildCommands = (k) => [...P[k].html.matchAll(/build-solution ([\w-]+) --output build\/([\w.-]+)/g)].map((m) => `${m[1]} -> build/${m[2]}`);
const targets = (k) => [...new Set([...P[k].html.matchAll(/--target (\S+?)(?=<|\s)/g)].map((m) => m[1]))];
const invocations = (k) => [...P[k].html.matchAll(/<div class="invocation-card"><span>([^<]+)<\/span><code>([^<]+)<\/code>/g)].map((m) => `${m[1]}: ${dec(m[2])}`);
const mediaInventory = (k) => {
  const p = P[k]; const tags = p.isHtml ? p.html.match(/<(img|svg|video|audio|picture|iframe|canvas|object|embed)\b[^>]*>/gi) || [] : [];
  return { elements: tags.map((t) => ({ tag: t.match(/^<(\w+)/)[1], src: attr(t, 'src'), alt: attr(t, 'alt'), raw: t })), roleImg: p.isHtml ? (p.html.match(/<[^>]+role="img"[^>]*>/g) || []) : [], figures: (p.html.match(/<figure\b/g) || []).length, ariaHiddenContainers: p.isHtml ? (p.html.match(/<(div|section|figure|aside|article)\b[^>]*aria-hidden="true"[^>]*>/g) || []) : [] };
};
const schemaScan = (k) => { const p = P[k]; return { jsonLdScripts: (p.html.match(/<script[^>]+application\/ld\+json/gi) || []).length, microdata: (p.html.match(/\sitem(scope|type|prop)[\s=>]/gi) || []).length, rdfa: (p.html.match(/\s(typeof|vocab|property)=/gi) || []).filter((m) => !/property=/.test(m)).length, ogProperties: p.metas.filter((m) => /^og:/.test(m.name)).map((m) => m.name) }; };

// ---------- evidence builders ----------
const evidence = []; const artifacts = {};
const add = (k, slug, kind, value, method, locator, sourceEvidenceIds, limitations) => {
  const evidenceId = `${slug}-${id8(k)}`; const artifact = `evidence/${evidenceId}.txt`;
  artifacts[artifact] = value;
  evidence.push({ evidenceId, itemId: P[k].itemId, kind, value, method, locator, collectedAt: NOW, snapshotHash: sha(value), artifact, encoding: 'utf8', sourceEvidenceIds, redaction: 'none; derived from public captured source or the audit request; no credentials or personal data', limitations });
  return evidenceId;
};
const allContentIds = keys.map((k) => P[k].contentId);
const E = {}; // evidence ids by key
const LIM_DERIVED = ['Host-derived inert regex inspection of the captured raw source; not a full HTML5 DOM parse and not a rendered DOM', 'Describes the snapshot captured at the cited time only; not live state, index status or engine behaviour'];

const OWNER_CONTEXT = 'Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.';
const SCOPE_CONTEXT = 'Declared pilot scope from the same request: static navigation reachable from https://nkskills.getgroove.me/, same exact allowed origin, maxPages=30, maxDepth=5, no browser or script execution; no credentials, authenticated providers or analytics exports are supplied; scopeComplete=false because CMS, orphan pages and rendered navigation are not supplied.';
const TASK = {
  root: 'Entry URL; redirects (308) to the English home page, so the served task is the English home task.',
  enHome: 'Inferred task: an English-reading Codex or Claude Code user wants to understand what NKSkills offers, which workflows exist and their release status, and how to start.',
  viHome: 'Inferred task: a Vietnamese-reading Codex or Claude Code user wants to understand what NKSkills offers, which workflows exist and their release status, and how to start.',
  enCat: 'Inferred task: evaluate which Solution Skills and pinned upstream skills exist, with source, revision, licence and release status (English).',
  viCat: 'Inferred task: evaluate which Solution Skills and pinned upstream skills exist, with source, revision, licence and release status (Vietnamese).',
  enSol: 'Inferred task: decide whether the codebase-onboarding Solution Skill 1.1.0 fits, including components, outputs, prerequisites and limits (English).',
  viSol: 'Inferred task: decide whether the codebase-onboarding Solution Skill 1.1.0 fits, including components, outputs, prerequisites and limits (Vietnamese).',
  enCodex: 'Inferred task: build, install and invoke NKSkills Solution Skills in Codex (English).',
  enClaude: 'Inferred task: build, install and invoke NKSkills Solution Skills in Claude Code (English).',
  viCodex: 'Inferred task: build, install and invoke NKSkills Solution Skills in Codex (Vietnamese).',
  viClaude: 'Inferred task: build, install and invoke NKSkills Solution Skills in Claude Code (Vietnamese).',
  readme: 'Inferred task: a visitor following the footer "Font licenses" link wants the attribution and licence of the site fonts.',
};
const PURPOSE = {
  root: ['redirect alias of /en/ (HTTP 308)', 'entry', 'en (served)'], enHome: ['home / product overview', 'discovery + evaluation', 'en'], viHome: ['home / product overview', 'discovery + evaluation', 'vi'],
  enCat: ['catalog of Solution and Upstream Skills', 'evaluation / reference', 'en'], viCat: ['catalog of Solution and Upstream Skills', 'evaluation / reference', 'vi'],
  enSol: ['solution page: codebase onboarding 1.1.0', 'evaluation / decision', 'en'], viSol: ['solution page: codebase onboarding 1.1.0', 'evaluation / decision', 'vi'],
  enCodex: ['install and use guide, host Codex', 'implementation', 'en'], enClaude: ['install and use guide, host Claude Code', 'implementation', 'en'],
  viCodex: ['install and use guide, host Codex', 'implementation', 'vi'], viClaude: ['install and use guide, host Claude Code', 'implementation', 'vi'],
  readme: ['font licence notices (text/plain)', 'support / legal attribution', 'English text, no declared locale'],
};
const order = ['root', 'enHome', 'viHome', 'enCat', 'viCat', 'enSol', 'viSol', 'enCodex', 'enClaude', 'viCodex', 'viClaude', 'readme'];
if (order.some((k) => !P[k]) || order.length !== keys.length) throw new Error('Inventory does not match the reviewed key set');

// Shared site-derived entity record
const entityLines = [];
entityLines.push('SITE-DERIVED ENTITY RECORD (compiled by the reviewer from the 12 captured snapshots of the allowed origin; it is NOT an independent authoritative record. The GitHub release records, manifests and catalog.yaml that the pages cite are outside the allowed origin and were not collected.)');
entityLines.push('Brand: NKSkills. Hosts named on every HTML page footer/tagline: Codex and Claude Code.');
for (const k of ['enHome', 'viHome', 'root']) {
  entityLines.push(`[${P[k].uri}] proof strip: ${proofStrip(k).map((s) => `${s.n} ${s.label}`).join(' | ')}`);
  entityLines.push(`[${P[k].uri}] solution cards (${homeCards(k).length}): ${homeCards(k).map((c) => `${c.n} ${c.name} ${c.version} ${c.status}`).join(' | ')}`);
}
for (const k of ['enCat', 'viCat']) {
  entityLines.push(`[${P[k].uri}] index chips: ${catalogChips(k).map((c) => `${c.n} ${c.label}`).join(' | ')}`);
  entityLines.push(`[${P[k].uri}] Solution Skill entries (${catalogSolutions(k).length}): ${catalogSolutions(k).join(' | ')}; pinned upstream/security source links (github .../tree/<commit>): ${treeLinks(k)}`);
}
for (const k of ['enSol', 'viSol']) entityLines.push(`[${P[k].uri}] title: ${P[k].title}; version strings in body: ${versions(k).join(', ')}; component headings: ${P[k].headings.filter((h) => h.startsWith('h3')).map((h) => h.slice(4)).join(', ')}`);
for (const k of ['enCodex', 'enClaude', 'viCodex', 'viClaude']) entityLines.push(`[${P[k].uri}] build commands: ${buildCommands(k).join(' | ')}; install --target: ${targets(k).join(', ')}; invocations: ${invocations(k).join(' | ')}`);
entityLines.push(`[${P.readme.uri}] first line: ${P.readme.html.split('\n')[0]}`);
const ENTITY_SHARED = entityLines.join('\n');

// Shared inventory map
const INVENTORY_SHARED = ['INVENTORY MAP (reviewer classification of the 12 declared items; purpose and stage are reviewer inferences from page content, not owner-supplied labels)', 'itemId8 | URL | purpose | task stage | language | pair/variant',
  ...order.map((k) => `${id8(k)} | ${P[k].uri} | ${PURPOSE[k][0]} | ${PURPOSE[k][1]} | ${PURPOSE[k][2]} | ${k === 'root' ? 'alias of /en/' : k === 'readme' ? 'none' : P[pairOf[k]].uri}`),
  `Byte-identical content: / and /en/ snapshots are ${P.root.html === P.enHome.html ? 'identical' : 'different'} (/ is served via 308 redirect to /en/).`,
  'Host variants: /guides/codex/ and /guides/claude-code/ share structure and differ in host name, --target value and invocation token.',
  'Not in this inventory: pages reachable only through rendered/scripted navigation, CMS records, orphan pages, the robots-declared sitemap.xml, and non-hyperlink resources (CSS, fonts, images, /scripts/prompt-picker.js, OFL notice files named in README.txt).',
].join('\n');

const parityRows = [['enHome', 'viHome'], ['enCat', 'viCat'], ['enSol', 'viSol'], ['enCodex', 'viCodex'], ['enClaude', 'viClaude']].map(([a, b]) => ({ a, b, ...parity(a, b) }));

for (const k of order) {
  const p = P[k]; const e = (E[k] = {});
  e.content = p.contentId; e.http = p.httpId; e.robots = p.robotsIds;
  e.audience = add(k, 'ctx-audience', 'audience-context',
    `OWNER-SUPPLIED CONTEXT (quoted from the audit request received 2026-11-18): "${OWNER_CONTEXT}"\n${SCOPE_CONTEXT}\nItem: ${p.uri}\n${TASK[k]}\nThe audience (Codex and Claude Code users; English and Vietnamese readers) comes from the owner statement. The per-page task is a reviewer inference from the page's own headings and text, not an owner-approved persona, journey or question set.`,
    'user-supplied-context', 'audit request task statement (business context and declared scope), 2026-11-18', [p.contentId],
    ['Owner-supplied context used as the comparison basis; not independently verified', 'No persona research, customer questions, search queries or market data were supplied; per-page task is inferred']);
  e.text = add(k, 'extracted-text', 'extracted-text', visibleText(k), p.isHtml ? 'host-inert-tag-stripping' : 'identity-copy-of-text-plain-body', p.uri, [p.contentId],
    p.isHtml ? ['Regex tag-stripping of the captured raw HTML; head, script, style and inert <template> contents removed; aria-hidden text retained', 'Not a rendered-DOM text extraction; visual order, CSS-hidden state and script-inserted text are unknown'] : ['Byte-identical copy of the captured text/plain body']);
  const can = canonicalOf(k); const linkHeader = p.http.headers.link ?? null; const xr = p.http.headers['x-robots-tag'] ?? null;
  e.canonical = add(k, 'canonical-targets', 'canonical-targets', [
    `Declared inventory URL: ${p.uri}`, `Redirect chain: ${p.http.redirects.length ? p.http.redirects.map((r) => `${r.url} -> HTTP ${r.status}`).join('; ') : 'none'}`, `Final response URL: ${p.finalUrl} (HTTP ${p.http.status}, content-type ${p.http.headers['content-type']})`,
    `rel=canonical in captured source: ${can ?? 'none'}`, `og:url in captured source: ${meta(k, 'og:url') ?? 'none'}`, `HTTP Link header in captured response: ${linkHeader ?? 'absent (the collector retains Link when sent)'}`,
    `Canonical equals final response URL: ${can ? String(can === p.finalUrl) : 'n/a'}; og:url equals canonical: ${can ? String(meta(k, 'og:url') === can) : 'n/a'}`,
    `Other captured items declaring the same canonical: ${order.filter((o) => o !== k && canonicalOf(o) && canonicalOf(o) === can).map((o) => P[o].uri).join(', ') || 'none'}`,
    `Query-string or alternate-path variants of this URL discovered in the static link graph: none`,
  ].join('\n'), 'host-inert-source-inspection', p.uri, [p.contentId, p.httpId], [...LIM_DERIVED, 'A declared canonical is not the engine-selected canonical; no index or Search Console evidence was supplied']);
  const alts = alternates(k); const pair = pairOf[k];
  const recip = alts.map((a) => { const t = byUri[a.href]; if (!t) return `${a.hreflang} -> ${a.href}: target not captured`; const back = alternates(t).some((x) => x.href === (can ?? p.finalUrl)); return `${a.hreflang} -> ${a.href}: target captured, html lang="${P[t].lang}", links back to ${can ?? p.finalUrl}: ${back}`; });
  const langLinks = p.anchors.filter((a) => a.internal && byUri[a.page] && P[byUri[a.page]].lang && P[byUri[a.page]].lang !== p.lang).map((a) => `${a.href} "${a.text}"`);
  e.locale = add(k, 'locale-map', 'locale-map', [
    `Item: ${p.uri} (final ${p.finalUrl})`, `html lang: ${p.lang ?? 'none (not an HTML document)'}`, `hreflang annotations in captured source (${alts.length}): ${alts.map((a) => `${a.hreflang}=${a.href}`).join(' ; ') || 'none'}`,
    `Reciprocity against the captured counterpart snapshots:`, ...(recip.length ? recip.map((r) => '  ' + r) : ['  none to check']), `Self-reference present: ${alts.some((a) => a.href === (can ?? p.finalUrl))}`, `x-default: ${alts.find((a) => a.hreflang === 'x-default')?.href ?? 'none'}`,
    `Visible cross-language links: ${[...new Set(langLinks)].join(' ; ') || 'none'}`, `HTTP Link header (possible hreflang for non-HTML): ${linkHeader ?? 'absent'}`,
    ...(pair && k !== 'root' ? [`Structural parity with ${P[pair].uri}: ${JSON.stringify(parity(k, pair))}`] : []),
  ].join('\n'), 'host-inert-source-inspection', p.uri, [...new Set([p.contentId, p.httpId, ...alts.map((a) => byUri[a.href]).filter(Boolean).map((t) => P[t].contentId)])], [...LIM_DERIVED, 'Reciprocity verified only between captured snapshots; engine-selected language results and indexing are not observed', 'Parity counts compare structure, not translation quality of every sentence']);
  const inb = inbound(k); const frag = fragmentIssues(k);
  e.links = add(k, 'link-graph', 'link-graph', [
    `Item: ${p.uri}`, `Anchors in captured source: ${p.anchors.length} (internal ${p.anchors.filter((a) => a.internal).length}, external ${p.anchors.filter((a) => a.abs && !a.internal).length})`,
    `Distinct internal target pages (${internalTargets(k).length}): ${internalTargets(k).join(' ; ') || 'none'}`, `Internal targets not in the captured inventory: ${uncaptured(k).join(' ; ') || 'none'}`,
    `Captured HTTP status of each internal target: ${internalTargets(k).map((u) => `${u}=${byUri[u] ? P[byUri[u]].http.status : 'not captured'}`).join(' ; ') || 'n/a'}`,
    `Internal fragment links whose id is missing in the captured target source: ${frag.join(' ; ') || 'none'}`,
    `Inbound internal links from other captured pages (${inb.length} pages): ${inb.map((r) => `${P[r.from].uri} x${r.count}`).join(' ; ') || 'none'}`,
    `Internal anchors (href | text): ${p.anchors.filter((a) => a.internal).map((a) => `${a.href} | ${a.text || '(no text)'}`).join(' ;; ') || 'none'}`,
    `Distinct external targets (${externalTargets(k).length}), recorded as excluded edges and not requested: ${externalTargets(k).join(' ; ') || 'none'}`,
  ].join('\n'), 'host-inert-source-inspection', p.uri, [...new Set([p.contentId, ...inb.map((r) => P[r.from].contentId), ...internalTargets(k).map((u) => byUri[u]).filter(Boolean).map((t) => P[t].contentId)])], [...LIM_DERIVED, 'Static a[href] links in raw source only; script-generated navigation, sitemap entries and orphan pages are not represented', 'External targets and non-hyperlink resources (CSS, fonts, images, scripts) were not requested, so their status is unknown']);
  const sc = schemaScan(k);
  e.schema = add(k, 'schema-extraction', 'schema-extraction', [
    `Item: ${p.uri} (content-type ${p.http.headers['content-type']})`, `application/ld+json script blocks in captured source: ${sc.jsonLdScripts}`, `Microdata attributes (itemscope/itemtype/itemprop): ${sc.microdata}`, `RDFa attributes (typeof/vocab): ${sc.rdfa}`,
    `Open Graph meta properties (not schema.org structured data): ${sc.ogProperties.join(', ') || 'none'}`, `Script elements in captured source: ${p.scripts.map((s) => `${s.src ?? 'inline'} (type ${s.type ?? 'classic'}, inline length ${s.inlineLength})`).join(' ; ') || 'none'}`,
    'Result: no schema.org structured data found in the raw captured source. Whether any script adds structured data at render time was not observed.',
  ].join('\n'), 'host-inert-source-inspection', p.uri, [p.contentId], [...LIM_DERIVED, 'Raw-source absence does not establish rendered absence; scripts were not fetched or executed']);
  const mi = mediaInventory(k);
  e.media = add(k, 'media-inventory', 'media-inventory', [
    `Item: ${p.uri} (content-type ${p.http.headers['content-type']})`, `Media elements (img/svg/video/audio/picture/iframe/canvas/object/embed) in captured source: ${mi.elements.length}`, ...mi.elements.map((m) => `  ${m.raw}`),
    `Elements with role="img": ${mi.roleImg.length}`, ...mi.roleImg.map((m) => `  ${m}`), `figure elements: ${mi.figures}`, `aria-hidden="true" block containers: ${mi.ariaHiddenContainers.length}`, ...mi.ariaHiddenContainers.map((m) => `  ${m}`),
    `og:image (social preview, not on-page media; file not collected): ${meta(k, 'og:image') ?? 'none'}`,
    ...(p.ids.has('workflow-description') ? [`Text alternative referenced by aria-describedby="workflow-description": ${strip((p.html.match(/<p id="workflow-description"[^>]*>([\s\S]*?)<\/p>/) || [])[1] ?? '')}`] : []),
  ].join('\n'), 'host-inert-source-inspection', p.uri, [p.contentId], [...LIM_DERIVED, 'CSS background images, the og:image file and rendered appearance were not collected; no audio/video transcripts were needed or supplied']);
  e.entity = add(k, 'entity-record', 'entity-record', `${ENTITY_SHARED}\n\nItem under comparison: ${p.uri}`, 'host-derived-cross-page-compilation', 'compiled from the 12 captured content snapshots of https://nkskills.getgroove.me', allContentIds,
    ['Site-derived record: shows what the site says about itself across pages; it cannot confirm that any version, status, licence or revision is true', 'Authoritative external records cited by the pages (GitHub release records, manifests, catalog.yaml) are outside the allowed origin and were not collected', ...LIM_DERIVED]);
  e.inventory = add(k, 'inventory-map', 'inventory-map', `${INVENTORY_SHARED}\n\nEN/VI structural parity: ${JSON.stringify(parityRows)}\n\nItem under comparison: ${p.uri}`, 'host-derived-cross-page-compilation', 'compiled from the campaign inventory and the 12 captured content snapshots', allContentIds,
    ['Purpose and stage labels are reviewer classifications', 'Declared inventory only: discovery is incomplete (rendered navigation, CMS, orphan pages and sitemap not supplied)', ...LIM_DERIVED]);
}

// ---------- reviews ----------
const reviews = []; const statusOf = {};
const R = (k, ruleId, status, reason, evidenceIds) => { reviews.push({ itemId: P[k].itemId, ruleId, status, reason, evidenceIds: [...new Set(evidenceIds)], reviewer: REVIEWER, reviewedAt: NOW }); statusOf[`${k}/${ruleId}`] = status; };
const homes = ['root', 'enHome', 'viHome']; const cats = ['enCat', 'viCat']; const sols = ['enSol', 'viSol']; const guides = ['enCodex', 'enClaude', 'viCodex', 'viClaude'];
const isVi = (k) => P[k].lang === 'vi';
const stripText = (k) => proofStrip(k).map((s) => `${s.n} ${s.label}`).join(', ');
const cardText = (k) => homeCards(k).map((c) => `${c.name} ${c.version} (${c.status})`).join('; ');
const auditLink = (k) => P[k].anchors.filter((a) => a.internal && a.frag === 'content-search-audit');
const hostGuideLinks = (k) => [...new Set(P[k].anchors.filter((a) => a.internal && /\/guides\/(codex|claude-code)\/$/.test(a.page)).map((a) => a.page.replace(B, '')))];

for (const k of order) {
  const p = P[k]; const e = E[k]; const html = p.isHtml;
  const C = [e.content];
  // ---- quality
  if (homes.includes(k)) R(k, 'quality-task-fit', 'pass', `${TASK[k]} All page sections were read in the raw snapshot (hero, model, three solution cards, source-to-output figure, install steps, starter prompt, catalog summary, security sources, FAQ, closing call to action). The page names the supported hosts, states each workflow's release status and limits, and links to the install guides and the solution page, so the inferred task can be completed. Caveats: the summary strip and meta description lag the three listed workflows (recorded under aio-entity-consistency, not double-counted here); the host/language prompt switch depends on /scripts/prompt-picker.js, which was not executed, while the default prompt is present in the textarea in raw source. Task is reviewer-inferred, not owner-approved.`, [...C, e.audience]);
  else if (k === 'enCat') R(k, 'quality-task-fit', 'pass', `${TASK[k]} The snapshot lists ${catalogSolutions(k).length} Solution Skill entries with version and status, ${treeLinks(k)} commit-pinned upstream/security sources each with licence and a short revision, and the versioning model, with a pointer to catalog.yaml for full commits and checksums. That is sufficient for the inferred evaluation task. Whether the listed licences and revisions are correct is a claims question (quality-claims, unknown).`, [...C, e.audience]);
  else if (k === 'viCat') R(k, 'quality-task-fit', 'pass', `${TASK[k]} The Vietnamese snapshot mirrors the English catalog (${catalogSolutions(k).length} Solution Skill entries, ${treeLinks(k)} commit-pinned sources, versioning model). One copy defect is recorded as a low-severity finding without changing this verdict: the hero eyebrow reads ${q(k, 'NKSKILLS / DANH MỤ</p>')} where the navigation on the same page uses ${q(k, '>Danh mục</a>')}; the label appears truncated but does not prevent the task.`, [...C, e.audience]);
  else if (sols.includes(k)) R(k, 'quality-task-fit', 'pass', `${TASK[k]} The snapshot states the release status and its limit, the three components and their origin, the Quick-mode outputs, prerequisites (Solution Skill, codegraph, rtk, valid CodeGraph index), the absence of a direct archive download, and links to both host guides, the manifest and the release record. The inferred decision task is served. Accuracy of those statements is not verified here (quality-claims unknown).`, [...C, e.audience]);
  else if (guides.includes(k)) R(k, 'quality-task-fit', 'pass', `${TASK[k]} The guide gives prerequisites, ordered build and install commands with the host-specific --target (${targets(k).join(', ')}), the invocation tokens (${invocations(k).join('; ')}), and review advice, for all three workflows. The procedure is complete as written for the inferred task. Caveats, not failures: the prerequisites paragraph says the Problem presentation trial is at the end of the guide although the Content search audit section follows it; ${k.startsWith('en') ? `one sentence has a stray comma (${q(k, k === 'enCodex' ? 'open Codex, at that project and invoke' : 'open Claude Code, at that project and invoke')})` : 'wording was read in Vietnamese and is intelligible'}. Whether the commands work was not tested (no repository access; quality-claims unknown).`, [...C, e.audience]);
  else R(k, 'quality-task-fit', 'pass', `${TASK[k]} The plain-text file names each font, its author and its licence (SIL Open Font License 1.1) for Fraunces, Source Sans 3 and IBM Plex Mono, which answers the inferred question. Caveat: the three "Full notice" files are named without URLs, so the full licence texts are not reachable from this file as captured (see portfolio-journey-links, unknown).`, [...C, e.audience]);

  const claimNeed = 'No dated authoritative source was collected: the GitHub release records, manifests, catalog.yaml and technical guide that the page cites are outside the single allowed origin and are recorded as external exclusions.';
  R(k, 'quality-claims', 'unknown', html ? `${claimNeed} Material claims present in this snapshot and left unverified: workflow versions and release status, component and upstream licences/revisions, prerequisites, host support, and (on guides) the build/install commands. ${homes.includes(k) ? 'An internal count inconsistency on this page is established from the site itself and recorded under aio-entity-consistency. ' : ''}Unverifiable is not false; evidence needed: the cited repository records at a dated commit.` : `${claimNeed} The font authorship and licence statements could not be compared with the OFL notice files they name (not hyperlinked, not collected) or with the fonts actually served.`, C);
  R(k, 'quality-freshness', 'unknown', html ? `The snapshot carries version labels (${versions(k).join(', ') || 'none'}) but no publication or last-updated date, and the captured response has no Last-Modified header. No dated source was supplied to judge whether these versions and statuses are current.` : 'No date in the file and no Last-Modified header in the captured response (ETag only); currency of the font notices cannot be judged without the served font files and their notices.', [...C, e.http]);
  if (html) R(k, 'quality-accessible-media', 'pass', `Raw-source media inventory: ${mediaInventory(k).elements.length} media element(s). The only image is the header logo with an empty alt inside a link that carries aria-label (${q(k, (p.html.match(/<a class="brand"[^>]*>/) || [""])[0])}), which is an appropriate decorative treatment. ${p.ids.has('workflow-description') ? `The one diagram is an HTML figure with role="img", an aria-label and a full text description (${q(k, 'aria-describedby="workflow-description"')}); the other illustrative panels are aria-hidden and repeat information given in adjacent text. ` : ''}No audio or video is present. Limits: CSS background images, the og:image file and rendered output were not collected.`, [...C, e.media]);
  else R(k, 'quality-accessible-media', 'not-applicable', 'The captured response is text/plain with no media elements of any kind, so there is no informative media needing a text alternative or transcript.', [...C, e.media, e.http]);

  // ---- seo
  R(k, 'seo-index-controls', 'unknown', `Observed: no robots meta tag in the captured source, no X-Robots-Tag header in the captured response (the collector retains that header when sent), and robots.txt allows this URL for all agents. Publisher intent for indexing and snippets of this URL was not supplied, so observed controls cannot be compared with intent; rendered-DOM directives and actual index status are also unobserved.`, [...C, e.http, ...e.robots]);
  if (html) R(k, 'seo-canonical', 'pass', k === 'root' ? `The declared URL answers HTTP 308 to ${p.finalUrl}; the served document declares rel=canonical ${canonicalOf(k)} and og:url ${meta(k, 'og:url')}, both equal to the final response URL. Redirect and canonical point to the same target and no competing declaration was captured. The redirect is language-independent as captured (anonymous request, no Accept-Language variation tested). This is the declared canonical only; the engine-selected canonical is unobserved.` : `The captured source declares rel=canonical ${canonicalOf(k)}, equal to the final response URL and to og:url; no redirect, no HTTP Link header and no other captured item declares the same canonical${k === 'enHome' ? ' except the / alias, which redirects here' : ''}. The ${isVi(k) ? 'Vietnamese' : 'English'} variant is self-canonical, so the locale variant is preserved. This is the declared canonical only; the engine-selected canonical is unobserved.`, [...C, e.canonical]);
  else R(k, 'seo-canonical', 'unknown', 'No canonical is declared: the captured response has no HTTP Link header (the collector retains it when sent) and text/plain cannot carry a link element. No variants of this URL were discovered. Whether the publisher intends this file to be indexed or canonicalised is not supplied, so no conflict can be assessed.', [...C, e.canonical]);
  if (homes.includes(k)) R(k, 'seo-metadata', 'pass', `Title ${q(k, `<title>${p.html.match(/<title>([\s\S]*?)<\/title>/)[1]}</title>`)} names the brand, the product category and both hosts, matching the page. The meta description is present and accurate for what it names. Caveat (optional improvement, not a failure): the description names two workflows, ${q(k, isVi(k) ? 'codebase-onboarding bản kỹ thuật và problem-presentation đang đánh giá' : 'the codebase-onboarding technical release and the problem-presentation evaluation candidate')}, while the page also presents Content search audit; this is handled with the stale summary strip under aio-entity-consistency. Headings follow one h1 and descriptive h2/h3 per section. No length rule applied.`, [...C, e.audience]);
  else if (guides.includes(k)) R(k, 'seo-metadata', 'pass', `Title "${p.title}" and the h1 state the task and host accurately; h2 headings describe each step. The meta description is accurate for what it names. Caveat (optional improvement, not a failure): the description names codebase onboarding and the presentation candidate but not the Content search audit section (${q(k, 'id="content-search-audit"')}) that the home and catalog pages deep-link to.`, [...C, e.audience]);
  else if (html) R(k, 'seo-metadata', 'pass', `Title "${p.title}", the meta description and the h1 "${p.headings[0].slice(4)}" describe the page's actual content and task; og:title and og:description repeat them. No misleading or duplicated title was found against the other captured pages (all ${htmlKeys.length} HTML titles are distinct except the / alias of /en/). No length rule applied.`, [...C, e.audience]);
  else R(k, 'seo-metadata', 'not-applicable', 'The item is a text/plain file: it has no title element, meta description or headings to review. Its first line, "NKSkills site font notices", describes the content.', [...C, e.audience, e.http]);
  R(k, 'seo-internal-links', 'pass', `Within the declared static graph: ${k === 'root' ? 'this is the crawl seed; no captured page links to / itself because all internal links use the /en/ or /vi/ paths, and / redirects to /en/' : `${inbound(k).length} other captured page(s) link here`}. ${html ? `All ${internalTargets(k).length} distinct internal target pages are in the captured inventory and returned HTTP 200, and every internal fragment link resolves to an element id present in the captured target source.` : 'The file has no hyperlinks (text/plain).'} Limits: discovery is incomplete (rendered navigation, sitemap, CMS and orphan pages not supplied), so this does not show that no other page is orphaned; external targets and asset URLs were not requested.`, [...C, e.links]);
  if (html) R(k, 'seo-structured-data', 'unknown', `No JSON-LD, microdata or RDFa is present in the raw captured source (Open Graph meta tags only), so there is nothing to compare with visible claims. Raw absence does not establish rendered absence: ${p.scripts.length} script element(s) were not fetched or executed and no rendered DOM was authorised. Structured data is optional; absence in raw source is an observation, not a defect.`, [...C, e.schema]);
  else R(k, 'seo-structured-data', 'not-applicable', 'A text/plain response cannot embed JSON-LD, microdata or RDFa, and no script runs for it; the captured response also has no Link header. Structured-data comparison does not apply to this item.', [...C, e.schema, e.http]);
  if (html) R(k, 'seo-locales', 'pass', `html lang="${p.lang}" matches the language of the captured text. The source declares hreflang en, vi and x-default (${alternates(k).map((a) => `${a.hreflang}=${a.href.replace(B, '')}`).join(', ')}), including a self-reference; the counterpart snapshot was captured, has the expected lang, and links back with the reciprocal annotation. Canonical is self-referencing per locale, so it does not conflict with the alternates. A visible language switch link is present.${k === 'root' ? ' The / URL serves the English document after its redirect, consistent with x-default pointing to /en/.' : ''}${k === 'viCat' ? ' The truncated Vietnamese eyebrow label is recorded as a separate copy finding.' : ''}${k === 'viHome' ? ' Some illustrative labels inside aria-hidden panels remain in English on the Vietnamese page; they are decorative.' : ''} Limits: annotations verified between captured snapshots only; engine language selection is unobserved.`, [...C, e.locale]);
  else R(k, 'seo-locales', 'not-applicable', 'No locale variant of this file was declared or discovered: it is a single English-language font notice linked from the footers of both language versions, with no hreflang Link header. There is no locale relationship to check for reciprocity or conflict.', [...C, e.locale]);
  R(k, 'seo-rendering', 'unknown', html ? `No rendered DOM was captured: browser and script execution are outside the authorised scope. ${p.scripts.map((s) => s.src).join(' and ')} ${p.scripts.length > 1 ? 'were' : 'was'} not fetched or executed. ${homes.includes(k) ? 'The starter-prompt host/language switch and copy button depend on /scripts/prompt-picker.js; the alternative prompts sit in inert template elements in raw source. ' : ''}Main content is present in the raw server response, but equivalence with rendered output is unknown.` : 'No rendered capture was authorised. The item is text/plain and references no scripts, but how a browser presents it was not observed.', C);
  // ---- aio
  R(k, 'aio-crawler-policy', 'unknown', `Captured robots.txt (HTTP 200) has one group, "User-agent: *" with "Allow: /", and a Sitemap line; this URL is allowed for every agent and there is no AI-crawler-specific group. The publisher's intent for search discovery, model-training crawlers and user-triggered retrieval was not supplied, so the policy cannot be compared with intent. Permission is not evidence that any crawler fetched the page.`, [...e.robots]);
  if (homes.includes(k)) {
    const s = proofStrip(k); const cards = homeCards(k); const cand = cards.filter((c) => /CANDIDATE|ỨNG VIÊN/.test(c.status)).length;
    R(k, 'aio-entity-consistency', 'fail', `The summary strip in this snapshot states ${q(k, s[0].raw)} and ${q(k, s[2].raw)}, but the same page presents ${cards.length} Solution Skill cards (${cardText(k)}), ${cand} of them labelled as evaluation candidates, including ${q(k, '<span>NK / SOLUTION 003</span><span>v0.1.32</span>')}. The catalog snapshot states ${q(isVi(k) ? 'viCat' : 'enCat', catalogChips(isVi(k) ? 'viCat' : 'enCat')[0].raw)} and lists the same three. The count of Solution Skills and of evaluation candidates therefore differs within the page and across pages. Names, versions (1.1.0, 0.1.0, 0.1.32), statuses and hosts are otherwise consistent across the captured pages. Which number is correct is for the owner to confirm; no external record was collected.`, [...C, e.entity]);
  } else if (k === 'readme') R(k, 'aio-entity-consistency', 'unknown', 'The file uses the brand name NKSkills consistently with the site. Its font, author and licence facts cannot be compared with any record: the stylesheet, font files and the three named OFL notice files were not collected. The HTML head preloads Fraunces and Source Sans 3 fonts, which is compatible with the notice, but IBM Plex Mono usage was not observable.', [...C, e.entity]);
  else R(k, 'aio-entity-consistency', 'pass', `Compared with the site-derived entity record: brand name, host names, workflow names, versions (${versions(k).join(', ')}) and release statuses in this snapshot agree with every other captured page that states them${cats.includes(k) ? `; the index chips (${catalogChips(k).map((c) => `${c.n} ${c.label}`).join(', ')}) match the ${catalogSolutions(k).length} Solution Skill entries and ${treeLinks(k)} pinned source links listed on the page` : ''}${guides.includes(k) ? `; build output names (${buildCommands(k).join(', ')}) carry the same versions` : ''}. Scope of this pass: internal consistency across captured pages only. The record is site-derived; agreement with the external release records and manifests is not verified.`, [...C, e.entity]);
  R(k, 'aio-retrievable-facts', 'pass', html ? `The facts a reader needs for the inferred task are present as text in the raw server response without script execution: ${homes.includes(k) ? 'brand and category, supported hosts, each workflow with version, status and stated limit, install outline, the default starter prompt and FAQ answers (inside details elements)' : cats.includes(k) ? 'each Solution Skill with version and status, each upstream with licence and short revision, and the versioning model' : sols.includes(k) ? 'version, status and limits, components, outputs and prerequisites' : 'prerequisites, exact commands in pre/code blocks, invocation tokens and limits'}. Each fact sits next to its qualifying context (status label or limit sentence). ${homes.includes(k) ? 'Exception noted: the summary strip gives a count that conflicts with the listed workflows (aio-entity-consistency). ' : ''}Readable facts do not show that any engine retrieved or cited them.` : 'The font names, authors and licence are plain text in the response body and readable without any processing. The full notices are referenced by file name only. Readable facts do not show that any engine retrieved or cited them.', [...C, e.audience]);
  // ---- aeo
  const noQ = 'No question set from search, support, sales or customer evidence was supplied, so real questions cannot be mapped to passages.';
  R(k, 'aeo-question-coverage', 'unknown', `${noQ}${homes.includes(k) ? ' The page has a four-item FAQ written by the publisher; those are publisher-chosen questions, not evidenced user questions, and were not used to resolve this check.' : ''} Evidence needed: an owner-supplied or exported question list for the ${isVi(k) ? 'Vietnamese' : 'English'} audience.`, C);
  R(k, 'aeo-answer-context', 'unknown', `${noQ} Without them, which passages count as answers is undetermined.${homes.includes(k) ? ' Observation only: each FAQ answer in the snapshot restates its subject and condition and can be read on its own.' : ''}`, C);
  R(k, 'aeo-answer-evidence', 'unknown', 'Source support for answer claims cannot be inspected: the release records, manifests and guides the page links to as evidence are on an origin outside the authorised scope and were not collected.', C);
  // ---- geo
  for (const r of ['geo-observed-presence', 'geo-answer-accuracy', 'geo-cohort-validity']) R(k, r, 'unknown', 'No AI response observations, prompt cohort or citation captures were supplied or collected; no Google AI Overviews or other AI-surface measurements exist for this audit. Mentions, citations and answer accuracy are unmeasured, not zero. Readiness checks do not substitute for this measurement.', []);
  // ---- portfolio (local)
  R(k, 'portfolio-task-gaps', 'unknown', 'No customer questions, search queries or support themes were supplied to map audience tasks to the inventory, and discovery is incomplete (scopeComplete=false). Any gap named without that evidence would be speculative. Observation only: Problem presentation and Content search audit have no on-site solution page; their detail links go to the catalog, a guide section or GitHub.', [...C, e.inventory]);
  R(k, 'portfolio-duplication', 'pass', k === 'root' ? 'The / snapshot is byte-identical to /en/ because / answers with a 308 redirect to /en/ and the canonical points to /en/; this is a redirect alias, not a competing duplicate page.' : guides.includes(k) ? `This guide overlaps heavily with the ${k.includes('Codex') ? 'Claude Code' : 'Codex'} guide in the same language, but the two differ in the facts that matter for the task (host name, --target ${targets(k).join('/')}, invocation tokens ${invocations(k).map((i) => i.split(': ')[1]).join(', ')}), and each is self-canonical. They are legitimate host variants; the ${isVi(k) ? 'English' : 'Vietnamese'} counterpart is a legitimate locale variant. No consolidation is proposed. Cannibalisation cannot be assessed without query data.` : html ? `Within the 12-item inventory this page has one ${isVi(k) ? 'English' : 'Vietnamese'} counterpart, declared through reciprocal hreflang and self-canonical, which is a legitimate locale variant${k === 'enHome' ? '; the / URL is a redirect alias of this page' : ''}. No other captured page covers the same task. Cannibalisation cannot be assessed without query data.` : 'No other captured item covers font licence notices; there is no overlapping page in the inventory.', [...C, e.inventory]);
  if (homes.includes(k)) R(k, 'portfolio-contradictions', 'fail', `Same defect as aio-entity-consistency for this item (one finding): the home summary strip says ${stripText(k)}, while this page lists ${homeCards(k).length} Solution Skills and the ${isVi(k) ? 'Vietnamese' : 'English'} catalog index states ${catalogChips(isVi(k) ? 'viCat' : 'enCat')[0].n} ${catalogChips(isVi(k) ? 'viCat' : 'enCat')[0].label}. No date, market or version difference explains the two numbers: both snapshots were captured within the same minute and describe the same catalogue.`, [...C, e.entity, e.inventory]);
  else if (k === 'readme') R(k, 'portfolio-contradictions', 'pass', 'No other captured page makes a statement about site fonts or their licences, and this file makes no statement about workflows, versions or hosts, so it conflicts with nothing in the captured inventory. Scope: captured pages only; the notices themselves are unverified (quality-claims unknown).', [...C, e.entity, e.inventory]);
  else R(k, 'portfolio-contradictions', 'pass', `No material claim in this snapshot conflicts with another captured page: workflow names, versions, statuses, hosts, prerequisites and the "no direct-download archive" statement agree wherever they are repeated, in both languages${cats.includes(k) ? '. The catalog count of three Solution Skills is internally consistent; the conflicting count is on the home pages, where the finding is recorded' : ''}. Scope: captured pages only; conflicts with the external release records were not checked.`, [...C, e.entity, e.inventory]);
  if (homes.includes(k) || cats.includes(k)) {
    const a = auditLink(k)[0];
    R(k, 'portfolio-journey-links', 'fail', `The Content search audit entry on this page offers one install link, ${q(k, `href="${a.href}"`)}, which leads to the Codex guide section. The owner context names Codex and Claude Code users as the audience, and a matching section exists in the captured Claude Code guide (id="content-search-audit"), but this entry does not link to it and the captured Codex guide has no link to the Claude Code guide. A Claude Code reader following this entry lands on Codex-specific commands (--target codex, $content-search-audit). Other journeys on the page are intact: ${homes.includes(k) ? `both host guides are linked elsewhere on the page (${hostGuideLinks(k).join(', ')}) and the codebase-onboarding card links to its solution page` : 'the codebase-onboarding entry links to its solution page'}. Effect on search ranking is not claimed.`, [...C, e.links, e.audience]);
  } else if (sols.includes(k)) R(k, 'portfolio-journey-links', 'pass', `The next steps for the inferred decision task are linked: both host guides (${hostGuideLinks(k).join(', ')}), the home page via breadcrumb, the catalog via navigation, and the manifest, release record and technical setup on GitHub. ${inbound(k).length} captured pages link to this page. External targets were not requested.`, [...C, e.links, e.audience]);
  else if (guides.includes(k)) R(k, 'portfolio-journey-links', 'pass', `From this guide the reader can reach the starter prompt (${q(k, isVi(k) ? 'href="/vi/#try-it"' : 'href="/en/#try-it"')}), the install overview via breadcrumb, the catalog via navigation, the same guide in the other language, and the technical guide, evaluation and release records on GitHub; all internal targets and fragments resolve in captured source. Caveat (preference, not a failure): the guide links neither to the other host's guide nor to the codebase-onboarding solution page; both are reachable through the home page and catalog. The single-host routing of Content search audit entries is recorded on the linking pages.`, [...C, e.links, e.audience]);
  else R(k, 'portfolio-journey-links', 'unknown', `${inbound(k).length} captured pages link to this file from their footers. The file's own next step, the three "Full notice" files it names, is given as bare file names in plain text; they are not hyperlinks, were not discovered by static link traversal and were not collected, so whether a reader can reach them is unverified. There is no route back to the site from a text/plain response other than browser navigation. Evidence needed: an authorised capture of the three notice URLs.`, [...C, e.links, e.audience]);
}

// ---------- findings ----------
const fEv = (ks, kinds) => ks.flatMap((k) => kinds.map((kind) => E[k][kind]));
const findings = [
  {
    findingId: 'home-solution-count-stale', title: 'Home summary strip and description count two Solution Skills while the page and catalog list three',
    affectedItemIds: homes.map((k) => P[k].itemId), ruleIds: ['aio-entity-consistency', 'portfolio-contradictions'], dimensions: ['aio', 'portfolio'],
    evidenceIds: fEv(homes, ['content', 'entity', 'inventory']), severity: 'medium', confidence: 'high', classification: 'observed',
    observation: `EN home (/ and /en/, identical content): strip reads "${stripText('enHome')}"; cards: ${cardText('enHome')}. VI home: strip reads "${stripText('viHome')}"; cards: ${cardText('viHome')}. Catalog index (EN and VI): ${catalogChips('enCat')[0].n} Solution Skills. The home meta and og descriptions also name only codebase-onboarding and problem-presentation.`,
    remediation: 'Update the home summary strip in both languages so its counts match the Solution Skills actually listed (as captured: three Solution Skills, one technical release, two evaluation candidates), and bring the home meta/og description in line by naming all three or describing them generically. If the strip is meant to count something narrower, label it so. This is a proposal; no site change was made by the audit.',
    actionCondition: 'the owner confirms that Content search audit 0.1.32 is meant to count as a Solution Skill, as the home cards and the catalog present it',
    verification: 'Re-capture /en/ and /vi/ and compare the strip counts with the number of solution cards on the page and with the "Solution Skills" chip on /en/catalog/ and /vi/catalog/; all three should agree in both languages.',
    ownerRole: 'Site content owner (EN and VI copy)', effort: 'small',
  },
  {
    findingId: 'vi-catalog-eyebrow-truncated', title: 'Vietnamese catalog hero label is truncated ("DANH MỤ")',
    affectedItemIds: [P.viCat.itemId], ruleIds: ['quality-task-fit'], dimensions: ['quality'], evidenceIds: fEv(['viCat'], ['content', 'audience']), severity: 'low', confidence: 'high', classification: 'observed',
    observation: 'The hero eyebrow on /vi/catalog/ reads "NKSKILLS / DANH MỤ" in raw source; the same page\'s navigation and footer use "Danh mục", and the English counterpart reads "NKSKILLS / CATALOG". The quality-task-fit check still passes; this is a copy defect, not a task blocker.',
    remediation: 'Correct the eyebrow text to "NKSKILLS / DANH MỤC" in the Vietnamese catalog source.',
    verification: 'Re-capture /vi/catalog/ and confirm the eyebrow paragraph contains the full word "DANH MỤC".', ownerRole: 'Site content owner (VI copy)', effort: 'small',
  },
  {
    findingId: 'content-search-audit-single-host-link', title: 'Content search audit entries link only to the Codex guide',
    affectedItemIds: [...homes, ...cats].map((k) => P[k].itemId), ruleIds: ['portfolio-journey-links'], dimensions: ['portfolio'], evidenceIds: fEv([...homes, ...cats], ['content', 'links', 'audience']), severity: 'low', confidence: 'high', classification: 'observed',
    observation: 'On the home pages (EN, VI and the / alias) and both catalog pages, the Content search audit entry has a single install link to /{lang}/guides/codex/#content-search-audit. The Claude Code guides contain the same section id but receive no link from these entries, and the Codex guides do not link to the Claude Code guides.',
    remediation: 'Add a second link from each Content search audit entry to /{lang}/guides/claude-code/#content-search-audit, or add a host switch between the two guides. This is a proposal; no site change was made by the audit.',
    verification: 'Re-capture the five linking pages and confirm each Content search audit entry exposes a link whose target is the Claude Code guide section, and that the fragment id exists in the captured guide source.',
    ownerRole: 'Site content owner', effort: 'small',
  },
];
// local finding contract uses title/remediation; keep observation text inside remediation context for the local renderer
for (const f of findings) { f.remediation = `${f.remediation} Observation: ${f.observation}`; delete f.observation; }

const bundle = { schemaVersion: 1, campaignId: manifest.campaignId, sourceManifestHash: sha(manifestBytes), parts: [{ path: PART, sourceSnapshotHash: index.partSnapshotHashes[PART], bundle: { reviews, evidence, artifacts, findings } }] };
fs.writeFileSync(outBundle, JSON.stringify(bundle, null, 2) + '\n', { flag: 'wx' });
const tally = {}; for (const r of reviews) tally[r.status] = (tally[r.status] ?? 0) + 1;
fs.writeFileSync(outFacts, JSON.stringify({ builtAt: NOW, reviews: reviews.length, tally, evidence: evidence.length, findings: findings.map((f) => f.findingId), parityRows, statusOf, proof: { en: proofStrip('enHome'), vi: proofStrip('viHome') }, cards: { en: homeCards('enHome'), vi: homeCards('viHome') }, chips: { en: catalogChips('enCat'), vi: catalogChips('viCat') }, catalogSolutions: { en: catalogSolutions('enCat'), vi: catalogSolutions('viCat') }, treeLinks: { en: treeLinks('enCat'), vi: treeLinks('viCat') }, inbound: Object.fromEntries(order.map((k) => [k, inbound(k).length])), uncaptured: Object.fromEntries(order.map((k) => [k, uncaptured(k)])), fragmentIssues: Object.fromEntries(order.map((k) => [k, fragmentIssues(k)])), titles: Object.fromEntries(order.map((k) => [k, P[k].title])) }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ builtAt: NOW, reviews: reviews.length, tally, evidence: evidence.length, findings: findings.length }));
