# NKSkills public pilot — supplemental summary (pilot-0131)

This note supplements the helper-generated report in `report-r1/` (report.md, report.html, content-actions.csv, coverage.json). Counts below are copied from the validated `report-r1/coverage.json`. It does not replace that report.

## Status

Partial. 12 declared items; 0 fully audited; 12 pending, 0 failed, 0 blocked, 0 unsupported, 0 excluded. Collected: 12 of 12. Missing checks: 0. Pending queue entries: 13. completionAllowed: false. Unresolved global rule: portfolio-task-gaps.

All 12 snapshots were read and reviewed, but no item is fully audited because every item still has checks that the supplied evidence cannot resolve.

| Dimension | Checks | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 60 | 35 | 24 | 1 |
| seo | 96 | 57 | 36 | 3 |
| aio | 36 | 23 | 13 | 0 |
| aeo | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 35 | 13 | 0 |

## Scope and discovery

- Sole origin: https://nkskills.getgroove.me. Static a[href] navigation from `/`, maxPages=30, maxDepth=5, no browser and no script execution.
- `initial-discovery/` validated first (1 capture, stopped at maxPages=1 with 6 unvisited pages queued), then continued with `discovery-resume` into `discovery-continued/`: 11 page captures, 12 inventory records (`/` and `/en/` are separate identities; `/` redirects 308 to `/en/`), frontier empty.
- No count or depth budget remains pending: 11 of 30 pages were used and no unvisited-page entry is left. No further `discovery-resume` is needed for this static scope.
- The discovery source is still `complete: false` and the campaign keeps scopeComplete=false. Open queue (13): 10 rendering-unreviewed pages (every HTML page), 1 page-extraction entry (README.txt is text/plain and was not parsed for links), source-incomplete, scope-unconfirmed.
- External exclusions: 98 link edges to 25 distinct github.com URLs, recorded and not requested.
- Not covered: rendered or script-generated navigation, CMS records, orphan pages, the sitemap that robots.txt declares (not a static-navigation source in this scope), and non-hyperlink resources (CSS, fonts, images, /scripts/prompt-picker.js, the three OFL notice files named in README.txt).

## Supported findings

### 1. Home summary counts two Solution Skills; page and catalog list three (medium, observed)

Affected: `/`, `/en/`, `/vi/`. Rules: aio-entity-consistency, portfolio-contradictions. Finding IDs: home-solution-count-stale (local), global-home-solution-count-contradiction (same defect at portfolio level).

English home, summary strip and third solution card:
- Q1 `<span><strong>02</strong> Solution Skills</span>` — ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1
- Q2 `<span><strong>01</strong> evaluation candidate</span>` — ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1
- Q3 `<span>NK / SOLUTION 003</span><span>v0.1.32</span>` — ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1

English catalog index:
- Q4 `<a href="#solutions">03 <span>Solution Skills</span></a>` — 5a5d590c6c69906f4df8412778c40f2fc03c7f034660ae682cbc01a0a7d9d62d.txt:1

Vietnamese home, same strip:
- Q5 `<span><strong>01</strong> ứng viên đánh giá</span>` — b828eaeefe1e0e1989d1f271c33b64bcd0a67859b50315299a688fd829ea725e.txt:1

The home meta description also names only two workflows. Proposed action, only if the owner confirms Content search audit 0.1.32 counts as a Solution Skill: align the strip (and description) in both languages with the three listed workflows. Verify by re-capturing the home and catalog pages and comparing the counts.

### 2. Content search audit entries link only to the Codex guide (low, observed)

Affected: `/`, `/en/`, `/vi/`, `/en/catalog/`, `/vi/catalog/`. Rule: portfolio-journey-links. Finding IDs: content-search-audit-single-host-link (local), global-content-search-audit-single-host-journey (same defect at portfolio level).

- Q7 `<a class="work-link" href="/en/guides/codex/#content-search-audit">Install and use ↗</a>` — ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1

The Claude Code guides contain the same section id but are not linked from these entries, and the two host guides do not link to each other. Proposed action: add the Claude Code link or a host switch. No ranking effect is claimed.

### 3. Vietnamese catalog hero label is truncated (low, observed)

Affected: `/vi/catalog/`. Finding ID: vi-catalog-eyebrow-truncated. The navigation on the same page uses "Danh mục".

- Q6 `<p class="eyebrow">NKSKILLS / DANH MỤ</p>` — 2c8f3fe152e34776360d6f3626209e21f14c53231dff311a760b5cd37dc2c69d.txt:1

## Clean results (narrow, raw-source judgments)

- All 12 URLs returned HTTP 200 (`/` after one 308 redirect); extracted text is non-empty for all 12.
- Canonical: the 11 HTML responses declare a self-referencing canonical equal to the final URL and og:url.
- Locales: the five EN/VI pairs carry reciprocal hreflang (en, vi, x-default) and matching html lang; pairs match on heading count, internal link count, external targets, code blocks and version strings.
- Internal links: every internal target is in the inventory and every fragment link resolves to an id in captured source.
- Workflow names, versions (1.1.0, 0.1.0, 0.1.32), statuses, hosts and commands agree across pages and languages, apart from finding 1.

Optional wording notes, not findings: home and guide meta descriptions do not mention Content search audit; English guides contain a stray comma ("open Codex, at that project"); Vietnamese pages keep the English aria-label "NKSkills home" on the logo link.

## Unknown and why

- Claims, freshness, answer evidence: the GitHub release records, manifests and catalog.yaml the pages cite are outside the allowed origin.
- Index controls, AI crawler policy: robots.txt allows all agents and no robots meta or X-Robots-Tag was captured, but publisher intent was not supplied.
- Rendering, structured data: no rendered DOM; raw source has no JSON-LD, microdata or RDFa.
- AEO question coverage and context, portfolio task gaps: no question or query set supplied.
- GEO (all three rules): no AI response observations. No Google AI Overviews measurements were supplied. Rankings, indexing, crawler logs, citations and conversions are unmeasured, not zero.

Quotes Q1–Q7 are exact substrings of the cited content snapshots under `campaign-r2/parts/000001/evidence/` (each HTML snapshot is a single line, so the locator is line 1); see `summary-quote-receipt.json`.
