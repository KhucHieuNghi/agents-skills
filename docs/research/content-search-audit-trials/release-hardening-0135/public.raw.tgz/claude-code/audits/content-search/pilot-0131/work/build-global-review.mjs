// Builds the attributed global portfolio review bundle against the reviewed campaign revision.
// Reads local validated artifacts only; no network access and no execution of target content.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const [campaignDir, indexDir, factsFile, outBundle] = process.argv.slice(2);
const sha = (v) => createHash('sha256').update(v).digest('hex');
const L = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const PART = 'parts/000001';
const index = JSON.parse(fs.readFileSync(path.join(indexDir, 'index.json'), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(campaignDir, 'campaign.json'), 'utf8'));
const inv = L(path.join(campaignDir, PART, 'inventory.jsonl'));
const ev = L(path.join(campaignDir, PART, 'evidence.jsonl'));
const checks = L(path.join(campaignDir, PART, 'checks.jsonl'));
const facts = JSON.parse(fs.readFileSync(factsFile, 'utf8'));
if (index.campaignId !== manifest.campaignId) throw new Error('Index does not belong to this campaign');
const NOW = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), AI host agent applying the packaged content-portfolio method; not a human domain reviewer';
const B = 'https://nkskills.getgroove.me';
const itemIds = manifest.itemIds;
const byUri = Object.fromEntries(inv.map((i) => [i.uri, i.itemId]));
const ref = (evidenceId) => ({ part: PART, evidenceId });
const of = (itemId, kind) => ev.filter((e) => e.itemId === itemId && e.kind === kind).map((e) => ref(e.evidenceId));
const all = (kind) => itemIds.flatMap((id) => of(id, kind));
const contentRefs = all('content');
if (contentRefs.length !== itemIds.length) throw new Error('Expected exactly one content snapshot per item');
const shared = (kind) => ev.find((e) => e.kind === kind && e.itemId === byUri[`${B}/`]).value.split('\n\nItem under comparison')[0];
const failed = (ruleId) => checks.filter((c) => c.ruleId === ruleId && c.status === 'fail').map((c) => c.itemId);
const uri = (id) => inv.find((i) => i.itemId === id).uri;

const OWNER = 'Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.';
const ctx = (evidenceId, kind, value, locator, sourceReferences) => ({ evidenceId, kind, value, snapshotHash: sha(value), locator, collectedAt: NOW, sourceReferences });
const linkLines = ev.filter((e) => e.kind === 'link-graph').map((e) => { const v = e.value.split('\n'); return `${v[0].replace('Item: ', '')} :: ${v[2]} :: ${v[5]} :: ${v[6]}`; });
const audit = ev.filter((e) => e.kind === 'link-graph').map((e) => { const item = e.value.split('\n')[0].replace('Item: ', ''); const hits = [...e.value.matchAll(/(\/(?:en|vi)\/guides\/(?:codex|claude-code)\/#content-search-audit) \| ([^;]*?) ;;/g)].map((m) => `${m[1]} "${m[2].trim()}"`); return `${item} -> ${hits.join(', ') || 'no link with fragment #content-search-audit'}`; });
const contextEvidence = [
  ctx('global-inventory-map', 'inventory-map', `${shared('inventory-map')}\n\nEN/VI structural parity (pairs compared on heading count, internal anchor count, external link targets, code blocks and version strings): ${JSON.stringify(facts.parityRows)}`, 'compiled from the reviewed campaign inventory and its 12 content snapshots', contentRefs),
  ctx('global-entity-record', 'entity-record', shared('entity-record'), 'compiled from the 12 captured content snapshots of https://nkskills.getgroove.me; site-derived, not an independent record', contentRefs),
  ctx('global-link-graph', 'link-graph', `STATIC INTERNAL LINK GRAPH SUMMARY (a[href] in captured raw source; external targets and assets not requested)\n${linkLines.join('\n')}\n\nLinks carrying the fragment #content-search-audit, per page:\n${audit.join('\n')}`, 'compiled from the per-item link-graph evidence in parts/000001', [...contentRefs, ...all('link-graph')]),
  ctx('global-audience-context', 'audience-context', `OWNER-SUPPLIED CONTEXT (quoted from the audit request received 2026-11-18): "${OWNER}" Per-page tasks used in this review are reviewer inferences from page content. No customer questions, search queries, personas or analytics were supplied.`, 'audit request task statement (business context), 2026-11-18', []),
];
const base = (ruleId, status, reason, evidenceReferences, contextEvidenceIds) => ({ ruleId, status, reason, reviewer: REVIEWER, reviewedAt: NOW, itemIds, evidenceReferences, contextEvidenceIds });
const contraItems = failed('portfolio-contradictions'); const journeyItems = failed('portfolio-journey-links');
const contraRefs = [...contentRefs, ...all('entity-record'), ...all('inventory-map')];
const journeyRefs = [...contentRefs, ...all('link-graph'), ...all('audience-context')];
const reviews = [
  base('portfolio-task-gaps', 'unknown', 'No customer questions, search queries, support themes or analytics were supplied, and discovery is incomplete (scopeComplete=false; rendered navigation, CMS records, orphan pages and the robots-declared sitemap are not in the union). The 12 items were mapped by purpose and stage, but a gap cannot be distinguished from a speculative opportunity without demand evidence. Observation only: Problem presentation 0.1.0 and Content search audit 0.1.32 have no on-site solution page, while Codebase onboarding 1.1.0 has one in each language. Evidence needed: an owner-supplied question or query list per language.', [...contentRefs, ...all('inventory-map')], ['global-inventory-map', 'global-audience-context']),
  base('portfolio-duplication', 'pass', 'All 12 content snapshots were compared. Overlap is limited to three legitimate patterns: (1) / is a 308 redirect alias of /en/ with canonical /en/, so its byte-identical snapshot is not a competing page; (2) five English/Vietnamese pairs are declared locale variants with reciprocal hreflang and self-canonicals, and they match on heading count, internal anchor count, external targets, code blocks and version strings; (3) the Codex and Claude Code guides in each language share structure but differ in host name, --target value and invocation tokens, and each is self-canonical. No two pages in the inventory serve the same task for the same audience, host and language, so no consolidation is proposed. Cannibalisation cannot be confirmed or excluded without query/page data, and pages outside the incomplete discovery union were not compared.', [...contentRefs, ...all('inventory-map')], ['global-inventory-map']),
  base('portfolio-contradictions', 'fail', `One material contradiction was found across the inventory: the home pages (/, /en/ and /vi/) state "02 Solution Skills" and one evaluation candidate in their summary strip, while the same pages list three Solution Skills (two labelled evaluation candidates) and both catalog pages state "03 Solution Skills" and list three. All snapshots were captured within the same minute, so no date, market or version difference explains it. This is the same defect as local finding home-solution-count-stale. Everything else repeated across pages agrees in both languages: workflow names, versions 1.1.0 / 0.1.0 / 0.1.32, release statuses, supported hosts, prerequisites, the statement that no direct-download archive is published, build output names and invocation tokens. English/Vietnamese reading found no conflicting claim; wording notes that do not change meaning: the Vietnamese catalog eyebrow is truncated (local finding vi-catalog-eyebrow-truncated), Vietnamese pages keep an English aria-label "NKSkills home" on the logo link and English labels inside decorative panels. Scope: captured pages against a site-derived entity record; the external release records and manifests were not collected, so truth of the agreed values is not established.`, contraRefs, ['global-entity-record', 'global-inventory-map']),
  base('portfolio-journey-links', 'fail', `Navigation between related tasks was checked on the static link graph of all 12 items with the owner-stated audience (Codex and Claude Code users, English and Vietnamese). Every internal target and fragment resolves in captured source, each HTML page offers a language switch to its counterpart, the home pages link to both host guides and to the solution page, and the solution pages link to both guides. One journey gap: on ${journeyItems.length} pages (${journeyItems.map((id) => uri(id).replace(B, '')).join(', ')}) the Content search audit entry links only to the Codex guide section, although the Claude Code guides contain the same section id, and the guides do not link to each other. This is the same defect as local finding content-search-audit-single-host-link. Unverified, not counted as a failure: README.txt names three full-notice files without links, and those URLs were not collected. Rendered or script-generated navigation was not observed. No ranking effect is claimed.`, journeyRefs, ['global-link-graph', 'global-audience-context']),
];
const findings = [
  {
    findingId: 'global-home-solution-count-contradiction', ruleId: 'portfolio-contradictions', severity: 'medium', confidence: 'high',
    observation: `Home pages (${contraItems.map((id) => uri(id).replace(B, '') || '/').join(', ')}) show a summary strip of "${facts.proof.en.map((s) => `${s.n} ${s.label}`).join(', ')}" (Vietnamese: "${facts.proof.vi.map((s) => `${s.n} ${s.label}`).join(', ')}") while listing three Solution Skills (${facts.cards.en.map((c) => `${c.name} ${c.version}`).join(', ')}); both catalog pages show "${facts.chips.en[0].n} ${facts.chips.en[0].label}". Portfolio-level view of local finding home-solution-count-stale; one defect, not two.`,
    recommendation: 'Update the home summary strip in both languages so its counts match the Solution Skills listed on the home and catalog pages (as captured: three Solution Skills, one technical release, two evaluation candidates), and align the home meta/og description. If the strip is meant to count something narrower, label it. Proposal only; the audit changed nothing.',
    actionCondition: 'the owner confirms that Content search audit 0.1.32 is meant to count as a Solution Skill, as the home cards and the catalog present it',
    verification: 'Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and confirm the strip counts, the number of home solution cards and the catalog "Solution Skills" chip agree in both languages.',
    affectedItemIds: contraItems, evidenceReferences: contraItems.flatMap((id) => [...of(id, 'content'), ...of(id, 'entity-record')]).concat(of(byUri[`${B}/en/catalog/`], 'content'), of(byUri[`${B}/vi/catalog/`], 'content')), ownerRole: 'Site content owner (EN and VI copy)', effort: 'small',
  },
  {
    findingId: 'global-content-search-audit-single-host-journey', ruleId: 'portfolio-journey-links', severity: 'low', confidence: 'high',
    observation: `On ${journeyItems.length} pages (${journeyItems.map((id) => uri(id).replace(B, '')).join(', ')}) the Content search audit entry has one install link, to /{lang}/guides/codex/#content-search-audit. The Claude Code guides contain the same section id and receive no link from these entries; Codex and Claude Code guides do not cross-link. Portfolio-level view of local finding content-search-audit-single-host-link; one defect, not two.`,
    recommendation: 'Add a second link from each Content search audit entry to /{lang}/guides/claude-code/#content-search-audit, or add a host switch between the two guides. Proposal only; the audit changed nothing.',
    verification: 'Re-capture the five linking pages and confirm each Content search audit entry exposes a link to the Claude Code guide section, and that the fragment id exists in the captured guide source.',
    affectedItemIds: journeyItems, evidenceReferences: journeyItems.flatMap((id) => [...of(id, 'content'), ...of(id, 'link-graph')]), ownerRole: 'Site content owner', effort: 'small',
  },
];
const bundle = { schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash, partSnapshotHashes: index.partSnapshotHashes, contextEvidence, reviews, findings };
fs.writeFileSync(outBundle, JSON.stringify(bundle, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ builtAt: NOW, reviews: reviews.map((r) => `${r.ruleId}:${r.status}`), contextEvidence: contextEvidence.length, findings: findings.map((f) => f.findingId), contraItems: contraItems.length, journeyItems: journeyItems.length }));
