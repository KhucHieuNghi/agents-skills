# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T04:23:39\.450Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 227285fc\-3e37\-44c4\-8ee9\-3e404cd94c5a\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 9befe3fb23d21e3c2acf01741af0784a38a6ceb190db01af47298e5aef91ebd4 | 05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb | local\-file | 2026\-11\-18T04:23:39\.423Z | 0 full elapsed days | [evidence/05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb\.txt](evidence/05e7dd87ed8a69a72028ccdf4da409cc85ec2b58bc7844aed724ff76febab2cb.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8da0a2cd5ad291be48a9f6a17879c17834fb8164e1606153dd342e30fd64ed54 | 0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa | local\-file | 2026\-11\-18T04:23:39\.424Z | 0 full elapsed days | [evidence/0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa\.txt](evidence/0e4e1cbb2a4976cd2bee64b609a7377149c48a8289316208dec03c9cb9e554aa.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2de852bc8b1d9a68165a77cfe89abe382508522a156bdf42f5e4a15cfbbf0f9b | 297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d | local\-file | 2026\-11\-18T04:23:39\.425Z | 0 full elapsed days | [evidence/297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d\.txt](evidence/297b051e0dd0fb7c79394fb0dcb626a5f27e05457bc9e41aa17dc0a6d8b9704d.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| df489406dae30038a486aba3902823d78bb0d5df2c895b40aa8efb583cfb5e4f | 425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11 | local\-file | 2026\-11\-18T04:23:39\.426Z | 0 full elapsed days | [evidence/425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11\.txt](evidence/425a6f3a0095da96e36581d2a39386b782adc8104ed876603e3063c24f4aec11.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2bed7646305935e889ce758b77e779e8be6aedd24e8c15d7fa4928dc4e86d7ed | 4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d | local\-file | 2026\-11\-18T04:23:39\.427Z | 0 full elapsed days | [evidence/4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d\.txt](evidence/4ff6b801e615fcf84bc1a3d96176e74b9a66dd27038f767b22ecb4847738746d.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 717c0bf07684e72b75eaa69278ab6bfab0d6f3cffee5e326ea8a00b4887117b9 | 521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290 | local\-file | 2026\-11\-18T04:23:39\.427Z | 0 full elapsed days | [evidence/521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290\.txt](evidence/521b7a09abc3a048c52bcb88bf18d4281b06c5741206658e3b3df637ba6d4290.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b54a5312a217010704300039b687a1c07bfef502f4188157b96dbea437d05d7d | 7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691 | local\-file | 2026\-11\-18T04:23:39\.428Z | 0 full elapsed days | [evidence/7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691\.txt](evidence/7a596d03147c13c4765bdd1d60443200f595586ed9490c08de4c6d10a9530691.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 341280a9bc9842555038c1744c35e1ae1d5dcc55f560ea781a153395e65e56ec | aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35 | local\-file | 2026\-11\-18T04:23:39\.429Z | 0 full elapsed days | [evidence/aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35\.txt](evidence/aba280d6f2d226ac0d483350b6201fc4581de65cfd9ec331fddaf31a63cf7b35.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1c3b424e1a947db7a18b1036c07d4392569eb44912960c98cd93966550cbc1ce | b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063 | local\-file | 2026\-11\-18T04:23:39\.429Z | 0 full elapsed days | [evidence/b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063\.txt](evidence/b57e7c1e32bcf40f921725dfe71cd6824c23bad33a761496fbbd8799a229b063.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 70787383ce98a11340d0ba6e6dda70c227d414a87ea25982bf06a861141ee70e | b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1 | local\-file | 2026\-11\-18T04:23:39\.430Z | 0 full elapsed days | [evidence/b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1\.txt](evidence/b6a83ce46f0820816132a01048a26cafa5391f1c491e6b9a5ce57c78d3d694b1.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
