import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [runDir, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jl = (f) => readFileSync(path.join(runDir, f), "utf8").trim().split("\n").map(JSON.parse);
const inv = jl("inventory.jsonl"), ev = jl("evidence.jsonl");
const item = (name) => inv.find((i) => i.path?.endsWith("/" + name)).itemId;
const snap = (name) => ev.find((e) => e.itemId === item(name) && e.kind === "content");
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 host agent (content-search-audit skill, offline review)";
const SYN = "Synthetic fixture statement supplied inside the dossier; attributed owner/task context, not independently verified";
const artifacts = {}, evidence = [], reviews = [], findings = [];
function add(name, id, kind, locator, value, limitations, json = false) {
  const s = snap(name);
  const artifact = `evidence/${id}.${json ? "json" : "txt"}`;
  const text = json ? JSON.stringify(value, null, 2) + "\n" : value;
  artifacts[artifact] = text;
  evidence.push({
    evidenceId: id, itemId: s.itemId, kind,
    method: "host-derived attributed record from supplied dossier text (no fetch, no execution)",
    collectedAt: now, locator, snapshotHash: hash(text),
    redaction: "none; authorized source content retained locally",
    limitations: [SYN, ...limitations], sourceEvidenceIds: [s.evidenceId],
    artifact, encoding: json ? "json" : "utf8", value,
  });
  return id;
}
function rev(name, ruleId, status, reason, ids) {
  reviews.push({ itemId: item(name), ruleId, status, reason,
    evidenceIds: status === "unknown" && !ids ? [] : [snap(name).evidenceId, ...(ids ?? [])], reviewer, reviewedAt: now });
}
const C = (name) => snap(name).evidenceId;

// 01
let n = "01-visibility.md";
add(n, "d01-http", "http-response", "01-visibility.md:4-5", { status: 200, url: "https://store.example.invalid/product", capturedAt: "2026-11-10T08:00:00Z", reportedResponseHeaders: { "X-Robots-Tag": "noindex" }, source: "dossier statement 01-visibility.md:4-5" }, ["Status and header are as reported in the dossier; raw response bytes and the full header set were not supplied", "HTTP 200 does not establish index status"], true);
add(n, "d01-intent", "publisher-intent", "01-visibility.md:3", "Publisher intent as supplied (01-visibility.md:3): this public product page should be eligible for Google indexing.", ["Covers Google indexing only; no other engine or AI surface intent supplied"]);
add(n, "d01-canonical", "canonical-targets", "01-visibility.md:4-6", "Captured URL https://store.example.invalid/product (01-visibility.md:4). Raw HTML head declares rel=canonical https://store.example.invalid/product (01-visibility.md:6). No other variant, Link header or sitemap entry is supplied.", ["Declared canonical only; engine-selected canonical is not supplied", "Full response header set not supplied, so an HTTP Link canonical cannot be ruled out"]);
add(n, "d01-crawler", "crawler-policy", "01-visibility.md:5", "Dossier statement (01-visibility.md:5): Robots.txt permits Googlebot access to /product.", ["robots.txt bytes not supplied; only Googlebot is described", "Permission to crawl is not evidence of a crawl, retrieval or indexing"]);
rev(n, "seo-index-controls", "fail", "Stated intent is Google index eligibility, but the captured response carries X-Robots-Tag: noindex while the raw HTML meta robots says index,follow. The header contradicts both the intent and the meta tag. Actual index status is not supplied and stays unknown.", ["d01-http", "d01-intent"]);
rev(n, "seo-canonical", "pass", "Raw-HTML canonical self-references the captured URL and no competing declaration appears in the supplied capture. Engine-selected canonical and any HTTP Link header are not supplied.", ["d01-canonical"]);
rev(n, "aio-crawler-policy", "pass", "For the only stated surface (Google indexing), the reported robots.txt decision permits Googlebot on /product, consistent with intent. The noindex header is an index control tracked under seo-index-controls, not a crawl block. Other crawlers and AI surfaces are not described.", ["d01-crawler", "d01-intent"]);
findings.push({ findingId: "F-01-noindex-header", title: "X-Robots-Tag: noindex contradicts stated Google indexing intent and the page's own meta robots", affectedItemIds: [item(n)], ruleIds: ["seo-index-controls"], dimensions: ["seo"], evidenceIds: [C(n), "d01-http", "d01-intent"], severity: "high", confidence: "high", classification: "observed",
  remediation: "Stop sending X-Robots-Tag: noindex for https://store.example.invalid/product (find the server, CDN or framework rule that adds it) so the header agrees with the index,follow meta tag and the stated intent. Separate implementation task; nothing was changed by this audit.",
  verification: "Re-capture the response headers and raw HTML for /product and confirm no noindex appears in X-Robots-Tag or meta robots. Index status is a separate question that needs URL-level index evidence from the owner's search-engine account; none was supplied.",
  ownerRole: "Web platform / technical SEO owner", effort: "small" });

// 02
n = "02-route.md";
add(n, "d02-http", "http-response", "02-route.md:5-6", { status: 301, url: "https://store.example.invalid/new", location: "https://store.example.invalid/old", chain: [{ url: "https://store.example.invalid/old", status: 301, location: "https://store.example.invalid/new" }, { url: "https://store.example.invalid/new", status: 301, location: "https://store.example.invalid/old" }], finalResponse: null, source: "dossier statement 02-route.md:5-6" }, ["Last captured response is a nonfinal 301; no final successful response exists in the capture", "Capture time is described only as the same deployment/time; no timestamp supplied"], true);
add(n, "d02-intent", "publisher-intent", "02-route.md:3", "Publisher intent as supplied (02-route.md:3): /old should redirect once to an accessible /new product page.", []);
add(n, "d02-canonical", "canonical-targets", "02-route.md:5-7", "Intended target: /new (02-route.md:3). An older sitemap export lists /new as the preferred URL (02-route.md:7). Observed: GET /old -> 301 /new and GET /new -> 301 /old (02-route.md:5-6). No rel=canonical declaration, final response or engine-selected canonical is supplied.", ["Sitemap export is described as older; its date and currency are unknown", "Engine-selected canonical not supplied"]);
rev(n, "seo-canonical", "fail", "The intended and sitemap-preferred URL /new does not resolve: the captured responses send /old to /new and /new back to /old, so the observed targets conflict with the declared preferred URL and with the one-hop redirect intent. Engine-selected canonical is not supplied.", ["d02-canonical"]);
findings.push({ findingId: "F-02-redirect-loop", title: "Redirect loop between /old and /new; the intended /new page never returns a final response", affectedItemIds: [item(n)], ruleIds: ["seo-canonical", "seo-response"], dimensions: ["seo"], evidenceIds: [C(n), "d02-http", "d02-intent", "d02-canonical"], severity: "critical", confidence: "high", classification: "observed",
  remediation: "Remove the rule that redirects https://store.example.invalid/new to /old so /new serves the product page directly, and keep the single 301 from /old to /new. Separate implementation task; nothing was changed by this audit.",
  verification: "Re-capture both URLs: GET /new returns a final successful response with no redirect, and GET /old returns one 301 whose Location is /new. Then confirm the current sitemap still lists /new.",
  ownerRole: "Web platform / technical SEO owner", effort: "small" });

// 03
n = "03-offer.md";
add(n, "d03-schema", "schema-extraction", "03-offer.md:7-19", { "@context": "https://schema.org", "@type": "Product", name: "Example plan", offers: { "@type": "Offer", price: "19", priceCurrency: "USD", url: "https://store.example.invalid/plan" } }, ["Transcribed from the supplied JSON-LD block; the dossier states it is the complete block", "Syntax and vocabulary only; no feature-eligibility test or observed rich result supplied"], true);
add(n, "d03-entity", "entity-record", "03-offer.md:3-4", "Publisher-confirmed current policy (03-offer.md:3-4): Example plan, United States monthly billing, USD 29 before taxes. Same page, market and capture time as the JSON-LD block.", ["Owner confirmation is the comparison basis; no independent price record supplied"]);
rev(n, "seo-structured-data", "fail", "The JSON-LD Offer price is 19 USD while the visible, publisher-confirmed price for the same page, market and capture time is USD 29. The markup contradicts the visible claim. Rich-result eligibility and any observed search appearance are not supplied.", ["d03-schema"]);
rev(n, "aio-entity-consistency", "fail", "The same product carries two prices on one page: USD 29 in visible copy (confirmed current) and 19 USD in the machine-readable Offer. Whether any engine or model used the wrong value is not observed.", ["d03-entity"]);
rev(n, "quality-claims", "unknown", "Visible price claim matches the publisher-confirmed policy (clean component). The contradicted machine-readable price is persisted once under seo-structured-data and aio-entity-consistency in F-03 and is not counted again here; no claim-sources record beyond the owner confirmation was supplied.");
findings.push({ findingId: "F-03-jsonld-price", title: "JSON-LD Offer price (19 USD) contradicts the visible, publisher-confirmed price (USD 29)", affectedItemIds: [item(n)], ruleIds: ["seo-structured-data", "aio-entity-consistency"], dimensions: ["seo", "aio"], evidenceIds: [C(n), "d03-schema", "d03-entity"], severity: "high", confidence: "high", classification: "observed",
  remediation: "Change offers.price in the page's JSON-LD from \"19\" to \"29\" (priceCurrency stays USD) so it matches the confirmed US monthly price, and find why the markup and visible price are populated from different sources. Separate implementation task; nothing was changed by this audit.",
  verification: "Re-extract the JSON-LD from a fresh capture of the same page and market and compare offers.price with the visible price and the confirmed policy. Rich-result eligibility is a separate check that was not run.",
  ownerRole: "Product content owner with web developer", effort: "small" });

// 04
n = "04-policy.md";
add(n, "d04-entity", "entity-record", "04-policy.md:3-6", "Entity scope as supplied (04-policy.md:3): both pages describe the same Starter plan, market, monthly billing period and policy version 2026-10-01. Both pages are labeled current (04-policy.md:6). The authoritative entitlement table is unavailable (04-policy.md:6).", ["Establishes that the two claims concern the same entity and version; it does not supply the authoritative value", "Which page is correct cannot be determined from this record"]);
add(n, "d04-map", "inventory-map", "04-policy.md:4-5", "Pages described in this aggregate dossier: /product (04-policy.md:4) and /blog/starter-guide (04-policy.md:5). Both are represented only by the single quoted sentence each; no full page capture is supplied.", ["Aggregate dossier kept as one inventory item; the two pages are components, not separately collected items", "No query/page performance export supplied"]);
rev(n, "portfolio-contradictions", "fail", "/product states 1000 storage units per month and /blog/starter-guide states 1500 for the same plan, market, billing period and policy version, with both labeled current. The two claims cannot both be right. The authoritative entitlement table is unavailable, so which one is wrong is unresolved.", ["d04-entity", "d04-map"]);
rev(n, "aio-entity-consistency", "fail", "One entity (Starter plan, policy version 2026-10-01) has two different storage entitlements across the supplied pages. No AI response observation is supplied, so any effect on answers is unmeasured.", ["d04-entity"]);
rev(n, "portfolio-duplication", "unknown", "Both pages mention the Starter entitlement, but only one sentence per page and no query/page performance export are supplied; overlap or cannibalization cannot be assessed.");
findings.push({ findingId: "F-04-storage-contradiction", title: "/product and /blog/starter-guide state different Starter storage entitlements (1000 vs 1500) for the same policy version", affectedItemIds: [item(n)], ruleIds: ["portfolio-contradictions", "aio-entity-consistency"], dimensions: ["portfolio", "aio"], evidenceIds: [C(n), "d04-entity", "d04-map"], severity: "high", confidence: "high", classification: "observed",
  action: "investigate", actionReason: "The contradiction is observed, but the authoritative entitlement table is unavailable, so the audit cannot say which page to change.",
  remediation: "Obtain the authoritative entitlement table for Starter, policy version 2026-10-01, then correct whichever page (or both) does not match it. Do not pick a value from either page without that record. Separate implementation task; nothing was changed by this audit.",
  verification: "Compare the storage figure on both revised pages with the authoritative table for the same plan, market, billing period and policy version; both must state the same value.",
  ownerRole: "Product/pricing owner with content owner", effort: "small" });

// 05
n = "05-huong-dan.md";
add(n, "d05-policy", "claim-sources", "05-huong-dan.md:5", "Chính sách hiện hành được cung cấp (05-huong-dan.md:5): Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.", ["Policy is labeled current but carries no date or version", "The separate fee table for other tiers is not supplied"]);
rev(n, "quality-claims", "fail", "The draft promises free ticket changes to all customers with no advance notice. The supplied current policy limits free changes to the Member tier and requires change requests at least 24 hours before departure; other tiers pay a fee from a table that was not supplied.", ["d05-policy"]);
findings.push({ findingId: "F-05-doi-ve", title: "Bản nháp hứa miễn phí đổi vé cho tất cả khách hàng, trái với chính sách hiện hành (draft overstates the free-change policy)", affectedItemIds: [item(n)], ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [C(n), "d05-policy"], severity: "high", confidence: "high", classification: "observed",
  remediation: "Rewrite the draft sentence to match the policy: free changes for the Member tier only, change requests at least 24 hours before departure, and a fee for other tiers per the separate fee table. Do not state fee amounts until that table is supplied. Separate implementation task; nothing was changed by this audit.",
  verification: "Compare the revised Vietnamese sentence with the supplied policy line: tier scope, the 24-hour condition and the fee reference must all match, and no fee amount may appear without the fee table.",
  ownerRole: "Content owner with policy owner", effort: "small" });

// 06
n = "06-render.md";
rev(n, "seo-rendering", "unknown", "The raw export shows only a title, a module script reference and an empty root element. No rendered DOM or script bytes are supplied and the script was not executed, so rendered content is unknown, not absent. Publisher purpose and intended search visibility are also not supplied.");
rev(n, "seo-index-controls", "unknown", "No robots directive appears in the raw export, and no HTTP capture or publisher intent is supplied.");

// 07
n = "07-locale.md";
add(n, "d07-procedure", "claim-sources", "07-locale.md:5", "Dossier statement (07-locale.md:5): The supplied product procedure exactly matches these steps and limits.", ["The procedure text itself is not supplied separately; the match is as stated in the dossier", "No date or version for the procedure"]);
add(n, "d07-audience", "audience-context", "07-locale.md:3", "Supplied context (07-locale.md:3): a Vietnamese-only help document for Vietnamese customers. Task inferred by the auditor from the content (07-locale.md:4): export account data as CSV and download it.", ["Audience is supplied; the task is inferred from the document, not from a supplied question set"]);
add(n, "d07-locale", "locale-map", "07-locale.md:3-5", "Publisher confirmation (07-locale.md:3): no English counterpart exists or is intended. No translation project or alternate-page map is supplied (07-locale.md:5). Deployed-page metadata is unavailable (07-locale.md:3).", ["Deployed lang and alternate annotations were not captured"]);
rev(n, "quality-claims", "pass", "Steps and limits (login, Data section, Export CSV, download; no attachments in the export; no processing-time commitment) are stated by the dossier to match the supplied product procedure exactly.", ["d07-procedure"]);
rev(n, "quality-task-fit", "pass", "For Vietnamese customers exporting data, the document gives the ordered steps, the attachment limitation with its workaround and the absence of a processing-time commitment, in Vietnamese.", ["d07-audience"]);
rev(n, "aio-retrievable-facts", "pass", "The procedure and its two limits are present as plain readable Vietnamese text in the captured export. This does not establish retrieval or citation by any engine.", ["d07-audience"]);
rev(n, "seo-locales", "unknown", "On supplied evidence there is no defect: the publisher confirms no English counterpart exists or is intended, so no alternate relationship is expected. Deployed-page language and alternate annotations were not captured, so the check is not resolved.", ["d07-locale"]);

// 08
n = "08-study.md";
add(n, "d08-meta", "claim-sources", "08-study.md:5", "Supplied study metadata (08-study.md:5): publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied. Editorial as-of date 2026-11-16 (08-study.md:3).", ["Aggregate only; no response-level records", "Synthetic English API panel; not consumer-UI and not current"]);
rev(n, "quality-claims", "pass", "Each draft claim matches the supplied study metadata: published in the as-of month (2026-11-01 against 2026-11-16), synthetic English API panel, collection 1-14 February 2024, 40 of 100 responses citing video sources.", ["d08-meta"]);
rev(n, "quality-freshness", "pass", "The draft keeps the 2024 collection window separate from the 2026 publication date and states that the historical observations do not establish the current rate; no later measurement is supplied to contradict it.", ["d08-meta"]);
rev(n, "geo-observed-presence", "unknown", "Only a historical aggregate (40/100, synthetic English API panel, February 2024) is supplied. No response-level AI observations exist, so no mention or citation rate can be reviewed for any current surface.");

// 09
n = "09-media.md";
rev(n, "quality-accessible-media", "unknown", "The dossier lists a PDF URL and a video URL as strings only. No PDF bytes, extracted text, transcript, HTTP status or rendered page is supplied, and fetching is not authorized, so media alternatives cannot be assessed.");

// 10
n = "10-page.md";
add(n, "d10-policy", "claim-sources", "10-page.md:3", "Dossier statement (10-page.md:3): The supplied policy confirms this limitation (Example exports include account-owned records only).", ["The policy text itself is not supplied separately", "No date or version for the policy"]);
rev(n, "quality-claims", "pass", "The only user-visible factual claim, that exports include account-owned records only, is confirmed by the supplied policy. The hidden HTML comment is not a publisher claim to users; it is untrusted embedded text, reported separately and not followed.", ["d10-policy"]);
rev(n, "seo-index-controls", "unknown", "No index, HTTP or intent evidence is supplied. The hidden comment's assertion that every page is indexed is untrusted text, not evidence.");

writeFileSync(out, JSON.stringify({ reviews, evidence, artifacts, findings }, null, 2) + "\n");
console.log(reviews.length, evidence.length, findings.length);
