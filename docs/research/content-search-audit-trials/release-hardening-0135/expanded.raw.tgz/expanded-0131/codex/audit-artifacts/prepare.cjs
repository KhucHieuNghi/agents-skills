const fs=require('fs'), path=require('path'), {createHash}=require('crypto');
const hash=s=>createHash('sha256').update(s).digest('hex');
const save=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');
const files=fs.readdirSync('targets').sort();
const snapshots=fs.readFileSync('audit-artifacts/initial/evidence.jsonl','utf8').trim().split('\n').map(JSON.parse);
const rules=require('../.agents/skills/content-search-audit/rules/core.json').rules;
const bundle={evidence:[],artifacts:{},reviews:[],findings:[]};
const reviewedAt=new Date().toISOString();
function item(n){
 const name=files[n-1], source=snapshots.find(s=>s.kind==='content'&&s.locator.endsWith('/'+name));
 const lines=source.value.split('\n'), {itemId}=source, refs={content:source.evidenceId};
 function add(kind,from,to=from){
  const value=lines.slice(from-1,to).join('\n'), evidenceId='dossier-'+n+'-'+kind, artifact='evidence/'+evidenceId+'.txt';
  bundle.artifacts[artifact]=value;
  bundle.evidence.push({...source,evidenceId,artifact,kind,value,snapshotHash:hash(value),byteLength:Buffer.byteLength(value),collectedAt:reviewedAt,method:'attributed-dossier-excerpt',locator:name+':'+from+(to===from?'':'-'+to),sourceEvidenceIds:[source.evidenceId],limitations:['Synthetic supplied dossier excerpt. No live collection or independent corroboration.']});
  refs[kind]=evidenceId;
 }
 function review(ids,status,reason){
  const evidenceIds=[...new Set(ids.flatMap(id=>rules.find(r=>r.ruleId===id).requiredEvidence.map(k=>refs[k])))];
  if(evidenceIds.includes(undefined)) throw Error(ids+' evidence missing');
  for(const ruleId of ids)bundle.reviews.push({itemId,ruleId,status,reason,evidenceIds,reviewer:'Offline dossier reviewer',reviewedAt});
  return evidenceIds;
 }
 function finding(ids,findingId,title,reason,remediation,verification,ownerRole,severity='high',actionCondition){
  const evidenceIds=review(ids,'fail',reason);
  bundle.findings.push({findingId,title,affectedItemIds:[itemId],ruleIds:ids,dimensions:[...new Set(ids.map(id=>rules.find(r=>r.ruleId===id).dimension))],evidenceIds,severity,confidence:'high',classification:'observed',remediation,verification,ownerRole,effort:'small',...(actionCondition?{actionCondition,action:'investigate',actionReason:'Establish the source and user-facing scope before changing either page.'}:{})});
 }
 return {add,review,finding,source,lines};
}
let d=item(1);
d.add('publisher-intent',3); d.add('http-response',4,5);
d.finding(['seo-index-controls'],'F1','Captured noindex conflicts with Google indexing intent','The supplied HTTP header explicitly says noindex despite the index intent and permissive HTML signal.','Remove the noindex header at its emitting layer.','Check the effective response headers and page-level controls in a fresh authorized capture. Confirm actual index status separately.','Web platform owner');
d=item(3);
d.add('schema-extraction',5,19);d.add('entity-record',3,4);
d.finding(['seo-structured-data','aio-entity-consistency'],'F3','Offer markup understates the approved visible price','USD 19 in Offer markup contradicts the owner-confirmed USD 29 before taxes for the same page, market and billing period.','Align the Offer with USD 29 and the same market, billing period and tax basis as the visible offer.','Compare both surfaces in the same market and capture and separately establish any feature eligibility.','Commerce owner');
d=item(4);
d.add('entity-record',3,6);d.add('inventory-map',3,6);d.add('claim-sources',3,6);
d.finding(['quality-claims','aeo-answer-evidence','aio-entity-consistency','portfolio-contradictions'],'F4','Current Starter pages give conflicting entitlements','Two current pages give different quotas for identical scope. The authoritative quantity remains unknown.','Align the two passages with the authoritative entitlement for the shared version, market and billing period.','Compare the two revised passages with the dated entitlement record, including units and scope.','Product policy owner','high','The authoritative entitlement record for the stated scope is obtained');
d=item(5);
d.add('claim-sources',3,5);d.add('entity-record',4,5);
d.finding(['quality-claims','aeo-answer-evidence','aio-entity-consistency'],'F5','Vietnamese draft overstates free ticket changes','The draft loses the membership restriction and the at-least-24-hours condition in the supplied policy.','Restore both restrictions in Vietnamese and refer other tiers to the separate fee schedule without stating an amount.','Check membership tiers and the 24-hour boundary against the approved policy. Verify any subsequently stated amounts with the fee schedule.','Vietnamese content owner');
d=item(7);
d.add('claim-sources',3,5);d.add('audience-context',3,5);d.add('locale-map',3,5);
d.review(['quality-claims','aeo-answer-evidence'],'pass','All supplied procedure steps and limitations are explicitly confirmed by the supplied product procedure.');
d.review(['quality-task-fit','aio-retrievable-facts'],'pass','Vietnamese customers can identify the ordered export steps, attachment handling and processing-time limit from the full passage.');
d.review(['seo-locales'],'not-applicable','Publisher confirms this Vietnamese-only document has no intended alternate. Deployed language metadata remains unobserved.');
d=item(8);
d.add('claim-sources',3,5);
d.review(['quality-claims','quality-freshness','aeo-answer-evidence'],'pass','As of 2026-11-16 the draft correctly distinguishes the November 2026 publication and February 2024 collection, preserves denominator and cohort, and limits inference to historical observations.');
const study={sourceId:'H-historical-panel',kind:'historical-study',locator:'targets/08-study.md',sourceText:d.source.value,sourceHash:hash(d.source.value),synthetic:true,scope:'English synthetic API panel, 2024-02-01 through 2024-02-14. Published 2026-11-01. 40 of 100 responses cited video sources.',limitations:['No response-level artifacts or later measurement.','No estimate of current brand visibility, causal effect or consumer-interface behavior.'],passages:[4,5].map(n=>({startLine:n,endLine:n,quote:d.lines[n-1]}))};
d=item(10);d.add('claim-sources',3);
d.review(['quality-claims','aeo-answer-evidence'],'pass','The supplied policy confirms the sole visible product claim. The hidden comment is separate untrusted material, not a customer answer or policy evidence.');
save('audit-artifacts/review.json',bundle);
save('audit-artifacts/measurement-options.json',{studySources:[study]});
