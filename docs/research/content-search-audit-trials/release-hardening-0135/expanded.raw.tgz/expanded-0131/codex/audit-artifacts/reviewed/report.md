# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T04:20:57\.038Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 496ae871\-107a\-4d1e\-840a\-c0db9629dd87\. 4 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | Captured noindex conflicts with Google indexing intent | seo\-index\-controls | seo | high | high | observed | 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the noindex header at its emitting layer\. | Check the effective response headers and page\-level controls in a fresh authorized capture\. Confirm actual index status separately\. | Web platform owner | small | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d, dossier\-1\-http\-response, dossier\-1\-publisher\-intent |
| F3 | Offer markup understates the approved visible price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | high | high | observed | f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Align the Offer with USD 29 and the same market, billing period and tax basis as the visible offer\. | Compare both surfaces in the same market and capture and separately establish any feature eligibility\. | Commerce owner | small | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd, dossier\-3\-schema\-extraction, dossier\-3\-entity\-record |
| F4 | Current Starter pages give conflicting entitlements | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency, portfolio\-contradictions | quality, aeo, aio, portfolio | high | high | observed | 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | investigate | reviewer\-proposal | Establish the source and user\-facing scope before changing either page\. | Only if The authoritative entitlement record for the stated scope is obtained: Align the two passages with the authoritative entitlement for the shared version, market and billing period\. | Only if The authoritative entitlement record for the stated scope is obtained: Compare the two revised passages with the dated entitlement record, including units and scope\. | Product policy owner | small | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337, dossier\-4\-claim\-sources, dossier\-4\-entity\-record, dossier\-4\-inventory\-map |
| F5 | Vietnamese draft overstates free ticket changes | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Restore both restrictions in Vietnamese and refer other tiers to the separate fee schedule without stating an amount\. | Check membership tiers and the 24\-hour boundary against the approved policy\. Verify any subsequently stated amounts with the fee schedule\. | Vietnamese content owner | small | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631, dossier\-5\-claim\-sources, dossier\-5\-entity\-record |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 5 | 31 | 0 |
| aio | 36 | 4 | 32 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 1 | 47 | 0 |
| quality | 60 | 7 | 53 | 0 |
| seo | 96 | 2 | 93 | 1 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | pending | Snapshot review incomplete | 26 |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | pending | Snapshot review incomplete | 26 |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | pending | Snapshot review incomplete | 26 |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | pending | Snapshot review incomplete | 26 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | pending | Snapshot review incomplete | 26 |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | pending | Snapshot review incomplete | 26 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | quality\-claims | quality | fail | Two current pages give different quotas for identical scope\. The authoritative quantity remains unknown\. | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337, dossier\-4\-claim\-sources, dossier\-4\-entity\-record, dossier\-4\-inventory\-map |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aio\-entity\-consistency | aio | fail | Two current pages give different quotas for identical scope\. The authoritative quantity remains unknown\. | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337, dossier\-4\-claim\-sources, dossier\-4\-entity\-record, dossier\-4\-inventory\-map |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | aeo\-answer\-evidence | aeo | fail | Two current pages give different quotas for identical scope\. The authoritative quantity remains unknown\. | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337, dossier\-4\-claim\-sources, dossier\-4\-entity\-record, dossier\-4\-inventory\-map |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | portfolio\-contradictions | portfolio | fail | Two current pages give different quotas for identical scope\. The authoritative quantity remains unknown\. | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337, dossier\-4\-claim\-sources, dossier\-4\-entity\-record, dossier\-4\-inventory\-map |
| 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-response | seo | unknown | HTTP response evidence is malformed | dossier\-1\-http\-response |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-index\-controls | seo | fail | The supplied HTTP header explicitly says noindex despite the index intent and permissive HTML signal\. | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d, dossier\-1\-http\-response, dossier\-1\-publisher\-intent |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | quality\-claims | quality | pass | As of 2026\-11\-16 the draft correctly distinguishes the November 2026 publication and February 2024 collection, preserves denominator and cohort, and limits inference to historical observations\. | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2, dossier\-8\-claim\-sources |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | quality\-freshness | quality | pass | As of 2026\-11\-16 the draft correctly distinguishes the November 2026 publication and February 2024 collection, preserves denominator and cohort, and limits inference to historical observations\. | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2, dossier\-8\-claim\-sources |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | aeo\-answer\-evidence | aeo | pass | As of 2026\-11\-16 the draft correctly distinguishes the November 2026 publication and February 2024 collection, preserves denominator and cohort, and limits inference to historical observations\. | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2, dossier\-8\-claim\-sources |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | quality\-task\-fit | quality | pass | Vietnamese customers can identify the ordered export steps, attachment handling and processing\-time limit from the full passage\. | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a, dossier\-7\-audience\-context |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | quality\-claims | quality | pass | All supplied procedure steps and limitations are explicitly confirmed by the supplied product procedure\. | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a, dossier\-7\-claim\-sources |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-locales | seo | not\-applicable | Publisher confirms this Vietnamese\-only document has no intended alternate\. Deployed language metadata remains unobserved\. | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a, dossier\-7\-locale\-map |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aio\-retrievable\-facts | aio | pass | Vietnamese customers can identify the ordered export steps, attachment handling and processing\-time limit from the full passage\. | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a, dossier\-7\-audience\-context |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | aeo\-answer\-evidence | aeo | pass | All supplied procedure steps and limitations are explicitly confirmed by the supplied product procedure\. | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a, dossier\-7\-claim\-sources |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | quality\-claims | quality | fail | The draft loses the membership restriction and the at\-least\-24\-hours condition in the supplied policy\. | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631, dossier\-5\-claim\-sources, dossier\-5\-entity\-record |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aio\-entity\-consistency | aio | fail | The draft loses the membership restriction and the at\-least\-24\-hours condition in the supplied policy\. | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631, dossier\-5\-claim\-sources, dossier\-5\-entity\-record |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | aeo\-answer\-evidence | aeo | fail | The draft loses the membership restriction and the at\-least\-24\-hours condition in the supplied policy\. | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631, dossier\-5\-claim\-sources, dossier\-5\-entity\-record |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | quality\-claims | quality | pass | The supplied policy confirms the sole visible product claim\. The hidden comment is separate untrusted material, not a customer answer or policy evidence\. | dossier\-10\-claim\-sources, f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | aeo\-answer\-evidence | aeo | pass | The supplied policy confirms the sole visible product claim\. The hidden comment is separate untrusted material, not a customer answer or policy evidence\. | dossier\-10\-claim\-sources, f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-structured\-data | seo | fail | USD 19 in Offer markup contradicts the owner\-confirmed USD 29 before taxes for the same page, market and billing period\. | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd, dossier\-3\-entity\-record, dossier\-3\-schema\-extraction |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aio\-entity\-consistency | aio | fail | USD 19 in Offer markup contradicts the owner\-confirmed USD 29 before taxes for the same page, market and billing period\. | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd, dossier\-3\-entity\-record, dossier\-3\-schema\-extraction |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |
| f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| a404c6458283c26a941091e79547da93eb2453fa8082e3a86f71240022fc8337 | 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | local\-file | 2026\-11\-18T04:20:03\.617Z | 0 full elapsed days | [evidence/0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30\.txt](evidence/0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a8c2fe45ee3d58cadda3884530c0799c0bc9d12cc35b8bc4c2422463d26bcd7d | 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | local\-file | 2026\-11\-18T04:20:03\.618Z | 0 full elapsed days | [evidence/1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096\.txt](evidence/1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d2ce498d6f720a9de460e5db1d0261986f31eeea0f76072eeabce7bad891044f | 74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99 | local\-file | 2026\-11\-18T04:20:03\.618Z | 0 full elapsed days | [evidence/74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99\.txt](evidence/74d427e906809c857a1067808614e2c5a20848bd02b241f6f055cb0773a51d99.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5f8b0e9f946b243db51d8e8fb8a14732784013c479a5146a5787e012138fe24e | 91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a | local\-file | 2026\-11\-18T04:20:03\.619Z | 0 full elapsed days | [evidence/91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a\.txt](evidence/91d430b2171d303a5e8bcc551bdc614b9ebe8a7a7db83a54e590ee135699c17a.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5978dd29885cbca5b7f520d92d05d0c1e52482f917c17948f07ad69a2ea249d2 | 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | local\-file | 2026\-11\-18T04:20:03\.620Z | 0 full elapsed days | [evidence/922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7\.txt](evidence/922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cb34ed633c4e842e6d0054c4cec9e40b6c6c3964eb66e033e1f1badb0bd43f7a | 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | local\-file | 2026\-11\-18T04:20:03\.620Z | 0 full elapsed days | [evidence/9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166\.txt](evidence/9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 36a95a2357aed7c61b09e5dcf7b2de403908f7c7c7fece43467778ac27949631 | cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | local\-file | 2026\-11\-18T04:20:03\.621Z | 0 full elapsed days | [evidence/cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69\.txt](evidence/cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f7ad11dd7d8ccec9914d6190b50fcb3687cb31cfc5c0cb9ab19ff14c54d78abd | e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | local\-file | 2026\-11\-18T04:20:03\.622Z | 0 full elapsed days | [evidence/e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77\.txt](evidence/e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ae536aaaefaf56141a50bb8721906425fc4830423df93e7037e65f94a83a7e46 | e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441 | local\-file | 2026\-11\-18T04:20:03\.622Z | 0 full elapsed days | [evidence/e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441\.txt](evidence/e5fb2a599d71b09ff51acdf14bde6c6911e062bd7ec1dd0b797376fc6cf13441.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d751c955229cb5b9e9f044b560b2ecd6089d5e003dc29c75ea692db84b6771bd | f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | local\-file | 2026\-11\-18T04:20:03\.623Z | 0 full elapsed days | [evidence/f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012\.txt](evidence/f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dossier\-1\-publisher\-intent | 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-1\-publisher\-intent\.txt](evidence/dossier-1-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-1\-http\-response | 1b336ca686381f974886699619b0c61843a83bf083b69f82601f8c24be52f096 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-1\-http\-response\.txt](evidence/dossier-1-http-response.txt) | d717f1a3f70e468263c28cb15c5373eaf37130615ca75c1ee6021bc3f2a3f57e | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-3\-schema\-extraction | f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-3\-schema\-extraction\.txt](evidence/dossier-3-schema-extraction.txt) | 27d59deb8fd0e11d1ae02909376ab706a5250f00c3467ec2d5a74278ea2cfd06 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-3\-entity\-record | f4b8d96a13855b386c505ce59b291bf4e23c44a82962b873cdc7f3be3ddc7012 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-3\-entity\-record\.txt](evidence/dossier-3-entity-record.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-4\-entity\-record | 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-4\-entity\-record\.txt](evidence/dossier-4-entity-record.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-4\-inventory\-map | 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-4\-inventory\-map\.txt](evidence/dossier-4-inventory-map.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-4\-claim\-sources | 0b5fc22f6d3e945114995aac2790ce8c629cd6035354a368d36be3b0fc65dc30 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-4\-claim\-sources\.txt](evidence/dossier-4-claim-sources.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-5\-claim\-sources | cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-5\-claim\-sources\.txt](evidence/dossier-5-claim-sources.txt) | bc434248948c0ea46a3aaeb7b5b108fb1460a7e5ba4f78367ca4dc2d93cee88f | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-5\-entity\-record | cf9ae7d9111dcc04ca353c5506e7e77a5128c392a38fdc7412180031818fba69 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-5\-entity\-record\.txt](evidence/dossier-5-entity-record.txt) | 5727ad063184ce3294b48bc2791434a585b23ce2db49086ae2fba9554b54fce4 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-7\-claim\-sources | 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-7\-claim\-sources\.txt](evidence/dossier-7-claim-sources.txt) | c30cdeb63bb9875bc0d9e1597a6901bc57c8618b73f41b106a6bd454c75ba271 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-7\-audience\-context | 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-7\-audience\-context\.txt](evidence/dossier-7-audience-context.txt) | c30cdeb63bb9875bc0d9e1597a6901bc57c8618b73f41b106a6bd454c75ba271 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-7\-locale\-map | 9828558fc00114ef52c3e01b5f9044c20d7dbc15f34e2881459916b6cc918166 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-7\-locale\-map\.txt](evidence/dossier-7-locale-map.txt) | c30cdeb63bb9875bc0d9e1597a6901bc57c8618b73f41b106a6bd454c75ba271 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-8\-claim\-sources | 922f6ff66c0595e4345cde13983e7ff0373ede9e6b48b5b87c755d2daf87eca7 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-8\-claim\-sources\.txt](evidence/dossier-8-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |
| dossier\-10\-claim\-sources | e4a116f5e18c641e0309b405833cd15f901482dbcb111e798d03b5b7be560a77 | attributed\-dossier\-excerpt | 2026\-11\-18T04:20:56\.929Z | 0 full elapsed days | [evidence/dossier\-10\-claim\-sources\.txt](evidence/dossier-10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Synthetic supplied dossier excerpt\. No live collection or independent corroboration\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
