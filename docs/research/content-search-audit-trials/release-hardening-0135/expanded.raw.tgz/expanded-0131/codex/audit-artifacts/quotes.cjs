const fs=require('fs'), {createHash}=require('crypto');
const hash=x=>createHash('sha256').update(x).digest('hex');
const report='report.md', data=fs.readFileSync(report);
const quotes=data.toString().split('\n').flatMap((line,index)=>{
 const m=line.match(/^- (\d\d-[\w-]+\.md):(\d+)(?:-(\d+))? — `(.*)`$/);
 if(!m)return [];
 const [,sourceLabel,first,last,quote]=m, source='targets/'+sourceLabel;
 return [{quoteId:'report-line-'+(index+1),source,sourceLabel,sourceHash:hash(fs.readFileSync(source)),startLine:+first,endLine:+(last||first),reportStartLine:index+1,reportEndLine:index+1,normalization:'whitespace',quote}];
});
if(quotes.length!==23)throw Error('Reconcile source quotations: '+quotes.length);
fs.writeFileSync('audit-artifacts/quotes.json',JSON.stringify({root:process.cwd(),report,reportHash:hash(data),quotes},null,2));
