# Content audit — Content Search Audit

## Audit status

Partial\. Run 49760de8\-cece\-428a\-9ccf\-5c16a85229f4\. 1 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 1 |
| In scope | 1 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 1 |
| Unsupported | 0 |
| Pending | 0 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Inventory completeness is unknown; Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 04288dd5d36af6c2e0dfff8013424eef40a46cab824d3db1caa358501c5b4364 | Captured HTTP status 404; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | seo\-response | seo | low | high | observed | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | 49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 3 | 0 | 3 | 0 |
| aio | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 1 | 7 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | failed | Public response HTTP 404; content remains unavailable | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-response | seo | fail | Captured HTTP status 404; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | 49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606 |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- |
| d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | public\-http | 1970\-01\-01T00:00:00\.000Z | [evidence/d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606\.json](evidence/d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | public\-http | 1970\-01\-01T00:00:00\.000Z | [evidence/3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427\.json](evidence/3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427.json) | 283e800279e15920fd2adf76a150ecfada07b216e1d9c9c842fc762fcfb5e0a4 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | public\-http | 1970\-01\-01T00:00:00\.000Z | [evidence/49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085\.json](evidence/49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085.json) | 812886d7de3ebe68f5e9bdbf917f8d05de99f891313dc89c3129c23dc4343602 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |

## Rule provenance

| Rule | Reviewed | Sources | Limitations |
| --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
