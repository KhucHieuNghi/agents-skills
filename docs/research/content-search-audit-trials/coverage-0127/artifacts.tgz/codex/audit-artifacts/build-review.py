import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

out = Path("audit-artifacts")
source = {int(Path(r["locator"]).name[:2]): r for r in map(json.loads, (out/"snapshots/evidence.jsonl").read_text().splitlines())}
rules = {r["ruleId"]: r for r in json.loads(Path(".agents/skills/content-search-audit/rules/core.json").read_text())["rules"]}
bundle = dict(reviews=[], evidence=[], artifacts={}, findings=[])
now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
scope = Path("targets/context.md").read_text()
evidence = {}

def add(n, kind, ranges, note):
    src = source[n]
    lines = src["value"].splitlines(keepends=True)
    value = "".join("".join(lines[a-1:b]) for a,b in ranges)
    if kind == "audience-context":
        value = scope + "\nDossier excerpts (see locator)\n" + value
    eid = f"dossier-{n:02d}-{kind}"
    artifact = f"evidence/{eid}.txt"
    loc = "; ".join(f"{Path(src['locator']).name}:{a}-{b}" for a,b in ranges)
    if kind == "audience-context":
        loc += "; context.md:3-17"
    bundle["artifacts"][artifact] = value
    bundle["evidence"].append(dict(evidenceId=eid,itemId=src["itemId"],kind=kind,
        method="attributed task context and dossier excerpts" if kind == "audience-context" else
        "identity extraction of readable UTF-8 Markdown" if kind == "extracted-text" else "attributed dossier excerpts",
        collectedAt=now,locator=loc,snapshotHash=hashlib.sha256(value.encode()).hexdigest(),
        redaction="none", limitations=[note],sourceEvidenceIds=[src["evidenceId"]],
        artifact=artifact,encoding="utf8",value=value))
    evidence[n,kind] = eid

def ids(n, rule):
    return [source[n]["evidenceId"] if k == "content" else evidence[n,k] for k in rules[rule]["requiredEvidence"]]

def review(n, rule, status, reason):
    bundle["reviews"].append(dict(itemId=source[n]["itemId"],ruleId=rule,status=status,reason=reason,
        evidenceIds=ids(n,rule),reviewer="Offline dossier reviewer",reviewedAt=now))

for n, src in source.items():
    add(n,"extracted-text",[(1,len(src["value"].splitlines()))],"Readable local Markdown source only.")
for n, ranges in {1:[(3,14)],2:[(3,8),(14,16)],3:[(3,6),(13,16)],4:[(3,5),(10,18)]}.items():
    add(n,"claim-sources",ranges,"Owner-supplied synthetic comparison evidence. Scope is limited to the quoted records.")
for n, ranges in {1:[(3,14)],3:[(3,6),(13,16)],4:[(3,5),(10,18)]}.items():
    add(n,"entity-record",ranges,"Owner-supplied synthetic records establish scoped identities and facts only.")
add(3,"inventory-map",[(3,3),(6,18)],"Complete declared service-page inventory within scenario 03 only.")
add(3,"audience-context",[(3,6),(13,18)],"New-order and old-order tasks are supported by the dossier and bounded by the user scope.")
add(4,"question-set",[(8,13)],"The explicit permission question covers only the FAQ component.")
review(3,"portfolio-duplication","pass","The current pages serve distinct geographies and the archive serves the 2024 old-order task. Shared layout and generic wording are intentional.")
review(4,"aeo-question-coverage","pass","The only supplied explicit question asks for the permitted role. The complete answer identifies the owner.")
review(4,"aeo-answer-context","pass","The explicit permissions answer stands on its own. The approved task requires no additional conditions or deletion steps.")

base = ["quality-claims","aeo-answer-evidence"]
entity = base + ["aio-entity-consistency"]
service = entity + ["quality-task-fit","aio-retrievable-facts","portfolio-contradictions"]
entries = [
  (1,3,service,"South advertises the wrong delivery service","Replace the South policy with next-business-day only. Retain both region pages and the archive.","Compare both revised region passages to approved policy, then inspect the archive label and new-order links.","Service content owner"),
  (2,4,entity,"Setup guarantee exceeds the study evidence","Use the observed median of 15 minutes across 20 sessions with study attribution, or remove the time claim.","Check metric, sample and scope against the approved product record.","Product marketing"),
  (3,1,entity,"Fir Enterprise SSO is denied","State the supplied SAML SSO Enterprise availability and 20 paid-seat minimum. Leave other plans unknown.","Check plan, protocol, minimum and November 2026 US scope against the SSO excerpt.","Comparison-page editor"),
  (4,1,entity,"The annual rate reverses the price comparison","Show separate US monthly-billed and annual-billed per-seat rates in USD before tax.","Recalculate both differences and verify the billing cadence and units against the November 2026 records.","Comparison-page editor"),
  (5,2,base,"October cost per conversion mixes windows","Use USD 20 for October 1–7 and mark full October unavailable.","Match campaign, currency, dates and completed-conversion definition before division.","Campaign reporting analyst"),
  (6,2,base,"Referral estimate has no tracking basis","Use the 15 identified-referrer sessions and leave other origins unknown.","Reconcile the identified count and look for a validated tracking estimate before extrapolating.","Referral reporting analyst"),
]
failed = {}
for f,n,checks,title,action,verification,owner in entries:
    bundle["findings"].append(dict(findingId=f"F{f}",title=title,remediation=action,
        verification=verification,ownerRole=owner,effort="Copy edit and owner evidence check",
        affectedItemIds=[source[n]["itemId"]],ruleIds=checks,dimensions=sorted({rules[r]["dimension"] for r in checks}),
        evidenceIds=sorted({i for r in checks for i in ids(n,r)}),severity="high",confidence="high",
        classification="observed",action="update",actionReason=f"See F{f} in the editorial report for the scoped contradiction or unsupported inference."))
    for rule in checks:
        failed.setdefault((n,rule),[]).append(f"F{f}: {title}")
for (n,rule), reasons in failed.items():
    review(n,rule,"fail","; ".join(reasons))
(out/"review.json").write_text(json.dumps(bundle,indent=2,ensure_ascii=False)+"\n")
