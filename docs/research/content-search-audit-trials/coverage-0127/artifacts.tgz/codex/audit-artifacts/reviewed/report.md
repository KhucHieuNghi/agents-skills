# Offline synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:49:52\.492Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 580ff205\-b2d7\-41a3\-a59a\-327d6aef2938\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | South advertises the wrong delivery service | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency, quality\-task\-fit, aio\-retrievable\-facts, portfolio\-contradictions | aeo, aio, portfolio, quality | high | high | observed | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | update | reviewer\-proposal | See F1 in the editorial report for the scoped contradiction or unsupported inference\. | Replace the South policy with next\-business\-day only\. Retain both region pages and the archive\. | Compare both revised region passages to approved policy, then inspect the archive label and new\-order links\. | Service content owner | Copy edit and owner evidence check | dossier\-03\-audience\-context, dossier\-03\-claim\-sources, dossier\-03\-entity\-record, dossier\-03\-inventory\-map, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| F2 | Setup guarantee exceeds the study evidence | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | aeo, aio, quality | high | high | observed | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | update | reviewer\-proposal | See F2 in the editorial report for the scoped contradiction or unsupported inference\. | Use the observed median of 15 minutes across 20 sessions with study attribution, or remove the time claim\. | Check metric, sample and scope against the approved product record\. | Product marketing | Copy edit and owner evidence check | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-claim\-sources, dossier\-04\-entity\-record |
| F3 | Fir Enterprise SSO is denied | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | aeo, aio, quality | high | high | observed | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | update | reviewer\-proposal | See F3 in the editorial report for the scoped contradiction or unsupported inference\. | State the supplied SAML SSO Enterprise availability and 20 paid\-seat minimum\. Leave other plans unknown\. | Check plan, protocol, minimum and November 2026 US scope against the SSO excerpt\. | Comparison\-page editor | Copy edit and owner evidence check | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f, dossier\-01\-claim\-sources, dossier\-01\-entity\-record |
| F4 | The annual rate reverses the price comparison | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | aeo, aio, quality | high | high | observed | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | update | reviewer\-proposal | See F4 in the editorial report for the scoped contradiction or unsupported inference\. | Show separate US monthly\-billed and annual\-billed per\-seat rates in USD before tax\. | Recalculate both differences and verify the billing cadence and units against the November 2026 records\. | Comparison\-page editor | Copy edit and owner evidence check | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f, dossier\-01\-claim\-sources, dossier\-01\-entity\-record |
| F5 | October cost per conversion mixes windows | quality\-claims, aeo\-answer\-evidence | aeo, quality | high | high | observed | 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | update | reviewer\-proposal | See F5 in the editorial report for the scoped contradiction or unsupported inference\. | Use USD 20 for October 1–7 and mark full October unavailable\. | Match campaign, currency, dates and completed\-conversion definition before division\. | Campaign reporting analyst | Copy edit and owner evidence check | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1, dossier\-02\-claim\-sources |
| F6 | Referral estimate has no tracking basis | quality\-claims, aeo\-answer\-evidence | aeo, quality | high | high | observed | 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | update | reviewer\-proposal | See F6 in the editorial report for the scoped contradiction or unsupported inference\. | Use the 15 identified\-referrer sessions and leave other origins unknown\. | Reconcile the identified count and look for a validated tracking estimate before extrapolating\. | Referral reporting analyst | Copy edit and owner evidence check | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1, dossier\-02\-claim\-sources |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 6 | 6 | 0 |
| aio | 12 | 4 | 8 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 9 | 11 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | pending | Snapshot review incomplete | 26 |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | pending | Snapshot review incomplete | 26 |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | pending | Snapshot review incomplete | 26 |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | quality\-claims | quality | fail | F5: October cost per conversion mixes windows; F6: Referral estimate has no tracking basis | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1, dossier\-02\-claim\-sources |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-02\-extracted\-text |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | aeo\-answer\-evidence | aeo | fail | F5: October cost per conversion mixes windows; F6: Referral estimate has no tracking basis | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1, dossier\-02\-claim\-sources |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | quality\-claims | quality | fail | F2: Setup guarantee exceeds the study evidence | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-claim\-sources |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-04\-extracted\-text |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aio\-entity\-consistency | aio | fail | F2: Setup guarantee exceeds the study evidence | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-entity\-record |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aeo\-question\-coverage | aeo | pass | The only supplied explicit question asks for the permitted role\. The complete answer identifies the owner\. | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-question\-set |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aeo\-answer\-context | aeo | pass | The explicit permissions answer stands on its own\. The approved task requires no additional conditions or deletion steps\. | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-question\-set |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | aeo\-answer\-evidence | aeo | fail | F2: Setup guarantee exceeds the study evidence | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd, dossier\-04\-claim\-sources |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | quality\-task\-fit | quality | fail | F1: South advertises the wrong delivery service | dossier\-03\-audience\-context, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | quality\-claims | quality | fail | F1: South advertises the wrong delivery service | dossier\-03\-claim\-sources, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-03\-extracted\-text |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aio\-entity\-consistency | aio | fail | F1: South advertises the wrong delivery service | dossier\-03\-entity\-record, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aio\-retrievable\-facts | aio | fail | F1: South advertises the wrong delivery service | dossier\-03\-audience\-context, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | aeo\-answer\-evidence | aeo | fail | F1: South advertises the wrong delivery service | dossier\-03\-claim\-sources, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | portfolio\-duplication | portfolio | pass | The current pages serve distinct geographies and the archive serves the 2024 old\-order task\. Shared layout and generic wording are intentional\. | dossier\-03\-inventory\-map, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | portfolio\-contradictions | portfolio | fail | F1: South advertises the wrong delivery service | dossier\-03\-entity\-record, dossier\-03\-inventory\-map, f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | quality\-claims | quality | fail | F3: Fir Enterprise SSO is denied; F4: The annual rate reverses the price comparison | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f, dossier\-01\-claim\-sources |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-01\-extracted\-text |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aio\-entity\-consistency | aio | fail | F3: Fir Enterprise SSO is denied; F4: The annual rate reverses the price comparison | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f, dossier\-01\-entity\-record |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | aeo\-answer\-evidence | aeo | fail | F3: Fir Enterprise SSO is denied; F4: The annual rate reverses the price comparison | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f, dossier\-01\-claim\-sources |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |
| df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| d5e92d49ca874b695cd1a250c397b7c3a000f55e401926547355f16693ac7ec1 | 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | local\-file | 2026\-11\-16T05:47:37\.918Z | 0 full elapsed days | [evidence/1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a\.txt](evidence/1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 35e17f43e2f85e42728a70b58d0a013291922b077054770b710dc7e04cf804dd | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | local\-file | 2026\-11\-16T05:47:37\.919Z | 0 full elapsed days | [evidence/1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78\.txt](evidence/1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f6514402915ef406213d213eadebf67e591ee212b80de282d27347855a49582d | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | local\-file | 2026\-11\-16T05:47:37\.920Z | 0 full elapsed days | [evidence/8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec\.txt](evidence/8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7642c08a99b6f7843ef0e24f44b431967d2b9c72365dfbaee8fae4b8c42ba54f | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | local\-file | 2026\-11\-16T05:47:37\.921Z | 0 full elapsed days | [evidence/df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372\.txt](evidence/df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dossier\-02\-extracted\-text | 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-02\-extracted\-text\.txt](evidence/dossier-02-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Readable local Markdown source only\. |
| dossier\-04\-extracted\-text | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-04\-extracted\-text\.txt](evidence/dossier-04-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Readable local Markdown source only\. |
| dossier\-03\-extracted\-text | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-03\-extracted\-text\.txt](evidence/dossier-03-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Readable local Markdown source only\. |
| dossier\-01\-extracted\-text | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-01\-extracted\-text\.txt](evidence/dossier-01-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Readable local Markdown source only\. |
| dossier\-01\-claim\-sources | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-01\-claim\-sources\.txt](evidence/dossier-01-claim-sources.txt) | 6cfa66eeb3a8c71dbb4dfde0e787615be14a976daf49a59622dd3ee9cefc0bcc | Owner\-supplied synthetic comparison evidence\. Scope is limited to the quoted records\. |
| dossier\-02\-claim\-sources | 1457e3199c46d39739f32b84976147dcefee62573b0b480d4b248b45175da43a | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-02\-claim\-sources\.txt](evidence/dossier-02-claim-sources.txt) | bcb73025c26f2908b44821e378f8b2fc275a88580104541bfeaf1cd719b8c3bb | Owner\-supplied synthetic comparison evidence\. Scope is limited to the quoted records\. |
| dossier\-03\-claim\-sources | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-03\-claim\-sources\.txt](evidence/dossier-03-claim-sources.txt) | 5ea42d9f66bfa2d0be0a4beb25035467d4dec0b586a5728522ab6336b6bd8ea9 | Owner\-supplied synthetic comparison evidence\. Scope is limited to the quoted records\. |
| dossier\-04\-claim\-sources | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-04\-claim\-sources\.txt](evidence/dossier-04-claim-sources.txt) | cbe39d9ee05a352c854f4ec1342a64b3fa315dee0455b0e81fc72e583f5f9210 | Owner\-supplied synthetic comparison evidence\. Scope is limited to the quoted records\. |
| dossier\-01\-entity\-record | df5311f62b8697c4aa9a64c1bf0a865fb25e5ce8cb202aa00f2c0fafacbe5372 | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-01\-entity\-record\.txt](evidence/dossier-01-entity-record.txt) | 6cfa66eeb3a8c71dbb4dfde0e787615be14a976daf49a59622dd3ee9cefc0bcc | Owner\-supplied synthetic records establish scoped identities and facts only\. |
| dossier\-03\-entity\-record | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-03\-entity\-record\.txt](evidence/dossier-03-entity-record.txt) | 5ea42d9f66bfa2d0be0a4beb25035467d4dec0b586a5728522ab6336b6bd8ea9 | Owner\-supplied synthetic records establish scoped identities and facts only\. |
| dossier\-04\-entity\-record | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-04\-entity\-record\.txt](evidence/dossier-04-entity-record.txt) | cbe39d9ee05a352c854f4ec1342a64b3fa315dee0455b0e81fc72e583f5f9210 | Owner\-supplied synthetic records establish scoped identities and facts only\. |
| dossier\-03\-inventory\-map | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-03\-inventory\-map\.txt](evidence/dossier-03-inventory-map.txt) | 67ae987e6e29e7a98e752569771ce73c886ce64be5c9a5981951618b3cb5134b | Complete declared service\-page inventory within scenario 03 only\. |
| dossier\-03\-audience\-context | 8c596495676095b21e990d3048636d9301c1a2baebd2a13c3af7fd7dd50fbbec | attributed task context and dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-03\-audience\-context\.txt](evidence/dossier-03-audience-context.txt) | f915352a10c19d6e5ab0442108dc1833346fdceac5bce0747696cd9ed2222074 | New\-order and old\-order tasks are supported by the dossier and bounded by the user scope\. |
| dossier\-04\-question\-set | 1d571227ca0fd31029faad36765990f281d2b0097b7bf375fd62e0834d441f78 | attributed dossier excerpts | 2026\-11\-16T05:49:52\.355Z | 0 full elapsed days | [evidence/dossier\-04\-question\-set\.txt](evidence/dossier-04-question-set.txt) | 9cfa13def3b25d421c999cfc938b28a8203ce3a80feb3156f41575940095013a | The explicit permission question covers only the FAQ component\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
