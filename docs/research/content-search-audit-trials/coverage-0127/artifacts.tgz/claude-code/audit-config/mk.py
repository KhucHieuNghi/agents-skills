import json,hashlib,re
p=open('report.md',encoding='utf8').read().replace('- Dates were checked with `bc`','- Quantities were checked with `bc`')
open('report.md','w',encoding='utf8').write(p)
rep=p.split('\n')
def h(f): return hashlib.sha256(open(f,'rb').read()).hexdigest()
Q=[("01-competitor-claims.md",17,17,'Fir has no SSO, as its pricing table proves.'),
("01-competitor-claims.md",12,13,'SAML SSO is available on Enterprise, with a minimum of 20 paid seats.'),
("01-competitor-claims.md",18,18,'Cedar is cheaper per seat than Fir on every billing option.'),
("01-competitor-claims.md",21,21,'On the supplied monthly plans, Cedar is USD 3 less per seat per month before tax.'),
("02-measurement-windows.md",10,10,'October cost per conversion was USD 85.71, from 3000 divided by 35.'),
("02-measurement-windows.md",11,12,'For October 1–7, observed cost per completed conversion was USD 20 (700 divided by 35). The rest of the month is unmeasured.'),
("02-measurement-windows.md",17,18,'These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked.'),
("03-template-service-area.md",10,11,'South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date.'),
("03-template-service-area.md",4,5,'South serves next-business-day delivery only.'),
("04-editorial-proof.md",6,6,'Every team is guaranteed to finish setup in 10 minutes.'),
("04-editorial-proof.md",3,5,'The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.'),
("04-editorial-proof.md",9,9,'Can editors delete the workspace? No. Only workspace owners can delete it.')]
qs=[]
for i,(f,s,e,q) in enumerate(Q):
    loc=f"{f}:{s}" if s==e else f"{f}:{s}-{e}"
    idx=[n for n,l in enumerate(rep) if loc in l]
    idx2=[n for n in idx if q in ' '.join(rep[n:n+2])]
    if not idx2: print("NOREPORT",loc,q[:40]); continue
    n=idx2[0]+1
    qs.append(dict(quoteId=f"Q{i}",source="targets/"+f,sourceLabel=f,sourceHash=h("targets/"+f),startLine=s,endLine=e,reportStartLine=n,reportEndLine=n+1,normalization="whitespace",quote=q))
json.dump(dict(root=".",report="report.md",reportHash=h("report.md"),quotes=qs),open("audit-config/quotes.json","w"),ensure_ascii=False)
print(len(qs))
