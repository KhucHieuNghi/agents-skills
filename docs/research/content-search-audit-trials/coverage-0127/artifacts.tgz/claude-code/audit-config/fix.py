p=open('report.md',encoding='utf8').read()
a=[l for l in p.split('\n') if l.startswith('- The quotation verifier')][0]
p=p.replace(a,"- Twelve key source quotations (all assertions under review, the SSO documentation, the approved South policy, the monthly and October 1–7 captions, the FAQ and the study scope) were checked with `verify-quotes` against source line ranges: 12 of 12 valid, with receipt `audit-config/receipt.json`. The receipt covers submitted spans only. Remaining quotations (for example, the lines at 01-competitor-claims.md:6-9) were checked manually against the line-numbered source.")
open('report.md','w',encoding='utf8').write(p)
