# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T04:48:39\.480Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run d3818225\-82ba\-4992\-afb3\-d1165c647099\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 68d56a405203a97c3a138968c992f31afc7b692a6c3fd550c040e076c659b505 | 0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab | local\-file | 2026\-11\-18T04:48:39\.455Z | 0 full elapsed days | [evidence/0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab\.txt](evidence/0467c281af250096892d5fef67eefdf47d185442699e3067c473676a480dd3ab.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1965748233a5bbec6cb70292412147158f6c646d0ae4d0eb6520bb4de57665c2 | 0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d | local\-file | 2026\-11\-18T04:48:39\.456Z | 0 full elapsed days | [evidence/0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d\.txt](evidence/0d2c7d17c445adfc55e30f7084707d55269482b1ff6f85e90c1bc42b648ef96d.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e275462f6b4cacbf2b2625da2ca06f1b23f53704f736a78c59c986afad360c05 | 27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518 | local\-file | 2026\-11\-18T04:48:39\.457Z | 0 full elapsed days | [evidence/27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518\.txt](evidence/27b7c3cbba4f8502f069f560560ac938d91f14dfddcf2aa46a5f4b259dd22518.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 23181c97c30fe81a95b34a90bfb000e70e1beb2a8f31081b24050e6864631f99 | 34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5 | local\-file | 2026\-11\-18T04:48:39\.458Z | 0 full elapsed days | [evidence/34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5\.txt](evidence/34f6421b06d6850ceff7f00a4c674a8b060f496cbef44b1613b8bb1301e359d5.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 972ee748318938f3bca0b128c6d1ef8a6248b739fda052ebd0f588005f4ec180 | 3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9 | local\-file | 2026\-11\-18T04:48:39\.459Z | 0 full elapsed days | [evidence/3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9\.txt](evidence/3a226aeeeb9a7e2755aaa508ae25adbe617b92f2e1082c41751c71018f87a6a9.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 454a0ea3a6349300f1705db7bb2b1462a2626e75175fbb2107d681b997e8beff | 602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e | local\-file | 2026\-11\-18T04:48:39\.459Z | 0 full elapsed days | [evidence/602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e\.txt](evidence/602b879f04a07c547375dca7b2e8f84904ebacec4b2bc5465bbba4025460b01e.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| de30611a1b3e1bc333ce9c1b8aaf355f0737e360ebbcb68bccced677f3e9b724 | 62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d | local\-file | 2026\-11\-18T04:48:39\.460Z | 0 full elapsed days | [evidence/62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d\.txt](evidence/62b025b118e806b7df73f06a4c742058993af875f3e0d702b2128df7f2d2772d.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 21f2caf532509db35f911f2d2145050c98d35d865047e76043e48e9e85f80a85 | 92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1 | local\-file | 2026\-11\-18T04:48:39\.461Z | 0 full elapsed days | [evidence/92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1\.txt](evidence/92813f467d4fe23bf6e2d29c5ee077475da46bbbfca47d84e2ae2726e71387a1.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 75be4ff9300eff87cc4c6c7df03302bba8c19caae708e8032a4d65623c7a2ee8 | aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9 | local\-file | 2026\-11\-18T04:48:39\.461Z | 0 full elapsed days | [evidence/aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9\.txt](evidence/aa040a7ce18ae0b3234944486fc1478e37c3d8ab5f96ca8528aa71980a379be9.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 97787ce19d43eb5c2783c845fc66b81d40227a9f5f919b90698e4ad84e90791f | abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df | local\-file | 2026\-11\-18T04:48:39\.462Z | 0 full elapsed days | [evidence/abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df\.txt](evidence/abc2f97fe99b4e33cabdd7a2ba8764ae2dab06679cc816a6bb01ffe3a757f6df.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
