import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [root, out] = process.argv.slice(2);
const hash = (b) => createHash("sha256").update(b).digest("hex");
const rp = path.join(root, "report.md");
let report = readFileSync(rp, "utf8");
// hard line breaks between consecutive quotation lines; note partial summary quote
let ls = report.split("\n");
ls = ls.map((l, i) => (l.startsWith("> **") && (ls[i + 1] ?? "").startsWith("> ") && !l.endsWith("  ") ? l + "  " : l));
report = ls.join("\n").replace("quoted as the factual base):", "opening sentences quoted as the factual base):");
writeFileSync(rp, report);
const lines = report.split("\n");
const quotes = [];
const checksum = {};
for (let i = 0; i < lines.length; i++) {
  const m = lines[i].match(/\*\*(\d\d-[a-z-]+\.md):(\d+)(?:-(\d+))?\*\* — (.*)$/);
  if (!m) continue;
  const [, file, s, e, rest] = m;
  const src = readFileSync(path.join(root, "targets", file));
  const srcLines = src.toString("utf8").split("\n");
  const start = +s, end = +(e ?? s);
  let quote, rs = i + 1, re = i + 1, normalization = "exact";
  if (rest.startsWith("the captured page contains")) {
    quote = srcLines[start - 1]; re = i + 4;
  } else {
    quote = rest.trimEnd().replace(/^`(.*)`$/, "$1");
    if (end > start) normalization = "whitespace";
  }
  quotes.push({ quoteId: `q${quotes.length + 1}-${file}-${s}`, source: `targets/${file}`, sourceLabel: file, sourceHash: hash(src), startLine: start, endLine: end, reportStartLine: rs, reportEndLine: re, normalization, quote });
}
writeFileSync(out, JSON.stringify({ root, report: "report.md", reportHash: hash(readFileSync(rp)), quotes }, null, 2));
console.log(quotes.length, "quotes; report locator lines:", lines.filter((l) => /\*\*\d\d-[a-z-]+\.md:\d+/.test(l)).length);
