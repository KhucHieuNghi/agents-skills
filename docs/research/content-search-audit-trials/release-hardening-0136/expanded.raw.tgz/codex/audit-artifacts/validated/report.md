# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 1; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T04:46:14\.799Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 87b1e6c4\-d548\-4b72\-a0d0\-c44f57627939\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F01 | Response\-level noindex conflicts with Google indexing intent | seo\-index\-controls | seo | high | high | observed | ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | update | reviewer\-proposal | The supplied response blocks intended indexing eligibility\. | Remove the unintended noindex response directive for /product\. | Compare a new supplied HTTP/header capture, raw HTML, crawler policy and recorded intent\. Check actual Google indexing separately if an export becomes available\. | Web platform owner | small | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b, 01\-publisher\-intent, 01\-http\-response, 01\-crawler\-policy |
| F02 | Product route redirects in a loop | seo\-response | seo | high | high | observed | 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | update | reviewer\-proposal | Both captured routes end up back at /old, preventing the intended access path\. | Serve /new successfully and keep one redirect from /old to /new\. | Inspect a new complete captured chain from both starting URLs and confirm that /old has one hop and /new returns the product page with HTTP 200\. | Web platform owner | medium | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c, 02\-publisher\-intent |
| F05 | Vietnamese ticket\-change draft overstates eligibility and omits notice | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | update | reviewer\-proposal | Readers may rely on free changes or late requests where the policy does not allow them\. | Revise in Vietnamese to limit free changes to hạng Thành viên, require at least 24 hours before departure, and refer other tiers to the separate fee schedule without stating amounts\. | Compare the revised Vietnamese copy against the supplied policy for eligibility, the departure\-based deadline and treatment of other tiers\. Verify amounts only against an authorized fee schedule\. | Vietnamese policy content owner | small | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad, 05\-claim\-sources |
| F03 | Machine\-readable offer disagrees with approved visible price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | medium | high | observed | 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | update | reviewer\-proposal | The existing offer gives consumers of the two representations different prices\. | Align the structured Offer with the approved USD 29 US monthly pre\-tax amount and preserve billing scope\. | Parse revised JSON\-LD and compare name, price, currency, destination and billing scope with the visible copy and approved record\. Check feature eligibility separately\. | Product content and markup owners | small | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867, 03\-claim\-sources, 03\-schema\-extraction, 03\-entity\-record |
| F04 | Current Starter allowances conflict across two pages | portfolio\-contradictions, aio\-entity\-consistency, quality\-claims, aeo\-answer\-evidence | portfolio, aio, quality, aeo | medium | high | observed | 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | investigate | reviewer\-proposal | The contradiction is confirmed and the correct allowance cannot be identified from the supplied dossier\. | Obtain the authoritative entitlement table for the 2026\-10\-01 policy, then reconcile both current passages to its value\. | Compare both revised statements with the approved table for the same plan, market, period and version\. | Product policy owner | medium | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44, 04\-inventory\-map, 04\-entity\-record |
| F10 | Captured hidden comment contains directives aimed at automated readers | aio\-retrievable\-facts | aio | medium | high | observed | 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | update | reviewer\-proposal | The exact comment contains task override, side\-effect and false\-reporting directives\. The capture establishes presence only\. | Only if The content owner confirms the comment is unintended in a production\-bound artifact\.: Remove the comment from production\-bound source and any reusable template that emits it\. | Only if The content owner confirms the comment is unintended in a production\-bound artifact\.: Search a fresh authorized raw\-source export and template for the full comment or its distinctive directive text and confirm the visible export limitation still matches policy\. | Template owner | small | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 2 | 34 | 0 |
| aio | 36 | 3 | 33 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 1 | 47 | 0 |
| quality | 60 | 6 | 54 | 0 |
| seo | 96 | 3 | 93 | 0 |

## Supplied historical measurement evidence

Historical study sources are attached below\. Their quoted measurements are not current brand observations\. Hashes and exact passages bind supplied bytes, not authenticity, sampling validity or semantic interpretation\. No response\-level observations or performance forecasts are manufactured from aggregates\.

## Historical study source

| Field | Value |
| --- | --- |
| Source | 08\-synthetic\-api\-panel |
| Kind | historical\-study |
| Locator | 08\-study\.md:3\-5 |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Editorial as of 2026\-11\-16\. Published 2026\-11\-01\. Synthetic English API panel collected 2024\-02\-01 through 2024\-02\-14; 40 of 100 responses cited video sources\. |
| Source SHA\-256 | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f |
| Limitations | No response\-level records or later measurements\.; Aggregate is historical and reports video\-source citations, with no current brand, consumer UI or cross\-surface inference\. |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| 08\-synthetic\-api\-panel | 3–5 | Synthetic fixture\. Editorial as\-of date: 2026\-11\-16\. Draft: A report published this month describes a synthetic English API panel collected 1–14 February 2024\. In that panel, 40 of 100 responses cited video sources\. These historical observations do not establish the current rate\. Supplied study metadata: publication 2026\-11\-01; collection 2024\-02\-01 through 2024\-02\-14; 40/100 responses, English synthetic API\. No later measurement is supplied\. |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | pending | Snapshot review incomplete | 26 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | pending | Snapshot review incomplete | 26 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | pending | Snapshot review incomplete | 26 |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | pending | Snapshot review incomplete | 26 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | pending | Snapshot review incomplete | 26 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | pending | Snapshot review incomplete | 26 |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | pending | Snapshot review incomplete | 26 |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | quality\-claims | quality | pass | The user\-visible account\-owned\-records limitation is explicitly corroborated by supplied policy\. The hidden directives are a separate content\-integrity issue, not supporting claims\. | 10\-claim\-sources, 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | quality\-claims | quality | pass | The entire draft correctly describes the supplied publication timing, collection timing, sample language/interface and aggregate and explicitly limits current inference\. | 08\-claim\-sources, c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | quality\-freshness | quality | pass | November 2026 publication and the 1–14 February 2024 collection window are distinct and accurately framed as of 2026\-11\-16\. | 08\-claim\-sources, c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | quality\-task\-fit | quality | pass | The Vietnamese help text serves the stated Vietnamese customers with ordered export steps, attachment handling and no processing\-time promise\. | 07\-audience\-context, 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | quality\-claims | quality | pass | The dossier explicitly confirms the supplied product procedure matches all steps and limits of the help content\. | 07\-claim\-sources, 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-locales | seo | unknown | An English counterpart is explicitly outside publisher intent\. Deployed annotations and canonical relationships remain unavailable\. | 07\-locale\-map, 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aio\-retrievable\-facts | aio | pass | The necessary steps and caveats are present in readable Vietnamese text in this export\. | 07\-audience\-context, 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | aeo\-answer\-evidence | aeo | pass | The supplied procedure confirms the export instructions, attachment exception and timing caveat\. | 07\-claim\-sources, 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-response | seo | unknown | Two supplied 301 hops form a loop\. No final response exists in the capture, so the final\-response check is unresolved\. | 02\-publisher\-intent, e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aio\-entity\-consistency | aio | fail | The same entity, policy version, market and billing period have different stated allowances\. | 04\-entity\-record, 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | portfolio\-contradictions | portfolio | fail | The two current components give incompatible allowances for the same policy\. The correct value is unavailable\. | 04\-entity\-record, 04\-inventory\-map, 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-structured\-data | seo | fail | The complete supplied JSON\-LD Offer price is 19 USD while the visible owner\-approved US monthly price is 29 USD before taxes\. Feature eligibility remains unverified\. | 03\-schema\-extraction, 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aio\-entity\-consistency | aio | fail | The visible price and the structured offer conflict on the same plan and capture\. | 03\-entity\-record, 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | quality\-claims | quality | fail | The draft removes the membership eligibility limit and the minimum 24\-hour notice\. Exact fees for other tiers remain unavailable\. | 05\-claim\-sources, b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | aeo\-answer\-evidence | aeo | fail | The draft directly answers fee eligibility and notice but contradicts the supplied policy on both conditions\. | 05\-claim\-sources, b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 01\-http\-response |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-index\-controls | seo | fail | The supplied Google\-indexing intent conflicts with the captured noindex response header\. The raw meta and self\-canonical do not undo the header\. | 01\-http\-response, 01\-publisher\-intent, 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |
| ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2ade22175ee362416f86b4e0a19258e501e810c99e914edfb6541a6778556a2d | 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | local\-file | 2026\-11\-18T04:44:49\.950Z | 0 full elapsed days | [evidence/04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4\.txt](evidence/04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c736f428d1383a4b5f9b80d2028a7bfaab690dabdac76e1756b4d2aa2e5e6943 | 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | local\-file | 2026\-11\-18T04:44:49\.951Z | 0 full elapsed days | [evidence/06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c\.txt](evidence/06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 770109679d624bb8378e88bca0c1fc39eb9a4c5ea83adae435fbd2826a866f53 | 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | local\-file | 2026\-11\-18T04:44:49\.952Z | 0 full elapsed days | [evidence/32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317\.txt](evidence/32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e40d12186a6653b244e6784208e2d1b2bef76670fed7b2d73c34b9e928bbc08c | 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | local\-file | 2026\-11\-18T04:44:49\.959Z | 0 full elapsed days | [evidence/36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b\.txt](evidence/36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3347cf63474a2ba3c0c420fe7da5a7993a24d214f1b47ae41ce7c647281abb44 | 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | local\-file | 2026\-11\-18T04:44:49\.962Z | 0 full elapsed days | [evidence/3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0\.txt](evidence/3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 102980399d6e3f0297d830c757c78f0bbff952a12ac562197957efe705dd6867 | 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | local\-file | 2026\-11\-18T04:44:49\.963Z | 0 full elapsed days | [evidence/4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86\.txt](evidence/4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b633de4cffa24392c6141b4c00d1a232673727be77f53049aa93402bbab754ad | 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | local\-file | 2026\-11\-18T04:44:49\.965Z | 0 full elapsed days | [evidence/482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b\.txt](evidence/482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d40ed2e5c3c8053286431bd54ec6d5c7391c9d3cc91be9e38c47dcf3fa57ddfc | 4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787 | local\-file | 2026\-11\-18T04:44:49\.969Z | 0 full elapsed days | [evidence/4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787\.txt](evidence/4f8c887a3c20fcd2702210c1745eb5699305515581f560e30cebe6ea56983787.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6eaa01059f1cb2b7a34585a853710e9afa93903cbd14b0d4dbeb203d2a03838f | 9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504 | local\-file | 2026\-11\-18T04:44:49\.973Z | 0 full elapsed days | [evidence/9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504\.txt](evidence/9579abde0d33c2b653118432c4653a5db045a17a4c8cdc7fcecb53f8a086b504.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 554086621ed9011cbde4ceca213c7f4083fa3208e3a47d6cfc0708326ef00f9b | ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | local\-file | 2026\-11\-18T04:44:49\.974Z | 0 full elapsed days | [evidence/ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23\.txt](evidence/ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 01\-publisher\-intent | ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/01\-publisher\-intent\.txt](evidence/01-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 01\-http\-response | ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/01\-http\-response\.txt](evidence/01-http-response.txt) | 21fa07330016c47c4d3349e21e2794aacc1e4622f6cf52870f5500de0f16c3fc | Supplied capture summary, without a live HTTP request\. |
| 01\-crawler\-policy | ee2261dacce64ae16e999bcd6a6a6a772fffd4bba9b527fa74b7818ef4c93e23 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/01\-crawler\-policy\.txt](evidence/01-crawler-policy.txt) | 680fa8f9b05a24905071b6cc7070e70dbc4ef39af7a9a1d7e14f64f63691e705 | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 02\-publisher\-intent | 36d0868ec9de61b41e9369cca1796b43f7148cf47df7e0fee33567eb39b9b60b | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/02\-publisher\-intent\.txt](evidence/02-publisher-intent.txt) | 78dadcd00928ec51256158c44d8ea8dc1f4baac289753616876317906cb877df | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 03\-claim\-sources | 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/03\-claim\-sources\.txt](evidence/03-claim-sources.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 03\-schema\-extraction | 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/03\-schema\-extraction\.txt](evidence/03-schema-extraction.txt) | 0c522356b25041d496d85210dae7c21b789759cc375e8c170bfa026ccf25c81d | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 03\-entity\-record | 4619ccd54790d5235bd9651310463d07ef66d8e4956007ea8141330977fa1e86 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/03\-entity\-record\.txt](evidence/03-entity-record.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 04\-inventory\-map | 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/04\-inventory\-map\.txt](evidence/04-inventory-map.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 04\-entity\-record | 3bc5bac882663484e59c85533f590d27834e1893a3c5ac43f9ebfc05a8c10cb0 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/04\-entity\-record\.txt](evidence/04-entity-record.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Two current assertions for the same entity and policy, with no authoritative entitlement table\. |
| 05\-claim\-sources | 482f111d8883c92fc1c361f67f12872ade7c124af6279bd303468502cb40497b | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/05\-claim\-sources\.txt](evidence/05-claim-sources.txt) | 2af2411c2c3cfa27fc949c553e7fdf34b4268519a65ed45aedcb56db3539d9db | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 07\-audience\-context | 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/07\-audience\-context\.txt](evidence/07-audience-context.txt) | 58e51d0700fe2112fa585b218c15b7b68b099d280cdcfa18e478501a33eb7c74 | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 07\-claim\-sources | 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/07\-claim\-sources\.txt](evidence/07-claim-sources.txt) | 5b3ff50e4a81caa84f8f0391b3e8b59e77c3b843bc00327de2146a2a720ffdaa | Dossier attests that the supplied procedure matches\. No independent procedure artifact was delivered\. |
| 07\-locale\-map | 32e94eaaa8c2cd96fd94ea31933c61788654c7ccbb104121aa1c6762210d8317 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/07\-locale\-map\.txt](evidence/07-locale-map.txt) | c30cdeb63bb9875bc0d9e1597a6901bc57c8618b73f41b106a6bd454c75ba271 | Attributed synthetic dossier evidence, restricted to the supplied components\. |
| 08\-claim\-sources | 06c5c872e943806b918019e1f606bd8a873d1fa13117c72f8b3fb403d346aa4c | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/08\-claim\-sources\.txt](evidence/08-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Synthetic aggregate and study metadata only\. Response rows, model details, current observations and independent corroboration are unavailable\. |
| 10\-claim\-sources | 04a7d564744037928ccd7dc37a3c1879b41988a2dd14ca122e093417d4a3a7c4 | supplied\-dossier\-attribution | 2026\-11\-18T04:46:08\.588Z | 0 full elapsed days | [evidence/10\-claim\-sources\.txt](evidence/10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Dossier attests to supplied policy agreement\. No independent policy document or live evidence was delivered\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
