import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const hash = value => createHash('sha256').update(value).digest('hex');
const write = (name, value) => fs.writeFileSync('audit-artifacts/' + name, JSON.stringify(value, null, 2) + '\n');
const snapshots = Object.fromEntries(fs.readFileSync('audit-artifacts/initial/evidence.jsonl', 'utf8').trim().split('\n').map(JSON.parse).filter(x => x.kind === 'content').map(x => [path.basename(x.locator).slice(0,2), x]));
const rules = new Map(JSON.parse(fs.readFileSync('.agents/skills/content-search-audit/rules/core.json')).rules.map(r=>[r.ruleId,r]));
const bundle = {reviews: [], evidence: [], artifacts: {}, findings: []};
const now = new Date().toISOString();
const ref = (n, range) => path.basename(snapshots[n].locator) + ':' + range;
const lines = (n, start, end=start) => snapshots[n].value.split('\n').slice(start-1,end).join('\n');
function add(n, kind, range, value, limitations = 'Attributed synthetic dossier evidence, restricted to the supplied components.') {
  const s = snapshots[n];
  const evidenceId = n + '-' + kind;
  const artifact = 'evidence/' + evidenceId + '.txt';
  const encoding = typeof value === 'string' ? 'utf8' : 'json';
  const encoded = encoding === 'utf8' ? value : JSON.stringify(value);
  bundle.artifacts[artifact] = encoded;
  bundle.evidence.push({itemId:s.itemId,evidenceId,kind,artifact,value,encoding,snapshotHash:hash(encoded),
    method:'supplied-dossier-attribution',locator:ref(n,range),collectedAt:now,redaction:'none',limitations:[limitations],sourceEvidenceIds:[s.evidenceId]});
  return evidenceId;
}
function review(n, ruleId, status, reason, ...ids) {
  bundle.reviews.push({itemId:snapshots[n].itemId,ruleId,status,reason,evidenceIds:[snapshots[n].evidenceId,...ids],reviewer:'offline-audit',reviewedAt:now});
}
function finding(n, title, ruleIds, severity, action, actionReason, remediation, verification, ownerRole, effort, ids=[], actionCondition) {
  bundle.findings.push({findingId:'F'+n,title,affectedItemIds:[snapshots[n].itemId],ruleIds,
    dimensions:[...new Set(ruleIds.map(id=>rules.get(id).dimension))],evidenceIds:[snapshots[n].evidenceId,...ids],
    severity,confidence:'high',classification:'observed',action,actionReason,remediation,verification,ownerRole,effort,...(actionCondition?{actionCondition}:{})});
}
const intent = add('01','publisher-intent','3',lines('01',3));
const http = add('01','http-response','4-5',{status:200,observedAt:'2026-11-10T08:00:00Z',headers:{'x-robots-tag':'noindex'}},'Supplied capture summary, without a live HTTP request.');
const crawler = add('01','crawler-policy','5',lines('01',5));
review('01','seo-index-controls','fail','The supplied Google-indexing intent conflicts with the captured noindex response header. The raw meta and self-canonical do not undo the header.',intent,http);
finding('01','Response-level noindex conflicts with Google indexing intent',['seo-index-controls'],'high','update','The supplied response blocks intended indexing eligibility.','Remove the unintended noindex response directive for /product.','Compare a new supplied HTTP/header capture, raw HTML, crawler policy and recorded intent. Check actual Google indexing separately if an export becomes available.','Web platform owner','small',[intent,http,crawler]);
const route = add('02','publisher-intent','3',lines('02',3));
review('02','seo-response','unknown','Two supplied 301 hops form a loop. No final response exists in the capture, so the final-response check is unresolved.',route);
finding('02','Product route redirects in a loop',['seo-response'],'high','update','Both captured routes end up back at /old, preventing the intended access path.','Serve /new successfully and keep one redirect from /old to /new.','Inspect a new complete captured chain from both starting URLs and confirm that /old has one hop and /new returns the product page with HTTP 200.','Web platform owner','medium',[route]);
const price = add('03','claim-sources','3-4',lines('03',3,4));
const schema = add('03','schema-extraction','8-18',lines('03',8,18));
const offer = add('03','entity-record','3-4',lines('03',3,4));
review('03','seo-structured-data','fail','The complete supplied JSON-LD Offer price is 19 USD while the visible owner-approved US monthly price is 29 USD before taxes. Feature eligibility remains unverified.',schema);
review('03','aio-entity-consistency','fail','The visible price and the structured offer conflict on the same plan and capture.',offer);
finding('03','Machine-readable offer disagrees with approved visible price',['seo-structured-data','aio-entity-consistency'],'medium','update','The existing offer gives consumers of the two representations different prices.','Align the structured Offer with the approved USD 29 US monthly pre-tax amount and preserve billing scope.','Parse revised JSON-LD and compare name, price, currency, destination and billing scope with the visible copy and approved record. Check feature eligibility separately.','Product content and markup owners','small',[price,schema,offer]);
const pair = add('04','inventory-map','3-6',lines('04',3,6));
const conflicting = add('04','entity-record','3-6',lines('04',3,6),'Two current assertions for the same entity and policy, with no authoritative entitlement table.');
review('04','portfolio-contradictions','fail','The two current components give incompatible allowances for the same policy. The correct value is unavailable.',pair,conflicting);
review('04','aio-entity-consistency','fail','The same entity, policy version, market and billing period have different stated allowances.',conflicting);
finding('04','Current Starter allowances conflict across two pages',['portfolio-contradictions','aio-entity-consistency','quality-claims','aeo-answer-evidence'],'medium','investigate','The contradiction is confirmed and the correct allowance cannot be identified from the supplied dossier.','Obtain the authoritative entitlement table for the 2026-10-01 policy, then reconcile both current passages to its value.','Compare both revised statements with the approved table for the same plan, market, period and version.','Product policy owner','medium',[pair,conflicting]);
const policy = add('05','claim-sources','5',lines('05',5));
review('05','quality-claims','fail','The draft removes the membership eligibility limit and the minimum 24-hour notice. Exact fees for other tiers remain unavailable.',policy);
review('05','aeo-answer-evidence','fail','The draft directly answers fee eligibility and notice but contradicts the supplied policy on both conditions.',policy);
finding('05','Vietnamese ticket-change draft overstates eligibility and omits notice',['quality-claims','aeo-answer-evidence'],'high','update','Readers may rely on free changes or late requests where the policy does not allow them.','Revise in Vietnamese to limit free changes to hạng Thành viên, require at least 24 hours before departure, and refer other tiers to the separate fee schedule without stating amounts.','Compare the revised Vietnamese copy against the supplied policy for eligibility, the departure-based deadline and treatment of other tiers. Verify amounts only against an authorized fee schedule.','Vietnamese policy content owner','small',[policy]);
const audience = add('07','audience-context','3',lines('07',3));
const procedure = add('07','claim-sources','5',lines('07',5),'Dossier attests that the supplied procedure matches. No independent procedure artifact was delivered.');
const locale = add('07','locale-map','3-5',lines('07',3,5));
review('07','quality-task-fit','pass','The Vietnamese help text serves the stated Vietnamese customers with ordered export steps, attachment handling and no processing-time promise.',audience);
review('07','quality-claims','pass','The dossier explicitly confirms the supplied product procedure matches all steps and limits of the help content.',procedure);
review('07','aeo-answer-evidence','pass','The supplied procedure confirms the export instructions, attachment exception and timing caveat.',procedure);
review('07','aio-retrievable-facts','pass','The necessary steps and caveats are present in readable Vietnamese text in this export.',audience);
review('07','seo-locales','unknown','An English counterpart is explicitly outside publisher intent. Deployed annotations and canonical relationships remain unavailable.',locale);
const study = add('08','claim-sources','3-5',lines('08',3,5),'Synthetic aggregate and study metadata only. Response rows, model details, current observations and independent corroboration are unavailable.');
review('08','quality-claims','pass','The entire draft correctly describes the supplied publication timing, collection timing, sample language/interface and aggregate and explicitly limits current inference.',study);
review('08','quality-freshness','pass','November 2026 publication and the 1–14 February 2024 collection window are distinct and accurately framed as of 2026-11-16.',study);
const exports = add('10','claim-sources','3',lines('10',3),'Dossier attests to supplied policy agreement. No independent policy document or live evidence was delivered.');
review('10','quality-claims','pass','The user-visible account-owned-records limitation is explicitly corroborated by supplied policy. The hidden directives are a separate content-integrity issue, not supporting claims.',exports);
finding('10','Captured hidden comment contains directives aimed at automated readers',['aio-retrievable-facts'],'medium','update','The exact comment contains task override, side-effect and false-reporting directives. The capture establishes presence only.','Remove the comment from production-bound source and any reusable template that emits it.','Search a fresh authorized raw-source export and template for the full comment or its distinctive directive text and confirm the visible export limitation still matches policy.','Template owner','small',[],'The content owner confirms the comment is unintended in a production-bound artifact.');
write('review.json',bundle);
write('study-options.json',{studySources:[{sourceId:'08-synthetic-api-panel',kind:'historical-study',locator:'08-study.md:3-5',sourceText:snapshots['08'].value,sourceHash:hash(snapshots['08'].value),synthetic:true,
  scope:'Editorial as of 2026-11-16. Published 2026-11-01. Synthetic English API panel collected 2024-02-01 through 2024-02-14; 40 of 100 responses cited video sources.',
  limitations:['No response-level records or later measurements.','Aggregate is historical and reports video-source citations, with no current brand, consumer UI or cross-surface inference.'],
  passages:[{startLine:3,endLine:5,quote:lines('08',3,5)}]}]});
