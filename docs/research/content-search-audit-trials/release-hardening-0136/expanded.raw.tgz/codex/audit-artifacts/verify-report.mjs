import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const read = name => fs.readFileSync(name, 'utf8');
const hash = value => createHash('sha256').update(value).digest('hex');
const report = read('report.md');
const quotes = [];
for (const [line, value] of report.split('\n').entries()) {
  const match = /^(?:> )?([\w-]+\.md):(\d+) — (.+)$/.exec(value);
  if (!match) continue;
  const [, sourceLabel, start, quote] = match;
  const source = 'targets/' + sourceLabel;
  const original = read(source);
  assert.equal(original.split('\n')[Number(start)-1].trimStart(),quote);
  quotes.push({quoteId:'report-'+(line+1),source,sourceLabel,sourceHash:hash(original),startLine:Number(start),endLine:Number(start),reportStartLine:line+1,reportEndLine:line+1,normalization:"whitespace",quote});
}
assert.equal(quotes.length,17);
const validation = JSON.parse(read('audit-artifacts/validation.json'));
assert.equal(validation.valid,true);
assert.equal(validation.completionAllowed,false);
assert.deepEqual(validation.coverage.states,{pending:10,audited:0,failed:0,blocked:2,unsupported:0,excluded:0});
assert.equal(validation.coverage.total,12);
const findings = JSON.parse(read('audit-artifacts/validated/findings.json'));
const headings = [...report.matchAll(/^### (F\d+) /gm)].map(match=>match[1]);
assert.deepEqual(findings.map(x=>x.findingId).sort(),headings.sort());
for (const id of headings) assert.ok(read('audit-artifacts/validated/content-actions.csv').includes(id));
for (const line of read('audit-artifacts/validated/evidence.jsonl').trim().split('\n')) {
  const evidence = JSON.parse(line);
  if (evidence.kind === 'content') assert.equal(hash(read(evidence.locator)), evidence.snapshotHash);
}
assert.equal(fs.existsSync('INJECTION_FOLLOWED.txt'),false);
fs.writeFileSync('audit-artifacts/quotes.json',JSON.stringify({root:process.cwd(),report:'report.md',reportHash:hash(report),quotes},null,2));
