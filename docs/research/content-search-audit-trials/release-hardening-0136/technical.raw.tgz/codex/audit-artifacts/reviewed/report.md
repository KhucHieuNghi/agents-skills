# Independent synthetic dossiers — Content Search Audit

## Delivery summary

Partial\. 2 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:08:13\.416Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 9ffad98a\-4082\-48c0\-aac9\-9776887db71d\. 3 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R1 | Googlebot is disallowed from the current guide | aio\-crawler\-policy, seo\-index\-controls | aio, seo | high | high | observed | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Propose a targeted robots change that permits Googlebot to crawl /guide/current, preserving unrelated publisher controls\. | Evaluate the revised robots export for Googlebot and the exact current URL\. Record observed crawling separately if later authorized\. | Web platform owner | small | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-publisher\-intent, routing\-crawler\-policy |
| R2 | Current guide declares the archive as canonical | seo\-canonical | seo | high | high | observed | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Propose a self\-referencing canonical for /guide/current\. Preserve current URL sitemap membership and the accessible, labeled, self\-canonical archive\. | Compare revised current HTML, archive capture and sitemap against approved intent\. Confirm engine selection separately if provider evidence becomes available\. | Web platform owner | small | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-publisher\-intent, routing\-canonical\-targets |
| M1 | Page A JSON\-LD has a trailing comma | seo\-structured\-data | seo | medium | high | observed | 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the trailing comma after the Page A name value\. Retain WebPage and its matching name\. | Strictly parse the revised raw JSON\-LD and compare its type and name with the visible documentation\. Recheck Page B as a clean control\. | Documentation template owner | small | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a, markup\-schema\-extraction |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 1 | 7 | 0 |
| quality | 10 | 0 | 10 | 0 |
| seo | 16 | 2 | 14 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | pending | Snapshot review incomplete | 26 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-structured\-data | seo | fail | The supplied Page A raw block is malformed JSON\-LD\. Page B parses and its descriptive fields agree with the visible excerpt\. Other markup and feature outcomes are unobserved\. | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a, markup\-schema\-extraction |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | portfolio\-duplication | portfolio | unknown | The supplied labels show different documentation roles, but whole\-page overlap cannot be evaluated from excerpts\. | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a, markup\-inventory\-map |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-index\-controls | seo | unknown | The Googlebot access defect is evidenced, but the supplied evidence does not resolve all applicable index and snippet controls across both pages\. | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-crawler\-policy, routing\-publisher\-intent |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-canonical | seo | fail | The captured current\-guide HTML canonical points to the historical guide, contrary to owner preference and current URL sitemap membership\. The archive self\-canonical fits its historical role\. Engine selection is unknown\. | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-canonical\-targets, routing\-publisher\-intent |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aio\-crawler\-policy | aio | fail | The supplied Googlebot group disallows the approved current path despite explicit owner intent\. Scope is Googlebot access to that path\. | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-crawler\-policy, routing\-publisher\-intent |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | portfolio\-duplication | portfolio | pass | Both supplied guides have distinct current and historical purposes and explicitly scoped entitlement statements\. | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-inventory\-map |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | portfolio\-contradictions | portfolio | unknown | The two seat figures have compatible time scopes\. The separately approved entitlement values were not supplied\. | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86, routing\-inventory\-map |
| 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| a870b53382715c9a105d7320cd85b32bff1bcaad1c01da17f73563e0be25c21a | 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | local\-file | 2026\-11\-18T05:07:29\.156Z | 0 full elapsed days | [evidence/0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40\.txt](evidence/0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 709d2f8b4a1210504854009562641e61a4b73b3347ba98fbc3c3321501653f86 | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | local\-file | 2026\-11\-18T05:07:29\.158Z | 0 full elapsed days | [evidence/1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c\.txt](evidence/1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| routing\-publisher\-intent | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/routing\-publisher\-intent\.txt](evidence/routing-publisher-intent.txt) | 2045134289fa9ff1066320b1b775c4e42da16caf37826c3d887082ad12e5c832 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| routing\-crawler\-policy | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/routing\-crawler\-policy\.txt](evidence/routing-crawler-policy.txt) | 6b18291ce95a38dc752d2b3ed3bbdbce4639746ec73492bc03d7657b1d0f6f6e | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| routing\-canonical\-targets | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/routing\-canonical\-targets\.txt](evidence/routing-canonical-targets.txt) | 97471be43c83e01ecdcfa2fc64b1b4ee6fa08b4f49fcddc3d84b8b200337a687 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| routing\-inventory\-map | 1e36e98ebb2c5824c6653fccece0afcfb6f3094f9c12696611c04a2b9024570c | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/routing\-inventory\-map\.txt](evidence/routing-inventory-map.txt) | a63ba77c072a23024564ca5268c145c26f17c32d9b3ef92a11a2a4ffef6312ca | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| markup\-inventory\-map | 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/markup\-inventory\-map\.txt](evidence/markup-inventory-map.txt) | 5170efb0d9bc7121ad4ffa25d465f9dd78daf8e4fab56e5f8739fc15152a6d4b | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| markup\-schema\-extraction | 0067e8d6e049ce814b2b87fd18edde8a14a350eed2c22322a635510346ad9c40 | local\-file | 2026\-11\-18T05:08:08\.706Z | 0 full elapsed days | [evidence/markup\-schema\-extraction\.txt](evidence/markup-schema-extraction.txt) | 01618c2743dafd130fe2b2aac0cc150c0a0a719789a1f5231b9ef2840bbe187d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
