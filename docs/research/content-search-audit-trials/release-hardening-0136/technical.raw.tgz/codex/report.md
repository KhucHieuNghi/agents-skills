# Content search audit

This partial offline audit covers two independent synthetic dossiers. Both were collected and reviewed. Validated coverage is **2 declared dossiers, 0 fully audited and 2 pending**, with 0 excluded, blocked, failed or unsupported. The four page subjects and accompanying exports are evidence within the two dossier inventory items. Discovery is complete for the supplied files, with 0 queued discovery tasks. Live site inventories remain unknown.

There are **3 findings**. Severity reflects impact on stated owner intent. All three have high confidence within their fixture scope.

## Routing dossier

### R1 · High · Googlebot is disallowed from the current guide

The owner approved /guide/current as of 2026-11-16 and explicitly wants Googlebot to crawl it. The Googlebot-specific robots group disallows the exact current path. The wildcard allowance does not override that group. This is one issue across technical SEO and AI search readiness.

01-routing.md:15-19

```text
User-agent: Googlebot
Disallow: /guide/current

User-agent: *
Allow: /
```

The current guide returned HTTP 200 in an ordinary browser-agent capture. Actual Googlebot requests and crawl outcomes remain unknown.

**Action and verification** — Propose a targeted robots change that permits Googlebot to crawl https://routing.example.test/guide/current while preserving unrelated controls. Evaluate the revised robots export for that agent and exact URL. If authorized evidence later becomes available, check crawler logs for actual requests.

### R2 · High · The current guide declares the archive as canonical

The current guide HTML points at /guide/2024 while the sitemap lists /guide/current. The captured signals conflict with each other, and the canonical conflicts with the owner's preferred URL. The archive's reported self-canonical fits its historical role.

01-routing.md:33

```text
    <link rel="canonical" href="https://routing.example.test/guide/2024" />
```

01-routing.md:46

```text
  <url><loc>https://routing.example.test/guide/current</loc></url>
```

**Action and verification** — Propose a self-referencing canonical for the current guide. Retain its sitemap entry and keep the archive accessible, clearly labeled and self-canonical. Compare the revised current HTML, any supplied canonical headers, sitemap and archive capture against that intent. Engine-selected canonical remains unknown and requires separate provider evidence.

### Clean and uncertain routing observations

The current title and heading identify the current guide. The current and historical seat figures have distinct time scopes. The owner describes the archive statement as accurate for its historical scope. The two pages serve legitimate versioned tasks, and the supplied capture contains no current-guide redirect. The dated owner intent establishes which guide is preferred. An underlying entitlement record for independently confirming the current three-seat figure was not supplied. Version labels help readers interpret the supplied answer passages. Genuine customer questions and a link graph would be needed to assess coverage and navigation.

01-routing.md:36-37

```text
    <h1>Current product guide</h1>
    <p>Current entitlement: 3 seats.</p>
```

01-routing.md:52-55

```text
The archive returns HTTP 200 and visibly states “2024 archive — former entitlement:
2 seats.” Its self-canonical names `/guide/2024`. The archive statement is accurate
for its explicit historical scope. No current-guide redirect is present in the
supplied capture. The owner has not authorized deletion, redirects or config edits.
```

## Markup dossier

### M1 · Medium · Page A JSON-LD fails strict JSON parsing

The Cedar Library overview’s raw JSON-LD payload has a trailing comma after its last member. Strict parsing rejected the payload, preventing strict consumption of the supplied machine-readable description.

02-markup.md:13-19

```text
<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Cedar Library",
  }
</script>
```

**Action and verification** — Remove the trailing comma after the Page A name. Retain the descriptive WebPage type and matching name. Strictly parse the revised raw script payload and compare the parsed name and type with the visible overview. Use the supplied Page B block as a clean comparison.

### Clean and uncertain markup observations

Page B’s raw block parses as JSON, and its name matches the visible Export reference heading. The generic WebPage description fits the owner’s documentation intent. Both pages are reported HTTP 200, and their visible excerpts distinguish overview and export reference as separate documentation tasks. Full task coverage, link paths, corroboration of the maintainer claim, other markup formats and rendered state remain unknown. The owner requested machine-readable descriptions and excluded product-offer treatment. Rich-result eligibility and downstream use were unmeasured.

02-markup.md:28-34

```text
<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Export reference"
  }
</script>
```

## Coverage and evidence needed

| Dimension | Resolved checks | Unknown checks | Evidence needed for broader assessment |
| --- | ---: | ---: | --- |
| Quality | 0 | 10 | Full page content and media evidence, dated entitlement and maintainer records |
| SEO | 2 | 14 | Complete responses and directives, rendered captures, link and locale evidence, indexed state |
| AIO | 1 | 5 | Publisher intent and controls for named retrieval surfaces, corroborating entity records and full captured content |
| AEO | 0 | 6 | Actual customer questions, full passages and source-backed claims |
| GEO | 0 | 6 | Dated AI response captures and documented prompt cohorts |
| Portfolio | 1 | 7 | Full content, navigation graph and evidence of demand or customer tasks |

All 52 planned checks are present. Four resolved and 48 remain unknown. Structural validation passed and the run remains partial. AIO here refers to AI search optimization. Google AI Overviews is a specific product surface with no supplied observations.

No Search Console, Bing, GA4, server-log, historical study, field performance or response-level AI measurements were supplied. Search traffic, canonical selection, AI mentions, citations and answer accuracy are unmeasured. In a later authorized measurement pass, use dated provider exports with page and query scope and repeated AI response captures grouped by named surface, locale and versioned prompt cohort. Retain full responses and citation URLs, and adjudicate claims against dated sources before reporting rates with denominators. The audit ran offline.

## Audit package

- [Packaged report](audit-artifacts/reviewed/report.md) and [HTML report](audit-artifacts/reviewed/report.html)
- [Delivery summary](audit-artifacts/reviewed/delivery-summary.md), [coverage](audit-artifacts/reviewed/coverage.json) and [validation receipt](audit-artifacts/validation.json)
- [Findings](audit-artifacts/reviewed/findings.json) and [action backlog](audit-artifacts/reviewed/content-actions.csv)
- [Quote ledger](audit-artifacts/quotes.json) and [quote verification receipt](audit-artifacts/quote-receipt.json)
