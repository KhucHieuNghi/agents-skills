// Builds the review bundle for the two supplied dossiers. Reads collected
// snapshots as inert text. No network access; no target script is executed.
// JSON-LD blocks are parsed as data with JSON.parse (a strict JSON grammar check).
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const [pkgArg, runArg, outArg] = process.argv.slice(2);
const pkg = path.resolve(pkgArg);
const run = path.resolve(runArg);
const { loadAuditData } = await import(
  pathToFileURL(path.join(pkg, "scripts/lib/validate.mjs"))
);
const { parseRobots, evaluateRobots } = await import(
  pathToFileURL(path.join(pkg, "scripts/lib/robots.mjs"))
);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const audit = await loadAuditData(run);
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 (content-search-audit host review)";

const byName = (name) => {
  const item = audit.inventory.find((i) => i.path.endsWith(name));
  const snap = audit.evidence.find(
    (e) => e.itemId === item.itemId && e.kind === "content",
  );
  return { item, snap, lines: snap.value.split("\n") };
};
const R = byName("01-routing.md");
const M = byName("02-markup.md");
const span = (d, a, b) => d.lines.slice(a - 1, b).join("\n");

const artifacts = {};
const evidence = [];
function add(d, id, kind, locator, value, limitations, method) {
  const json = typeof value !== "string";
  const bytes = json ? JSON.stringify(value, null, 2) + "\n" : value;
  const artifact = `evidence/${id}.${json ? "json" : "txt"}`;
  artifacts[artifact] = bytes;
  evidence.push({
    evidenceId: id,
    itemId: d.item.itemId,
    kind,
    method,
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    byteLength: Buffer.byteLength(bytes),
    redaction: "none; synthetic owner-supplied content retained locally",
    limitations,
    sourceEvidenceIds: [d.snap.evidenceId],
    artifact,
    encoding: json ? "json" : "utf8",
    value: json ? JSON.parse(bytes) : bytes,
  });
  return id;
}
const synthetic =
  "Synthetic owner-supplied dossier; not independently verified and not a live capture by the auditor";

// ---------- Dossier 01: routing ----------
const robotsText = span(R, 15, 19);
const parsed = parseRobots(robotsText + "\n");
const decide = (url, agent) => {
  const r = evaluateRobots(parsed, url, agent);
  return { url, agent, allowed: r.allowed, matchedRule: r.matchedRule ?? null };
};
const cur = "https://routing.example.test/guide/current";
const arc = "https://routing.example.test/guide/2024";
const robotsDecisions = [
  decide(cur, "Googlebot"),
  decide(arc, "Googlebot"),
  decide(cur, "ExampleOtherBot"),
  decide(arc, "ExampleOtherBot"),
];

add(
  R,
  "r01-extracted-text",
  "extracted-text",
  "01-routing.md:1-55",
  R.snap.value,
  [
    "Identity extraction of the UTF-8 Markdown dossier; nonempty text does not establish quality",
    synthetic,
  ],
  "identity text extraction of collected local Markdown snapshot",
);
add(
  R,
  "r01-owner-intent",
  "publisher-intent",
  "01-routing.md:3-10 and 01-routing.md:52-55",
  `Owner statements preserved verbatim from the supplied dossier (lines 3-10):\n${span(R, 3, 10)}\n\nLines 52-55:\n${span(R, 52, 55)}\n`,
  [
    synthetic,
    "Owner intent is an approved comparison basis for this audit, not verified platform behavior",
    "Intent is stated for Googlebot and for the current/archive roles only; intent for other crawlers, AI training or user-triggered retrieval agents is not stated",
  ],
  "verbatim preservation of owner context from supplied dossier",
);
add(
  R,
  "r01-crawler-policy",
  "crawler-policy",
  "01-routing.md:12-20",
  {
    surface: "supplied robots.txt export (section A), text only",
    robotsUrlAsLabelled: "https://routing.example.test/robots.txt",
    robotsText,
    decisions: robotsDecisions,
    decisionMethod:
      "Packaged scripts/lib/robots.mjs parser (RFC 9309-informed, package review date 2026-11-16) applied offline to the supplied text; URLs used only as identifiers, not requested. 'ExampleOtherBot' is a placeholder token standing for any agent without its own group.",
  },
  [
    synthetic,
    "A robots decision is a permission evaluation of supplied text, not an observation that any crawler fetched or skipped a URL",
    "Capture date of the robots.txt export is not stated in the dossier",
    "Engine-specific handling by Google was not verified against live documentation (offline audit)",
  ],
  "offline evaluation of supplied robots.txt text",
);
add(
  R,
  "r01-canonical-targets",
  "canonical-targets",
  "01-routing.md:33, 01-routing.md:46, 01-routing.md:52-53",
  {
    ownerPreferredCurrentGuide: "/guide/current (as of 2026-11-16, 01-routing.md:5)",
    declarations: [
      {
        page: "/guide/current",
        declaredCanonical: "https://routing.example.test/guide/2024",
        locator: "01-routing.md:33",
        surface: "raw HTML supplied in section B",
        relation: "cross-URL; points at the archived guide",
      },
      {
        page: "/guide/2024",
        declaredCanonical: "/guide/2024",
        locator: "01-routing.md:53",
        surface: "owner description in section D; raw archive HTML not supplied",
        relation: "self-referential",
      },
    ],
    sitemapMembership: [
      { loc: cur, locator: "01-routing.md:46" },
    ],
    engineSelectedCanonical: "not available (01-routing.md:8-9)",
  },
  [
    synthetic,
    "Declared canonicals only; no engine-selected canonical is supplied",
    "Archive canonical is described by the owner, not shown as raw markup",
    "Response captured with an ordinary browser user agent, not Googlebot; HTTP Link headers beyond the two shown header lines are not supplied",
  ],
  "structured transcription of canonical and sitemap signals from supplied dossier",
);
add(
  R,
  "r01-http-response",
  "http-response",
  "01-routing.md:24-27 and 01-routing.md:52",
  {
    status: 200,
    components: [
      { url: "/guide/current", status: 200, locator: "01-routing.md:25", form: "supplied response status line" },
      { url: "/guide/2024", status: 200, locator: "01-routing.md:52", form: "owner statement" },
    ],
    userAgent: "ordinary browser user agent, not Googlebot (01-routing.md:9-10)",
  },
  [
    synthetic,
    "Supplied transcription for two component URLs in one dossier item; not captured by the auditor",
    "Transport only: not index status, not robots permission, not what Googlebot would receive",
    "Capture date not stated",
  ],
  "transcription of supplied HTTP status evidence",
);

// ---------- Dossier 02: markup ----------
const jsonOf = (a, b) => span(M, a, b);
const tryParse = (text) => {
  try {
    return { parses: true, value: JSON.parse(text) };
  } catch (error) {
    return { parses: false, error: String(error.message) };
  }
};
const blockA = jsonOf(14, 18);
const blockB = jsonOf(29, 33);
add(
  M,
  "m02-extracted-text",
  "extracted-text",
  "02-markup.md:1-40",
  M.snap.value,
  [
    "Identity extraction of the UTF-8 Markdown dossier; nonempty text does not establish quality",
    synthetic,
  ],
  "identity text extraction of collected local Markdown snapshot",
);
add(
  M,
  "m02-owner-intent",
  "publisher-intent",
  "02-markup.md:3-5 and 02-markup.md:37-40",
  `Owner statements preserved verbatim from the supplied dossier (lines 3-5):\n${span(M, 3, 5)}\n\nLines 37-40:\n${span(M, 37, 40)}\n`,
  [
    synthetic,
    "Owner request is the comparison basis; it does not establish any engine feature eligibility",
  ],
  "verbatim preservation of owner context from supplied dossier",
);
add(
  M,
  "m02-schema-extraction",
  "schema-extraction",
  "02-markup.md:13-19 and 02-markup.md:28-34",
  {
    surface: "raw source blocks as supplied in the dossier; no rendered snapshot",
    blocks: [
      {
        page: "Page A: current library overview",
        locator: "02-markup.md:13-19",
        jsonText: blockA,
        strictJson: tryParse(blockA),
        visibleHeading: "Cedar Library (02-markup.md:9)",
      },
      {
        page: "Page B: current export reference",
        locator: "02-markup.md:28-34",
        jsonText: blockB,
        strictJson: tryParse(blockB),
        visibleHeading: "Export reference (02-markup.md:24)",
      },
    ],
    parseMethod:
      "JSON.parse on the text between the script tags, treated as inert data; no script executed, no schema or URL fetched",
  },
  [
    synthetic,
    "Strict JSON grammar result only; how any particular consumer or search engine handles the block was not observed",
    "No rich-result testing, rendered DOM, indexed state or other markup formats supplied",
    "schema.org vocabulary was not fetched; type/property meaning rests on the auditor's general knowledge",
  ],
  "offline extraction and strict JSON parse of supplied JSON-LD text",
);
add(
  M,
  "m02-http-response",
  "http-response",
  "02-markup.md:4",
  {
    status: 200,
    components: [
      { url: "Page A", status: 200 },
      { url: "Page B", status: 200 },
    ],
    statement: "Both pages return HTTP 200.",
    userAgent: "not stated",
  },
  [
    synthetic,
    "Owner statement for two component pages; URLs, user agent, headers and capture date are not supplied",
    "Transport only: not index status or rendered completeness",
  ],
  "transcription of supplied HTTP status statement",
);

const snapR = R.snap.evidenceId;
const snapM = M.snap.evidenceId;
const rev = (d, ruleId, status, reason, evidenceIds) => ({
  itemId: d.item.itemId,
  ruleId,
  status,
  reason,
  evidenceIds,
  reviewer,
  reviewedAt: now,
});

const reviews = [
  rev(
    R,
    "aio-crawler-policy",
    "fail",
    "Section A robots.txt has a Googlebot-specific group that disallows /guide/current, while the owner states they want Googlebot to crawl the current guide. Googlebot is the only crawler whose intent is stated; the wildcard group allows other agents, and intent for other search, training or user-triggered agents is unstated (not assessed as defects). Permission evaluation of supplied text only; no crawl behaviour observed.",
    ["r01-crawler-policy", "r01-owner-intent"],
  ),
  rev(
    R,
    "seo-canonical",
    "fail",
    "Section B: the current guide declares a canonical to /guide/2024, the archive the owner says is not the preferred current guide; the sitemap lists /guide/current. The archive's self-canonical (section D, described not shown) is consistent with intent and is clean. Engine-selected canonical is unavailable and stays unknown.",
    [snapR, "r01-canonical-targets", "r01-owner-intent"],
  ),
  rev(
    R,
    "seo-index-controls",
    "unknown",
    "No index or snippet directive (meta robots, X-Robots-Tag) appears in the supplied current-guide capture, but only two response header lines are shown, the capture used a browser user agent, and the archive's raw source and headers are not supplied. robots.txt Disallow is a crawl control, not an index directive; the crawl conflict is persisted as finding F1 and referenced here without resolving this check.",
    [snapR, "r01-http-response", "r01-owner-intent", "r01-crawler-policy"],
  ),
  rev(
    R,
    "portfolio-duplication",
    "unknown",
    "Current and archive guides are owner-declared version variants (current vs. 2024 archive) and are to be preserved. The cross-URL canonical in finding F2 declares the current version a duplicate of the archive. Full archive content and a complete inventory map are not supplied, so overlap of task coverage cannot be assessed.",
    [snapR, "r01-canonical-targets", "r01-owner-intent"],
  ),
  rev(
    R,
    "portfolio-contradictions",
    "unknown",
    "Observed clean component: 'Current entitlement: 3 seats' (current guide) and 'former entitlement: 2 seats' (2024 archive) are date-scoped and do not contradict; the owner states the archive statement is accurate for its historical scope. No authoritative entity record or inventory map is supplied, so the check cannot resolve.",
    [snapR, "r01-owner-intent"],
  ),
  rev(
    R,
    "quality-claims",
    "unknown",
    "Archive claim (2 seats, 2024) is owner-confirmed for its historical scope. The current guide's 'Current entitlement: 3 seats.' has no supplied approved source; unverifiable, not false. Check unresolved for that component.",
    [snapR, "r01-owner-intent"],
  ),
  rev(
    M,
    "seo-structured-data",
    "fail",
    "Page A's JSON-LD block has a trailing comma after the name property and does not parse as strict JSON, so the supplied raw source carries no parseable machine-readable description for Page A, contrary to the owner's request. Page B's block parses and its WebPage name matches the visible heading (clean component). Owner did not request Google rich-result eligibility; none assessed. Rendered state unknown.",
    [snapM, "m02-schema-extraction", "m02-owner-intent"],
  ),
  rev(
    M,
    "quality-claims",
    "unknown",
    "Visible claim 'maintained by Cedar Tools' (Page A) has no supplied source; unverifiable, not false. No other material factual claims are supplied.",
    [snapM],
  ),
  rev(
    M,
    "portfolio-contradictions",
    "unknown",
    "Observed clean component: both pages use the same product name 'Cedar Library' in visible text. No entity record or inventory map supplied; check unresolved.",
    [snapM],
  ),
];

const rid = R.item.itemId;
const mid = M.item.itemId;
const findings = [
  {
    findingId: "F1-googlebot-disallow-current-guide",
    title:
      "robots.txt disallows Googlebot from the current guide the owner wants Googlebot to crawl",
    affectedItemIds: [rid],
    ruleIds: ["aio-crawler-policy", "seo-index-controls"],
    dimensions: ["seo", "aio"],
    evidenceIds: [snapR, "r01-crawler-policy", "r01-owner-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "Supplied robots.txt text conflicts directly with the owner's stated crawl intent for /guide/current; one consolidated issue covering the search crawl (SEO) and Google AI-feature discovery prerequisite (AIO).",
    actionCondition:
      "the owner separately authorizes a robots.txt change (the dossier states config edits are not authorized)",
    remediation:
      "Change the Googlebot group so that the effective decision for Googlebot on /guide/current is allow, for example by removing the 'Disallow: /guide/current' line (or the Googlebot group, if it has no other purpose) so Googlebot falls back to the existing wildcard 'Allow: /'. Do not alter access for /guide/2024 or add rules for other crawlers. Coordinate with F2: once crawlable, the page's canonical will be readable.",
    verification:
      "Re-export robots.txt and re-evaluate the effective group and rule for user agent Googlebot on the exact URL /guide/current; expected result: allowed, with /guide/2024 still allowed. This confirms permission only. Whether Googlebot then fetches the page needs Googlebot-attributed server-log entries or engine crawl data, which are not supplied; any specific tool workflow is unverified offline.",
    ownerRole: "Site/platform owner (robots.txt)",
    effort: "small",
  },
  {
    findingId: "F2-current-guide-canonical-to-archive",
    title:
      "Current guide declares the 2024 archive as its canonical, contrary to the approved preferred URL",
    affectedItemIds: [rid],
    ruleIds: ["seo-canonical", "portfolio-duplication"],
    dimensions: ["seo", "portfolio"],
    evidenceIds: [snapR, "r01-canonical-targets", "r01-owner-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "The declared canonical on /guide/current names /guide/2024 while the owner's approved current guide and the sitemap name /guide/current; one consolidated issue covering the canonical signal (SEO) and the current/archive version relationship (portfolio).",
    actionCondition:
      "the owner separately authorizes a change to the current guide's head markup",
    remediation:
      "Change the canonical link on /guide/current to the self-referential https://routing.example.test/guide/current. Keep /guide/2024 served, labelled as the 2024 archive and self-canonical; no redirect, deletion or consolidation is proposed.",
    verification:
      "Re-capture the raw HTML of /guide/current and confirm exactly one canonical link whose href is https://routing.example.test/guide/current, that the sitemap still lists that URL, and that the archive still returns 200 with its self-canonical and archive label. This verifies the declared signal only; the engine-selected canonical needs engine data that is not supplied.",
    ownerRole: "Web/content owner (page templates)",
    effort: "small",
  },
  {
    findingId: "F3-page-a-jsonld-trailing-comma",
    title:
      "Page A JSON-LD is not valid JSON (trailing comma), so its machine-readable description cannot be parsed",
    affectedItemIds: [mid],
    ruleIds: ["seo-structured-data"],
    dimensions: ["seo"],
    evidenceIds: [snapM, "m02-schema-extraction", "m02-owner-intent"],
    severity: "medium",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "Strict JSON parse of the supplied Page A block fails; the owner asks for correct machine-readable descriptions. Page B is clean and needs no change.",
    actionCondition:
      "the owner separately authorizes a source edit to Page A",
    remediation:
      "Remove the trailing comma after \"name\": \"Cedar Library\" in Page A's JSON-LD block, keeping @context, @type WebPage and name unchanged. Do not add Product, FAQPage, review, rating or offer markup. Leave Page B's block as is.",
    verification:
      "Re-capture Page A's raw source and parse the text inside the application/ld+json script element with a strict JSON parser; expected: it parses to an object with @type WebPage and name 'Cedar Library', matching the visible heading. Rendered-DOM state and any engine feature eligibility remain separate, unrequested and unverified.",
    ownerRole: "Documentation site developer",
    effort: "small",
  },
];

const bundle = { artifacts, evidence, reviews, findings };
await writeFile(path.resolve(outArg), JSON.stringify(bundle, null, 2) + "\n");
console.log(
  JSON.stringify(
    {
      builtAt: now,
      robotsDecisions,
      pageA: tryParse(blockA),
      pageB: tryParse(blockB),
      evidence: evidence.length,
      reviews: reviews.length,
      findings: findings.length,
    },
    null,
    2,
  ),
);
