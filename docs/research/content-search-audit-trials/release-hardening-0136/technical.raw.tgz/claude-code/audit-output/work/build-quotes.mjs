// Builds the quotation ledger for the root report.md against the two targets.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const [rootArg, outArg] = process.argv.slice(2);
const root = path.resolve(rootArg);
const hash = (b) => createHash("sha256").update(b).digest("hex");
const norm = (s) => s.replace(/\s+/g, " ").trim();
const reportBytes = await readFile(path.join(root, "report.md"));
const report = reportBytes.toString("utf8").split(/\r?\n/);
const src = {};
for (const name of ["01-routing.md", "02-markup.md"]) {
  const bytes = await readFile(path.join(root, "targets", name));
  src[name] = { hash: hash(bytes), lines: bytes.toString("utf8").split(/\r?\n/) };
}
const R = "01-routing.md";
const M = "02-markup.md";
// [id, source, startLine, endLine, quote (null = whole source range), occurrence]
const entries = [
  ["prov-r-synthetic", R, 3, 3, "All evidence is synthetic.", 0],
  ["prov-r-offline", R, 4, 4, "No network access is authorized.", 0],
  ["prov-m-synthetic", M, 3, 3, "All evidence is synthetic and belongs to one English software documentation site.", 0],
  ["intent-r-approved", R, 5, 5, "As of 2026-11-16, the approved public product guide is `/guide/current`.", 0],
  ["intent-r-archive", R, 6, 7, "The archived `/guide/2024` must remain accessible as a clearly labeled historical document; it is not the preferred current guide.", 0],
  ["intent-r-googlebot", R, 7, 8, "The owner wants Googlebot to crawl the current guide.", 0],
  ["intent-r-nodata", R, 8, 10, "No Search Console or engine-selected canonical data is available. HTTP responses below were captured by an ordinary browser user agent, not Googlebot.", 0],
  ["intent-r-limits", R, 53, 55, "The archive statement is accurate for its explicit historical scope. No current-guide redirect is present in the supplied capture. The owner has not authorized deletion, redirects or config edits.", 0],
  ["F1-robots", R, 15, 19, null, 0],
  ["F1-intent", R, 7, 8, "The owner wants Googlebot to crawl the current guide.", 1],
  ["F2-canonical", R, 33, 33, '<link rel="canonical" href="https://routing.example.test/guide/2024" />', 0],
  ["F2-approved", R, 5, 5, "As of 2026-11-16, the approved public product guide is `/guide/current`.", 1],
  ["F2-archive", R, 6, 7, "The archived `/guide/2024` must remain accessible as a clearly labeled historical document; it is not the preferred current guide.", 1],
  ["F2-sitemap", R, 46, 46, "<url><loc>https://routing.example.test/guide/current</loc></url>", 0],
  ["C2-archive", R, 52, 53, "The archive returns HTTP 200 and visibly states “2024 archive — former entitlement: 2 seats.” Its self-canonical names `/guide/2024`.", 0],
  ["C4-seats", R, 37, 37, "<p>Current entitlement: 3 seats.</p>", 0],
  ["C5-title", R, 32, 32, "<title>Current product guide</title>", 0],
  ["C5-h1", R, 36, 36, "<h1>Current product guide</h1>", 0],
  ["C7-status", R, 25, 25, "HTTP/1.1 200 OK", 0],
  ["U3-seats", R, 37, 37, "<p>Current entitlement: 3 seats.</p>", 1],
  ["U5-label", R, 6, 6, "clearly labeled", 0],
  ["U6-disallow", R, 16, 16, "Disallow: /guide/current", 0],
  ["intent-m-request", M, 37, 38, "The owner asks for correct machine-readable descriptions of these documentation pages.", 0],
  ["intent-m-limits", M, 38, 40, "They have not requested Product, FAQPage, reviews, ratings or eligibility for a specific Google rich result. No other markup formats or rendered snapshots are supplied. Do not treat the documentation pages as product offers.", 0],
  ["intent-m-status", M, 4, 5, "Both pages return HTTP 200. No rich-result testing, indexed state or AI-answer observations are supplied.", 0],
  ["F3-page-a", M, 13, 19, null, 0],
  ["C8-page-b", M, 28, 34, null, 0],
  ["C9-page-a-visible", M, 9, 10, "Visible heading: “Cedar Library”. Visible text: “Reference documentation for Cedar Library, maintained by Cedar Tools.”", 0],
  ["C8-page-b-visible", M, 24, 25, "Visible heading: “Export reference”. Visible text: “Export reference for Cedar Library.”", 0],
  ["U8-maintainer", M, 10, 10, "maintained by Cedar Tools.", 0],
];
const quotes = entries.map(([quoteId, source, startLine, endLine, q, occurrence]) => {
  const quote = q ?? src[source].lines.slice(startLine - 1, endLine).join("\n");
  const citation = `${source}:${startLine}${endLine === startLine ? "" : `-${endLine}`}`;
  const re = new RegExp(
    `(?:^|[^\\p{L}\\p{N}_./-])${citation.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![0-9-])`,
    "u",
  );
  const hits = [];
  report.forEach((line, i) => {
    if (!re.test(line)) return;
    for (let end = i; end < Math.min(report.length, i + 12); end++) {
      if (norm(report.slice(i, end + 1).join("\n")).includes(norm(quote))) {
        hits.push([i + 1, end + 1]);
        break;
      }
    }
  });
  if (!hits[occurrence]) throw new Error(`No report block for ${quoteId}`);
  return {
    quoteId,
    source: `targets/${source}`,
    sourceLabel: source,
    sourceHash: src[source].hash,
    startLine,
    endLine,
    reportStartLine: hits[occurrence][0],
    reportEndLine: hits[occurrence][1],
    normalization: "whitespace",
    quote,
  };
});
await writeFile(
  path.resolve(outArg),
  JSON.stringify({ root, report: "report.md", reportHash: hash(reportBytes), quotes }, null, 2) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, sources: Object.fromEntries(Object.entries(src).map(([k, v]) => [k, v.hash])) }));
