# Content audit — Content Search Audit

## Delivery summary

Partial\. 2 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:11:54\.882Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 0ee59fa4\-ce59\-4567\-baf5\-9ad8a04611b9\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 0 | 6 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 0 | 8 | 0 |
| quality | 10 | 0 | 10 | 0 |
| seo | 16 | 0 | 16 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | local\-file | 2026\-11\-18T05:11:54\.868Z | 0 full elapsed days | [evidence/4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f\.txt](evidence/4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | local\-file | 2026\-11\-18T05:11:54\.869Z | 0 full elapsed days | [evidence/6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1\.txt](evidence/6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
