# Content audit — Content Search Audit

## Delivery summary

Partial\. 2 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:14:00\.293Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 1f129f78\-78f3\-4a0b\-99a0\-8b302f4ea56f\. 3 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1\-googlebot\-disallow\-current\-guide | robots\.txt disallows Googlebot from the current guide the owner wants Googlebot to crawl | aio\-crawler\-policy, seo\-index\-controls | seo, aio | high | high | observed | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | update | reviewer\-proposal | Supplied robots\.txt text conflicts directly with the owner&\#39;s stated crawl intent for /guide/current; one consolidated issue covering the search crawl \(SEO\) and Google AI\-feature discovery prerequisite \(AIO\)\. | Only if the owner separately authorizes a robots\.txt change \(the dossier states config edits are not authorized\): Change the Googlebot group so that the effective decision for Googlebot on /guide/current is allow, for example by removing the &\#39;Disallow: /guide/current&\#39; line \(or the Googlebot group, if it has no other purpose\) so Googlebot falls back to the existing wildcard &\#39;Allow: /&\#39;\. Do not alter access for /guide/2024 or add rules for other crawlers\. Coordinate with F2: once crawlable, the page&\#39;s canonical will be readable\. | Only if the owner separately authorizes a robots\.txt change \(the dossier states config edits are not authorized\): Re\-export robots\.txt and re\-evaluate the effective group and rule for user agent Googlebot on the exact URL /guide/current; expected result: allowed, with /guide/2024 still allowed\. This confirms permission only\. Whether Googlebot then fetches the page needs Googlebot\-attributed server\-log entries or engine crawl data, which are not supplied; any specific tool workflow is unverified offline\. | Site/platform owner \(robots\.txt\) | small | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-crawler\-policy, r01\-owner\-intent |
| F2\-current\-guide\-canonical\-to\-archive | Current guide declares the 2024 archive as its canonical, contrary to the approved preferred URL | seo\-canonical, portfolio\-duplication | seo, portfolio | high | high | observed | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | update | reviewer\-proposal | The declared canonical on /guide/current names /guide/2024 while the owner&\#39;s approved current guide and the sitemap name /guide/current; one consolidated issue covering the canonical signal \(SEO\) and the current/archive version relationship \(portfolio\)\. | Only if the owner separately authorizes a change to the current guide&\#39;s head markup: Change the canonical link on /guide/current to the self\-referential https://routing\.example\.test/guide/current\. Keep /guide/2024 served, labelled as the 2024 archive and self\-canonical; no redirect, deletion or consolidation is proposed\. | Only if the owner separately authorizes a change to the current guide&\#39;s head markup: Re\-capture the raw HTML of /guide/current and confirm exactly one canonical link whose href is https://routing\.example\.test/guide/current, that the sitemap still lists that URL, and that the archive still returns 200 with its self\-canonical and archive label\. This verifies the declared signal only; the engine\-selected canonical needs engine data that is not supplied\. | Web/content owner \(page templates\) | small | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-canonical\-targets, r01\-owner\-intent |
| F3\-page\-a\-jsonld\-trailing\-comma | Page A JSON\-LD is not valid JSON \(trailing comma\), so its machine\-readable description cannot be parsed | seo\-structured\-data | seo | medium | high | observed | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | update | reviewer\-proposal | Strict JSON parse of the supplied Page A block fails; the owner asks for correct machine\-readable descriptions\. Page B is clean and needs no change\. | Only if the owner separately authorizes a source edit to Page A: Remove the trailing comma after &quot;name&quot;: &quot;Cedar Library&quot; in Page A&\#39;s JSON\-LD block, keeping @context, @type WebPage and name unchanged\. Do not add Product, FAQPage, review, rating or offer markup\. Leave Page B&\#39;s block as is\. | Only if the owner separately authorizes a source edit to Page A: Re\-capture Page A&\#39;s raw source and parse the text inside the application/ld\+json script element with a strict JSON parser; expected: it parses to an object with @type WebPage and name &\#39;Cedar Library&\#39;, matching the visible heading\. Rendered\-DOM state and any engine feature eligibility remain separate, unrequested and unverified\. | Documentation site developer | small | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c, m02\-schema\-extraction, m02\-owner\-intent |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 0 | 8 | 0 |
| quality | 10 | 2 | 8 | 0 |
| seo | 16 | 4 | 12 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | pending | Snapshot review incomplete | 26 |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-claims | quality | unknown | Archive claim \(2 seats, 2024\) is owner\-confirmed for its historical scope\. The current guide&\#39;s &\#39;Current entitlement: 3 seats\.&\#39; has no supplied approved source; unverifiable, not false\. Check unresolved for that component\. | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | r01\-extracted\-text |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | r01\-http\-response |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-index\-controls | seo | unknown | No index or snippet directive \(meta robots, X\-Robots\-Tag\) appears in the supplied current\-guide capture, but only two response header lines are shown, the capture used a browser user agent, and the archive&\#39;s raw source and headers are not supplied\. robots\.txt Disallow is a crawl control, not an index directive; the crawl conflict is persisted as finding F1 and referenced here without resolving this check\. | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-crawler\-policy, r01\-http\-response, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-canonical | seo | fail | Section B: the current guide declares a canonical to /guide/2024, the archive the owner says is not the preferred current guide; the sitemap lists /guide/current\. The archive&\#39;s self\-canonical \(section D, described not shown\) is consistent with intent and is clean\. Engine\-selected canonical is unavailable and stays unknown\. | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-canonical\-targets, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-crawler\-policy | aio | fail | Section A robots\.txt has a Googlebot\-specific group that disallows /guide/current, while the owner states they want Googlebot to crawl the current guide\. Googlebot is the only crawler whose intent is stated; the wildcard group allows other agents, and intent for other search, training or user\-triggered agents is unstated \(not assessed as defects\)\. Permission evaluation of supplied text only; no crawl behaviour observed\. | r01\-crawler\-policy, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-duplication | portfolio | unknown | Current and archive guides are owner\-declared version variants \(current vs\. 2024 archive\) and are to be preserved\. The cross\-URL canonical in finding F2 declares the current version a duplicate of the archive\. Full archive content and a complete inventory map are not supplied, so overlap of task coverage cannot be assessed\. | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-canonical\-targets, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-contradictions | portfolio | unknown | Observed clean component: &\#39;Current entitlement: 3 seats&\#39; \(current guide\) and &\#39;former entitlement: 2 seats&\#39; \(2024 archive\) are date\-scoped and do not contradict; the owner states the archive statement is accurate for its historical scope\. No authoritative entity record or inventory map is supplied, so the check cannot resolve\. | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9, r01\-owner\-intent |
| 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-claims | quality | unknown | Visible claim &\#39;maintained by Cedar Tools&\#39; \(Page A\) has no supplied source; unverifiable, not false\. No other material factual claims are supplied\. | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | m02\-extracted\-text |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | m02\-http\-response |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-structured\-data | seo | fail | Page A&\#39;s JSON\-LD block has a trailing comma after the name property and does not parse as strict JSON, so the supplied raw source carries no parseable machine\-readable description for Page A, contrary to the owner&\#39;s request\. Page B&\#39;s block parses and its WebPage name matches the visible heading \(clean component\)\. Owner did not request Google rich\-result eligibility; none assessed\. Rendered state unknown\. | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c, m02\-owner\-intent, m02\-schema\-extraction |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-contradictions | portfolio | unknown | Observed clean component: both pages use the same product name &\#39;Cedar Library&\#39; in visible text\. No entity record or inventory map supplied; check unresolved\. | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |
| 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| a21ef8c34bb350816068f5e3563b234feba70d9113a51c960872bd0e0f1384f9 | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | local\-file | 2026\-11\-18T05:11:54\.868Z | 0 full elapsed days | [evidence/4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f\.txt](evidence/4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cdc0c35004845bcc8234fc8b78e8e95376b02bb9faaa670fc68ef9df5c02616c | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | local\-file | 2026\-11\-18T05:11:54\.869Z | 0 full elapsed days | [evidence/6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1\.txt](evidence/6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| r01\-extracted\-text | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | identity text extraction of collected local Markdown snapshot | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/r01\-extracted\-text\.txt](evidence/r01-extracted-text.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Identity extraction of the UTF\-8 Markdown dossier; nonempty text does not establish quality; Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor |
| r01\-owner\-intent | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | verbatim preservation of owner context from supplied dossier | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/r01\-owner\-intent\.txt](evidence/r01-owner-intent.txt) | 7046ab4549280a962ca627b5eb33683d06ad1c51adb31ee923a0b32ab198e1d6 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Owner intent is an approved comparison basis for this audit, not verified platform behavior; Intent is stated for Googlebot and for the current/archive roles only; intent for other crawlers, AI training or user\-triggered retrieval agents is not stated |
| r01\-crawler\-policy | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | offline evaluation of supplied robots\.txt text | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/r01\-crawler\-policy\.json](evidence/r01-crawler-policy.json) | a97cc011e714132d1a1105e26d9865d3b61716cb3d7ac58b7bb2447f72147fea | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; A robots decision is a permission evaluation of supplied text, not an observation that any crawler fetched or skipped a URL; Capture date of the robots\.txt export is not stated in the dossier; Engine\-specific handling by Google was not verified against live documentation \(offline audit\) |
| r01\-canonical\-targets | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | structured transcription of canonical and sitemap signals from supplied dossier | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/r01\-canonical\-targets\.json](evidence/r01-canonical-targets.json) | 5c734eb3ac2592abfcb8f906cadcf04c475a53302cae1802c39265d971532bcc | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Declared canonicals only; no engine\-selected canonical is supplied; Archive canonical is described by the owner, not shown as raw markup; Response captured with an ordinary browser user agent, not Googlebot; HTTP Link headers beyond the two shown header lines are not supplied |
| r01\-http\-response | 4dfce4bde295ac0d3e25e94633d7fcf43e9c6ce11dcf26a4f8d0c21bf76a5e6f | transcription of supplied HTTP status evidence | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/r01\-http\-response\.json](evidence/r01-http-response.json) | 6f0ee4b88c5b9fdbb4dabf1ba894027dfeedb1f027cb69ba834c6000ed1d189a | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Supplied transcription for two component URLs in one dossier item; not captured by the auditor; Transport only: not index status, not robots permission, not what Googlebot would receive; Capture date not stated |
| m02\-extracted\-text | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | identity text extraction of collected local Markdown snapshot | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/m02\-extracted\-text\.txt](evidence/m02-extracted-text.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Identity extraction of the UTF\-8 Markdown dossier; nonempty text does not establish quality; Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor |
| m02\-owner\-intent | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | verbatim preservation of owner context from supplied dossier | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/m02\-owner\-intent\.txt](evidence/m02-owner-intent.txt) | de8ce529f43c9882cb4c7eaf28f04be1a99200fba50f8eecdd6a73c2e9efb3bd | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Owner request is the comparison basis; it does not establish any engine feature eligibility |
| m02\-schema\-extraction | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | offline extraction and strict JSON parse of supplied JSON\-LD text | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/m02\-schema\-extraction\.json](evidence/m02-schema-extraction.json) | b3d0d5f73556f808c315bbb35c0dbcaebcc4e6722195a7e4bd95418ef4d7a200 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Strict JSON grammar result only; how any particular consumer or search engine handles the block was not observed; No rich\-result testing, rendered DOM, indexed state or other markup formats supplied; schema\.org vocabulary was not fetched; type/property meaning rests on the auditor&\#39;s general knowledge |
| m02\-http\-response | 6a9dc8a516e5d699a13def2d7fd9a6281f2fcfa24a6a06fe37a2369b03054af1 | transcription of supplied HTTP status statement | 2026\-11\-18T05:13:54\.835Z | 0 full elapsed days | [evidence/m02\-http\-response\.json](evidence/m02-http-response.json) | 6f27bd5dc8a6d520efcd909b3f61b186272e3ead1365d48bca6aa78fc538d7d4 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by the auditor; Owner statement for two component pages; URLs, user agent, headers and capture date are not supplied; Transport only: not index status or rendered completeness |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
