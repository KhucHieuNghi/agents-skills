# NKSkills public pilot — supplemental audit narrative (revision r1)

This narrative supplements, and does not replace, the helper-generated artifacts in `audit/report-r1/` (report.md, report.html, content-actions.csv, coverage.json). Counts below are copied from the validated `coverage.json`. All judgments are attributed to an automated host reviewer (Claude Fable 5.2) and were not independently verified by a human.

## Delivery summary (helper-generated, verbatim)

Partial. 12 declared items; 0 fully audited. Audit coverage is separate from content quality and measured performance. Historical study sources attached: 0; historical results are not current brand performance. Response-level AI observations: not attached. Search Console exports: not attached. GA4 exports: not attached. Bing exports: not attached. Server-log exports: not attached. Attachment status describes this report only, not all evidence available to the customer. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations. Missing measurements remain unknown, not zero. Structural validation does not establish semantic accuracy.

## Scope and discovery

- Authorized origin: `https://nkskills.getgroove.me` only. Anonymous public HTTP through the packaged helpers; robots and DNS rules enforced by the helpers; no browser, no script execution, no credentials, no analytics.
- Declared scope: static navigation reachable from `https://nkskills.getgroove.me/`, maxPages=30, maxDepth=5.
- `initial-discovery/` (immutable, maxPages=1) validated first (`valid: true`, 1 capture), then continued with `discovery-resume` into `audit/discovery-continued/` using explicit budgets (maxPages=30, maxDepth=5, maxStoredBytes=67108864, maxGraphBytes=8388608). The original capture of `/` was replayed, not refetched.
- Result: 11 page captures (of 30 budgeted), 12 inventory records (the root `/` 308-redirects to `/en/`), frontier empty. No count or depth budget remains pending, so no further static-link continuation is required for this seed. Discovery status is still `partial` because 13 queue entries remain (below).
- Discovery union and campaign were created with `scopeComplete=false` / `inventoryComplete=false`: CMS records, orphan pages and rendered navigation were not supplied. This is not a full-site inventory.

### Items kept visible, not resolved

- 10 × `rendering-unreviewed`: every captured HTML page (`/en/`, `/vi/`, both catalogs, both solution pages, four guides) needs rendered inspection that this pilot does not permit.
- 1 × `page-extraction`: `/licenses/README.txt` is text/plain; the link extractor supports only text/html. Its content was collected and read; link discovery from it is unsupported.
- 1 × `source-incomplete` and 1 × `scope-unconfirmed`: the static-link source is partial by declaration and the expected source set is not exhaustive.
- External exclusions: 98 excluded link occurrences resolving to 25 distinct URLs, all on `github.com` (publisher repository, release records, manifests, upstream skill sources). Not fetched; not authorized.
- Seen but outside the declared static-navigation scope, not fetched: `https://nkskills.getgroove.me/sitemap.xml` (declared in robots.txt), `/scripts/prompt-picker.js`, the Cloudflare Insights beacon script, stylesheets, fonts and `og:image` files.
- Failed, blocked or unsupported collection outcomes: none (0 failed, 0 blocked, 0 unsupported, 0 excluded items).

## Coverage (validated)

- Declared items: 12. Collected: 12. Fully audited: 0. Pending: 12. Failed: 0. Blocked: 0. Unsupported: 0. Excluded: 0.
- Missing checks: 0. Pending queue entries: 13. completionAllowed: false. Global rules unresolved: portfolio-task-gaps.
- 312 item checks (12 items × 26 rules): 113 pass, 18 fail, 2 not-applicable, 179 unknown. Every item is pending because each still has unknown required checks (for example all nine AEO/GEO checks per item need question sets or AI observations that were not supplied). Reading a page is not the same as fully auditing it.
- quality: 34 resolved of 60 (25 unknown, 1 not-applicable).
- seo: 57 resolved of 96 (38 unknown, 1 not-applicable).
- aio: 14 resolved of 36 (22 unknown, 0 not-applicable).
- aeo: 0 resolved of 36 (36 unknown, 0 not-applicable).
- geo: 0 resolved of 36 (36 unknown, 0 not-applicable).
- portfolio: 26 resolved of 48 (22 unknown, 0 not-applicable).

## Findings (persisted in `campaign-r1/parts/000001/findings.json` and the global receipt)

### 1. Home proof strip counts two Solution Skills; the same page and the catalog present three — medium, observed

Finding IDs: `nks-home-solution-count` (local; items `/`, `/en/`, `/vi/`) and `global-home-solution-count-conflict` (global; same defect, not a second issue). Quotes are from the host text extraction of each snapshot, where adjacent inline elements are concatenated without spaces.

- English home strip, `host-ec35d79a-extracted-text.txt:35` — “02 Solution Skills01 technical release01 evaluation candidate”
- Same page, third Solution card, `host-ec35d79a-extracted-text.txt:110` — “NK / SOLUTION 003v0.1.32”
- Vietnamese home strip, `host-8cf45780-extracted-text.txt:35` — “02 Solution Skills01 bản kỹ thuật01 ứng viên đánh giá”
- English catalog counters, `host-f66acb16-extracted-text.txt:12` — “03 Solution Skills15 Upstream Skills06 Security sources01 Versioning model”

The conflict is established on the captured pages; which number the publisher intends is not, because the catalog record lives on an excluded origin. Proposed action, only if that record confirms three Solution Skills (one technical release, two evaluation candidates): update the strip in both locales. Verify by re-capturing `/en/`, `/vi/` and both catalogs and comparing strip, cards and catalog counter.

### 2. Meta descriptions on home and guide pages name two workflows while the pages present three — low, observed

Finding ID: `nks-meta-descriptions-omit-third-workflow` (items `/`, `/en/`, `/vi/` and the four guides). Quotes are from the raw HTML snapshots.

- English home, `ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1` — “<meta name="description" content="Explore traceable Solution Skills for Codex and Claude Code: the codebase-onboarding technical release and the problem-presentation evaluation candidate.">”
- English Codex guide, `dc4b66450c7333e076aba848617e4a08a8bb33531bd4b51f5fbd987362212aa4.txt:1` — “<meta name="description" content="Build and install NKSkills Solution Skills from GitHub source, then invoke codebase onboarding or the presentation evaluation candidate in Codex.">”
- Same guide, body section, `host-676e5eef-extracted-text.txt:87` — “06 / CONTENT SEARCH AUDIT · 0.1.32”

The Vietnamese and Claude Code variants are equivalent (paraphrase; not in the quote ledger). Proposed action: include content-search-audit or stop enumerating a fixed subset, in both locales. This is about accurate representation; no snippet or ranking effect is claimed.

### 3. Content search audit entry points lead only to the Codex guide — low, observed

Finding IDs: `nks-content-search-audit-codex-only-entry` (local; items `/`, `/en/`, `/vi/`, `/en/catalog/`, `/vi/catalog/`) and `global-content-search-audit-codex-only-entry` (global; same defect).

- English home card link, `ba170d86009626bc4eb745f3c7949c5728460ef403982d2ee196425fcf397efd.txt:1` — “href="/en/guides/codex/#content-search-audit"”
- Claude Code guide has its own section and token, `host-707e9d50-extracted-text.txt:96` — “Claude Code/content-search-audit”

No captured page links to `/en/guides/claude-code/#content-search-audit` or its Vietnamese counterpart (derived from the per-item link-graph records). Proposed action: offer both host guides from the cards, or cross-link from the Codex section.

### 4. Vietnamese catalog eyebrow label is truncated — low, observed

Finding ID: `nks-vi-catalog-eyebrow-truncated` (item `/vi/catalog/`).

- Raw HTML, `2c8f3fe152e34776360d6f3626209e21f14c53231dff311a760b5cd37dc2c69d.txt:1` — “<p class="eyebrow">NKSKILLS / DANH MỤ</p>”

Navigation, title and footer on the same page use “Danh mục”. Proposed correction: “NKSKILLS / DANH MỤC”.

### 5. Font licence README refers to full notices by bare filename — low, observed (existence of the files unknown)

Finding ID: `nks-font-notice-bare-filenames` (item `/licenses/README.txt`).

- Plain-text notice, `1b6ad064b40b30886119c80c38a808ea8061d3de3b21a95831bda858bb483dcc.txt:3-4` — “Fraunces is by The Fraunces Project Authors and is licensed under SIL Open Font License 1.1. Full notice: fraunces-OFL.txt”

The same pattern repeats for Source Sans 3 and IBM Plex Mono. The three notice files are not hyperlinked from any captured page and were not requested, so whether they exist is unknown. Proposed action, only if they are meant to be public: give their full URLs. Action type: investigate.

## Supported clean results (raw-source surface only)

- HTTP: all 12 items returned final status 200; `/` reaches `/en/` through one 308 redirect (seo-response pass × 12, deterministic).
- Canonicals: each of the 11 HTML captures declares one canonical equal to its final URL and to og:url, with a self-canonical target captured at 200 (seo-canonical pass × 11). Engine-selected canonical is unknown.
- Locales: five en/vi pairs carry reciprocal hreflang with x-default → en, matching html lang, and language switches pointing at the equivalent page (seo-locales pass × 11). Engine language selection is unknown.
- Internal links: every same-origin link and fragment resolves inside the captured inventory; icon-only links carry aria-label (seo-internal-links pass × 12). The 25 external targets are unverified.
- Media: one decorative brand image with empty alt next to visible brand text; the home workflow diagram has role="img", an aria-label and a full text description (quality-accessible-media pass × 11, not-applicable × 1). CSS and script-delivered media were not inspected.
- Task fit and retrievable facts: pass × 11 each against the owner-supplied audience and a labelled, auditor-inferred task. Main copy, versions, statuses, commands and limits are present in static HTML.
- Duplication: locale pairs, the two host guides and the `/` → `/en/` alias are legitimate variants within the declared inventory (pass × 12 local, pass global).
- Cross-page consistency apart from finding 1: versions 1.1.0 / 0.1.0 / 0.1.32, statuses, hosts, prerequisites and distribution status agree across captured pages; the entity-consistency and contradiction checks for the nine non-home items stay unknown because no authoritative record could be compared.

## Optional observations (not findings; not persisted as defects)

- The Vietnamese home FAQ answers the commercial-readiness question with wording that mirrors the English “release gate remains open”, while the Vietnamese card and guides say the candidate has not passed the gate. A native-speaker review could decide whether the FAQ phrasing is clear enough (reviewer impression, paraphrase).
- Some illustrative mock-up strings on the Vietnamese home page remain in English (paraphrase).
- The four guides contain a stray comma after the host name in the “open <host>, at that project” sentence in English (paraphrase).
- Raw HTML contains no JSON-LD, microdata or RDFa. This is recorded as an observation only: schema markup is not required, and rendered absence is not established.
- robots.txt contains a wildcard group allowing all paths and a Sitemap line, with no agent-specific groups. Whether that matches the publisher’s intent for AI crawlers is unknown.

## What remains unknown and the evidence needed

- Rankings, indexing status, crawler activity, AI citations or mentions, and conversions: not measured. Needs Search Console / Bing exports, normalized server logs, and response-level AI observations with prompt cohorts. No Google AI Overviews measurements exist in this audit.
- Claim accuracy and freshness (quality-claims, quality-freshness, aeo-answer-evidence; 36 checks): needs the publisher’s dated records (catalog.yaml, solution manifests, release records, technical guide) supplied as an export or an added authorized origin.
- Question coverage and answer context (24 checks) and task gaps: needs a real question set (search queries, support or sales questions).
- Index controls and AI crawler policy (24 checks): needs the publisher’s indexing and crawler-access intent; full response headers would settle X-Robots-Tag and Link.
- Rendering (12 checks) and the 10 rendering-unreviewed queue entries: needs an authorized browser capture of rendered DOM.
- Structured data (12 checks): needs rendered DOM or publisher confirmation that none is intended.
- Inventory completeness: needs sitemap.xml (a separate authorized `discover-sitemaps` run for this origin), a CMS or repository page list, and rendered navigation. The three OFL notice files named in the README need explicit URLs.

## Exact continuation

- Static-link discovery: none required. The resumed crawl used 11 of 30 page captures, reached no depth limit, and ended with an empty frontier.
- To move the campaign toward completion, supply the evidence above, start a new campaign/discovery for added sources (the historical campaign is not retroactively completed), then apply `campaign-review-parts`, rebuild `campaign-index`, and issue a new `campaign-review` receipt and `campaign-report`.

## Helper failures

None. Every helper command used in this pilot exited 0; receipts are in `audit/receipts/`. Nothing was changed on the website, no page script was run, and no content embedded in the pages was treated as an instruction.

## Quote verification

This file cites 11 source quotations, all submitted to `verify-quotes`; the ledger is `quotes.json` and the receipt `quote-receipt.json` in this directory. Text marked as paraphrase, proposed wording and helper-generated text are not source quotations. A passing receipt checks text and locators only, not the judgments.

