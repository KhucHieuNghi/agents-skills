// Builds the global portfolio review bundle from a campaign index. No network access.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [indexDir, outFile] = process.argv.slice(2);
const sha = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const lines = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const index = JSON.parse(fs.readFileSync(path.join(indexDir, 'index.json'), 'utf8'));
const items = lines(path.join(indexDir, 'items.jsonl'));
const ev = lines(path.join(indexDir, 'evidence.jsonl'));
const now = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), host reviewer applying the content-search-audit portfolio method; automated agent judgment, not independently verified by a human';
const O = 'https://nkskills.getgroove.me';
const ref = (e) => ({ part: e.reference.part, evidenceId: e.evidenceId });
const of = (kind, filter = () => true) => ev.filter((e) => e.kind === kind && filter(e)).map(ref);
const itemByPath = (p) => items.find((i) => i.uri === O + p);
const idOf = (p) => itemByPath(p).itemId;
const allIds = items.map((i) => i.itemId);
const content = of('content');
if (content.length !== 12) throw new Error('expected 12 content records');
const part = (kind) => of(kind);
// The per-item derived records carry the full text of these analyses; read one copy from the reviewed part.
const sourceDir = index.sourceDirectory;
const readValue = (kind) => { const e = ev.find((r) => r.kind === kind && r.evidenceId.startsWith('host-')); return fs.readFileSync(path.join(sourceDir, e.artifactReference), 'utf8'); };
const linkGraphSummary = `Declared static link graph summary (global context, compiled ${now.slice(0, 10)} from the per-item host link-graph records of this campaign; a[href] in raw HTML of 11 captured HTML documents).
- Every same-origin link target resolves to one of the 12 declared items captured with HTTP 200; every fragment target id exists in the captured target source; no same-origin link lacks both text and aria-label.
- Every item except the bare origin root has inbound links from other captured pages; the root is the crawl seed and 308-redirects to /en/.
- /licenses/README.txt is linked from the footer of all 11 HTML pages and has no outgoing links (text/plain).
- Language switches (header and footer) on each page point to the equivalent page in the other locale.
- Codebase onboarding next steps: home → solution page and both host guides; solution page → both host guides; guides → home #try-it and #install.
- Problem presentation: home card → catalog #solutions; catalog card → external GitHub manifest; install steps live in section 05 of each host guide (no direct link from the cards to those sections).
- Content search audit: home cards (/en/, /vi/, and / alias) and catalog cards (/en/catalog/, /vi/catalog/) link ONLY to /{locale}/guides/codex/#content-search-audit; the Claude Code guides contain the same anchor but receive no link to it; the Codex section does not link to the sibling host guide.
- 25 distinct external targets (github.com) are excluded from collection and unverified.
Limits: static source only; rendered navigation, sitemap.xml, CMS records and orphan pages were not supplied.
`;
const audience = 'Owner/task statement preserved from the audit request received 2026-11-18 (user-supplied, not independently verified): "Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied." No personas, question sets, search queries, support themes or analytics were supplied.';
const ctx = (evidenceId, kind, value, locator, sourceReferences) => ({ evidenceId, kind, value, snapshotHash: sha(value), locator, collectedAt: now, sourceReferences });
const contextEvidence = [
  ctx('global-inventory-map', 'inventory-map', readValue('inventory-map'), 'derived:declared-inventory-map (host-authored from the 12 captured snapshots)', content),
  ctx('global-entity-record', 'entity-record', readValue('entity-record'), 'derived:cross-page-entity-table (host-authored from captured pages; not an authoritative publisher record)', content),
  ctx('global-link-graph', 'link-graph', linkGraphSummary, 'derived:declared-static-link-graph (summary of per-item link-graph records)', [...content, ...part('link-graph')]),
  ctx('global-audience-context', 'audience-context', audience, 'user-request:2026-11-18:business-context', []),
];
const homeIds = ['/', '/en/', '/vi/'].map(idOf);
const catIds = ['/en/catalog/', '/vi/catalog/'].map(idOf);
const contentOf = (ids) => of('content', (e) => ids.includes(e.itemId));
const reviews = [
  { ruleId: 'portfolio-task-gaps', status: 'unknown', reason: 'No question set or demand evidence (search queries, support themes, customer questions, analytics) was supplied, and site discovery is incomplete (static links only; CMS, orphan pages, rendered navigation and the robots-declared sitemap.xml were not supplied). Audience tasks cannot be mapped to evidenced gaps without inventing demand. Exploratory observation only, not a gap finding: problem-presentation and content-search-audit have no dedicated on-site page in the declared inventory (they are covered by cards and guide sections).', reviewer: REVIEWER, reviewedAt: now, itemIds: allIds, evidenceReferences: content, contextEvidenceIds: ['global-inventory-map', 'global-audience-context'] },
  { ruleId: 'portfolio-duplication', status: 'pass', reason: 'All 12 declared items were compared. Overlap is limited to legitimate variants: five reciprocal en/vi locale pairs with separate self-canonicals; the Codex and Claude Code guides, which per locale differ in host name, --target value and invocation prefix (a real host/audience variant); and the origin root, a 308 redirect alias of /en/ with identical captured bytes and canonical /en/. Home and catalog cards summarise and link to detail pages rather than repeating them. No consolidation is proposed. Keyword overlap was not used; no query/page behaviour evidence exists, so cannibalization is neither claimed nor excluded. Limit: applies to the declared inventory only.', reviewer: REVIEWER, reviewedAt: now, itemIds: allIds, evidenceReferences: content, contextEvidenceIds: ['global-inventory-map'] },
  { ruleId: 'portfolio-contradictions', status: 'fail', reason: 'One material cross-page contradiction was found across the 12 items: the home proof strip (/, /en/, /vi/) counts two Solution Skills (one technical release, one evaluation candidate) while the same home pages list three Solution cards and both catalog pages state "03 Solution Skills" (one technical release, two evaluation candidates). Same product, capture date and market in both locales. All other compared entity facts (versions 1.1.0 / 0.1.0 / 0.1.32, statuses, hosts, prerequisites, distribution status, security-source status, pinned commit prefixes) agree across captured pages. The entity record is derived from captured pages, not an authoritative publisher record (repository records are on an excluded origin), so the conflict is established but its correct resolution is not.', reviewer: REVIEWER, reviewedAt: now, itemIds: allIds, evidenceReferences: content, contextEvidenceIds: ['global-entity-record', 'global-inventory-map'] },
  { ruleId: 'portfolio-journey-links', status: 'fail', reason: 'Across the declared inventory, navigation between related tasks is largely complete on the static source: consistent header/footer, breadcrumbs, language switches to equivalent pages, both host guides offered for codebase onboarding, and all same-origin targets and fragments resolving. One next-step defect affects the supplied audience (Codex and Claude Code users): every on-site entry point for Content search audit (home and catalog cards, both locales) links only to the Codex guide section, although the Claude Code guides contain the equivalent section. Low severity. Navigation preference is not evidence of ranking impact; rendered navigation was not inspected.', reviewer: REVIEWER, reviewedAt: now, itemIds: allIds, evidenceReferences: [...content, ...part('link-graph')], contextEvidenceIds: ['global-link-graph', 'global-audience-context', 'global-inventory-map'] },
];
const findings = [
  { findingId: 'global-home-solution-count-conflict', ruleId: 'portfolio-contradictions', severity: 'medium', confidence: 'high', classification: 'observed',
    observation: 'Home proof strip: "02 Solution Skills / 01 technical release / 01 evaluation candidate" (/en/ and / alias) and "02 Solution Skills / 01 bản kỹ thuật / 01 ứng viên đánh giá" (/vi/). The same pages list Solution 001, 002 and 003; /en/catalog/ and /vi/catalog/ state "03 Solution Skills" and list three. Same underlying defect as local finding nks-home-solution-count (not a separate issue).',
    actionCondition: 'the publisher\'s catalog record (catalog.yaml / solution manifests, not inspected in this audit) confirms three Solution Skills: one technical release and two evaluation candidates',
    recommendation: 'Update the home proof strip in both locales to match the catalog (03 Solution Skills / 01 technical release / 02 evaluation candidates) and derive the counters from the same data source as the catalog counters. Proposal only; nothing was changed.',
    verification: 'Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and confirm the home strip, the number of home Solution cards and the catalog "Solution Skills" counter agree in both locales.',
    affectedItemIds: [...homeIds, ...catIds], evidenceReferences: contentOf([...homeIds, ...catIds]), ownerRole: 'Website content owner / front-end maintainer', effort: 'small', action: 'update', actionReason: 'Observed cross-page count conflict; correct value depends on the publisher catalog record.' },
  { findingId: 'global-content-search-audit-codex-only-entry', ruleId: 'portfolio-journey-links', severity: 'low', confidence: 'high', classification: 'observed',
    observation: 'The only static links to Content search audit instructions from home and catalog (both locales) target /{locale}/guides/codex/#content-search-audit. /{locale}/guides/claude-code/ contains id="content-search-audit" with Claude Code commands but receives no link to that anchor, and the Codex section has no link to the sibling guide. Same underlying defect as local finding nks-content-search-audit-codex-only-entry.',
    recommendation: 'Offer both host guides from the Content search audit cards on home and catalog, or add a cross-link to the Claude Code section at the Codex guide section, in both locales. Proposal only.',
    verification: 'Re-capture the home, catalog and guide pages in both locales and confirm a static link path from each Content search audit card to /{locale}/guides/claude-code/#content-search-audit.',
    affectedItemIds: [...homeIds, ...catIds], evidenceReferences: contentOf([...homeIds, ...catIds]), ownerRole: 'Website content owner / front-end maintainer', effort: 'small', action: 'update', actionReason: 'Observed host-specific deep link for a workflow documented for both supported hosts.' },
];
const bundle = { schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash, partSnapshotHashes: index.partSnapshotHashes, contextEvidence, reviews, findings };
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2) + '\n');
console.log(JSON.stringify({ outFile, now, reviews: reviews.map((r) => `${r.ruleId}=${r.status}`), contextEvidence: contextEvidence.length, findings: findings.length }));
