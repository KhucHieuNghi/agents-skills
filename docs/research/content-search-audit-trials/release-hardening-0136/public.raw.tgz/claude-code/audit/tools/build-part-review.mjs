// Builds the per-part review bundle (derived evidence + attributed reviews + findings)
// from registered campaign snapshots. Text-only inspection; no network; target markup
// is never executed. Judgments are host-authored and encoded explicitly below.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [campaignDir, indexDir, extractDir, outFile] = process.argv.slice(2);
const sha = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const lines = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const index = JSON.parse(fs.readFileSync(path.join(indexDir, 'index.json'), 'utf8'));
const PART = 'parts/000001';
const partDir = path.join(campaignDir, PART);
const inv = lines(path.join(partDir, 'inventory.jsonl'));
const ev = lines(path.join(partDir, 'evidence.jsonl'));
const O = 'https://nkskills.getgroove.me';
const now = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), host reviewer applying the content-search-audit methods; automated agent judgment, not independently verified by a human';

const I = {};
for (const item of inv) {
  const short = item.itemId.slice(0, 8);
  const meta = JSON.parse(fs.readFileSync(path.join(extractDir, short, 'meta.json'), 'utf8'));
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === 'content');
  const raw = fs.readFileSync(path.join(partDir, content.artifact), 'utf8');
  if (sha(raw) !== content.snapshotHash) throw new Error('content hash mismatch ' + item.uri);
  I[item.uri] = { item, short, meta, raw, contentId: content.evidenceId, httpId: mine.find((e) => e.kind === 'http-response').evidenceId, robotsIds: mine.filter((e) => e.kind === 'crawler-policy').map((e) => e.evidenceId), p: item.uri.slice(O.length) };
}
const all = Object.values(I);
const html = all.filter((x) => x.meta.isHtml);
const klass = (x) => (!x.meta.isHtml ? 'TXT' : /\/guides\//.test(x.p) ? 'GUIDE' : /\/solutions\//.test(x.p) ? 'SOL' : /\/catalog\//.test(x.p) ? 'CAT' : 'HOME');
const byPath = (p) => I[O + p];
const allContentIds = all.map((x) => x.contentId);
const htmlContentIds = html.map((x) => x.contentId);

// ---------- derived structures ----------
const ids = {};
for (const x of html) ids[x.item.uri] = new Set([...x.raw.matchAll(/\sid\s*=\s*"([^"]+)"/g)].map((m) => m[1]));
const pageOf = (resolved) => { const u = new URL(resolved); return u.origin + u.pathname; };
const inbound = {};
for (const x of html) for (const l of x.meta.links) {
  if (!l.resolved) continue;
  const u = new URL(l.resolved);
  if (u.origin !== O) continue;
  (inbound[pageOf(l.resolved)] ??= new Set()).add(x.item.uri);
}

const evidence = [];
const artifacts = {};
const E = {}; // E[uri][kind] = evidenceId
const add = (x, kind, value, locator, sourceEvidenceIds, limitations, method = 'host-derived-analysis') => {
  const evidenceId = `host-${x.short}-${kind}`;
  const artifact = `evidence/${evidenceId}.txt`;
  artifacts[artifact] = value;
  evidence.push({ evidenceId, itemId: x.item.itemId, kind, method, locator, collectedAt: now, snapshotHash: sha(value), artifact, encoding: 'utf8', sourceEvidenceIds: [...new Set(sourceEvidenceIds)], redaction: 'Derived from public anonymous captures and the audit request; no credentials or private data', limitations, value });
  (E[x.item.uri] ??= {})[kind] = evidenceId;
};
const J = (o) => JSON.stringify(o, null, 2) + '\n';

const USER_CONTEXT = 'Owner/task statement preserved from the audit request received 2026-11-18 (user-supplied, not independently verified): "Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied." No personas, search queries, support questions, publisher indexing intent or AI-crawler policy intent were supplied.';
const TASK = {
  HOME: 'Auditor-inferred task (labelled inference): a Codex or Claude Code user evaluates what NKSkills offers and starts with the codebase-onboarding starter prompt or a host install guide. Supporting passages in the captured page: hero sentence ("We compose version-pinned public skills with original workflows, so Codex and Claude Code can finish a complete job." / VI equivalent), sections 02 Solution Skills, 04 Install and use, 05 Try it.',
  CAT: 'Auditor-inferred task (labelled inference): a prospective user checks which Solution Skills and pinned Upstream Skills exist, with source, revision, licence and release status. Supporting passage: catalog hero sentence about two layers and the section intro "This catalog tracks source, commit, and license." / VI equivalent.',
  SOL: 'Auditor-inferred task (labelled inference): a developer evaluates the codebase-onboarding Solution Skill 1.1.0 — composition, outputs, prerequisites and verification limits — before using it with Codex or Claude Code. Supporting passages: H1, "Prerequisites and current limits" section / VI equivalent.',
  GUIDE: 'Auditor-inferred task (labelled inference): a user of the named host builds NKSkills from GitHub source, installs a Solution Skill into a project and invokes it. Supporting passages: H1 and lead sentence ("Start from public source, verify prerequisites, and invoke the skill only after it is installed in the project." / VI equivalent).',
  TXT: 'Auditor-inferred task (labelled inference, low confidence): a visitor following the footer link "Font licenses" / "Giấy phép font" looks up the licence terms of the site fonts. No owner statement about this resource was supplied.',
};

const ENTITY_RECORD = `Derived cross-page entity table for NKSkills (compiled by the host reviewer from the 11 captured HTML snapshots of this campaign, 2026-11-18).
STATUS: derived from captured site pages only. It is NOT an authoritative product record. The publisher's own records (catalog.yaml, solution manifests, release records) live on github.com, which is outside the authorized origin and was not collected.

Brand / product: "NKSkills" — "Versioned skill workflows for Codex and Claude Code" (footer, all HTML pages); title of /en/: "NKSkills | Versioned AI skill workflows for Codex and Claude Code".
Supported hosts: Codex and Claude Code (all HTML pages; home FAQ "Which hosts are supported?"). Invocation tokens in guides: "$<skill>" for Codex, "/<skill>" for Claude Code.

Solution Skills as presented per page:
- codebase-onboarding 1.1.0, status "technical release": home card "NK / SOLUTION 001 v1.1.0 TECHNICAL RELEASE" (/en/, /vi/); catalog "01 / TECHNICAL RELEASE — Codebase onboarding 1.1.0 … 3 components"; solution page "SOLUTION SKILL v1.1.0", "One workflow, three traceable components" (codebase-onboarding-c4, html-docs-standard, Hallmark); guides build path "build/codebase-onboarding-1.1.0"; starter prompt "codebase-onboarding@1.1.0". Consistent across captured pages.
- problem-presentation 0.1.0, status "evaluation candidate": home card "NK / SOLUTION 002 v0.1.0 EVALUATION CANDIDATE", home FAQ "Version 0.1.0 is an evaluation candidate"; catalog "02 / EVALUATION CANDIDATE — Problem presentation 0.1.0"; guides section 05 "Version 0.1.0 has not passed the commercial release gate". Consistent.
- content-search-audit 0.1.32, status "evaluation candidate": home card "NK / SOLUTION 003 v0.1.32 EVALUATION CANDIDATE"; catalog "03 / EVALUATION CANDIDATE — Content search audit 0.1.32"; guides section "06 / CONTENT SEARCH AUDIT · 0.1.32". Consistent.

Counts stated:
- Home proof strip (/en/ and the identical / alias): "02 Solution Skills", "01 technical release", "01 evaluation candidate". /vi/: "02 Solution Skills", "01 bản kỹ thuật", "01 ứng viên đánh giá".
- Same home pages list THREE Solution cards (001, 002, 003): one technical release and TWO evaluation candidates.
- Catalog counters (/en/catalog/, /vi/catalog/): "03 Solution Skills", "15 Upstream Skills", "06 Security sources"/"06 Nguồn bảo mật". The catalog lists 3 Solution entries, 9 general + 6 security upstream entries (= 15), matching its own counters.
=> CONFLICT: home strip (2 / 1 / 1) versus home cards and catalog (3 / 1 / 2). Which value the publisher intends is not established by captured evidence.
- Home meta descriptions (EN/VI) and the four guide meta descriptions name only codebase-onboarding and problem-presentation.

Other cross-page facts (consistent on captured pages):
- Distribution: no published direct-download archive; build from GitHub source (home step 02, solution page, guides).
- codebase-onboarding prerequisites: Solution Skill, codegraph, rtk, valid CodeGraph index at repository root (solution page, guides, starter prompt); guides add Node.js 22+, npm, Git.
- Security: six tracked upstream security skills; "NKSkills has no installable security Solution Skill yet" (home) / "No security Solution Skill is released" (catalog). Pinned commit prefixes on home links match catalog short hashes (c1c8a8c147, 0c464f411b, 301b02b12b, 49f948faa9, 173483d7c6 x2).
- Verification limits: build and installation checked/verified; behaviour across customer repositories not broadly verified (home card, solution page).
`;

const INVENTORY_MAP = `Inventory map of the 12 declared items (host-authored classification from captured snapshots, 2026-11-18). Discovery scope is incomplete (static links only; CMS, orphan pages, rendered navigation and sitemap.xml not supplied), so this map covers the declared inventory, not the whole site.

${all.map((x) => `- ${x.item.itemId} | ${x.p} | class=${klass(x)} | html lang=${x.meta.lang ?? 'n/a (text/plain)'} | ${({ HOME: x.p === '/' ? 'origin root; 308 redirect to /en/ and byte-identical captured body; purpose: landing/overview (discovery→evaluation→start)' : 'landing/overview: model, three Solution cards, install steps, starter prompt, catalog teaser, security sources, FAQ (discovery→evaluation→start)', CAT: 'catalog/reference: Solution Skills, upstream skills with licence and commit, versioning model (evaluation/reference)', SOL: 'solution detail for codebase-onboarding 1.1.0: composition, output, prerequisites and limits (evaluation)', GUIDE: `host install-and-use guide for ${/claude-code/.test(x.p) ? 'Claude Code' : 'Codex'}: prerequisites, build, install, run; sections for problem-presentation and content-search-audit (implementation)`, TXT: 'font licence notice, plain text, English only, linked from every footer in both locales (legal/support)' })[klass(x)]}`).join('\n')}

Variant relationships:
- Locale pairs (reciprocal hreflang en/vi, x-default=en): /en/ ↔ /vi/; /en/catalog/ ↔ /vi/catalog/; /en/solutions/codebase-onboarding/ ↔ /vi/solutions/codebase-onboarding/; /en/guides/codex/ ↔ /vi/guides/codex/; /en/guides/claude-code/ ↔ /vi/guides/claude-code/.
- Host variants: guides/codex vs guides/claude-code differ (per locale) only in host name, --target value, invocation prefix ($ vs /), and the language-switch link (line diff of extracted text).
- Alias: / → 308 → /en/ (same captured bytes as /en/).
- Topics without an on-site page in the declared inventory: problem-presentation (home card → catalog anchor; catalog card → external GitHub manifest; install steps inside both host guides) and content-search-audit (home and catalog cards → Codex guide anchor only).
`;

for (const x of all) {
  const k = klass(x);
  const m = x.meta;
  // extracted text (plain; link/heading markers removed)
  const t = fs.readFileSync(path.join(extractDir, x.short, 'text.txt'), 'utf8');
  const plain = m.isHtml ? t.replace(/⟦a [^⟧]*⟧|⟦\/a⟧/g, '').replace(/^\[H[1-6]\] /gm, '') : t;
  add(x, 'extracted-text', plain, x.item.uri, [x.contentId], m.isHtml ? ['Regex-based inert text extraction of the raw HTML body by audit/tools/extract.mjs; not a rendered DOM', 'Inline elements may be concatenated without spaces; inert <template> prompt variants are included as text; script/style/comment content removed'] : ['text/plain body reproduced unchanged'], 'host-inert-text-extraction');
  add(x, 'audience-context', `${USER_CONTEXT}\n\nItem: ${x.item.uri}\n${TASK[k]}\n`, 'user-request:2026-11-18:business-context', [x.contentId], ['Owner-supplied context is an approved comparison basis, not independent verification', 'The intended task is an auditor inference from the captured page; no persona, query or support evidence exists']);
  if (m.isHtml) {
    const canonical = m.headLinks.find((l) => l.rel === 'canonical')?.href ?? null;
    const ogUrl = m.meta.find((a) => a.property === 'og:url')?.content ?? null;
    const alternates = m.headLinks.filter((l) => l.rel === 'alternate' && l.hreflang).map((l) => ({ hreflang: l.hreflang, href: l.href }));
    const target = canonical ? I[canonical] : null;
    add(x, 'canonical-targets', J({ requestedUrl: x.item.uri, finalUrl: m.http.finalUrl, redirects: m.http.redirects, canonicalDeclarations: m.headLinks.filter((l) => l.rel === 'canonical').map((l) => l.href), ogUrl, canonicalEqualsFinalUrl: canonical === m.http.finalUrl, canonicalTargetInInventory: Boolean(target), canonicalTargetCapturedStatus: target?.meta.http.status ?? null, canonicalTargetSelfCanonical: target ? target.meta.headLinks.find((l) => l.rel === 'canonical')?.href === canonical : null, httpLinkHeader: 'not present in the retained response-header subset (content-type, cache-control only); retention is selective, so absence is not established', alternates }), x.item.uri, [x.contentId, x.httpId, ...(target ? [target.contentId, target.httpId] : [])], ['Declared canonical in raw HTML only; engine-selected canonical is unknown', 'Rendered DOM and full response headers not captured']);
    const other = alternates.find((a) => a.hreflang !== m.lang && a.hreflang !== 'x-default');
    const counterpart = other ? I[other.href] : null;
    const cAlt = counterpart ? counterpart.meta.headLinks.filter((l) => l.rel === 'alternate' && l.hreflang).map((l) => ({ hreflang: l.hreflang, href: l.href })) : null;
    const self = alternates.find((a) => a.hreflang === m.lang)?.href ?? null;
    add(x, 'locale-map', J({ url: x.item.uri, finalUrl: m.http.finalUrl, htmlLang: m.lang, alternates, selfReferenceMatchesFinalUrl: self === m.http.finalUrl, counterpart: counterpart ? { url: counterpart.item.uri, capturedStatus: counterpart.meta.http.status, htmlLang: counterpart.meta.lang, alternates: cAlt, returnsLinkToThisFinalUrl: cAlt.some((a) => a.href === m.http.finalUrl), sameAlternateSet: JSON.stringify([...cAlt].sort((a, b) => a.hreflang.localeCompare(b.hreflang))) === JSON.stringify([...alternates].sort((a, b) => a.hreflang.localeCompare(b.hreflang))) } : null, xDefault: alternates.find((a) => a.hreflang === 'x-default')?.href ?? null, bodyLanguageSwitchLinks: m.links.filter((l) => /^(VI|EN|Tiếng Việt|English)$/.test(l.text)).map((l) => ({ href: l.href, text: l.text })), ogImage: m.meta.find((a) => a.property === 'og:image')?.content ?? null }), x.item.uri, [x.contentId, ...(counterpart ? [counterpart.contentId] : [])], ['hreflang annotations in raw HTML only; sitemap or HTTP-header annotations not captured', 'Does not observe engine language selection or indexing']);
  }
  // link graph
  const out = (m.links ?? []).filter((l) => l.resolved);
  const internal = out.filter((l) => new URL(l.resolved).origin === O).map((l) => { const u = new URL(l.resolved); const pg = pageOf(l.resolved); const tgt = I[pg]; return { href: l.href, resolved: l.resolved, label: l.text || null, ariaLabel: l.ariaLabel, targetInInventory: Boolean(tgt), targetCapturedStatus: tgt?.meta.http.status ?? null, fragment: u.hash || null, fragmentIdPresentInTargetSource: u.hash ? (tgt?.meta.isHtml ? ids[pg].has(decodeURIComponent(u.hash.slice(1))) : false) : null }; });
  const external = [...new Set(out.filter((l) => new URL(l.resolved).origin !== O).map((l) => l.resolved))];
  const inb = [...(inbound[m.http.finalUrl] ?? [])].filter((u) => u !== x.item.uri);
  const inbReq = [...(inbound[x.item.uri] ?? [])].filter((u) => u !== x.item.uri);
  add(x, 'link-graph', J({ url: x.item.uri, finalUrl: m.http.finalUrl, surface: 'a[href] in raw HTML body of the 11 captured HTML documents (static source only)', outgoingInternal: internal, outgoingInternalSummary: { total: internal.length, targetsNotInInventory: internal.filter((l) => !l.targetInInventory).length, targetsNot200: internal.filter((l) => l.targetInInventory && l.targetCapturedStatus !== 200).length, fragmentsMissing: internal.filter((l) => l.fragment && !l.fragmentIdPresentInTargetSource).length, linksWithoutTextOrAriaLabel: internal.filter((l) => !l.label && !l.ariaLabel).length }, outgoingExternalNotFetched: external, inboundFromOtherCapturedPagesToFinalUrl: inb, inboundToRequestedUrl: inbReq }), x.item.uri, [x.contentId, ...[...new Set([...inb, ...inbReq])].map((u) => I[u].contentId)], ['Static links in declared inventory only; rendered navigation, sitemap.xml, CMS and orphan pages not supplied', 'External targets were excluded from collection and are unverified']);
  // media + schema
  if (m.isHtml) {
    const roleImg = [...x.raw.matchAll(/<([a-z0-9]+)\b[^>]*\brole="img"[^>]*>/gi)].map((mm) => { const lab = (mm[0].match(/aria-label="([^"]*)"/) ?? [])[1] ?? null; const desc = (mm[0].match(/aria-describedby="([^"]*)"/) ?? [])[1] ?? null; let descText = null; if (desc) { const dm = x.raw.match(new RegExp(`<([a-z0-9]+)\\b[^>]*\\bid="${desc}"[^>]*>([\\s\\S]*?)</\\1>`, 'i')); descText = dm ? dm[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : null; } return { element: mm[1], ariaLabel: lab, ariaDescribedby: desc, describedbyTargetPresent: desc ? ids[x.item.uri].has(desc) : null, descriptionText: descText }; });
    add(x, 'media-inventory', J({ url: x.item.uri, surface: 'raw HTML body', img: m.media.img.map((i) => ({ ...i, context: 'header brand link <a class="brand" aria-label=…> containing adjacent visible text "NKSkills"' })), inlineSvg: (x.raw.match(/<svg\b/gi) ?? []).length, video: m.media.video, audio: m.media.audio, picture: m.media.picture, canvas: m.media.canvas, objectOrEmbed: m.media.object, iframe: m.inertSurfaces.iframe, roleImgElements: roleImg, figcaptions: (x.raw.match(/<figcaption\b/gi) ?? []).length, ogImageDeclaredNotCollected: m.meta.find((a) => a.property === 'og:image')?.content ?? null, notInventoried: ['CSS background images (stylesheets not collected)', 'media injected by scripts (scripts not executed)', 'binary og:image content'] }), x.item.uri, [x.contentId], ['Raw-source inventory only; rendered and CSS-delivered media not inspected']);
    add(x, 'schema-extraction', J({ url: x.item.uri, surface: 'raw HTML', jsonLdBlocks: m.jsonLd.length, microdataAttributes: (x.raw.match(/\sitem(scope|prop|type)\b/gi) ?? []).length, rdfaTypeofAttributes: (x.raw.match(/\stypeof=/gi) ?? []).length, openGraph: m.meta.filter((a) => a.property), twitterCardMeta: m.meta.filter((a) => /^twitter:/.test(a.name ?? '')).length, note: 'No JSON-LD, microdata or RDFa typeof found in raw source. Open Graph tags are not schema.org structured data. Rendered-DOM structured data not captured.' }), x.item.uri, [x.contentId], ['Raw absence does not establish rendered absence', 'No engine validation or eligibility test was run']);
  } else {
    add(x, 'media-inventory', J({ url: x.item.uri, surface: 'text/plain body', contentType: m.http.headers['content-type'], media: 'none possible in a plain-text representation; 377 characters of text' }), x.item.uri, [x.contentId, x.httpId], ['Plain text only']);
  }
  add(x, 'entity-record', ENTITY_RECORD, 'derived:cross-page-entity-table', [x.contentId, ...htmlContentIds], ['Derived from captured pages; not an authoritative record', 'Publisher repository records on github.com are outside the authorized origin and were not compared']);
  add(x, 'inventory-map', INVENTORY_MAP, 'derived:declared-inventory-map', [x.contentId, ...allContentIds], ['Covers the 12 declared items only; discovery scope is incomplete']);
}

// ---------- reviews ----------
const reviews = [];
const R = (x, ruleId, status, reason, kinds) => reviews.push({ itemId: x.item.itemId, ruleId, status, reason, evidenceIds: [...new Set(kinds.flatMap((kk) => (kk === 'content' ? [x.contentId] : kk === 'http-response' ? [x.httpId] : kk === 'crawler-policy' ? x.robotsIds : [E[x.item.uri][kk]])).filter(Boolean))], reviewer: REVIEWER, reviewedAt: now });
const SURFACE = ' Surface: anonymous raw HTTP source captured 2026-11-18; rendered DOM, indexing and engine behaviour not observed.';
const claudeAnchor = ['/en/guides/claude-code/', '/vi/guides/claude-code/'].every((p) => ids[O + p].has('content-search-audit'));
if (!claudeAnchor) throw new Error('expected #content-search-audit in Claude Code guides');

for (const x of all) {
  const k = klass(x);
  const m = x.meta;
  const isHome = k === 'HOME', isTxt = k === 'TXT';
  const desc = m.isHtml ? m.meta.find((a) => a.name === 'description')?.content : null;
  const lm = m.isHtml ? JSON.parse(artifacts[`evidence/host-${x.short}-locale-map.txt`]) : null;
  const ct = m.isHtml ? JSON.parse(artifacts[`evidence/host-${x.short}-canonical-targets.txt`]) : null;
  const lg = JSON.parse(artifacts[`evidence/host-${x.short}-link-graph.txt`]);
  const mi = JSON.parse(artifacts[`evidence/host-${x.short}-media-inventory.txt`]);

  // quality
  if (!isTxt) R(x, 'quality-task-fit', 'pass', `Against the owner-supplied audience (Codex and Claude Code users; English and Vietnamese) and an auditor-inferred task (labelled in the audience-context record), the captured page supplies what the task needs: ${({ HOME: 'what NKSkills is, three Solution cards with version and release status, a three-step install outline, links to both host guides, a statically present starter prompt and stated limits. Caveat: the proof-strip count conflicts with the cards (finding nks-home-solution-count); this is a factual-consistency defect assessed under entity/claims rules, not a missing task step.', CAT: `Solution Skills with status, upstream entries with licence and pinned commit prefix, and the versioning model, each with a source link.${x.p.startsWith('/vi/') ? ' Caveat: the eyebrow label reads "NKSKILLS / DANH MỤ" (finding nks-vi-catalog-eyebrow-truncated).' : ''}`, SOL: 'composition (three named components), required outputs, prerequisites, distribution status, verification limits and links to both host guides.', GUIDE: 'prerequisites, ordered build/install commands with placeholders explained, verification commands, the host invocation token, and separate sections for the two evaluation candidates with their limits.' })[k]} Whether the commands and claims are correct is not part of this verdict (quality-claims remains unknown).${SURFACE}`, ['content', 'audience-context']);
  else R(x, 'quality-task-fit', 'unknown', 'The plain-text notice names three fonts, their authors and the SIL Open Font License 1.1, and refers to full notices by bare filename ("Full notice: fraunces-OFL.txt" etc.). No owner statement defines the audience task for this resource, and the referenced notice files were neither linked nor collected, so task completion cannot be judged. Narrow observation persisted as finding nks-font-notice-bare-filenames.', ['content', 'audience-context']);
  R(x, 'quality-claims', 'unknown', `Required claim-sources evidence is not available: the publisher's dated records (release records, catalog.yaml, manifests, technical guide) are on github.com, outside the single authorized origin, and were not collected. ${isTxt ? 'Claims present: font authorship and SIL OFL 1.1 licensing for Fraunces, Source Sans 3 and IBM Plex Mono — unverified.' : 'Material claims inventoried but unverified include versions and release status, verification status ("build and installation checked/verified"), prerequisites, licences/commit pins and CLI commands where present.'}${isHome ? ' A narrower supported observation is persisted without resolving this check: the proof strip states two Solution Skills while the same page lists three (finding nks-home-solution-count).' : ''} Absence of corroboration is not evidence of falsehood.`, ['content', ...(isHome ? ['entity-record'] : [])]);
  R(x, 'quality-freshness', 'unknown', `No dated authoritative source was supplied or collectable in scope, and the captured ${isTxt ? 'text' : 'page'} carries no visible publication or last-updated date${isTxt ? '' : ' (version numbers are present but undated)'}; the retained response headers contain no Last-Modified value. Version/date applicability of changing facts therefore cannot be assessed.`, ['content', 'http-response']);
  if (!isTxt) R(x, 'quality-accessible-media', 'pass', `Raw-source media inventory: one <img> (brand mark, empty alt) inside the header brand link that has aria-label and adjacent visible text "NKSkills" — an empty alternative is appropriate for this decorative duplicate; no inline SVG, video, audio, picture, canvas, object/embed or iframe elements.${mi.roleImgElements.length ? ` ${mi.roleImgElements.length} element(s) with role="img": ${mi.roleImgElements.map((r) => `aria-label "${r.ariaLabel}"${r.ariaDescribedby ? `, aria-describedby target ${r.describedbyTargetPresent ? 'present with a full text description' : 'MISSING'}` : ''}`).join('; ')}.` : ''} No informative media lacking a text alternative was found and no audio/video requiring a transcript exists in source. Limits: CSS background images, script-injected media and the binary og:image were not inspected.`, ['content', 'media-inventory']);
  else R(x, 'quality-accessible-media', 'not-applicable', 'The captured representation is text/plain (HTTP content-type header and 377-character body); a plain-text file cannot embed images, audio or video, so there is no media requiring text alternatives or transcripts anywhere in the item.', ['content', 'media-inventory', 'http-response']);

  // seo
  R(x, 'seo-index-controls', 'unknown', `Publisher indexing/snippet intent was not supplied, so directives cannot be compared with intent. Observed only: ${isTxt ? 'a text/plain resource; ' : 'no <meta name="robots"> (or googlebot) element in raw HTML; '}no X-Robots-Tag among the retained response headers (header retention is selective, so header absence is not established); robots.txt for this origin answered 200 with "User-agent: * / Allow: /". Access is not index status.`, ['content', 'http-response', 'crawler-policy']);
  if (!isTxt) R(x, 'seo-canonical', 'pass', `Exactly one canonical declaration in raw HTML: ${ct.canonicalDeclarations[0]}. It equals the final response URL${x.p === '/' ? ' reached after the 308 redirect from the origin root (the root itself declares nothing separately; its captured body is the /en/ document)' : ''}, matches og:url, its target is in the inventory with captured status ${ct.canonicalTargetCapturedStatus} and is self-canonical. The en/vi alternates are declared as separate variants and are not canonicalised into each other. No conflicting declaration was found on the captured surface. Limits: HTTP Link headers were not retained, the rendered DOM was not captured, and a declared canonical does not establish the engine-selected canonical.`, ['content', 'canonical-targets']);
  else R(x, 'seo-canonical', 'unknown', 'A text/plain resource can declare a canonical only through an HTTP Link header. The retained header subset (content-type, content-length, etag, cache-control) does not include Link, and retention is selective, so neither presence nor absence is established; intended variants were not supplied. Non-HTML format alone does not justify not-applicable.', ['content', 'canonical-targets'].filter((kk) => E[x.item.uri][kk] || kk === 'content').concat(['http-response']));
  if (k === 'HOME') R(x, 'seo-metadata', 'fail', `Title ("${m.title}") and H1 represent the page. The meta description and og:description, however, enumerate the offering as "${desc}" — two workflows — while the same captured page presents three Solution cards including "Content search audit" v0.1.32. The description under-represents current page content (same stale enumeration as the proof-strip count). No length or keyword rule was applied. Finding nks-meta-descriptions-omit-third-workflow.${SURFACE}`, ['content', 'audience-context']);
  else if (k === 'GUIDE') R(x, 'seo-metadata', 'fail', `Title ("${m.title}") and H1 accurately name the host guide and headings describe their sections. The meta description and og:description say "${desc}", naming two workflows, while the captured guide also contains section "06 / CONTENT SEARCH AUDIT · 0.1.32" with its own build, install and invocation steps. The description under-represents the page task set. No length or keyword rule was applied. Finding nks-meta-descriptions-omit-third-workflow.${SURFACE}`, ['content', 'audience-context']);
  else if (!isTxt) R(x, 'seo-metadata', 'pass', `Title ("${m.title}"), meta description ("${desc}"), og tags, single H1 and section headings consistently and accurately describe the captured page for the supplied audience; the description is distinct from other pages in the inventory and the two locale variants carry translated metadata. No length, keyword-position or H1-count rule was applied.${SURFACE}`, ['content', 'audience-context']);
  else R(x, 'seo-metadata', 'not-applicable', 'The item is served as text/plain (content-type header). A plain-text representation has no HTML title, meta description or heading markup to review; its first line "NKSkills site font notices" is plain body text. The metadata rule therefore has no applicable component in this item.', ['content', 'audience-context', 'http-response']);
  R(x, 'seo-internal-links', 'pass', `Static link graph of the declared inventory: ${isTxt ? 'the text file has no outgoing links (plain text)' : `${lg.outgoingInternalSummary.total} outgoing same-origin links, all resolving to inventory items captured with status 200 (${lg.outgoingInternalSummary.targetsNotInInventory} outside inventory, ${lg.outgoingInternalSummary.targetsNot200} non-200), ${lg.outgoingInternalSummary.fragmentsMissing} fragment targets missing from the target source, ${lg.outgoingInternalSummary.linksWithoutTextOrAriaLabel} links lacking both text and aria-label (icon-only arrows carry aria-label)`}. Inbound: ${x.p === '/' ? 'no captured page links to the bare origin root; it is the crawl seed and permanently (308) redirects to /en/, which has inbound links from ' + lg.inboundFromOtherCapturedPagesToFinalUrl.length + ' other captured pages' : `${lg.inboundFromOtherCapturedPagesToFinalUrl.length} other captured pages link to it`}. No verified broken internal target. Limits: ${lg.outgoingExternalNotFetched.length} distinct external targets were excluded and are unverified; discovery is static-source only, so absence of other inbound links is not established.`, ['content', 'link-graph']);
  R(x, 'seo-structured-data', 'unknown', isTxt ? 'No schema-extraction evidence applies to a text/plain body and no HTTP-level structured metadata was captured; applicability to this notice file is unresolved without publisher intent.' : 'Raw HTML contains no JSON-LD block, microdata attribute or RDFa typeof (schema-extraction record); only Open Graph meta tags are present. There is therefore no extracted structured data to compare with visible claims on this surface. Raw absence does not establish rendered absence (scripts were not executed), and absence of schema markup is not itself a defect or an eligibility verdict. Left unresolved rather than passed.', isTxt ? ['content'] : ['content', 'schema-extraction']);
  if (!isTxt) R(x, 'seo-locales', 'pass', `html lang="${m.lang}" matches the body language. Raw-HTML alternates: ${lm.alternates.map((a) => `${a.hreflang} → ${a.href.slice(O.length)}`).join(', ')}; the self reference equals the final URL (${lm.selfReferenceMatchesFinalUrl}); the counterpart ${lm.counterpart.url.slice(O.length)} was captured with status ${lm.counterpart.capturedStatus}, html lang="${lm.counterpart.htmlLang}", declares the identical alternate set (${lm.counterpart.sameAlternateSet}) and links back (${lm.counterpart.returnsLinkToThisFinalUrl}); canonical stays within the same locale; header and footer language switches point to the equivalent page.${x.p === '/' ? ' The origin root 308-redirects to /en/, consistent with x-default → /en/ (no language negotiation was tested).' : ''}${x.p === '/vi/catalog/' ? ' Content caveat: eyebrow label "NKSKILLS / DANH MỤ" is truncated relative to "Danh mục" used elsewhere (finding nks-vi-catalog-eyebrow-truncated); this does not affect the locale relationship.' : ''}${x.p === '/vi/' ? ' Content caveat: some illustrative mock-up strings remain in English on the Vietnamese page (e.g. "What is the real problem?"); recorded as an optional note, not a relationship defect.' : ''} Limits: sitemap/HTTP-header annotations and engine language selection not observed.`, ['content', 'locale-map']);
  else R(x, 'seo-locales', 'unknown', 'One English text/plain notice is linked from both the English and Vietnamese footers ("Font licenses" / "Giấy phép font"). No locale variant or annotation is observable on the captured surface (Link headers not retained) and no publisher intent about localising legal notices was supplied.', ['content', 'http-response']);
  R(x, 'seo-rendering', 'unknown', `No rendered DOM was captured: browser and script execution are outside the declared pilot scope. ${isTxt ? 'A text/plain body is unlikely to depend on scripts, but no rendered evidence exists.' : `Raw source references ${m.scripts.length} script(s): ${m.scripts.map((s) => s.src).join(', ')} (not fetched, not executed)${m.inertSurfaces.template ? `, and ${m.inertSurfaces.template} inert <template> elements holding starter-prompt variants selected by script; the default prompt text is present statically` : ''}. Main copy is present in raw HTML, but source-versus-rendered comparison is not possible.`} The discovery queue keeps this item as rendering-unreviewed.`, ['content']);

  // aio
  R(x, 'aio-crawler-policy', 'unknown', 'Publisher intent for search discovery, AI training crawlers and user-triggered retrieval was not supplied. Observed control only: robots.txt (HTTP 200) contains "User-agent: *", "Allow: /" and a Sitemap line; no agent-specific groups (e.g. for OAI-SearchBot, GPTBot, ChatGPT-User, Google-Extended) are present, so all agents fall under the wildcard allow for this URL. Permission is not evidence that any crawler fetched, retrieved or cited the page.', ['crawler-policy']);
  if (isHome) R(x, 'aio-entity-consistency', 'fail', `Product facts on this page conflict with each other and with the catalog: the proof strip states "${x.p === '/vi/' ? '02 Solution Skills / 01 bản kỹ thuật / 01 ứng viên đánh giá' : '02 Solution Skills / 01 technical release / 01 evaluation candidate'}" while the same page presents three Solution cards (001 v1.1.0 technical release; 002 v0.1.0 and 003 v0.1.32 evaluation candidates) and both catalog pages state "03 Solution Skills". The conflict exists whichever number is intended; the authoritative value is unresolved because the repository records are outside the authorized origin. Names, versions, statuses and hosts are otherwise consistent across captured pages (entity-record). Finding nks-home-solution-count. An ambiguous count is not proof of actual model confusion.`, ['content', 'entity-record']);
  else R(x, 'aio-entity-consistency', 'unknown', `${isTxt ? 'The notice states font names, authors and licences; no authoritative record (font licence files, upstream font metadata) was collected to compare against.' : 'On the captured surface this page\'s names, versions (1.1.0 / 0.1.0 / 0.1.32 where present), release statuses and supported hosts agree with the other captured pages (derived entity-record).'} The rule compares against authoritative entity records; the publisher's catalog.yaml, manifests and release records are on an excluded origin and were not compared, so a pass is not supported.${k === 'CAT' ? ' Note: this page\'s "03 Solution Skills" counter conflicts with the home proof strip ("02"); see finding nks-home-solution-count on the home items.' : ''}`, ['content', 'entity-record']);
  if (!isTxt) R(x, 'aio-retrievable-facts', 'pass', `The concrete facts a Codex/Claude Code user would need from this page are present as readable text in the raw HTML (no script execution needed): ${({ HOME: 'product definition, three Solution Skills with versions and statuses, supported hosts, install outline, default starter prompt, security-source status and FAQ answers with their conditions. Caveat: the conflicting "02 Solution Skills" count is also retrievable (finding nks-home-solution-count); host/language prompt variants beyond the default sit in inert <template> elements.', CAT: 'each Solution Skill with version and status, each upstream entry with licence and commit prefix, and the update policy.', SOL: 'version and status, the three components and their origin, required outputs, prerequisites, distribution status and the human-review limit.', GUIDE: 'prerequisites, the literal build/install commands, verification commands, invocation tokens and the candidate-status caveats.' })[k]} Readable facts do not prove retrieval or citation by any engine; factual accuracy is assessed separately (unknown).`, ['content', 'audience-context']);
  else R(x, 'aio-retrievable-facts', 'unknown', 'Font names, authors and licence names are readable plain text, but the full licence notices are referenced only by bare filename and were not collected; with no owner-defined audience need for this resource, whether the needed facts are retrievable is unresolved.', ['content', 'audience-context']);

  // aeo
  R(x, 'aeo-question-coverage', 'unknown', `No question set from search, support, sales or customer evidence was supplied.${isHome ? ' The page\'s own FAQ (four publisher-authored questions) is not evidence of real user questions.' : ''} Hypothetical questions were not invented to resolve this check.`, ['content']);
  R(x, 'aeo-answer-context', 'unknown', `No supplied question set against which to judge whether extracted answers keep their definitions, prerequisites and limitations.${isHome ? ' Observation only: the four FAQ answers each restate their condition (e.g. the problem-presentation answer names version 0.1.0 and its candidate status).' : ''}`, ['content']);
  R(x, 'aeo-answer-evidence', 'unknown', 'Claim-sources evidence for material answer claims is unavailable in scope (publisher records are on an excluded origin); see quality-claims. Clear formatting does not establish factual accuracy.', ['content']);
  // geo
  for (const r of ['geo-observed-presence', 'geo-answer-accuracy', 'geo-cohort-validity']) R(x, r, 'unknown', 'No AI response observations, prompt cohorts or claim adjudications were supplied or collected (no authenticated providers or measurement exports in this pilot). Mentions, citations, answer accuracy and cohort validity are unmeasured — unavailable, not zero. Readiness checks do not substitute for measurement.', ['content']);

  // portfolio (local)
  R(x, 'portfolio-task-gaps', 'unknown', 'No question set or demand evidence (queries, support themes, customer questions) was supplied, and discovery of the site inventory is incomplete; audience tasks cannot be mapped to gaps without inventing demand.', ['content', 'inventory-map']);
  R(x, 'portfolio-duplication', 'pass', `Within the 12 declared items, overlap involving this item is limited to legitimate variants: ${({ HOME: x.p === '/' ? 'the origin root is a 308 redirect alias of /en/ (same bytes, canonical /en/), and /vi/ is its declared Vietnamese variant.' : 'its declared en/vi locale counterpart (reciprocal hreflang, separate canonicals) and the / → /en/ redirect alias.', CAT: 'its declared en/vi locale counterpart; the home catalog teaser summarises and links to it rather than duplicating its tables.', SOL: 'its declared en/vi locale counterpart; home and catalog cards summarise and link to it.', GUIDE: 'its en/vi locale counterpart and the sibling host guide, which differs in host name, --target value and invocation prefix — a real audience (host) variant with its own canonical.', TXT: 'none; it is the only licence notice in the inventory.' })[k]} No consolidation is proposed. Keyword overlap was not used as a criterion, and no query/page behaviour evidence exists. Limit: the declared inventory is not the whole site.`, ['content', 'inventory-map']);
  if (isHome) R(x, 'portfolio-contradictions', 'fail', 'The home proof strip counts two Solution Skills (one technical release, one evaluation candidate) while this page\'s own cards and both catalog pages present three (one technical release, two evaluation candidates). Same product, same capture date, both locales — not a date or market difference. Resolution against an authoritative record is pending (repository records are on an excluded origin). Finding nks-home-solution-count.', ['content', 'entity-record', 'inventory-map']);
  else R(x, 'portfolio-contradictions', 'unknown', `${k === 'CAT' ? 'This page\'s "03 Solution Skills" counter conflicts with the home proof strip ("02"); the catalog is internally consistent (3 listed, 15 upstream = 9 + 6), so the defect is recorded on the home items, but which value is authoritative is unresolved.' : 'No conflicting material claim involving this item was found among the captured pages (derived entity-record).'} Resolution against authoritative records (catalog.yaml, manifests, release records on an excluded origin) was not possible, so a pass is not supported.`, ['content', 'entity-record', 'inventory-map']);
  if (k === 'HOME' || k === 'CAT') R(x, 'portfolio-journey-links', 'fail', `Navigation to related tasks is otherwise complete (header, footer, language switch to the equivalent page, ${k === 'HOME' ? 'both host guides offered for codebase onboarding' : 'solution and source links'}), but the only next-step link for "Content search audit" on this page ("${k === 'HOME' ? (x.p === '/vi/' ? 'Cài đặt và sử dụng' : 'Install and use') : (x.p.startsWith('/vi/') ? 'Cài Content search audit' : 'Install Content search audit')}") goes to ${x.p.startsWith('/vi/') ? '/vi' : '/en'}/guides/codex/#content-search-audit. The audience includes Claude Code users, and the Claude Code guide has the same #content-search-audit section with --target claude-code and the /content-search-audit token; from this entry point they land on Codex-specific commands with no in-section link to their host's guide. Finding nks-content-search-audit-codex-only-entry. Navigation preference is not evidence of ranking impact.`, ['content', 'link-graph', 'audience-context']);
  else if (!isTxt) R(x, 'portfolio-journey-links', 'pass', `For the supplied audience the next steps are linked from the captured source: ${k === 'SOL' ? 'both host guides ("Use with Codex" / "Use with Claude Code"), the release record, manifest and full technical setup (external), plus catalog and home via header/breadcrumb' : 'the starter prompt (home #try-it), the install overview breadcrumb (home #install, which offers both host guides), release records and evaluation documents (external), and the catalog'}; the language switch targets the equivalent page; all same-origin targets and fragments resolve in the captured inventory. External targets are unverified. Navigation preference is not evidence of ranking impact.`, ['content', 'link-graph', 'audience-context']);
  else R(x, 'portfolio-journey-links', 'unknown', 'A text/plain notice cannot carry links back to the site or to the full licence files it names; whether a next step is needed for this resource depends on an audience task that was not supplied.', ['content', 'link-graph', 'audience-context']);
}

// ---------- findings ----------
const home = all.filter((x) => klass(x) === 'HOME');
const guides = all.filter((x) => klass(x) === 'GUIDE');
const cats = all.filter((x) => klass(x) === 'CAT');
const viCat = byPath('/vi/catalog/');
const txt = all.find((x) => klass(x) === 'TXT');
const fe = (xs, kinds) => [...new Set(xs.flatMap((x) => kinds.map((kk) => (kk === 'content' ? x.contentId : E[x.item.uri][kk]))))];
const findings = [
  {
    findingId: 'nks-home-solution-count',
    title: 'Home proof strip counts two Solution Skills while the same page and the catalog present three',
    affectedItemIds: home.map((x) => x.item.itemId),
    ruleIds: ['aio-entity-consistency', 'portfolio-contradictions', 'quality-claims'],
    dimensions: ['aio', 'portfolio', 'quality'],
    evidenceIds: fe(home, ['content', 'entity-record', 'inventory-map']),
    classification: 'observed', severity: 'medium', confidence: 'high',
    observation: 'Raw HTML of /en/ (and the identical / alias): <strong>02</strong> Solution Skills, <strong>01</strong> technical release, <strong>01</strong> evaluation candidate; /vi/: 02 Solution Skills, 01 bản kỹ thuật, 01 ứng viên đánh giá. The same pages list Solution 001 (v1.1.0, technical release), 002 (v0.1.0, evaluation candidate) and 003 (v0.1.32, evaluation candidate); /en/catalog/ and /vi/catalog/ state "03 Solution Skills".',
    actionCondition: 'the publisher\'s catalog record (catalog.yaml / solution manifests, not inspected in this audit) confirms three Solution Skills: one technical release and two evaluation candidates',
    remediation: 'Update the home proof strip in both locales to 03 Solution Skills / 01 technical release / 02 evaluation candidates (VI: 03 / 01 bản kỹ thuật / 02 ứng viên đánh giá), ideally generating the counters from the same catalog data as the catalog page. Proposal only; no site change was made by this audit.',
    verification: 'Re-capture /en/ and /vi/ raw HTML and confirm the strip numbers equal the number and statuses of Solution cards on the page and the "Solution Skills" counter on /en/catalog/ and /vi/catalog/.',
    ownerRole: 'Website content owner / front-end maintainer', effort: 'small',
    action: 'update', actionReason: 'Observed internal and cross-page count conflict on the landing page in both locales; the correct value depends on the publisher catalog record.',
  },
  {
    findingId: 'nks-meta-descriptions-omit-third-workflow',
    title: 'Meta descriptions on home and guide pages name two workflows while the pages present three',
    affectedItemIds: [...home, ...guides].map((x) => x.item.itemId),
    ruleIds: ['seo-metadata'], dimensions: ['seo'],
    evidenceIds: fe([...home, ...guides], ['content', 'audience-context']),
    classification: 'observed', severity: 'low', confidence: 'high',
    observation: 'Home meta/og description (EN): "Explore traceable Solution Skills for Codex and Claude Code: the codebase-onboarding technical release and the problem-presentation evaluation candidate." Guide meta/og description (EN, Codex): "Build and install NKSkills Solution Skills from GitHub source, then invoke codebase onboarding or the presentation evaluation candidate in Codex." The Vietnamese and Claude Code variants are equivalent. The home pages also present the "Content search audit" v0.1.32 card and each guide contains section "06 / CONTENT SEARCH AUDIT · 0.1.32".',
    remediation: 'Revise the meta description and og:description of /en/, /vi/ and the four guides so they either include content-search-audit or describe the offering without enumerating a fixed subset; keep EN and VI equivalent. This concerns accurate representation only; no snippet, ranking or length outcome is implied.',
    verification: 'Re-capture the six affected URLs (and / via its redirect) and compare each description with the workflows actually presented in that page\'s body in both locales.',
    ownerRole: 'Website content owner', effort: 'small',
    action: 'update', actionReason: 'Descriptions observed to lag behind page content after the third Solution Skill was added.',
  },
  {
    findingId: 'nks-content-search-audit-codex-only-entry',
    title: 'Content search audit entry points on home and catalog lead only to the Codex guide',
    affectedItemIds: [...home, ...cats].map((x) => x.item.itemId),
    ruleIds: ['portfolio-journey-links'], dimensions: ['portfolio'],
    evidenceIds: fe([...home, ...cats], ['content', 'link-graph', 'audience-context']),
    classification: 'observed', severity: 'low', confidence: 'high',
    observation: 'Home card link "Install and use ↗" / "Cài đặt và sử dụng ↗" and catalog card link (aria-label "Install Content search audit" / "Cài Content search audit") resolve to /{en|vi}/guides/codex/#content-search-audit. The Claude Code guides contain the same id="content-search-audit" section with --target claude-code and the /content-search-audit token, but are not offered from these entry points; the Codex section has no link to the sibling host guide.',
    remediation: 'Offer both host guides for Content search audit on the home and catalog cards (as the codebase-onboarding sections already do), or add a "Using Claude Code?" link at the Codex guide section pointing to /{locale}/guides/claude-code/#content-search-audit. Proposal only.',
    verification: 'Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and confirm a static link to each locale\'s Claude Code #content-search-audit section is reachable from the Content search audit card or its landing section.',
    ownerRole: 'Website content owner / front-end maintainer', effort: 'small',
    action: 'update', actionReason: 'Observed host-specific deep link for a workflow documented for both supported hosts.',
  },
  {
    findingId: 'nks-vi-catalog-eyebrow-truncated',
    title: 'Vietnamese catalog eyebrow label is truncated ("NKSKILLS / DANH MỤ")',
    affectedItemIds: [viCat.item.itemId],
    ruleIds: ['seo-locales', 'quality-task-fit'], dimensions: ['seo', 'quality'],
    evidenceIds: fe([viCat], ['content', 'locale-map', 'audience-context']),
    classification: 'observed', severity: 'low', confidence: 'high',
    observation: 'Raw HTML of /vi/catalog/: <p class="eyebrow">NKSKILLS / DANH MỤ</p>. The English counterpart reads "NKSKILLS / CATALOG" and the Vietnamese navigation, title and footer use "Danh mục"; the final letter "C" is missing in the source text itself (not a rendering effect).',
    remediation: 'Change the eyebrow text on /vi/catalog/ to "NKSKILLS / DANH MỤC". Proposal only.',
    verification: 'Re-capture /vi/catalog/ raw HTML and confirm the eyebrow paragraph reads "NKSKILLS / DANH MỤC".',
    ownerRole: 'Website content owner (Vietnamese copy)', effort: 'small',
    action: 'update', actionReason: 'Observed typo in the captured Vietnamese source.',
  },
  {
    findingId: 'nks-font-notice-bare-filenames',
    title: 'Font licence README refers to full notices by bare filename only',
    affectedItemIds: [txt.item.itemId],
    ruleIds: ['quality-task-fit'], dimensions: ['quality'],
    evidenceIds: fe([txt], ['content', 'audience-context', 'link-graph']),
    classification: 'observed', severity: 'low', confidence: 'medium',
    observation: '/licenses/README.txt (text/plain) says "Full notice: fraunces-OFL.txt", "Full notice: source-sans-3-OFL.txt" and "Full notice: ibm-plex-mono-OFL.txt". These are bare filenames in a plain-text file, so they are not hyperlinks; no captured page links to them, they are not in the discovered inventory, and their existence at any URL was not checked (no request was made).',
    actionCondition: 'the three notice files are meant to be publicly reachable next to the README',
    remediation: 'State the full URLs of the three OFL notice files in the README (or link them from an HTML licences page) so a reader can reach the full licence text. Proposal only.',
    verification: 'Supply or capture the three notice URLs in a follow-up discovery (they are not reachable through static links today) and confirm each returns the licence text.',
    ownerRole: 'Website maintainer', effort: 'small',
    action: 'investigate', actionReason: 'The bare filenames are observed; whether the notice files exist and are reachable is unknown because they were outside discoverable scope.',
  },
];

const bundle = { schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash, parts: [{ path: PART, sourceSnapshotHash: index.partSnapshotHashes[PART], bundle: { reviews, evidence, artifacts, findings } }] };
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2) + '\n');
const tally = {};
for (const r of reviews) tally[r.status] = (tally[r.status] ?? 0) + 1;
console.log(JSON.stringify({ outFile, now, reviews: reviews.length, tally, evidence: evidence.length, findings: findings.length }));
