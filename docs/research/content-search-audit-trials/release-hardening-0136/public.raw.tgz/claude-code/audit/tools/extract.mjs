// Inert text-only extraction of collected campaign snapshots. Reads registered
// evidence artifacts; never executes target markup or scripts; no network access.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [partDir, outDir] = process.argv.slice(2);
const lines = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const inv = lines(path.join(partDir, 'inventory.jsonl'));
const ev = lines(path.join(partDir, 'evidence.jsonl'));
fs.mkdirSync(outDir, { recursive: true });

const decode = (s) =>
  s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
const attrs = (tag) => {
  const out = {};
  for (const m of tag.matchAll(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) {
    out[m[1].toLowerCase()] = decode(m[2] ?? m[3] ?? m[4] ?? '');
  }
  return out;
};
const stripTags = (s) => decode(s.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();

const summary = [];
for (const item of inv) {
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === 'content');
  const http = mine.find((e) => e.kind === 'http-response');
  const robots = mine.filter((e) => e.kind === 'crawler-policy');
  const short = item.itemId.slice(0, 8);
  const dir = path.join(outDir, short);
  fs.mkdirSync(dir, { recursive: true });
  const raw = content ? fs.readFileSync(path.join(partDir, content.artifact), 'utf8') : '';
  const isHtml = /<html[\s>]/i.test(raw);
  const rec = {
    itemId: item.itemId,
    uri: item.uri,
    contentEvidenceId: content?.evidenceId ?? null,
    contentSnapshotHash: content?.snapshotHash ?? null,
    contentSha256Recomputed: crypto.createHash('sha256').update(raw, 'utf8').digest('hex'),
    contentCollectedAt: content?.collectedAt ?? null,
    httpEvidenceId: http?.evidenceId ?? null,
    http: http ? { status: http.value.status, finalUrl: http.value.url, redirects: http.value.redirects, headers: http.value.headers } : null,
    robotsEvidenceIds: robots.map((r) => r.evidenceId),
    robots: robots.map((r) => ({ url: r.value.capture.url, status: r.value.capture.status, body: r.value.capture.body, decision: r.value.decision })),
    isHtml,
    rawChars: raw.length,
  };
  if (isHtml) {
    const headEnd = raw.search(/<\/head>/i);
    const head = raw.slice(0, headEnd < 0 ? 0 : headEnd);
    rec.lang = attrs((raw.match(/<html[^>]*>/i) ?? [''])[0]).lang ?? null;
    rec.title = stripTags((head.match(/<title[^>]*>([\s\S]*?)<\/title>/i) ?? ['', ''])[1]);
    rec.meta = [...head.matchAll(/<meta\b[^>]*>/gi)].map((m) => attrs(m[0].slice(5))).filter((a) => a.name || a.property || a['http-equiv']);
    rec.headLinks = [...head.matchAll(/<link\b[^>]*>/gi)].map((m) => attrs(m[0].slice(5))).filter((a) => /canonical|alternate|sitemap|manifest/i.test(a.rel ?? ''));
    rec.scripts = [...raw.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].map((m) => {
      const a = attrs(m[1]);
      return { type: a.type ?? null, src: a.src ?? null, inlineChars: m[2].length, inlineSha256: crypto.createHash('sha256').update(m[2]).digest('hex').slice(0, 16) };
    });
    rec.jsonLd = [...raw.matchAll(/<script\b[^>]*type\s*=\s*["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script>/gi)].map((m) => {
      try { return { parsed: JSON.parse(m[1]) }; } catch (e) { return { parseError: String(e.message), text: m[1].slice(0, 500) }; }
    });
    rec.inertSurfaces = {
      noscript: (raw.match(/<noscript\b/gi) ?? []).length,
      iframe: (raw.match(/<iframe\b/gi) ?? []).length,
      template: (raw.match(/<template\b/gi) ?? []).length,
      form: (raw.match(/<form\b/gi) ?? []).length,
      eventHandlerAttributes: (raw.match(/\son[a-z]+\s*=/gi) ?? []).length,
    };
    const bodyStart = raw.search(/<body[\s>]/i);
    let body = raw.slice(bodyStart < 0 ? 0 : bodyStart);
    rec.media = {
      img: [...body.matchAll(/<img\b[^>]*>/gi)].map((m) => { const a = attrs(m[0].slice(4)); return { src: a.src ?? null, alt: 'alt' in a ? a.alt : null, role: a.role ?? null, ariaHidden: a['aria-hidden'] ?? null }; }),
      svg: [...body.matchAll(/<svg\b[^>]*>/gi)].map((m) => { const a = attrs(m[0].slice(4)); return { ariaHidden: a['aria-hidden'] ?? null, role: a.role ?? null, ariaLabel: a['aria-label'] ?? null }; }),
      video: (body.match(/<video\b/gi) ?? []).length,
      audio: (body.match(/<audio\b/gi) ?? []).length,
      picture: (body.match(/<picture\b/gi) ?? []).length,
      canvas: (body.match(/<canvas\b/gi) ?? []).length,
      object: (body.match(/<(object|embed)\b/gi) ?? []).length,
    };
    rec.links = [...body.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map((m) => {
      const a = attrs(m[1]);
      let abs = null;
      try { abs = new URL(a.href ?? '', rec.http?.finalUrl ?? item.uri).href; } catch { /* unresolved */ }
      return { href: a.href ?? null, resolved: abs, rel: a.rel ?? null, hreflang: a.hreflang ?? null, ariaLabel: a['aria-label'] ?? null, text: stripTags(m[2]) };
    });
    rec.headings = [...body.matchAll(/<(h[1-6])\b[^>]*>([\s\S]*?)<\/\1>/gi)].map((m) => ({ level: m[1].toLowerCase(), text: stripTags(m[2]) }));
    body = body.replace(/<script\b[\s\S]*?<\/script>/gi, ' ').replace(/<style\b[\s\S]*?<\/style>/gi, ' ').replace(/<svg\b[\s\S]*?<\/svg>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ');
    body = body.replace(/<(h[1-6])\b[^>]*>/gi, (_, h) => `\n\n[${h.toUpperCase()}] `);
    body = body.replace(/<li\b[^>]*>/gi, '\n- ').replace(/<(p|div|section|article|header|footer|nav|main|ul|ol|table|tr|pre|dl|dt|dd|br|figure|figcaption|details|summary|blockquote|aside)\b[^>]*>/gi, '\n').replace(/<\/(p|div|section|article|header|footer|nav|main|ul|ol|table|tr|pre|dl|dt|dd|figure|figcaption|details|summary|blockquote|aside|h[1-6])>/gi, '\n');
    body = body.replace(/<a\b([^>]*)>/gi, (_, a) => `⟦a ${attrs(a).href ?? ''}⟧`).replace(/<\/a>/gi, '⟦/a⟧');
    const text = decode(body.replace(/<[^>]+>/g, '')).replace(/[ \t\r\f\v]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    fs.writeFileSync(path.join(dir, 'text.txt'), text + '\n');
    rec.textChars = text.length;
  } else {
    fs.writeFileSync(path.join(dir, 'text.txt'), raw);
    rec.textChars = raw.length;
  }
  fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify(rec, null, 2) + '\n');
  summary.push({ short, uri: item.uri, isHtml, lang: rec.lang ?? null, rawChars: rec.rawChars, textChars: rec.textChars, hashOk: rec.contentSha256Recomputed === rec.contentSnapshotHash });
}
fs.writeFileSync(path.join(outDir, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 1));
