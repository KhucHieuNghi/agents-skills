import sys,json
from pathlib import Path
from html.parser import HTMLParser
class Source(HTMLParser):
    def __init__(self):
        super().__init__(); self.meta=[]; self.text=[]; self.skip=None; self.links=[]; self.media=[]
    def handle_starttag(self,t,attrs):
        a=dict(attrs)
        if t in ('script','style','template'):
            self.skip=t
            self.meta.append([t,a])
        if t in ('html','meta','link','h1','title'):
            self.meta.append([t,a])
        if t=='a': self.links.append(a.get('href'))
        if t in ('img','video','audio','svg','iframe','canvas'): self.media.append([t,a])
    def handle_endtag(self,t):
        if t==self.skip: self.skip=None
    def handle_data(self,s):
        if not self.skip and s.strip(): self.text.append(s.strip())
