import csv,hashlib,json
from pathlib import Path
from urllib.parse import urlsplit
P=Path(__file__).resolve().parent
R=P/'report'
def read(p): return json.loads(p.read_text())
def hashfile(p): return hashlib.sha256(p.read_bytes()).hexdigest()
m=read(R/'report-manifest.json')
c=read(R/'coverage.json')
assert m['coverage']==c['itemCoverage']
for name,h in m['files'].items(): assert hashfile(R/name)==h
D=P/'reviewed/parts/000001'
ev=[json.loads(l) for l in (D/'evidence.jsonl').read_text().splitlines()]
inv={e['itemId']:urlsplit(e['uri']).path for e in map(json.loads,(D/'inventory.jsonl').read_text().splitlines())}
findings=read(D/'findings.json')
with (R/'content-actions.csv').open() as f: actions=list(csv.DictReader(f))
assert len(findings)==m['localFindings']==len(actions)==2
for finding in findings:
    assert any(finding['findingId'] in row.values() for row in actions)
    assert finding['title'] in (R/'report.md').read_text().replace(chr(92), chr(0)[:0])
scope=read(P/'discovery/source.json')
queue=read(P/'union.json')['pendingQueue']
cov=c['itemCoverage']
assert len(scope['records'])==cov['total']
assert not read(P/'discovery/discovery.json')['frontier']
exclusions=len(scope['exclusions'])
unique=len({e['locator'] for e in scope['exclusions']})
checks=sum(d['total'] for d in cov['dimensions'].values())
done=sum(d['completed'] for d in cov['dimensions'].values())
unknown=sum(d['unknown'] for d in cov['dimensions'].values())
lines=['# NKSkills public pilot evidence notes','',
       'The campaign collected all 12 allowed URL identities, including the root redirect to the English homepage. It inspected five English/Vietnamese HTML pairs and one plain-text font notice, plus the redirect’s final representation. Coverage remains partial.',
       '',f'The installed report records {cov["audited"]} fully audited, {cov["states"]["pending"]} pending, and 0 blocked, failed, unsupported or excluded inventory items. There are {checks} required local checks, with {done} resolved, {unknown} unknown and {cov["missingChecks"]} missing check records. Three of four global judgments are unresolved.',
       '',f'Discovery used {scope["scope"]["visitedPages"]} of 30 page captures at max depth 5. There are no outstanding page-count or depth entries. The union retains {len(queue)} entries (10 rendering checks, one navigation adapter limitation for the readable font notice, one partial source and one unconfirmed scope). Discovery separately records {exclusions} excluded external link occurrences across {unique} unique URLs. The original capture’s six unvisited entries remain historical in the immutable source. CMS, orphan and rendered navigation coverage remain unconfirmed.',
       '', '## Highest-priority editorial action','',
       'Both homepage proof strips describe two Solution Skills and one evaluation candidate. Both catalogs list three solutions and include the content-search-audit evaluation candidate. Pull totals from the catalog or label the home figures as featured workflows. Verify both language pairs against the same inventory in a fresh static capture. The evidence below is normalized text linked to the captured HTML.',
       '']
quotes=[]
report='pilot-evidence-notes.md'
for route,num in [('/en/','02'),('/en/catalog/','03'),('/vi/','02'),('/vi/catalog/','03')]:
    e=next(x for x in ev if inv[x['itemId']]==route and x['kind']=='extracted-text')
    sf=D/e['artifact']; sl=sf.read_text().splitlines()
    i=next(i for i in range(len(sl)-1) if sl[i:i+2]==[num,'Solution Skills'])
    label=str(sf.relative_to(P))
    lines.append(f'- {route} — “{num} Solution Skills” ({label}:{i+1}-{i+2})')
    quotes.append(dict(quoteId='count-'+route,source=label,sourceLabel=label,sourceHash=hashfile(sf),startLine=i+1,endLine=i+2,reportStartLine=len(lines),reportEndLine=len(lines),normalization='whitespace',quote=num+' Solution Skills'))
lines.extend(['','## Other source observations','',
    '- All five captured English/Vietnamese HTML pairs have reciprocal language alternates and self-canonical links in source. The shared x-default for each pair points to its English version. Search-engine canonical selection and indexing are unknown.',
    '- Both platform guide pairs use distinct install targets and invocation syntax. The onboarding solution pages retain the technical-release caveat and the need for human review. Runtime behavior and upstream claims were outside the captured evidence.',
    '- The license README was readable in the campaign. Static HTML link extraction does not cover its three plain-text notice filenames.',
    '', '## Evidence needed to continue','',
    'Supply the CMS and orphan URL inventory and an authorized rendered-navigation capture. Provide owner-approved canonical and publisher crawler intent, upstream release and license records, and a sourced English/Vietnamese question set. Keep dated webmaster index and ranking data, verified crawler logs, conversion exports and response-level AI observations separate. For AI observations, record the surface, locale, prompt cohort, date, exact responses and cited URLs, then adjudicate factual claims against attributable sources. Google AI Overviews, citations, rankings, indexing, crawler activity and conversions remain unmeasured in this pilot.',
    '', '[Unified audit report](report/report.md) · [Discovery receipt](discovery/source.json) · [Global validation](global-validation.json)',''])
(P/report).open('x').write('\n'.join(lines))
with (P/'quote-ledger.json').open('x') as f: json.dump(dict(root=str(P),report=report,reportHash=hashfile(P/report),quotes=quotes),f,indent=2)
with (P/'report-integrity.json').open('x') as f: json.dump(dict(valid=True,reportFiles=m['files'],localFindings=len(findings),discoveryExcludedOccurrences=exclusions,discoveryExcludedUnique=unique),f,indent=2)
