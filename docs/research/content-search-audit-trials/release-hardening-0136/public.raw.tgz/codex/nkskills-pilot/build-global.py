import json,hashlib
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlsplit
P=Path(__file__).parent
I=P/'reviewed-index'
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def now(): return datetime.now(timezone.utc).isoformat()
idx=json.loads((I/'index.json').read_text())
part='parts/000001'
src=P/'reviewed'/part
items=rows(src/'inventory.jsonl')
es=rows(src/'evidence.jsonl')
ids=[i['itemId'] for i in items]
by={(e['itemId'],e['kind']):e for e in es}
def refs(kinds):
    return [dict(part=part,evidenceId=by[i,k]['evidenceId']) for i in ids for k in kinds if (i,k) in by]
content=refs(['content'])
raw=refs(['http-response','source-review-notes'])
matrix='\n'.join(i['uri']+' | '+by[i['itemId'],'audience-context']['value'].split('Inferred page task: ')[-1] for i in items)
contexts=[]
def context(id,kind,value,locator,sources):
    contexts.append(dict(evidenceId=id,kind=kind,value=value,locator=locator,collectedAt=now(),snapshotHash=hashlib.sha256(value.encode()).hexdigest(),sourceReferences=sources))
context('task-matrix','inventory-map',matrix,'Attributed mapping of 12 campaign content identities',content)
context('audiences','audience-context','Owner-supplied pilot context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences.','Pilot request',[])
context('observed-graph','link-graph',(P/'discovery/graph.jsonl').read_text(),'Continued static discovery graph; source anchors only',raw)
context('product-observations','entity-record','Owner-supplied product identity: versioned NKSkills workflows for Codex and Claude Code. Across the five source pairs, Codebase onboarding is presented as technical release 1.1.0. The catalogs and install guides present Content search audit 0.1.32 as an evaluation candidate. Both home proof strips report two solutions while their corresponding catalogs report three. That discrepancy concerns site copy; upstream release verification is unavailable.','Pilot request and attributed campaign snapshot comparison',content)
reviews=[]
for rule,status,reason,ctx in [
 ('portfolio-task-gaps','unknown','All declared identities were mapped to inferred tasks. Customer demand and uncovered journeys require sourced questions and broader inventory.', ['task-matrix','audiences']),
 ('portfolio-duplication','pass','Within the declared snapshot set the apparent duplicate root is an HTTP redirect to the English home. The five English/Vietnamese pairs serve parallel language audiences. Codex and Claude Code guides share setup but differ in the install target and invocation. Catalog, onboarding detail, and font attribution each serve distinct tasks. This is a source overlap judgment within the declared set.', ['task-matrix']),
 ('portfolio-contradictions','unknown','The bilingual home/catalog count conflict is supported and recorded as two local findings. Other visible workflow identifiers and release caveats were compared. The owner context does not adjudicate the full set of release, runtime and license claims.', ['task-matrix','product-observations']),
 ('portfolio-journey-links','unknown','Observed static routes connect home, catalog, onboarding and localized install guides. The font README names notice files in plain text. Rendered menus and navigation beyond the static graph remain unavailable.', ['observed-graph','audiences'])]:
    reviews.append(dict(ruleId=rule,status=status,reason=reason,reviewer='Codex, NKSkills public pilot reviewer',reviewedAt=now(),itemIds=ids,evidenceReferences=content+raw,contextEvidenceIds=ctx))
bundle={k:idx[k] for k in ('schemaVersion','campaignId','sourceManifestHash','partSnapshotHashes')}
bundle.update(contextEvidence=contexts,reviews=reviews,findings=[])
with (P/'global-review-bundle.json').open('x') as f: json.dump(bundle,f,ensure_ascii=False,indent=2)
