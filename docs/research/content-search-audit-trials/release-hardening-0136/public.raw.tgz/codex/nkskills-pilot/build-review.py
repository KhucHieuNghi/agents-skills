import json,hashlib,re
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlsplit
from inspect_source import Source
P=Path(__file__).parent
def j(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def write(name,obj):
    with (P/name).open('x') as f: json.dump(obj,f,ensure_ascii=False,indent=2)
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
reviewer='Codex, NKSkills public pilot reviewer'
owner='NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.'
notes={
'/':('Redirect entry into the English home and its browse or starter-prompt paths.','The campaign response must substantiate the redirect destination. The English landing snapshot shares its editorial content.'),
'/en/':('English discovery and starter-prompt selection.','The home showcases onboarding 1.1.0 and problem presentation 0.1.0 with release limits. The proof strip counts two Solution Skills while the English catalog lists three, including content search audit.'),
'/vi/':('Vietnamese discovery and starter-prompt selection.','The home preserves the English release distinctions and caveats. Its proof strip counts two while the Vietnamese catalog lists three.'),
'/en/catalog/':('English workflow evaluation and upstream provenance lookup.','Three solutions are visibly distinguished from upstream entries. The audit candidate is 0.1.32. Security sources are explicitly distinguished from released solutions.'),
'/vi/catalog/':('Vietnamese workflow evaluation and upstream provenance lookup.','Three solutions and the audit candidate 0.1.32 match the English catalog. The tracked-source versus released-solution distinction is present.'),
'/en/solutions/codebase-onboarding/':('English evaluation of onboarding outputs, prerequisites and release limits.','Three named components, file evidence and C1/C2 deliverables accompany the technical-release caveat. The page links both platform guides.'),
'/vi/solutions/codebase-onboarding/':('Vietnamese evaluation of onboarding outputs, prerequisites and release limits.','Component names, prerequisites, technical release and human verification caveat align with the English solution.'),
'/en/guides/codex/':('English Codex install and invocation.','Build, digest, installation and Quick mode are ordered. Problem presentation and content search audit have separate candidate installation sections and caveats.'),
'/vi/guides/codex/':('Vietnamese Codex install and invocation.','CodeGraph is scoped to onboarding and examples retain the Codex target. Candidate versions and caveats align with the English guide.'),
'/en/guides/claude-code/':('English Claude Code install and invocation.','The installation example targets Claude Code and the guide uses slash invocations. Candidate and release caveats are present.'),
'/vi/guides/claude-code/':('Vietnamese Claude Code install and invocation.','The target and slash invocations align with the English guide. Candidate and release caveats are present.'),
'/licenses/README.txt':('Font attribution and full license reference.','The notice names three fonts and the corresponding plain-text notice filenames. Those filenames are text references rather than static HTML hyperlinks. Full notices and license assertions remain unverified.')
}
index=j(P/'ready-index/index.json')
def binding(i): return {k:i[k] for k in ('schemaVersion','campaignId','sourceManifestHash')}
parts=[]
for path,snapshot in index['partSnapshotHashes'].items() if isinstance(index['partSnapshotHashes'],dict) else [(x['path'],x['snapshotHash']) for x in index['partSnapshotHashes']]:
    d=P/'campaign'/path
    inv=rows(d/'inventory.jsonl'); es=rows(d/'evidence.jsonl'); checks=rows(d/'checks.jsonl')
    evidence=[]; artifacts={}; reviews=[]; findings=j(d/'findings.json')
    def add(it,kind,value,refs,method,locator,limitations):
        eid=sha(it+kind+value); a='evidence/'+eid+'.txt'; artifacts[a]=value
        evidence.append(dict(evidenceId=eid,itemId=it,kind=kind,value=value,method=method,locator=locator,collectedAt=now(),snapshotHash=sha(value),artifact=a,encoding='utf8',sourceEvidenceIds=refs,redaction='Public source or supplied pilot context',limitations=limitations,byteLength=len(value.encode())))
        return eid
    lookup={}
    for i in inv:
        it=i['itemId']; url=i['uri']; route=urlsplit(url).path
        by={e['kind']:e for e in es if e['itemId']==it}
        if 'content' not in by: continue
        c=by['content']; cid=c['evidenceId']; raw=(d/c['artifact']).read_text(); s=Source(); s.feed(raw)
        task,obs=notes[route]; text='\n'.join(s.text)
        metadata=[(tag,a) for tag,a in s.meta if tag=='html' or tag=='link' and a.get('rel') in ('canonical','alternate') or tag=='meta' and a.get('name') in ('description','robots')]
        captured=by['http-response']['value']
        lookup[route]=(it,cid,text,metadata)
        a=add(it,'audience-context',owner+'\nInferred page task: '+task,[cid],'Owner task statement and source-task annotation','Pilot request and '+url,['Business context is owner-supplied. Page task is inferred.'])
        add(it,'extracted-text',text,[cid],'Inert HTMLParser text extraction or plain text','Content snapshot '+c['artifact'],['Source text only. Script, style and template content excluded.'])
        material=f"Task and editorial review: {task} {obs}\nSource SEO: {json.dumps(metadata,ensure_ascii=False)}\nRaw anchor destinations: {json.dumps(list(dict.fromkeys(s.links)),ensure_ascii=False)}\nMedia elements inspected: {len(s.media)}. Rendered behavior and complete media equivalence are unresolved.\nAIO: Public collector access and source extractability are observable. Publisher crawler intent and actual AI retrieval are unresolved.\nAEO: Source passages were inspected for decision context. Real customer questions and independent claim verification are unavailable.\nGEO: Mentions, citations and answer accuracy are unmeasured.\nPortfolio: Role and language compared with the corresponding pages; discovery excludes orphan, CMS and rendered inventory."
        memo=add(it,'source-review-notes',material,[cid,by['http-response']['evidenceId']],'Attributed six-dimension inspection',url,['Bounded to captured source and supplied context.'])
        generic={
        'quality-claims':'External release, runtime and license assertions were not independently verified.',
        'quality-freshness':'Current authoritative release or font records are outside the authorized source.',
        'quality-accessible-media':'Rendered equivalence and complete media applicability have not been established.',
        'seo-index-controls':'Publisher indexing and snippet intent was not supplied.',
        'seo-canonical':'Source annotations were inspected. Complete intended canonical and variant policy was not supplied.',
        'seo-internal-links':'Observed anchors were inspected. Rendered navigation and the complete link graph are unavailable.',
        'seo-structured-data':'Source was inspected without browser execution. Full structured data surface remains unresolved.',
        'seo-locales':'Source locale annotations were compared where present. Broader intended variant inventory and rendered annotations are unresolved.',
        'seo-rendering':'Browser execution was outside the authorized scope.',
        'aio-crawler-policy':'Captured robots decisions cover the audit collector; publisher intent and AI crawler activity are unresolved.',
        'aio-entity-consistency':'Workflow versions and scope were compared in source. A comprehensive authoritative entity record was not supplied.',
        'aeo-question-coverage':'No sourced customer question set was supplied.',
        'aeo-answer-context':'Source answers were read; no sourced question set was supplied.',
        'aeo-answer-evidence':'Source answers were read; underlying independent release and license evidence was not collected.',
        'geo-observed-presence':'No captured AI responses or provider observations were supplied.',
        'geo-answer-accuracy':'No captured AI answers to adjudicate were supplied.',
        'geo-cohort-validity':'No observed response cohort or sourced question set was supplied.',
        'portfolio-task-gaps':'No sourced customer question set or complete site inventory was supplied.',
        'portfolio-duplication':'Observed English/Vietnamese variants and redirect alias were compared; no query behavior or exhaustive inventory was supplied.',
        'portfolio-contradictions':'Observed cross-page assertions were compared. Broader authoritative entity and inventory reconciliation remains open.',
        'portfolio-journey-links':'Static journeys were inspected; browser navigation and actual use remain unknown.'
        }
        for check in [x for x in checks if x['itemId']==it and x['status']=='unknown']:
            rid=check['ruleId']
            if rid=='quality-readable-text': continue
            status='unknown'; reason=generic.get(rid,obs); refs=[cid,memo,a]
            if rid=='seo-metadata' and route not in ('/','/licenses/README.txt'):
                status='pass'; reason='The captured HTML title, description and primary heading describe the inferred task. '+task
            if rid=='aio-retrievable-facts' and route not in ('/','/en/','/vi/','/licenses/README.txt'):
                status='pass'; reason='The task-critical workflow facts appear in readable captured source, with release status or prerequisites in context. '+obs
            if rid=='quality-task-fit' and route in ('/en/solutions/codebase-onboarding/','/vi/solutions/codebase-onboarding/'):
                status='pass'; reason='The evaluation page provides outputs, prerequisites, both installation paths and explicit limits before adoption. '+obs
            reviews.append(dict(itemId=it,ruleId=rid,status=status,reason=reason,evidenceIds=refs,reviewer=reviewer,reviewedAt=now()))
    for lang in ('en','vi'):
        home=lookup.get('/'+lang+'/'); cat=lookup.get('/'+lang+'/catalog/')
        if home and cat and re.search(r'02\s+Solution Skills',home[2]) and re.search(r'03\s+Solution Skills',cat[2]):
            findings.append(dict(findingId='catalog-count-'+lang,title='The home and catalog give different Solution Skill totals ('+lang+')',observation='The home proof strip counts two Solution Skills and one evaluation candidate. The catalog counts three and lists Content search audit as a second evaluation candidate.',remediation='Use a shared catalog source for totals, or label the home counts explicitly as featured workflows.',verification='Compare the English and Vietnamese home proof strips with the corresponding catalog entries and status totals in a fresh static capture.',ownerRole='NKSkills site maintainer',effort='Small copy or template update',affectedItemIds=[home[0],cat[0]],ruleIds=['portfolio-contradictions'],dimensions=['portfolio'],evidenceIds=[home[1],cat[1]],severity='medium',confidence='high',classification='observed'))
    parts.append(dict(path=path,sourceSnapshotHash=snapshot,bundle=dict(reviews=reviews,evidence=evidence,artifacts=artifacts,findings=findings)))
write('part-review-bundle.json',dict(binding(index),parts=parts))
