# NKSkills public pilot evidence notes

The campaign collected all 12 allowed URL identities, including the root redirect to the English homepage. It inspected five English/Vietnamese HTML pairs and one plain-text font notice, plus the redirect’s final representation. Coverage remains partial.

The installed report records 0 fully audited, 12 pending, and 0 blocked, failed, unsupported or excluded inventory items. There are 312 required local checks, with 44 resolved, 268 unknown and 0 missing check records. Three of four global judgments are unresolved.

Discovery used 11 of 30 page captures at max depth 5. There are no outstanding page-count or depth entries. The union retains 13 entries (10 rendering checks, one navigation adapter limitation for the readable font notice, one partial source and one unconfirmed scope). Discovery separately records 98 excluded external link occurrences across 25 unique URLs. The original capture’s six unvisited entries remain historical in the immutable source. CMS, orphan and rendered navigation coverage remain unconfirmed.

## Highest-priority editorial action

Both homepage proof strips describe two Solution Skills and one evaluation candidate. Both catalogs list three solutions and include the content-search-audit evaluation candidate. Pull totals from the catalog or label the home figures as featured workflows. Verify both language pairs against the same inventory in a fresh static capture. The evidence below is normalized text linked to the captured HTML.

- /en/ — “02 Solution Skills” (reviewed/parts/000001/evidence/a527879c69a9889c7b8b9696211d01997993bd787e88ce77ad4659b562bce539.txt:41-42)
- /en/catalog/ — “03 Solution Skills” (reviewed/parts/000001/evidence/ce43e18523a44213d68417e1a7faadb873e4820d1d8b56795b5d9e43558c6805.txt:12-13)
- /vi/ — “02 Solution Skills” (reviewed/parts/000001/evidence/6c3ca63e3082d3b07ce083b58d52a1067dc0985a473588df8cf2af7cccc6224a.txt:41-42)
- /vi/catalog/ — “03 Solution Skills” (reviewed/parts/000001/evidence/c2a31916008faba2fd7f99f8648cfe24c335c0c949dd634584a339edec96d1f1.txt:12-13)

## Other source observations

- All five captured English/Vietnamese HTML pairs have reciprocal language alternates and self-canonical links in source. The shared x-default for each pair points to its English version. Search-engine canonical selection and indexing are unknown.
- Both platform guide pairs use distinct install targets and invocation syntax. The onboarding solution pages retain the technical-release caveat and the need for human review. Runtime behavior and upstream claims were outside the captured evidence.
- The license README was readable in the campaign. Static HTML link extraction does not cover its three plain-text notice filenames.

## Evidence needed to continue

Supply the CMS and orphan URL inventory and an authorized rendered-navigation capture. Provide owner-approved canonical and publisher crawler intent, upstream release and license records, and a sourced English/Vietnamese question set. Keep dated webmaster index and ranking data, verified crawler logs, conversion exports and response-level AI observations separate. For AI observations, record the surface, locale, prompt cohort, date, exact responses and cited URLs, then adjudicate factual claims against attributable sources. Google AI Overviews, citations, rankings, indexing, crawler activity and conversions remain unmeasured in this pilot.

[Unified audit report](report/report.md) · [Discovery receipt](discovery/source.json) · [Global validation](global-validation.json)
