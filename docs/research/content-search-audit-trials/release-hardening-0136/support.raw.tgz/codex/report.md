# Offline content and search audit

**Partial coverage.** All 4 declared dossiers were collected and inspected, with 0 fully audited and 4 pending. Collection states for failed, blocked, unsupported and excluded each count 0. The scope memo was also inspected and serves as instructions, so the file total is 5 and the audit denominator is 4. Embedded pages, captions and policy records are components of their respective dossiers. Each scenario stands alone. All figures and policies are synthetic, and owner records are the comparison basis within their scenario.

**Six material findings.** Correct the customer-facing SSO, pricing, delivery and setup claims before using the drafts. Correct the two October reporting claims before using them for campaign or channel decisions. Each issue appears once, even where several checks apply.

## 01. November 2026 US plan comparison

### F1. The Fir SSO denial conflicts with the supplied documentation

- `01-competitor-claims.md:17` — “Fir has no SSO, as its pricing table proves.”
- `01-competitor-claims.md:13` — “SAML SSO is available on Enterprise, with a minimum of 20 paid seats.”

**Affected item and rationale.** The `/compare` draft turns silence in Fir’s pricing table into an absolute feature denial. The supplied Fir documentation establishes Enterprise availability with a seat minimum. Availability on other plans remains unknown. This affects factual quality, answer support and AI search readiness for the product claim.

**Action and verification.** Replace the denial with the Enterprise SAML SSO statement, including the 20-paid-seat minimum. Compare the revised passage with the supplied November 2026 US documentation and check that it leaves other plans unspecified.

### F2. The price advantage reverses on annual billing

- `01-competitor-claims.md:18` — “Cedar is cheaper per seat than Fir on every billing option.”
- `01-competitor-claims.md:7-9` — “Our annual option: USD 10 per seat per month equivalent, billed annually. Competitor Fir monthly option: USD 15 per seat per month, billed monthly. Fir annual option: USD 9 per seat per month equivalent, billed annually.”

**Affected item and rationale.** The `/compare` claim fails for the supplied annual options. In November 2026 US pretax USD, Cedar is USD 3 less per seat per month on monthly billing (12 vs. 15), while Fir is USD 1 less per seat per month equivalent on annual billing (9 vs. 10). The comparison excludes optional services, none of which are required here. This affects factual quality, answer support and AI search readiness for the pricing claim.

**Action and verification.** Show separate monthly and annual rows with market, date, currency, tax basis and billing cadence. Recompute each comparison using like billing periods and verify the annual rates are labeled monthly equivalents billed annually. Preserve the supported `/monthly-comparison` caption within its monthly-only task (`01-competitor-claims.md:20-24`). Total cost, equivalent features and customer-wide superiority remain outside that caption’s scope.

**Other dimension evidence.** The supplied comparison text serves plan evaluation and the caption serves a narrower monthly price check. Wider content overlap, demand and navigation are unknown. The draft assertions are readable but carry inaccurate facts. Technical SEO and observed generative visibility are unmeasured.

## 02. October 2026 reporting windows

### F3. The monthly cost per conversion mixes two windows

- `02-measurement-windows.md:10` — “October cost per conversion was USD 85.71, from 3000 divided by 35.”
- `02-measurement-windows.md:5-8` — “Spend is complete for October 1–31: USD 3000. Conversion export covers only October 1–7: 35 completed conversions. No conversion data exists for October 8–31. The same spend export gives October 1–7 spend of USD 700.”

**Affected item and rationale.** Draft A reports a full-month cost per conversion for one campaign in USD. The arithmetic rounds correctly, but its spend and completed-conversion counts cover different dates. The supplied first-week caption is sound at USD 20 per completed conversion (700 ÷ 35) and discloses the gap (`02-measurement-windows.md:11-12`).

**Action and verification.** Use that existing caption. Before reporting a monthly ratio, verify a complete October 1–31 conversion export for the same campaign and conversion definition, then divide the matched spend by that count. Missing days remain unmeasured.

### F4. Identified referrals do not support a tenfold estimate

- `02-measurement-windows.md:17-18` — “These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked.”
- `02-measurement-windows.md:14-16` — “Independent referral report: 15 October sessions have an identified AI-assistant referrer. Other sessions have unknown origin. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.”

**Affected item and rationale.** Draft B adds an unsupported tracking fraction, inferred total and causal attribution. The descriptive count of 15 identified sessions is supported. Unknown origin leaves total influence unquantified. This is a factual reporting issue with a GEO measurement interpretation consequence. It establishes no AI answer presence, mention, citation or recommendation rate.

**Action and verification.** Retain only the descriptive October count. Reconcile it to the independent referral report, leave unknown origins unresolved and keep the referral report separate from the campaign conversions. Any future estimate needs evidence for its tracking assumptions, and any causal claim needs a suitable study.

**Other dimension evidence.** The reporting components serve campaign efficiency and referral description separately. No public page, audience questions or related site inventory were supplied for technical SEO, AIO retrieval readiness, AEO coverage or broader portfolio checks.

## 03. Current regional delivery and the 2024 archive

### F5. The current South page repeats North’s same-day policy

- `03-template-service-area.md:10-11` — “South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date.”
- `03-template-service-area.md:4-5` — “Current approved policy: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.”

**Affected item and rationale.** The complete current `/south-delivery` policy passage gives the wrong delivery expectation. The supplied `/north-delivery` passage accurately states the North cutoff (`03-template-service-area.md:8-9`). The South defect spans factual quality, answer evidence, AI search readiness and portfolio consistency.

**Action and verification.** Replace the South passage with the approved next-business-day-only policy. Compare the entire revised passage with the owner record and verify the correct region and timing in each current passage. Retain both regional pages and confirm the archive still carries its 2024 label and routes new orders to both current pages.

**Clean and uncertain cases.** The declared three-page set covers current orders in two distinct regions and historical terms for old orders. `/terms-v1` accurately describes the 2024 contract, when South offered same-day service, and points readers to current pages for new orders (`03-template-service-area.md:13-16`). Shared layout and generic contact wording provide no basis to merge the regional pages (`03-template-service-area.md:18-20`). The archive links are owner-described. Crawl, actual link responses, engine-selected canonicals, query overlap and generative visibility remain unknown.

## 04. Setup promise, permissions FAQ and technical reference

### F6. The universal ten-minute setup guarantee lacks support

- `04-editorial-proof.md:6` — “Every team is guaranteed to finish setup in 10 minutes.”
- `04-editorial-proof.md:3-5` — “Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.”

**Affected item and rationale.** The landing-page copy turns a study median into a universal guarantee and supplies a different time. This affects factual quality and the support for a material setup-duration answer. The sample establishes a descriptive median. Study date and wider applicability are unknown.

**Action and verification.** Remove the guarantee. If a timing claim remains, state the median of 15 minutes across the 20 observed onboarding sessions in the supplied study. Check the revised copy against that record for the correct statistic and sample and for any unsupported ceiling, guarantee, refund implication or extrapolation.

**Clean and uncertain cases.** The complete permissions FAQ answers the stated role-identification task. It correctly says editors cannot delete the workspace and only owners can (`04-editorial-proof.md:8-13`). A deletion procedure would serve a different task. The owner describes the `/status-codes` table as complete and accurate for its technical reference task. Its terse style and lack of a purchase CTA fit that task, and authorship remains unknown (`04-editorial-proof.md:15-19`). The setup, permissions and reference components serve distinct purposes. The FAQ is clear in the captured text. Broader portfolio coverage, technical SEO, AI retrieval and GEO outcomes remain unknown.

## Coverage and evidence needed

| Dimension | Resolved | Unknown | Evidence needed for remaining checks |
| --- | ---: | ---: | --- |
| Content quality | 8 | 12 | Complete page and media captures, audience tasks and dated claim or version records |
| Technical and on-page SEO | 0 | 32 | Supplied HTTP, headers, crawl and rendered captures, index controls and status, canonical and locale signals, metadata, links and structured data |
| AI search optimization (AIO) | 2 | 10 | Target surfaces and markets, crawler controls and publisher intent, full retrievable text and authoritative entity records |
| Answer quality (AEO) | 5 | 7 | Documented customer questions and supporting records for remaining answer passages |
| Generative visibility (GEO) | 0 | 12 | Supplied response captures, prompt/cohort metadata, exact citations and dated sources for answer adjudication |
| Portfolio | 2 | 14 | Broader inventory where applicable, task and demand evidence, and a supplied link graph |
| **Total** | **17** | **87** | **104 planned checks** |

Resolved includes passes and findings. Every planned check has a record. The unresolved checks keep all four dossiers pending. The supplied set is complete as a file inventory and separately as dossier 03’s declared three-page inventory. The evidence supports localized findings and specific clean passages. Collection cannot establish wider site completeness, live page behavior or performance.

Three synthetic measurement sources are attached in the generated [evidence report](audit-artifacts/with-measurements/report.md). They preserve the October 2026 campaign’s spend and first-week conversions, the independent October count of 15 identified AI-referrer sessions and the undated 20-session onboarding study. No Search Console, GA4, Bing, server-log or response-level AI exports were supplied. Rankings, keyword volumes, indexing, mentions, citations, recommendation rates and answer accuracy remain unavailable. A future authorized offline review can use supplied captures grouped by surface, locale, prompt, date and repeat, then compute each rate on its own eligible denominator and compare only compatible cohorts.

The [validated coverage](audit-artifacts/validation.json), [action register](audit-artifacts/with-measurements/content-actions.csv) and [quotation receipt](audit-artifacts/quote-receipt.json) accompany the report.
