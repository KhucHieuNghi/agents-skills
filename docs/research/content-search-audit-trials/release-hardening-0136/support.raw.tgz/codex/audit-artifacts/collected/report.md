# Content audit — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T04:58:57\.442Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run bfe74f7a\-0528\-4a11\-89ec\-a608c92a42a6\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |
| bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| c7346e54e28071739fb47f6eb55d1d740b4e4e23aee09b69ff94eb42ee58fb22 | 1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0 | local\-file | 2026\-11\-18T04:58:57\.425Z | 0 full elapsed days | [evidence/1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0\.txt](evidence/1af91cf12468d037470f6c6a9287011afdea845914e25eaecb5f140c976fd3b0.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7272923b5a9e6e66122eb1202216be817264c670de230a50eeb25c03d2e1c586 | 7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d | local\-file | 2026\-11\-18T04:58:57\.426Z | 0 full elapsed days | [evidence/7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d\.txt](evidence/7ae14e35c244039973f7d1fc0345298c8e183d43a71f2801ff3690e905d0b94d.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 211f3ba16a959085de86fc0795c45d411a4696c95baee722a91faa6b230f77eb | 87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9 | local\-file | 2026\-11\-18T04:58:57\.426Z | 0 full elapsed days | [evidence/87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9\.txt](evidence/87b279dadb85fea3be08627390aca2e5114d5d89fcdfe2f375c1afc4515c0ce9.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6152fcb8afab6c502e0580d9d553dfdd081ef8906240cc34f7ccc084866a2afb | bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9 | local\-file | 2026\-11\-18T04:58:57\.427Z | 0 full elapsed days | [evidence/bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9\.txt](evidence/bf466020c6f76c0b1bf0ec3350b412eb0c617f677033483982dcf5015ece54a9.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
