import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

base = Path('audit-artifacts')
snapshots = {Path(s['locator']).name[:2]: s for s in map(json.loads,(base/'collected/evidence.jsonl').read_text().splitlines())}
now = datetime.now(timezone.utc).isoformat()
digest = lambda s: hashlib.sha256(s.encode()).hexdigest()
bundle = dict(artifacts={}, evidence=[], reviews=[], findings=[])
def save(name, value):
    (base/name).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
def source(key, first, last):
    return '\n'.join(snapshots[key]['value'].splitlines()[first-1:last])
def attach(key, kind, value, locator):
    snap = snapshots[key]
    eid = key+'-'+kind
    artifact = 'evidence/'+eid+'.txt'
    bundle['artifacts'][artifact] = value
    bundle['evidence'].append(dict(snap, evidenceId=eid, kind=kind, artifact=artifact, value=value,
        snapshotHash=digest(value), byteLength=len(value.encode()), collectedAt=now,
        locator=locator, limitations=['Synthetic dossier material supplied for offline comparison only.'],
        sourceEvidenceIds=[snap['evidenceId']]))
    return eid
ids = {}
for key, (first,last) in {'01':(3,14),'02':(3,16),'03':(3,5),'04':(3,18)}.items():
    snap = snapshots[key]
    filename = Path(snap['locator']).name
    ids[key] = {'content': snap['evidenceId']}
    ids[key]['claim-sources'] = attach(key,'claim-sources',source(key,first,last),f'{filename}:{first}-{last}')
    ids[key]['extracted-text'] = attach(key,'extracted-text',snap['value'],filename)
for key, kind, first, last in [
    ('01','entity-record',3,14), ('03','entity-record',3,5),
    ('03','inventory-map',3,19), ('04','question-set',8,13)]:
    ids[key][kind] = attach(key,kind,source(key,first,last),f"{Path(snapshots[key]['locator']).name}:{first}-{last}")
rules = {r['ruleId']:r for r in json.loads(Path('.agents/skills/content-search-audit/rules/core.json').read_text())['rules']}
def check(key, rule, status, reason):
    bundle['reviews'].append(dict(itemId=snapshots[key]['itemId'], ruleId=rule, status=status, reason=reason,
        evidenceIds=[ids[key][kind] for kind in rules[rule]['requiredEvidence']], reviewer='Offline dossier reviewer', reviewedAt=now))
c = 'quality-claims'
a = 'aeo-answer-evidence'
e = 'aio-entity-consistency'
p = 'portfolio-contradictions'
findings = [
    ('F1','01',[c,a,e],'Fir SSO denial conflicts with the supplied Enterprise documentation',
     'Replace the blanket denial with Enterprise SAML SSO availability and its 20-paid-seat minimum. Leave other plans unspecified.',
     'Compare the full revised assertion with the November 2026 US SSO excerpt and confirm the minimum and plan qualifier.'),
    ('F2','01',[c,a,e],'Cedar price advantage reverses on annual billing',
     'Compare monthly and annual billing separately using November 2026 US pretax USD per-seat rates and label annual amounts as monthly equivalents billed annually.',
     'Recompute each billing comparison using the same cadence. Confirm the monthly caption still states USD 3 less and that Fir is USD 1 less on annual billing.'),
    ('F3','02',[c],'Full-month cost per conversion uses a partial-month denominator',
     'Use the existing October 1–7 caption. Leave October 1–31 cost per conversion unavailable until aligned conversion coverage exists.',
     'Check both inputs cover October 1–7, compute USD 700 divided by 35, and require full matched coverage before reporting a monthly ratio.'),
    ('F4','02',[c],'Identified referrals do not support the tenfold estimate',
     'Report 15 October sessions with an identified AI-assistant referrer. Remove the tracking fraction and inferred total.',
     'Reconcile 15 with the independent referral report and confirm unknown origins stay unknown and campaign conversions stay separate.'),
    ('F5','03',[c,a,e,p],'South service page repeats the North same-day policy',
     'Replace the current South promise with next-business-day delivery only. Retain the North policy and the 2024 archive.',
     'Compare the entire South policy passage with the approved South record, confirm the North cutoff is unchanged and confirm the archive still labels 2024 and links to current pages.'),
    ('F6','04',[c,a],'The universal ten-minute setup guarantee lacks support',
     'Remove the guarantee. If retaining a timing claim, state the supplied study median of 15 minutes across 20 observed onboarding sessions.',
     'Check the revised claim identifies the study sample and median and contains no unsupported ceiling, guarantee, refund implication or population generalization.')
]
for fid,key,ruleids,title,action,verification in findings:
    kinds = sorted({k for r in ruleids for k in rules[r]['requiredEvidence']})
    bundle['findings'].append(dict(findingId=fid,title=title,affectedItemIds=[snapshots[key]['itemId']],
        ruleIds=ruleids,dimensions=sorted({rules[r]['dimension'] for r in ruleids}),
        evidenceIds=[ids[key][k] for k in kinds],severity='medium',confidence='high',classification='observed',
        remediation=action,verification=verification,ownerRole='Reporting owner' if key=='02' else 'Content owner',
        effort='small'))
for key, ruleids, reason in [
    ('01',[c,a,e],'Both draft comparison assertions conflict with supplied November US records. The separate monthly-only caption is supported.'),
    ('02',[c],'Both draft calculations make unsupported claims. The aligned first-week caption and descriptive independent referral count are supported.'),
    ('03',[c,a,e,p],'The South current service promise contradicts the approved region-specific policy. North and the dated archive are supported within their roles.'),
    ('04',[c,a],'The landing-page timing promise is a material answer about setup duration and exceeds the approved study. The permissions answer is supported and the reference task is owner-attested.')]:
    for rule in ruleids:
        check(key,rule,'fail',reason)
check('03','portfolio-duplication','pass','The complete declared three-page set serves distinct regional or historical tasks. The repeated wrong South policy is tracked as a contradiction.')
check('04','aeo-question-coverage','pass','The only supplied question asks who may delete a workspace. The complete permissions FAQ answers it. Broader answer evidence is assessed separately.')
check('04','aeo-answer-context','pass','The complete permissions answer states both the excluded editor role and the permitted owner role. The owner record says no additional conditions apply.')
save('review.json',bundle)
def study(key, sid, first, last, scope, limitations):
    s = snapshots[key]['value']
    return dict(sourceId=sid,kind='historical-study',locator=Path(snapshots[key]['locator']).name,
        sourceText=s,sourceHash=digest(s),synthetic=True,scope=scope,limitations=limitations,
        passages=[dict(startLine=first,endLine=last,quote=source(key,first,last))])
save('measurements.json',dict(studySources=[
    study('02','october-campaign',3,8,'One campaign in USD, October 2026. Spend covers October 1–31 and conversion rows cover October 1–7.', ['Conversion data unavailable October 8–31.']),
    study('02','october-ai-referral',14,16,'Independent October 2026 referral report.', ['Unknown origins, no complete session count or conversion linkage, and no measurement of untracked influence.']),
    study('04','onboarding-study',3,5,'20 observed onboarding sessions. Study date, locale and interface unspecified.', ['Median only. No detailed distribution or broader population estimate.'])
]))
assert Decimal(700)/35 == 20
assert round(Decimal(3000)/35,2) == Decimal('85.71')
assert 15-12 == 3 and 10-9 == 1
