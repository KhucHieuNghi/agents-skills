import hashlib
import json
import re
from pathlib import Path
report = Path('report.md')
hash_file = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
quotes = []
for report_line, line in enumerate(report.read_text().splitlines(), 1):
    m = re.fullmatch(r'- `(\d\d-[^:`]+):(\d+)(?:-(\d+))?` — “(.+)”', line)
    if not m:
        assert '“' not in line
        continue
    name, first, last, quote = m.groups()
    source = Path('targets') / name
    first, last = int(first), int(last or first)
    span = source.read_text().splitlines()[first-1:last]
    assert quote in ' '.join(' '.join(span).split()), (name, first, last, quote)
    quotes.append(dict(quoteId=f'Q{len(quotes)+1}', source=str(source), sourceLabel=name,
        sourceHash=hash_file(source), startLine=first, endLine=last, reportStartLine=report_line,
        reportEndLine=report_line, normalization='whitespace', quote=quote))
assert len(quotes) == 12
Path('audit-artifacts/quotes.json').write_text(json.dumps(dict(root=str(Path.cwd()),
    report=str(report), reportHash=hash_file(report), quotes=quotes), ensure_ascii=False, indent=2))
