# Content search audit — four synthetic dossiers

**Status: partial.** 4 declared items; 0 fully audited; 4 pending. 6 material findings; 7 clean components. Every organization, price, policy and metric is invented test data (`targets/context.md:3-4`); nothing here describes live behavior.

## 1. Delivery summary

- **Scope audited:** the four numbered dossiers in `targets/`, each treated as a separate scenario. `targets/context.md` was read in full and used as scope instructions; it is not an inventory item.
- **Coverage (from validated `coverage.json`):** declared 4 · in scope 4 · fully audited 0 · pending 4 · failed 0 · blocked 0 · unsupported 0 · excluded 0 · discovery queue 0. Validator result: `valid: true`, `completionAllowed: false`.
- **Checks:** 104 planned (26 rules × 4 items); 14 resolved (10 fail, 4 pass); 90 unknown. All four files were read completely, but reading is not auditing: every item still has unresolved required checks, so none counts as fully audited.
- **Findings:** 6 material findings, all observed and persisted: dossier 01 has 2, dossier 02 has 2, dossier 03 has 1, dossier 04 has 1.
- **Clean components:** 7 (listed in section 4).
- **Measurements:** 2 supplied synthetic aggregates are attached as historical study sources (dossier 02 rows, dossier 04 study). No AI response observations, Search Console, GA4, Bing or server-log exports exist. Missing measurements are unknown, not zero.
- **This is not a campaign run** and no completed-coverage claim is made. No overall SEO/GEO score, ranking forecast or uplift estimate is given.
- **Nothing was changed, fetched or published.** All actions below are proposals for the content owner.

Terminology: "AIO" here means AI search optimization generally, not the Google product named AI Overviews. No target AI surface was named in the scope.

## 2. Inventory accounting

| Dossier | Item ID (prefix) | State | Resolved checks | Findings | Clean components |
| --- | --- | --- | --- | --- | --- |
| `01-competitor-claims.md` | `f8d829bd34ae` | pending | 4 of 26 (3 fail, 1 pass) | F1, F2 | 1 |
| `02-measurement-windows.md` | `c1ed448701d6` | pending | 2 of 26 (1 fail, 1 pass) | F3, F4 | 1 |
| `03-template-service-area.md` | `ebd17e4dfe3f` | pending | 4 of 26 (3 fail, 1 pass) | F5 | 3 |
| `04-editorial-proof.md` | `3a07dd03e991` | pending | 4 of 26 (3 fail, 1 pass) | F6 | 2 |

Each dossier is one aggregate inventory item describing several pages or drafts. The pages themselves (for example `/compare`, `/south-delivery`, `/status-codes`) were not supplied as separate files, so they are reported as components and not counted as extra items. The single pass per item is the deterministic non-empty-text check, which is not a quality verdict.

## 3. Material findings

All six are classed observed, high severity, high confidence, small effort. Severity reflects that each is a customer-facing or decision-relevant claim contradicted or unsupported by the owner's own supplied record. Suggested order: F5 and F6 (service promise and guarantee), then F1 and F2 (competitor claims), then F3 and F4 (reporting drafts).

### F1 — Draft `/compare` assertion A denies Fir SSO against the supplied Fir documentation

Scenario: dossier 01 (November 2026 US plans). Component: draft `/compare`. Dimensions: content quality, AEO, AIO (one issue).

Observation:

> 01-competitor-claims.md:17 — A. "Fir has no SSO, as its pricing table proves."

> 01-competitor-claims.md:12-14 — Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: "SAML SSO is available on Enterprise, with a minimum of 20 paid seats." No SSO statement is supplied for Fir's other plans.

Rationale: the supplied Fir SSO documentation directly contradicts "has no SSO". The stated proof also fails on its own terms: a pricing excerpt that does not mention a feature does not establish the feature is absent. SSO on Fir's non-Enterprise plans is unknown, not absent.

Proposed action: replace assertion A with a statement limited to the record, for example that per the supplied current Fir SSO documentation, SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats. Make no claim about Fir's other plans and do not cite the pricing table as proof of absence.

Verification: compare the revised sentence with `01-competitor-claims.md:12-14`. It must not deny Fir SSO, must keep the Enterprise and 20-paid-seat conditions, and must say nothing about other Fir plans.

### F2 — Draft `/compare` assertion B says Cedar is cheaper on every billing option; the annual figures show Fir lower

Scenario: dossier 01. Component: draft `/compare`. Dimensions: content quality, AEO, AIO (one issue).

Observation:

> 01-competitor-claims.md:18 — B. "Cedar is cheaper per seat than Fir on every billing option."

> 01-competitor-claims.md:6-9 — Our Cedar plan: USD 12 per seat per month, billed monthly, no seat minimum. Our annual option: USD 10 per seat per month equivalent, billed annually. Competitor Fir monthly option: USD 15 per seat per month, billed monthly. Fir annual option: USD 9 per seat per month equivalent, billed annually.

Rationale: on monthly billing Cedar is lower (12 vs 15). On annual billing Fir is lower by USD 1 per seat per month equivalent (9 vs 10). "Every billing option" is therefore false for one of the two supplied options.

Proposed action: either restrict the claim to monthly billing (the `/monthly-comparison` caption already does this correctly) or state both options with their figures and scope: November 2026 US plans, USD before tax, per seat per month.

Verification: recompute each billing option in the revised text against `01-competitor-claims.md:6-9`. No sentence may state or imply Cedar is cheaper on annual billing.

### F3 — Draft A labels a mixed-window ratio as October cost per conversion

Scenario: dossier 02 (one campaign, USD, October 2026). Component: Draft A. Dimension: content quality (reporting accuracy).

Observation:

> 02-measurement-windows.md:10 — Draft A: "October cost per conversion was USD 85.71, from 3000 divided by 35."

> 02-measurement-windows.md:5-7 — Spend is complete for October 1–31: USD 3000. Conversion export covers only October 1–7: 35 completed conversions. No conversion data exists for October 8–31.

Rationale: the division is arithmetically right (3000 / 35 = 85.71) but the numerator covers 31 days and the denominator 7 days. The result is not a cost per conversion for October or for any single window. Conversions for October 8–31 are unmeasured, so the true full-month figure is unknown; it must not be assumed that those days had zero conversions.

Proposed action: withdraw Draft A's figure. Report the matched window already in the verified-window caption (October 1–7: USD 700 / 35 = USD 20) and say October 8–31 is unmeasured. Hold any full-month figure until conversion data for October 8–31 is supplied.

Verification: confirm numerator and denominator of any revised statement cover the same dates per `02-measurement-windows.md:5-8`, and that October 8–31 is described as unmeasured, not zero.

### F4 — Draft B extrapolates 15 tracked sessions to 150 using an unsupplied tracking rate

Scenario: dossier 02, independent referral report (separate from the campaign). Component: Draft B. Dimensions: content quality, GEO (one issue).

Observation:

> 02-measurement-windows.md:17-18 — Draft B: "These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked."

> 02-measurement-windows.md:14-16 — Independent referral report: 15 October sessions have an identified AI-assistant referrer. Other sessions have unknown origin. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.

Rationale: the count of 15 identified-referrer sessions is supported. The one-in-ten rate, the total of 150 and the words "prove" and "generated" have no supplied basis: the record states that no estimating model, incrementality test or complete session count exists. Unknown-origin sessions are unknown, neither AI-driven nor not.

Proposed action: replace Draft B with the observed count only: 15 October sessions had an identified AI-assistant referrer; the origin of other sessions is unknown. Remove the total, the rate and the causal wording. Keep this report separate from campaign conversions, as the dossier requires.

Verification: check the revised sentence against `02-measurement-windows.md:14-16`. It should state only the 15 sessions, with no total, rate, causal or conversion claim.

### F5 — `/south-delivery` promises same-day delivery; approved policy for South is next-business-day only

Scenario: dossier 03 (declared complete inventory of three pages). Component: `/south-delivery`. Dimensions: content quality, AEO, AIO, with a portfolio cause (one issue).

Observation:

> 03-template-service-area.md:10-11 — /south-delivery: "South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."

> 03-template-service-area.md:4-5 — Current approved policy: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.

Rationale: the South page states a service the approved policy does not offer. Its passage is word-for-word the North passage at `03-template-service-area.md:8-9` with only the region name changed (compared directly). Interpretation: this is consistent with the North policy text being carried over with the shared template, though the dossier does not state how it happened. The defect is the wrong policy text; the shared layout itself is intentional and is not a finding.

Proposed action: replace the `/south-delivery` policy passage with the approved South policy, next-business-day delivery only. The approved policy gives no order cut-off or service days for South, so add none unless the owner supplies them. Keep both regional pages; leave `/north-delivery` and `/terms-v1` unchanged.

Verification: compare the revised `/south-delivery` passage with `03-template-service-area.md:4-5`, and re-read `/north-delivery` to confirm it is unchanged. Live serving and index state remain unverified.

### F6 — Draft landing-page claim guarantees 10-minute setup for every team

Scenario: dossier 04. Component: draft landing-page claim. Dimensions: content quality, AEO, AIO (one issue).

Observation:

> 04-editorial-proof.md:6 — Draft landing-page claim: "Every team is guaranteed to finish setup in 10 minutes."

> 04-editorial-proof.md:3-5 — Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.

Rationale: three parts of the claim exceed the record. "Guaranteed" has no supplied guarantee. "Every team" is universal, while the record covers 20 observed sessions with no wider population estimate. "10 minutes" is below the only supplied statistic. If onboarding completion time measures the same setup the claim describes, a 15-minute median also means some observed sessions took at least 15 minutes, which contradicts the claim for the observed sample. What the median does not tell us: the maximum, how many sessions finished within 10 minutes, or anything about teams outside the study.

Proposed action: remove "every team", "guaranteed" and "10 minutes". If a time statement is wanted, state the result with its scope: in a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes. Add no maximum, typical range or guarantee.

Verification: compare the revised claim with `04-editorial-proof.md:3-5`: statistic (median), value (15 minutes) and sample (20 observed sessions) must match, with no guarantee, maximum or universal wording.

## 4. Clean components (no action proposed)

1. **Dossier 01, `/monthly-comparison` caption.** Supported and correctly scoped: 15 − 12 = 3, monthly plans only, before tax.

   > 01-competitor-claims.md:21 — "On the supplied monthly plans, Cedar is USD 3 less per seat per month before tax."

   The owner's stated intent (`01-competitor-claims.md:22-23`) is monthly billing only, with no total-cost, feature-equivalence or superiority claim, and the caption makes none. No extra disclaimer is needed.

2. **Dossier 02, verified-window caption.** Numerator and denominator share one window (700 / 35 = 20) and the gap is disclosed.

   > 02-measurement-windows.md:11-12 — Separate verified-window caption: "For October 1–7, observed cost per completed conversion was USD 20 (700 divided by 35). The rest of the month is unmeasured."

3. **Dossier 03, `/north-delivery`.** Matches the approved North policy at `03-template-service-area.md:4-5`.

   > 03-template-service-area.md:8-9 — /north-delivery: "North: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."

4. **Dossier 03, `/terms-v1` archive.** Keep as is. Its statement that South had same-day service describes the 2024 contract and is not a current-policy conflict.

   > 03-template-service-area.md:13-16 — Owner confirms /terms-v1 is a clearly labeled 2024 archive kept for old orders. It accurately describes the 2024 service contract, when South had same-day service. It links to the two current pages for new orders. No mixed-version customer task or misleading current-policy label is present.

   Basis: owner attestation. The archive's own text was not supplied, so this is clean on the record given, not independently inspected. It links to `/south-delivery`, so F5 affects readers arriving from the archive until fixed; the archive itself needs no change.

5. **Dossier 03, keeping two regional pages with a shared layout.** No duplication or cannibalization finding. The pages serve different regions and no overlap data exists.

   > 03-template-service-area.md:18-20 — The two current pages serve different regions and the owner wants both retained. Shared layout and repeated generic contact wording are intentional. No ranking, query/page overlap, backlink, conversion or search-engine selection data exists.

6. **Dossier 04, permissions FAQ.** The answer is direct, complete for its question and matches the approved policy at `04-editorial-proof.md:10-13`. No procedure or extra conditions are needed, because the task is identifying the permitted role.

   > 04-editorial-proof.md:9 — "Can editors delete the workspace? No. Only workspace owners can delete it."

7. **Dossier 04, `/status-codes` reference page.** No finding on terse style, punctuation, missing purchase CTA or authorship.

   > 04-editorial-proof.md:15-18 — Separate reference page /status-codes has a complete, accurate table for its declared technical task. Its terse language, punctuation and lack of a purchase CTA are approved by the documentation owner. No authorship evidence, readability failure, acquisition objective or user task failure was supplied for this page.

   Basis: owner attestation. The table itself was not supplied, so its accuracy was not independently checked.

## 5. Uncertain and unresolved points (not findings)

- **Dossier 01:** which Fir plan the Fir prices belong to is not stated; SSO on Fir's non-Enterprise plans is unknown; total cost and feature equivalence are not compared. The rest of the `/compare` draft beyond assertions A and B was not supplied. Records are scoped to November 2026, US, USD before tax (`01-competitor-claims.md:3`); any revised claim should carry that scope. Fir records are owner-supplied excerpts, not independently verified.
- **Dossier 02:** full-October cost per conversion, total sessions and total AI-assisted sessions are unknown. The referral report and the campaign conversions must stay separate.

  > 02-measurement-windows.md:20-21 — Do not combine the campaign conversion counts with the independent referral report. No citation annotations or generated answer captures are supplied.

- **Dossier 03:** South's order cut-off and service days are not in the approved policy. Only the policy passages were supplied, so titles, metadata, canonicals, internal links and the generic contact wording are unreviewed. The archive's links are owner-stated, not captured.
- **Dossier 04:** the session-time distribution, the maximum, and whether sessions map one-to-one to teams are unknown. Collection dates for the study are not stated.

## 6. Dimension coverage by dossier

| Dimension | 01 | 02 | 03 | 04 |
| --- | --- | --- | --- | --- |
| Content quality | Claims fail (F1, F2); caption clean | Claims fail (F3, F4); caption clean | Claims fail (F5); North and archive clean | Claims fail (F6); FAQ and reference clean |
| SEO | Unknown | Unknown | Unknown | Unknown |
| AIO | Entity consistency fail (F1, F2) | Unknown | Entity consistency fail (F5) | Entity consistency fail (F6) |
| AEO | Answer evidence fail (F1, F2) | Unknown | Answer evidence fail (F5) | Answer evidence fail (F6); FAQ answer clean |
| GEO | Unmeasured | Unmeasured; F4 concerns a visibility claim | Unmeasured | Unmeasured |
| Portfolio | Unknown | Unknown | Unknown at check level; components 4 and 5 clean | Unknown |

Why the unknowns remain:

- **SEO (32 checks):** no HTTP responses, raw HTML, rendered DOM, metadata, canonical, robots, structured data, locale map or link graph were supplied.
- **AIO (9 checks):** no crawler policy, publisher intent or named target surface. Dossier 02 holds reporting drafts with no entity record to compare.
- **AEO (9 checks):** no question set was supplied, so question coverage and answer context stay unknown everywhere. For dossier 02 it is unclear that the reporting drafts are customer-facing answers, so no AEO verdict was forced.
- **GEO (12 checks):** no AI response captures, citations or mention data. Readiness is not measured visibility.
- **Portfolio (16 checks):** no question set, query/page data or link graph; full page text is absent. Dossier 03's inventory is declared complete, which supports the component observations but not item-wide verdicts.
- **Content quality (12 checks):** task fit lacks audience evidence, media checks lack a media inventory, and freshness was left unknown because the drafts' surrounding page text and dates were not supplied.

## 7. Measurements and missing data

Supplied (synthetic, attached to the generated report as historical study sources with exact passages):

- Dossier 02: October 2026 spend USD 3000 (October 1–31); USD 700 and 35 completed conversions (October 1–7); 15 October sessions with an identified AI-assistant referrer.
- Dossier 04: median completion time of 15 minutes across 20 observed onboarding sessions.

These are owner-supplied counts, not connector responses, and are not brand visibility results.

Not supplied, and therefore unknown: live account data, engine output, AI answer captures, citation annotations, rankings, keyword volume, index status, backlinks, Search Console, GA4, Bing and server-log exports; conversions for October 8–31; complete session counts; session-level study data.

Measurement plan, for the owner to decide (nothing was set up):

1. Dossier 02: obtain the conversion export for October 8–31 before reporting any full-month cost per conversion.
2. Dossier 02: to estimate untracked AI influence, a complete session count and a documented estimation method or incrementality test would be needed first.
3. GEO: to measure visibility, name the target surfaces and markets, then capture dated responses for a versioned prompt set with explicit denominators.
4. Dossier 04: to support any time claim beyond the median, supply the session-level distribution and the study's dates and population.

## 8. Coverage limits and recovery path

- Offline only. No URLs were fetched and no rendered pages, accounts or credentials were used, as the scope requires.
- The dossiers summarize pages; most page text was not supplied. Component verdicts rest on the quoted passages and owner statements.
- Item-level checks were kept conservative: a clean component does not pass a whole dossier, and no check was marked not-applicable merely because data was missing.
- To move items from pending to audited, supply per page: full text, HTTP and HTML captures, metadata and canonical data, link graph, audience and question evidence, crawler policy and intent, and AI observations where GEO matters.
- Helper note: the standalone review step renders its report before measurements can be attached, so the final edition was produced by copying the validated review artifacts unchanged into a separate output revision and rendering it with the two study sources. It validates with the same coverage.

## 9. Artifacts

- Final validated run: `audits/content-search/run-20261118/final/` (generated `report.md`, `report.html`, `coverage.json`, `content-actions.csv`, `delivery-summary.md`, `findings.json`, `study-evidence.json`). Run ID `e5000384-3c13-48f4-9271-f924b5c3b1f2`.
- Earlier revisions kept for history: `initial/` (collection) and `reviewed/` (review without study attachments).
- Working files and receipts: `audits/content-search/run-20261118/work/` (`config.json`, `review.json`, `validation.json`, `report-options.json`, `quotes.json`, `quote-receipt.json`).
- Quotation check: every block quotation in this report is in the quote ledger and was verified against its source file and cited lines; see `quote-receipt.json`. The receipt confirms text and locators only, not the correctness of the judgments.
