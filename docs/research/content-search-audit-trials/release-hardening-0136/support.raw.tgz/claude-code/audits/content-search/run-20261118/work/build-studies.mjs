import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const [targets, out] = process.argv.slice(2);
const src = (file, sourceId, scope, ranges, limitations) => {
  const sourceText = readFileSync(`${targets}/${file}`, "utf8");
  const l = sourceText.split(/\r?\n/);
  return { sourceId, kind: "historical-study", locator: `targets/${file}`, sourceText,
    sourceHash: createHash("sha256").update(sourceText).digest("hex"), synthetic: true, scope, limitations,
    passages: ranges.map(([a, b]) => ({ startLine: a, endLine: b, quote: l.slice(a - 1, b).join("\n") })) };
};
writeFileSync(out, JSON.stringify({ studySources: [
  src("02-measurement-windows.md", "dossier-02-supplied-rows",
    "Synthetic owner-supplied counts: one campaign, USD, October 2026 reporting window; spend Oct 1-31, conversions Oct 1-7 only; separate independent referral report of October sessions with identified AI-assistant referrer. Interface, locale and collection method not stated.",
    [[3, 8], [14, 16]],
    ["Synthetic fixture counts, not a live connector response", "Conversions for October 8-31 are unmeasured, not zero", "Referral report has no complete session count, incrementality test, untracked-influence model or conversion linkage; it must not be combined with campaign conversions", "Referral sessions are not AI answer mentions or citations; no generated answer captures exist"]),
  src("04-editorial-proof.md", "dossier-04-onboarding-study",
    "Synthetic owner-supplied study aggregate: 20 observed onboarding sessions, median completion time 15 minutes. Collection window, population, product version and locale not stated.",
    [[3, 5]],
    ["Synthetic fixture aggregate; no session-level data supplied", "No maximum, guarantee, refund policy, percentile distribution or wider population estimate supplied; a median does not establish a distribution, maximum or guarantee", "Sessions are not shown to correspond one-to-one with teams"]),
] }, null, 2) + "\n");
