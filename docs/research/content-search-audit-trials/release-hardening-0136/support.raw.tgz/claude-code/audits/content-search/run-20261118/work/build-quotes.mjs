import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const [root, out] = process.argv.slice(2);
const hash = (b) => createHash("sha256").update(b).digest("hex");
const reportBytes = readFileSync(`${root}/report.md`);
const lines = reportBytes.toString("utf8").split("\n");
const quotes = [];
const re = /^\s*> (0\d-[a-z-]+\.md):(\d+)(?:-(\d+))? — (.+)$/;
lines.forEach((line, i) => {
  const m = line.match(re);
  if (!m) return;
  const [, file, s, e, quote] = m;
  quotes.push({ quoteId: `q${quotes.length + 1}-${file.slice(0, 2)}-${s}`, source: `targets/${file}`, sourceLabel: file,
    sourceHash: hash(readFileSync(`${root}/targets/${file}`)), startLine: +s, endLine: +(e || s),
    reportStartLine: i + 1, reportEndLine: i + 1, normalization: "whitespace", quote });
});
const blockLines = lines.filter((l) => /^\s*> /.test(l)).length;
writeFileSync(out, JSON.stringify({ root, report: "report.md", reportHash: hash(reportBytes), quotes }, null, 2) + "\n");
console.log(JSON.stringify({ ledgerQuotes: quotes.length, blockquoteLines: blockLines }));
