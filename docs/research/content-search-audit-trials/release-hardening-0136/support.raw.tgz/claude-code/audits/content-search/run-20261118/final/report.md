# Content audit — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 2; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:04:58\.469Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run e5000384\-3c13\-48f4\-9271\-f924b5c3b1f2\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1\-fir\-sso | Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: replace assertion A with a statement limited to the supplied record, e\.g\. that per the supplied current Fir SSO documentation SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats\. Do not assert anything about SSO on Fir&\#39;s other plans, and do not cite the pricing table as proof of absence\. | Compare the revised sentence with 01\-competitor\-claims\.md:12\-14: it must not deny Fir SSO, must keep the Enterprise and 20\-paid\-seat conditions, and must make no claim about other Fir plans\. | Content owner with product marketing/legal review | small | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b, d01\-claims, d01\-entity |
| F2\-every\-billing\-option | Draft /compare assertion B claims Cedar is cheaper on every billing option; the supplied annual figures show Fir lower | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: restrict the claim to monthly billing \(the existing /monthly\-comparison caption already does this correctly\) or state both options: monthly Cedar USD 12 vs Fir USD 15; annual Cedar USD 10 vs Fir USD 9 per seat per month equivalent, November 2026 US plans, USD before tax\. | Recompute each billing option in the revised text against 01\-competitor\-claims\.md:6\-9; no sentence may state or imply Cedar is cheaper on annual billing\. | Content owner with product marketing/legal review | small | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b, d01\-claims, d01\-entity |
| F3\-october\-cpc\-window | Draft A labels a mixed\-window ratio as October cost per conversion | quality\-claims | quality | high | high | observed | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: withdraw Draft A&\#39;s October figure\. Report the matched window already stated in the verified\-window caption \(October 1\-7: USD 700 / 35 = USD 20\) and state that October 8\-31 conversions are unmeasured\. Do not present a full\-month figure until conversion data for October 8\-31 is supplied\. | Confirm numerator and denominator in any revised statement cover the same dates \(02\-measurement\-windows\.md:5\-8\) and that October 8\-31 is described as unmeasured, not zero\. | Analytics/reporting owner | small | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6, d02\-claims |
| F4\-ai\-sessions\-extrapolation | Draft B extrapolates 15 tracked AI\-referrer sessions to 150 with an unsupplied tracking rate and causal wording | quality\-claims, geo\-observed\-presence | quality, geo | high | high | observed | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: replace Draft B with the observed count: 15 October sessions had an identified AI\-assistant referrer; origin of other sessions is unknown\. Remove 150, the one\-in\-ten rate and &\#39;prove&\#39;/&\#39;generated&\#39;\. Keep this report separate from campaign conversions\. | Check the revised sentence against 02\-measurement\-windows\.md:14\-16: only the count of 15 identified\-referrer sessions is stated, with no total, rate, causal or conversion claim\. | Analytics/reporting owner | small | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6, d02\-claims |
| F5\-south\-same\-day | /south\-delivery promises same\-day delivery; approved policy for South is next\-business\-day only | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: replace the /south\-delivery policy passage with the approved South policy \(next\-business\-day delivery only\)\. Do not add order cut\-offs or service days for South unless the owner supplies them\. Keep /north\-delivery and /terms\-v1 unchanged and keep both regional pages\. | Compare the revised /south\-delivery passage with 03\-template\-service\-area\.md:4\-5; re\-read /north\-delivery to confirm it is unchanged\. Live serving and index state remain unverified\. | Content owner / operations policy owner | small | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c, d03\-claims, d03\-entity |
| F6\-setup\-guarantee | Draft landing\-page claim guarantees 10\-minute setup for every team; the record supports only a 15\-minute median over 20 sessions | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | update | reviewer\-proposal | Supplied owner record contradicts or does not support the quoted draft claim | Proposal only: remove &\#39;every team&\#39;, &\#39;guaranteed&\#39; and &\#39;10 minutes&\#39;\. If a time statement is wanted, state the supplied result with its scope: in a supplied study of 20 observed onboarding sessions the median completion time was 15 minutes\. Do not add a maximum, typical range or guarantee\. | Compare the revised claim with 04\-editorial\-proof\.md:3\-5: statistic \(median\), value \(15 minutes\), sample \(20 observed sessions\) match, and no guarantee, maximum or universal wording remains\. | Content owner with product/legal review | small | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828, d04\-claims, d04\-entity |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 3 | 9 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Supplied historical measurement evidence

Historical study sources are attached below\. Their quoted measurements are not current brand observations\. Hashes and exact passages bind supplied bytes, not authenticity, sampling validity or semantic interpretation\. No response\-level observations or performance forecasts are manufactured from aggregates\.

## Historical study source

| Field | Value |
| --- | --- |
| Source | dossier\-02\-supplied\-rows |
| Kind | historical\-study |
| Locator | targets/02\-measurement\-windows\.md |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Synthetic owner\-supplied counts: one campaign, USD, October 2026 reporting window; spend Oct 1\-31, conversions Oct 1\-7 only; separate independent referral report of October sessions with identified AI\-assistant referrer\. Interface, locale and collection method not stated\. |
| Source SHA\-256 | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 |
| Limitations | Synthetic fixture counts, not a live connector response; Conversions for October 8\-31 are unmeasured, not zero; Referral report has no complete session count, incrementality test, untracked\-influence model or conversion linkage; it must not be combined with campaign conversions; Referral sessions are not AI answer mentions or citations; no generated answer captures exist |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| dossier\-02\-supplied\-rows | 3–8 | Scope: one campaign, one currency \(USD\), completed October 2026 reporting window\. All figures are synthetic owner\-supplied counts, not a live connector response\. Spend is complete for October 1–31: USD 3000\. Conversion export covers only October 1–7: 35 completed conversions\. No conversion data exists for October 8–31\. The same spend export gives October 1–7 spend of USD 700\. |
| dossier\-02\-supplied\-rows | 14–16 | Independent referral report: 15 October sessions have an identified AI\-assistant referrer\. Other sessions have unknown origin\. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists\. |

## Historical study source

| Field | Value |
| --- | --- |
| Source | dossier\-04\-onboarding\-study |
| Kind | historical\-study |
| Locator | targets/04\-editorial\-proof\.md |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Synthetic owner\-supplied study aggregate: 20 observed onboarding sessions, median completion time 15 minutes\. Collection window, population, product version and locale not stated\. |
| Source SHA\-256 | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 |
| Limitations | Synthetic fixture aggregate; no session\-level data supplied; No maximum, guarantee, refund policy, percentile distribution or wider population estimate supplied; a median does not establish a distribution, maximum or guarantee; Sessions are not shown to correspond one\-to\-one with teams |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| dossier\-04\-onboarding\-study | 3–5 | Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes\. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate\. |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | pending | Snapshot review incomplete | 26 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | pending | Snapshot review incomplete | 26 |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | pending | Snapshot review incomplete | 26 |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-claims | quality | fail | The draft landing\-page claim \(line 6\) asserts a universal 10\-minute guarantee; the approved record \(lines 3\-5\) supplies only a 15\-minute median for 20 observed sessions and no guarantee or maximum\. The permissions FAQ \(line 9\) and /status\-codes \(lines 15\-18\) are supported and stay clean\. | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828, d04\-claims |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d04\-text |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-entity\-consistency | aio | fail | The landing claim&\#39;s setup\-time fact \(guaranteed 10 minutes, every team\) is inconsistent with the approved product record \(median 15 minutes, 20 sessions, no guarantee\)\. | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828, d04\-entity |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-answer\-evidence | aeo | fail | The landing\-page setup\-time promise is a material product answer without source support\. The separate permissions FAQ answer is fully supported by the approved policy; that clean result does not extend to the landing claim\. | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828, d04\-claims |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-claims | quality | fail | Draft A \(line 10\) divides full\-month spend \(Oct 1\-31\) by conversions measured only for Oct 1\-7 and labels it October cost per conversion\. Draft B \(lines 17\-18\) asserts 150 total AI sessions and a one\-in\-ten tracking rate that no supplied record supports\. The verified\-window caption \(lines 11\-12\) is supported \(700 / 35 = 20\) and stays clean\. | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6, d02\-claims |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d02\-text |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-claims | quality | fail | /south\-delivery \(lines 10\-11\) promises same\-day delivery; the current approved policy \(line 5\) gives South next\-business\-day delivery only\. /north\-delivery \(lines 8\-9\) matches policy; /terms\-v1 is an accurately labeled 2024 archive per owner \(lines 13\-16\)\. | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c, d03\-claims |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d03\-text |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-entity\-consistency | aio | fail | The South service fact on /south\-delivery conflicts with the approved service record \(line 5\)\. North is consistent\. | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c, d03\-entity |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-answer\-evidence | aeo | fail | The /south\-delivery policy passage is the page&\#39;s answer to what delivery service South receives and is contradicted by the approved policy\. North and the archive are supported\. | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c, d03\-claims |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-claims | quality | fail | Draft /compare assertions A \(line 17\) and B \(line 18\) are contradicted by the supplied records: Fir SSO docs show SAML SSO on Enterprise \(line 13\), and Fir annual USD 9 is below Cedar annual USD 10 \(lines 7, 9\)\. The separate /monthly\-comparison caption \(line 21\) is supported \(15 \- 12 = 3\) and stays clean\. | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b, d01\-claims |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d01\-text |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-entity\-consistency | aio | fail | Draft /compare states plan price and SSO facts inconsistent with the supplied plan records \(lines 6\-14\)\. Fir records are owner\-supplied excerpts, not independently verified\. | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b, d01\-entity |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-answer\-evidence | aeo | fail | Assertions A and B are the comparison answers of the draft /compare page and lack source support \(see quality\-claims\)\. The monthly caption is a supported, scoped answer\. No question set was supplied; question coverage/context remain unknown\. | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b, d01\-claims |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | local\-file | 2026\-11\-18T05:02:33\.543Z | 0 full elapsed days | [evidence/3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5\.txt](evidence/3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | local\-file | 2026\-11\-18T05:02:33\.544Z | 0 full elapsed days | [evidence/c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3\.txt](evidence/c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | local\-file | 2026\-11\-18T05:02:33\.545Z | 0 full elapsed days | [evidence/ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc\.txt](evidence/ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | local\-file | 2026\-11\-18T05:02:33\.546Z | 0 full elapsed days | [evidence/f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b\.txt](evidence/f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d01\-text | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d01\-text\.txt](evidence/d01-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d02\-text | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d02\-text\.txt](evidence/d02-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d03\-text | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d03\-text\.txt](evidence/d03-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d04\-text | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d04\-text\.txt](evidence/d04-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d01\-claims | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d01\-claims\.txt](evidence/d01-claims.txt) | 4604c00e12fabaa7483e885edfbbda67501e7dc88472561542a507e2eb198124 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d01\-entity | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d01\-entity\.txt](evidence/d01-entity.txt) | c4f7bd63ab898a7a246a08dead0e8a9271b2500ec99ae295bbd9b164579fb6ce | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d02\-claims | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d02\-claims\.txt](evidence/d02-claims.txt) | a9441f5893c594c4058dc79fe8538312a60c13e8c3fc5badba92ea76d7842921 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d03\-claims | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d03\-claims\.txt](evidence/d03-claims.txt) | 2648674b98d9f0a65738d1d0f3abba0d4ceab682b1dcdcc8258b1e43cb608e2a | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d03\-entity | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d03\-entity\.txt](evidence/d03-entity.txt) | d660eb42ecb0ffc7c81ba9de30c3397a1be01ccb18cecc51fc8115afa4b769b6 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d04\-claims | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d04\-claims\.txt](evidence/d04-claims.txt) | 175b756f430d230ca26969f7036fc722d95c43c80a5941f59effc7a7cc24a248 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |
| d04\-entity | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | local\-file | 2026\-11\-18T05:04:36\.845Z | 0 full elapsed days | [evidence/d04\-entity\.txt](evidence/d04-entity.txt) | 4dc664d027e114eaf769fdefb2332b289567bc9a312da69bf4effe1d5ece8b8e | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behavior; Derived by the reviewing host from the collected local snapshot |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
