import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [runDir, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = (f) => readFileSync(path.join(runDir, f), "utf8").trim().split("\n").map((l) => JSON.parse(l));
const inv = lines("inventory.jsonl"), ev = lines("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "claude-agent-host-review";
const item = (n) => inv.find((i) => path.basename(i.path).startsWith(n));
const snap = (it) => ev.find((e) => e.itemId === it.itemId && e.kind === "content");
const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const ids = {};
function add(n, key, kind, locator, value) {
  const it = item(n), s = snap(it);
  const evidenceId = `d${n}-${key}`;
  const artifact = `evidence/${evidenceId}.txt`;
  bundle.artifacts[artifact] = value;
  bundle.evidence.push({ ...s, evidenceId, kind, artifact, value, snapshotHash: hash(value), collectedAt: now, locator,
    sourceEvidenceIds: [s.evidenceId],
    limitations: ["Synthetic owner-supplied comparison record preserved from the dossier; not independently verified live behavior", "Derived by the reviewing host from the collected local snapshot"] });
  ids[evidenceId] = evidenceId;
  return evidenceId;
}
function text(n) {
  const it = item(n), s = snap(it);
  return add(n, "text", "extracted-text", path.basename(it.path), s.value);
}
const C = (n) => snap(item(n)).evidenceId, I = (n) => item(n).itemId;
for (const n of ["01", "02", "03", "04"]) text(n);
const syn = "Synthetic owner-supplied record (targets/context.md:3-7: invented for this test; comparison evidence within this scenario only, not independently verified live behavior). ";
const c01 = add("01", "claims", "claim-sources", "01-competitor-claims.md:3-14", syn + "01-competitor-claims.md:3-14: November 2026 US plans, USD before tax. Cedar USD 12/seat/month billed monthly, no seat minimum; Cedar annual USD 10/seat/month equivalent billed annually; Fir monthly USD 15/seat/month billed monthly; Fir annual USD 9/seat/month equivalent billed annually; figures exclude optional services and none is required. Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: \"SAML SSO is available on Enterprise, with a minimum of 20 paid seats.\" No SSO statement is supplied for Fir's other plans.");
const e01 = add("01", "entity", "entity-record", "01-competitor-claims.md:6-14", syn + "Plan/price/SSO records at 01-competitor-claims.md:6-14 for Cedar and Fir (November 2026, US, USD before tax), as summarised in d01-claims. Fir records are owner-supplied excerpts of a third party's material.");
const c02 = add("02", "claims", "claim-sources", "02-measurement-windows.md:3-8,14-16", syn + "02-measurement-windows.md:3-8: one campaign, USD, October 2026. Spend complete for October 1-31: USD 3000. Conversion export covers only October 1-7: 35 completed conversions. No conversion data exists for October 8-31. October 1-7 spend USD 700. 02-measurement-windows.md:14-16: independent referral report, 15 October sessions with an identified AI-assistant referrer; other sessions unknown origin; no model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.");
const c03 = add("03", "claims", "claim-sources", "03-template-service-area.md:3-5,13-16", syn + "03-template-service-area.md:3-5: declared inventory complete (/north-delivery, /south-delivery, /terms-v1). Current approved policy: North same-day delivery Monday-Friday for orders placed before 10:00 local time; South next-business-day delivery only. 03-template-service-area.md:13-16: /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurate for the 2024 contract when South had same-day service, linking to the two current pages.");
const e03 = add("03", "entity", "entity-record", "03-template-service-area.md:4-5", syn + "Current approved service policy at 03-template-service-area.md:4-5: North same-day Monday-Friday for orders before 10:00 local time; South next-business-day delivery only.");
const c04 = add("04", "claims", "claim-sources", "04-editorial-proof.md:3-5,10-13,15-18", syn + "04-editorial-proof.md:3-5: for 20 observed onboarding sessions in a supplied study the median completion time was 15 minutes; no maximum time, guarantee, refund policy, percentile distribution or wider population estimate is supplied. 04-editorial-proof.md:10-13: approved permissions policy states editors cannot delete a workspace and owners can; no additional conditions. 04-editorial-proof.md:15-18: /status-codes table complete and accurate for its declared technical task; terse style and no CTA approved.");
const e04 = add("04", "entity", "entity-record", "04-editorial-proof.md:3-5", syn + "Approved product record at 04-editorial-proof.md:3-5: median completion time 15 minutes across 20 observed onboarding sessions; no maximum, guarantee, percentile distribution or wider population estimate.");
const rev = (n, ruleId, status, reason, evidenceIds) => bundle.reviews.push({ itemId: I(n), ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
// 01
rev("01", "quality-claims", "fail", "Draft /compare assertions A (line 17) and B (line 18) are contradicted by the supplied records: Fir SSO docs show SAML SSO on Enterprise (line 13), and Fir annual USD 9 is below Cedar annual USD 10 (lines 7, 9). The separate /monthly-comparison caption (line 21) is supported (15 - 12 = 3) and stays clean.", [C("01"), c01]);
rev("01", "aeo-answer-evidence", "fail", "Assertions A and B are the comparison answers of the draft /compare page and lack source support (see quality-claims). The monthly caption is a supported, scoped answer. No question set was supplied; question coverage/context remain unknown.", [C("01"), c01]);
rev("01", "aio-entity-consistency", "fail", "Draft /compare states plan price and SSO facts inconsistent with the supplied plan records (lines 6-14). Fir records are owner-supplied excerpts, not independently verified.", [C("01"), e01]);
// 02
rev("02", "quality-claims", "fail", "Draft A (line 10) divides full-month spend (Oct 1-31) by conversions measured only for Oct 1-7 and labels it October cost per conversion. Draft B (lines 17-18) asserts 150 total AI sessions and a one-in-ten tracking rate that no supplied record supports. The verified-window caption (lines 11-12) is supported (700 / 35 = 20) and stays clean.", [C("02"), c02]);
// 03
rev("03", "quality-claims", "fail", "/south-delivery (lines 10-11) promises same-day delivery; the current approved policy (line 5) gives South next-business-day delivery only. /north-delivery (lines 8-9) matches policy; /terms-v1 is an accurately labeled 2024 archive per owner (lines 13-16).", [C("03"), c03]);
rev("03", "aeo-answer-evidence", "fail", "The /south-delivery policy passage is the page's answer to what delivery service South receives and is contradicted by the approved policy. North and the archive are supported.", [C("03"), c03]);
rev("03", "aio-entity-consistency", "fail", "The South service fact on /south-delivery conflicts with the approved service record (line 5). North is consistent.", [C("03"), e03]);
// 04
rev("04", "quality-claims", "fail", "The draft landing-page claim (line 6) asserts a universal 10-minute guarantee; the approved record (lines 3-5) supplies only a 15-minute median for 20 observed sessions and no guarantee or maximum. The permissions FAQ (line 9) and /status-codes (lines 15-18) are supported and stay clean.", [C("04"), c04]);
rev("04", "aeo-answer-evidence", "fail", "The landing-page setup-time promise is a material product answer without source support. The separate permissions FAQ answer is fully supported by the approved policy; that clean result does not extend to the landing claim.", [C("04"), c04]);
rev("04", "aio-entity-consistency", "fail", "The landing claim's setup-time fact (guaranteed 10 minutes, every team) is inconsistent with the approved product record (median 15 minutes, 20 sessions, no guarantee).", [C("04"), e04]);
const F = (findingId, n, title, ruleIds, dimensions, evidenceIds, severity, remediation, verification, ownerRole, extra = {}) =>
  bundle.findings.push({ findingId, title, affectedItemIds: [I(n)], ruleIds, dimensions, evidenceIds, severity, confidence: "high", classification: "observed", remediation, verification, ownerRole, effort: "small", action: "update", actionReason: "Supplied owner record contradicts or does not support the quoted draft claim", ...extra });
F("F1-fir-sso", "01", "Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation", ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [C("01"), c01, e01], "high",
  "Proposal only: replace assertion A with a statement limited to the supplied record, e.g. that per the supplied current Fir SSO documentation SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats. Do not assert anything about SSO on Fir's other plans, and do not cite the pricing table as proof of absence.",
  "Compare the revised sentence with 01-competitor-claims.md:12-14: it must not deny Fir SSO, must keep the Enterprise and 20-paid-seat conditions, and must make no claim about other Fir plans.", "Content owner with product marketing/legal review");
F("F2-every-billing-option", "01", "Draft /compare assertion B claims Cedar is cheaper on every billing option; the supplied annual figures show Fir lower", ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [C("01"), c01, e01], "high",
  "Proposal only: restrict the claim to monthly billing (the existing /monthly-comparison caption already does this correctly) or state both options: monthly Cedar USD 12 vs Fir USD 15; annual Cedar USD 10 vs Fir USD 9 per seat per month equivalent, November 2026 US plans, USD before tax.",
  "Recompute each billing option in the revised text against 01-competitor-claims.md:6-9; no sentence may state or imply Cedar is cheaper on annual billing.", "Content owner with product marketing/legal review");
F("F3-october-cpc-window", "02", "Draft A labels a mixed-window ratio as October cost per conversion", ["quality-claims"], ["quality"], [C("02"), c02], "high",
  "Proposal only: withdraw Draft A's October figure. Report the matched window already stated in the verified-window caption (October 1-7: USD 700 / 35 = USD 20) and state that October 8-31 conversions are unmeasured. Do not present a full-month figure until conversion data for October 8-31 is supplied.",
  "Confirm numerator and denominator in any revised statement cover the same dates (02-measurement-windows.md:5-8) and that October 8-31 is described as unmeasured, not zero.", "Analytics/reporting owner");
F("F4-ai-sessions-extrapolation", "02", "Draft B extrapolates 15 tracked AI-referrer sessions to 150 with an unsupplied tracking rate and causal wording", ["quality-claims", "geo-observed-presence"], ["quality", "geo"], [C("02"), c02], "high",
  "Proposal only: replace Draft B with the observed count: 15 October sessions had an identified AI-assistant referrer; origin of other sessions is unknown. Remove 150, the one-in-ten rate and 'prove'/'generated'. Keep this report separate from campaign conversions.",
  "Check the revised sentence against 02-measurement-windows.md:14-16: only the count of 15 identified-referrer sessions is stated, with no total, rate, causal or conversion claim.", "Analytics/reporting owner");
F("F5-south-same-day", "03", "/south-delivery promises same-day delivery; approved policy for South is next-business-day only", ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [C("03"), c03, e03], "high",
  "Proposal only: replace the /south-delivery policy passage with the approved South policy (next-business-day delivery only). Do not add order cut-offs or service days for South unless the owner supplies them. Keep /north-delivery and /terms-v1 unchanged and keep both regional pages.",
  "Compare the revised /south-delivery passage with 03-template-service-area.md:4-5; re-read /north-delivery to confirm it is unchanged. Live serving and index state remain unverified.", "Content owner / operations policy owner");
F("F6-setup-guarantee", "04", "Draft landing-page claim guarantees 10-minute setup for every team; the record supports only a 15-minute median over 20 sessions", ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [C("04"), c04, e04], "high",
  "Proposal only: remove 'every team', 'guaranteed' and '10 minutes'. If a time statement is wanted, state the supplied result with its scope: in a supplied study of 20 observed onboarding sessions the median completion time was 15 minutes. Do not add a maximum, typical range or guarantee.",
  "Compare the revised claim with 04-editorial-proof.md:3-5: statistic (median), value (15 minutes), sample (20 observed sessions) match, and no guarantee, maximum or universal wording remains.", "Content owner with product/legal review");
writeFileSync(out, JSON.stringify(bundle, null, 2) + "\n");
console.log(JSON.stringify({ reviews: bundle.reviews.length, evidence: bundle.evidence.length, findings: bundle.findings.length, now }));
