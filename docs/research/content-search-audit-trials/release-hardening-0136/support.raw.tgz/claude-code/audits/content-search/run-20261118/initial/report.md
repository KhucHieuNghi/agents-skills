# Content audit — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:02:33\.564Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 3c3c81e8\-f567\-4913\-8436\-1e183c07f575\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |
| f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 4fd722354d458612b8ce51872471ae248964c2d083045542a1adad0b93e5f828 | 3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5 | local\-file | 2026\-11\-18T05:02:33\.543Z | 0 full elapsed days | [evidence/3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5\.txt](evidence/3a07dd03e991b2ecb5a74949982fd5ee6caef3ec970a5855f0779fdd0c57c5d5.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4dbc00599ecfbec657b6114f9ea7d6154c5113f8a6a07283bbaf2ffbb6ac52f6 | c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3 | local\-file | 2026\-11\-18T05:02:33\.544Z | 0 full elapsed days | [evidence/c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3\.txt](evidence/c1ed448701d6935965850d04ce8cfc5ee281de8631cd6122cd84883e2e29e5b3.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0eebb7315c75a4cbcf452c9cb326eb7c3e343cd367f34ade62b8cb65335bae2c | ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc | local\-file | 2026\-11\-18T05:02:33\.545Z | 0 full elapsed days | [evidence/ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc\.txt](evidence/ebd17e4dfe3f0d9cf023e0b579bbb48e8017c283dac0716a6c627e76a6ea79fc.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 49999873cd72ca323961a3d889d3797ac46f25474650fd19a2c5632c18311f3b | f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b | local\-file | 2026\-11\-18T05:02:33\.546Z | 0 full elapsed days | [evidence/f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b\.txt](evidence/f8d829bd34ae9da8d7d7252ab0fd9bc80f97ce7fef89dbc736a41e96a2dfe43b.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
