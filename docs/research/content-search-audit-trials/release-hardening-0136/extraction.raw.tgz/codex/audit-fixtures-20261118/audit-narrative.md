# Local content and search audit

The declared inventory is complete for the three controlled local fixtures in config.json. The helper validated a partial audit with **3 declared and in-scope items, 0 fully audited, 2 pending, 1 unsupported, 0 failed, 0 blocked and 0 excluded**. All 78 required check records are present. Seven passed, one was inapplicable and 70 remain unknown. The inventory covers these files only. [Validation](validation.json) · [Reviewed check appendix](reviewed/report.md)

| Inventory item | Evidence obtained | Collection state |
| --- | --- | --- |
| targets/render.html | Original HTML and inert extraction of the initial task text. Chrome capture terminated before producing a DOM. | Pending |
| targets/document.pdf | Byte-bound native text recovery for both pages, with matching wording from a second extractor. | Pending |
| targets/image-only.pdf | Native text extraction yielded no text. A raster preview shows visible content on its sole page. | Unsupported |

## Renewal instructions lose the final action in the source update

**Medium severity, high confidence at source level.** The owner requires both actions. Initial HTML contains the complete ordered procedure. At render.html:1 the initial main text is “Open Billing. Select Disable renewal.” The scheduled callback assigns “Open Billing.” to the same main element and then sets the owner-confirmed readiness marker. That replacement loses the action that actually disables renewal. The raw procedure therefore checks out, while the code would leave an incomplete answer if the callback runs. The source text extraction passed. The fixture has no informative media component to assess. [Owner task](reviewed/evidence/renewal-task.txt) · [Readiness contract](reviewed/evidence/renewal-ready-contract.txt)

Chrome ran headless with a fresh local profile and a loopback-only proxy configuration. It terminated with signal 6 and produced zero DOM bytes. The cause was undetermined. Browser-level rendering, task fit, retrievable facts and answer coverage/context remain unknown at readiness. The helper records one source-level finding, `renewal-source-drops-step`, covering the shared defect across those checks. [Capture diagnostic](reviewed/evidence/chrome-attempt.json) · [Action backlog](reviewed/content-actions.csv)

The fixture author should preserve both approved instructions through the scheduled update. To verify the change, capture the visible main content in a fresh isolated local browser with normal protections, after `document.documentElement.dataset.auditReady === 'true'`. Check both steps in order and retain the ready DOM and capture metadata. Engine rendering would require a separate engine-provided capture for an intended public URL.

## The export policy matches both recovered language sections

The English page states the limit and plan scope. PDF page 1, document-content.txt:2-3 — “A single export contains at most 5000 records. Applies to current VN plans.”

The Vietnamese page states the same per-export limit and explicitly confirms the fee policy. PDF page 2, document-content.txt:4-5 — “Mỗi lần xuất tối đa 5000 bản ghi. Không cần thanh toán thêm.”

The common limit, current VN plan scope and no-extra-charge wording agree with the owner-approved policy. The language sections emphasize different details as allowed by the owner. There is no supported policy contradiction or translation-completeness defect. The recovered PDF passes the fixture-scoped factual, applicability, entity consistency, retrievable-facts and answer-evidence checks, as well as the text extraction check. The no-extra-charge detail is already present in Vietnamese. Customer question coverage and answer context against a question set remain open because the request supplies policy only for this task. URL locale relationships and deployed metadata remain unverified. [PDF text](reviewed/evidence/document-content.txt) · [Owner policy](reviewed/evidence/export-policy.txt) · [Language scope](reviewed/evidence/export-scope.txt)

PDFKit 1451.3.3 obtained nonempty text on both pages. Ghostscript 10.05.1 returned identical text by page after its text spans were reconstructed in baseline order. The recovery revision preserves page count, page order, extractor details and SHA-256 linkage to the original PDF. The recovery is limited to the text layer. Layout, assistive technology behavior and deployed search signals need separate evidence. [Extraction manifest](reviewed/evidence/document-extraction.json) · [Recovery review](recovered/report.md)

## The image PDF has visible content and no recovered text

PDFKit returned a null page string and Ghostscript emitted one page without text spans. The raster preview shows a sentence about needing a separate OCR capability. The text-layer result therefore leaves the source content readable visually and the extraction check unknown. The run retains the original item as unsupported. OCR was not run. To recover the item for text review, use a locally authorized OCR result or a verified page-by-page transcript, check it against the page image, preserve the provenance and bind it to the original bytes through the helper. Verify document text alternatives and assistive technology behavior separately if accessibility is in scope. [Extraction diagnostic](reviewed/evidence/image-extraction-attempt.json) · [Page preview](image-only-page-1.png)

## Unmeasured surfaces and remaining review

- **SEO and AI search access.** No live HTTP responses, headers, public URL graph, effective crawler controls, canonical selection, engine-rendered capture, index status or feature eligibility evidence were supplied. The initial HTML identifies itself as an English controlled fixture, with no alternate, canonical or structured-data markup in the raw source. Those source observations do not resolve the deployment checks. For an intended public deployment, collect the applicable URL, HTTP and crawler-policy evidence with publisher intent, engine-rendered and index evidence, and any intended locale and canonical mapping.
- **Answer quality and portfolio.** Renewal support and VN export policy are distinct tasks. The two language sections are within one PDF and agree on the shared export limit. The third item is an extraction-control fixture based on visual inspection. The local inventory provides no basis for a consolidation or cross-task navigation finding. For broader task-gap or answer-coverage review, supply actual questions, the intended audience and navigation scope, and any applicable link graph. Keep the owner-approved task and policy as comparison evidence.
- **Generative visibility and analytics.** No AI observations, historical study measurements, Search Console, GA4, Bing or server-log exports were supplied. Presence, citations, answer accuracy, cohort validity, indexing and performance remain unmeasured. If measurement is later in scope, record comparable prompts by product surface and locale, preserve dated responses and citations, and adjudicate claims against dated policy. Report eligible-response denominators and capture gaps. Review any authorized provider exports within their own date and scope.

The initial run, recovery revision and semantic revision preserve the audit trail. The source artifacts, reviews and receipts are available locally. [Initial run](initial/report.md) · [Recovery revision](recovered/report.md) · [Semantic revision](reviewed/report.md)
