# Content audit — Content Search Audit

## Delivery summary

Partial\. 3 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:08:17\.074Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 1142b79d\-469d\-4349\-939e\-d6a89e69c82d\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 1 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 2 | 13 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | pending | Snapshot review incomplete | 26 |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | pending | Snapshot review incomplete | 26 |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | html\-static\-main |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | document\-text |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 425cf76edb79815276873c47dc604cd35217a06bf48a10f7d7bc827d54f0ac18 | 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | local\-file | 2026\-11\-18T05:06:08\.369Z | 0 full elapsed days | [evidence/00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74\.txt](evidence/00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| document\-extraction | 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | PDFKit native text | 2026\-11\-18T05:06:27\.577Z | 0 full elapsed days | [evidence/document\-extraction\.json](evidence/document-extraction.json) | fdd4ab50e26efc70e660b807b4db7493dfa50c496637297b99cb330eed7e4db9 | Native PDF text\-layer extraction only\. PDFKit strings checked against Ghostscript 10\.05\.1 text extraction on both pages\.; Text\-layer agreement does not validate layout, assistive technology behavior, live availability or indexing\. |
| document\-content | 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | PDFKit native text | 2026\-11\-18T05:06:27\.577Z | 0 full elapsed days | [evidence/document\-content\.txt](evidence/document-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native PDF text\-layer extraction only\. PDFKit strings checked against Ghostscript 10\.05\.1 text extraction on both pages\.; Text\-layer agreement does not validate layout, assistive technology behavior, live availability or indexing\. |
| document\-text | 264b086e8e6106fd5dcb46f299e1b29943c9699e439ccabf6410f31ade19d93c | PDFKit native text | 2026\-11\-18T05:06:27\.577Z | 0 full elapsed days | [evidence/document\-text\.txt](evidence/document-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native PDF text\-layer extraction only\. PDFKit strings checked against Ghostscript 10\.05\.1 text extraction on both pages\.; Text\-layer agreement does not validate layout, assistive technology behavior, live availability or indexing\. |
| chrome\-attempt | 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | Headless Chrome with fresh local profile | 2026\-11\-18T05:08:12\.655Z | 0 full elapsed days | [evidence/chrome\-attempt\.json](evidence/chrome-attempt.json) | cee368f7df7ec741b929b1046d479ac2f680a019f0d0c48773cc17415def91db | The readiness marker and rendered state could not be observed\. The termination cause is undetermined\. |
| image\-extraction\-attempt | 271f06a2390e3733e62629cb9b616f911841fc0ce47515fd9159a58bfa43e5c1 | PDFKit text layer, Ghostscript text extraction and visual raster inspection | 2026\-11\-18T05:08:12\.655Z | 0 full elapsed days | [evidence/image\-extraction\-attempt\.json](evidence/image-extraction-attempt.json) | 85630dee39b74e4b4d04c38e025cedf77ecb6e907732ff172c349bd92668d90f | The preview confirms visible content\. The text result is unavailable; visual inspection is not a recovered text snapshot\. |
| html\-static\-main | 00d013ced71361a0548b463fcece58e633409781664205938fd7d289a5142b74 | Inert source text extraction | 2026\-11\-18T05:08:12\.655Z | 0 full elapsed days | [evidence/html\-static\-main\.txt](evidence/html-static-main.txt) | b2fdadf97d9222745357e356607707419af032d86f00749b46ce7ca1082c6e59 | Source main text only\. No browser or engine state is captured\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
