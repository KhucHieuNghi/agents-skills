import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = fs.realpathSync('.');
const dir = 'audit-fixtures-20261118';
const report = dir + '/audit-narrative.md';
const lines = fs.readFileSync(report, 'utf8').split('\n');
const hash = (file) => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const pdf = dir + '/reviewed/evidence/document-content.txt';
const entries = [
  ['initial-task', 'targets/render.html', 1, 1, 'Open Billing. Select Disable renewal.'],
  ['scheduled-task', 'targets/render.html', 1, 1, 'Open Billing.'],
  ['en-policy', pdf, 2, 3, 'A single export contains at most 5000 records. Applies to current VN plans.'],
  ['vi-policy', pdf, 4, 5, 'Mỗi lần xuất tối đa 5000 bản ghi. Không cần thanh toán thêm.']
];
const quotes = entries.map(([quoteId, source, startLine, endLine, quote]) => {
  const reportLine = lines.findIndex((line) => line.includes('“' + quote + '”')) + 1;
  if (!reportLine) throw new Error('Missing quote: ' + quoteId);
  return {
    quoteId, source, sourceLabel: path.basename(source), sourceHash: hash(source),
    startLine, endLine, reportStartLine: reportLine, reportEndLine: reportLine,
    normalization: 'whitespace', quote
  };
});
fs.writeFileSync(dir + '/quotes.json', JSON.stringify({root, report, reportHash: hash(report), quotes}, null, 2) + '\n');
