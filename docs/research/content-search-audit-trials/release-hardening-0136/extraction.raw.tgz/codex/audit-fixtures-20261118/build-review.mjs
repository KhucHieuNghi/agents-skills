import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';

const dir = path.dirname(new URL(import.meta.url).pathname);
const read = (file) => fs.readFileSync(file, 'utf8');
const json = (value) => JSON.stringify(value, null, 2) + '\n';
const digest = (value) => crypto.createHash('sha256').update(value).digest('hex');
const records = (file) => read(path.join(dir, 'initial', file)).trim().split('\n').map(JSON.parse);
const inventory = records('inventory.jsonl');
const item = (name) => inventory.find((entry) => path.basename(entry.path) === name);
const html = item('render.html');
const doc = item('document.pdf');
const image = item('image-only.pdf');
const raw = records('evidence.jsonl')[0];
assert.equal(digest(fs.readFileSync(html.path)), raw.snapshotHash);
const kitFile = path.join(dir, 'pdfkit.json');
const kit = JSON.parse(read(kitFile));
const current = new Date().toISOString();
const collection = { artifacts: {}, evidence: [], reviews: [], collectionRecoveries: [] };
const semantic = { artifacts: {}, evidence: [], reviews: [], findings: [] };

function add(bundle, owner, id, kind, value, locator, method, limitations, sourceEvidenceIds = [], collectedAt = current) {
  const isText = typeof value === 'string';
  const bytes = isText ? value : json(value);
  const artifact = 'evidence/' + id + (isText ? '.txt' : '.json');
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({
    itemId: owner.itemId, evidenceId: id, kind, value, artifact, method, locator,
    collectedAt, limitations, sourceEvidenceIds, snapshotHash: digest(bytes),
    byteLength: Buffer.byteLength(bytes), redaction: 'none', encoding: isText ? 'utf8' : 'json'
  });
  return id;
}

const pdf = kit['document.pdf'];
assert.equal(pdf.pageCount, pdf.pages.length);
assert(pdf.pages.every(({page, text}, i) => page === i + 1 && text.trim()));
const gsLines = read(path.join(dir, 'gs-document.xml')).trim().split(/<page>\s*/).slice(1).map((page) => {
  const lines = new Map();
  for (const match of page.matchAll(/<char bbox="\d+ (\d+) \d+ \d+" c="([^"]*)"\/>/g)) {
    const [, baseline, char] = match;
    const decoded = char.replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)));
    lines.set(baseline, (lines.get(baseline) ?? '') + decoded);
  }
  return [...lines.values()].join('\n');
});
assert.deepEqual(gsLines, pdf.pages.map(({text}) => text));

const source = fs.readFileSync(doc.path);
const limitations = [
  'Native PDF text-layer extraction only. PDFKit strings checked against Ghostscript 10.05.1 text extraction on both pages.',
  'Text-layer agreement does not validate layout, assistive technology behavior, live availability or indexing.'
];
const provenance = {
  schemaVersion: 1, sourceSha256: digest(source), sourceByteLength: source.length,
  extractor: {name: 'Apple PDFKit PDFPage.string', version: pdf.pdfkit + ' on macOS ' + pdf.os},
  pageCount: pdf.pageCount, pages: pdf.pages, coverage: 'complete', limitations
};
const extractTime = fs.statSync(kitFile).mtime.toISOString();
const man = add(collection, doc, 'document-extraction', 'extraction-provenance', provenance, 'targets/document.pdf, pages 1–2', 'PDFKit native text', limitations, [], extractTime);
const allText = pdf.pages.map(({text}) => text).join('\f');
const content = add(collection, doc, 'document-content', 'content', allText, 'targets/document.pdf, pages 1–2', 'PDFKit native text', limitations, [man], extractTime);
const extracted = add(collection, doc, 'document-text', 'extracted-text', allText, 'targets/document.pdf, pages 1–2', 'PDFKit native text', limitations, [content], extractTime);
collection.collectionRecoveries.push({
  itemId: doc.itemId, manifestEvidenceId: man, contentEvidenceId: content, textEvidenceId: extracted,
  reviewer: 'Codex', reviewedAt: current, reason: 'Both original pages yielded nonempty text in order. Their wording agrees with the independent Ghostscript text pass.'
});

const diagnostic = (owner, id, value, locator, method, boundaries) =>
  add(collection, owner, id, 'collection-diagnostic', value, locator, method, boundaries);
const chrome = diagnostic(html, 'chrome-attempt', {
  command: 'rtk proxy "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless --user-data-dir="$PWD/audit-fixtures-20261118/chrome-profile" --disable-background-networking --disable-component-update --disable-sync --no-first-run --no-default-browser-check --proxy-server="http://127.0.0.1:9" --virtual-time-budget=1000 --dump-dom "file://$PWD/targets/render.html"',
  stderr: read(path.join(dir, 'chrome.stderr')), domBytes: fs.statSync(path.join(dir, 'rendered.html')).size
}, 'Local Chrome capture attempt for targets/render.html', 'Headless Chrome with fresh local profile', ['The readiness marker and rendered state could not be observed. The termination cause is undetermined.']);
const preview = fs.readFileSync(path.join(dir, 'image-only-page-1.png'));
const imageSource = fs.readFileSync(image.path);
const noText = diagnostic(image, 'image-extraction-attempt', {
  sourceSha256: digest(imageSource), sourceByteLength: imageSource.length,
  pdfkit: kit['image-only.pdf'], ghostscript: '10.05.1 txtwrite, one page with no text spans',
  preview: { file: 'image-only-page-1.png', sha256: digest(preview), page: 1 },
  visualObservation: 'Page 1 contains a visible sentence explaining that a separate OCR capability is needed.'
}, 'targets/image-only.pdf, page 1', 'PDFKit text layer, Ghostscript text extraction and visual raster inspection', ['The preview confirms visible content. The text result is unavailable; visual inspection is not a recovered text snapshot.']);
const staticMain = raw.value.match(/<main id="task">([^<]+)<\/main>/)[1];
add(collection, html, 'html-static-main', 'extracted-text', staticMain, 'targets/render.html:1, initial main markup', 'Inert source text extraction', ['Source main text only. No browser or engine state is captured.'], [raw.evidenceId]);

const owner = (entry, id, kind, value, deps = []) =>
  add(semantic, entry, id, kind, value, 'Owner statement in the current audit request', 'Owner-supplied audit context', ['Approved scope for comparison in this fixture audit. No independent product or platform verification.'], deps);
const task = owner(html, 'renewal-task', 'audience-context', 'Approved renewal task requires opening Billing and selecting Disable renewal.');
const question = owner(html, 'renewal-question', 'question-set', 'Owner-supplied renewal task to assess: opening Billing and selecting Disable renewal. No demand or query-volume evidence.');
const ready = owner(html, 'renewal-ready-contract', 'publisher-intent', "The author-approved completion signal is document.documentElement.dataset.auditReady === 'true'.");
const claim = owner(doc, 'export-policy', 'claim-sources', 'Approved export policy: current VN plans support at most 5000 records per export, with no extra charge.');
const audience = owner(doc, 'export-scope', 'audience-context', 'Policy subject and audience scope for this review: export limits and charges for current VN plans. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.');
const entity = add(semantic, doc, 'export-entity', 'entity-record', 'Current VN plans: at most 5000 records per export, no extra charge. The recovered English and Vietnamese pages agree on the limit. The English page supplies plan scope and the Vietnamese page supplies the no-extra-charge detail.', 'Owner export policy and targets/document.pdf pages 1–2', 'Scoped policy comparison', ['One PDF with two language sections. No authoritative identity or plan claim outside supplied scope.'], [claim, content]);

function review(owner, ruleId, status, reason, evidenceIds) {
  semantic.reviews.push({ itemId: owner.itemId, ruleId, status, reason, evidenceIds, reviewer: 'Codex', reviewedAt: current });
}

const htmlEvidence = [raw.evidenceId, task, question, ready, chrome];
review(html, 'seo-rendering', 'unknown', 'Source line 1 schedules a replacement of the task text with only its first step. Chrome terminated before a ready DOM was captured.', htmlEvidence);
review(html, 'quality-task-fit', 'unknown', 'Initial markup has both approved steps. The script drops the decisive step in its assigned value, and the ready user-facing state is unverified.', htmlEvidence);
review(html, 'aio-retrievable-facts', 'unknown', 'The approved steps are present in initial markup, but one is removed by the scheduled source assignment and post-render capture is unavailable.', htmlEvidence);
review(html, 'aeo-question-coverage', 'unknown', 'The initial procedure covers the owner-supplied renewal task. Post-ready coverage remains unverified after the browser attempt terminated.', htmlEvidence);
review(html, 'aeo-answer-context', 'unknown', 'The initial ordered steps are clear. The source has an incomplete replacement and no ready DOM was captured.', htmlEvidence);
review(html, 'quality-accessible-media', 'not-applicable', 'The fixture source contains plain text and a script that assigns text only. It has no informative image, audio or video component.', [raw.evidenceId]);
review(doc, 'quality-claims', 'pass', 'Both pages use the approved 5000-record maximum per export. The English page identifies current VN plans and the Vietnamese no-extra-charge statement agrees with the approved policy.', [content, claim]);
review(doc, 'quality-freshness', 'pass', 'The English applicability statement matches the current VN plan scope in the supplied approval. The Vietnamese section is a companion emphasis within the same PDF. This is an owner-context review for the supplied fixture.', [content, claim, audience]);
review(doc, 'aio-entity-consistency', 'pass', 'Across both sections the shared export limit is consistent and the complementary scope and fee details agree with the owner record.', [content, entity]);
review(doc, 'aio-retrievable-facts', 'pass', 'Both native-text sections state the export limit and its unit. The full recovered document makes both the current VN scope and no-extra-charge detail readable for the supplied policy task.', [content, audience]);
review(doc, 'aeo-answer-evidence', 'pass', 'All material export answer claims in the recovered document are covered by the supplied approval, including maximum per export, current VN applicability and Vietnamese no-extra-charge wording.', [content, claim]);
review(doc, 'aeo-question-coverage', 'unknown', 'The approved policy supports answer facts. No export customer question set was supplied for a coverage verdict.', [content, claim]);
review(doc, 'aeo-answer-context', 'unknown', 'The standalone English and Vietnamese limit sentences each retain the unit and per-export context. The current-plan scope is expressed in English and the fee detail in Vietnamese. No export question set was supplied.', [content, audience]);
review(doc, 'seo-locales', 'unknown', 'The recovered English and Vietnamese sections agree on their shared fact. Intended URL alternates, reciprocal annotations and canonical signals are unverified.', [content, audience]);
review(image, 'quality-readable-text', 'unknown', 'Both native extraction methods produced no text. The raster preview shows a visible sentence. A provenance-bound page transcript or OCR result has not been admitted.', [noText]);
semantic.findings.push({
  findingId: 'renewal-source-drops-step',
  title: 'Scheduled HTML update drops the approved renewal action from the task text',
  affectedItemIds: [html.itemId], dimensions: ['seo', 'quality', 'aio', 'aeo'],
  ruleIds: ['seo-rendering', 'quality-task-fit', 'aio-retrievable-facts', 'aeo-question-coverage', 'aeo-answer-context'],
  evidenceIds: htmlEvidence, severity: 'medium', confidence: 'high', classification: 'observed',
  remediation: 'Preserve both approved steps in the task text when the scheduled update runs.',
  verification: "In a fresh authorized local browser profile, wait until document.documentElement.dataset.auditReady === 'true'. Capture the ready DOM and confirm the visible task still instructs opening Billing and selecting Disable renewal, in that order.",
  ownerRole: 'Fixture author', effort: 'small',
  action: 'update', actionReason: 'The source replacement removes the action that completes the approved renewal task. Browser verification is still required.'
});
fs.writeFileSync(path.join(dir, 'collection-review.json'), json(collection));
fs.writeFileSync(path.join(dir, 'semantic-review.json'), json(semantic));
