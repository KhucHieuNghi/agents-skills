// Text-layer extraction with macOS PDFKit. Reads the PDF only; no OCR, no rendering to disk.
import Foundation
import PDFKit
let args = CommandLine.arguments
guard args.count == 2 else { FileHandle.standardError.write("usage: pdfkit-extract PDF\n".data(using: .utf8)!); exit(2) }
let url = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: url) else { FileHandle.standardError.write("PDFKit could not open document\n".data(using: .utf8)!); exit(3) }
var pages: [[String: Any]] = []
for i in 0..<doc.pageCount {
  guard let p = doc.page(at: i) else { pages.append(["page": i + 1, "text": NSNull(), "error": "page unavailable"]); continue }
  let b = p.bounds(for: .mediaBox)
  pages.append(["page": i + 1, "text": p.string ?? "", "stringWasNil": p.string == nil,
                "characterCount": p.numberOfCharacters, "annotationCount": p.annotations.count,
                "mediaBox": [b.origin.x, b.origin.y, b.size.width, b.size.height]])
}
let os = ProcessInfo.processInfo.operatingSystemVersionString
let bundle = Bundle(for: PDFDocument.self)
let out: [String: Any] = [
  "pageCount": doc.pageCount, "isEncrypted": doc.isEncrypted, "isLocked": doc.isLocked,
  "allowsCopying": doc.allowsCopying,
  "documentAttributes": (doc.documentAttributes ?? [:]).reduce(into: [String: String]()) { $0["\($1.key)"] = "\($1.value)" },
  "pdfVersion": "\(doc.majorVersion).\(doc.minorVersion)",
  "pdfKitBundleVersion": (bundle.infoDictionary?["CFBundleVersion"] as? String) ?? "unknown",
  "pdfKitShortVersion": (bundle.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "unknown",
  "operatingSystem": os, "pages": pages]
let data = try JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(data)
