# Content audit — Content Search Audit

## Delivery summary

Partial\. 3 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:14:21\.610Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run f1f532b9\-8a67\-4842\-9efe\-794bed894eb8\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 1 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 2 | 13 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | pending | Snapshot review incomplete | 26 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | document\-pdf\-extracted\-text |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | render\-html\-rendered\-text |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |
| d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 5d3bd44dd2f2de07a0c28956f46ab74282bda08b2410a6fd709d41d7b4c0ea14 | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | local\-file | 2026\-11\-18T05:10:27\.183Z | 0 full elapsed days | [evidence/d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7\.txt](evidence/d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| document\-pdf\-extraction\-manifest | 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | pdfkit\-text\-layer\-extraction | 2026\-11\-18T05:11:09\.956Z | 0 full elapsed days | [evidence/document\-pdf\-extraction\-manifest\.json](evidence/document-pdf-extraction-manifest.json) | 8569f1d1004b8ada6d27e93f60a7dc75d950affb1daf41b7762a4c6fd0bfc178 | Text\-layer extraction only; no OCR and no visual comparison of the rendered pages was performed\.; Reading order is PDFKit&\#39;s and was not independently verified\.; Images, figures, alternative text, links, document JavaScript and HTTP headers are not captured by this extraction\.; Page count, completeness and text fidelity are attributed assertions of the extractor run, not independent verification\. |
| document\-pdf\-content | 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | pdfkit\-text\-layer\-extraction | 2026\-11\-18T05:11:09\.956Z | 0 full elapsed days | [evidence/document\-pdf\-content\.txt](evidence/document-pdf-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Text\-layer extraction only; no OCR and no visual comparison of the rendered pages was performed\.; Reading order is PDFKit&\#39;s and was not independently verified\.; Images, figures, alternative text, links, document JavaScript and HTTP headers are not captured by this extraction\.; Page count, completeness and text fidelity are attributed assertions of the extractor run, not independent verification\. |
| document\-pdf\-extracted\-text | 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | pdfkit\-text\-layer\-extraction | 2026\-11\-18T05:11:09\.956Z | 0 full elapsed days | [evidence/document\-pdf\-extracted\-text\.txt](evidence/document-pdf-extracted-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Text\-layer extraction only; no OCR and no visual comparison of the rendered pages was performed\.; Reading order is PDFKit&\#39;s and was not independently verified\.; Images, figures, alternative text, links, document JavaScript and HTTP headers are not captured by this extraction\.; Page count, completeness and text fidelity are attributed assertions of the extractor run, not independent verification\. |
| image\-only\-pdf\-extraction\-attempt | 6bf06702e232dd7b3151df907aaf6cf9b5767ae2bfd7630687f7e6f9c4062256 | pdfkit\-text\-layer\-extraction\-attempt | 2026\-11\-18T05:11:10\.389Z | 0 full elapsed days | [evidence/image\-only\-pdf\-extraction\-attempt\.json](evidence/image-only-pdf-extraction-attempt.json) | 9dfae0dba0be53e6596b8f5651a4013acf111d1d708e188490f5e1a0e49a7465 | Empty text\-layer output is an extraction limitation, not proof of empty source content\.; No OCR or visual transcription was performed; the pixel content is unread\.; Not usable for attributed recovery: the recovery contract requires nonempty extracted text for every page\.; Byte\-pattern inspection does not decode compressed streams, so absence of an /Alt marker does not prove alternative text is absent\. |
| render\-html\-render\-provenance | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | headless\-chrome\-cdp\-capture | 2026\-11\-18T05:11:48\.378Z | 0 full elapsed days | [evidence/render\-html\-render\-provenance\.json](evidence/render-html-render-provenance.json) | c1f2b3f4d9f0ae78db8feb3bf80a0554a42fcc7470192e6f0a6c7d73871a268f | Local headless Google Chrome capture of a file:// URL in a fresh temporary profile; not search\-engine or AI\-crawler rendering\.; Captured once, after the owner\-confirmed ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39;; later mutations are not observed\.; Does not establish HTTP delivery, index status or behaviour in other browsers\. |
| render\-html\-rendered\-dom | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | headless\-chrome\-cdp\-capture | 2026\-11\-18T05:11:48\.378Z | 0 full elapsed days | [evidence/render\-html\-rendered\-dom\.txt](evidence/render-html-rendered-dom.txt) | e1e537fd2f540b47687241ad6ba9e96551bedc88f6fa97ddaa138271463d50f2 | Local headless Google Chrome capture of a file:// URL in a fresh temporary profile; not search\-engine or AI\-crawler rendering\.; Captured once, after the owner\-confirmed ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39;; later mutations are not observed\.; Does not establish HTTP delivery, index status or behaviour in other browsers\. |
| render\-html\-rendered\-text | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | headless\-chrome\-cdp\-capture | 2026\-11\-18T05:11:48\.378Z | 0 full elapsed days | [evidence/render\-html\-rendered\-text\.txt](evidence/render-html-rendered-text.txt) | ca117db5ad1267b66ca8341827787ff0684718487e677baea400a3e2239e6d7d | Local headless Google Chrome capture of a file:// URL in a fresh temporary profile; not search\-engine or AI\-crawler rendering\.; Captured once, after the owner\-confirmed ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39;; later mutations are not observed\.; Does not establish HTTP delivery, index status or behaviour in other browsers\.; Rendered visible text only; the raw source text differs and is retained separately as content evidence\. |
| render\-html\-media\-inventory | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | derived\-pattern\-inspection | 2026\-11\-18T05:14:21\.420Z | 0 full elapsed days | [evidence/render\-html\-media\-inventory\.json](evidence/render-html-media-inventory.json) | c8a9a28c99465f72cb841675db94a02f112e8429d4aba4c85912e9bd4b84a9b3 | Derived by pattern counts over the retained raw source text and the retained rendered DOM text; no target code was executed for this derivation\.; Covers only the two captured surfaces\. |
| render\-html\-schema\-extraction | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | derived\-pattern\-inspection | 2026\-11\-18T05:14:21\.420Z | 0 full elapsed days | [evidence/render\-html\-schema\-extraction\.json](evidence/render-html-schema-extraction.json) | 2abf29ba7bc7a99335f7aa4628693bfa3aa51b5328341c5f513044f472347657 | Derived by pattern counts over the retained raw source text and the retained rendered DOM text; no target code was executed for this derivation\.; Covers only the two captured surfaces\. |
| render\-html\-owner\-task\-context | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | owner\-supplied\-task\-statement | 2026\-11\-18T05:14:21\.420Z | 0 full elapsed days | [evidence/render\-html\-owner\-task\-context\.txt](evidence/render-html-owner-task-context.txt) | 52a940a3aa9cba24e5832f24848a81d35c5f81a100aa077e55d67dddf3845fea | Supplied by the audit requester in the task statement; an approved comparison basis for this audit, not independently verified platform or business behaviour\.; No effective date, product version or source document accompanies the statement beyond its wording\.; States the approved user task only; no audience segment, market or question set is supplied\. |
| render\-html\-owner\-task\-claim\-source | d8c64e50e0d8972c595a63d8a119883b270bd39744f2b744518944ebb2dce1a7 | owner\-supplied\-task\-statement | 2026\-11\-18T05:14:21\.420Z | 0 full elapsed days | [evidence/render\-html\-owner\-task\-claim\-source\.txt](evidence/render-html-owner-task-claim-source.txt) | 52a940a3aa9cba24e5832f24848a81d35c5f81a100aa077e55d67dddf3845fea | Supplied by the audit requester in the task statement; an approved comparison basis for this audit, not independently verified platform or business behaviour\.; No effective date, product version or source document accompanies the statement beyond its wording\. |
| document\-pdf\-owner\-export\-policy | 861d69c90e30c366f40bbdaa94972572d4c171e5110f052a8df58a3dc2d11a7d | owner\-supplied\-task\-statement | 2026\-11\-18T05:14:21\.420Z | 0 full elapsed days | [evidence/document\-pdf\-owner\-export\-policy\.txt](evidence/document-pdf-owner-export-policy.txt) | 7f7c1c2e59983b2bc74345d398672a3ab0b7a5a49652c09c07dd0e8e6e25d904 | Supplied by the audit requester in the task statement; an approved comparison basis for this audit, not independently verified platform or business behaviour\.; No effective date, product version or source document accompanies the statement beyond its wording\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
