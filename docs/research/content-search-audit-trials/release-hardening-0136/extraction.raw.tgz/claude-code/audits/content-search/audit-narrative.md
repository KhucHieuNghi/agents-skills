# Content search audit narrative: three declared local fixtures

Audit date: 2026-11-18 (UTC). Final validated revision: `run-03-reviewed` (run `b708f559-fa22-400a-913d-48b148a3de90`).
This narrative supplements the helper-generated reports; counts below are copied from the validated `run-03-reviewed/coverage.json`.

## 1. Result in brief

**The audit is partial: 3 declared items, 0 fully audited, 2 pending, 1 unsupported, 0 failed, 0 blocked, 0 excluded.** The validator reports the run as structurally valid with `completionAllowed: false`.

- **One actual defect, in `render.html`:** once rendering finishes, the page shows only the first of the two steps in the approved renewal task. The raw HTML contains both steps.
- **`document.pdf` is clean on the checks that could be assessed:** every claim in its text layer matches the approved export policy.
- **`image-only.pdf` could not be read:** PDFKit returned no text layer. Its content is unknown, not empty, and none of its 26 checks is resolved.
- **Most checks remain unknown** (66 of 78) because the evidence they need was not supplied: HTTP responses, publisher intent, question sets, locale maps, link graphs, entity records and AI observations.

No search-engine rendering, indexing, analytics, AI observation or feature-eligibility evidence was supplied, so nothing in this audit measures search or AI visibility.

## 2. Scope and coverage

The inventory is the three inputs declared in `config.json`, which declares the inventory complete. Discovery is complete for that declared set only; it says nothing about any live site.

| Item | Collection | State | Pass | Fail | Not applicable | Unknown |
| --- | --- | --- | --- | --- | --- | --- |
| `targets/render.html` | Raw source read by the helper; rendered DOM captured in headless Chrome | pending | 3 | 3 | 2 | 18 |
| `targets/document.pdf` | Recovered from the PDFKit text layer (2 pages) | pending | 4 | 0 | 0 | 22 |
| `targets/image-only.pdf` | PDFKit returned no text; not recovered | unsupported | 0 | 0 | 0 | 26 |

Each item carries the full 26-rule plan (78 checks in total, none missing). An item counts as fully audited only when all 26 of its checks resolve, which is why both readable items remain pending even though they were read in full.

Revisions, each preserved unchanged:

| Revision | What it adds | States |
| --- | --- | --- |
| `run-01-initial` | Helper `start`: inventory, raw HTML snapshot, 78 planned checks | 1 pending, 2 unsupported |
| `run-02-recovered` | Attributed PDF recovery, extraction and render evidence, owner context; no semantic verdicts | 2 pending, 1 unsupported |
| `run-03-reviewed` | Semantic assessments and the persisted finding | 2 pending, 1 unsupported |

The three target files have the same SHA-256 hashes after the audit as before it. No target or installed skill file was modified.

## 3. Actual defect

### `render-drops-disable-renewal-step` (high severity, high confidence, observed)

Affected item: `targets/render.html`. Failed checks: `quality-task-fit`, `seo-rendering`, `aio-retrievable-facts`. These are three views of one defect, persisted as one finding.

The owner's statement, preserved as evidence, sets the task: "Approved renewal task requires opening Billing and selecting Disable renewal." (render-html-owner-task-context.txt:1)

- Raw source has both steps: `<main id="task">Open Billing. Select Disable renewal.</main>` (render.html:1)
- The page's inline script then overwrites that text: `setTimeout(() => { document.getElementById('task').textContent = 'Open Billing.'; document.documentElement.dataset.auditReady = 'true'; }, 50);` (render.html:1)
- The rendered DOM, captured after the ready signal, has one step: `<main id="task">Open Billing.</main>` (render-html-rendered-dom.txt:1)

The capture waited until `document.documentElement.dataset.auditReady === 'true'` evaluated true (observed after 70 ms of polling), which the owner confirms means rendering has finished. The visible body text at that point was "Open Billing." and nothing else. A person reading the rendered page is never told to select Disable renewal, so the page does not enable the approved task.

What this does and does not establish:

- **Established:** raw source and the locally rendered DOM of the same file disagree on a required step.
- **Not established:** how any search engine or AI crawler renders or indexes the page. A reader of raw HTML would get both steps; a reader of the rendered page would get one. Which surface any engine uses is not evidenced.

**Proposed change (not implemented):** change the inline script in `targets/render.html` so that `main#task` still reads both steps when the ready signal is set, for example by not overwriting the element text.

**Verification:** open the revised file in an isolated browser profile, wait until `document.documentElement.dataset.auditReady === 'true'` (a string comparison), then confirm the `main#task` text contains both steps and matches the raw source.

## 4. Clean checks

### `targets/document.pdf`

The owner's statement, preserved as evidence: "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge." (document-pdf-owner-export-policy.txt:1)

| Page | Extracted claim | Locator | Against approved policy |
| --- | --- | --- | --- |
| 1 (English) | "A single export contains at most 5000 records." | document-pdf-content.txt:2 | Matches the 5000-record limit |
| 1 (English) | "Applies to current VN plans." | document-pdf-content.txt:3 | Matches the plan and market scope |
| 2 (Vietnamese) | "Mỗi lần xuất tối đa 5000 bản ghi." | document-pdf-content.txt:4 | Matches the 5000-record limit (each export is at most 5000 records) |
| 2 (Vietnamese) | "Không cần thanh toán thêm." | document-pdf-content.txt:5 | Matches no extra charge (no additional payment is needed) |

- `quality-claims`: pass. No claim contradicts or exceeds the approved policy.
- `quality-freshness`: pass. The document's only applicability statement matches the policy's scope as supplied at audit time. The text carries no effective date, so this does not establish how long the policy stays current.
- `aeo-answer-evidence`: pass. Each answer claim is supported by the approved policy.
- `quality-readable-text`: pass, computed by the helper from the nonempty extraction.

The English page does not mention the charge and the Vietnamese page does not mention plan scope. This is not a finding: the owner states the two language pages may emphasise different aspects and that translation completeness is not required.

These passes rest on the owner's statement as the comparison basis and on a text-layer extraction. They are not independent verification of the product, and the pages were not compared visually with the extracted text.

### `targets/render.html`

- `quality-claims`: pass. Every step stated on either surface matches the approved task. The missing rendered step is an omission (failed under `quality-task-fit`), not an inaccurate claim.
- `aeo-answer-evidence`: pass. Each step that appears is supported by the approved task.
- `quality-readable-text`: pass, computed by the helper. The rendered text is nonempty; this says nothing about completeness.
- `quality-accessible-media`: not applicable. Neither surface contains any image, video, audio, SVG, canvas, object, embed or iframe element.
- `seo-structured-data`: not applicable. Neither surface contains JSON-LD, microdata or RDFa, so there is nothing to compare with visible claims. Absence of markup is not treated as a defect.

Other observations from the capture, none of them findings:

- The only request Chrome made was for the file itself, and no script exception was raised.
- Apart from the task text, the rendered DOM differs from the source only by the added `data-audit-ready="true"` attribute.
- The title is `<title>Controlled render fixture</title>` (render.html:1), with no meta description and no headings on either surface. `seo-metadata` is left unknown: whether a title that names the fixture rather than the task is a defect depends on publisher intent, which was not supplied.

## 5. Unavailable evidence and unknown checks

### `targets/image-only.pdf` (unsupported)

PDFKit opened the file, reported 1 page, and returned no text (0 characters; the page string was nil). **Empty extracted text is not proof of empty source content.** An inert search of the file's uncompressed dictionary bytes found image objects (800 × 100) and no font objects, which is consistent with content that exists only as pixels.

- The item was not recovered: the recovery contract requires nonempty extracted text for every page.
- No OCR was attempted. Tesseract is installed on this machine but was not run; OCR output would be a different evidence surface whose fidelity could not be checked here, and it could not honestly support a complete-coverage recovery manifest.
- No empty extraction was submitted as `extracted-text` evidence, so the helper did not compute a readable-text failure for this item. The attempt is preserved as `image-only-pdf-extraction-attempt`.
- All 26 checks remain unknown, including whether the image carries alternative text.

### Checks left unknown on the two readable items

| Checks | Items | Evidence that was not supplied |
| --- | --- | --- |
| `seo-response`, `seo-index-controls`, `aio-crawler-policy` | both | HTTP responses, publisher intent, crawler policy (local files only) |
| `seo-canonical`, `seo-locales`, `seo-internal-links`, `portfolio-journey-links` | both | Canonical targets, locale map, link graph |
| `aeo-question-coverage`, `aeo-answer-context`, `portfolio-task-gaps` | both | A question set from real users |
| `aio-entity-consistency`, `portfolio-contradictions`, `portfolio-duplication` | both | Entity records and an inventory map; also blocked by the unread `image-only.pdf` |
| `geo-observed-presence`, `geo-answer-accuracy`, `geo-cohort-validity` | both | AI response observations (unmeasured, not zero) |
| `quality-task-fit`, `seo-metadata`, `aio-retrievable-facts` | `document.pdf` | An audience or intended user task for the export-policy document |
| `quality-accessible-media`, `seo-structured-data`, `seo-rendering` | `document.pdf` | The text-layer extraction does not inventory images, alternative text, metadata or scripts |
| `quality-freshness`, `seo-metadata` | `render.html` | An effective date or version for the task; publisher intent for the page |

## 6. How the evidence was obtained

All evidence was derived from the original files during this audit.

| Surface | Tool | Notes |
| --- | --- | --- |
| Raw HTML | Skill helper `start` | Source text only; scripts not executed |
| Rendered DOM | Google Chrome 157.0.8103.79, headless, driven over the DevTools protocol | Fresh temporary profile, removed afterwards; default sandbox left on; `file://` URL of the target only |
| PDF text | macOS PDFKit (bundle 1451.3.3, macOS 26.3) through a small Swift script | Text layer only; no OCR |
| Owner context | The audit request | Preserved as attributed evidence; an approved comparison basis, not independent verification |

The scripts are in `tools/`, their raw outputs in `extraction/`, and the two review bundles in `bundles/`. No optional extraction step errored: the render capture and both PDFKit runs exited normally. The only extraction shortfall is the absent text layer in `image-only.pdf`.

## 7. Recovery steps

1. **`image-only.pdf`:** supply a text transcript of the page, or authorise an OCR run whose output a person checks against the page image. Then start a fresh run, submit the text through the same attributed recovery, and review its checks. If the page is an informative image, also supply its intended alternative text.
2. **`render.html`:** after the script is corrected, repeat the isolated-browser capture described in section 3 and re-review `quality-task-fit`, `seo-rendering` and `aio-retrievable-facts`.
3. **`document.pdf`:** supply the intended audience and task, and a media and metadata inventory of the PDF, to resolve the task-fit, media and metadata checks.
4. **Both readable items:** supply publisher intent and, if the content is published, HTTP captures, canonical and locale declarations, the link graph and a real question set.
5. **Visibility:** generative-visibility checks need response-level AI observations with prompts, surfaces and dates. Until then they are unmeasured.

## 8. Quotation check

Source quotations in this narrative are listed in `quote-ledger.json` and checked by the helper's `verify-quotes`; the receipt is `quote-receipt.json`. The receipt covers the submitted spans only. Short phrases repeated from those spans in running text (for example "Open Billing.") are not separate ledger entries. The Vietnamese glosses in section 4 are the reviewer's translations, not quotations.
