// Builds review bundle 2: host semantic assessments and the persisted finding. Judgments are the reviewer's.
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
const [runDir, outFile] = process.argv.slice(2);
const lines = async (f) => (await readFile(f, "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const inventory = await lines(path.join(runDir, "inventory.jsonl"));
const evidence = await lines(path.join(runDir, "evidence.jsonl"));
const item = (n) => inventory.find((i) => i.path.endsWith("/targets/" + n)).itemId;
const H = item("render.html"), D = item("document.pdf");
const raw = evidence.find((e) => e.itemId === H && e.kind === "content" && e.method === "local-file").evidenceId;
const reviewer = "Claude Fable 5.2 (claude-fable-5-2), content-search-audit host agent";
const reviewedAt = new Date().toISOString();
const r = (itemId, ruleId, status, evidenceIds, reason) => ({ itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt });
const dom = "render-html-rendered-dom", rtext = "render-html-rendered-text", prov = "render-html-render-provenance";
const task = "render-html-owner-task-context", hclaim = "render-html-owner-task-claim-source";
const dc = "document-pdf-content", dpol = "document-pdf-owner-export-policy";
const reviews = [
  r(H, "quality-task-fit", "fail", [raw, task, dom, rtext, prov],
    "Owner-approved task has two steps: open Billing, then select Disable renewal. The raw source main#task carries both ('Open Billing. Select Disable renewal.'), but after the owner-confirmed ready signal the rendered main#task and visible body text read only 'Open Billing.'. A reader of the rendered page is not told to select Disable renewal, so the page as rendered does not enable the approved task. The raw-source component is clean. Local headless Chrome capture only."),
  r(H, "seo-rendering", "fail", [raw, dom, prov],
    "The inline script replaces the main#task text. Important source content ('Select Disable renewal.') present in raw HTML is absent from the rendered DOM captured at the ready signal; the rest (lang, title, CSP meta, 'Open Billing.') is unchanged apart from the added data-audit-ready attribute. This compares raw source with a local headless Chrome render; no search-engine rendering or indexing evidence was supplied, so engine behaviour stays unobserved."),
  r(H, "aio-retrievable-facts", "fail", [raw, task, dom, rtext],
    "The concrete fact needed for the approved task, the 'Select Disable renewal' step, is locatable only in the raw source capture. In the rendered capture the readable text is 'Open Billing.' alone, so the needed fact is not consistently present in the readable captured content: a reader or retriever working from the rendered page gets an incomplete instruction, while one reading raw HTML gets both steps. Which surface any engine uses is not evidenced; this does not measure retrieval or citation."),
  r(H, "quality-claims", "pass", [raw, hclaim, dom],
    "Material instructional claims present on either surface were compared with the owner-approved renewal task. Raw source: 'Open Billing.' and 'Select Disable renewal.' both match the approved steps. Rendered: 'Open Billing.' matches the first approved step. No stated claim contradicts or exceeds the approved task; the omitted rendered step is an incompleteness assessed under quality-task-fit, not an inaccurate claim. Basis is the owner statement, not independent verification of the product UI."),
  r(H, "aeo-answer-evidence", "pass", [raw, hclaim, dom],
    "The item's answer claims are the task steps. Each step that appears (both in raw source, the first in the rendered DOM) is supported by the owner-approved renewal task. No unsupported answer claim was found. Completeness of the rendered answer is a separate judgment (failed under quality-task-fit); question coverage and answer context remain unknown without a question set."),
  r(H, "quality-accessible-media", "not-applicable", [raw, "render-html-media-inventory", dom],
    "Media inventory over both captured surfaces found zero img, picture, video, audio, svg, canvas, object, embed or iframe elements and no CSS background images. The item contains no informative media needing a text alternative or transcript."),
  r(H, "seo-structured-data", "not-applicable", [raw, "render-html-schema-extraction", dom],
    "Schema extraction over raw source and rendered DOM found no JSON-LD, microdata or RDFa markers, so there is no structured data to compare with visible claims. Whether markup would be useful is not judged: no feature-eligibility evidence was supplied and absence of markup is not treated as a defect."),
  r(H, "seo-metadata", "unknown", [raw, task, dom],
    "Observed on both surfaces: title 'Controlled render fixture', no meta description, no heading elements. The title names the fixture rather than the renewal task. Whether that is a defect depends on publisher intent for this controlled fixture (whether it is meant to be a discoverable help page), which was not supplied. Left unresolved; recorded as an observation, not a finding."),
  r(H, "quality-freshness", "unknown", [raw, hclaim],
    "The content states no date, version or market, and the owner statement gives the approved task without an effective date or product version. The steps match the task as approved at audit time, but applicability of a UI path over time cannot be judged from the supplied evidence."),
  r(D, "quality-claims", "pass", [dc, dpol],
    "All material claims in the extracted text were compared with the owner-approved export policy. Page 1 (English): at most 5000 records per single export; applies to current VN plans. Page 2 (Vietnamese): each export is at most 5000 records; no additional payment is needed. Each matches the approved policy (current VN plans, at most 5000 records per export, no extra charge). The English page does not mention the charge and the Vietnamese page does not mention plan scope; the owner states the language pages may emphasise different aspects and translation completeness is not required, so these are not defects. Text-layer extraction only; basis is the owner statement."),
  r(D, "quality-freshness", "pass", [dc, dpol],
    "The only applicability statement in the document, 'Applies to current VN plans.', matches the market and plan scope of the approved policy as supplied at audit time. No dated or versioned fact in the extracted text conflicts with it. The document text carries no effective date; this pass does not establish how long the policy remains current."),
  r(D, "aeo-answer-evidence", "pass", [dc, dpol],
    "The decision-relevant answer claims (record limit per export, plan scope, no extra payment) are each supported by the owner-approved export policy with matching market and scope. No unsupported answer claim was found on either page. Question coverage and answer context remain unknown without a question set."),
  r(D, "quality-task-fit", "unknown", [dc],
    "No audience or intended user task for the export-policy document was supplied; the owner statement is a policy (claim source) and a translation-completeness allowance, not a task. Fit cannot be judged without it."),
];
const findings = [{
  findingId: "render-drops-disable-renewal-step",
  title: "Rendered page drops the required 'Select Disable renewal' step that the raw HTML contains",
  affectedItemIds: [H], ruleIds: ["quality-task-fit", "seo-rendering", "aio-retrievable-facts"], dimensions: ["quality", "seo", "aio"],
  evidenceIds: [raw, dom, rtext, prov, task],
  severity: "high", confidence: "high", classification: "observed",
  action: "update",
  actionReason: "Raw source and rendered DOM of the same file disagree on a step the owner-approved task requires; the rendered text is what a browser user reads once rendering has finished.",
  remediation: "In targets/render.html, change the inline script so that main#task still reads 'Open Billing. Select Disable renewal.' when the ready signal is set (for example, stop overwriting the element text, or write both steps). Proposal only; this audit did not modify the file.",
  verification: "Open the revised file in an isolated browser profile, wait until document.documentElement.dataset.auditReady === 'true' (string comparison), then confirm the main#task text contains both 'Open Billing.' and 'Select Disable renewal.' and matches the raw source text.",
  ownerRole: "Content owner with front-end developer", effort: "small",
}];
await writeFile(outFile, JSON.stringify({ reviews, findings }, null, 2) + "\n", { flag: "wx" });
