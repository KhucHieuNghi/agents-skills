// Builds review bundle 1: attributed extraction evidence, PDF recovery, rendered capture and owner context.
// No semantic verdicts. Reads original targets only to hash them.
import { createHash } from "node:crypto";
import { readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";
const [project, runDir, outFile] = process.argv.slice(2);
const sha = (v) => createHash("sha256").update(v).digest("hex");
const lines = async (f) => (await readFile(f, "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const inventory = await lines(path.join(runDir, "inventory.jsonl"));
const evidence0 = await lines(path.join(runDir, "evidence.jsonl"));
const item = (name) => inventory.find((i) => i.path.endsWith("/targets/" + name));
const H = item("render.html"), D = item("document.pdf"), I = item("image-only.pdf");
const rawHtml = evidence0.find((e) => e.itemId === H.itemId && e.kind === "content");
const reviewer = "Claude Fable 5.2 (claude-fable-5-2), content-search-audit host agent";
const now = new Date().toISOString();
const artifacts = {}, evidence = [];
function add({ id, itemId, kind, value, encoding = "utf8", method, collectedAt, locator, limitations, sources = [], ext }) {
  const artifact = `evidence/${id}.${ext ?? (encoding === "json" ? "json" : "txt")}`;
  const bytes = encoding === "json" ? JSON.stringify(value, null, 2) : value;
  artifacts[artifact] = bytes;
  evidence.push({ evidenceId: id, itemId, method, collectedAt, locator, snapshotHash: sha(bytes), byteLength: Buffer.byteLength(bytes),
    redaction: "none; authorized controlled fixture content retained locally", limitations, kind, value, artifact, encoding, sourceEvidenceIds: sources });
  return id;
}
// ---------- PDFs (macOS PDFKit text layer) ----------
const pdf = async (name) => {
  const src = await readFile(path.join(project, "targets", name));
  const f = path.join(project, "audits/content-search/extraction", name.replace(".pdf", ".pdfkit.json"));
  return { src, out: JSON.parse(await readFile(f, "utf8")), at: (await stat(f)).mtime.toISOString(), file: f };
};
const d = await pdf("document.pdf"), im = await pdf("image-only.pdf");
const extractor = (o) => ({ name: "macOS PDFKit PDFPage.string via tools/pdfkit-extract.swift (text layer only, no OCR)",
  version: `PDFKit bundle ${o.pdfKitBundleVersion}; macOS ${o.operatingSystem}; Apple Swift 6.2` });
const dLimits = ["Text-layer extraction only; no OCR and no visual comparison of the rendered pages was performed.",
  "Reading order is PDFKit's and was not independently verified.",
  "Images, figures, alternative text, links, document JavaScript and HTTP headers are not captured by this extraction.",
  "Page count, completeness and text fidelity are attributed assertions of the extractor run, not independent verification."];
const manifest = { schemaVersion: 1, sourceSha256: sha(d.src), sourceByteLength: d.src.length, extractor: extractor(d.out),
  pageCount: d.out.pageCount, pages: d.out.pages.map((p) => ({ page: p.page, text: p.text })), coverage: "complete", limitations: dLimits };
const joined = manifest.pages.map((p) => p.text).join("\f");
const dLoc = D.path;
add({ id: "document-pdf-extraction-manifest", itemId: D.itemId, kind: "extraction-provenance", encoding: "json", value: manifest,
  method: "pdfkit-text-layer-extraction", collectedAt: d.at, locator: `${dLoc} (pages 1-2)`, limitations: dLimits });
add({ id: "document-pdf-content", itemId: D.itemId, kind: "content", value: joined, method: "pdfkit-text-layer-extraction", collectedAt: d.at,
  locator: `${dLoc} (pages 1-2, pages joined with form feed)`, limitations: dLimits, sources: ["document-pdf-extraction-manifest"] });
add({ id: "document-pdf-extracted-text", itemId: D.itemId, kind: "extracted-text", value: joined, method: "pdfkit-text-layer-extraction", collectedAt: d.at,
  locator: `${dLoc} (pages 1-2, pages joined with form feed)`, limitations: dLimits, sources: ["document-pdf-content"] });
add({ id: "image-only-pdf-extraction-attempt", itemId: I.itemId, kind: "extraction-attempt", encoding: "json",
  value: { sourceSha256: sha(im.src), sourceByteLength: im.src.length, extractor: extractor(im.out), outcome: "no-text-layer-returned",
    pageCount: im.out.pageCount, pages: im.out.pages.map((p) => ({ page: p.page, characterCount: p.characterCount, stringWasNil: p.stringWasNil, mediaBox: p.mediaBox })),
    documentAttributes: im.out.documentAttributes,
    inertByteInspection: { method: "pattern search over uncompressed PDF dictionary bytes; compressed streams not decoded",
      imageXObjectMarkers: 2, imageDimensionMarkers: "/Width 800, /Height 100", fontMarkers: 0, structTreeRootMarkers: 1, altTextMarkersFound: 0 },
    ocr: "not attempted; no OCR output exists in this run",
    interpretation: "PDFKit returned no characters for the single page. The file carries raster image objects and no font objects in its uncompressed dictionaries, which is consistent with content present only as pixels. This is NOT evidence that the page is empty." },
  method: "pdfkit-text-layer-extraction-attempt", collectedAt: im.at, locator: `${I.path} (page 1)`,
  limitations: ["Empty text-layer output is an extraction limitation, not proof of empty source content.", "No OCR or visual transcription was performed; the pixel content is unread.",
    "Not usable for attributed recovery: the recovery contract requires nonempty extracted text for every page.",
    "Byte-pattern inspection does not decode compressed streams, so absence of an /Alt marker does not prove alternative text is absent."] });
// ---------- HTML rendered capture (isolated headless Chrome) ----------
const capFile = path.join(project, "audits/content-search/extraction/render.chrome-capture.json");
const cap = JSON.parse(await readFile(capFile, "utf8"));
if (!cap.ok || cap.readySignalObserved !== true || cap.auditReadyValue !== "true") throw new Error("Rendered capture not usable");
const rLimits = ["Local headless Google Chrome capture of a file:// URL in a fresh temporary profile; not search-engine or AI-crawler rendering.",
  "Captured once, after the owner-confirmed ready signal document.documentElement.dataset.auditReady === 'true'; later mutations are not observed.",
  "Does not establish HTTP delivery, index status or behaviour in other browsers."];
const { outerHTML, ...prov } = cap;
add({ id: "render-html-render-provenance", itemId: H.itemId, kind: "render-provenance", encoding: "json", value: prov, method: "headless-chrome-cdp-capture",
  collectedAt: cap.capturedAt, locator: cap.url, limitations: rLimits, sources: [rawHtml.evidenceId] });
add({ id: "render-html-rendered-dom", itemId: H.itemId, kind: "rendered-dom", value: outerHTML, method: "headless-chrome-cdp-capture", collectedAt: cap.capturedAt,
  locator: `${cap.url} (document.documentElement.outerHTML at ready signal)`, limitations: rLimits, sources: ["render-html-render-provenance", rawHtml.evidenceId] });
add({ id: "render-html-rendered-text", itemId: H.itemId, kind: "extracted-text", value: cap.bodyInnerText, method: "headless-chrome-cdp-capture", collectedAt: cap.capturedAt,
  locator: `${cap.url} (document.body.innerText at ready signal)`, sources: ["render-html-rendered-dom"],
  limitations: [...rLimits, "Rendered visible text only; the raw source text differs and is retained separately as content evidence."] });
// Derived inert inspections of raw source text and rendered DOM text (no script execution).
const count = (s, re) => (s.match(re) ?? []).length;
const surfaces = { rawSource: rawHtml.value, renderedDom: outerHTML };
const mediaRe = { img: /<img\b/gi, picture: /<picture\b/gi, video: /<video\b/gi, audio: /<audio\b/gi, svg: /<svg\b/gi, canvas: /<canvas\b/gi, object: /<object\b/gi, embed: /<embed\b/gi, iframe: /<iframe\b/gi, cssBackgroundImage: /background(-image)?\s*:/gi };
const schemaRe = { jsonLdScript: /<script[^>]+type\s*=\s*["']?application\/ld\+json/gi, microdataItemscope: /\bitemscope\b/gi, microdataItemtype: /\bitemtype\s*=/gi, rdfaTypeof: /\btypeof\s*=/gi, rdfaVocab: /\bvocab\s*=/gi };
const tally = (res) => Object.fromEntries(Object.entries(surfaces).map(([k, s]) => [k, Object.fromEntries(Object.entries(res).map(([n, re]) => [n, count(s, re)]))]));
const derivedLimits = ["Derived by pattern counts over the retained raw source text and the retained rendered DOM text; no target code was executed for this derivation.", "Covers only the two captured surfaces."];
add({ id: "render-html-media-inventory", itemId: H.itemId, kind: "media-inventory", encoding: "json", value: { method: "element pattern counts", counts: tally(mediaRe), mediaElementsFound: 0 },
  method: "derived-pattern-inspection", collectedAt: now, locator: "render.html raw source and rendered DOM snapshots", limitations: derivedLimits, sources: [rawHtml.evidenceId, "render-html-rendered-dom"] });
add({ id: "render-html-schema-extraction", itemId: H.itemId, kind: "schema-extraction", encoding: "json", value: { method: "structured-data marker pattern counts", counts: tally(schemaRe), structuredDataBlocksFound: 0 },
  method: "derived-pattern-inspection", collectedAt: now, locator: "render.html raw source and rendered DOM snapshots", limitations: derivedLimits, sources: [rawHtml.evidenceId, "render-html-rendered-dom"] });
for (const id of ["render-html-media-inventory", "render-html-schema-extraction"]) {
  const v = evidence.find((e) => e.evidenceId === id).value;
  if (Object.values(v.counts).some((s) => Object.values(s).some((n) => n !== 0))) throw new Error(`${id}: nonzero count; revise claimed totals`);
}
// ---------- Owner-supplied context (task statement) ----------
const ctxLimits = ["Supplied by the audit requester in the task statement; an approved comparison basis for this audit, not independently verified platform or business behaviour.",
  "No effective date, product version or source document accompanies the statement beyond its wording."];
const general = "Also supplied: 'No search-engine rendering, indexing, analytics, AI observation or feature eligibility evidence is supplied.' The targets are described as controlled author-generated fixtures.";
const renewal = "Owner/task statement captured for this audit: 'Approved renewal task requires opening Billing and selecting Disable renewal.' Render readiness: 'The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering.' " + general;
const exportPolicy = "Owner/task statement captured for this audit: 'Approved export policy: current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.' " + general;
add({ id: "render-html-owner-task-context", itemId: H.itemId, kind: "audience-context", value: renewal, method: "owner-supplied-task-statement", collectedAt: now,
  locator: "audit request, user message of this session (renewal task and ready-signal statements)", sources: [],
  limitations: [...ctxLimits, "States the approved user task only; no audience segment, market or question set is supplied."] });
add({ id: "render-html-owner-task-claim-source", itemId: H.itemId, kind: "claim-sources", value: renewal, method: "owner-supplied-task-statement", collectedAt: now,
  locator: "audit request, user message of this session (renewal task statement)", limitations: ctxLimits, sources: [] });
add({ id: "document-pdf-owner-export-policy", itemId: D.itemId, kind: "claim-sources", value: exportPolicy, method: "owner-supplied-task-statement", collectedAt: now,
  locator: "audit request, user message of this session (export policy and EN/VI statements)", limitations: ctxLimits, sources: [] });
const bundle = { reviews: [], evidence, artifacts,
  collectionRecoveries: [{ itemId: D.itemId, manifestEvidenceId: "document-pdf-extraction-manifest", contentEvidenceId: "document-pdf-content", textEvidenceId: "document-pdf-extracted-text",
    reviewer, reviewedAt: now,
    reason: "PDFKit reported 2 pages and returned nonempty text-layer strings for both (89 and 82 characters; English page 1, Vietnamese page 2). Host read both page texts. Text layer only: no OCR, no visual page comparison, reading order unverified, images/alt text/links not captured." }] };
await writeFile(outFile, JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ evidence: evidence.length, items: { H: H.itemId, D: D.itemId, I: I.itemId } }));
