import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
const [root, outFile] = process.argv.slice(2);
const sha = (b) => createHash("sha256").update(b).digest("hex");
const report = "audits/content-search/audit-narrative.md";
const reportBytes = await readFile(path.join(root, report));
const reportLines = reportBytes.toString("utf8").split("\n");
const E = "audits/content-search/run-03-reviewed/evidence/";
const specs = [
  ["F1-owner-task", E + "render-html-owner-task-context.txt", "Approved renewal task requires opening Billing and selecting Disable renewal."],
  ["F1-raw-steps", "targets/render.html", `<main id="task">Open Billing. Select Disable renewal.</main>`],
  ["F1-raw-script", "targets/render.html", `setTimeout(() => { document.getElementById('task').textContent = 'Open Billing.'; document.documentElement.dataset.auditReady = 'true'; }, 50);`],
  ["F1-rendered", E + "render-html-rendered-dom.txt", `<main id="task">Open Billing.</main>`],
  ["C-owner-policy", E + "document-pdf-owner-export-policy.txt", "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge."],
  ["C-en-limit", E + "document-pdf-content.txt", "A single export contains at most 5000 records."],
  ["C-en-scope", E + "document-pdf-content.txt", "Applies to current VN plans."],
  ["C-vi-limit", E + "document-pdf-content.txt", "Mỗi lần xuất tối đa 5000 bản ghi."],
  ["C-vi-charge", E + "document-pdf-content.txt", "Không cần thanh toán thêm."],
  ["O-title", "targets/render.html", "<title>Controlled render fixture</title>"],
];
const quotes = [];
for (const [quoteId, source, quote] of specs) {
  const bytes = await readFile(path.join(root, source));
  const lines = bytes.toString("utf8").split("\n");
  const hits = lines.map((l, i) => (l.includes(quote) ? i + 1 : 0)).filter(Boolean);
  if (hits.length !== 1) throw new Error(`${quoteId}: expected one source line, got ${hits.length}`);
  const label = path.basename(source), locator = `${label}:${hits[0]}`;
  const rl = reportLines.map((l, i) => (l.includes(quote) && l.includes(locator) ? i + 1 : 0)).filter(Boolean);
  if (rl.length !== 1) throw new Error(`${quoteId}: expected one report line with quote and locator, got ${rl.length}`);
  quotes.push({ quoteId, source, sourceLabel: label, sourceHash: sha(bytes), startLine: hits[0], endLine: hits[0], reportStartLine: rl[0], reportEndLine: rl[0], normalization: "exact", quote });
}
await writeFile(outFile, JSON.stringify({ root, report, reportHash: sha(reportBytes), quotes }, null, 2) + "\n");
