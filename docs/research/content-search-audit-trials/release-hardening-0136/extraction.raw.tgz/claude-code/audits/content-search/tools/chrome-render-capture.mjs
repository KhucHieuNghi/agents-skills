// Captures the rendered DOM of one local HTML file in a fresh, isolated headless Chrome profile.
// Default sandboxing is left intact. Waits for the owner-confirmed ready signal before capture.
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";
const [target, outFile, profileParent] = process.argv.slice(2);
const chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const READY = "document.documentElement.dataset.auditReady === 'true'";
const profile = await mkdtemp(path.join(profileParent, "chrome-profile-"));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const result = { target, url: pathToFileURL(target).href, readyExpression: READY, startedAt: new Date().toISOString(),
  chromeFlags: ["--headless=new", `--user-data-dir=<fresh temporary profile>`, "--remote-debugging-port=0", "--no-first-run",
    "--no-default-browser-check", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-extensions", "about:blank"] };
const proc = spawn(chrome, result.chromeFlags.map((f) => f.startsWith("--user-data-dir") ? `--user-data-dir=${profile}` : f), { stdio: ["ignore", "ignore", "pipe"] });
let stderr = ""; proc.stderr.on("data", (d) => (stderr += d));
let ws;
try {
  let port;
  for (let i = 0; i < 100 && !port; i++) {
    await sleep(100);
    try { port = (await readFile(path.join(profile, "DevToolsActivePort"), "utf8")).split("\n")[0]; } catch {}
  }
  if (!port) throw new Error("Chrome did not expose a DevTools port");
  const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  const page = targets.find((t) => t.type === "page");
  ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pending = new Map(); const requests = []; const consoleMessages = [];
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
    if (msg.method === "Network.requestWillBeSent") requests.push(msg.params.request.url);
    if (msg.method === "Runtime.exceptionThrown") consoleMessages.push(msg.params.exceptionDetails.text);
  };
  const send = (method, params = {}) => new Promise((res, rej) => {
    const n = ++id; pending.set(n, (msg) => (msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result)));
    ws.send(JSON.stringify({ id: n, method, params }));
  });
  const evaluate = async (expression) => (await send("Runtime.evaluate", { expression, returnByValue: true })).result.value;
  result.browser = await send("Browser.getVersion");
  await send("Network.enable"); await send("Runtime.enable"); await send("Page.enable");
  const nav = await send("Page.navigate", { url: result.url });
  if (nav.errorText) throw new Error(`Navigation failed: ${nav.errorText}`);
  const t0 = Date.now(); let ready = false;
  while (Date.now() - t0 < 10000) { ready = (await evaluate(READY)) === true; if (ready) break; await sleep(25); }
  result.readySignalObserved = ready; result.readyWaitMs = Date.now() - t0;
  if (!ready) throw new Error("Ready signal not observed within 10000 ms");
  result.capturedAt = new Date().toISOString();
  result.location = await evaluate("location.href");
  result.auditReadyValue = await evaluate("document.documentElement.dataset.auditReady");
  result.title = await evaluate("document.title");
  result.taskTextContent = await evaluate("document.getElementById('task') && document.getElementById('task').textContent");
  result.bodyInnerText = await evaluate("document.body.innerText");
  result.outerHTML = await evaluate("document.documentElement.outerHTML");
  result.outerHTMLSha256 = createHash("sha256").update(result.outerHTML).digest("hex");
  result.networkRequests = requests; result.exceptions = consoleMessages; result.ok = true;
} catch (e) { result.ok = false; result.error = String(e?.message ?? e); }
finally {
  try { ws?.close(); } catch {}
  proc.kill("SIGTERM"); await new Promise((r) => { proc.once("exit", r); setTimeout(r, 5000); });
  await sleep(300); await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
  result.profileRemoved = true; result.finishedAt = new Date().toISOString(); result.chromeStderrTail = stderr.slice(-1500);
  await writeFile(outFile, JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
}
console.log(JSON.stringify({ ok: result.ok, error: result.error, ready: result.readySignalObserved }));
