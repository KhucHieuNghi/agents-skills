import Foundation
import PDFKit
import Vision
for path in CommandLine.arguments.dropFirst() {
 let url = URL(fileURLWithPath: path)
 guard let doc = PDFDocument(url: url) else { print("Cannot open \(path)"); continue }
 var pages: [[String:Any]] = []
 for i in 0..<doc.pageCount {
   guard let p = doc.page(at: i) else { continue }
   var row: [String:Any] = ["page":i+1,"text":p.string ?? ""]
   if (p.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
     let img = p.thumbnail(of: CGSize(width: 2400,height: 2400),for:.mediaBox)
     var rect = CGRect(origin: .zero,size: img.size)
     if let cg = img.cgImage(forProposedRect:&rect,context:nil,hints:nil) {
       let req = VNRecognizeTextRequest()
       req.recognitionLevel = .accurate
       do {
         try VNImageRequestHandler(cgImage:cg,options:[:]).perform([req])
         row["ocr"] = (req.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator:"\n")
       } catch { row["ocrError"] = String(describing:error) }
     }
   }
   pages.append(row)
 }
 let json = try JSONSerialization.data(withJSONObject:["pages":pages,"pageCount":doc.pageCount],options:[.prettyPrinted,.sortedKeys])
 try json.write(to:URL(fileURLWithPath:"audit-work/"+url.lastPathComponent+".json"))
}
