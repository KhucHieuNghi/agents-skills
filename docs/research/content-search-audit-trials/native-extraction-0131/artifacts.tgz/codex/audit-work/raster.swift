import Foundation
import PDFKit
print(Bundle(for: PDFDocument.self).object(forInfoDictionaryKey:"CFBundleVersion") ?? "unknown")
for path in CommandLine.arguments.dropFirst() {
 let url = URL(fileURLWithPath:path)
 let d = PDFDocument(url:url)!
 for i in 0..<d.pageCount {
  let p = d.page(at:i)!
  let image = p.thumbnail(of:CGSize(width:1400,height:1400),for:.mediaBox)
  let png = NSBitmapImageRep(data:image.tiffRepresentation!)!.representation(using:.png,properties:[:])!
  try png.write(to:URL(fileURLWithPath:"audit-work/\(url.lastPathComponent)-page-\(i+1).png"))
 }
}
