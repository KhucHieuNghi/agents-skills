import fs from "node:fs";
import {createHash} from "node:crypto";
const hash=p=>createHash("sha256").update(fs.readFileSync(p)).digest("hex");
const report="audit-narrative.md", reportLines=fs.readFileSync(report,"utf8").split("\n");
const q=[
 ["renewal-source","targets/render.html","render.html",1,1,"Open Billing. Select Disable renewal."],
 ["english-policy","audit-reviewed/evidence/policy-content.txt","policy-content.txt",2,3,"A single export contains at most 5000 records. Applies to current VN plans."],
 ["vietnamese-policy","audit-reviewed/evidence/policy-content.txt","policy-content.txt",4,5,"Mỗi lần xuất tối đa 5000 bản ghi. Không cần thanh toán thêm."],
];
const quotes=q.map(([quoteId,source,sourceLabel,startLine,endLine,quote])=>{
 const reportStartLine=reportLines.findIndex(l=>l.includes(quote))+1;
 return {quoteId,source,sourceLabel,sourceHash:hash(source),startLine,endLine,reportStartLine,reportEndLine:reportStartLine,normalization:"whitespace",quote};
});
const checks=fs.readFileSync("audit-reviewed/checks.jsonl","utf8").trim().split("\n").map(JSON.parse);
console.log(checks.reduce((m,c)=>(m[c.status]=(m[c.status]||0)+1,m),{}));
fs.writeFileSync("audit-work/quote-ledger.json",JSON.stringify({root:process.cwd(),report,reportHash:hash(report),quotes},null,2));
