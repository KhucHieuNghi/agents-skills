import fs from "node:fs";
import {createHash} from "node:crypto";
const read=(p)=>fs.readFileSync(p,"utf8"), hash=(x)=>createHash("sha256").update(x).digest("hex"), json=x=>JSON.stringify(x,null,2)+"\n";
const write=(p,x)=>fs.writeFileSync(p,x);
const lines=p=>read(p).trim().split("\n").map(JSON.parse);
const [pdf,html,img]=lines("audit-initial/inventory.jsonl");
const [raw]=lines("audit-initial/evidence.jsonl");
const now=new Date().toISOString(), reviewer="Codex local evidence review";
const newBundle=()=>({artifacts:{},evidence:[],reviews:[],collectionRecoveries:[]});
const b=newBundle();
function ev(bundle,item,kind,id,value,locator,method,limitations,sourceEvidenceIds=[]){
 const encoding=typeof value==="string"?"utf8":"json", str=encoding==="json"?json(value):value, artifact="evidence/"+id+(encoding==="json"?".json":".txt");
 bundle.artifacts[artifact]=str;
 bundle.evidence.push({evidenceId:id,itemId:item.itemId,kind,value,encoding,artifact,locator,method,limitations,sourceEvidenceIds,snapshotHash:hash(str),byteLength:Buffer.byteLength(str),collectedAt:now,redaction:"none"});
 return id;
}
const framework=read("audit-work/pdfkit-version.txt").trim();
const doc=JSON.parse(read("audit-work/document.pdf.json")), imgProbe=JSON.parse(read("audit-work/image-only.pdf.json"));
if(doc.pageCount!==2 || imgProbe.pageCount!==1 || imgProbe.pages[0].text.trim()) throw Error("Unexpected extraction");
const raster="audit-work/image-only.pdf-page-1.png";
const transcript="Image-only document: a separate OCR capability is needed.";
function recover(item,prefix,doc,extractor,limitations){
 const bytes=fs.readFileSync(item.path);
 const value={schemaVersion:1,sourceSha256:hash(bytes),sourceByteLength:bytes.length,extractor,pageCount:doc.pageCount,pages:doc.pages,coverage:"complete",limitations};
 const text=value.pages.map(p=>p.text).join("\f");
 const manifestEvidenceId=ev(b,item,"extraction-provenance",prefix+"-manifest",value,item.path,extractor.name,limitations);
 const contentEvidenceId=ev(b,item,"content",prefix+"-content",text,item.path+" pp. 1–"+doc.pageCount,extractor.name,limitations,[manifestEvidenceId]);
 const textEvidenceId=ev(b,item,"extracted-text",prefix+"-text",text,item.path+" pp. 1–"+doc.pageCount,extractor.name,limitations,[contentEvidenceId]);
 b.collectionRecoveries.push({itemId:item.itemId,manifestEvidenceId,contentEvidenceId,textEvidenceId,reviewer,reviewedAt:now,reason:"All page records are in order and checked against local page rasters. "+limitations.join(" ")});
 return contentEvidenceId;
}
const pc=recover(pdf,"policy",doc,{name:"Apple PDFKit PDFPage.string",version:framework},["Text layer recovered on both pages and visually cross-checked against fresh PDFKit rasters; no accessibility or indexing inference."]);
const ic=recover(img,"image",{pageCount:1,pages:[{page:1,text:transcript}]},{name:"Codex manual visual transcription of Apple PDFKit raster",version:"1 (transcription procedure); PDFKit "+framework},["One complete visible sentence transcribed from "+raster+" (SHA-256 "+hash(fs.readFileSync(raster))+"). Native PDFKit text extraction returned empty and Vision OCR returned nilError. The transcript is an audit derivative, not a native text layer or source accessibility remediation."]);
const initialHtml=read("targets/render.html").match(/<main id="task">([^<]+)<\/main>/)[1];
ev(b,html,"extracted-text","html-static-task",initialHtml,"targets/render.html:1, main#task","manual inert source extraction",["Initial main text only; no rendered DOM."],[raw.evidenceId]);
const chrome="Fresh isolated Google Chrome profile; headless --dump-dom with local file, DNS blocked, background networking disabled and no sandbox overrides. Chrome aborted with signal 6 (exit 134). stdout and stderr were empty; cause not established. No ready signal or DOM was captured.";
ev(b,html,"collection-diagnostic","chrome-attempt",chrome,"audit-work/chrome.log and audit-work/rendered.html","local process outcome",["No browser or search-engine render claim."],[raw.evidenceId]);
const ownerTask="The approved renewal task requires opening Billing and selecting Disable renewal. The owner confirms document.documentElement.dataset.auditReady === true (string value true) denotes finished rendering.";
const ownerPolicy="Approved export policy: current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.";
function owner(item,kind,id,value){return ev(b,item,kind,id,value,"User task statement","owner-supplied fixture context",["Comparison basis only; not independent live verification."]);}
const task=owner(html,"audience-context","renewal-task",ownerTask);
const qh=owner(html,"question-set","renewal-question","Owner task operationalized: How do I disable renewal? Approved answer includes opening Billing and selecting Disable renewal.");
const claim=owner(pdf,"claim-sources","export-policy",ownerPolicy);
const pa=owner(pdf,"audience-context","export-audience",ownerPolicy);
const pq=owner(pdf,"question-set","export-questions","Owner policy operationalized: What is the single export limit for current VN plans, and is there an extra charge? Evaluate the bilingual PDF as one supplied item.");
const entity=owner(pdf,"entity-record","vn-plan-record",ownerPolicy);
const inv=ev(b,pdf,"inventory-map","policy-inventory-map","Full declared scope: rendered-renewal HTML source, two-page bilingual export-policy PDF, and one image-only PDF containing a transcription diagnostic. Only the bilingual PDF contains export claims; both pages say 5000 records per export, English gives current VN scope, Vietnamese specifies no extra charge.","config.json; document.pdf pp. 1–2; render.html:1; image-only.pdf p. 1","cross-item review",["Local inventory only; no independently served locale URLs."],[pc,ic,raw.evidenceId]);
const ib=fs.readFileSync(img.path).toString("latin1");
const structure=ib.match(/12 0 obj\s*<<[\s\S]*?>>\s*endobj/)[0];
if(/\/(Alt|ActualText)\b/.test(ib)) throw Error("Unexpected text alternative marker");
const media=ev(b,img,"media-inventory","image-figure",structure+"\nPDFKit page 1 native text: empty. PDFKit page 1 raster visibly contains the single informative sentence. No /Alt or /ActualText marker found in the PDF bytes.\n", "image-only.pdf p. 1, structure object 12","PDF structure and local raster inspection",["No assistive-technology interaction test."],[ic]);
write("audit-work/recovery-bundle.json",json(b));
const s=newBundle(); s.findings=[];
function check(item,ruleId,status,reason,...evidenceIds){s.reviews.push({itemId:item.itemId,ruleId,status,reason,evidenceIds,reviewer,reviewedAt:now});}
function finding(item,findingId,title,ruleIds,dimensions,evidenceIds,severity,remediation,verification,ownerRole){
 s.findings.push({findingId,title,affectedItemIds:[item.itemId],ruleIds,dimensions,evidenceIds,severity,confidence:"high",classification:"observed",remediation,verification,ownerRole,effort:"small"});
}
check(html,"quality-task-fit","fail","Source-level task defect: the sole task block initially provides both approved steps, but the timer callback replaces it with only the first and sets the ready marker immediately afterward. Browser behavior was not captured.",raw.evidenceId,task);
check(html,"seo-rendering","unknown",chrome,raw.evidenceId,"chrome-attempt");
for(const r of ["aeo-question-coverage","aeo-answer-context"])check(html,r,"unknown","Static markup answers the one approved task; the script would remove the decisive step. Completed-state answer assessment awaits an authorized ready DOM.",raw.evidenceId,qh);
check(html,"aio-retrievable-facts","unknown","Both steps are available in the inert markup; source mutation conflicts with it and completed DOM capture failed.",raw.evidenceId,task);
finding(html,"renewal-step-overwrite","Renewal script overwrites the step that disables renewal",["quality-task-fit"],["quality"],[raw.evidenceId,task],"high","Keep both approved instructions in the task element when the timer marks the document ready.","Capture the completed DOM in an isolated local browser with the owner-specified ready attribute equal to true, then verify the visible task includes both ordered steps.","Frontend owner");
for(const [rule,reason] of [
 ["quality-claims","Both language pages give the same 5000-record per-export cap; English limits it to current VN plans, and Vietnamese says no additional payment. Every policy assertion agrees with the owner-approved basis."],
 ["quality-freshness","The English page explicitly identifies current VN plans; the Vietnamese page states the same cap and no extra charge within the same document. All changing policy assertions match the owner-approved current scope for this fixture; no external applicability beyond it is inferred."],
 ["aeo-answer-evidence","The 5000-record limit on both pages and Vietnamese no-extra-payment clause are supported by approved policy; the English current-VN qualifier is already present."]
])check(pdf,rule,"pass",reason,pc,claim);
for(const r of ["aeo-question-coverage","aeo-answer-context"])check(pdf,r,"pass","As one bilingual document, the English page supplies the per-export cap and current VN scope, and the Vietnamese page supplies the same cap plus no additional charge. Both approved policy questions are answered across the supplied item; no standalone translation requirement.",pc,pq);
for(const r of ["quality-task-fit","aio-retrievable-facts"])check(pdf,r,"pass","The two fully checked text pages provide the policy facts for the supplied export task: current VN scope, 5000 records per export and no extra charge. This describes the document as supplied.",pc,pa);
check(pdf,"aio-entity-consistency","pass","Both components agree on units and cap, and all policy assertions agree with the supplied VN-plan record.",pc,entity);
check(pdf,"portfolio-duplication","pass","The overlapping cap is useful bilingual coverage; the two pages add complementary policy details and the other inventory items cover different purposes.",pc,inv);
check(pdf,"portfolio-contradictions","pass","Both language pages agree on the cap. The English market qualifier and the Vietnamese no-fee clause address different aspects. The other inventory items make no conflicting export-policy claim.",pc,entity,inv);
check(img,"quality-accessible-media","fail","Page 1 contains a meaningful sentence in a tagged Figure with no alternate or replacement text found, and native extraction yielded no readable text. The analyst transcript is external to the PDF.",ic,media);
finding(img,"image-text-alternative","Image-only PDF lacks a native text alternative for its visible sentence",["quality-accessible-media"],["quality"],[ic,media],"medium","Supply the sentence as real PDF text or provide an equivalent accessible alternative in the document.","Verify extraction of the sentence from the revised PDF itself and inspect the accessibility reading order or figure alternative.","Document owner");
write("audit-work/semantic-bundle.json",json(s));
