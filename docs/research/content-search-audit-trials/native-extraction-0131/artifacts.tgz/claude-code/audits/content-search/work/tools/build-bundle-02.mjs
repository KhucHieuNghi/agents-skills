// Builds review bundle 02: attributed PDF recovery + capture evidence. No semantic verdicts.
import { readFile, writeFile, stat } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
const [project] = process.argv.slice(2);
const W = path.join(project, "audits/content-search/work");
const run = path.join(project, "audits/content-search/run-01-initial");
const sha = (v) => createHash("sha256").update(v).digest("hex");
const inv = (await readFile(path.join(run, "inventory.jsonl"), "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const ev0 = (await readFile(path.join(run, "evidence.jsonl"), "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const id = (name) => inv.find((i) => i.path.endsWith("/" + name)).itemId;
const html = id("render.html"), doc = id("document.pdf"), img = id("image-only.pdf");
const htmlContent = ev0.find((e) => e.itemId === html && e.kind === "content");
const reviewer = "Claude (claude-fable-5-2), AI audit host; not a human domain reviewer";
const now = new Date().toISOString();
const artifacts = {}, evidence = [];
function add({ evidenceId, itemId, kind, artifact, value, encoding = "utf8", method, collectedAt, locator, limitations, sourceEvidenceIds = [] }) {
  const bytes = encoding === "json" ? JSON.stringify(value, null, 2) + "\n" : value;
  artifacts[artifact] = bytes;
  evidence.push({ evidenceId, itemId, method, collectedAt, locator, snapshotHash: sha(bytes), byteLength: Buffer.byteLength(bytes), redaction: "none; authorized source content retained locally", limitations, kind, value, artifact, encoding, sourceEvidenceIds });
}
// ---- document.pdf: native text layer via PDFKit
const docJsonPath = path.join(W, "pdf/document.pdfkit.json");
const d = JSON.parse(await readFile(docJsonPath, "utf8"));
const docBytes = await readFile(path.join(project, "targets/document.pdf"));
const docAt = (await stat(docJsonPath)).mtime.toISOString();
const docLimits = [
  "Native PDF text-layer extraction with Apple PDFKit PDFPage.string; no OCR was performed",
  "Reading order, line breaks and Unicode normalization are as returned by the extractor and were not independently verified against the visual page",
  "Page image XObject count was 0 on both pages; inline images and vector drawings were not enumerated",
  "Manifest assertions are host-attributed evidence, not independent verification of page count, completeness or text fidelity",
];
const pages = d.pages.map((p) => ({ page: p.page, text: p.text }));
const joined = pages.map((p) => p.text).join("\f");
add({ evidenceId: "document-pdf-extraction-manifest", itemId: doc, kind: "extraction-provenance", artifact: "evidence/document-pdf-extraction-manifest.json", encoding: "json",
  value: { schemaVersion: 1, sourceSha256: sha(docBytes), sourceByteLength: docBytes.length, extractor: { name: "Apple PDFKit PDFPage.string via auditor-authored Swift script (work/tools/pdfextract.swift)", version: "macOS 26.3 (25D125) system PDFKit; Apple Swift 6.2" }, pageCount: d.pageCount, pages, coverage: "complete", limitations: docLimits },
  method: "native-pdf-text-layer-extraction (PDFKit)", collectedAt: docAt, locator: "targets/document.pdf pages 1-2", limitations: docLimits });
add({ evidenceId: "document-pdf-recovered-content", itemId: doc, kind: "content", artifact: "evidence/document-pdf-recovered-content.txt", value: joined,
  method: "native-pdf-text-layer-extraction (PDFKit)", collectedAt: docAt, locator: "targets/document.pdf pages 1-2 (form feed separates pages)", limitations: docLimits, sourceEvidenceIds: ["document-pdf-extraction-manifest"] });
add({ evidenceId: "document-pdf-extracted-text", itemId: doc, kind: "extracted-text", artifact: "evidence/document-pdf-extracted-text.txt", value: joined,
  method: "native-pdf-text-layer-extraction (PDFKit)", collectedAt: docAt, locator: "targets/document.pdf pages 1-2 (form feed separates pages)", limitations: docLimits, sourceEvidenceIds: ["document-pdf-recovered-content"] });
add({ evidenceId: "document-pdf-pdfkit-diagnostics", itemId: doc, kind: "extraction-diagnostics", artifact: "evidence/document-pdf-pdfkit-diagnostics.json", encoding: "json", value: d,
  method: "PDFKit/CoreGraphics read-only inspection", collectedAt: docAt, locator: "targets/document.pdf", limitations: ["Raw extractor output including document info metadata and per-page resource counts; diagnostic only", "Annotation and image counts reflect what PDFKit/CoreGraphics exposed, not a full structural audit"] });
// ---- image-only.pdf: preserved attempt; NOT a recovery
const imgJsonPath = path.join(W, "pdf/image-only.pdfkit.json");
const im = JSON.parse(await readFile(imgJsonPath, "utf8"));
const imgBytes = await readFile(path.join(project, "targets/image-only.pdf"));
const imgAt = (await stat(imgJsonPath)).mtime.toISOString();
add({ evidenceId: "image-only-pdf-extraction-attempt", itemId: img, kind: "extraction-provenance", artifact: "evidence/image-only-pdf-extraction-attempt.json", encoding: "json",
  value: { outcome: "no-text-layer-returned", recovered: false, sourceSha256: sha(imgBytes), sourceByteLength: imgBytes.length, extractor: { name: "Apple PDFKit PDFPage.string via auditor-authored Swift script (work/tools/pdfextract.swift)", version: "macOS 26.3 (25D125) system PDFKit; Apple Swift 6.2" }, ocrAttempted: false, pdfkitOutput: im },
  method: "native-pdf-text-layer-extraction attempt (PDFKit)", collectedAt: imgAt, locator: "targets/image-only.pdf page 1",
  limitations: ["PDFKit returned nil page text for the single page; the page lists 1 image XObject and 0 font resources", "An empty native text layer is not evidence that the page has no content; visible content inside the image was not transcribed", "No OCR was performed; this record is not an extracted-text or content snapshot and does not recover the item"] });
// ---- render.html: authorized isolated-browser capture
const log = JSON.parse(await readFile(path.join(W, "render/capture-log.json"), "utf8"));
const dom = await readFile(path.join(W, "render/rendered-dom.html"), "utf8");
const rtext = await readFile(path.join(W, "render/rendered-text.txt"), "utf8");
if (sha(dom) !== log.renderedDomSha256) throw new Error("rendered DOM hash mismatch");
const rAt = log.state.capturedAt;
const rLimits = [
  "Local rendered DOM from headless " + log.browser + " in a fresh temporary profile over file://; not a search-engine or AI-crawler rendering",
  "Serialized after the owner-declared ready signal document.documentElement.dataset.auditReady === \"true\" was observed; single capture, single browser version",
  "No HTTP response, headers or network context exist for a file:// load",
];
add({ evidenceId: "render-html-capture-log", itemId: html, kind: "capture-provenance", artifact: "evidence/render-html-capture-log.json", encoding: "json", value: log,
  method: "headless Chrome DevTools Protocol capture, fresh isolated profile", collectedAt: log.finishedAt, locator: log.url, limitations: rLimits, sourceEvidenceIds: [htmlContent.evidenceId] });
add({ evidenceId: "render-html-rendered-dom", itemId: html, kind: "rendered-dom", artifact: "evidence/render-html-rendered-dom.html", value: dom,
  method: "headless Chrome DevTools Protocol capture, fresh isolated profile", collectedAt: rAt, locator: log.url + " (post-ready DOM serialization)", limitations: rLimits, sourceEvidenceIds: [htmlContent.evidenceId, "render-html-capture-log"] });
add({ evidenceId: "render-html-rendered-text", itemId: html, kind: "extracted-text", artifact: "evidence/render-html-rendered-text.txt", value: rtext,
  method: "document.body.innerText of the post-ready rendered DOM (headless Chrome)", collectedAt: rAt, locator: log.url + " (post-ready body innerText)",
  limitations: [...rLimits, "This is the rendered-state text only; the raw HTML source text differs and is retained separately as the content snapshot", "Nonempty text does not establish completeness or quality"], sourceEvidenceIds: ["render-html-rendered-dom"] });
const media = { sourceMarkup: { elementsMatched: 0, pattern: "<img|<picture|<video|<audio|<svg|<canvas|<object|<embed|<iframe", checkedBy: "regex over raw source bytes" }, renderedDom: { selector: "img,picture,video,audio,svg,canvas,object,embed,iframe", elementsMatched: log.state.mediaElements }, cssBackgroundImages: "none: source has no style element or style attribute" };
const src = await readFile(path.join(project, "targets/render.html"), "utf8");
media.sourceMarkup.elementsMatched = (src.match(/<(img|picture|video|audio|svg|canvas|object|embed|iframe)\b/gi) ?? []).length;
if (/style=|<style/i.test(src)) media.cssBackgroundImages = "style present; not assessed";
add({ evidenceId: "render-html-media-inventory", itemId: html, kind: "media-inventory", artifact: "evidence/render-html-media-inventory.json", encoding: "json", value: media,
  method: "derived media element inventory from raw source and rendered DOM", collectedAt: now, locator: "targets/render.html raw source and post-ready rendered DOM", limitations: ["Counts media elements in the raw source and one local rendered DOM capture only"], sourceEvidenceIds: [htmlContent.evidenceId, "render-html-rendered-dom"] });
const bundle = {
  reviews: [{ itemId: img, ruleId: "quality-readable-text", status: "unknown", evidenceIds: ["image-only-pdf-extraction-attempt"], reviewer, reviewedAt: now,
    reason: "Native PDFKit extraction returned no text layer for the single page (1 image XObject, 0 font resources). Empty native text is not proof of empty source content; no OCR or transcript exists, so no extracted-text snapshot was recorded and readability stays unknown. Collection remains unsupported." }],
  evidence, artifacts,
  collectionRecoveries: [{ itemId: doc, manifestEvidenceId: "document-pdf-extraction-manifest", contentEvidenceId: "document-pdf-recovered-content", textEvidenceId: "document-pdf-extracted-text", reviewer, reviewedAt: now,
    reason: "PDFKit reported 2 pages, unencrypted; both pages returned nonempty native text-layer strings and 0 image XObjects, so the page manifest covers every declared page. Text is native text layer (no OCR); reading order and fidelity against the visual page are attributed to the extractor, not independently verified." }],
};
await writeFile(path.join(W, "review-02-recovery.json"), JSON.stringify(bundle, null, 2) + "\n");
console.log(JSON.stringify({ html, doc, img, evidence: evidence.map((e) => [e.evidenceId, e.kind, e.snapshotHash.slice(0, 12)]), media }, null, 1));
