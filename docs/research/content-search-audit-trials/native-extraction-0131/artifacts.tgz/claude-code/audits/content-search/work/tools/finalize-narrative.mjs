// Fills extracted-text placeholders from the persisted artifact and builds the quote ledger.
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
const [root] = process.argv.slice(2);
const sha = (v) => createHash("sha256").update(v).digest("hex");
const rel = {
  html: "targets/render.html",
  dom: "audits/content-search/run-03-reviewed/evidence/render-html-rendered-dom.html",
  pdf: "audits/content-search/run-03-reviewed/evidence/document-pdf-extracted-text.txt",
};
const bytes = {};
for (const [k, p] of Object.entries(rel)) bytes[k] = await readFile(path.join(root, p));
const pdfLines = bytes.pdf.toString("utf8").split(/\r?\n/);
let report = await readFile(
  path.join(root, "audits/content-search/work/tools/narrative-template.md"),
  "utf8",
);
report = report.replace("{{VI_1}}", pdfLines[3]).replace("{{VI_2}}", pdfLines[4]);
if (report.includes("{{")) throw new Error("unfilled placeholder");
const reportPath = "audits/content-search/audit-narrative.md";
await writeFile(path.join(root, reportPath), report);
const reportLines = report.split(/\r?\n/);
const spec = [
  ["render-source-main", "html", 1, '<main id="task">Open Billing. Select Disable renewal.</main>'],
  ["render-source-script", "html", 1, "document.getElementById('task').textContent = 'Open Billing.';"],
  ["rendered-dom-ready", "dom", 1, 'data-audit-ready="true"'],
  ["rendered-dom-main", "dom", 1, '<main id="task">Open Billing.</main>'],
  ["pdf-en-limit", "pdf", 2, "A single export contains at most 5000 records."],
  ["pdf-en-scope", "pdf", 3, "Applies to current VN plans."],
  ["pdf-vi-limit", "pdf", 4, pdfLines[3]],
  ["pdf-vi-charge", "pdf", 5, pdfLines[4]],
];
const quotes = spec.map(([quoteId, key, line, quote]) => {
  const label = path.posix.basename(rel[key]);
  const citation = label + ":" + line;
  const index = reportLines.findIndex((l) => l.includes(citation) && l.includes(quote));
  if (index < 0) throw new Error("report line not found for " + quoteId);
  return {
    quoteId,
    source: rel[key],
    sourceLabel: label,
    sourceHash: sha(bytes[key]),
    startLine: line,
    endLine: line,
    reportStartLine: index + 1,
    reportEndLine: index + 1,
    normalization: "exact",
    quote,
  };
});
const ledger = { root, report: reportPath, reportHash: sha(Buffer.from(report, "utf8")), quotes };
await writeFile(
  path.join(root, "audits/content-search/quote-ledger.json"),
  JSON.stringify(ledger, null, 2) + "\n",
);
console.log(quotes.map((q) => q.quoteId + "@" + q.reportStartLine).join(" "));
