// Builds review bundle 03: owner context evidence, semantic verdicts and the finding.
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
const [project] = process.argv.slice(2);
const W = path.join(project, "audits/content-search/work");
const run = path.join(project, "audits/content-search/run-02-recovered");
const sha = (v) => createHash("sha256").update(v).digest("hex");
const lines = async (f) =>
  (await readFile(path.join(run, f), "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const inv = await lines("inventory.jsonl");
const ev = await lines("evidence.jsonl");
const id = (name) => inv.find((i) => i.path.endsWith("/" + name)).itemId;
const html = id("render.html");
const doc = id("document.pdf");
const htmlContent = ev.find((e) => e.itemId === html && e.kind === "content").evidenceId;
const reviewer = "Claude (claude-fable-5-2), AI audit host; not a human domain reviewer";
const now = new Date().toISOString();
const artifacts = {};
const evidence = [];
const origin =
  "Origin: statement by the audit requester (content owner) in the audit task, preserved verbatim. It is an approved comparison basis for this audit, not independently verified product behavior, a public source or an observed engine result.";
function ctx(evidenceId, itemId, kind, quotes, limitations, sources) {
  const value =
    origin + "\n" + quotes.map((q) => 'Owner statement: "' + q + '"').join("\n") + "\n";
  const artifact = "evidence/" + evidenceId + ".txt";
  artifacts[artifact] = value;
  evidence.push({
    evidenceId,
    itemId,
    method: "owner-supplied task context (user statement)",
    collectedAt: now,
    locator: "audit task statement supplied by the requester on 2026-11-17 (local date)",
    snapshotHash: sha(value),
    byteLength: Buffer.byteLength(value),
    redaction: "none",
    limitations,
    kind,
    value,
    artifact,
    encoding: "utf8",
    sourceEvidenceIds: sources,
  });
}
const task = "Approved renewal task requires opening Billing and selecting Disable renewal.";
const ready =
  "The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering.";
const policy =
  "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge.";
const locale =
  "English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.";
const none =
  "No search-engine rendering, indexing, analytics, AI observation or feature eligibility evidence is supplied.";
ctx(
  "owner-context-renewal-task",
  html,
  "audience-context",
  [task, ready],
  [
    "Establishes the approved user task and the meaning of the ready signal; it does not describe the audience, market, product version or an effective date",
    "Owner-approved comparison basis, not independent verification",
  ],
  [htmlContent],
);
ctx(
  "owner-context-renewal-task-claims",
  html,
  "claim-sources",
  [task],
  [
    "Undated owner-approved task used as the comparison record for instruction claims; not independent verification of the Billing interface",
  ],
  [htmlContent],
);
ctx(
  "owner-context-export-policy",
  doc,
  "claim-sources",
  [policy, locale],
  [
    "Undated owner-approved policy described as applying to current VN plans at the time of the audit request; not independent verification of product limits or pricing",
    "The locale statement removes translation completeness as a requirement; it does not supply a locale map",
  ],
  ["document-pdf-recovered-content"],
);
const R = (itemId, ruleId, status, evidenceIds, reason) => ({
  itemId,
  ruleId,
  status,
  evidenceIds,
  reason,
  reviewer,
  reviewedAt: now,
});
const reviews = [
  // ---- render.html
  R(
    html,
    "seo-rendering",
    "fail",
    [htmlContent, "render-html-rendered-dom", "render-html-capture-log", "owner-context-renewal-task"],
    'Raw source main text is "Open Billing. Select Disable renewal."; the inline script replaces it, and the local Chrome DOM serialized after the owner-declared ready signal has main text "Open Billing." only. The step "Select Disable renewal." required by the approved task exists in source but not in the finished rendered state. Scope: one local headless Chrome capture over file://; search-engine or AI-crawler rendering was not observed.',
  ),
  R(
    html,
    "quality-task-fit",
    "fail",
    [htmlContent, "render-html-rendered-dom", "owner-context-renewal-task"],
    'Approved task requires opening Billing and selecting Disable renewal. The finished rendered page shows only "Open Billing.", so a reader of the rendered page is not told the step that disables renewal. The raw source does contain both steps. Audience and market are not supplied; the verdict rests on the owner-approved task only.',
  ),
  R(
    html,
    "quality-claims",
    "pass",
    [htmlContent, "render-html-rendered-dom", "owner-context-renewal-task-claims"],
    'Instruction claims inventoried on both surfaces: source "Open Billing." and "Select Disable renewal."; rendered "Open Billing.". Each stated instruction matches the owner-approved task and none contradicts it. The omission of the second step in the rendered state is an incompleteness recorded under quality-task-fit and seo-rendering, not a false claim. The approved task is owner-supplied, not independently verified against the product.',
  ),
  R(
    html,
    "quality-accessible-media",
    "not-applicable",
    [htmlContent, "render-html-rendered-dom", "render-html-media-inventory"],
    "Neither the raw source nor the post-ready rendered DOM contains any image, video, audio, SVG, canvas, object, embed or iframe element, and the source has no style element or attribute; there is no media requiring a text alternative or transcript in this item.",
  ),
  R(
    html,
    "quality-freshness",
    "unknown",
    [htmlContent, "owner-context-renewal-task-claims"],
    "The page states no date, version or market, and the owner-approved task carries no effective date or product version, so date/version applicability cannot be assessed.",
  ),
  R(
    html,
    "seo-metadata",
    "unknown",
    [htmlContent, "render-html-rendered-dom", "owner-context-renewal-task"],
    'Observed: title is "Controlled render fixture" in source and rendered DOM; there is no meta description and no heading element. The title does not name the renewal task, but no audience, publication intent or search context is supplied for this controlled fixture, so whether that misrepresents the page for its users is not established. Left unknown rather than failed.',
  ),
  R(
    html,
    "aio-retrievable-facts",
    "unknown",
    [htmlContent, "render-html-rendered-dom", "owner-context-renewal-task"],
    'The fact "Select Disable renewal." is readable in raw source and absent from the local rendered DOM, so retrievability depends on which surface a system reads. No target AI surface, audience or retrieval observation is supplied; see the rendering finding for the observed discrepancy.',
  ),
  // ---- document.pdf
  R(
    doc,
    "quality-claims",
    "pass",
    ["document-pdf-recovered-content", "owner-context-export-policy"],
    'All material claims on both pages were compared with the owner-approved export policy. Page 1 (English): "A single export contains at most 5000 records." and "Applies to current VN plans." match the 5000-record limit and current-VN-plan scope. Page 2 (Vietnamese): "Mỗi lần xuất tối đa 5000 bản ghi." (auditor reading: each export is at most 5000 records) and "Không cần thanh toán thêm." (auditor reading: no additional payment is needed) match the limit and no-extra-charge terms. The English page not mentioning charges and the Vietnamese page not mentioning plan scope are differences of emphasis the owner states are acceptable, not contradictions. Based on PDFKit native text; the Vietnamese readings are the AI host\'s, not a certified translation.',
  ),
  R(
    doc,
    "quality-freshness",
    "pass",
    ["document-pdf-recovered-content", "owner-context-export-policy"],
    'The changing facts (record limit, plan/market scope, charge) match the policy the owner supplied as approved for current VN plans at the time of this audit, and page 1 states the same scope ("Applies to current VN plans."). No stale or superseded value was found. Neither the PDF text nor the policy carries an effective date, so this holds only as of the owner statement on the audit date.',
  ),
  R(
    doc,
    "quality-task-fit",
    "unknown",
    ["document-pdf-recovered-content"],
    "No audience or intended user task is supplied for this export-policy document; the approved policy supports claim checks, not a task-fit judgment.",
  ),
  R(
    doc,
    "seo-metadata",
    "unknown",
    ["document-pdf-recovered-content", "document-pdf-pdfkit-diagnostics"],
    'Observed: PDF document-info Title is "document.html" while page 1 is headed "Export policy" and page 2 "Giới hạn xuất dữ liệu". No audience context or publication intent is supplied, so whether the filename-style title misrepresents the document to its users is not established.',
  ),
  R(
    doc,
    "seo-locales",
    "unknown",
    ["document-pdf-recovered-content", "owner-context-export-policy"],
    "The single PDF holds an English page and a Vietnamese page. No locale map, alternate declarations or separate locale variants are supplied; the owner statement only removes translation completeness as a requirement.",
  ),
  R(
    doc,
    "quality-accessible-media",
    "unknown",
    ["document-pdf-recovered-content", "document-pdf-pdfkit-diagnostics"],
    "PDFKit/CoreGraphics listed 0 image XObjects on both pages, but inline images, vector graphics and tagged-PDF alternative text were not inventoried, so no complete media inventory exists.",
  ),
];
const findings = [
  {
    findingId: "render-drops-disable-renewal-step",
    title:
      'Finished render of render.html removes the "Select Disable renewal." step required by the approved task',
    affectedItemIds: [html],
    ruleIds: ["seo-rendering", "quality-task-fit"],
    dimensions: ["seo", "quality"],
    evidenceIds: [
      htmlContent,
      "render-html-rendered-dom",
      "render-html-capture-log",
      "owner-context-renewal-task",
    ],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      'In targets/render.html, change the inline script so the content present when data-audit-ready becomes "true" still includes both approved steps ("Open Billing. Select Disable renewal."), for example by not overwriting the main element with the shortened text. This is a proposal for a separate implementation task; the audit did not modify the file.',
    verification:
      'Load the revised file in a fresh isolated browser profile, wait until document.documentElement.dataset.auditReady === "true", then confirm the main element text contains both "Open Billing." and "Select Disable renewal." and matches the raw source. This checks local browser rendering only, not search-engine rendering or indexing.',
    ownerRole: "Front-end developer with content owner sign-off",
    effort: "small",
    action: "update",
    actionReason:
      "Observed in the authorized local browser capture: the rendered state omits a step the owner-approved task requires, while the raw source contains it.",
  },
];
await writeFile(
  path.join(W, "review-03-semantic.json"),
  JSON.stringify({ reviews, evidence, artifacts, findings }, null, 2) + "\n",
);
const own =
  "# Supplied owner context (preserved verbatim from the audit task)\n\n" +
  [ready, task, policy, locale, none].map((q) => '- "' + q + '"').join("\n") +
  "\n\n" +
  origin +
  "\n";
await writeFile(path.join(project, "audits/content-search/owner-context.md"), own);
console.log("reviews", reviews.length, "evidence", evidence.length);
