import Foundation
import PDFKit
import CoreGraphics

// Read-only native text-layer extraction via PDFKit. No OCR. Emits JSON on stdout.
let args = CommandLine.arguments
guard args.count == 2 else { FileHandle.standardError.write("usage: pdfextract FILE\n".data(using: .utf8)!); exit(2) }
let url = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: url) else { FileHandle.standardError.write("PDFKit could not open document\n".data(using: .utf8)!); exit(3) }
func imageCount(_ page: CGPDFPage?) -> Int {
  guard let page = page, let dict = page.dictionary else { return -1 }
  var res: CGPDFDictionaryRef? = nil
  guard CGPDFDictionaryGetDictionary(dict, "Resources", &res), let r = res else { return 0 }
  var xo: CGPDFDictionaryRef? = nil
  guard CGPDFDictionaryGetDictionary(r, "XObject", &xo), let x = xo else { return 0 }
  var n = 0
  CGPDFDictionaryApplyBlock(x, { _, obj, info in
    var s: CGPDFStreamRef? = nil
    if CGPDFObjectGetValue(obj, .stream, &s), let st = s, let d = CGPDFStreamGetDictionary(st) {
      var name: UnsafePointer<CChar>? = nil
      if CGPDFDictionaryGetName(d, "Subtype", &name), let nm = name, String(cString: nm) == "Image" {
        info!.assumingMemoryBound(to: Int.self).pointee += 1
      }
    }
    return true
  }, &n)
  return n
}
func fontCount(_ page: CGPDFPage?) -> Int {
  guard let page = page, let dict = page.dictionary else { return -1 }
  var res: CGPDFDictionaryRef? = nil
  guard CGPDFDictionaryGetDictionary(dict, "Resources", &res), let r = res else { return 0 }
  var f: CGPDFDictionaryRef? = nil
  guard CGPDFDictionaryGetDictionary(r, "Font", &f), let fd = f else { return 0 }
  return CGPDFDictionaryGetCount(fd)
}
var pages: [[String: Any]] = []
for i in 0..<doc.pageCount {
  let p = doc.page(at: i)
  let s = p?.string
  let b = p?.bounds(for: .mediaBox) ?? .zero
  pages.append([
    "page": i + 1,
    "textIsNil": s == nil,
    "text": s ?? "",
    "utf16Length": (s ?? "").utf16.count,
    "imageXObjects": imageCount(p?.pageRef),
    "fontResources": fontCount(p?.pageRef),
    "mediaBox": [b.origin.x, b.origin.y, b.size.width, b.size.height],
    "annotations": p?.annotations.count ?? -1
  ])
}
var attrs: [String: String] = [:]
for (k, v) in doc.documentAttributes ?? [:] { attrs["\(k)"] = "\(v)" }
let v = ProcessInfo.processInfo.operatingSystemVersion
let out: [String: Any] = [
  "file": url.path,
  "pageCount": doc.pageCount,
  "isEncrypted": doc.isEncrypted,
  "isLocked": doc.isLocked,
  "pdfVersion": "\(doc.majorVersion).\(doc.minorVersion)",
  "documentAttributes": attrs,
  "pages": pages,
  "extractor": ["name": "Apple PDFKit PDFPage.string (macOS system framework, via swift script)", "os": "macOS \(v.majorVersion).\(v.minorVersion).\(v.patchVersion)"]
]
let data = try JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(data)
