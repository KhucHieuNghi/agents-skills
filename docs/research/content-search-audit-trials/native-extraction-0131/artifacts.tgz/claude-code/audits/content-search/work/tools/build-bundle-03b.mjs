// Adds attributed "unknown" reviews so remaining reasons reflect the evidence actually
// present after recovery/capture. Never changes a status away from unknown.
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
const [project] = process.argv.slice(2);
const A = path.join(project, "audits/content-search");
const lines = async (f) =>
  (await readFile(path.join(A, "run-02-recovered", f), "utf8")).trim().split("\n").map((l) => JSON.parse(l));
const registry = JSON.parse(
  await readFile(path.join(project, ".claude/skills/content-search-audit/rules/core.json"), "utf8"),
);
const bundlePath = path.join(A, "work/review-03-semantic.json");
const bundle = JSON.parse(await readFile(bundlePath, "utf8"));
const inv = await lines("inventory.jsonl");
const evidence = [...(await lines("evidence.jsonl")), ...bundle.evidence];
const checks = await lines("checks.jsonl");
const reviewer = bundle.reviews[0].reviewer;
const now = new Date().toISOString();
const notes = {
  "http-response": "the item is a local file with no declared URL, so no HTTP response exists to capture",
  "publisher-intent": "no publication or indexing intent is supplied for these controlled fixtures",
  "crawler-policy": "no robots or crawler policy is supplied",
  "canonical-targets": "no canonical targets or intended variants are supplied",
  "link-graph": "no link graph was built; only the three declared local files exist and inbound discovery is undefined for them",
  "schema-extraction": "no structured-data extraction was recorded and no feature-eligibility evidence is supplied",
  "locale-map": "no locale map or alternate declarations are supplied",
  "entity-record": "no authoritative entity record is supplied",
  "question-set": "no real user questions are supplied and none were invented",
  "ai-observations": "no AI response observations are supplied",
  "inventory-map": "no cross-item inventory map was built because one of three items has no extracted content",
  "audience-context": "no audience or intended user task is supplied for this item",
  "rendered-dom": "no rendered DOM applies to or was captured for this item",
  "media-inventory": "no complete media inventory exists for this item",
  "claim-sources": "no approved claim source is supplied for this item",
  content: "no content snapshot exists for this item",
  "extracted-text": "no extracted text exists for this item",
};
let added = 0;
for (const item of inv.filter((i) => i.state !== "unsupported")) {
  for (const check of checks.filter((c) => c.itemId === item.itemId)) {
    if (check.status !== "unknown") continue;
    if (bundle.reviews.some((r) => r.itemId === item.itemId && r.ruleId === check.ruleId)) continue;
    const rule = registry.rules.find((r) => r.ruleId === check.ruleId);
    const have = new Set(evidence.filter((e) => e.itemId === item.itemId).map((e) => e.kind));
    const missing = rule.requiredEvidence.filter((k) => !have.has(k));
    const reason = missing.length
      ? "Unresolved, not a defect and not a pass. Required evidence still unavailable: " +
        missing.map((k) => k + " (" + notes[k] + ")").join("; ") +
        "."
      : "Unresolved, not a defect and not a pass. The required evidence kinds are present, but no user question set is supplied, so which statements count as material answer claims is not established; support for the stated claims is assessed under quality-claims.";
    bundle.reviews.push({
      itemId: item.itemId,
      ruleId: check.ruleId,
      status: "unknown",
      evidenceIds: [],
      reason,
      reviewer,
      reviewedAt: now,
    });
    added++;
  }
}
await writeFile(bundlePath, JSON.stringify(bundle, null, 2) + "\n");
console.log("added unknown reviews", added, "total reviews", bundle.reviews.length);
