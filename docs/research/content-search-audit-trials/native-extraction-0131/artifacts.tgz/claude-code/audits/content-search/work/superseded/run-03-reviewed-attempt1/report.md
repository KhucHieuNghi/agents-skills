# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T18:02:19\.048Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 9ef5e774\-a9d4\-421c\-af02\-183756cd88c5\. 1 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 1 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| render\-drops\-disable\-renewal\-step | Finished render of render\.html removes the &quot;Select Disable renewal\.&quot; step required by the approved task | seo\-rendering, quality\-task\-fit | seo, quality | high | high | observed | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | update | reviewer\-proposal | Observed in the authorized local browser capture: the rendered state omits a step the owner\-approved task requires, while the raw source contains it\. | In targets/render\.html, change the inline script so the content present when data\-audit\-ready becomes &quot;true&quot; still includes both approved steps \(&quot;Open Billing\. Select Disable renewal\.&quot;\), for example by not overwriting the main element with the shortened text\. This is a proposal for a separate implementation task; the audit did not modify the file\. | Load the revised file in a fresh isolated browser profile, wait until document\.documentElement\.dataset\.auditReady === &quot;true&quot;, then confirm the main element text contains both &quot;Open Billing\.&quot; and &quot;Select Disable renewal\.&quot; and matches the raw source\. This checks local browser rendering only, not search\-engine rendering or indexing\. | Front\-end developer with content owner sign\-off | small | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, render\-html\-rendered\-dom, render\-html\-capture\-log, owner\-context\-renewal\-task |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 6 | 8 | 1 |
| seo | 24 | 1 | 23 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | pending | Snapshot review incomplete | 26 |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | quality\-task\-fit | quality | unknown | No audience or intended user task is supplied for this export\-policy document; the approved policy supports claim checks, not a task\-fit judgment\. | document\-pdf\-recovered\-content |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | quality\-claims | quality | pass | All material claims on both pages were compared with the owner\-approved export policy\. Page 1 \(English\): &quot;A single export contains at most 5000 records\.&quot; and &quot;Applies to current VN plans\.&quot; match the 5000\-record limit and current\-VN\-plan scope\. Page 2 \(Vietnamese\): &quot;Mỗi lần xuất tối đa 5000 bản ghi\.&quot; \(auditor reading: each export is at most 5000 records\) and &quot;Không cần thanh toán thêm\.&quot; \(auditor reading: no additional payment is needed\) match the limit and no\-extra\-charge terms\. The English page not mentioning charges and the Vietnamese page not mentioning plan scope are differences of emphasis the owner states are acceptable, not contradictions\. Based on PDFKit native text; the Vietnamese readings are the AI host&\#39;s, not a certified translation\. | document\-pdf\-recovered\-content, owner\-context\-export\-policy |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | quality\-freshness | quality | pass | The changing facts \(record limit, plan/market scope, charge\) match the policy the owner supplied as approved for current VN plans at the time of this audit, and page 1 states the same scope \(&quot;Applies to current VN plans\.&quot;\)\. No stale or superseded value was found\. Neither the PDF text nor the policy carries an effective date, so this holds only as of the owner statement on the audit date\. | document\-pdf\-recovered\-content, owner\-context\-export\-policy |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | quality\-accessible\-media | quality | unknown | PDFKit/CoreGraphics listed 0 image XObjects on both pages, but inline images, vector graphics and tagged\-PDF alternative text were not inventoried, so no complete media inventory exists\. | document\-pdf\-pdfkit\-diagnostics, document\-pdf\-recovered\-content |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | document\-pdf\-extracted\-text |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-metadata | seo | unknown | Observed: PDF document\-info Title is &quot;document\.html&quot; while page 1 is headed &quot;Export policy&quot; and page 2 &quot;Giới hạn xuất dữ liệu&quot;\. No audience context or publication intent is supplied, so whether the filename\-style title misrepresents the document to its users is not established\. | document\-pdf\-pdfkit\-diagnostics, document\-pdf\-recovered\-content |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-locales | seo | unknown | The single PDF holds an English page and a Vietnamese page\. No locale map, alternate declarations or separate locale variants are supplied; the owner statement only removes translation completeness as a requirement\. | document\-pdf\-recovered\-content, owner\-context\-export\-policy |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | quality\-readable\-text | quality | unknown | Native PDFKit extraction returned no text layer for the single page \(1 image XObject, 0 font resources\)\. Empty native text is not proof of empty source content; no OCR or transcript exists, so no extracted\-text snapshot was recorded and readability stays unknown\. Collection remains unsupported\. | image\-only\-pdf\-extraction\-attempt |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | quality\-task\-fit | quality | fail | Approved task requires opening Billing and selecting Disable renewal\. The finished rendered page shows only &quot;Open Billing\.&quot;, so a reader of the rendered page is not told the step that disables renewal\. The raw source does contain both steps\. Audience and market are not supplied; the verdict rests on the owner\-approved task only\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | quality\-claims | quality | pass | Instruction claims inventoried on both surfaces: source &quot;Open Billing\.&quot; and &quot;Select Disable renewal\.&quot;; rendered &quot;Open Billing\.&quot;\. Each stated instruction matches the owner\-approved task and none contradicts it\. The omission of the second step in the rendered state is an incompleteness recorded under quality\-task\-fit and seo\-rendering, not a false claim\. The approved task is owner\-supplied, not independently verified against the product\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task\-claims, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | quality\-freshness | quality | unknown | The page states no date, version or market, and the owner\-approved task carries no effective date or product version, so date/version applicability cannot be assessed\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task\-claims |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | quality\-accessible\-media | quality | not\-applicable | Neither the raw source nor the post\-ready rendered DOM contains any image, video, audio, SVG, canvas, object, embed or iframe element, and the source has no style element or attribute; there is no media requiring a text alternative or transcript in this item\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, render\-html\-media\-inventory, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | render\-html\-rendered\-text |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-metadata | seo | unknown | Observed: title is &quot;Controlled render fixture&quot; in source and rendered DOM; there is no meta description and no heading element\. The title does not name the renewal task, but no audience, publication intent or search context is supplied for this controlled fixture, so whether that misrepresents the page for its users is not established\. Left unknown rather than failed\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | seo\-rendering | seo | fail | Raw source main text is &quot;Open Billing\. Select Disable renewal\.&quot;; the inline script replaces it, and the local Chrome DOM serialized after the owner\-declared ready signal has main text &quot;Open Billing\.&quot; only\. The step &quot;Select Disable renewal\.&quot; required by the approved task exists in source but not in the finished rendered state\. Scope: one local headless Chrome capture over file://; search\-engine or AI\-crawler rendering was not observed\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task, render\-html\-capture\-log, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aio\-retrievable\-facts | aio | unknown | The fact &quot;Select Disable renewal\.&quot; is readable in raw source and absent from the local rendered DOM, so retrievability depends on which surface a system reads\. No target AI surface, audience or retrieval observation is supplied; see the rendering finding for the observed discrepancy\. | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6, owner\-context\-renewal\-task, render\-html\-rendered\-dom |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |
| fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 5e22351d8745789ea041b650b6891f0886e0cd0ed8d084db4138bd4ea19134b6 | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | local\-file | 2026\-11\-16T17:57:17\.553Z | 0 full elapsed days | [evidence/fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720\.txt](evidence/fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| document\-pdf\-extraction\-manifest | 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | native\-pdf\-text\-layer\-extraction \(PDFKit\) | 2026\-11\-16T17:57:51\.376Z | 0 full elapsed days | [evidence/document\-pdf\-extraction\-manifest\.json](evidence/document-pdf-extraction-manifest.json) | b78d6474223840a41db6a5235117647699e0f88016ed8c83a41096f789b813db | Native PDF text\-layer extraction with Apple PDFKit PDFPage\.string; no OCR was performed; Reading order, line breaks and Unicode normalization are as returned by the extractor and were not independently verified against the visual page; Page image XObject count was 0 on both pages; inline images and vector drawings were not enumerated; Manifest assertions are host\-attributed evidence, not independent verification of page count, completeness or text fidelity |
| document\-pdf\-recovered\-content | 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | native\-pdf\-text\-layer\-extraction \(PDFKit\) | 2026\-11\-16T17:57:51\.376Z | 0 full elapsed days | [evidence/document\-pdf\-recovered\-content\.txt](evidence/document-pdf-recovered-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native PDF text\-layer extraction with Apple PDFKit PDFPage\.string; no OCR was performed; Reading order, line breaks and Unicode normalization are as returned by the extractor and were not independently verified against the visual page; Page image XObject count was 0 on both pages; inline images and vector drawings were not enumerated; Manifest assertions are host\-attributed evidence, not independent verification of page count, completeness or text fidelity |
| document\-pdf\-extracted\-text | 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | native\-pdf\-text\-layer\-extraction \(PDFKit\) | 2026\-11\-16T17:57:51\.376Z | 0 full elapsed days | [evidence/document\-pdf\-extracted\-text\.txt](evidence/document-pdf-extracted-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native PDF text\-layer extraction with Apple PDFKit PDFPage\.string; no OCR was performed; Reading order, line breaks and Unicode normalization are as returned by the extractor and were not independently verified against the visual page; Page image XObject count was 0 on both pages; inline images and vector drawings were not enumerated; Manifest assertions are host\-attributed evidence, not independent verification of page count, completeness or text fidelity |
| document\-pdf\-pdfkit\-diagnostics | 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | PDFKit/CoreGraphics read\-only inspection | 2026\-11\-16T17:57:51\.376Z | 0 full elapsed days | [evidence/document\-pdf\-pdfkit\-diagnostics\.json](evidence/document-pdf-pdfkit-diagnostics.json) | 234c23caba877290587b98271317dd6c20105902ba3fe6ac920093864166cbb3 | Raw extractor output including document info metadata and per\-page resource counts; diagnostic only; Annotation and image counts reflect what PDFKit/CoreGraphics exposed, not a full structural audit |
| image\-only\-pdf\-extraction\-attempt | 466ccb375877bf8084eb28863e7d7add103daff9f0cfcf223f56d605c20a29f9 | native\-pdf\-text\-layer\-extraction attempt \(PDFKit\) | 2026\-11\-16T17:57:51\.955Z | 0 full elapsed days | [evidence/image\-only\-pdf\-extraction\-attempt\.json](evidence/image-only-pdf-extraction-attempt.json) | 96afc5dca738d30a0a71729514654f8546b4f61b427804f7cf7c2de7bd0fdc19 | PDFKit returned nil page text for the single page; the page lists 1 image XObject and 0 font resources; An empty native text layer is not evidence that the page has no content; visible content inside the image was not transcribed; No OCR was performed; this record is not an extracted\-text or content snapshot and does not recover the item |
| render\-html\-capture\-log | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | headless Chrome DevTools Protocol capture, fresh isolated profile | 2026\-11\-16T17:59:05\.512Z | 0 full elapsed days | [evidence/render\-html\-capture\-log\.json](evidence/render-html-capture-log.json) | 75631ab98959b7256ed0a3c64d18b3bb0a3ddf1332891ce67b706ea0317d1e04 | Local rendered DOM from headless Chrome/157\.0\.8103\.51 in a fresh temporary profile over file://; not a search\-engine or AI\-crawler rendering; Serialized after the owner\-declared ready signal document\.documentElement\.dataset\.auditReady === &quot;true&quot; was observed; single capture, single browser version; No HTTP response, headers or network context exist for a file:// load |
| render\-html\-rendered\-dom | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | headless Chrome DevTools Protocol capture, fresh isolated profile | 2026\-11\-16T17:59:05\.007Z | 0 full elapsed days | [evidence/render\-html\-rendered\-dom\.html](evidence/render-html-rendered-dom.html) | cac1f56e13a975d0654c0a3f12bd118cd0cc00bd979815563e586f5d6beab37b | Local rendered DOM from headless Chrome/157\.0\.8103\.51 in a fresh temporary profile over file://; not a search\-engine or AI\-crawler rendering; Serialized after the owner\-declared ready signal document\.documentElement\.dataset\.auditReady === &quot;true&quot; was observed; single capture, single browser version; No HTTP response, headers or network context exist for a file:// load |
| render\-html\-rendered\-text | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | document\.body\.innerText of the post\-ready rendered DOM \(headless Chrome\) | 2026\-11\-16T17:59:05\.007Z | 0 full elapsed days | [evidence/render\-html\-rendered\-text\.txt](evidence/render-html-rendered-text.txt) | ca117db5ad1267b66ca8341827787ff0684718487e677baea400a3e2239e6d7d | Local rendered DOM from headless Chrome/157\.0\.8103\.51 in a fresh temporary profile over file://; not a search\-engine or AI\-crawler rendering; Serialized after the owner\-declared ready signal document\.documentElement\.dataset\.auditReady === &quot;true&quot; was observed; single capture, single browser version; No HTTP response, headers or network context exist for a file:// load; This is the rendered\-state text only; the raw HTML source text differs and is retained separately as the content snapshot; Nonempty text does not establish completeness or quality |
| render\-html\-media\-inventory | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | derived media element inventory from raw source and rendered DOM | 2026\-11\-16T18:00:45\.106Z | 0 full elapsed days | [evidence/render\-html\-media\-inventory\.json](evidence/render-html-media-inventory.json) | 131aa9a11d7a2a7dcc76e745f8539c6c07b9044a90ea0714ceb2429628ec672f | Counts media elements in the raw source and one local rendered DOM capture only |
| owner\-context\-renewal\-task | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | owner\-supplied task context \(user statement\) | 2026\-11\-16T18:02:18\.946Z | 0 full elapsed days | [evidence/owner\-context\-renewal\-task\.txt](evidence/owner-context-renewal-task.txt) | be85dee4c32f7ba72de81ba02875d6dfe5fff58ab7e7a5d0b8edd5a972d6f29b | Establishes the approved user task and the meaning of the ready signal; it does not describe the audience, market, product version or an effective date; Owner\-approved comparison basis, not independent verification |
| owner\-context\-renewal\-task\-claims | fce56632614ae22d6d971639e09af0f5b1c6f07a9bf2e74cab98aa543a951720 | owner\-supplied task context \(user statement\) | 2026\-11\-16T18:02:18\.946Z | 0 full elapsed days | [evidence/owner\-context\-renewal\-task\-claims\.txt](evidence/owner-context-renewal-task-claims.txt) | 31958ce294b6f85143c6af8c894c678fd5a76f894b7d3969f7a283aa6dc1588f | Undated owner\-approved task used as the comparison record for instruction claims; not independent verification of the Billing interface |
| owner\-context\-export\-policy | 38ea9e5c69ca0577270fb766115f6a0e504ee5e5f752a0af8d10e6ac876e1308 | owner\-supplied task context \(user statement\) | 2026\-11\-16T18:02:18\.946Z | 0 full elapsed days | [evidence/owner\-context\-export\-policy\.txt](evidence/owner-context-export-policy.txt) | 3edd6b3952aa04eae693994f625cf7edf8b3a90382a490455c9375d17bb53c23 | Undated owner\-approved policy described as applying to current VN plans at the time of the audit request; not independent verification of product limits or pricing; The locale statement removes translation completeness as a requirement; it does not supply a locale map |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
