# Supplied owner context (preserved verbatim from the audit task)

- "The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering."
- "Approved renewal task requires opening Billing and selecting Disable renewal."
- "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge."
- "English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement."
- "No search-engine rendering, indexing, analytics, AI observation or feature eligibility evidence is supplied."

Origin: statement by the audit requester (content owner) in the audit task, preserved verbatim. It is an approved comparison basis for this audit, not independently verified product behavior, a public source or an observed engine result.
