// Auditor-authored capture driver. Launches installed Chrome headless with a fresh,
// empty, isolated profile, loads one local file URL, waits for the owner-declared
// ready signal, and serializes the DOM. Sandbox is left at Chrome defaults.
import { spawn } from "node:child_process";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import path from "node:path";
import os from "node:os";
const [target, outDir] = process.argv.slice(2);
const chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const profile = await mkdtemp(path.join(os.tmpdir(), "audit-chrome-profile-"));
const url = pathToFileURL(target).href;
const flags = [
  "--headless=new", `--user-data-dir=${profile}`, "--remote-debugging-port=0",
  "--no-first-run", "--no-default-browser-check", "--disable-extensions",
  "--disable-background-networking", "--disable-component-update", "--disable-sync",
  "--disable-default-apps", "--no-pings", "--host-resolver-rules=MAP * ~NOTFOUND",
  "about:blank",
];
const log = { startedAt: new Date().toISOString(), chrome, flags, url, profileFresh: true, events: [] };
const sourceBytes = await readFile(target);
log.sourceSha256 = createHash("sha256").update(sourceBytes).digest("hex");
const child = spawn(chrome, flags, { stdio: ["ignore", "ignore", "pipe"] });
let stderr = ""; child.stderr.on("data", (d) => (stderr += d));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let result = { ok: false };
try {
  let port = null;
  for (let i = 0; i < 100 && !port; i++) {
    await sleep(100);
    try { port = (await readFile(path.join(profile, "DevToolsActivePort"), "utf8")).split("\n")[0]; } catch {}
  }
  if (!port) throw new Error("Chrome did not expose a DevTools port");
  const version = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json();
  log.browser = version.Browser; log.userAgent = version["User-Agent"];
  const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  const page = targets.find((t) => t.type === "page");
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pending = new Map();
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
    else if (msg.method === "Network.requestWillBeSent") log.events.push({ request: msg.params.request.url });
    else if (msg.method === "Runtime.exceptionThrown") log.events.push({ exception: msg.params.exceptionDetails.text });
    else if (msg.method === "Runtime.consoleAPICalled") log.events.push({ console: msg.params.type });
  };
  const send = (method, params = {}) => new Promise((res) => { const n = ++id; pending.set(n, res); ws.send(JSON.stringify({ id: n, method, params })); });
  const evaluate = async (expression) => (await send("Runtime.evaluate", { expression, returnByValue: true })).result?.result?.value;
  await send("Page.enable"); await send("Runtime.enable"); await send("Network.enable");
  const nav = await send("Page.navigate", { url });
  log.navigate = nav.result ?? nav.error;
  const t0 = Date.now(); let ready = false; let early = null;
  while (Date.now() - t0 < 15000) {
    if (early === null) {
      const e = await evaluate("location.href === " + JSON.stringify(url) + " && document.documentElement ? JSON.stringify({ready: document.documentElement.dataset.auditReady ?? null, outerHTML: document.documentElement.outerHTML}) : null");
      if (e) early = { atMs: Date.now() - t0, ...JSON.parse(e) };
    }
    ready = (await evaluate("location.href === " + JSON.stringify(url) + " && document.documentElement.dataset.auditReady === \"true\"")) === true;
    if (ready) break;
    await sleep(20);
  }
  log.readySignal = { expression: "document.documentElement.dataset.auditReady === \"true\"", observed: ready, waitedMs: Date.now() - t0 };
  log.firstObservation = early;
  if (!ready) throw new Error("Ready signal not observed within 15000 ms");
  const dom = await evaluate("\"<!DOCTYPE \" + document.doctype.name + \">\" + document.documentElement.outerHTML");
  const state = JSON.parse(await evaluate("JSON.stringify({href: location.href, title: document.title, lang: document.documentElement.lang, auditReady: document.documentElement.dataset.auditReady, mainText: document.getElementById(\"task\")?.textContent ?? null, bodyInnerText: document.body.innerText, mediaElements: document.querySelectorAll(\"img,picture,video,audio,svg,canvas,object,embed,iframe\").length, links: document.querySelectorAll(\"a[href],link[href]\").length, metaCount: document.querySelectorAll(\"meta\").length, jsonLd: document.querySelectorAll(\"script[type=\\\"application/ld+json\\\"]\").length, capturedAt: new Date().toISOString()})"));
  await writeFile(path.join(outDir, "rendered-dom.html"), dom);
  await writeFile(path.join(outDir, "rendered-text.txt"), state.bodyInnerText);
  log.state = state; log.renderedDomSha256 = createHash("sha256").update(dom).digest("hex");
  result = { ok: true };
  ws.close();
} catch (e) { result = { ok: false, error: String(e?.message ?? e) }; }
finally {
  child.kill("SIGTERM"); await sleep(500);
  log.finishedAt = new Date().toISOString(); log.result = result; log.chromeStderrTail = stderr.slice(-1500);
  log.sourceUnchanged = createHash("sha256").update(await readFile(target)).digest("hex") === log.sourceSha256;
  await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }).then(() => (log.profileRemoved = true), () => (log.profileRemoved = false));
  await writeFile(path.join(outDir, "capture-log.json"), JSON.stringify(log, null, 2) + "\n");
  console.log(JSON.stringify(log, null, 2));
}
process.exit(result.ok ? 0 : 1);
