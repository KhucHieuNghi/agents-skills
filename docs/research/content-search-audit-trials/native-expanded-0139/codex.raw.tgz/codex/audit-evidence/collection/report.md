# Independent synthetic scenarios — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:10:02\.957Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 02a99ceb\-b021\-475f\-a327\-5bd1f4078815\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2aa67cd57152679ffe7cd993e49003bc486367cd10791708bdcbbca4d123d8fd | 326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b | local\-file | 2026\-11\-18T08:10:02\.935Z | 0 full elapsed days | [evidence/326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b\.txt](evidence/326e9ba6d9a1a2dce543d8eb1be1941a9cb0b21596671d9778c5734a356ae45b.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ec278551822f9210fe78db65c2a9b08a6ee4b9e296833f6ecac0829b1bf32291 | 3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089 | local\-file | 2026\-11\-18T08:10:02\.936Z | 0 full elapsed days | [evidence/3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089\.txt](evidence/3cd1f921b5c7f8a14d6193748de79e3dc79ccad7ceed458e1ba0757c218db089.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 68e31392dd0969b315ab125d2ce8dc594d773fdfaa103d651bd99c9e9a2b33d5 | 4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267 | local\-file | 2026\-11\-18T08:10:02\.936Z | 0 full elapsed days | [evidence/4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267\.txt](evidence/4149c65c27dac7d607dc57d94bc7f6d22d2d097d79b486180b9fe59c090af267.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 9679e0a0c6344d01f4253cccfc89889410ad8ba7c201c446ee9f9a936bb211c7 | 6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027 | local\-file | 2026\-11\-18T08:10:02\.937Z | 0 full elapsed days | [evidence/6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027\.txt](evidence/6916e194c415cf67726eed3fdcc8bbe96647e716f02242a55d075b46c2ef8027.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4b0a8a3c1a5b7f95f58c9b0d8f2bdfd71ccb42d938cdaf2858297db7908cc569 | 7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c | local\-file | 2026\-11\-18T08:10:02\.938Z | 0 full elapsed days | [evidence/7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c\.txt](evidence/7d21e3a685d0e3a1f3aea70612b1aa547d6cf3e91d44a204ad0cb82503eabd3c.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 24193626eca631b03f149f0e5b839f241e1ce558305320660f83af1cb9dd8f21 | 97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62 | local\-file | 2026\-11\-18T08:10:02\.938Z | 0 full elapsed days | [evidence/97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62\.txt](evidence/97e4906953237edb2de0633fee31a453baa51a2f468bfa08be8e540cd12efd62.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 184f41c5aec18f62a33fdc197eaf9d8b230d356fa522ac8e7a8a99f284e58c24 | 98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760 | local\-file | 2026\-11\-18T08:10:02\.939Z | 0 full elapsed days | [evidence/98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760\.txt](evidence/98b5378c2489d39112b6d082ff8f4e39c6d8859ffa033a168c45c577d2e64760.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6998cf4a1d1a48b734d8beb9609970613c640c318b7549ddaf2370face7278b1 | a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de | local\-file | 2026\-11\-18T08:10:02\.939Z | 0 full elapsed days | [evidence/a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de\.txt](evidence/a94abe07250f64f6623de065a7190b9e1e017e8521d52d475d6a7210eeb397de.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3e305538c17e041ea3e8d0a5435e77bc2703aae487c81cba3962ef696415fce7 | dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b | local\-file | 2026\-11\-18T08:10:02\.940Z | 0 full elapsed days | [evidence/dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b\.txt](evidence/dff03bb41827a7dffda1c6f0fea9f27fcefa85e3135918bf7b56794178a4713b.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 13afe05337daa8915fe688959e43ad50cd7c2efed273794a2e6b24f5c2f00cde | e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6 | local\-file | 2026\-11\-18T08:10:02\.940Z | 0 full elapsed days | [evidence/e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6\.txt](evidence/e41ac97a86e3fd2748da5b1a9938849a362de75a8561ecf88d27ecea128582e6.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
