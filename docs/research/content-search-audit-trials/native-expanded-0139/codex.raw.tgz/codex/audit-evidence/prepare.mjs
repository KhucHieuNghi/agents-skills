import fs from 'node:fs';
import {createHash} from 'node:crypto';
const hash = v => createHash('sha256').update(v).digest('hex');
const read = p => fs.readFileSync(p,'utf8');
const save = (p,v) => fs.writeFileSync('audit-evidence/'+p,JSON.stringify(v,null,2)+'\n');
const rows = read('audit-evidence/collection/evidence.jsonl').trim().split('\n').map(JSON.parse);
const rules = JSON.parse(read('.agents/skills/content-search-audit/rules/core.json')).rules;
const bundle = {artifacts:{},evidence:[],reviews:[],findings:[]};
const now = new Date().toISOString();
const snap = n => rows.find(r => r.kind==='content' && r.locator.split('/').at(-1).startsWith(n+'-'));
const lines = (n,a,b=a) => snap(n).value.split('\n').slice(a-1,b).join('\n');
function add(n,kind,a,b=a,value=lines(n,a,b)){
  const s=snap(n), id=n+'-'+kind, artifact='evidence/'+id+'.json', body=JSON.stringify(value);
  bundle.artifacts[artifact]=body;
  bundle.evidence.push({...s,evidenceId:id,kind,artifact,value,encoding:"json",snapshotHash:hash(body),byteLength:Buffer.byteLength(body),locator:s.locator+':'+a+(b===a?'':'-'+b),sourceEvidenceIds:[s.evidenceId], limitations:['Attributed derivative of the supplied synthetic dossier only. No independent live verification.']});
  return id;
}
function review(n,ruleId,status,reason,...ids){
  bundle.reviews.push({itemId:snap(n).itemId,ruleId,status,reason,evidenceIds:[snap(n).evidenceId,...ids],reviewer:'offline-dossier-audit',reviewedAt:now});
}
function finding(n,title,severity,ruleIds,actionReason,remediation,verification,ownerRole,effort,ids=[],action='update'){
  bundle.findings.push({findingId:'F'+n,title,severity,ruleIds,dimensions:[...new Set(ruleIds.map(id=>rules.find(r=>r.ruleId===id).dimension))],affectedItemIds:[snap(n).itemId],evidenceIds:[snap(n).evidenceId,...ids],confidence:'high',classification:'observed',action,actionReason,remediation,verification,ownerRole,effort});
}
const intent=add('01','publisher-intent',3);
const http=add('01','http-response',4,5,{status:200,headers:{'x-robots-tag':'noindex'},url:'https://store.example.invalid/product',capturedAt:'2026-11-10T08:00:00Z'});
review('01','seo-index-controls','fail','Captured header noindex conflicts with the stated Google indexing intent, despite the index meta tag.',intent,http);
finding('01','Captured noindex conflicts with public indexing intent','high',['seo-index-controls','aio-crawler-policy'],'Google access and indexing eligibility are separate.','Remove unintended noindex from the serving layer for the product URL.','Compare approved revised header and HTML captures, then assess index status separately if supplied.','Web platform','small',[intent,http]);

const redirects=add('02','http-response',5,6,{status:301,chain:[{path:'/old',status:301,location:'/new'},{path:'/new',status:301,location:'/old'}]});
finding('02','Two redirects form a loop','high',['seo-response'],'The supplied route cannot reach the intended product destination.','Serve /new successfully and retain one /old to /new redirect.','Verify revised two-URL capture shows one redirect and final HTTP 200.','Web platform','small',[redirects]);

const schema=add('03','schema-extraction',8,18,JSON.parse(lines('03',8,18)));
const offer=add('03','claim-sources',3,4);
review('03','seo-structured-data','fail','The complete supplied Offer gives USD 19 while the owner confirms visible USD 29 for the same US monthly offer.',schema,offer);
finding('03','Structured offer price disagrees with visible US price','high',['seo-structured-data','aio-entity-consistency'],'Consumers of the two captured fields receive incompatible prices.','Generate both representations from the approved US monthly price of USD 29 before taxes.','Compare visible price and parsed Offer in the same revised capture and market.','Commerce engineering','small',[schema,offer]);

finding('04','Current Starter pages disagree on storage entitlement','high',['quality-claims','aio-entity-consistency','aeo-answer-evidence','portfolio-contradictions'],'Same plan, market, monthly period and policy version carry conflicting figures.','Obtain the authoritative versioned entitlement table, then align both pages.','Compare both revised statements to the approved market, plan, billing period and version row.','Product policy and content','depends on policy access',[],'investigate');

const policy=add('05','claim-sources',5);
for(const rule of ['quality-claims','aeo-answer-evidence']) review('05',rule,'fail','Draft broadens eligibility to everyone and removes the explicit 24-hour minimum. Other classes use an unavailable separate price table.',policy);
finding('05','Vietnamese draft misstates ticket-change eligibility and notice','high',['quality-claims','aeo-answer-evidence'],'Readers could act on an incorrect fee exemption and deadline.','State that only Members receive free changes, requests require at least 24 hours before departure, and other classes follow the separate fee table.','Check member and nonmember, before and at the deadline, against the supplied policy and approved fee schedule when available.','Ticketing policy and Vietnamese editor','small for copy',[policy]);

review('06','seo-rendering','unknown','The raw root is empty and references a script. Rendered output and script bytes are unavailable.');
const audience=add('07','audience-context',3,5), procedure=add('07','claim-sources',4,5), locales=add('07','locale-map',3,5);
review('07','seo-locales','not-applicable','The owner confirms this standalone Vietnamese help document has no intended counterpart or alternate relationship.',locales);
review('07','quality-task-fit','pass','The Vietnamese export procedure serves the specified customers and covers download, attachment handling and timing limitations.',audience);
for(const rule of ['quality-claims','aeo-answer-evidence']) review('07',rule,'pass','Owner-supplied procedure confirms the complete Vietnamese CSV instructions and limits.',procedure);
const study=add('08','claim-sources',3,5);
for(const rule of ['quality-claims','quality-freshness']) review('08',rule,'pass','The historical rate, API panel, collection window, publication month and current-rate caveat match supplied study metadata and editorial as-of date.',study);
const ownership=add('10','claim-sources',3);
review('10','quality-claims','pass','The supplied policy confirms the only visible product assertion, the account-owned export limit.',ownership);
save('review.json',bundle);
const sourceText=snap('08').value;
save('measurements.json',{studySources:[{sourceId:'08-study',kind:'historical-study',locator:'targets/08-study.md',sourceText,sourceHash:hash(sourceText),synthetic:true,scope:'English synthetic API panel, 1–14 February 2024, 40 of 100 responses cited video sources. Published 2026-11-01. Editorial as-of 2026-11-16.',limitations:['Response-level captures and later measurements were not supplied. The aggregate describes this historical panel only.'],passages:[{startLine:4,endLine:5,quote:lines('08',4,5)}]}]});
