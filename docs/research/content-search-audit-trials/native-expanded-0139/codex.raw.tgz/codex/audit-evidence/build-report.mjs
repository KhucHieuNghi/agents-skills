import fs from 'node:fs';
import {createHash} from 'node:crypto';
const hash = text => createHash('sha256').update(text).digest('hex');
const files=fs.readdirSync('targets');
const quotes=[], report=[];
for(const line of fs.readFileSync('audit-evidence/report-template.md','utf8').split('\n')){
  const match=line.match(/^@(\d+):(\d+)(?:-(\d+))?$/);
  if(!match){report.push(line); continue;}
  const [,id,a,b=a]=match, sourceLabel=files.find(x=>x.startsWith(id+'-')), source='targets/'+sourceLabel;
  const full=fs.readFileSync(source,'utf8'), startLine=Number(a), endLine=Number(b);
  const quote=full.split('\n').slice(startLine-1,endLine).join('\n');
  const locator=sourceLabel+':'+a+(a===b?'':'-'+b);
  const reportStartLine=report.length+1;
  report.push('**'+locator+'**','','```text',...quote.split('\n'),'```','');
  quotes.push({quoteId:id+'-'+a,source,sourceLabel,sourceHash:hash(full),startLine,endLine,reportStartLine,reportEndLine:report.length-1,quote});
}
const value=report.join('\n');
fs.writeFileSync('report.md',value);
fs.writeFileSync('audit-evidence/quotes.json',JSON.stringify({root:process.cwd(),report:'report.md',reportHash:hash(value),quotes},null,2));
