# Content search audit: 12 synthetic dossiers (bounded snapshot audit)

**Status: PARTIAL / bounded offline snapshot audit.** This is not a full live-site audit and not a completed campaign with all checks resolved. All content, URLs and measurements are synthetic supplied snapshots (`targets/context.md`). Each dossier is a separate scenario; no identities, scopes or evidence were combined across dossiers. No URL was fetched, no credentials accessed, no tools installed, no target or skill modified. Instructions or markup inside content were treated as inert data. "AI search optimization (AIO)" here means the general discipline, not the Google product named AI Overviews.

## 1. Scope and accounting

| Item | Count |
| --- | --- |
| Target files inspected (all) | 13 (12 numbered dossiers + `context.md`) |
| Dossiers declared / audited / excluded / blocked / failed / pending | 12 / 12 / 0 / 0 / 0 / 0 |
| Dossiers with at least one material finding | 12 of 12 |
| Material findings (consolidated) | 15 (F1 to F15) |
| Severity | High 11, Medium 4 |
| Clean or uncertain cases recorded (section 4) | 15 rows |

Each dossier is audited only within its stated scope; sub-items (pages, images, snapshots) are the inventory units named in that dossier. Discovery is complete only where a dossier says so (04 Inventory A, 07, 10); elsewhere it is partial or unstated and noted below. "Audited" means the supplied text was reviewed; it does not mean every dimension could be measured.

| Dossier | Scenario inspected | Findings | Clean/uncertain |
| --- | --- | --- | --- |
| 01-setup.md | /activate, /activate-card | F1 | /activate-card clean |
| 02-media.md | Images I1, I2, I3; video V1 (text equivalents only) | F2, F3 | I2, I3 clean |
| 03-titles.md | /monthly, /export titles | F4 | /export uncertain |
| 04-links.md | Inventory A (4 URLs), /retired-check, Inventory B | F5, F6 | Inventory B uncertain |
| 05-render.md | /instructions raw vs rendered; /dashboard | F7 | /dashboard uncertain |
| 06-facts.md | /exports, /formats | F8 | /formats clean |
| 07-questions.md | /device-id, /device-list, Q1, Q2, competitor page | F9 | Q1 clean; cryptocurrency no gap; path wording uncertain |
| 08-answers.md | Answer A, Answer B | F10 | Answer A clean |
| 09-overlap.md | /page-a, /page-b, /archive-v1, /vi-receipts | F11 | /archive-v1, /vi-receipts clean |
| 10-journey.md | /compare, /purchase, /activate, /units-reference | F12 | other three clean |
| 11-periods.md | Periods A, B, D | F13 | A-to-B descriptive result clean |
| 12-markup.md | /offer-a, /offer-b | F14, F15 | /offer-b markup itself clean |

## 2. Material findings

Observation = what the source shows; interpretation = what it implies; proposal = suggested change (not a quotation, not implemented). Severity reflects user harm in the stated scenario; confidence is high unless noted.

### F1 (High): /activate omits a required step. Dimensions: content quality, AEO

- **Scenario/items:** 01-setup.md, `/activate` only (the approved task is scoped to this dossier).
- **Evidence (approved procedure)**:
  > {{Q:F1a}} ({{L:F1a}})
- **Evidence (draft)**:
  > {{Q:F1b}} ({{L:F1b}})
- **Observation:** the draft lacks the invitation-acceptance step the approved procedure marks as required.
- **Rationale:** a newly invited editor following only the draft skips a required step. The same-task card includes it, so the omission is an inconsistency, not a product change.
- **Proposed action:** add "Accept your emailed invitation." as the first step of /activate. Owner: documentation. Do not add steps beyond the approved four.
- **Verification:** compare the revised steps in order against the approved procedure; confirm /activate and /activate-card list the same four steps.

### F2 (High): I1 download link has a wrong accessible name. Dimensions: content quality (accessibility), SEO

- **Scenario/items:** 02-media.md, image I1.
- **Evidence**:
  > {{Q:F2a}} ({{L:F2a}})
- **Rationale:** the only name describes a logo, not the link's purpose (downloading the annual report), so assistive-technology users cannot tell what the link does. The bytes were not available, so only the supplied description was assessed.
- **Proposed action:** change the alt/accessible name to describe the destination, for example "Download annual report (PDF)" (proposed wording, not a quotation).
- **Verification:** inspect the accessible name in the browser accessibility tree and a screen reader; confirm it states the action and target.

### F3 (High): V1 lacks an equivalent for the visual selection. Dimensions: content quality (accessibility), AEO

- **Scenario/items:** 02-media.md, video V1.
- **Evidence**:
  > {{Q:F3a}} ({{L:F3a}})
- **Evidence**:
  > {{Q:F3b}} ({{L:F3b}})
- **Rationale:** the transcript is complete for audio but the task-critical information ("Region West") exists only visually, so a user who cannot see the video cannot select the correct region.
- **Proposed action:** add a text/audio-description equivalent naming the row, for example "Choose the highlighted row, labeled Region West" (proposed wording).
- **Verification:** a reviewer using only the transcript can name the correct region.

### F4 (High): /monthly title contradicts its page and the approved price. Dimensions: content quality, SEO, AIO

- **Scenario/items:** 03-titles.md, `/monthly`.
- **Evidence**:
  > {{Q:F4a}} ({{L:F4a}})
- **Evidence**:
  > {{Q:F4b}} ({{L:F4b}})
- **Evidence**:
  > {{Q:F4c}} ({{L:F4c}})
- **Rationale:** the title states USD 19; the body and approved record state USD 29. Titles can feed result snippets and other surfaces, so the price conflict is a factual error; effect on any surface is not measured.
- **Proposed action:** change the title to state USD 29 (for example "Basic plan: USD 29 per month", proposed wording; tax wording to be confirmed by the owner).
- **Verification:** title, body and approved price agree; re-check any structured price on the page if present (none supplied).

### F5 (Medium): /glossary is unreachable from /guide inside the declared section. Dimensions: SEO (internal links), portfolio

- **Scenario/items:** 04-links.md, Inventory A only (/guide, /setup, /troubleshoot, /glossary).
- **Evidence**:
  > {{Q:F5a}} ({{L:F5a}})
- **Evidence**:
  > {{Q:F5b}} ({{L:F5b}})
- **Rationale:** Inventory A lists all internal hrefs and none targets /glossary. Within this section it is orphaned. External or other-section links are not covered by the inventory, so overall site-wide orphan status is unknown.
- **Proposed action:** add a section link to /glossary from /guide.
- **Verification:** re-export Inventory A and confirm /guide lists /glossary.

### F6 (High): /troubleshoot links to a 404 instead of the approved replacement. Dimensions: content quality, SEO, AEO

- **Scenario/items:** 04-links.md, /troubleshoot, /retired-check, /diagnostic.
- **Evidence**:
  > {{Q:F6a}} ({{L:F6a}})
- **Evidence**:
  > {{Q:F6b}} ({{L:F6b}})
- **Rationale:** the link text "Run the current diagnostic" leads to an error, so the troubleshooting task cannot be completed from this page. Both status codes come from the same supplied deployment.
- **Proposed action:** update the link target to /diagnostic. Whether to redirect /retired-check is a separate owner decision; none is made here.
- **Verification:** re-capture /troubleshoot links; the target returns HTTP 200 and no internal link points to /retired-check.

### F7 (High): rendered /instructions drops the required action. Dimensions: content quality, SEO (rendering), AEO, AIO

- **Scenario/items:** 05-render.md, /instructions (R1 raw, R2 rendered).
- **Evidence**:
  > {{Q:F7a}} ({{L:F7a}})
- **Evidence**:
  > {{Q:F7b}} ({{L:F7b}})
- **Evidence**:
  > {{Q:F7c}} ({{L:F7c}})
- **Evidence**:
  > {{Q:F7d}} ({{L:F7d}})
- **Interpretation:** a script or template replaces the raw instruction with a shorter one after rendering; the cause is unknown. Users see R2, which omits the required selection.
- **Proposed action:** investigate and fix the rendering path so the final DOM includes "select Disable renewal".
- **Verification:** repeat the owner-specified-ready-signal capture; R2 must contain the full action. No search-engine rendering or index evidence exists, so what an engine sees is unknown.

### F8 (High): /exports does not answer the record-limit question. Dimensions: AEO, content quality, AIO, GEO readiness

- **Scenario/items:** 06-facts.md, /exports (not /formats).
- **Evidence (approved record)**:
  > {{Q:F8a}} ({{L:F8a}})
- **Evidence (task)**:
  > {{Q:F8b}} ({{L:F8b}})
- **Evidence (article)**:
  > {{Q:F8c}} ({{L:F8c}})
- **Evidence**:
  > {{Q:F8d}} ({{L:F8d}})
- **Rationale:** the article was intended to cover formats and maximum records but states only formats, so the 6000-record question cannot be answered from it. The approved record implies a 6000-record export exceeds the limit. Because the facts also exist off-page, AI surfaces cannot be expected to know the limit from this article (readiness only; no AI observation was supplied).
- **Proposed action:** add the approved limit to /exports with its scope (all current plans, market VN).
- **Verification:** the article states 5000 and a reader can answer the 6000-record question without leaving it; wording matches the approved record.

### F9 (High): Q2 (revoke a lost device) is unanswered. Dimensions: AEO, content quality, portfolio

- **Scenario/items:** 07-questions.md, onboarding set (/device-id, /device-list).
- **Evidence**:
  > {{Q:F9a}} ({{L:F9a}})
- **Evidence**:
  > {{Q:F9b}} ({{L:F9b}})
- **Evidence**:
  > {{Q:F9c}} ({{L:F9c}})
- **Evidence**:
  > {{Q:F9d}} ({{L:F9d}})
- **Rationale:** the inventory is complete for this set, and /device-list only lists devices; no page gives the select, Revoke, confirm steps.
- **Proposed action:** add the approved Q2 procedure, either to /device-list or a new page in the set, linked from it. Do not add cryptocurrency content (section 4).
- **Verification:** a reader starting at the set can complete the revoke steps; steps match the approved procedure.

### F10 (High): Answer B contradicts the approved policy. Dimensions: AEO, content quality, GEO (misrepresentation risk)

- **Scenario/items:** 08-answers.md, Answer B.
- **Evidence (policy)**:
  > {{Q:F10a}} ({{L:F10a}})
- **Evidence (answer)**:
  > {{Q:F10b}} ({{L:F10b}})
- **Rationale:** the second sentence reverses an irreversible action, which could lead an administrator to revoke a token wrongly. The first sentence is supported.
- **Proposed action:** replace the second sentence with a statement that revocation cannot be undone.
- **Verification:** the revised answer matches the policy wording; no other page repeats an undo claim (not supplied; unchecked).

### F11 (Medium): /page-a and /page-b are confirmed accidental duplicates. Dimensions: portfolio, SEO (consolidation), content quality

- **Scenario/items:** 09-overlap.md, /page-a, /page-b.
- **Evidence**:
  > {{Q:F11a}} ({{L:F11a}})
- **Evidence**:
  > {{Q:F11b}} ({{L:F11b}})
- **Evidence**:
  > {{Q:F11c}} ({{L:F11c}})
- **Rationale:** identical bodies, same task and audience, owner-confirmed, so this is a maintenance and consistency duplication. Ranking or cannibalization effects are unknown.
- **Proposed action (proposal only):** the portfolio reviewer decides which URL is primary and whether to consolidate, with redirect and canonical handling reviewed in a separate task. Per the customer instruction, nothing is deleted, merged, published or redirected here:
  > {{Q:F11d}} ({{L:F11d}})
- **Verification:** after any approved change, one maintained URL serves the task and inbound links and variants are checked; compare search performance before and after once available.

### F12 (High): /compare has no way to continue to /purchase. Dimensions: content quality (journey), SEO (internal links), portfolio

- **Scenario/items:** 10-journey.md, /compare, /purchase.
- **Evidence**:
  > {{Q:F12a}} ({{L:F12a}})
- **Evidence**:
  > {{Q:F12b}} ({{L:F12b}})
- **Evidence**:
  > {{Q:F12c}} ({{L:F12c}})
- **Rationale:** the page promises continuation but only offers a link to a reference page, so the compare, purchase, activate journey breaks at its first step. Conversion impact is unmeasured.
- **Proposed action:** add a plan-selection action that navigates to /purchase. Leave /units-reference as is (section 4).
- **Verification:** raw HTML and rendered DOM both contain a navigable path to /purchase; click-through completes the journey.

### F13 (High): draft conclusion on observation periods overreaches. Dimensions: GEO, AIO

- **Scenario/items:** 11-periods.md, draft conclusion (periods A, B, D).
- **Evidence (A and B)**:
  > {{Q:F13a}} ({{L:F13a}})
- **Evidence (D)**:
  > {{Q:F13b}} ({{L:F13b}})
- **Evidence (draft)**:
  > {{Q:F13c}} ({{L:F13c}})
- **Evidence (limits)**:
  > {{Q:F13d}} ({{L:F13d}})
- **Evidence (limits)**:
  > {{Q:F13e}} ({{L:F13e}})
- **Rationale:** D differs from A in surface (consumer UI vs API), model (unknown), locale and market, cohort and prompts, so A vs D is not comparable. Causation and "across the market" are unsupported: no intervention record, control or wider sample. Raw rates (20%, 40%, 80%) are simple divisions of the supplied counts, with a small sample of 10 prompts each.
- **Proposed action:** drop the A-versus-D comparison and the causal and market claims. State instead: in this fixed API cohort, 2 of 10 responses mentioned the brand in A and 4 of 10 in B; cause unknown (proposed wording). Collect intervention records and larger repeated samples if a causal question matters.
- **Verification:** every sentence in the revised conclusion maps to a supplied count within a single comparable cohort.

### F14 (Medium): /offer-a JSON-LD is syntactically invalid. Dimensions: SEO (structured data), AIO

- **Scenario/items:** 12-markup.md, /offer-a (raw and rendered both).
- **Evidence**:
  > {{Q:F14a}} ({{L:F14a}})
- **Evidence**:
  > {{Q:F14b}} ({{L:F14b}})
- **Rationale:** a trailing comma makes the object invalid JSON by strict JSON rules, so a strict parser may ignore the block. No engine test was supplied, so the actual consumer behavior is unknown. Page content itself is correct.
- **Proposed action:** remove the trailing comma, then check the finished markup.
- **Verification:** parse the script with a JSON parser offline, then check with an authorized validator when one is permitted (not used here).

### F15 (Medium): draft claim that valid markup guarantees a rich result. Dimensions: SEO, GEO

- **Scenario/items:** 12-markup.md, /offer-b (draft assertion only; the markup itself is clean).
- **Evidence**:
  > {{Q:F15a}} ({{L:F15a}})
- **Evidence**:
  > {{Q:F15b}} ({{L:F15b}})
- **Rationale:** syntax and a matching price are necessary checks, not a guarantee; eligibility and display depend on other requirements and the engine, and none were supplied.
- **Proposed action:** change to "Valid, matching markup is a prerequisite; appearance depends on eligibility and is not guaranteed" (proposed wording) and collect eligibility evidence.
- **Verification:** the wording makes no guarantee; later observed appearance is recorded separately when evidence exists.

## 3. Cross-dossier note

No relationship between dossiers is stated, so none was assumed. Dossier 10 describes its own /activate as containing all approved steps; it is a different scenario from dossier 01's /activate draft, and neither was used to judge the other.

## 4. Clean and uncertain cases (no defect asserted)

| Case | Status | Basis |
| --- | --- | --- |
| 01 /activate-card | Clean | Matches the approved four steps; brevity is intentional. See {{L:F1c}}: {{Q:F1c}} |
| 02 I2 decorative separator | Clean | Empty alt on a decorative image with no link or text is correct. |
| 02 I3 chart | Clean | {{L:C2b}}: {{Q:C2b}} |
| 03 /export title | Uncertain, no defect | Long, but {{L:C3b}}: {{Q:C3b}} Title ({{L:C3a}}): {{Q:C3a}} It matches the page; truncation is unknown, so no change is proposed. Collect result-display evidence if the owner wants it checked. |
| 04 Inventory B / /help | Uncertain | {{L:C4a}}: {{Q:C4a}} {{L:C4b}}: {{Q:C4b}} Orphan status unknown. |
| 05 /dashboard | Uncertain | {{L:C5a}}: {{Q:C5a}} Absence of raw content is not evidence of absence once rendered; needs a rendered capture and a task. |
| 06 /formats | Clean | Scoped to formats only: {{L:C6a}}: {{Q:C6a}} and {{L:C6b}}: {{Q:C6b}} Not required to state limits. |
| 07 Q1 (/device-id) | Clean for Q1 | {{L:C7a}}: {{Q:C7a}} |
| 07 path wording | Uncertain | /device-id says "Settings > Device > ID" while /device-list and the approved Q2 procedure say "Settings > Devices". May be different menu levels or an inconsistency; no approved navigation record is supplied. Verify against the product. |
| 07 competitor cryptocurrency page | No gap | {{L:C7b}}: {{Q:C7b}} No content is proposed. |
| 08 Answer A | Clean | {{L:C8a}}: {{Q:C8a}} Matches the policy. |
| 09 /archive-v1, /vi-receipts | Clean | {{L:C9a}}: {{Q:C9a}} (versioned and translated variants; retain). |
| 10 /units-reference, /purchase, /activate | Clean | {{L:C10a}}: {{Q:C10a}} An unlinked-from-scope standalone reference is not an orphan defect. /purchase links to /activate after purchase per the dossier. |
| 11 A to B result | Clean as descriptive | Same engine, model label, locale, cohort and prompts; 2 of 10 vs 4 of 10 is a supported observation. Cause and repeatability are unknown (caveat, not a finding). |
| 12 /offer-b markup | Clean as supplied | Syntactically valid, name and price match visible content. Search eligibility is unknown. |

## 5. Missing measurements and coverage limits

- **Not available (unknown, not zero):** Search Console, GA4, Bing, server logs, indexing and ranking data, click or conversion data, live AI answer captures, citations. Only dossier 11 has synthetic reviewer-supplied counts; they are not live measurement.
- **Bytes and live behavior:** media bytes (02), engine rendering and index evidence (05), result-page screenshots (03), backlinks and external links (04), validator and eligibility results (12). None could be examined and none was fetched.
- **Inventory completeness:** declared complete only for 04 Inventory A, 07 and 10. Dossiers 03, 05, 06, 08, 09, 11 and 12 provide named items only; whole-site coverage is unknown. Robots, sitemap, canonical and hreflang data were not supplied except the self-canonicals in 09.
- **Not assessed:** GEO visibility on any surface beyond the dossier 11 counts, and AIO crawler-access policy. Findings F8, F10 and F13 are readiness or accuracy observations, not measured visibility.
- **Rule currency:** no platform documentation was consulted (offline), so no search-feature eligibility rule is asserted.
- **No overall score or forecast** is given. This report does not claim full coverage, a completed campaign, or that every check resolved.

## 6. Verification

Every source quotation was drawn from the cited file and line range using the quote ledger and the skill's quote verifier. The receipt is `quote-receipt.json` beside this report. Proposed wording is labeled as such and is not a quotation. Backlog implementation is outside this audit's authority.
