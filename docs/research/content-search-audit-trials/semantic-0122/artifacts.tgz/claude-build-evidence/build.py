import re,sys,hashlib,json
sys.path.insert(0,'/tmp/csa-scripts')
from q import Q
R='/private/var/folders/qz/snbf5txj0tjbkngsfl9gv6qh0000gn/T/nks-semantic-0122-6capic24/claude-code'
norm=lambda s:' '.join(s.split())
loc={}
for k,(f,t) in Q.items():
    lines=open(f'{R}/targets/{f}',encoding='utf-8').read().split('\n')
    found=None
    for a in range(len(lines)):
        acc=''
        for b in range(a,min(a+6,len(lines))):
            acc=norm(acc+' '+lines[b])
            if norm(t) in acc:
                found=(a+1,b+1);break
            if len(acc)>len(norm(t))+400:break
        if found:break
    if not found: print('MISSING',k);sys.exit(1)
    # tighten start
    a,b=found
    while a<b and norm(t) in norm(' '.join(lines[a:b])): a+=1
    loc[k]=(a,b)
tpl=open('/tmp/csa-scripts/report.tpl.md',encoding='utf-8').read()
def L(m):
    k=m.group(1);f,_=Q[k];a,b=loc[k];return f'{f}:{a}' if a==b else f'{f}:{a}-{b}'
out=re.sub(r'\{\{L:(\w+)\}\}',L,tpl)
out=re.sub(r'\{\{Q:(\w+)\}\}',lambda m:Q[m.group(1)][1],out)
open(f'{R}/report.md','w',encoding='utf-8').write(out)
rl=out.split('\n');quotes=[]
for k,(f,t) in Q.items():
    if t not in out: print('not in report',k);continue
    pos=out.index(t);rs=out[:pos].count('\n')+1;re_=rs+t.count('\n')
    a,b=loc[k]
    quotes.append(dict(quoteId=k,source=f'targets/{f}',sourceLabel=f,sourceHash=hashlib.sha256(open(f'{R}/targets/{f}','rb').read()).hexdigest(),startLine=a,endLine=b,reportStartLine=rs,reportEndLine=re_,normalization='whitespace',quote=t))
json.dump(dict(root=R,report='report.md',reportHash=hashlib.sha256(out.encode()).hexdigest(),quotes=quotes),open('/tmp/csa-scripts/bundle.json','w'),indent=1)
print(len(quotes),'quotes')
