# Content Search Audit campaign

Status: partial. Collection accounting is distinct from completed content review.

Declared items: 4; owned once: 4; collected snapshots: 0; audited items: 0.

Global portfolio review remains required. No combined SEO/GEO score is calculated.

## Partition reports

- [parts/000001](parts/000001/report.md): 1 owned items, 0 findings.
- [parts/000002](parts/000002/report.md): 1 owned items, 0 findings.
- [parts/000003](parts/000003/report.md): 1 owned items, 0 findings.
- [parts/000004](parts/000004/report.md): 1 owned items, 1 findings.

Only owned items count in this aggregate. Pending placeholder rows in earlier partition reports are not counted twice.

See campaign-coverage.json for pending items, dimensions and scope limitations.
