# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:23:54\.363Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 1c40956c\-e28b\-4233\-ab71\-993fcce419c4\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 1 |
| In scope | 1 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 1 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 0 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Inventory completeness is unknown; Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 3 | 0 | 3 | 0 |
| aio | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 0 | 8 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | blocked | Public content blocked by HTTP 401 | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-response | seo | unknown | Captured HTTP status 401 is an access or rate\-limit barrier; verify intended access and repeat an authorized capture before assessing a page defect\. | 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | 464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7 |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7 | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7\.json](evidence/464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034 | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034\.json](evidence/acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034.json) | 574b0c1c79c785dd7dc313ff4618782eeec8d59f6ad7c09dffab7dd192ef91e5 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a\.json](evidence/510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a.json) | 96ee886cb815e719fc2e10affd7655b6871e0cf0e8c608ac5f1b5670abf9881d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
