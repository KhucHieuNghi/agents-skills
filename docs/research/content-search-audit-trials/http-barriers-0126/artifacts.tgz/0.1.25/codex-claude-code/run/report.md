# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:23:52\.495Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run c66b96fa\-340a\-4ccb\-8457\-dda6e6ef9d78\. 4 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 4 |
| Excluded | 0 |
| Blocked | 3 |
| Failed | 1 |
| Unsupported | 0 |
| Pending | 0 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 3f085a0ee21bee669c24cf0eeef6ef65da4a753ab4a674829b892fe5df0fa49f | Captured HTTP status 401; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | seo\-response | seo | low | high | observed | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a |
| 7598457a17a2814816aca3b162431fddfd673731c74241f6137673ae32406517 | Captured HTTP status 403; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | seo\-response | seo | low | high | observed | eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4 |
| 9cfe0d334ff8bf72e2aa9eb1f0aaf74c98692c737971ce10bf1b6b7f96d35b47 | Captured HTTP status 404; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | seo\-response | seo | low | high | observed | f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76 |
| aa497b813e91e02b80dbe2058b64ee29ea8b56b89cc9e4b23fe59a0579720716 | Captured HTTP status 429; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | seo\-response | seo | low | high | observed | 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 4 | 28 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | blocked | Public content blocked by HTTP 401 | 26 |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | blocked | Public content blocked by HTTP 429 | 26 |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | blocked | Public content blocked by HTTP 403 | 26 |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | failed | Public response HTTP 404; content remains unavailable | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-response | seo | fail | Captured HTTP status 401; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | 464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7 |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-response | seo | fail | Captured HTTP status 429; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | f9d898137032329ffad9a0681631a550f7712930ec42ae127e2c2c9e20333556 |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-response | seo | fail | Captured HTTP status 403; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4 |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4 |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | ac8b331d6a057282c2c81175d026e9b735ef9ed1e0d066d950b70de1f6767f54 |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-response | seo | fail | Captured HTTP status 404; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76 |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-index\-controls | seo | unknown | Missing required evidence: content, publisher\-intent | d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76 |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aio\-crawler\-policy | aio | unknown | Missing required evidence: publisher\-intent | d43a7cc2eacb73caae8ca67a167b392c42338ff029c37f3c66d4b898e6d2a272 |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7 | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7\.json](evidence/464946a79aac0b93c1c63b40b57b4206a751bbc0d80a884bbb62cb16990201d7.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034 | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034\.json](evidence/acd8cdf1bab173b6c9317ed9f6f9da35ca2d51b384b5ca47df1742ff0d44c034.json) | 574b0c1c79c785dd7dc313ff4618782eeec8d59f6ad7c09dffab7dd192ef91e5 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a | 25a30defae5110b4872e3e43d04350b9a281c6bceef40965d954282f44d507df | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a\.json](evidence/510d85f4d84f2d026aef17773a7241dec4b321bd82571d8dac4b8e009274331a.json) | 96ee886cb815e719fc2e10affd7655b6871e0cf0e8c608ac5f1b5670abf9881d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| f9d898137032329ffad9a0681631a550f7712930ec42ae127e2c2c9e20333556 | 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/f9d898137032329ffad9a0681631a550f7712930ec42ae127e2c2c9e20333556\.json](evidence/f9d898137032329ffad9a0681631a550f7712930ec42ae127e2c2c9e20333556.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| a7ddd9b41a2a2bfb2e8551f6d3fea284851575920c4a37e61268146c3d14d8ec | 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/a7ddd9b41a2a2bfb2e8551f6d3fea284851575920c4a37e61268146c3d14d8ec\.json](evidence/a7ddd9b41a2a2bfb2e8551f6d3fea284851575920c4a37e61268146c3d14d8ec.json) | 574b0c1c79c785dd7dc313ff4618782eeec8d59f6ad7c09dffab7dd192ef91e5 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e | 95c5080b040f78f664db17714ef70a098add51d0901f963ec71deb9bcc9d2023 | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e\.json](evidence/d31709a96f748cbbd0ba8ee4d9375d6490dd420966795eb6c831faf14ccb5c0e.json) | de56682cf628567d5cfa9d1d7361ac9e59455ccdee4bbc6cc351a19877fa4917 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| ac8b331d6a057282c2c81175d026e9b735ef9ed1e0d066d950b70de1f6767f54 | eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/ac8b331d6a057282c2c81175d026e9b735ef9ed1e0d066d950b70de1f6767f54\.json](evidence/ac8b331d6a057282c2c81175d026e9b735ef9ed1e0d066d950b70de1f6767f54.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 7260057c5961000ea022501dea668bc4617aa600657beef622b103c656197cd9 | eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | public\-http | 1970\-01\-01T00:00:01\.000Z | 20773 full elapsed days | [evidence/7260057c5961000ea022501dea668bc4617aa600657beef622b103c656197cd9\.json](evidence/7260057c5961000ea022501dea668bc4617aa600657beef622b103c656197cd9.json) | 574b0c1c79c785dd7dc313ff4618782eeec8d59f6ad7c09dffab7dd192ef91e5 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4 | eae913c24fbdd6acc1f7b4a32e8cf28dcd7606fd36a948997612de8751bec653 | public\-http | 1970\-01\-01T00:00:01\.000Z | 20773 full elapsed days | [evidence/e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4\.json](evidence/e0cd77e00ac64577f223e637e09be5c1d74da4721e35857ec9cf781c5f3cb6c4.json) | 637d80157d65ab3cf6bc8670df5ad600950b7d9d4d3b2a92a97b23b711eb4da2 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| d43a7cc2eacb73caae8ca67a167b392c42338ff029c37f3c66d4b898e6d2a272 | f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | public\-http | 1970\-01\-01T00:00:00\.000Z | 20773 full elapsed days | [evidence/d43a7cc2eacb73caae8ca67a167b392c42338ff029c37f3c66d4b898e6d2a272\.json](evidence/d43a7cc2eacb73caae8ca67a167b392c42338ff029c37f3c66d4b898e6d2a272.json) | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 11bf66f0c14aff0c112e23b17d7ed0bae6676ce4edc6284e0eca9c5f31a3bf06 | f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | public\-http | 1970\-01\-01T00:00:01\.000Z | 20773 full elapsed days | [evidence/11bf66f0c14aff0c112e23b17d7ed0bae6676ce4edc6284e0eca9c5f31a3bf06\.json](evidence/11bf66f0c14aff0c112e23b17d7ed0bae6676ce4edc6284e0eca9c5f31a3bf06.json) | 574b0c1c79c785dd7dc313ff4618782eeec8d59f6ad7c09dffab7dd192ef91e5 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76 | f99f7e6a0f78e88fbbb7b150fd9d3a90af9805b41045fd53cf861685ab11a8ab | public\-http | 1970\-01\-01T00:00:01\.000Z | 20773 full elapsed days | [evidence/d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76\.json](evidence/d50924293160f0c59df5c3f6438dc29dc388749de5b879708d43679b86f51c76.json) | 5bac24624a138e55f5529b54343c1c18bf3ec993c9f212369c1143bc6acfbff6 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
