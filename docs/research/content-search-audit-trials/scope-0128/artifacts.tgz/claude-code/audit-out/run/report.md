# Synthetic — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:59:57\.462Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 5ec437c5\-0a01\-48fd\-ace0\-997bcbc63021\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |
| cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 45411a699460a84eb2ceaddfb89c7a2d4c73937a8911b65c2e527c00334bc245 | 12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04 | local\-file | 2026\-11\-16T05:59:56\.949Z | 0 full elapsed days | [evidence/12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04\.txt](evidence/12ac88cb6bbb5818d7b5676b442dc78dd6f4ad7caf94ad8a9e61940653e28d04.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e41ccc571d8cd94729aaacacf9669bee4363b777efd3c4eda3d671906b25a7f3 | 31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709 | local\-file | 2026\-11\-16T05:59:57\.037Z | 0 full elapsed days | [evidence/31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709\.txt](evidence/31db8dd82192873617228c35dc347e5151293e4083450c4ccb653ff53efc2709.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 33230738de201ad0622db339c24ead568b1627554a1188c7ced8da4760552113 | 4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b | local\-file | 2026\-11\-16T05:59:57\.065Z | 0 full elapsed days | [evidence/4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b\.txt](evidence/4909dda0356880d2f4db0e31ffafe650e671875d3d582f97ef0ba0deeb46495b.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 09fb95394abd0e6d608032fa95d012f18323da0b95d0ceeeac2017f594404643 | cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e | local\-file | 2026\-11\-16T05:59:57\.096Z | 0 full elapsed days | [evidence/cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e\.txt](evidence/cc880b157fac7ca0d04c8847afb090359c00ce38dbe4f9ec75d8fb3c3fb0058e.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
