import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';

const dir = 'audit-artifacts';
const read = file => fs.readFileSync(file, 'utf8');
const hash = data => createHash('sha256').update(data).digest('hex');
const write = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n');
const records = read(dir + '/initial/evidence.jsonl').trim().split('\n').map(JSON.parse)
  .sort((a,b) => path.basename(a.locator).localeCompare(path.basename(b.locator)));
const now = new Date().toISOString();
const bundle = {reviews: [], evidence: [], artifacts: {}, findings: []};
function derive(i, kind, locator, value) {
  const source = records[i-1];
  const evidenceId = hash(source.evidenceId + kind);
  const artifact = 'evidence/' + evidenceId + '.txt';
  bundle.artifacts[artifact] = value;
  bundle.evidence.push({evidenceId, itemId:source.itemId, kind, method:'off-line dossier review',
    collectedAt:now, locator, snapshotHash:hash(value), byteLength:Buffer.byteLength(value),
    redaction:'none', limitations:['Synthetic dossier evidence only'], artifact,
    encoding:'utf8', value, sourceEvidenceIds:[source.evidenceId]});
  return evidenceId;
}
function cite(i, a, b = a) {
  const source = records[i-1];
  return path.basename(source.locator) + ':' + a + (a === b ? '' : '-' + b);
}
function lines(i, a, b = a) {
  return records[i-1].value.split('\n').slice(a-1,b).join('\n');
}
function review(i, ruleId, status, reason, extra) {
  const {itemId, evidenceId} = records[i-1];
  bundle.reviews.push({itemId, ruleId, status, reason, evidenceIds:[evidenceId,...extra],
    reviewer:'Codex offline editorial review', reviewedAt:now});
}
const claims = [
  [[3,15],[20,24]],
  [[3,8],[11,16],[20,21]],
  [[3,6],[13,20]],
  [[3,5],[8,19]]
];
const claimIds = claims.map((ranges,n) => derive(n+1,'claim-sources',
  ranges.map(([a,b])=>cite(n+1,a,b)).join(', '),
  ranges.map(([a,b])=>lines(n+1,a,b)).join('\n\n')));
for (let i=1;i<=4;i++) {
  const source = records[i-1];
  derive(i,'extracted-text',cite(i,1,source.value.trimEnd().split('\n').length),source.value);
}
const entity1 = derive(1,'entity-record',cite(1,3,15),lines(1,3,15));
const entity3 = derive(3,'entity-record',cite(3,3,5)+', '+cite(3,13,18),lines(3,3,5)+'\n'+lines(3,13,18));
const inv3 = derive(3,'inventory-map',cite(3,3,20),lines(3,3,20));

const issues = [
  {i:1,id:'F1',title:'Fir SSO denial contradicts Enterprise documentation',severity:'high', item:'/compare assertion A',dims:['quality','aio','aeo'],rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence'],extra:[entity1],owner:'Comparison editor',
   spans:[[17,17],[13,13]], support:'The pricing excerpt’s silence cannot establish product-wide absence. The supplied current Fir documentation explicitly supports SAML SSO on Enterprise with a minimum of 20 paid seats. Other Fir plans remain unverified (01-competitor-claims.md:12-15). The denial can mislead buyers screening for SSO.',
   action:'Replace the denial with the documented Enterprise entitlement and its 20-paid-seat minimum. Leave other plans unspecified.',
   verify:'Compare the revised answer and any comparison-table cell with the supplied current Fir documentation and check that each retains the plan and seat condition.'},
  {i:1,id:'F2',title:'The universal Cedar price claim reverses on annual billing',severity:'high',item:'/compare assertion B',dims:['quality','aio','aeo'],rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence'],extra:[entity1],owner:'Comparison editor',
   spans:[[18,18],[6,9]],support:'For November 2026 US plans, Cedar is USD 3 less per seat per month on monthly billing and USD 1 more per seat per month equivalent on annual billing, before tax. The universal comparison misstates the annual choice.',
   action:'Show the two billing options separately and retain the market, date, currency, tax and per-seat basis. Preserve annual billing alongside its monthly equivalent.',
   verify:'Recompute 15 − 12 and 10 − 9 using the matching billing rows and check that neither unit-price comparison implies total cost or feature parity.'},
  {i:2,id:'F3',title:'October cost per conversion mixes reporting windows',severity:'high',item:'Draft A',dims:['quality'],rules:['quality-claims'],extra:[],owner:'Campaign reporting owner',
   spans:[[10,10],[5,8]],support:'USD 85.71 is the rounded arithmetic result of 3000 ÷ 35. The numerator covers October 1–31, while the denominator covers October 1–7. A completed reporting period does not supply the missing conversion rows. The month-wide metric could mislead budget decisions.',
   action:'Use the existing October 1–7 caption and indicate that October 8–31 is unmeasured. Recompute a full-month figure when aligned conversion data is available.',
   verify:'Match campaign, USD, completed-conversion definition and date boundaries for both totals. Confirm 700 ÷ 35 = USD 20 for October 1–7 and show the full-month value as unavailable until the denominator is complete.'},
  {i:2,id:'F4',title:'AI referral extrapolation lacks a measurement basis',severity:'high',item:'Draft B in the independent referral report',dims:['quality','geo'],rules:['quality-claims'],extra:[],owner:'Referral reporting owner',
   spans:[[17,18],[14,16]],support:'The 15 sessions with identified AI-assistant referrers support an observed count. The dossier supplies neither a one-in-ten tracking estimate nor evidence of incremental sessions. Unknown traffic origin also prevents estimating total assisted sessions, and there is no conversion linkage.',
   action:'Report the 15 identified October sessions and the unknown origin of other sessions. Remove the inferred total and causal attribution.',
   verify:'Reconcile the 15 against the independent referral report. Review any future extrapolation against a documented tracking model and any causal claim against an incrementality design. Keep campaign conversions outside this analysis.'},
  {i:3,id:'F5',title:'Current South page gives North’s delivery promise',severity:'high',item:'/south-delivery, with /north-delivery and approved policy as comparison evidence',dims:['quality','aio','aeo','portfolio'],rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence','portfolio-contradictions'],extra:[entity3,inv3],owner:'Delivery content owner',
   spans:[[10,11],[4,5],[8,9]],support:'The South wording contradicts the current next-business-day-only policy and repeats the North same-day window. A South customer could plan around an unavailable delivery date.',
   action:'Replace the South passage with the approved next-business-day-only policy, removing the copied cutoff and later-date language associated with North. Retain both region pages.',
   verify:'Check the complete revised South and North policy passages side by side against the current owner record. Confirm the archive still identifies its historical contract and directs new orders to current pages.'},
  {i:4,id:'F6',title:'A 20-session median does not support a universal setup guarantee',severity:'high',item:'Draft onboarding landing page',dims:['quality','aeo'],rules:['quality-claims','aeo-answer-evidence'],extra:[],owner:'Product marketing editor',
   spans:[[6,6],[3,5]],support:'The study supports a 15-minute median for the 20 observed onboarding sessions. It supplies no 10-minute maximum or guarantee and cannot establish a claim about every team. The promise can set an unsupported expectation before signup.',
   action:'Use the observed median and sample size, attributed to the supplied study. Remove the guarantee and universal wording.',
   verify:'Match the revised copy to the study record for sample, statistic and scope. Check that the text introduces no timing ceiling, population estimate or refund promise.'}
];
for (let i=1;i<=4;i++) {
  const affected = issues.filter(f=>f.i===i);
  const rules = [...new Set(affected.flatMap(f=>f.rules))];
  for (const rule of rules) {
    const failures = affected.filter(f=>f.rules.includes(rule));
    review(i,rule,'fail',failures.map(f=>f.id + ' ' + f.title).join('. ')+
      '. Supported passages and remaining evidence gaps are scoped in report.md.',
      [...new Set([claimIds[i-1], ...failures.flatMap(f=>f.extra)])]);
  }
}
review(3,'portfolio-duplication','pass','The stated complete inventory preserves separate regional tasks and a distinct historic-contract task. The copied policy error is tracked as F5.',[inv3]);
for (const f of issues) {
  bundle.findings.push({findingId:f.id,title:f.title,remediation:f.action,verification:f.verify,
    ownerRole:f.owner,effort:'Low editorial effort; owner verification required',affectedItemIds:[records[f.i-1].itemId],
    ruleIds:f.rules,dimensions:[...new Set(f.rules.map(r=>r.split('-')[0]))],
    evidenceIds:[records[f.i-1].evidenceId,claimIds[f.i-1],...f.extra],severity:f.severity,
    confidence:'high',classification:'observed',action:'update',actionReason:f.support});
}
write(dir+'/review.json',bundle);
write(dir+'/issues.json',issues);
