# Synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:28:37\.922Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 3357b49b\-a1a5\-4f16\-9825\-4e9db8c5f29a\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | Fir SSO denial contradicts Enterprise documentation | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | update | reviewer\-proposal | The pricing excerpt’s silence cannot establish product\-wide absence\. The supplied current Fir documentation explicitly supports SAML SSO on Enterprise with a minimum of 20 paid seats\. Other Fir plans remain unverified \(01\-competitor\-claims\.md:12\-15\)\. The denial can mislead buyers screening for SSO\. | Replace the denial with the documented Enterprise entitlement and its 20\-paid\-seat minimum\. Leave other plans unspecified\. | Compare the revised answer and any comparison\-table cell with the supplied current Fir documentation and check that each retains the plan and seat condition\. | Comparison editor | Low editorial effort; owner verification required | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f, 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea, 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482 |
| F2 | The universal Cedar price claim reverses on annual billing | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | update | reviewer\-proposal | For November 2026 US plans, Cedar is USD 3 less per seat per month on monthly billing and USD 1 more per seat per month equivalent on annual billing, before tax\. The universal comparison misstates the annual choice\. | Show the two billing options separately and retain the market, date, currency, tax and per\-seat basis\. Preserve annual billing alongside its monthly equivalent\. | Recompute 15 − 12 and 10 − 9 using the matching billing rows and check that neither unit\-price comparison implies total cost or feature parity\. | Comparison editor | Low editorial effort; owner verification required | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f, 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea, 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482 |
| F3 | October cost per conversion mixes reporting windows | quality\-claims | quality | high | high | observed | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | update | reviewer\-proposal | USD 85\.71 is the rounded arithmetic result of 3000 ÷ 35\. The numerator covers October 1–31, while the denominator covers October 1–7\. A completed reporting period does not supply the missing conversion rows\. The month\-wide metric could mislead budget decisions\. | Use the existing October 1–7 caption and indicate that October 8–31 is unmeasured\. Recompute a full\-month figure when aligned conversion data is available\. | Match campaign, USD, completed\-conversion definition and date boundaries for both totals\. Confirm 700 ÷ 35 = USD 20 for October 1–7 and show the full\-month value as unavailable until the denominator is complete\. | Campaign reporting owner | Low editorial effort; owner verification required | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906, b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4 |
| F4 | AI referral extrapolation lacks a measurement basis | quality\-claims | quality | high | high | observed | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | update | reviewer\-proposal | The 15 sessions with identified AI\-assistant referrers support an observed count\. The dossier supplies neither a one\-in\-ten tracking estimate nor evidence of incremental sessions\. Unknown traffic origin also prevents estimating total assisted sessions, and there is no conversion linkage\. | Report the 15 identified October sessions and the unknown origin of other sessions\. Remove the inferred total and causal attribution\. | Reconcile the 15 against the independent referral report\. Review any future extrapolation against a documented tracking model and any causal claim against an incrementality design\. Keep campaign conversions outside this analysis\. | Referral reporting owner | Low editorial effort; owner verification required | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906, b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4 |
| F5 | Current South page gives North’s delivery promise | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence, portfolio\-contradictions | quality, aio, aeo, portfolio | high | high | observed | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | update | reviewer\-proposal | The South wording contradicts the current next\-business\-day\-only policy and repeats the North same\-day window\. A South customer could plan around an unavailable delivery date\. | Replace the South passage with the approved next\-business\-day\-only policy, removing the copied cutoff and later\-date language associated with North\. Retain both region pages\. | Check the complete revised South and North policy passages side by side against the current owner record\. Confirm the archive still identifies its historical contract and directs new orders to current pages\. | Delivery content owner | Low editorial effort; owner verification required | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c, 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30 |
| F6 | A 20\-session median does not support a universal setup guarantee | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | update | reviewer\-proposal | The study supports a 15\-minute median for the 20 observed onboarding sessions\. It supplies no 10\-minute maximum or guarantee and cannot establish a claim about every team\. The promise can set an unsupported expectation before signup\. | Use the observed median and sample size, attributed to the supplied study\. Remove the guarantee and universal wording\. | Match the revised copy to the study record for sample, statistic and scope\. Check that the text introduces no timing ceiling, population estimate or refund promise\. | Product marketing editor | Low editorial effort; owner verification required | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303, 7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | pending | Snapshot review incomplete | 26 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | pending | Snapshot review incomplete | 26 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | pending | Snapshot review incomplete | 26 |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-claims | quality | fail | F6 A 20\-session median does not support a universal setup guarantee\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303, 7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | c29d5cab4f7b5866a8cfe2f89ac24396abd9f37489aa9db58e5463f887733b99 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-answer\-evidence | aeo | fail | F6 A 20\-session median does not support a universal setup guarantee\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303, 7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-claims | quality | fail | F3 October cost per conversion mixes reporting windows\. F4 AI referral extrapolation lacks a measurement basis\. Supported passages and remaining evidence gaps are scoped in report\.md\. | b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4, c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | c44da53947badf94a9d54f6367b39e9378631d488f1f5ca30541a3e45dced12e |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-claims | quality | fail | F5 Current South page gives North’s delivery promise\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30, 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36, 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dadc9acb34dea470a25ca01c493406180099f51d59b87be550657d33d46152c9 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-entity\-consistency | aio | fail | F5 Current South page gives North’s delivery promise\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30, 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36, 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-answer\-evidence | aeo | fail | F5 Current South page gives North’s delivery promise\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30, 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36, 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-duplication | portfolio | pass | The stated complete inventory preserves separate regional tasks and a distinct historic\-contract task\. The copied policy error is tracked as F5\. | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-contradictions | portfolio | fail | F5 Current South page gives North’s delivery promise\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595, 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30, 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36, 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-claims | quality | fail | F1 Fir SSO denial contradicts Enterprise documentation\. F2 The universal Cedar price claim reverses on annual billing\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea, 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482, cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | f6dde0ca931756493aa16a070f3beb9e4e3a8f548853d1ed3d7776f9ec92d98b |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-entity\-consistency | aio | fail | F1 Fir SSO denial contradicts Enterprise documentation\. F2 The universal Cedar price claim reverses on annual billing\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea, 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482, cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-answer\-evidence | aeo | fail | F1 Fir SSO denial contradicts Enterprise documentation\. F2 The universal Cedar price claim reverses on annual billing\. Supported passages and remaining evidence gaps are scoped in report\.md\. | 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea, 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482, cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 | 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | local\-file | 2026\-11\-16T05:59:52\.169Z | 0 full elapsed days | [evidence/33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387\.txt](evidence/33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | local\-file | 2026\-11\-16T05:59:52\.172Z | 0 full elapsed days | [evidence/5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765\.txt](evidence/5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | local\-file | 2026\-11\-16T05:59:52\.176Z | 0 full elapsed days | [evidence/5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32\.txt](evidence/5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | local\-file | 2026\-11\-16T05:59:52\.178Z | 0 full elapsed days | [evidence/eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1\.txt](evidence/eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea\.txt](evidence/1842295e38d12230836ea5fadc3bf183485d560bf38a363bbb0be5f53fb558ea.txt) | 288d8d738dae59485a8acc6a5d652eeb97bd1d9f9b77bfbb5734c73463059191 | Synthetic dossier evidence only |
| b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4 | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4\.txt](evidence/b4fedf72cb10cd774b91e3b5c059feca86f43b91be07860ad9b0d3a8d91f47d4.txt) | 34fd8e536a42d88ac19451d7c4e48a06232e09cd96263734d6a90bcf2aba9ce7 | Synthetic dossier evidence only |
| 942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c\.txt](evidence/942a4aade78b860c740e16e3edddda318d0fc82c2e31a09b8d8825fa2a55758c.txt) | 9d74e8f507caaa6b2c1bd6711d7766361c9d40d39555e774635b76b07c1dc02a | Synthetic dossier evidence only |
| 7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a | 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a\.txt](evidence/7c14aabfb73b6ebdc6dea5bf44972fbb80d54ee1399c29530dd65d20cac2b35a.txt) | 38676474ecec3a21b4c054faca1f29c468d2ee9fb6a265e17bf0ad38b3925601 | Synthetic dossier evidence only |
| f6dde0ca931756493aa16a070f3beb9e4e3a8f548853d1ed3d7776f9ec92d98b | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/f6dde0ca931756493aa16a070f3beb9e4e3a8f548853d1ed3d7776f9ec92d98b\.txt](evidence/f6dde0ca931756493aa16a070f3beb9e4e3a8f548853d1ed3d7776f9ec92d98b.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Synthetic dossier evidence only |
| c44da53947badf94a9d54f6367b39e9378631d488f1f5ca30541a3e45dced12e | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/c44da53947badf94a9d54f6367b39e9378631d488f1f5ca30541a3e45dced12e\.txt](evidence/c44da53947badf94a9d54f6367b39e9378631d488f1f5ca30541a3e45dced12e.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Synthetic dossier evidence only |
| dadc9acb34dea470a25ca01c493406180099f51d59b87be550657d33d46152c9 | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/dadc9acb34dea470a25ca01c493406180099f51d59b87be550657d33d46152c9\.txt](evidence/dadc9acb34dea470a25ca01c493406180099f51d59b87be550657d33d46152c9.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Synthetic dossier evidence only |
| c29d5cab4f7b5866a8cfe2f89ac24396abd9f37489aa9db58e5463f887733b99 | 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/c29d5cab4f7b5866a8cfe2f89ac24396abd9f37489aa9db58e5463f887733b99\.txt](evidence/c29d5cab4f7b5866a8cfe2f89ac24396abd9f37489aa9db58e5463f887733b99.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Synthetic dossier evidence only |
| 50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482 | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482\.txt](evidence/50259d822931e8e9329d0dec72bc5cffd119dd006972ed5a51188cd34504a482.txt) | 6cfa66eeb3a8c71dbb4dfde0e787615be14a976daf49a59622dd3ee9cefc0bcc | Synthetic dossier evidence only |
| 477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36 | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36\.txt](evidence/477a501d0d8270cb658bab25c79e0c1df580658338358145ecc92b6f2053ee36.txt) | 7a7285bf58fd9b0664d939b8ed48b67dc88d992a441e5197c2121046c5b46e87 | Synthetic dossier evidence only |
| 235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30 | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | off\-line dossier review | 2026\-11\-16T13:28:37\.763Z | 0 full elapsed days | [evidence/235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30\.txt](evidence/235876ddb7367c6ea2d4f2c9947b0e059106368d67affe9388a6bdf6e89c6f30.txt) | 5ebbb25fb8a21bca16ba46e84eb9ecd295739f96f0ca6d2b945200c2f5055168 | Synthetic dossier evidence only |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
