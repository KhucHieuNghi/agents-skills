# Synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:59:52\.211Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 1e7e2db4\-83ef\-44d4\-84aa\-03e208abe43a\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |
| eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3e81d39cba71a24fb398a082af4434ebb7f0b013c286fa0098241eafec3cc303 | 33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387 | local\-file | 2026\-11\-16T05:59:52\.169Z | 0 full elapsed days | [evidence/33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387\.txt](evidence/33e2b8c1f7507fa87492f130d9c28e2dee08106c6830c41f4023c4b6ee0fd387.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c8bdd48af09da91e64898fcba8c34b5a4f2d8f8daf2ac9fc35864fa0b89a8906 | 5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765 | local\-file | 2026\-11\-16T05:59:52\.172Z | 0 full elapsed days | [evidence/5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765\.txt](evidence/5519f985f8a667059f70b44738d8991eedd09fd50a8be9a3c5a2ab7347428765.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 15393ddc52d4b92cd53bada8b98607d32d44858ac97f9318d9badacdb4839595 | 5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32 | local\-file | 2026\-11\-16T05:59:52\.176Z | 0 full elapsed days | [evidence/5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32\.txt](evidence/5648f103324b87f1c8d4619f36e58b00894789b5ed9c258479842f1e6c147f32.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cb9fa140ad151df73cd47b0880ebeac3cc959b0528439f630235cc919b7f2a4f | eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1 | local\-file | 2026\-11\-16T05:59:52\.178Z | 0 full elapsed days | [evidence/eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1\.txt](evidence/eb116b331fb4b1c1ca9f4c72cd3300ef2176133c10ff12399ab8f69879b301a1.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
