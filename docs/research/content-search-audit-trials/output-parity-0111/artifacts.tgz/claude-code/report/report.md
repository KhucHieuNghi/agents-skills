# Content audit — Content Search Audit

Partial.

## Scope and coverage

Counts use unique owned content, not repeated placeholder rows\. Completion concerns audit coverage, not whether content is defect\-free\. Discovery completeness is a declared scope assertion\.

| Metric | Value |
| --- | --- |
| Campaign | e01c34ff\-b1ca\-4a6b\-a6a0\-1b3d6480be8a |
| Declared items | 1 |
| Owned/attempted | 1 |
| Collected | 1 |
| Audited | 0 |
| Inventory complete | true |
| Mode | full |
| Unresolved items | 1 |
| Missing checks | 0 |
| Pending queue | 0 |
| Global rules unresolved | portfolio\-task\-gaps, portfolio\-duplication, portfolio\-contradictions, portfolio\-journey\-links |
| pending | 1 |
| audited | 0 |
| failed | 0 |
| blocked | 0 |
| unsupported | 0 |
| excluded | 0 |

## Dimension coverage

Supplied checks only; missing checks are reported separately\. No combined SEO/GEO score is calculated\.

| Dimension | Supplied | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 0 | 8 | 0 |
| aio | 3 | 0 | 3 | 0 |
| aeo | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |

## Global portfolio review

Attributed judgments remain subject to domain review\. Evidence hashes and valid references do not certify semantic truth or reviewer identity\.

| Rule | Status | Reason | Reviewer | Reviewed | Applicability reason |
| --- | --- | --- | --- | --- | --- |

## Priority backlog

Ordered by severity, then global findings and partition order\. Confidence is separate\. Each finding retains its scope; potentially overlapping findings are not silently merged\. Proposed actions are not executed\.

| Scope / finding | Severity | Confidence | Classification | Observation | Affected items | Recommendation | Verification | Owner role | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Finding interpretation

0 local findings; 0 global findings\. Zero findings does not resolve unknown checks or demonstrate measured search visibility\.


## Evidence and partition reports

Evidence identifiers are scoped by partition\. Links resolve to the original validated snapshots; keep source campaign and receipt with this report when sharing\. Raw bodies are not embedded here\.

| Partition / evidence | Item | Kind | Captured | SHA\-256 | Artifact |
| --- | --- | --- | --- | --- | --- |
| [parts/000001](../../../nks-native-accuracy-017-aw7tyj9_/codex/audits/content-search/fixture-campaign/parts/000001/report.md) |  | Partition report |  |  |  |
| parts/000001:591b8035822f143d88cb4eeae5d693babf90f6457ac552b72ebc371ec5a11877 | 1eec6770ccb0ac80ef452d7c3f99c737efa242414cb7dd0a7f93379986f1730a | content | 2026\-11\-15T23:37:27\.485Z | cb7f59e0854bc77fb225701f8ad31e0f16a76f07333513f76eebb950bc3517ca | [evidence/1eec6770ccb0ac80ef452d7c3f99c737efa242414cb7dd0a7f93379986f1730a\.txt](../../../nks-native-accuracy-017-aw7tyj9_/codex/audits/content-search/fixture-campaign/parts/000001/evidence/1eec6770ccb0ac80ef452d7c3f99c737efa242414cb7dd0a7f93379986f1730a.txt) |

## Global context evidence

Context values and review source references are preserved in the linked receipt\. Validate its bound source before interpreting judgments\.

| Evidence | Kind | Locator | Collected | SHA\-256 | Receipt |
| --- | --- | --- | --- | --- | --- |

## Remaining work

Resolve these queues and unknown checks before claiming full coverage\. Empty queues alone do not resolve unknown checks\.

| Kind | Item | Reason |
| --- | --- | --- |

## Measurements and interpretation

No visibility metrics are inferred or pooled by this report\. Consult explicitly supplied, dated, surface\-specific measurements in the underlying evidence\. Readiness is not measured mentions, citations, ranking or revenue; missing observations are unknown, not zero\.


## Visibility measurement status

SYNTHETIC FIXTURE DATA — not live visibility


## Visibility observations



| Engine | Surface | Model | Search | Locale/market | Cohort | Dates | Mention | Citation | Capture errors | Unknown mention/citation |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| fixture | api | unknown | enabled | vi\-VN/VN | accuracy@1 | 2026\-11\-15T23:35:23\.819Z – 2026\-11\-15T23:35:23\.819Z | Unavailable \(0 reviewed responses\) | Unavailable \(0 reviewed responses\) | 0 | 2/2 |

## Adjudicated AI\-answer accuracy



| Segment | Claim accuracy | Fully reviewed response accuracy | Unknown claims | Reviewed/unreviewed responses | Incomplete/empty/unresolved inventories |
| --- | --- | --- | --- | --- | --- |
| \[&quot;fixture&quot;,&quot;api&quot;,&quot;unknown&quot;,&quot;enabled&quot;,&quot;vi\-VN&quot;,&quot;VN&quot;,&quot;accuracy&quot;,&quot;1&quot;\] | 1/2 \(50\.0%\) | 0/1 \(0\.0%\) | 0 | 1/1 | 0/0/0 |

## Accuracy denominator

Claim accuracy uses correct/\(correct\+incorrect\) supplied material\-claim judgments; unknown claims are excluded and disclosed\. Response accuracy includes only complete, nonempty claim inventories without unknown verdicts; all claims must be correct\. Missing reviews and zero denominators are unavailable, never perfect\. These are reviewer assertions, not automatic fact checks or population estimates; inventory exclusion counts can overlap\.


## Measurement denominator

Captured responses with supplied non\-null annotations within each segment; capture errors and unknown annotations are disclosed separately\. Citation means at least one exact authorized brand\-host citation in a response, not share of all citations\.


## Measurement limitations

Artifact hashes verify supplied bytes, not capture authenticity or annotation correctness; Accuracy uses supplied material\-claim judgments, not automatic fact checking or population accuracy; no cross\-period uplift, causal attribution or market\-wide estimate is inferred; Only supplied exact brand hosts count; subdomains must be explicitly listed


## AI observation evidence



| Artifact |
| --- |
| [ai\-observation\-evidence\.json](ai-observation-evidence.json) |
| [ai\-observations\.jsonl](ai-observations.jsonl) |

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.


## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.


## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.


## Server\-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.


## Rule provenance

Sources and review dates belong to the validated packaged rule registry; they do not certify current search outcomes\.

| Rule | Reviewed | Sources | Limitations |
| --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve missing local/global evidence, complete declared discovery, apply new immutable reviews and regenerate this report\. The current audit is partial\.

