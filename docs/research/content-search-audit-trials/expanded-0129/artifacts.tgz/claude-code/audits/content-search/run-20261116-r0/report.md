# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T15:31:47\.761Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 0e3b1221\-4876\-4bd9\-9988\-a51f20c3619e\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |
| fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 15781adc8dd9138e72283768262011c16d1c21815700ce70e7254794903debf2 | 2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72 | local\-file | 2026\-11\-16T15:31:47\.737Z | 0 full elapsed days | [evidence/2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72\.txt](evidence/2277e11e047ac309357118c5619c41773f1ad1cac70fe8bfb67f95081d6fbc72.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2f38026dcc2da44f2c354c0efb1946a9f4f0f59629021098256111f94a265d1b | 3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b | local\-file | 2026\-11\-16T15:31:47\.738Z | 0 full elapsed days | [evidence/3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b\.txt](evidence/3a3a4f9c34a4c9045f3a5ffe52b3e1b43e47e8702c04c9a207c4a98f8b95f33b.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8b4fefcb212bcbcfeaf85cc12b94d1120878b633b637ee79f2ffc0c28f9fc677 | 8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9 | local\-file | 2026\-11\-16T15:31:47\.739Z | 0 full elapsed days | [evidence/8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9\.txt](evidence/8ae7aa4dcbb2f800d9e28fa98f3915a2024a8cfb90f9aa272eaf54173bd39ee9.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 861d9d40a55093823b039ed8d1c6724ade410628687ffd7d8066a6b6cdbfd86a | a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad | local\-file | 2026\-11\-16T15:31:47\.739Z | 0 full elapsed days | [evidence/a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad\.txt](evidence/a8f4351e42be8f8357c705fab7e2e868b0bac06cbbe2fd4e14afe119ab2ac5ad.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0ecd4c46c536590f811d0ab1ce1a7134d90218d98d6c6b06ac8ec742a9cb821b | b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05 | local\-file | 2026\-11\-16T15:31:47\.740Z | 0 full elapsed days | [evidence/b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05\.txt](evidence/b613a4f3bf3df294f4f6f325d2db4242945acd6cc79913b29dc590101340fa05.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b49809cc6268dccc83f24d36e15cbb28a58260532546b2139cd72038d0bbb58c | be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2 | local\-file | 2026\-11\-16T15:31:47\.741Z | 0 full elapsed days | [evidence/be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2\.txt](evidence/be14ddd19d148b2d116f66c2079ddf9991e3c842d4091694d0eabbd5c1013ec2.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| eb46bed7cda9a0f69a7d79fd311bf056431c6676ec6da8a269b187ec8f12a202 | c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46 | local\-file | 2026\-11\-16T15:31:47\.741Z | 0 full elapsed days | [evidence/c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46\.txt](evidence/c847023339efbc92cdf3f091a9fb9b4044227f2bb4515c6bfbd048c4f4051a46.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2f2e60771016506220a7856ec8dbb6bf7d0c2fd5e9f39f2c9c95570697cd2907 | f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97 | local\-file | 2026\-11\-16T15:31:47\.742Z | 0 full elapsed days | [evidence/f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97\.txt](evidence/f1fb863809c8ef9497035e9f41d0dd0a6f73f3f81cdd1f83d4e5601446768b97.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8f151416a525d5f3347849822ff3b15e50407aaab5c677031d31b947fb06d936 | f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80 | local\-file | 2026\-11\-16T15:31:47\.742Z | 0 full elapsed days | [evidence/f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80\.txt](evidence/f6666138561a8385271da3409aff26056850754bc531adb41b521864e97abd80.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0ffa0737a460e9cf7d8f8bd31bb2bc9254d89677b14af6df155af43408454422 | fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35 | local\-file | 2026\-11\-16T15:31:47\.743Z | 0 full elapsed days | [evidence/fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35\.txt](evidence/fff779797482c66100814489317e175063f3b43947cd6bede01cfc1f33a8eb35.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
