const fs=require("fs");const f=process.argv[2]+"/report.md";const t=fs.readFileSync(f,"utf8");
const a="Every source quotation in this report is listed in `audits/content-search/work/quotes.json` and was checked against its cited lines with the skill's quote verifier.";
const b="All 31 block quotations in this report are listed in `audits/content-search/work/quotes.json` and were checked against their cited lines with the skill's quote verifier. Short phrases repeated inside sentences (the page title in dossier 06, \"published this month\" in dossier 08, and directive or price values) are not in that ledger; I checked them by reading the source lines.";
if(!t.includes(a))throw new Error("anchor missing");fs.writeFileSync(f,t.replace(a,b));console.log("edited");
