const fs=require("fs"),crypto=require("crypto"),path=require("path");
const R=process.argv[2];const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const rep=fs.readFileSync(R+"/report.md");const lines=rep.toString("utf8").split("\n");
const quotes=[];let bq=0;
lines.forEach((l,i)=>{ if(l.startsWith(">"))bq++;
  const m=l.match(/^> `(.*)` — `([\w.-]+\.md):(\d+)(?:-(\d+))?`$/); if(!m)return;
  quotes.push({quoteId:"Q"+(quotes.length+1),source:"targets/"+m[2],sourceLabel:m[2],sourceHash:hash(fs.readFileSync(R+"/targets/"+m[2])),
    startLine:+m[3],endLine:+(m[4]||m[3]),reportStartLine:i+1,reportEndLine:i+1,normalization:"whitespace",quote:m[1]});});
fs.writeFileSync(R+"/audits/content-search/work/quotes.json",JSON.stringify({root:R,report:"report.md",reportHash:hash(rep),quotes},null,2)+"\n");
console.log("blockquote lines",bq,"ledger quotes",quotes.length);
