from pathlib import Path
import json, hashlib
from datetime import datetime, timezone

base = Path(__file__).parent
initial = base / 'initial'
snapshots = {
    Path(e['locator']).name[:2]: e
    for e in map(json.loads, (initial / 'evidence.jsonl').read_text().splitlines())
    if e['kind'] == 'content'
}
now = datetime.now(timezone.utc).isoformat(timespec='milliseconds')
bundle = dict(artifacts={}, evidence=[], reviews=[], findings=[])

def evidence(n, kind, start, end=None, value=None):
    snapshot = snapshots[n]
    end = end or start
    span = '\n'.join(snapshot['value'].splitlines()[start-1:end])
    if value is None:
        value = span
    encoding = 'utf8' if isinstance(value, str) else 'json'
    raw = value if encoding == 'utf8' else json.dumps(value, ensure_ascii=False)
    evidence_id = f'dossier-{n}-{kind}'
    artifact = f'evidence/{evidence_id}.' + ('txt' if encoding == 'utf8' else 'json')
    locator = f"{Path(snapshot['locator']).name}:{start}" + (f'-{end}' if start != end else '')
    bundle['artifacts'][artifact] = raw
    bundle['evidence'].append(dict(
        evidenceId=evidence_id, itemId=snapshot['itemId'], kind=kind, encoding=encoding,
        artifact=artifact, value=value, byteLength=len(raw.encode()), collectedAt=now,
        method='attributed offline dossier excerpt or transcription',
        locator=locator, snapshotHash=hashlib.sha256(raw.encode()).hexdigest(),
        sourceEvidenceIds=[snapshot['evidenceId']], redaction='none',
        limitations=['Synthetic dossier evidence. Basis is the stated capture or supplied owner context. Live behavior and independent corroboration are outside scope.']
    ))
    return evidence_id

def review(n, rule, status, reason, evidence_ids):
    bundle['reviews'].append(dict(
        itemId=snapshots[n]['itemId'], ruleId=rule, status=status, reason=reason,
        evidenceIds=[snapshots[n]['evidenceId'], *evidence_ids], reviewer='Codex',
        reviewedAt=now
    ))

def finding(n, key, title, severity, reason, remediation, verification, owner, effort, rules, evidence_ids):
    for rule in rules:
        review(n, rule, 'fail', reason, evidence_ids)
    bundle['findings'].append(dict(
        findingId=key, title=title, affectedItemIds=[snapshots[n]['itemId']],
        ruleIds=rules, dimensions=list(dict.fromkeys(rule.split('-')[0] for rule in rules)),
        evidenceIds=[snapshots[n]['evidenceId'], *evidence_ids],
        severity=severity, confidence='high', classification='observed',
        remediation=remediation, verification=verification, ownerRole=owner, effort=effort
    ))

http = evidence('01', 'http-response', 4, 5, dict(status=200, capturedAt='2026-11-10T08:00:00Z', headers={'X-Robots-Tag':'noindex'}))
intent = evidence('01', 'publisher-intent', 3)
finding('01','F1','HTTP noindex conflicts with Google indexing intent','high',
        'At the supplied capture the response header directly contradicts the stated Google indexing intent, despite the permissive page meta and self-canonical.',
        'Remove the unintended noindex header from the product response.',
        'Inspect a fresh supplied response and raw head for successful transport and compatible directives, and request a separate dated Google indexing observation if needed.',
        'Web platform owner','small',['seo-index-controls'],[http,intent])

route = evidence('02','canonical-targets',3,7)
finding('02','F2','Redirect loop prevents access to the preferred destination','high',
        'The two same-deployment redirects cycle. The publisher-intended target, also named in the older sitemap, redirects straight back.',
        'Serve /new directly and retain a single permanent redirect from /old to /new.',
        'Trace both paths from fresh supplied captures through to the final response and check the current sitemap and declared canonical against the intended URL.',
        'Web platform owner','small',['seo-canonical'],[route])

schema = evidence('03','schema-extraction',8,18)
entity = evidence('03','entity-record',3,4)
finding('03','F3','Structured offer misstates the US monthly price','medium',
        'Product Offer JSON-LD says USD 19 while the same-capture visible source and approved US monthly pre-tax policy say USD 29.',
        'Update the structured offer to USD 29 and use a shared source for visible and marked-up price.',
        'Compare the visible US monthly pre-tax price with price and currency in the parsed JSON-LD from the same capture.',
        'Commerce content and markup owner','small',['seo-structured-data','aio-entity-consistency'],[schema,entity])

entity = evidence('04','entity-record',3,6)
inventory = evidence('04','inventory-map',3,6)
finding('04','F4','Two current pages contradict each other on the Starter allowance','medium',
        'The two current passages are about the same version, plan, market and monthly unit but give different values. The authoritative table is unavailable.',
        'Obtain the entitlement record for version 2026-10-01 and reconcile both pages to it.',
        'Compare both revised passages to the authoritative record for their shared market and billing period.',
        'Product policy and content owners','medium',['aio-entity-consistency','portfolio-contradictions'],[entity,inventory])

policy = evidence('05','claim-sources',5)
finding('05','F5','Vietnamese draft misstates free ticket-change eligibility and notice','high',
        'The draft promises fee-free changes to all customers without notice. Supplied policy limits the fee waiver to Thành viên and requires at least 24 hours of notice.',
        'Correct the Vietnamese draft to state the eligible tier, deadline before departure and separate fee schedule for other tiers.',
        'Check the complete revised sentence against the supplied policy, including the exact boundary and treatment of other tiers. Confirm any amounts from the fee table before adding them.',
        'Vietnamese content and policy owners','small',['quality-claims','aeo-answer-evidence'],[policy])

context = evidence('07','audience-context',3,5)
procedure = evidence('07','claim-sources',4,5)
review('07','quality-task-fit','pass','The stated Vietnamese audience gets an ordered CSV export procedure, the separate attachment retrieval step and the processing-time limitation.',[context])
review('07','quality-claims','pass','The supplied product procedure confirms the steps and limits for the complete help passage.',[procedure])
review('07','aio-retrievable-facts','pass','The complete Vietnamese export instructions retain task sequence, attachment limitation and timing scope in the text export.',[context])
review('07','aeo-answer-evidence','pass','The supplied procedure confirms the whole task answer, including the attachment exception and timing language.',[procedure])

metadata = evidence('08','claim-sources',3,5)
review('08','quality-claims','pass','Supplied metadata corroborates the reported synthetic English API panel dates, publication month and 40 of 100 responses. The text expressly limits the claim to historical observations.',[metadata])
review('08','quality-freshness','pass','The draft distinguishes November 2026 publication from February 2024 collection and disclaims any current rate as of 2026-11-16.',[metadata])

policy = evidence('10','claim-sources',3)
review('10','quality-claims','pass','Supplied policy confirms the only customer-facing claim. The hidden tool instructions are fixture data outside the product claim.',[policy])

for item, line in [('05',4),('07',4),('08',4),('10',3)]:
    passage = snapshots[item]['value'].splitlines()[line-1]
    evidence(item,'extracted-text',line,value=passage.partition(': ')[2])
(base/'review.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2)+'\n')
