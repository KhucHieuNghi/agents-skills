# Independent synthetic scenarios A–J — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T15:32:31\.632Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 8eeafe0b\-6d2f\-4c08\-9cde\-b071d0437d7a\. 5 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | HTTP noindex conflicts with Google indexing intent | seo\-index\-controls | seo | high | high | observed | 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the unintended noindex header from the product response\. | Inspect a fresh supplied response and raw head for successful transport and compatible directives, and request a separate dated Google indexing observation if needed\. | Web platform owner | small | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a, dossier\-01\-http\-response, dossier\-01\-publisher\-intent |
| F2 | Redirect loop prevents access to the preferred destination | seo\-canonical | seo | high | high | observed | a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Serve /new directly and retain a single permanent redirect from /old to /new\. | Trace both paths from fresh supplied captures through to the final response and check the current sitemap and declared canonical against the intended URL\. | Web platform owner | small | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8, dossier\-02\-canonical\-targets |
| F5 | Vietnamese draft misstates free ticket\-change eligibility and notice | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Correct the Vietnamese draft to state the eligible tier, deadline before departure and separate fee schedule for other tiers\. | Check the complete revised sentence against the supplied policy, including the exact boundary and treatment of other tiers\. Confirm any amounts from the fee table before adding them\. | Vietnamese content and policy owners | small | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f, dossier\-05\-claim\-sources |
| F3 | Structured offer misstates the US monthly price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | medium | high | observed | 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Update the structured offer to USD 29 and use a shared source for visible and marked\-up price\. | Compare the visible US monthly pre\-tax price with price and currency in the parsed JSON\-LD from the same capture\. | Commerce content and markup owner | small | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c, dossier\-03\-schema\-extraction, dossier\-03\-entity\-record |
| F4 | Two current pages contradict each other on the Starter allowance | aio\-entity\-consistency, portfolio\-contradictions | aio, portfolio | medium | high | observed | 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Obtain the entitlement record for version 2026\-10\-01 and reconcile both pages to it\. | Compare both revised passages to the authoritative record for their shared market and billing period\. | Product policy and content owners | medium | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b, dossier\-04\-entity\-record, dossier\-04\-inventory\-map |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 2 | 34 | 0 |
| aio | 36 | 3 | 33 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 1 | 47 | 0 |
| quality | 60 | 10 | 50 | 0 |
| seo | 96 | 4 | 92 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | pending | Snapshot review incomplete | 26 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | pending | Snapshot review incomplete | 26 |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | pending | Snapshot review incomplete | 26 |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | pending | Snapshot review incomplete | 26 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | pending | Snapshot review incomplete | 26 |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | pending | Snapshot review incomplete | 26 |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | pending | Snapshot review incomplete | 26 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | pending | Snapshot review incomplete | 26 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | dossier\-01\-http\-response |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-index\-controls | seo | fail | At the supplied capture the response header directly contradicts the stated Google indexing intent, despite the permissive page meta and self\-canonical\. | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a, dossier\-01\-http\-response, dossier\-01\-publisher\-intent |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | quality\-claims | quality | pass | Supplied metadata corroborates the reported synthetic English API panel dates, publication month and 40 of 100 responses\. The text expressly limits the claim to historical observations\. | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132, dossier\-08\-claim\-sources |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | quality\-freshness | quality | pass | The draft distinguishes November 2026 publication from February 2024 collection and disclaims any current rate as of 2026\-11\-16\. | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132, dossier\-08\-claim\-sources |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-08\-extracted\-text |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | quality\-task\-fit | quality | pass | The stated Vietnamese audience gets an ordered CSV export procedure, the separate attachment retrieval step and the processing\-time limitation\. | dossier\-07\-audience\-context, fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | quality\-claims | quality | pass | The supplied product procedure confirms the steps and limits for the complete help passage\. | dossier\-07\-claim\-sources, fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-07\-extracted\-text |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-locales | seo | unknown | Missing required evidence: locale\-map | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aio\-retrievable\-facts | aio | pass | The complete Vietnamese export instructions retain task sequence, attachment limitation and timing scope in the text export\. | dossier\-07\-audience\-context, fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | aeo\-answer\-evidence | aeo | pass | The supplied procedure confirms the whole task answer, including the attachment exception and timing language\. | dossier\-07\-claim\-sources, fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-structured\-data | seo | fail | Product Offer JSON\-LD says USD 19 while the same\-capture visible source and approved US monthly pre\-tax policy say USD 29\. | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c, dossier\-03\-entity\-record, dossier\-03\-schema\-extraction |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aio\-entity\-consistency | aio | fail | Product Offer JSON\-LD says USD 19 while the same\-capture visible source and approved US monthly pre\-tax policy say USD 29\. | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c, dossier\-03\-entity\-record, dossier\-03\-schema\-extraction |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | quality\-claims | quality | pass | Supplied policy confirms the only customer\-facing claim\. The hidden tool instructions are fixture data outside the product claim\. | dossier\-10\-claim\-sources, fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-10\-extracted\-text |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | quality\-claims | quality | fail | The draft promises fee\-free changes to all customers without notice\. Supplied policy limits the fee waiver to Thành viên and requires at least 24 hours of notice\. | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f, dossier\-05\-claim\-sources |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-05\-extracted\-text |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | aeo\-answer\-evidence | aeo | fail | The draft promises fee\-free changes to all customers without notice\. Supplied policy limits the fee waiver to Thành viên and requires at least 24 hours of notice\. | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f, dossier\-05\-claim\-sources |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aio\-entity\-consistency | aio | fail | The two current passages are about the same version, plan, market and monthly unit but give different values\. The authoritative table is unavailable\. | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b, dossier\-04\-entity\-record, dossier\-04\-inventory\-map |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | portfolio\-contradictions | portfolio | fail | The two current passages are about the same version, plan, market and monthly unit but give different values\. The authoritative table is unavailable\. | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b, dossier\-04\-entity\-record, dossier\-04\-inventory\-map |
| 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-canonical | seo | fail | The two same\-deployment redirects cycle\. The publisher\-intended target, also named in the older sitemap, redirects straight back\. | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8, dossier\-02\-canonical\-targets |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 96ac63489b8ff7d43fa79c9ea964ff7b08b37ceaeadad12de374fb54c342014a | 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | local\-file | 2026\-11\-16T15:31:31\.775Z | 0 full elapsed days | [evidence/104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55\.txt](evidence/104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 113b3dab46acba117ad9b037cdda4b6add8624bdf126d738a7fb1b7aaa1f8132 | 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | local\-file | 2026\-11\-16T15:31:31\.777Z | 0 full elapsed days | [evidence/170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a\.txt](evidence/170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| fa30a6a9a1b72535f12605f170e29e764777018444d8b82b89fb53b4028453ca | 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | local\-file | 2026\-11\-16T15:31:31\.778Z | 0 full elapsed days | [evidence/1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef\.txt](evidence/1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b30ae8baf145a2d9c75f0962f4afa76e6ee1c850a123bb4e7ac78c9de118a77c | 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | local\-file | 2026\-11\-16T15:31:31\.779Z | 0 full elapsed days | [evidence/31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1\.txt](evidence/31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| fd3ea0f72a4b5f1a39fe78861b214f8d5d87fdd58c6024a4940d2bdf3a6e6f46 | 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | local\-file | 2026\-11\-16T15:31:31\.779Z | 0 full elapsed days | [evidence/3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4\.txt](evidence/3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a27bff6d0213248880ba255c5c5a060c283dfcb4f33d697640a578a9a1c2c31f | 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | local\-file | 2026\-11\-16T15:31:31\.780Z | 0 full elapsed days | [evidence/4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418\.txt](evidence/4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 54a1faa25fcde3db9bf06a93c19f8e809847451958b75561fccbd962fe81dc4b | 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | local\-file | 2026\-11\-16T15:31:31\.780Z | 0 full elapsed days | [evidence/5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a\.txt](evidence/5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4809003ef795a8f04a2312385f0862552f1cc95b5f9051518e076c01d2d542e8 | a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | local\-file | 2026\-11\-16T15:31:31\.781Z | 0 full elapsed days | [evidence/a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2\.txt](evidence/a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 05c6d5a83b69135196c74efb73ecae635bbbe4934104209d15e532246b9fbbe4 | acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b | local\-file | 2026\-11\-16T15:31:31\.781Z | 0 full elapsed days | [evidence/acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b\.txt](evidence/acf493b93c966fe8f636c8fe5b69a120a6edc97db2bf49f2c7f6a059702a035b.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a5d66582f3edb0720caf45a683bfb2b5d6b27d8dd5cec21bbbb3206087a0014d | b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545 | local\-file | 2026\-11\-16T15:31:31\.782Z | 0 full elapsed days | [evidence/b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545\.txt](evidence/b21682344883129278c90aa47eac1bb31755ab7f9c0f8bb7fa4734e526d33545.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dossier\-01\-http\-response | 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-01\-http\-response\.json](evidence/dossier-01-http-response.json) | ddffc152934a961ea252796efa3a82d6daa5e0fd716401b45e3b5267735dc7ad | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-01\-publisher\-intent | 104f256fc8cbd8c62f352c90fce4bb0b17c531b345bd00ae9890f54b59b62e55 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-01\-publisher\-intent\.txt](evidence/dossier-01-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-02\-canonical\-targets | a5fb3f924d8192f71c51f33ac68a76c0fa556b007d6ab4cad701fb6bd8b15bc2 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-02\-canonical\-targets\.txt](evidence/dossier-02-canonical-targets.txt) | 2f5e425ce0585fbb1dc363d41eed691bdec4c2b4f4f9c5d76742e02153a1faad | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-03\-schema\-extraction | 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-03\-schema\-extraction\.txt](evidence/dossier-03-schema-extraction.txt) | 0c522356b25041d496d85210dae7c21b789759cc375e8c170bfa026ccf25c81d | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-03\-entity\-record | 31de8be19524d0043877c50d42f810d5f48553be2f57e8e6efdec79db95d90d1 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-03\-entity\-record\.txt](evidence/dossier-03-entity-record.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-04\-entity\-record | 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-04\-entity\-record\.txt](evidence/dossier-04-entity-record.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-04\-inventory\-map | 5d3d87d47837e351069dbe80e6320198f791c1c520c6cfcd69fce497e79f421a | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-04\-inventory\-map\.txt](evidence/dossier-04-inventory-map.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-05\-claim\-sources | 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-05\-claim\-sources\.txt](evidence/dossier-05-claim-sources.txt) | 2af2411c2c3cfa27fc949c553e7fdf34b4268519a65ed45aedcb56db3539d9db | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-07\-audience\-context | 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-07\-audience\-context\.txt](evidence/dossier-07-audience-context.txt) | c30cdeb63bb9875bc0d9e1597a6901bc57c8618b73f41b106a6bd454c75ba271 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-07\-claim\-sources | 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-07\-claim\-sources\.txt](evidence/dossier-07-claim-sources.txt) | 7148637143c17a923c83788e641a724c8f19a65bf61ef2cc1df2a894b4ac510a | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-08\-claim\-sources | 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-08\-claim\-sources\.txt](evidence/dossier-08-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-10\-claim\-sources | 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-10\-claim\-sources\.txt](evidence/dossier-10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-05\-extracted\-text | 4934076b2c1f028a5cfb0954d66f93abc007a738710cd085386ec6d255d7a418 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-05\-extracted\-text\.txt](evidence/dossier-05-extracted-text.txt) | 10a7579133b1123a2ef89f6bdb6a6428db1118dd148db2188c19404431a5efa6 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-07\-extracted\-text | 1863849d41f4b6a494312debfe1a236153697f3244710ccf521f0fa9682daeef | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-07\-extracted\-text\.txt](evidence/dossier-07-extracted-text.txt) | b4dc8f912e00ca5065c2abec27c20d2d3ba2372f1f4eb4ce479f915de687e6f7 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-08\-extracted\-text | 170ebe27b5fbf3f2d22d7d1c7c6d75c713c18bd31e4c3e1c0d03f7b312a5f61a | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-08\-extracted\-text\.txt](evidence/dossier-08-extracted-text.txt) | 7e1198481faa295c42d6cfdf468fd13cc1fa53c1c2baedb1a13e84a9d56d5fd4 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |
| dossier\-10\-extracted\-text | 3d1d9815805df92311950cdcfa027cadf5669ac0bff16bda32ff36ea34cd4ed4 | attributed offline dossier excerpt or transcription | 2026\-11\-16T15:32:31\.324\+00:00 | 0 full elapsed days | [evidence/dossier\-10\-extracted\-text\.txt](evidence/dossier-10-extracted-text.txt) | 6ba7c1b6ba14a9c8ebaa6cbde9e8466a53c4b77d1cf119ac776121e8a7daa928 | Synthetic dossier evidence\. Basis is the stated capture or supplied owner context\. Live behavior and independent corroboration are outside scope\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
