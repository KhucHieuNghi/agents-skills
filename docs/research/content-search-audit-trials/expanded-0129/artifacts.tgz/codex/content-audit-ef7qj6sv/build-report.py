from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).resolve().parent
root = base.parent
report = root / 'report.md'
validation = json.loads((base / 'validation.json').read_text())
assert validation['valid'] and not validation['completionAllowed']
coverage = validation['coverage']
assert coverage['total'] == coverage['inScope'] == 12
assert coverage['states'] == dict(pending=10, audited=0, failed=0, blocked=2, unsupported=0, excluded=0)
assert len(json.loads((base / 'reviewed' / 'findings.json').read_text())) == 5
dim_names = dict(quality='Content quality',seo='SEO',aio='AIO',aeo='AEO',geo='GEO',portfolio='Portfolio')
rows = ['| Dimension | Planned | Resolved | Unknown |','| --- | ---: | ---: | ---: |']
for key, counts in coverage['dimensions'].items():
    rows.append(f"| {dim_names[key]} | {counts['total']} | {counts['completed']} | {counts['unknown']} |")
tot, res, unk = (sum(v[k] for v in coverage['dimensions'].values()) for k in ['total','completed','unknown'])
rows.append(f'| **Total** | **{tot}** | **{res}** | **{unk}** |')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

quotes = []
output = []
for line in (base / 'report-template.md').read_text().splitlines():
    match = re.fullmatch(r'\{\{(\d\d):(\d+)(?:-(\d+))?\}\}', line)
    if not match:
        output.extend(rows if line == '{{COVERAGE}}' else [line])
        continue
    dossier, first, last = match.groups()
    source, = (root / 'targets').glob(dossier + '-*.md')
    first, last = int(first), int(last or first)
    raw = source.read_bytes()
    source_lines = raw.decode().splitlines()[first-1:last]
    quote = '\n'.join(source_lines)
    locator = f'{source.name}:{first}' + (f'-{last}' if first != last else '')
    output.extend(['**' + locator + '**', '', '\x60\x60\x60text', *source_lines, '\x60\x60\x60', ''])
    quotes.append(dict(quoteId=f'dossier-{dossier}-{first}',source=str(source.relative_to(root)),sourceLabel=source.name,
                       sourceHash=digest(raw),startLine=first,endLine=last,reportStartLine=len(output)-len(source_lines)-4,
                       reportEndLine=len(output)-2,normalization='exact',quote=quote))
report.write_text('\n'.join(output)+'\n')
ledger = dict(root=str(root),report=report.name,reportHash=digest(report.read_bytes()),quotes=quotes)
(base / 'quotes.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
