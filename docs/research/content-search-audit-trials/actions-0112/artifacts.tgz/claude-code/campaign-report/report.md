# Content audit — Content Search Audit

Partial.

## Scope and coverage

Counts use unique owned content, not repeated placeholder rows\. Completion concerns audit coverage, not whether content is defect\-free\. Discovery completeness is a declared scope assertion\.

| Metric | Value |
| --- | --- |
| Campaign | f1e64f12\-6a4c\-40ef\-99e2\-97ea137bf022 |
| Declared items | 1 |
| Owned/attempted | 1 |
| Collected | 0 |
| Audited | 0 |
| Inventory complete | true |
| Mode | full |
| Unresolved items | 1 |
| Missing checks | 0 |
| Pending queue | 0 |
| Global rules unresolved | portfolio\-task\-gaps, portfolio\-duplication, portfolio\-contradictions, portfolio\-journey\-links |
| pending | 0 |
| audited | 0 |
| failed | 1 |
| blocked | 0 |
| unsupported | 0 |
| excluded | 0 |

## Dimension coverage

Supplied checks only; missing checks are reported separately\. No combined SEO/GEO score is calculated\.

| Dimension | Supplied | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 1 | 7 | 0 |
| aio | 3 | 0 | 3 | 0 |
| aeo | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |

## Global portfolio review

Attributed judgments remain subject to domain review\. Evidence hashes and valid references do not certify semantic truth or reviewer identity\.

| Rule | Status | Reason | Reviewer | Reviewed | Applicability reason |
| --- | --- | --- | --- | --- | --- |

## Priority backlog

Ordered by severity, then global findings and partition order\. Confidence is separate\. Each finding retains its scope; potentially overlapping findings are not silently merged\. Proposed actions are not executed\.

| Scope / finding | Severity | Confidence | Classification | Observation | Affected items | Recommendation | Action | Action origin | Action reason | Verification | Owner role | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| parts/000001 / 04288dd5d36af6c2e0dfff8013424eef40a46cab824d3db1caa358501c5b4364 | low | high | observed | Captured HTTP status 404; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | Confirm intended access and page lifecycle before proposing changes; an anonymous HTTP error alone does not establish a search\-ranking defect | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Repeat an authorized read and compare expected behavior with captured status and content | Content owner and website operator | Triage required | parts/000001:49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 |

## Finding interpretation

1 local findings; 0 global findings\. Zero findings does not resolve unknown checks or demonstrate measured search visibility\.


## Evidence and partition reports

Evidence identifiers are scoped by partition\. Links resolve to the original validated snapshots; keep source campaign and receipt with this report when sharing\. Raw bodies are not embedded here\.

| Partition / evidence | Item | Kind | Captured | SHA\-256 | Artifact |
| --- | --- | --- | --- | --- | --- |
| [parts/000001](../../../nks-backlog-0110-nlxlkurm/codex/source/parts/000001/report.md) |  | Partition report |  |  |  |
| parts/000001:d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | crawler\-policy | 1970\-01\-01T00:00:00\.000Z | 11ccc263980f86d40cc4ca2c743f39e1d17af580ca1dfec9f2cbde4d912b7a0d | [evidence/d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606\.json](../../../nks-backlog-0110-nlxlkurm/codex/source/parts/000001/evidence/d333955ecf87682f7ebd45c0f8919eefee5419081f439bd5d9939d2ec9172606.json) |
| parts/000001:3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | http\-body\-encoded | 1970\-01\-01T00:00:00\.000Z | 283e800279e15920fd2adf76a150ecfada07b216e1d9c9c842fc762fcfb5e0a4 | [evidence/3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427\.json](../../../nks-backlog-0110-nlxlkurm/codex/source/parts/000001/evidence/3e5444f63bdd9be068bea878fdd1a1b87f0008dbc0affce7b58d91f21a462427.json) |
| parts/000001:49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085 | 75d4e6a3023d05ae09187b68765a6ad162bfe7f33354091f083cda2e541de656 | http\-response | 1970\-01\-01T00:00:00\.000Z | 812886d7de3ebe68f5e9bdbf917f8d05de99f891313dc89c3129c23dc4343602 | [evidence/49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085\.json](../../../nks-backlog-0110-nlxlkurm/codex/source/parts/000001/evidence/49793c0f5225066620befe52cd985f3dcbf62227057ba93883b95ea0c2d37085.json) |

## Global context evidence

Context values and review source references are preserved in the linked receipt\. Validate its bound source before interpreting judgments\.

| Evidence | Kind | Locator | Collected | SHA\-256 | Receipt |
| --- | --- | --- | --- | --- | --- |

## Remaining work

Resolve these queues and unknown checks before claiming full coverage\. Empty queues alone do not resolve unknown checks\.

| Kind | Item | Reason |
| --- | --- | --- |

## Measurements and interpretation

No visibility metrics are inferred or pooled by this report\. Consult explicitly supplied, dated, surface\-specific measurements in the underlying evidence\. Readiness is not measured mentions, citations, ranking or revenue; missing observations are unknown, not zero\.


## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.


## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.


## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.


## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.


## Server\-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.


## Rule provenance

Sources and review dates belong to the validated packaged rule registry; they do not certify current search outcomes\.

| Rule | Reviewed | Sources | Limitations |
| --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve missing local/global evidence, complete declared discovery, apply new immutable reviews and regenerate this report\. The current audit is partial\.

