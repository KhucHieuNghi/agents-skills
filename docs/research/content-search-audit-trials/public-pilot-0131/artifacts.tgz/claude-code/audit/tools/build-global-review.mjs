// Builds the attributed global portfolio review bundle from the reviewed campaign index. Inert local reads only.
// Usage: node build-global-review.mjs CAMPAIGN_DIR INDEX_DIR DISCOVERY_DIR OUT_BUNDLE.json
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
const [campaignDir, indexDir, discoveryDir, outFile] = process.argv.slice(2);
const PART = "parts/000001";
const sha = (s) => createHash("sha256").update(s).digest("hex");
const L = (f) => fs.readFileSync(f, "utf8").trim().split("\n").map(JSON.parse);
const index = JSON.parse(fs.readFileSync(path.join(indexDir, "index.json"), "utf8"));
const inv = L(path.join(campaignDir, PART, "inventory.jsonl"));
const ev = L(path.join(campaignDir, PART, "evidence.jsonl"));
const discovery = JSON.parse(fs.readFileSync(path.join(discoveryDir, "discovery.json"), "utf8"));
const source = JSON.parse(fs.readFileSync(path.join(discoveryDir, "source.json"), "utf8"));
const graphHash = sha(fs.readFileSync(path.join(discoveryDir, "graph.jsonl")));
const now = new Date().toISOString();
const REVIEWER = "Claude (model claude-fable-5-2), host reviewer running the content-search-audit skill; automated agent review, not a human domain expert";
const ref = (evidenceId) => ({ part: PART, evidenceId });
const content = inv.map((i) => ev.find((e) => e.itemId === i.itemId && e.kind === "content"));
const kind = (k) => ev.filter((e) => e.kind === k && e.evidenceId.startsWith("rev1-"));
const ctx = (evidenceId, k, value, locator, sourceReferences) => ({ evidenceId, kind: k, value, snapshotHash: sha(value), locator, collectedAt: now, sourceReferences });
const map = { ...kind("inventory-map")[0].value };
delete map.boundItem;
const lg = kind("link-graph").map((e) => e.value);
const linkSummary = {
  description: "Campaign-level static link graph summary derived from the packaged discovery graph and per-item link-graph evidence.",
  graphSource: {
    file: "audit/discovery-continued/graph.jsonl", sha256: graphHash, discoveryId: discovery.discoveryId, parentDiscoveryId: discovery.recovery?.parentDiscoveryId,
    status: discovery.status, frontierRemaining: discovery.frontier.length, capturedPages: discovery.captures.length, budgets: { maxPages: source.scope.maxPages, maxDepth: source.scope.maxDepth },
  },
  pages: lg.map((v) => ({
    item: v.item, servedUrl: v.servedUrl, inScopeTargets: v.inScopeTargets.map((t) => t.uri + " [" + t.collectedStatus + "]"), inboundFromCollectedPages: v.inboundFromCollectedPages,
    unresolvedFragmentLinks: v.fragmentLinks.filter((f) => f.fragmentIdPresentInTargetSource !== true).length,
    idsWithoutInboundFragmentLink: v.idAttributesWithNoInboundFragmentLinkInInventory, plainTextFileReferencesNotHyperlinks: v.plainTextFileReferencesNotHyperlinks,
  })),
  uniqueExternalTargetsExcluded: [...new Set(source.exclusions.map((x) => x.locator))],
  discoveryPendingQueue: source.pendingQueue,
  limitations: [
    "Static a/area href links only; rendered or script-generated navigation unreviewed",
    "External targets unchecked",
    "robots.txt declares https://nkskills.getgroove.me/sitemap.xml; it is not reachable by static navigation and was not collected, so sitemap-only or orphan URLs are unknown",
  ],
};
const OWNER = "Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.";
const contextEvidence = [
  ctx("global-inventory-map", "inventory-map", JSON.stringify(map, null, 2), `derived from ${PART} content evidence of all 12 declared items (campaign ${index.campaignId})`, kind("inventory-map").map((e) => ref(e.evidenceId)).concat(content.map((e) => ref(e.evidenceId)))),
  ctx("global-link-graph", "link-graph", JSON.stringify(linkSummary, null, 2), `audit/discovery-continued/graph.jsonl (sha256 ${graphHash}) joined to ${PART} link-graph evidence`, kind("link-graph").map((e) => ref(e.evidenceId))),
  ctx("global-audience-context", "audience-context", `Owner-supplied audit context preserved verbatim from the user task statement (captured ${now}): "${OWNER}" Reviewer note: establishes positioning, the two hosts and the two audience languages only. No per-page tasks, customer questions, queries or analytics were supplied; tasks used in review are inferred from page content and labelled as such. Not independently verified.`, "user task statement for this audit session (business context paragraph)", kind("audience-context").map((e) => ref(e.evidenceId))),
  ctx("global-entity-record", "entity-record", `Owner-supplied entity statement preserved verbatim from the user task statement (captured ${now}): "${OWNER}" Reviewer note: covers brand name, offering, hosts and languages only. It contains no versions, release status, licences or limitations; the publisher release records are on github.com, outside the authorized origin, and were not collected. Not an independently verified registry.`, "user task statement for this audit session (business context paragraph)", kind("entity-record").map((e) => ref(e.evidenceId))),
];
const itemIds = inv.map((i) => i.itemId);
const contentRefs = content.map((e) => ref(e.evidenceId));
const review = (ruleId, status, reason, contextEvidenceIds, extraRefs = []) => ({ ruleId, status, reason, reviewer: REVIEWER, reviewedAt: now, itemIds, evidenceReferences: [...contentRefs, ...extraRefs], contextEvidenceIds });
const reviews = [
  review("portfolio-task-gaps", "unknown", "No question set, search query, support or analytics evidence was supplied, so audience tasks cannot be mapped to the inventory beyond the publisher's own structure, and no gap can be evidenced. Partial observation only: the 12 items form home, catalog, one solution detail page and two host guides in each of English and Vietnamese, plus one shared font-licence notice and the / redirect alias. The evaluation candidate (problem-presentation 0.1.0) has no on-site detail page; this is an exploratory observation, not an evidenced gap. Discovery scope is incomplete (no CMS export, sitemap or rendered navigation).", ["global-inventory-map", "global-audience-context"]),
  review("portfolio-duplication", "pass", "All 12 collected snapshots were read and compared. Overlap found is of three legitimate kinds: (1) five English/Vietnamese pairs declared reciprocally via hreflang with self-canonicals; (2) Codex and Claude Code guides in each locale, which share most text but differ in host name, --target value and invocation token and serve different install tasks; (3) / and /en/ are byte-identical because / answers 308 to /en/, which self-canonicalises. Home, catalog and solution pages repeat short status summaries while serving different tasks. No illegitimate duplicate was observed and no consolidation is proposed. Caveats: keyword/query cannibalization cannot be assessed without query-page data; only the incomplete static-link inventory is covered.", ["global-inventory-map"]),
  review("portfolio-contradictions", "pass", "Material claims were compared across all 12 snapshots and across locales (claim probe matrix plus full reading): Solution Skill versions and statuses (codebase-onboarding 1.1.0 technical release; problem-presentation 0.1.0 evaluation candidate), supported hosts (Codex, Claude Code), three-component composition, prerequisites, absence of a direct-download archive, per-host invocation tokens, catalog counts (2 Solution Skills, 15 upstream entries of which 6 security sources) and the pinned upstream revision links (identical sets in EN and VI) all agree; they agree with the owner entity statement where it applies (name, hosts, languages). No conflicting material claim was found, so nothing required resolution against a record. Recorded separately as local findings, not contradictions: Vietnamese FAQ wording variance on the commercial gate (F-003) and a truncated Vietnamese label (F-001). Limits: this is agreement among captured pages, not verification of truth; versions, statuses and licences were not checked against the release records on github.com (excluded origin), and the owner statement does not cover them.", ["global-inventory-map", "global-entity-record"]),
  review("portfolio-journey-links", "pass", "Using the packaged static-link graph: every HTML page links to home, catalog, try-it and its locale counterpart; home links to the solution page and both host guides; the solution page links to both guides; guides link back to the starter prompt and install section; the catalog links to the solution detail page. All in-scope link targets returned HTTP 200 and every fragment link resolves to an id in the collected target source. The next step for the owner-described audience (pick host, install, invoke) is reachable by static links in both languages. Optional improvements, not failures: the guides' #presentation section has no inbound fragment link from the problem-presentation cards on home or catalog (those lead to the catalog and an external manifest); the font-licence notice names three notice files as plain text that are not linked or collected. Rendered/script navigation is unreviewed and navigation quality is not ranking evidence.", ["global-link-graph", "global-audience-context"], kind("link-graph").map((e) => ref(e.evidenceId))),
];
const bundle = { schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash, partSnapshotHashes: index.partSnapshotHashes, contextEvidence, reviews, findings: [] };
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2));
console.log(JSON.stringify({ outFile, generatedAt: now, reviews: reviews.map((r) => r.ruleId + "=" + r.status), contextEvidence: contextEvidence.length }));
