// Read-only inert probes over collected content evidence (regex over text; no execution of target content).
import fs from "node:fs";
const part = process.argv[2];
const L = f => fs.readFileSync(f, "utf8").trim().split("\n").map(JSON.parse);
const inv = L(part + "/inventory.jsonl"), ev = L(part + "/evidence.jsonl");
const pages = inv.map(it => ({ it, c: ev.find(e => e.itemId === it.itemId && e.kind === "content") }));
const ids = {};
for (const { it, c } of pages) ids[it.uri] = new Set([...c.value.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));
for (const { it, c } of pages) {
  const h = c.value;
  console.log("\n## " + it.uri + " sha=" + c.snapshotHash.slice(0, 12));
  console.log(" ids: " + [...ids[it.uri]].join(","));
  const frag = [];
  for (const m of h.matchAll(/<a\s[^>]*href="([^"]*#[^"]*)"/g)) {
    const u = new URL(m[1], it.uri === "https://nkskills.getgroove.me/" ? "https://nkskills.getgroove.me/en/" : it.uri);
    const base = u.origin + u.pathname, f = decodeURIComponent(u.hash.slice(1));
    const ok = ids[base] ? ids[base].has(f) : "target-not-collected";
    frag.push(m[1] + "=>" + ok);
  }
  console.log(" fragment links: " + [...new Set(frag)].join(" | "));
  console.log(" ld+json: " + (h.match(/application\/ld\+json/g) || []).length + " meta-robots: " + (h.match(/<meta[^>]+name="(robots|googlebot)"[^>]*>/gi) || []).join("") + " twitter: " + (h.match(/name="twitter:[^"]+"/g) || []).length + " meta-refresh: " + /http-equiv="refresh"/i.test(h));
  console.log(" dates: " + [...new Set(h.match(/\b20\d\d[-\/]\d\d[-\/]\d\d\b|\b(19|20)\d\d\b/g) || [])].join(","));
  console.log(" lang attrs: " + [...new Set(h.match(/\slang="[^"]+"/g) || [])].join(",") + " hidden: " + (h.match(/\shidden(=""|\s|>)/g) || []).length + " aria-hidden: " + (h.match(/aria-hidden="true"/g) || []).length);
  console.log(" h1: " + (h.match(/<h1[\s\S]*?<\/h1>/gi) || []).map(s => s.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()).join(" || "));
  const eyebrow = h.match(/DANH M[^<]{0,6}</g); if (eyebrow) console.log(" eyebrow: " + JSON.stringify(eyebrow));
  const brand = h.match(/<a[^>]*class="[^"]*brand[^"]*"[^>]*>[\s\S]*?<\/a>/i); if (brand) console.log(" brand: " + brand[0].slice(0, 400));
  console.log(" NKSkills=" + (h.match(/NKSkills/g) || []).length + " \"NK Skills\"=" + (h.match(/NK Skills/g) || []).length + " versions: " + [...new Set(h.match(/\bv?\d+\.\d+\.\d+\b/g) || [])].join(","));
}
