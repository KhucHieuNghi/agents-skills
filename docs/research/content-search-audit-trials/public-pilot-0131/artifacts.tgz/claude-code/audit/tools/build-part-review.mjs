// Builds the per-part review bundle for the NKSkills pilot.
// Reads collected snapshots as inert text only; never executes target content and performs no network access.
// Usage: node build-part-review.mjs CAMPAIGN_DIR INDEX_DIR DISCOVERY_DIR OUT_BUNDLE.json
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";

const [campaignDir, indexDir, discoveryDir, outFile] = process.argv.slice(2);
const PART = "parts/000001";
const partDir = path.join(campaignDir, PART);
const sha = (s) => createHash("sha256").update(s).digest("hex");
const L = (f) => fs.readFileSync(f, "utf8").trim().split("\n").map(JSON.parse);
const inv = L(path.join(partDir, "inventory.jsonl"));
const ev = L(path.join(partDir, "evidence.jsonl"));
const index = JSON.parse(fs.readFileSync(path.join(indexDir, "index.json"), "utf8"));
const graph = L(path.join(discoveryDir, "graph.jsonl"));
const graphHash = sha(fs.readFileSync(path.join(discoveryDir, "graph.jsonl")));
const discovery = JSON.parse(fs.readFileSync(path.join(discoveryDir, "discovery.json"), "utf8"));
const now = new Date().toISOString();
const REVIEWER =
  "Claude (model claude-fable-5-2), host reviewer running the content-search-audit skill; automated agent review, not a human domain expert";
const ORIGIN = "https://nkskills.getgroove.me";
const OWNER_CONTEXT =
  "Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.";
const OWNER_SCOPE =
  "The sole authorized public origin is https://nkskills.getgroove.me. No credentials, authenticated providers or analytics exports are supplied.";

const s8 = (id) => id.slice(0, 8);
const byUri = new Map(inv.map((i) => [i.uri, i]));
const E = (item, kind) => ev.find((e) => e.itemId === item.itemId && e.kind === kind);
const P = inv.map((item) => {
  const content = E(item, "content");
  const http = E(item, "http-response");
  const policy = ev.filter((e) => e.itemId === item.itemId && e.kind === "crawler-policy");
  const html = content.value;
  const finalUrl = http.value.url ?? item.uri;
  const isHtml = /text\/html/.test(http.value.headers["content-type"] ?? "");
  const p = new URL(item.uri).pathname;
  const cls =
    p === "/" ? "home-redirect-alias" : /^\/(en|vi)\/$/.test(p) ? "home" : /catalog/.test(p) ? "catalog" : /solutions/.test(p) ? "solution" : /guides/.test(p) ? "guide" : "license-notice";
  return { item, content, http, policy, html, finalUrl, isHtml, cls, path: p };
});
const pageOf = (uri) => P.find((p) => p.item.uri === uri);

const decode = (s) =>
  s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'").replace(/&nbsp;/g, " ");
function extractText(p) {
  if (!p.isHtml) return p.html;
  let b = p.html.replace(/<script[\s\S]*?<\/script>/gi, "\n").replace(/<style[\s\S]*?<\/style>/gi, "\n");
  b = b.replace(/<\/(p|div|li|section|tr|h[1-6]|header|footer|nav|main|article|ul|ol|table|pre|details|summary|title|textarea|template|button|a)>/gi, "\n").replace(/<br\s*\/?>/gi, "\n");
  b = decode(b.replace(/<[^>]+>/g, " "));
  return b.split("\n").map((s) => s.replace(/[ \t\r]+/g, " ").trim()).filter(Boolean).join("\n") + "\n";
}
const attr = (tag, name) => (new RegExp(`\\s${name}="([^"]*)"`).exec(tag) || [])[1];
function head(p) {
  const h = p.html;
  const title = decode((/<title>([\s\S]*?)<\/title>/i.exec(h) || [])[1] ?? "");
  const meta = (n) => decode((new RegExp(`<meta (?:name|property)="${n}" content="([^"]*)"`).exec(h) || [])[1] ?? "");
  const alternates = {};
  for (const m of h.matchAll(/<link rel="alternate" hreflang="([^"]+)" href="([^"]+)">/g)) alternates[m[1]] = m[2];
  return {
    htmlLang: (/<html lang="([^"]+)"/.exec(h) || [])[1] ?? null,
    title,
    description: meta("description"),
    canonical: (/<link rel="canonical" href="([^"]+)">/.exec(h) || [])[1] ?? null,
    alternates,
    og: { type: meta("og:type"), title: meta("og:title"), description: meta("og:description"), image: meta("og:image"), url: meta("og:url") },
    metaRobots: (h.match(/<meta[^>]+name="(?:robots|googlebot)"[^>]*>/gi) || []),
    h1: (h.match(/<h1[\s\S]*?<\/h1>/gi) || []).map((s) => decode(s.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim()),
    headings: [...h.matchAll(/<(h[2-3])[^>]*>([\s\S]*?)<\/\1>/gi)].map((m) => m[1] + ": " + decode(m[2].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim()),
  };
}
for (const p of P) {
  p.head = p.isHtml ? head(p) : null;
  p.text = extractText(p);
  p.ids = new Set([...p.html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
}

const records = [];
const artifacts = {};
const made = new Map(); // itemId -> {kind: evidenceId}
function add(p, kind, value, { method, locator, sources, limitations }) {
  const json = typeof value !== "string";
  const evidenceId = `rev1-${kind}-${s8(p.item.itemId)}`;
  const bytes = json ? JSON.stringify(value, null, 2) : value;
  const artifact = `evidence/${evidenceId}.${json ? "json" : "txt"}`;
  artifacts[artifact] = bytes;
  records.push({
    evidenceId, itemId: p.item.itemId, kind, value: json ? JSON.parse(bytes) : bytes, method, locator, collectedAt: now,
    snapshotHash: sha(bytes), artifact, encoding: json ? "json" : "utf8", sourceEvidenceIds: [...new Set(sources)],
    redaction: "No credentials or personal data; derived from public snapshot or task statement",
    limitations,
  });
  if (!made.has(p.item.itemId)) made.set(p.item.itemId, {});
  made.get(p.item.itemId)[kind] = evidenceId;
  return evidenceId;
}
const DER = "host-derived inert text analysis of collected snapshot (regex over source text; no DOM parser, no script execution, no network)";
const RAW_LIM = "Raw HTTP source only; rendered DOM, external stylesheets and scripts were not captured or executed";

// ---- cross-page helpers
const edgesFrom = (url) => graph.filter((g) => g.from === url);
const fragmentTargets = (p) => {
  const out = [];
  for (const m of p.html.matchAll(/<a\s[^>]*href="([^"]*#[^"]*)"/g)) {
    const u = new URL(m[1], p.finalUrl);
    const target = P.find((q) => q.finalUrl === u.origin + u.pathname && q.cls !== "home-redirect-alias") ?? null;
    const frag = decodeURIComponent(u.hash.slice(1));
    out.push({ href: m[1], resolved: u.href, fragment: frag, targetCollected: !!target, fragmentIdPresentInTargetSource: target ? target.ids.has(frag) : null });
  }
  const seen = new Set();
  return out.filter((o) => !seen.has(o.href) && seen.add(o.href));
};
const PROBES = {
  "codebase-onboarding 1.1.0": /1\.1\.0/,
  "problem-presentation 0.1.0": /0\.1\.0/,
  "status: technical release (EN 'technical release' / VI 'bản kỹ thuật|phát hành kỹ thuật')": /technical release|bản kỹ thuật|phát hành kỹ thuật/i,
  "status: evaluation candidate (EN 'evaluation candidate' / VI 'ứng viên đánh giá|đang đánh giá|ứng viên')": /evaluation candidate|ứng viên/i,
  "hosts: Codex": /Codex/,
  "hosts: Claude Code": /Claude Code/,
  "no direct-download archive (EN) / chưa có archive tải trực tiếp (VI)": /direct-download archive|direct archive download|archive (phát hành )?tải trực tiếp/i,
  "prerequisite: codegraph": /codegraph/,
  "prerequisite: rtk": /\brtk\b/,
  "three components (EN '3 components|three traceable components' / VI '3 thành phần|ba thành phần')": /3 components|three traceable components|3 thành phần|ba thành phần/i,
  "invocation token $codebase-onboarding-c4": /\$codebase-onboarding-c4/,
  "invocation token /codebase-onboarding-c4": /\/codebase-onboarding-c4/,
  "commercial gate 'remains open' (EN) / 'vẫn mở' (VI)": /gate remains open|vẫn mở/i,
  "commercial gate 'has not passed' (EN) / 'chưa qua cổng' (VI)": /not passed the commercial release gate|chưa qua cổng/i,
  "catalog count '15 Upstream Skills'": /15\s*(<[^>]+>\s*)*Upstream Skills/,
  "catalog count '02 Solution Skills'": /02\s*(<[^>]+>\s*)*Solution Skills/,
  "any explicit calendar date (YYYY-MM-DD or month-year) in visible text": /\b20\d\d-\d\d-\d\d\b|\b(January|February|March|April|May|June|July|August|September|October|November|December) 20\d\d\b|tháng \d{1,2}(,| năm)? 20\d\d/i,
};
const claimMatrix = P.map((p) => ({ uri: p.item.uri, probes: Object.fromEntries(Object.entries(PROBES).map(([k, re]) => [k, re.test(p.isHtml ? p.html.replace(/<script[\s\S]*?<\/script>/gi, "") : p.html)])) }));
const upstreamCards = (p) => [...p.html.matchAll(/href="(https:\/\/github\.com\/[^"]+\/tree\/[0-9a-f]{40}[^"]*)"/g)].map((m) => m[1]);
const lineDiff = (a, b) => {
  const A = a.text.split("\n"), B = new Set(b.text.split("\n"));
  return { linesInA: A.length, linesOfANotInB: A.filter((l) => !B.has(l)).length };
};
const dupGroups = Object.values(P.reduce((acc, p) => ((acc[p.content.snapshotHash] ??= []).push(p.item.uri), acc), {})).filter((g) => g.length > 1);
const inventoryMap = {
  description: "Portfolio map of the declared inventory (12 items) derived from collected snapshots. Page class is a reviewer classification inferred from URL path and content; it is not publisher metadata.",
  generatedAt: now,
  scopeNote: "Inventory is the static-link discovery union only (scopeComplete=false). CMS records, orphan pages, sitemap.xml membership and rendered navigation are not represented.",
  items: P.map((p) => ({
    itemId: p.item.itemId, uri: p.item.uri, finalUrl: p.finalUrl, reviewerClass: p.cls, contentType: p.http.value.headers["content-type"],
    htmlLang: p.head?.htmlLang ?? null, title: p.head?.title ?? null, h1: p.head?.h1 ?? [], canonical: p.head?.canonical ?? null,
    declaredAlternates: p.head?.alternates ?? {}, contentSha256: p.content.snapshotHash, contentBytes: Buffer.byteLength(p.html),
  })),
  identicalContentGroups: dupGroups,
  localePairs: P.filter((p) => p.head?.htmlLang === "en" && p.cls !== "home-redirect-alias").map((p) => ({ en: p.item.uri, vi: p.head.alternates.vi, viCollected: !!byUri.get(p.head.alternates.vi) })),
  hostGuideComparison: ["en", "vi"].map((l) => {
    const a = pageOf(`${ORIGIN}/${l}/guides/codex/`), b = pageOf(`${ORIGIN}/${l}/guides/claude-code/`);
    return { locale: l, codexVsClaudeCode: lineDiff(a, b), claudeCodeVsCodex: lineDiff(b, a) };
  }),
  pinnedUpstreamLinkSets: {
    enCatalogCount: upstreamCards(pageOf(`${ORIGIN}/en/catalog/`)).length,
    viCatalogCount: upstreamCards(pageOf(`${ORIGIN}/vi/catalog/`)).length,
    enViCatalogIdentical: JSON.stringify(upstreamCards(pageOf(`${ORIGIN}/en/catalog/`))) === JSON.stringify(upstreamCards(pageOf(`${ORIGIN}/vi/catalog/`))),
    enHomeCount: upstreamCards(pageOf(`${ORIGIN}/en/`)).length,
    viHomeCount: upstreamCards(pageOf(`${ORIGIN}/vi/`)).length,
    enViHomeIdentical: JSON.stringify(upstreamCards(pageOf(`${ORIGIN}/en/`))) === JSON.stringify(upstreamCards(pageOf(`${ORIGIN}/vi/`))),
    homeSecurityLinksSubsetOfCatalog: upstreamCards(pageOf(`${ORIGIN}/en/`)).every((u) => upstreamCards(pageOf(`${ORIGIN}/en/catalog/`)).includes(u)),
  },
  claimProbeMatrix: claimMatrix,
  probeNote: "Probes are literal/regex string presence tests over snapshot source with script elements removed. Presence is not verification of truth against release records (GitHub is an excluded origin).",
};
const allContentIds = P.map((p) => p.content.evidenceId);

// ---- per-item evidence
for (const p of P) {
  const own = p.content.evidenceId;
  add(p, "extracted-text", p.text, {
    method: p.isHtml ? "host regex tag-strip extraction of the collected content evidence (script/style removed, basic entities decoded; inert template and textarea text retained)" : "identity copy of collected text/plain content evidence",
    locator: `${PART}/${p.content.artifact} (snapshot ${p.content.snapshotHash})`,
    sources: [own],
    limitations: ["Not a DOM parser or rendered-text capture; reading order and hidden/visible state are not established", "Nonempty extraction does not establish quality or completeness"],
  });
  add(p, "audience-context", `Owner-supplied audit context, preserved verbatim from the user's task statement for this audit (captured ${now}):\n\n"${OWNER_CONTEXT}"\n\n"${OWNER_SCOPE}"\n\nBound item: ${p.item.uri}\nReviewer note (interpretation, not owner statement): the statement establishes product positioning (versioned skill workflows), the two supported hosts (Codex, Claude Code) and the two audience languages (English, Vietnamese). It does not supply per-page user tasks, customer questions, search queries, indexing intent or crawler policy intent; page tasks used in reviews are inferred from the page itself and labelled as inferred.\n`, {
    method: "user/task statement preserved by host", locator: "user task statement for this audit session (business context paragraph)", sources: [],
    limitations: ["Owner-supplied context; not independently verified", "No per-page task, question set, query data or publisher indexing/crawler intent is included"],
  });
  add(p, "entity-record", `Owner-supplied entity statement, preserved verbatim from the user's task statement (captured ${now}):\n\n"${OWNER_CONTEXT}"\n\nBound item: ${p.item.uri}\nReviewer note: this record covers brand name (NKSkills), offering (versioned skill workflows), supported hosts (Codex and Claude Code) and audience languages (English, Vietnamese) only. It contains no versions, release status, prices, component lists or limitations; the publisher's release records live on github.com, which is outside the authorized origin and was not collected.\n`, {
    method: "user/task statement preserved by host", locator: "user task statement for this audit session (business context paragraph)", sources: [],
    limitations: ["Owner-supplied statement; not an independently verified registry or release record", "Does not cover versions, status, licenses or limitations"],
  });
  add(p, "inventory-map", { boundItem: p.item.uri, ...inventoryMap }, {
    method: DER, locator: `${PART} content evidence of all 12 declared items`, sources: allContentIds,
    limitations: [RAW_LIM, "Covers only the declared static-link inventory; discovery scope is incomplete", "Reviewer classification and string probes are not publisher metadata or fact verification"],
  });
  add(p, "media-inventory", p.isHtml ? {
    imgElements: (p.html.match(/<img[^>]*>/gi) || []).map((t) => ({ src: attr(t, "src"), alt: attr(t, "alt") ?? null, insideBrandLinkWithAriaLabel: /<a class="brand"[^>]*aria-label="[^"]+"[^>]*><img/.test(p.html) })),
    svgElements: (p.html.match(/<svg/gi) || []).length,
    videoAudioCanvasPictureObjectEmbedIframe: (p.html.match(/<(video|audio|canvas|picture|object|embed|iframe)[\s>]/gi) || []).length,
    figureElements: (p.html.match(/<figure/gi) || []).length,
    roleImgElements: [...p.html.matchAll(/<[a-z]+[^>]*role="img"[^>]*>/g)].map((t) => ({ ariaLabel: attr(t[0], "aria-label") ?? null, ariaDescribedby: attr(t[0], "aria-describedby") ?? null })),
    ariaHiddenTrueCount: (p.html.match(/aria-hidden="true"/g) || []).length,
    ariaHiddenBlockContainers: [...p.html.matchAll(/<div class="([^"]*)" aria-hidden="true"/g)].map((m) => m[1]),
    ariaDescribedbyOrLabelledbyRefs: [...p.html.matchAll(/aria-(describedby|labelledby)="([^"]+)"/g)].map((m) => ({ attr: m[1], id: m[2], idPresent: m[2].split(/\s+/).every((i) => p.ids.has(i)) })),
    workflowDescriptionText: (/id="workflow-description"[^>]*>([\s\S]*?)<\//.exec(p.html) || [])[1] ?? null,
    ogImage: p.head.og.image,
    ogImageFetched: false,
  } : { contentType: p.http.value.headers["content-type"], mediaElements: 0, note: "text/plain representation; no media elements can be embedded" }, {
    method: DER, locator: `${PART}/${p.content.artifact}`, sources: [own, p.http.evidenceId],
    limitations: [RAW_LIM, "CSS background imagery and the og:image file were not collected; their content and alternatives are unknown"],
  });
  add(p, "schema-extraction", p.isHtml ? {
    jsonLdScriptBlocks: (p.html.match(/application\/ld\+json/g) || []).length,
    microdataItemscopeAttributes: (p.html.match(/\sitemscope/g) || []).length,
    rdfaTypeofOrVocabAttributes: (p.html.match(/\s(typeof|vocab)=/g) || []).length,
    openGraph: p.head.og,
    twitterCardMetaCount: (p.html.match(/name="twitter:[^"]+"/g) || []).length,
    scriptElements: (p.html.match(/<script[^>]*>/gi) || []).map((t) => attr(t, "src") ?? "(inline)"),
  } : { contentType: p.http.value.headers["content-type"], structuredDataBlocks: 0, note: "text/plain representation" }, {
    method: DER, locator: `${PART}/${p.content.artifact}`, sources: [own],
    limitations: [RAW_LIM, "Absence in raw source does not establish absence in a rendered DOM", "No vocabulary or search-feature eligibility validation was performed"],
  });
  if (p.isHtml) {
    add(p, "canonical-targets", {
      requestedUrl: p.item.uri, redirects: p.http.value.redirects ?? [], finalUrl: p.finalUrl, finalStatus: p.http.value.status,
      declaredCanonical: p.head.canonical, ogUrl: p.head.og.url,
      canonicalEqualsFinalUrl: p.head.canonical === p.finalUrl, ogUrlEqualsCanonical: p.head.og.url === p.head.canonical,
      canonicalTargetCollected: !!P.find((q) => q.item.uri === p.head.canonical), canonicalTargetStatus: P.find((q) => q.item.uri === p.head.canonical)?.http.value.status ?? null,
      canonicalLinkElementsInSource: (p.html.match(/<link rel="canonical"/g) || []).length,
      retainedResponseHeaders: p.http.value.headers,
    }, {
      method: DER, locator: `${PART}/${p.content.artifact} and ${PART}/${p.http.artifact}`,
      sources: [own, p.http.evidenceId, ...(P.find((q) => q.item.uri === p.head.canonical && q !== p) ? [P.find((q) => q.item.uri === p.head.canonical).http.evidenceId] : [])],
      limitations: [RAW_LIM, "A declared canonical is not evidence of an engine-selected canonical", "HTTP Link headers are not among the retained response headers; header-level canonicals are unobserved"],
    });
    const lang = p.head.htmlLang, other = lang === "en" ? "vi" : "en";
    const cp = P.find((q) => q.item.uri === p.head.alternates[other]);
    add(p, "locale-map", {
      servedUrl: p.finalUrl, htmlLang: lang, declaredAlternates: p.head.alternates,
      selfReferencePresent: p.head.alternates[lang] === p.finalUrl,
      counterpart: cp ? { uri: cp.item.uri, itemId: cp.item.itemId, htmlLang: cp.head.htmlLang, status: cp.http.value.status, declaredAlternates: cp.head.alternates, canonical: cp.head.canonical } : null,
      reciprocalAlternatesIdentical: cp ? JSON.stringify(cp.head.alternates) === JSON.stringify(p.head.alternates) : null,
      counterpartCanonicalIsSelf: cp ? cp.head.canonical === cp.item.uri : null,
      xDefault: p.head.alternates["x-default"] ?? null,
      languageSwitchLinks: [...p.html.matchAll(/<a[^>]*href="([^"]+)"[^>]*lang="(en|vi)"[^>]*>([^<]*)</g)].map((m) => ({ href: m[1], lang: m[2], text: m[3] })),
      vietnameseDiacriticCharCount: (p.text.match(/[ăâđêôơưàáảãạằắẳẵặầấẩẫậèéẻẽẹềếểễệìíỉĩịòóỏõọồốổỗộờớởỡợùúủũụừứửữựỳýỷỹỵ]/gi) || []).length,
      residualEnglishUiStrings: lang === "vi" ? ["NKSkills home", "NKSkills original", "Pinned public upstream", "Switch to English"].filter((s) => p.html.includes(s)) : [],
    }, {
      method: DER, locator: `${PART}/${p.content.artifact}` + (cp ? ` and ${PART}/${cp.content.artifact}` : ""), sources: [own, ...(cp ? [cp.content.evidenceId, cp.http.evidenceId] : [])],
      limitations: [RAW_LIM, "Annotation reciprocity is not evidence of engine-selected language results or indexing", "sitemap.xml hreflang annotations, if any, were not collected"],
    });
  }
  const out = edgesFrom(p.finalUrl);
  const inbound = [...new Set(graph.filter((g) => g.to === p.item.uri && g.from !== p.finalUrl).map((g) => g.from))];
  const inScopeTargets = [...new Set(out.filter((g) => g.inScope).map((g) => g.to))];
  const srcPages = inbound.map((u) => pageOf(u)).filter(Boolean);
  const tgtPages = inScopeTargets.map((u) => pageOf(u)).filter(Boolean);
  add(p, "link-graph", {
    item: p.item.uri, servedUrl: p.finalUrl,
    graphSource: { file: "audit/discovery-continued/graph.jsonl", sha256: graphHash, discoveryId: discovery.discoveryId, parentDiscoveryId: discovery.recovery?.parentDiscoveryId, edgesTotal: graph.length },
    graphSnapshotMatchesCampaignContent: out.length ? out.every((g) => g.snapshotHash === p.content.snapshotHash) : null,
    outboundEdgeCount: out.length,
    inScopeTargets: inScopeTargets.map((u) => ({ uri: u, edgeCount: out.filter((g) => g.to === u).length, collectedStatus: pageOf(u)?.http.value.status ?? null, redirectsTo: pageOf(u) && pageOf(u).finalUrl !== u ? pageOf(u).finalUrl : null })),
    externalTargetsExcludedUnchecked: [...new Set(out.filter((g) => !g.inScope).map((g) => g.to))],
    inboundFromCollectedPages: inbound,
    relValuesObserved: [...new Set(out.flatMap((g) => g.rel))],
    fragmentLinks: p.isHtml ? fragmentTargets(p) : [],
    idAttributesWithNoInboundFragmentLinkInInventory: p.isHtml ? [...p.ids].filter((id) => !P.some((q) => q.isHtml && fragmentTargets(q).some((f) => f.fragment === id && f.resolved.split("#")[0] === p.finalUrl))) : [],
    plainTextFileReferencesNotHyperlinks: p.isHtml ? [] : (p.html.match(/[\w-]+-OFL\.txt/g) || []),
    note: p.cls === "home-redirect-alias" ? "Requested URL redirects (308) to /en/; edges are those of the served /en/ document. The seed has no inbound static links in the collected graph." : undefined,
  }, {
    method: "host-derived from the packaged discover-links/discovery-resume graph plus inert fragment-id matching over collected snapshots",
    locator: `audit/discovery-continued/graph.jsonl (sha256 ${graphHash}) joined to ${PART} content evidence`,
    sources: [own, p.http.evidenceId, ...srcPages.map((q) => q.content.evidenceId), ...tgtPages.map((q) => q.http.evidenceId), ...tgtPages.filter((q) => q.isHtml).map((q) => q.content.evidenceId)],
    limitations: ["Static a/area href graph only; script-generated or rendered navigation is unreviewed (rendering-unreviewed queue)", "External (github.com) targets are excluded from scope and their availability was not checked", "Incomplete discovery cannot prove any page is orphaned or that no other inbound links exist"],
  });
}

// ---- reviews
const reviews = [];
const m = (p) => made.get(p.item.itemId);
const R = (p, ruleId, status, reason, kinds) => reviews.push({
  itemId: p.item.itemId, ruleId, status, reason, reviewer: REVIEWER, reviewedAt: now,
  evidenceIds: [...new Set(kinds.map((k) => (k === "content" ? p.content.evidenceId : k === "http-response" ? p.http.evidenceId : k === "crawler-policy" ? p.policy[0].evidenceId : m(p)[k])))],
});
const robotsBody = P[0].policy[0].value.capture.body.trim().replace(/\n/g, " | ");
for (const p of P) {
  const html = p.isHtml, h = p.head, alias = p.cls === "home-redirect-alias";
  const aliasNote = alias ? " Requested URL / answers 308 to /en/ and this snapshot is byte-identical to the /en/ item; the judgment is that of the served /en/ document." : "";
  // quality
  if (p.cls === "guide") {
    R(p, "quality-task-fit", "fail", `Inferred task (from title "${h.title}" and H1): install the Solution Skill from source and invoke it in the named host. Build, digest, install and invocation steps are present and ordered. Defect: the "Check prerequisites before running" section lists codegraph, rtk and a valid CodeGraph index as requirements, but the captured page contains no definition of these tools, no install/index-creation instruction and no link labelled for obtaining them; the only link to the external technical guide in the build section is labelled for archive and digest verification. A reader who lacks the tools cannot complete the stated task from this page. Clean components: build commands, install command with --target, post-install checks and invocation token are present. See finding F-002. Whether the external technical guide covers tool setup is unverified (github.com is outside the authorized origin).`, ["content", "audience-context"]);
    R(p, "aio-retrievable-facts", "fail", `Readable static source contains product name, host, version numbers, commands, install target and invocation token with their context. Missing concrete fact needed by the stated audience: what codegraph and rtk are and where/how to obtain them and create the index the page declares mandatory (see finding F-002). Readability of facts is not evidence of retrieval or citation by any engine.`, ["content", "audience-context"]);
  } else if (html) {
    const task = p.cls === "catalog" ? "see which Solution Skills and pinned upstream skills exist, with source, revision, licence and status" : p.cls === "solution" ? "evaluate the codebase-onboarding Solution Skill: what it produces, its components, prerequisites and current limits, then proceed to a host guide" : "understand what NKSkills offers, the status of its two Solution Skills, and how to start (install guides, starter prompt)";
    R(p, "quality-task-fit", "pass", `Inferred task (reviewer inference from title "${h.title}" and page content; owner context gives audience only): ${task}. The captured source provides that information with status qualifiers and next-step links to the related pages.${p.cls === "home" && h.htmlLang === "vi" ? " Caveat: one FAQ answer uses wording that can be misread (finding F-003); it does not remove information needed for the task." : ""}${p.cls !== "catalog" ? " Caveat: prerequisite tools codegraph/rtk are named without definition here; the actionable gap is recorded against the guide pages (F-002)." : ""} Truth of the claims is not assessed by this rule.${aliasNote}`, ["content", "audience-context"]);
    R(p, "aio-retrievable-facts", "pass", `Entity and product facts needed by the owner-described audience are present as plain text in the static source: brand NKSkills, hosts Codex and Claude Code, versions/status of the Solution Skills on this page, and limits/qualifiers adjacent to the claims.${p.cls === "home" || alias ? " The four starter-prompt variants exist in inert template elements and the default prompt is in a readonly textarea in source." : ""} No release or last-updated date accompanies the status statements (finding F-004, tracked under quality-freshness). Readable facts do not prove retrieval or citation by any engine.${aliasNote}`, ["content", "audience-context"]);
  } else {
    R(p, "quality-task-fit", "unknown", "Plain-text font licence notice. It names three typefaces, their authors and SIL OFL 1.1 and refers to three full-notice files by filename (not hyperlinks). Those files are not in the static-link inventory and were not collected, so whether the notice task is fully served is unresolved. The owner context does not describe an audience task for this file.", ["content", "audience-context"]);
    R(p, "aio-retrievable-facts", "pass", "The item's own facts (typeface names, attributed authors, licence name and version, full-notice filenames) are present as readable UTF-8 plain text in the captured body. The referenced full notices are separate uncollected resources and are not assessed here. Readable facts do not prove retrieval or citation.", ["content", "audience-context"]);
  }
  R(p, "quality-claims", "unknown", `No claim-sources evidence is available: the publisher's release record, manifests and catalog.yaml are linked on github.com, which is outside the sole authorized origin and was not collected. Material claims on this item (${html ? "versions, release status, verification statements, component/licence listings, commands" : "font authorship and licence"}) are therefore unverified, not false. Cross-page consistency of these claims is assessed under portfolio-contradictions.`, ["content"]);
  R(p, "quality-freshness", "unknown", `No dated authoritative source was supplied to check version/date applicability. Observation from the snapshot: ${html ? "the page source contains no calendar date for its status statements; the only year-like string is the version of the third-party analytics beacon script (finding F-004)" : "the file carries no date or version"}. HTTP Last-Modified is not among retained headers.`, ["content"]);
  if (html) R(p, "quality-accessible-media", "pass", `Media in captured source: one img (brand mark, alt="" inside a link that carries aria-label and visible brand text), no svg/video/audio/iframe elements.${p.cls === "home" || alias ? " Illustrative panels are text-built and marked aria-hidden; the one figure is a text-built workflow diagram with role=img, an aria-label and aria-describedby pointing to a text description paragraph (id workflow-description) present in source." : ""} No informative media lacking a text alternative was found in the HTML source. Not covered: CSS background imagery and the og:image file (not collected).${aliasNote}`, ["content", "media-inventory"]);
  else R(p, "quality-accessible-media", "not-applicable", "The captured representation is text/plain (377 bytes) and cannot embed images, audio, video or other media; the rule is irrelevant to the whole item.", ["content", "media-inventory", "http-response"]);
  // seo
  R(p, "seo-index-controls", "unknown", `Publisher indexing/snippet intent was not supplied, so directives cannot be compared with intent. Observations: ${html ? "no meta robots/googlebot element in raw source; " : ""}no X-Robots-Tag among retained response headers (retained set is selective, so header absence is not established); robots.txt allows the fetched path. HTTP success and crawl permission are not index evidence; rendered directives unobserved.`, ["content", "http-response"]);
  if (html) {
    R(p, "seo-canonical", "pass", `Raw source declares exactly one canonical, ${h.canonical}, equal to the served final URL${alias ? " (/ redirects 308 to /en/, which self-canonicalises)" : ""} and to og:url; the canonical target was collected with HTTP 200. Locale variants keep their own self-canonicals (no cross-locale canonical conflict). Intended variants are taken from the page's own hreflang set; no separate publisher intent was supplied. Not evidence of engine-selected canonical; Link headers and rendered DOM unobserved.`, ["content", "canonical-targets"]);
    const typo = p.item.uri.endsWith("/vi/catalog/");
    R(p, "seo-metadata", "pass", `Title "${h.title}", meta description and H1 "${h.h1.join(" / ")}" describe the page's actual content and match og:title/og:description. Title and description are unique within the inventory${alias ? " apart from the /en/ document this URL redirects to" : p.cls === "home" && h.htmlLang === "en" ? " apart from the / redirect alias" : ""}; H2/H3 headings match their sections.${typo ? " Minor defect outside title/description/headings: the eyebrow label above the H1 reads \"NKSKILLS / DANH MỤ\" (truncated; see finding F-001). It is not treated as a material metadata failure." : ""} No character-count or keyword rule applied.${aliasNote}`, ["content", "audience-context"]);
    R(p, "seo-internal-links", "pass", `In the packaged static-link graph this document has ${[...new Set(edgesFrom(p.finalUrl).filter((g) => g.inScope).map((g) => g.to))].length} distinct in-scope targets, all collected with a final HTTP 200${alias ? "" : `, and inbound links from ${[...new Set(graph.filter((g) => g.to === p.item.uri && g.from !== p.finalUrl).map((g) => g.from))].length} other collected pages`}. Every fragment link resolves to an id present in the collected target source. No verified broken internal target. External github.com targets are excluded and unchecked; orphan status cannot be assessed with incomplete discovery; rendered navigation unreviewed.${aliasNote}`, ["content", "link-graph"]);
    R(p, "seo-structured-data", "unknown", "No JSON-LD, microdata or RDFa is present in the raw source (Open Graph meta only), so there is nothing to compare with visible claims. Absence in raw source does not establish absence in the rendered DOM, which was not captured; no feature-eligibility requirement is asserted. Structured data is not prescribed as mandatory.", ["content", "schema-extraction"]);
    R(p, "seo-locales", "pass", `html lang="${h.htmlLang}" matches the language of the served text; hreflang en/vi/x-default are declared with a self-reference; the ${h.htmlLang === "en" ? "vi" : "en"} counterpart was collected (HTTP 200), declares the identical alternate set and self-canonicalises; x-default points to the English variant. Visible language-switch links target the same counterpart.${h.htmlLang === "vi" ? " Caveat (not a failure): a few UI strings remain English in the Vietnamese source (see locale-map residualEnglishUiStrings)." : ""} Annotation consistency only; engine language selection, indexing and any sitemap annotations are unobserved.${aliasNote}`, ["content", "locale-map"]);
    R(p, "seo-rendering", "unknown", `No rendered DOM was captured (browser and script execution are outside the authorized scope). Source loads ${(p.html.match(/<script[^>]*src=/g) || []).length} external script(s)${p.cls === "home" || alias ? " including /scripts/prompt-picker.js, which presumably swaps the starter-prompt text from inert template elements" : " (third-party analytics beacon only)"}; main content is present in raw HTML, but source/rendered equivalence is unverified.`, ["content"]);
    R(p, "portfolio-journey-links", "pass", `${p.cls === "guide" ? "Guide links back to the starter prompt (home #try-it), the install section breadcrumb, catalog and its locale counterpart" : p.cls === "solution" ? "Solution page links forward to both host guides, back to home/catalog and to its locale counterpart" : p.cls === "catalog" ? "Catalog links to the solution detail page, in-page sections, home try-it and its locale counterpart" : "Home links to the solution page, both host guides, the catalog (including #solutions and #security-upstreams) and its locale counterpart"}; all in-scope targets and fragments resolve in the collected graph. The next step for the owner-described audience (choose host, install, invoke) is reachable by static links.${p.cls === "guide" ? " Optional: the guide's #presentation section has no inbound fragment link from the candidate cards on home/catalog." : ""} Navigation quality is not ranking evidence; rendered navigation unreviewed.${aliasNote}`, ["content", "link-graph", "audience-context"]);
  } else {
    R(p, "seo-canonical", "unknown", "text/plain resource with no in-body canonical mechanism. HTTP Link headers are not among the retained response headers, so a header-level canonical and the intended variant relationship are unobserved. Media type alone does not justify not-applicable.", ["content", "http-response"]);
    R(p, "seo-metadata", "not-applicable", "The captured representation is text/plain; HTML title, meta description and heading elements cannot exist in it. Its first line (\"NKSkills site font notices\") describes the content. The rule's title/description/heading review is irrelevant to the whole item.", ["content", "audience-context", "http-response"]);
    R(p, "seo-internal-links", "unknown", "The file is linked from the footer of the 10 collected HTML documents and returned HTTP 200. It names three full-notice files (fraunces-OFL.txt, source-sans-3-OFL.txt, ibm-plex-mono-OFL.txt) as plain text; these are not hyperlinks, are not in the static-link inventory and were not requested, so their availability is unverified.", ["content", "link-graph"]);
    R(p, "seo-structured-data", "not-applicable", "The captured representation is text/plain; it cannot carry JSON-LD, microdata or RDFa, so structured-data comparison is irrelevant to the whole item.", ["content", "schema-extraction", "http-response"]);
    R(p, "seo-locales", "unknown", "Single English plain-text notice linked from both English and Vietnamese footers. No locale annotation can be observed in the body and Link headers are not retained; whether a Vietnamese variant is intended is not established by supplied evidence.", ["content"]);
    R(p, "seo-rendering", "not-applicable", "The captured representation is text/plain with no markup or scripts; client-side rendering cannot alter its content, so source/rendered comparison is irrelevant to the whole item.", ["content", "http-response"]);
    R(p, "portfolio-journey-links", "unknown", "Terminal plain-text notice reached from page footers; it has no hyperlinks, and the three notice files it names were not collected. Whether readers can reach the full notices is unresolved.", ["content", "link-graph", "audience-context"]);
  }
  // aio
  R(p, "aio-crawler-policy", "unknown", `Publisher intent for search discovery, AI training crawlers and user-triggered retrieval was not supplied, so the control cannot be evaluated against intent. Observation: captured robots.txt (HTTP 200) is "${robotsBody}" with no agent-specific groups; the audit agent's fetch of this path was allowed. This is not a recommendation to allow or block any crawler and is not evidence of retrieval or citation.`, ["crawler-policy"]);
  R(p, "aio-entity-consistency", "unknown", `Only the owner's one-sentence entity statement is available as a record. ${html ? "Brand name NKSkills and hosts Codex/Claude Code on this page agree with it (the header wordmark is split markup 'NK' + 'Skills' under aria-label 'NKSkills home'). " : "The brand name NKSkills agrees with it. "}Versions, release status, component lists, licences and limitations have no authoritative record in scope (release records are on excluded github.com), so the full comparison is unresolved. Cross-page agreement is assessed under portfolio-contradictions.`, ["content", "entity-record"]);
  // aeo / geo
  const faq = p.cls === "home" || alias;
  R(p, "aeo-question-coverage", "unknown", `No question set (search, support, sales or customer questions) was supplied; hypothetical questions were not invented.${faq ? " The page's own four FAQ questions are publisher-authored copy, not evidence of real user questions." : ""}`, ["content"]);
  R(p, "aeo-answer-context", "unknown", `No supplied question set to map answers against.${faq && h.htmlLang === "vi" ? " Narrow observation recorded as finding F-003: the Vietnamese FAQ answer about commercial readiness uses \"cổng phát hành thương mại vẫn mở\" while the same page's solution card says \"Chưa qua cổng phát hành thương mại\"." : faq ? " Observation: the four on-page FAQ answers carry their conditions (e.g. the prompt stops before installing tools if prerequisites are missing)." : ""}`, ["content"]);
  R(p, "aeo-answer-evidence", "unknown", "No claim-sources evidence in scope (release records and manifests are on excluded github.com); source support for answer claims is unverified.", ["content"]);
  for (const r of ["geo-observed-presence", "geo-answer-accuracy", "geo-cohort-validity"])
    R(p, r, "unknown", "No AI response observations, prompts or cohorts were supplied or collected. Mentions, citations, answer accuracy and visibility are unmeasured; readiness observations are not a substitute. No Google AI Overviews or other surface measurement exists for this run.", []);
  // portfolio (local)
  R(p, "portfolio-task-gaps", "unknown", "No question set or demand evidence was supplied, so audience tasks cannot be mapped to the inventory beyond the publisher's own structure. No gaps are asserted.", ["content", "inventory-map"]);
  R(p, "portfolio-duplication", "pass", alias ? "Byte-identical to the /en/ item because / answers with a 308 redirect to /en/, which self-canonicalises and is the hreflang x-default; this is a redirect alias, not competing duplicate content." : p.cls === "guide" ? `Overlaps heavily with the sibling host guide in the same locale (see inventory-map hostGuideComparison), differing in host name, --target value and invocation token ($ vs /). These are distinct host variants serving different install tasks, plus a legitimate ${h.htmlLang === "en" ? "Vietnamese" : "English"} locale variant. No consolidation proposed; cannibalization would need query/page data, which is absent.` : html ? `The only overlapping item is its ${h.htmlLang === "en" ? "Vietnamese" : "English"} counterpart, a declared hreflang locale variant${p.cls === "home" && h.htmlLang === "en" ? ", plus the / redirect alias" : ""}. Home, catalog and solution pages repeat short status summaries but serve different tasks. No illegitimate duplication observed; cannibalization would need query/page data, which is absent.` : "No other inventory item covers font licence notices.", ["content", "inventory-map"]);
  R(p, "portfolio-contradictions", "pass", html ? `Material claims on this item were compared with every other collected item (inventory-map claimProbeMatrix plus full reading): Solution Skill versions (1.1.0, 0.1.0) and statuses, supported hosts, three-component composition, prerequisites (codegraph, rtk, CodeGraph index), no direct-download archive, invocation tokens per host, catalog counts and pinned upstream revisions agree across pages and between English and Vietnamese variants. They also agree with the owner entity statement where it applies (name, hosts, languages). No conflicting material claim found.${p.cls === "home" && h.htmlLang === "vi" ? " Wording variance on the same fact within this page is recorded as F-003 (clarity, not a factual conflict)." : ""} This is consistency among captured pages, not verification against release records.${aliasNote}` : "The notice's font/licence statements do not appear on, or conflict with, any other collected item; the brand name matches the owner statement. Consistency only; licences not verified against the upstream font projects.", ["content", "entity-record", "inventory-map"]);
}

// ---- findings
const id = (suffix) => pageOf(ORIGIN + suffix).item.itemId;
const c = (suffix) => pageOf(ORIGIN + suffix).content.evidenceId;
const guides = ["/en/guides/codex/", "/en/guides/claude-code/", "/vi/guides/codex/", "/vi/guides/claude-code/"];
const htmlPages = ["/en/", "/vi/", "/en/catalog/", "/vi/catalog/", "/en/solutions/codebase-onboarding/", "/vi/solutions/codebase-onboarding/", ...guides];
const findings = [
  {
    findingId: "F-001", title: "Vietnamese catalog eyebrow label is truncated (\"DANH MỤ\")",
    affectedItemIds: [id("/vi/catalog/")], ruleIds: ["seo-metadata"], dimensions: ["seo"],
    evidenceIds: [c("/vi/catalog/"), c("/en/catalog/"), c("/vi/")], classification: "observed", severity: "low", confidence: "high",
    observation: "The eyebrow paragraph directly above the H1 on /vi/catalog/ reads \"NKSKILLS / DANH MỤ\" in raw source. The English counterpart reads \"NKSKILLS / CATALOG\" and the Vietnamese home page spells the section label \"DANH MỤC\".",
    remediation: "Correct the eyebrow text on /vi/catalog/ to \"NKSKILLS / DANH MỤC\" in the site source. This is a proposal; no site change was made by the audit.",
    verification: "Re-collect https://nkskills.getgroove.me/vi/catalog/ and confirm the eyebrow paragraph contains \"DANH MỤC\".",
    ownerRole: "Content owner (Vietnamese localization)", effort: "small",
    action: "update", actionReason: "Observed spelling truncation in a visible label; the correct spelling is already used on the Vietnamese home page.",
  },
  {
    findingId: "F-002", title: "Host guides list codegraph, rtk and a CodeGraph index as prerequisites without saying what they are or how to obtain them",
    affectedItemIds: guides.map(id), ruleIds: ["quality-task-fit", "aio-retrievable-facts"], dimensions: ["quality", "aio"],
    evidenceIds: [...guides.map(c), c("/en/solutions/codebase-onboarding/"), c("/vi/solutions/codebase-onboarding/")], classification: "observed", severity: "medium", confidence: "medium",
    observation: "On all four host guides (EN/VI x Codex/Claude Code) the prerequisites section names \"codegraph, rtk\" and a valid CodeGraph index, and the run section tells the reader to run codegraph --version, rtk --version and codegraph status. None of the 12 collected items defines these tools, links to them, or explains index creation. On the guides, the nearest link to the external technical guide is labelled for archive and digest verification; only the solution pages label that same external document as the full technical setup. Whether the external guide covers tool setup is unverified (excluded origin).",
    remediation: "In the prerequisites section of each guide, add one sentence per tool stating what it is and where to get it, and either the index-creation step or a clearly labelled link to the setup section of the technical guide. Keep EN and VI in step.",
    verification: "Re-collect the four guide URLs and confirm the prerequisites section contains a definition or source for codegraph and rtk and an index-creation instruction or a link whose text names tool setup. Separately confirm the linked document covers these steps (requires authorization to read the GitHub document).",
    ownerRole: "Documentation owner", effort: "small",
    action: "update", actionReason: "The pages themselves declare the tools mandatory; the gap is observable in the captured page text. Impact on real users is inferred, not measured.",
  },
  {
    findingId: "F-003", title: "Vietnamese FAQ answer on commercial readiness uses wording that can be read the opposite way",
    affectedItemIds: [id("/vi/")], ruleIds: ["aeo-answer-context"], dimensions: ["aeo"],
    evidenceIds: [c("/vi/"), c("/en/"), c("/vi/guides/codex/")], classification: "inferred", severity: "low", confidence: "medium",
    observation: "The /vi/ FAQ answers \"Problem presentation đã sẵn sàng thương mại chưa?\" with \"Chưa. Bản 0.1.0 là ứng viên đánh giá; cổng phát hành thương mại vẫn mở.\" The same page's solution card and the Vietnamese guides state the same fact as \"Chưa qua cổng phát hành thương mại\" / \"chưa qua cổng phát hành thương mại\". \"Cổng ... vẫn mở\" is a literal rendering of the English \"gate remains open\"; read without the leading \"Chưa\", it can suggest that commercial release is open. Reader misinterpretation is an inference, not an observed outcome.",
    remediation: "Align the FAQ answer with the phrasing already used elsewhere in Vietnamese, e.g. \"Chưa. Bản 0.1.0 là ứng viên đánh giá và chưa qua cổng phát hành thương mại.\" Optionally apply the same \"has not passed\" phrasing to the English \"gate remains open\" statements for consistency with the English guides.",
    verification: "Re-collect https://nkskills.getgroove.me/vi/ and confirm the FAQ answer no longer contains \"vẫn mở\" and matches the solution-card wording; have a Vietnamese-speaking reviewer confirm the reading.",
    ownerRole: "Content owner (Vietnamese localization)", effort: "small",
    action: "update", actionReason: "Wording alignment to phrasing the publisher already uses on the same page; low risk. Needs native-speaker confirmation.",
  },
  {
    findingId: "F-004", title: "Release-status and verification statements carry versions but no date",
    affectedItemIds: htmlPages.map(id), ruleIds: ["quality-freshness"], dimensions: ["quality"],
    evidenceIds: htmlPages.map(c), classification: "inferred", severity: "low", confidence: "medium",
    observation: "The 10 HTML documents make time-sensitive statements (for example that a direct-download archive is not published yet, that statuses reflect current evidence, that the commercial release gate is unresolved) tied to versions 1.1.0 and 0.1.0. No calendar date appears in the source of any collected page; the only year-like string is the third-party analytics beacon version. A reader or retrieval system cannot tell from the page when these statements were true. Whether any statement is actually stale is unknown: release records are on an excluded origin.",
    remediation: "Add a visible release date for each versioned Solution Skill and/or a last-reviewed date near status statements, sourced from the release record. Do not add dates that the release record does not support.",
    verification: "Re-collect the pages and confirm each status block shows a date; compare that date with the publisher's release record (requires authorization to read the GitHub release document).",
    ownerRole: "Content owner", effort: "small",
  },
];

const bundle = {
  schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash,
  parts: [{ path: PART, sourceSnapshotHash: index.partSnapshotHashes[PART], bundle: { reviews, evidence: records, artifacts, findings } }],
};
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2));
const tally = {};
for (const r of reviews) tally[r.status] = (tally[r.status] ?? 0) + 1;
console.log(JSON.stringify({ outFile, generatedAt: now, reviews: reviews.length, byStatus: tally, evidence: records.length, artifacts: Object.keys(artifacts).length, findings: findings.length, bytes: fs.statSync(outFile).size }, null, 1));
