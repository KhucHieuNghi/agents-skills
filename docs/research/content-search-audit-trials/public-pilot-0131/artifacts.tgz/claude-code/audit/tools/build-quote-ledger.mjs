// Builds the quote ledger for pilot-summary.md from quotes followed by a (file.txt:LINE) locator on the same line.
import fs from "node:fs"; import path from "node:path"; import { createHash } from "node:crypto";
const [root, out] = process.argv.slice(2);
const sha = (b) => createHash("sha256").update(b).digest("hex");
const reportBytes = fs.readFileSync(path.join(root, "pilot-summary.md"));
const lines = reportBytes.toString("utf8").split("\n");
const evDir = "campaign-02-reviewed/parts/000001/evidence";
const quotes = [];
lines.forEach((line, i) => {
  for (const m of line.matchAll(/"((?:[^"]|"(?=[a-z>]))*?)" \(([0-9a-f]{64}\.txt):(\d+)\)/g)) {
    const source = `${evDir}/${m[2]}`;
    quotes.push({ quoteId: `Q${quotes.length + 1}`, source, sourceLabel: m[2], sourceHash: sha(fs.readFileSync(path.join(root, source))), startLine: +m[3], endLine: +m[3], reportStartLine: i + 1, reportEndLine: i + 1, normalization: "exact", quote: m[1] });
  }
});
fs.writeFileSync(out, JSON.stringify({ root, report: "pilot-summary.md", reportHash: sha(reportBytes), quotes }, null, 2));
console.log(quotes.map((q) => q.quoteId + " L" + q.reportStartLine + " " + q.sourceLabel.slice(0, 8) + ":" + q.startLine + " " + q.quote).join("\n"));
