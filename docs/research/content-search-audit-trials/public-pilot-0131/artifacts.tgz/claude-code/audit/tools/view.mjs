// Read-only inert text viewer for collected content evidence. Never executes target content.
import fs from "node:fs";
const [part, mode, ...ids] = process.argv.slice(2);
const L = f => fs.readFileSync(f, "utf8").trim().split("\n").map(JSON.parse);
const inv = L(part + "/inventory.jsonl"), ev = L(part + "/evidence.jsonl");
for (const it of inv) {
  if (ids.length && !ids.some(i => it.itemId.startsWith(i))) continue;
  const c = ev.find(e => e.itemId === it.itemId && e.kind === "content");
  const html = c.value;
  console.log("\n=================== " + it.itemId.slice(0, 8) + " " + it.uri + " content=" + c.evidenceId.slice(0, 8));
  if (mode === "head") {
    const m = html.match(/<head[\s\S]*?<\/head>/i);
    let h = m ? m[0] : "(no head)";
    h = h.replace(/<style[\s\S]*?<\/style>/gi, s => "<style>[" + s.length + " chars]</style>");
    console.log(h.replace(/></g, ">\n<"));
    console.log("-- html tag: " + (html.match(/<html[^>]*>/i) || [""])[0]);
    console.log("-- scripts: " + (html.match(/<script[^>]*>/gi) || []).join(" | "));
    console.log("-- iframes/templates/noscript: " + (html.match(/<(iframe|template|noscript)[^>]*>/gi) || []).join(" | "));
    console.log("-- img: " + (html.match(/<img[^>]*>/gi) || []).join(" | "));
    console.log("-- svg count: " + (html.match(/<svg/gi) || []).length + " video/audio/picture/canvas: " + (html.match(/<(video|audio|picture|canvas|object|embed)[^>]*>/gi) || []).join("|"));
  } else if (mode === "body") {
    let b = html.replace(/<head[\s\S]*?<\/head>/i, "");
    b = b.replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, (s, x) => "\n[[script " + x.length + " chars]]\n").replace(/<style[\s\S]*?<\/style>/gi, "");
    b = b.replace(/<svg[\s\S]*?<\/svg>/gi, "[svg]");
    b = b.replace(/<a\s[^>]*href="([^"]*)"[^>]*>/gi, (s, h) => "[a→" + h.replace("https://github.com/", "gh:") + "]").replace(/<\/a>/gi, "[/a]");
    b = b.replace(/<(h[1-6])[^>]*>/gi, "\n\n#$1# ").replace(/<\/(p|div|li|section|tr|h[1-6]|header|footer|nav|main|article|ul|ol|table|pre|details|summary|dt|dd|figure)>/gi, "\n").replace(/<br\s*\/?>/gi, "\n");
    b = b.replace(/<(code|pre)[^>]*>/gi, "`").replace(/<\/(code)>/gi, "`");
    b = b.replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&#39;|&#x27;/g, "\x27").replace(/&nbsp;/g, " ");
    console.log(b.split("\n").map(s => s.replace(/[ \t]+/g, " ").trim()).filter(Boolean).join("\n"));
  } else if (mode === "raw") console.log(html);
}
