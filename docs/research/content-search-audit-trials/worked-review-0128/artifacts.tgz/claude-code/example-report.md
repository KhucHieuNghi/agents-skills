# Synthetic review example
refund.md:2 — Approved record: refunds are available within 30 days of purchase.
refund.md:3 — Draft: refunds are available within 60 days of purchase.
The draft conflicts with the supplied policy. One finding is persisted; the audit remains partial. See reviewed/report.md and validation.json for complete coverage.
