# Synthetic refund policy
Approved record: refunds are available within 30 days of purchase.
Draft: refunds are available within 60 days of purchase.
