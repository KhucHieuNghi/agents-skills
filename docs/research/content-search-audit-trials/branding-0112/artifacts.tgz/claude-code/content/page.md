# Supplied synthetic content
Customer brand fixture only.
