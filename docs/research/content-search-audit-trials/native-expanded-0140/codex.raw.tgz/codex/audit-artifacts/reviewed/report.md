# Independent synthetic scenarios — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:23:16\.722Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 4a42535e\-38df\-4e59\-8385\-13bbd54337c0\. 5 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F01 | Product response sends noindex despite Google indexing intent | seo\-index\-controls | seo | high | high | observed | 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the conflicting noindex from the intended public product response and check other delivery layers for the same directive\. | Compare a revised successful capture for the exact URL across response headers and robots metadata against intended Google eligibility\. Verify actual index status separately if evidence is later supplied\. | Web platform owner | small | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848, 01\-publisher\-intent, 01\-http\-response |
| F02 | Old and new product routes redirect to one another | seo\-response | seo | high | high | observed | 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Keep one redirect from /old to /new and make /new return the intended accessible product page\. | Inspect a revised hop\-by\-hop capture starting at /old and a direct /new capture\. Require exactly one redirect then a successful product response\. | Web platform owner | small | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0, 02\-publisher\-intent |
| F05 | Vietnamese draft overpromises free ticket changes | quality\-claims, quality\-task\-fit, aio\-retrievable\-facts, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Revise the Vietnamese draft to state free changes apply only to Thành viên, requests must be submitted at least 24 hours before departure, and other classes follow a separate fee table\. Obtain the table before publishing specific fees\. | Compare the revised passage with the supplied policy and check member/non\-member and before/at/inside the 24\-hour boundary\. Check any specific fees against an approved table if supplied\. | Vietnamese content and policy owners | small | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec, 05\-claim\-sources, 05\-audience\-context |
| F03 | Machine\-readable offer price differs from approved visible price | seo\-structured\-data, aio\-entity\-consistency, quality\-claims | seo, aio, quality | medium | high | observed | 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Align the machine\-readable US monthly offer with the approved USD 29 before\-tax price, preferably from the same pricing source\. | Parse the revised offer and compare price, currency and plan identity with the visible US monthly before\-tax policy in the same capture\. Assess feature eligibility separately\. | Pricing and web content owners | small | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5, 03\-schema\-extraction, 03\-entity\-record, 03\-claim\-sources |
| F04 | Current Starter entitlement claims conflict across product and guide | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence, portfolio\-contradictions | quality, aio, aeo, portfolio | medium | high | observed | 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Obtain the versioned authoritative entitlement for the same market and billing period, then reconcile both pages and align their source of truth\. | Compare both revised statements with the approved policy and each other using the same version, market and monthly period\. | Product policy and content owners | medium | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d, 04\-inventory\-map |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 4 | 32 | 0 |
| aio | 36 | 3 | 33 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 8 | 52 | 0 |
| seo | 96 | 3 | 92 | 1 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | pending | Snapshot review incomplete | 26 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | pending | Snapshot review incomplete | 26 |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | pending | Snapshot review incomplete | 26 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | pending | Snapshot review incomplete | 26 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | pending | Snapshot review incomplete | 26 |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | pending | Snapshot review incomplete | 26 |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | pending | Snapshot review incomplete | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response | 02\-publisher\-intent, 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy | 02\-publisher\-intent |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 01\-http\-response |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-index\-controls | seo | fail | The captured Google indexing directives contain noindex despite explicit intent for index eligibility\. | 01\-http\-response, 01\-publisher\-intent, 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy | 01\-publisher\-intent |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: question\-set | 04\-inventory\-map, bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | portfolio\-duplication | portfolio | unknown | Semantic review and applicability assessment required | 04\-inventory\-map, bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record | 04\-inventory\-map, bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | quality\-claims | quality | fail | The machine\-readable price conflicts with the publisher\-confirmed visible price for the same offer\. | 03\-claim\-sources, 03\-schema\-extraction, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 03\-claim\-sources, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-structured\-data | seo | fail | Complete supplied offer block gives USD 19 while same\-market visible policy gives USD 29 before taxes\. | 03\-schema\-extraction, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aio\-entity\-consistency | aio | fail | Same US monthly plan has different machine\-readable and visible prices\. | 03\-entity\-record, 03\-schema\-extraction, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | aeo\-answer\-evidence | aeo | pass | The supplied visible US monthly price answer includes its tax caveat and matches the publisher\-confirmed policy\. The incompatible machine\-readable offer is tracked separately under this same finding\. | 03\-claim\-sources, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | 03\-claim\-sources |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: inventory\-map | 03\-entity\-record, f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | quality\-task\-fit | quality | pass | The Vietnamese export instructions provide the user steps and the attachment and timing limitations\. | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-audience\-context |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | quality\-claims | quality | pass | The supplied procedure supports the steps and limitations exactly\. | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-claim\-sources |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-claim\-sources |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-metadata | seo | unknown | Semantic review and applicability assessment required | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-audience\-context |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-locales | seo | not\-applicable | Publisher confirms the Vietnamese\-only document has no intended English counterpart or observed alternative relationship\. Deployment metadata remains unverified\. | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aio\-retrievable\-facts | aio | pass | The Vietnamese export instructions provide the user steps and the attachment and timing limitations\. | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-audience\-context |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | aeo\-answer\-evidence | aeo | pass | The supplied procedure supports the steps and limitations exactly\. | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-claim\-sources |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | 07\-claim\-sources |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 |
| 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph | 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383, 07\-audience\-context |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | quality\-claims | quality | pass | The draft accurately distinguishes November 2026 publication from February 2024 collection and explicitly limits the aggregate to the historical panel\. | 08\-claim\-sources, a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | quality\-freshness | quality | pass | The draft accurately distinguishes November 2026 publication from February 2024 collection and explicitly limits the aggregate to the historical panel\. | 08\-claim\-sources, a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | 08\-claim\-sources, a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | 08\-claim\-sources |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | quality\-task\-fit | quality | fail | The Vietnamese draft omits the membership and timing conditions and misstates eligibility for other fare classes\. | 05\-audience\-context, 05\-claim\-sources, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | quality\-claims | quality | fail | The Vietnamese draft omits the membership and timing conditions and misstates eligibility for other fare classes\. | 05\-audience\-context, 05\-claim\-sources, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 05\-claim\-sources, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-metadata | seo | unknown | Semantic review and applicability assessment required | 05\-audience\-context, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aio\-retrievable\-facts | aio | fail | The Vietnamese draft omits the membership and timing conditions and misstates eligibility for other fare classes\. | 05\-audience\-context, 05\-claim\-sources, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | aeo\-answer\-evidence | aeo | fail | The Vietnamese draft omits the membership and timing conditions and misstates eligibility for other fare classes\. | 05\-audience\-context, 05\-claim\-sources, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | 05\-claim\-sources |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph | 05\-audience\-context, 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | quality\-claims | quality | pass | The sole user\-visible answer limits exports to account\-owned records, as the supplied policy confirms\. The hidden instruction is not a product assertion\. | 10\-claim\-sources, a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 10\-claim\-sources, a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | aeo\-answer\-evidence | aeo | pass | The sole user\-visible answer limits exports to account\-owned records, as the supplied policy confirms\. The hidden instruction is not a product assertion\. | 10\-claim\-sources, a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | 10\-claim\-sources |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |
| ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0a90890a41863bbe75843d5260c489940e03fa95d134fd7dd414fff4940758d0 | 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | local\-file | 2026\-11\-18T08:21:55\.810Z | 0 full elapsed days | [evidence/3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6\.txt](evidence/3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 849fbe1ac21be44e556ebc7ad296cf840bfd1b02a51a5231565c5ad1d300b848 | 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | local\-file | 2026\-11\-18T08:21:55\.811Z | 0 full elapsed days | [evidence/44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90\.txt](evidence/44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| bb37c790bb3329c4062f60fce95883d4aa194cca12a96ab15645e797d0e2c01d | 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | local\-file | 2026\-11\-18T08:21:55\.812Z | 0 full elapsed days | [evidence/494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c\.txt](evidence/494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f953d998ecd50e94d3cb94e5ddec2a09b09109d559aeab5300b559cb582438d5 | 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | local\-file | 2026\-11\-18T08:21:55\.812Z | 0 full elapsed days | [evidence/4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b\.txt](evidence/4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0093e1fd754157b1c05ba2ce94a6373b203a37d32da83d477e2e92c55ba2a383 | 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | local\-file | 2026\-11\-18T08:21:55\.813Z | 0 full elapsed days | [evidence/55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998\.txt](evidence/55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a8a2e58f5ec106b5945046313e06a6e7bd6443eade1f08ac959cc60a87606c8c | 91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35 | local\-file | 2026\-11\-18T08:21:55\.813Z | 0 full elapsed days | [evidence/91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35\.txt](evidence/91e74cd63e59afb04cf60c2d6fc3bf69cb2ec7659c51442e614d57c3a6097a35.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3591ce1697eb6c2cc9fd5fda9b7539ea04893b93a16587ab711896c0854f39da | aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c | local\-file | 2026\-11\-18T08:21:55\.814Z | 0 full elapsed days | [evidence/aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c\.txt](evidence/aba8722cc34218221f7f54a4c19ea53ebf1d5388fde138b3f0bc2285592cc87c.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a16476c5ee65cb4ce88b9b5f33abefe9fceebb32c6b9373ef328976f29b561c3 | ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | local\-file | 2026\-11\-18T08:21:55\.814Z | 0 full elapsed days | [evidence/ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a\.txt](evidence/ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3e108bbf2dec13881634e668174a8ed5acdbb41755186c61f278a946567043ec | af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | local\-file | 2026\-11\-18T08:21:55\.815Z | 0 full elapsed days | [evidence/af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68\.txt](evidence/af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a2d644af571a23669f0d91ba0208eb1023e9f5d4fe16c1bdd4672efaeee5d1d0 | ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | local\-file | 2026\-11\-18T08:21:55\.816Z | 0 full elapsed days | [evidence/ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441\.txt](evidence/ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 01\-publisher\-intent | 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/01\-publisher\-intent\.txt](evidence/01-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Derived from supplied offline synthetic evidence only\. |
| 01\-http\-response | 44f1b7953dc64638fb0936a832518c3dc9727cd53083069e94d35ea6b266bf90 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/01\-http\-response\.txt](evidence/01-http-response.txt) | 18f373d85dbf31e1f4d22eeaafa9b1e4833598475ee824c3b6e7eb42a82885c6 | Derived from supplied offline synthetic evidence only\. |
| 02\-publisher\-intent | 3d5312a804e224b6cb29703a8c66897573afd4b84155134b8c37b5c05d1796d6 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/02\-publisher\-intent\.txt](evidence/02-publisher-intent.txt) | 78dadcd00928ec51256158c44d8ea8dc1f4baac289753616876317906cb877df | Derived from supplied offline synthetic evidence only\. |
| 03\-schema\-extraction | 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/03\-schema\-extraction\.txt](evidence/03-schema-extraction.txt) | 0c522356b25041d496d85210dae7c21b789759cc375e8c170bfa026ccf25c81d | Derived from supplied offline synthetic evidence only\. |
| 03\-entity\-record | 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/03\-entity\-record\.txt](evidence/03-entity-record.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Derived from supplied offline synthetic evidence only\. |
| 03\-claim\-sources | 4e3e519181316ecdb97057b5ca23087042285bf2b1cf51c02e775cd1c348935b | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/03\-claim\-sources\.txt](evidence/03-claim-sources.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Derived from supplied offline synthetic evidence only\. |
| 04\-inventory\-map | 494a79f094cbf99b5283c0c9c1376a71f38e4c1107c694e6f59dc9ee4c2f032c | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/04\-inventory\-map\.txt](evidence/04-inventory-map.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Derived from supplied offline synthetic evidence only\. |
| 05\-claim\-sources | af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/05\-claim\-sources\.txt](evidence/05-claim-sources.txt) | 2af2411c2c3cfa27fc949c553e7fdf34b4268519a65ed45aedcb56db3539d9db | Derived from supplied offline synthetic evidence only\. |
| 05\-audience\-context | af0176911ba45cdb689095aea9718ed48775180c8a212c1c5c28fbc211d58d68 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/05\-audience\-context\.txt](evidence/05-audience-context.txt) | bc434248948c0ea46a3aaeb7b5b108fb1460a7e5ba4f78367ca4dc2d93cee88f | Derived from supplied offline synthetic evidence only\. |
| 07\-audience\-context | 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/07\-audience\-context\.txt](evidence/07-audience-context.txt) | 444f8003d17a158d2494be87dcbe1dc9e8c305fef553f1a8fd52dae372d2467e | Derived from supplied offline synthetic evidence only\. |
| 07\-claim\-sources | 55074e34fb21230867d72807c1453502d701fc6cbc13ebd7c4813f61168cf998 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/07\-claim\-sources\.txt](evidence/07-claim-sources.txt) | 5b3ff50e4a81caa84f8f0391b3e8b59e77c3b843bc00327de2146a2a720ffdaa | Derived from supplied offline synthetic evidence only\. |
| 08\-claim\-sources | ae8c9ce2bdec9396e50fe310196ec684b86d9d3cc9714a590f86a1b10c12bc1a | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/08\-claim\-sources\.txt](evidence/08-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Derived from supplied offline synthetic evidence only\. |
| 10\-claim\-sources | ee851d16cf523e87c543099f796b8f1386c691d6baffa8b6f09c2d5c41ba0441 | supplied\-synthetic\-dossier | 2026\-11\-18T08:23:16\.582Z | 0 full elapsed days | [evidence/10\-claim\-sources\.txt](evidence/10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Derived from supplied offline synthetic evidence only\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
