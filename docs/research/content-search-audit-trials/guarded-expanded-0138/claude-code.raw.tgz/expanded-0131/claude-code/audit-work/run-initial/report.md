# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:02:44\.425Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run f1931aed\-a1a3\-440d\-8fa5\-fcbc42b7ff3c\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| b043d214b9ed462470cf484f3d76f4f3cdeac7a7a13a3f9bfce21c27968d3f0f | 2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80 | local\-file | 2026\-11\-18T08:02:44\.404Z | 0 full elapsed days | [evidence/2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80\.txt](evidence/2065aae122895e608ed6ecdf76a7485ca4aa576800e58cb77d986bc60282fa80.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 9aca465d20a24bd3ee7a40c98ade467606f1d0ce90822a1f8631ae13b0c34c62 | 2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921 | local\-file | 2026\-11\-18T08:02:44\.405Z | 0 full elapsed days | [evidence/2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921\.txt](evidence/2e06d35dffdfea285bcc8063040fb48786892feaf35c65003a882020f0abd921.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| aba7a713217785d7ad36620867b1d67c0cfb59991c42416c6bfc681b639436b0 | 404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923 | local\-file | 2026\-11\-18T08:02:44\.406Z | 0 full elapsed days | [evidence/404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923\.txt](evidence/404e634d026d8ce8e42bfc162ac61dce2082f91aaa1245e6a3777af4806d0923.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 88c1a2f5f9f8e2f755875eda32292cf08978dd33089bf1bd1f8f37cf2e3b723a | 6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549 | local\-file | 2026\-11\-18T08:02:44\.406Z | 0 full elapsed days | [evidence/6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549\.txt](evidence/6cbdf1f2129c8d0f32d011ecfec5e577516b59bda466aa57cf28e0cca7c1c549.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 67c3f003580d56430415ffac2e64a81878e653b8bee2f4e7adda75de230e8dbf | 98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec | local\-file | 2026\-11\-18T08:02:44\.407Z | 0 full elapsed days | [evidence/98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec\.txt](evidence/98e59a6652216724d40003987b1cdebe8cbab7e40885a76079c3ea120a560aec.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b8d835ddf566df448f59531c72529acfa214bd9459c153b60c57602ec5d93269 | af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936 | local\-file | 2026\-11\-18T08:02:44\.407Z | 0 full elapsed days | [evidence/af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936\.txt](evidence/af3c2f5a30c1f6c7dfc51a1ca1381da9f064d8fbfe3c06df2c935c1d4c456936.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4b92263cd1395dc5bd5353ad024acb3c713d40b4ebad3de4b8c9e9317f7c1f57 | ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af | local\-file | 2026\-11\-18T08:02:44\.407Z | 0 full elapsed days | [evidence/ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af\.txt](evidence/ca3cdeb8155ff9c98caa5363eeaac8ef0069482164192e30bbc2a9263b53e3af.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ca435c1f987aca8709c4decdd09e8511c478f13095d2fc3d94c843e12589ec23 | d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f | local\-file | 2026\-11\-18T08:02:44\.408Z | 0 full elapsed days | [evidence/d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f\.txt](evidence/d14deaf8e5c650a52eaabb7aa01781e68c7109190b5f7279e2429fb677c6015f.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e9f77a88b9a662f2add1d9abdbe7a87955fc51b707fed518b5f22f88ed73fe11 | e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97 | local\-file | 2026\-11\-18T08:02:44\.408Z | 0 full elapsed days | [evidence/e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97\.txt](evidence/e3643c4353a65fc7916145decc68c6b56e29e175ee3d8aaf91e89a5c3dba0d97.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 80eec48aea879cda80420af947531397584b961b43b5ab980774042ddd37a3f2 | e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2 | local\-file | 2026\-11\-18T08:02:44\.409Z | 0 full elapsed days | [evidence/e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2\.txt](evidence/e7b63d1d944b5ecace3ac3844d7f301bd9016a361f5d0aaa8b5e6167672973a2.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
