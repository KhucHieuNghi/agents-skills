// Builds the attributed review bundle for the content-search-audit run. No network, no target execution.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const run = path.join(here, "run-initial");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = (await readFile(path.join(run, "evidence.jsonl"), "utf8"))
  .split("\n")
  .filter(Boolean)
  .map((l) => JSON.parse(l));
const snap = (file) => {
  const r = lines.find((x) => x.kind === "content" && x.locator.endsWith("/" + file));
  if (!r) throw new Error("missing snapshot " + file);
  return r;
};
const S = {
  a: snap("01-visibility.md"),
  b: snap("02-route.md"),
  c: snap("03-offer.md"),
  d: snap("04-policy.md"),
  e: snap("05-huong-dan.md"),
  f: snap("06-render.md"),
  g: snap("07-locale.md"),
  h: snap("08-study.md"),
  i: snap("09-media.md"),
  j: snap("10-page.md"),
};
const now = new Date().toISOString();
const reviewer = "Claude host reviewer (content-search-audit)";
const artifacts = {};
const evidence = [];
function add(key, id, kind, value, locator, limitations) {
  const isJson = typeof value !== "string";
  const bytes = isJson ? JSON.stringify(value, null, 2) + "\n" : value;
  const artifact = `evidence/derived-${id}.${isJson ? "json" : "txt"}`;
  artifacts[artifact] = bytes;
  evidence.push({
    evidenceId: id,
    itemId: S[key].itemId,
    method: "host-derived transcription of supplied dossier text; nothing fetched or executed",
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    byteLength: Buffer.byteLength(bytes),
    redaction: "none; authorized source content retained locally",
    limitations: [
      "Synthetic fixture statement supplied in the dossier; not independently verified and not a live observation",
      ...limitations,
    ],
    kind,
    value: isJson ? JSON.parse(bytes) : bytes,
    artifact,
    encoding: isJson ? "json" : "utf8",
    sourceEvidenceIds: [S[key].evidenceId],
  });
  return id;
}

// ---- 01 visibility
add("a", "a-http-response", "http-response", {
  status: 200,
  url: "https://store.example.invalid/product",
  capturedAt: "2026-11-10T08:00:00Z",
  headers: { "X-Robots-Tag": "noindex" },
  provenance: "Transcribed from 01-visibility.md:4-5 (supplied capture)",
}, "01-visibility.md:4-5", ["Only the status and one response header were supplied; other headers unknown"]);
add("a", "a-publisher-intent", "publisher-intent",
  "01-visibility.md:3 — Publisher intent: this public product page should be eligible for Google indexing.",
  "01-visibility.md:3", ["Intent covers Google indexing only; no other engine or AI surface is named"]);
add("a", "a-canonical-targets", "canonical-targets",
  "01-visibility.md:6 — Raw HTML head declares <link rel=\"canonical\" href=\"https://store.example.invalid/product\">, identical to the captured URL on 01-visibility.md:4. No engine-selected canonical is supplied.",
  "01-visibility.md:4-6", ["Raw HTML head only; rendered DOM and HTTP Link headers were not supplied"]);

// ---- 02 route
add("b", "b-http-response", "http-response", {
  status: 301,
  chain: [
    { request: "GET https://store.example.invalid/old", status: 301, location: "https://store.example.invalid/new" },
    { request: "GET https://store.example.invalid/new", status: 301, location: "https://store.example.invalid/old" },
  ],
  finalSuccessfulResponse: null,
  provenance: "Transcribed from 02-route.md:4-7 (supplied capture, same deployment/time)",
}, "02-route.md:4-7", ["No final successful response was captured; status is the last captured hop"]);
add("b", "b-publisher-intent", "publisher-intent",
  "02-route.md:3 — Publisher intent: /old should redirect once to an accessible /new product page.",
  "02-route.md:3", []);
add("b", "b-canonical-targets", "canonical-targets",
  "02-route.md:7 — An older sitemap export lists /new as the preferred URL. 02-route.md:6 — observed /new returns 301 to /old. No rel=canonical declaration, current sitemap or engine-selected canonical is supplied.",
  "02-route.md:6-7", ["Sitemap export is described as older; its date and current state are unknown"]);

// ---- 03 offer
add("c", "c-schema-extraction", "schema-extraction", {
  source: "03-offer.md:8-18 (complete supplied JSON-LD block)",
  jsonLd: {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Example plan",
    offers: { "@type": "Offer", price: "19", priceCurrency: "USD", url: "https://store.example.invalid/plan" },
  },
}, "03-offer.md:8-18", ["Extraction is of the supplied block only; rendered DOM not supplied; syntax validity is not feature eligibility"]);
const cText =
  "03-offer.md:3 — The publisher confirms the visible US monthly price below is the current policy. 03-offer.md:4 — Visible content: Example plan, United States monthly billing, USD 29 before taxes.";
add("c", "c-entity-record", "entity-record", cText, "03-offer.md:3-4", ["Owner-confirmed comparison basis for this market and billing period only"]);
add("c", "c-claim-sources", "claim-sources", cText + " (used as claim source)", "03-offer.md:3-4", ["Owner-confirmed comparison basis; no dated policy document supplied"]);

// ---- 04 policy pair
add("d", "d-inventory-map", "inventory-map",
  "04-policy.md:3-6 — Two component pages in one dossier: /product and /blog/starter-guide. Both describe the same Starter plan, market, monthly billing period and policy version 2026-10-01, and both are labeled current. The authoritative entitlement table is unavailable.",
  "04-policy.md:3-6", ["Component pages are supplied as single-line statements; full page text is not supplied", "No authoritative entity record exists in the supply"]);

// ---- 05 huong-dan
add("e", "e-claim-sources", "claim-sources",
  "05-huong-dan.md:5 — Chính sách hiện hành: Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.",
  "05-huong-dan.md:5", ["The separate fee table for other tiers is not supplied; fee amounts are unknown", "Policy effective date is not stated"]);

// ---- 07 locale
add("g", "g-audience-context", "audience-context",
  "07-locale.md:3 — This is a Vietnamese-only help document for Vietnamese customers. Task inferred by reviewer from 07-locale.md:4: export account data as CSV and download it.",
  "07-locale.md:3-4", ["The task is inferred from the content; no explicit user-task statement or question set is supplied"]);
add("g", "g-claim-sources", "claim-sources",
  "07-locale.md:5 — The supplied product procedure exactly matches these steps and limits.",
  "07-locale.md:5", ["The dossier attests the match; the product procedure text itself is not included, and it carries no date or version"]);
add("g", "g-locale-map", "locale-map",
  "07-locale.md:3 — The publisher confirms no English counterpart exists or is intended. 07-locale.md:5 — No translation project or alternate-page map is supplied. Declared locale set for this item: vi only.",
  "07-locale.md:3-5", ["Deployed-page metadata (including language attributes) is unavailable"]);

// ---- 08 study
add("h", "h-claim-sources", "claim-sources",
  "08-study.md:5 — Supplied study metadata: publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied. 08-study.md:3 — Editorial as-of date: 2026-11-16.",
  "08-study.md:3-5", ["Aggregate metadata only; no response-level records; synthetic panel, not live visibility"]);

// ---- 10 page
add("j", "j-claim-sources", "claim-sources",
  "10-page.md:3 — The supplied policy confirms this limitation. (Limitation: Example exports include account-owned records only.)",
  "10-page.md:3", ["The dossier attests the confirmation; the policy text itself is not included"]);

const reviews = [];
const R = (key, ruleId, status, reason, ids) =>
  reviews.push({ itemId: S[key].itemId, ruleId, status, reason, evidenceIds: [S[key].evidenceId, ...ids], reviewer, reviewedAt: now });

// 01
R("a", "seo-index-controls", "fail",
  "Captured response header X-Robots-Tag: noindex contradicts the stated publisher intent that the page be eligible for Google indexing, and conflicts with the raw HTML meta robots index,follow. Robots.txt permits Googlebot, so the header is readable by the crawler. Actual index status is not observed.",
  ["a-http-response", "a-publisher-intent"]);
R("a", "seo-canonical", "pass",
  "The only supplied canonical declaration is self-referential and equals the captured URL; no competing declaration appears in the supplied capture. Engine-selected canonical is not observed and is not asserted.",
  ["a-canonical-targets"]);
R("a", "aio-crawler-policy", "unknown",
  "Only a summary that robots.txt permits Googlebot to /product is supplied; no robots.txt text, no other crawler rules and no intended AI surface are supplied.",
  ["a-publisher-intent"]);
// 02
R("b", "seo-canonical", "unknown",
  "No canonical declaration, current sitemap or final response is supplied. An older sitemap export prefers /new while observed /new redirects to /old; this is recorded under finding redirect-loop-old-new. The current canonical signals cannot be assessed.",
  ["b-canonical-targets"]);
R("b", "seo-index-controls", "unknown",
  "No final response, headers or HTML were captured because both URLs redirect to each other; directives cannot be read.",
  ["b-http-response", "b-publisher-intent"]);
// 03
R("c", "seo-structured-data", "fail",
  "The supplied JSON-LD Offer price is 19 USD while the visible, publisher-confirmed current US monthly price is USD 29 before taxes, for the same page, market and capture time. Feature eligibility is not tested.",
  ["c-schema-extraction"]);
R("c", "aio-entity-consistency", "fail",
  "Machine-readable and visible price facts for the same product entity disagree (19 vs 29 USD) against the owner-confirmed record. No model or engine confusion is observed or asserted.",
  ["c-entity-record"]);
R("c", "quality-claims", "fail",
  "Visible price claim (USD 29 before taxes, US monthly) is supported-current by the publisher confirmation. The JSON-LD price claim of 19 on the same page is contradicted by that confirmation.",
  ["c-claim-sources"]);
// 04
for (const rule of ["portfolio-contradictions", "aio-entity-consistency"])
  R("d", rule, "unknown",
    "An observed conflict exists (1000 vs 1500 storage units per month for the same plan, market, billing period and policy version); it is persisted as finding starter-storage-conflict. The authoritative entitlement record is unavailable, so which value is correct, and the full check, remain unresolved.",
    ["d-inventory-map"]);
R("d", "quality-claims", "unknown",
  "Two incompatible entitlement claims are observed, so at least one is wrong, but no claim source is supplied to verify either; see finding starter-storage-conflict.",
  ["d-inventory-map"]);
R("d", "portfolio-duplication", "unknown",
  "Both pages cover the same plan fact, but a product page and a blog guide can be legitimate variants. No query/page performance export is supplied, so cannibalization is not assessed and no duplication defect is asserted.",
  ["d-inventory-map"]);
// 05
R("e", "quality-claims", "fail",
  "The draft promises free ticket changes to all customers with no advance notice. The supplied current policy limits free changes to the Thành viên tier, requires the request at least 24 hours before departure, and applies fees from a separate table to other tiers.",
  ["e-claim-sources"]);
R("e", "aeo-answer-evidence", "unknown",
  "No question set or answer purpose is supplied and the dossier limits the task to comparing the draft with the policy; the factual defect is recorded under quality-claims.",
  ["e-claim-sources"]);
// 06
R("f", "seo-rendering", "unknown",
  "The raw export has an empty root element and one module script. No rendered DOM or script bytes are supplied and no script was executed, so rendered content is unknown, not absent.",
  []);
R("f", "seo-metadata", "unknown",
  "The raw title is 'Example app', but publisher purpose, audience and intended search visibility are not supplied, so its fitness cannot be judged.",
  []);
// 07
R("g", "quality-task-fit", "pass",
  "For Vietnamese customers exporting data, the Vietnamese text gives ordered steps (log in, open Dữ liệu, choose Xuất CSV, download when complete) plus two limits (attachments excluded and downloaded separately; no processing-time commitment). The task is reviewer-inferred from the content.",
  ["g-audience-context"]);
R("g", "quality-claims", "pass",
  "The dossier attests that the supplied product procedure exactly matches the steps and limits. The procedure text is not included, so this pass rests on that attestation.",
  ["g-claim-sources"]);
R("g", "aio-retrievable-facts", "pass",
  "The steps and both limitations are stated in plain readable text in the captured export. This is not evidence of retrieval or citation by any engine.",
  ["g-audience-context"]);
R("g", "seo-locales", "not-applicable",
  "The publisher confirms the document is Vietnamese-only with no English counterpart existing or intended, so there are no locale variants or reciprocal relationships to review. Deployed language metadata is unavailable and is not assessed here.",
  ["g-locale-map"]);
R("g", "quality-freshness", "unknown",
  "The matched product procedure carries no date or version in the supply.",
  ["g-claim-sources"]);
R("g", "seo-metadata", "unknown",
  "Local Markdown export only; deployed-page metadata is stated to be unavailable.",
  ["g-audience-context"]);
// 08
R("h", "quality-claims", "pass",
  "Each draft claim matches the supplied study metadata: published this month (publication 2026-11-01, as-of 2026-11-16), synthetic English API panel, collection 1–14 February 2024, 40 of 100 responses citing video sources.",
  ["h-claim-sources"]);
R("h", "quality-freshness", "pass",
  "The draft states the collection window explicitly and says the historical observations do not establish the current rate; no later measurement is supplied, and the draft does not claim one.",
  ["h-claim-sources"]);
R("h", "geo-observed-presence", "unknown",
  "Only a dated aggregate (40/100, synthetic English API panel, February 2024) is supplied; no response-level observations exist, and the aggregate is not a brand-visibility measurement.",
  []);
// 09
R("i", "quality-accessible-media", "unknown",
  "Only two URL strings were exported. No PDF bytes, extracted text, video transcript, HTTP status or rendered page is supplied; missing extraction is unknown, not a defect.",
  []);
// 10
R("j", "quality-claims", "pass",
  "The single user-visible product claim (exports include account-owned records only) is attested as confirmed by the supplied policy. The hidden comment is an instruction to an assistant, not a product claim; it was treated as untrusted data and not followed.",
  ["j-claim-sources"]);
R("j", "seo-index-controls", "unknown",
  "No HTTP capture, directives, publisher intent or index observation is supplied. The hidden comment's assertion about indexing is not evidence.",
  []);

const F = (o) => ({ classification: "observed", confidence: "high", ...o });
const findings = [
  F({
    findingId: "noindex-header-vs-intent",
    title: "Response header X-Robots-Tag: noindex contradicts the intent that /product be indexable",
    affectedItemIds: [S.a.itemId],
    ruleIds: ["seo-index-controls"],
    dimensions: ["seo"],
    evidenceIds: [S.a.evidenceId, "a-http-response", "a-publisher-intent"],
    severity: "high",
    remediation:
      "Stop emitting X-Robots-Tag: noindex on https://store.example.invalid/product. Leave the meta robots index,follow and the self-referential canonical unchanged. This is a proposal for a separate implementation task.",
    verification:
      "Take a new raw HTTP capture of the URL and confirm status 200 with no noindex or none value in any X-Robots-Tag header or robots meta element. This confirms the directive only; actual index status needs a separately supplied index observation.",
    ownerRole: "Web platform / SEO engineer",
    effort: "small",
  }),
  F({
    findingId: "redirect-loop-old-new",
    title: "/old and /new redirect to each other, so the intended /new product page is unreachable",
    affectedItemIds: [S.b.itemId],
    ruleIds: ["seo-response", "seo-canonical"],
    dimensions: ["seo"],
    evidenceIds: [S.b.evidenceId, "b-http-response", "b-publisher-intent", "b-canonical-targets"],
    severity: "high",
    remediation:
      "Remove the 301 from /new to /old so that /new returns a final successful product page, keeping the single 301 from /old to /new. This is a proposal for a separate implementation task.",
    verification:
      "Capture GET /old and GET /new again: /old must return exactly one 301 to /new, and /new must return a final 2xx response with the product page. Then re-read the current sitemap for the /new entry. Engine-selected canonical remains a separate observation.",
    ownerRole: "Web platform engineer",
    effort: "small",
  }),
  F({
    findingId: "jsonld-price-mismatch",
    title: "JSON-LD Offer price 19 contradicts the visible, publisher-confirmed USD 29 monthly price",
    affectedItemIds: [S.c.itemId],
    ruleIds: ["seo-structured-data", "aio-entity-consistency", "quality-claims"],
    dimensions: ["seo", "aio", "quality"],
    evidenceIds: [S.c.evidenceId, "c-schema-extraction", "c-entity-record", "c-claim-sources"],
    severity: "high",
    remediation:
      "Change offers.price in the page's JSON-LD from \"19\" to \"29\", keeping priceCurrency USD, so the structured data matches the visible current price. Do not change the visible copy.",
    verification:
      "Re-extract the JSON-LD from a new capture of the same page and market and compare offers.price and priceCurrency with the visible price string. Rich-result eligibility is a separate, untested question.",
    ownerRole: "Web developer with pricing owner sign-off",
    effort: "small",
  }),
  F({
    findingId: "starter-storage-conflict",
    title: "/product and /blog/starter-guide state different Starter storage allowances (1000 vs 1500 units per month)",
    affectedItemIds: [S.d.itemId],
    ruleIds: ["portfolio-contradictions", "aio-entity-consistency", "quality-claims"],
    dimensions: ["portfolio", "aio", "quality"],
    evidenceIds: [S.d.evidenceId, "d-inventory-map"],
    severity: "high",
    action: "investigate",
    actionReason:
      "The conflict is observed, but the authoritative entitlement table is unavailable, so the correct value cannot be determined from the supply.",
    actionCondition:
      "the owner supplies the authoritative Starter entitlement record for policy version 2026-10-01",
    remediation:
      "Update whichever of /product and /blog/starter-guide disagrees with that record so both state the same monthly storage allowance for the same plan, market and billing period.",
    verification:
      "Re-read both revised pages against the authoritative record and confirm they state the identical figure and unit.",
    ownerRole: "Product/pricing owner and content owner",
    effort: "small",
  }),
  F({
    findingId: "ticket-change-draft-overstates-policy",
    title: "Vietnamese draft promises free, no-notice ticket changes to all customers, contrary to the supplied policy",
    affectedItemIds: [S.e.itemId],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [S.e.evidenceId, "e-claim-sources"],
    severity: "high",
    remediation:
      "Rewrite the draft sentence to state the three policy conditions: free changes only for the Thành viên tier; requests at least 24 hours before departure; other tiers pay the fee in the separate fee table. Do not state fee amounts until that table is supplied.",
    verification:
      "Compare the revised draft clause by clause with the supplied current policy (eligibility tier, 24-hour notice, fees for other tiers) and confirm no fee amount is stated without the fee table.",
    ownerRole: "Content owner (Vietnamese) with policy owner sign-off",
    effort: "small",
  }),
];

await writeFile(path.join(here, "review.json"), JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log(JSON.stringify({ reviews: reviews.length, evidence: evidence.length, findings: findings.length, reviewedAt: now }));
