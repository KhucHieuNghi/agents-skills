// Renders a separate report edition of the validated reviewed run with the supplied
// historical study attached via the packaged studySources option. New-only output.
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);
const pkg = path.join(root, ".claude/skills/content-search-audit");
const { buildReportDocuments } = await import(pathToFileURL(path.join(pkg, "scripts/lib/report.mjs")));
const { loadAuditData, validateAudit } = await import(pathToFileURL(path.join(pkg, "scripts/lib/validate.mjs")));
const registry = JSON.parse(await readFile(path.join(pkg, "rules/core.json"), "utf8"));
const runDir = path.join(here, "run-reviewed");
const validation = await validateAudit(runDir);
if (!validation.valid) throw new Error("Reviewed run invalid");
const audit = await loadAuditData(runDir);
const sourceText = await readFile(path.join(root, "targets/08-study.md"), "utf8");
const srcLines = sourceText.split(/\r?\n/);
const studySources = [
  {
    sourceId: "dossier-08-study",
    kind: "historical-study",
    locator: "targets/08-study.md",
    sourceText,
    sourceHash: createHash("sha256").update(sourceText).digest("hex"),
    synthetic: true,
    scope:
      "Synthetic English API panel; collection 2024-02-01 through 2024-02-14; 40/100 responses cited video sources; publication 2026-11-01. Engine, model, prompts and brand are not stated.",
    limitations: [
      "Aggregate only; no response-level records, so no observation rows or current rates are derived",
      "Historical window; no later measurement is supplied, so the current rate is unknown",
      "Synthetic fixture; API panel results are not consumer-UI or live brand visibility",
    ],
    passages: [4, 5].map((n) => ({ startLine: n, endLine: n, quote: srcLines[n - 1] })),
  },
];
const documents = buildReportDocuments(audit, registry, { studySources });
const out = path.join(here, "report-with-study");
await mkdir(out);
for (const [name, content] of Object.entries(documents))
  await writeFile(path.join(out, name), content, { flag: "wx" });
console.log(JSON.stringify({ out, files: Object.keys(documents) }));
