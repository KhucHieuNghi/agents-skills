// Builds the quote ledger from every "- `file:line` — `quote`" line in the final report.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const report = await readFile(path.join(root, "report.md"));
const lines = report.toString("utf8").split("\n");
const pattern = /^- `(\d\d-[a-z-]+\.md):(\d+)(?:-(\d+))?` — `(.+)`$/;
const sources = new Map();
const quotes = [];
const unmatched = [];
for (const [index, line] of lines.entries()) {
  const m = pattern.exec(line);
  if (!m) {
    if (/^- `\d\d-[a-z-]+\.md:/.test(line)) unmatched.push(index + 1);
    continue;
  }
  const [, file, start, end, quote] = m;
  if (!sources.has(file)) sources.set(file, hash(await readFile(path.join(root, "targets", file))));
  quotes.push({
    quoteId: `q${quotes.length + 1}-${file}-${start}`,
    source: `targets/${file}`,
    sourceLabel: file,
    sourceHash: sources.get(file),
    startLine: Number(start),
    endLine: Number(end ?? start),
    reportStartLine: index + 1,
    reportEndLine: index + 1,
    normalization: "exact",
    quote,
  });
}
if (unmatched.length) throw new Error("Unparsed quote lines: " + unmatched.join(","));
await writeFile(
  path.join(here, "quotes.json"),
  JSON.stringify({ root, report: "report.md", reportHash: hash(report), quotes }, null, 2) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, files: [...sources.keys()] }));
