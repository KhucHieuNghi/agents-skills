# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T02:20:27\.012Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 312d97a4\-f60b\-4baf\-9c6b\-c0ac53168f44\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 2 |
| Pending | 1 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 1 | 14 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | pdf\-text |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| b1707fe9d99643990828a61e47ab0954285f01550b8aac2c05b8c1c8b52351dc | 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | local\-file | 2026\-11\-16T02:20:26\.888Z | 0 full elapsed days | [evidence/2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428\.txt](evidence/2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| real\-rendered\-dom | 2f1b8aeca9338e141c4c2e5dc17fb273eccf028c72987fecb7bc888c3af58428 | chrome\-headless\-dump\-dom | 2026\-11\-16T02:20:26\.933Z | 0 full elapsed days | [evidence/real\-rendered\-dom\.txt](evidence/real-rendered-dom.txt) | d97ba418d6ef26ffa11fb26b35033eda6e7a7260a7ff16284c9c23ae462b2836 | Actual isolated\-profile local Chrome capture; not engine rendering or indexing\.; Only controlled authored script was executed; no process\-level network attestation\. |
| pdf\-provenance | 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | host\-capture\-manifest | 2026\-11\-16T02:20:26\.934Z | 0 full elapsed days | [evidence/pdf\-provenance\.json](evidence/pdf-provenance.json) | 39c7a50764ab58f8e8e99a00fe0d4d00631a79e006f87fb6aa96fbf75d2d22ff | Original PDF retained externally in trial archive; helper validates the manifest bytes, not the external binary or extractor truth\. |
| pdf\-content | 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | apple\-pdfkit\-text | 2026\-11\-16T02:20:26\.934Z | 0 full elapsed days | [evidence/pdf\-content\.txt](evidence/pdf-content.txt) | 9f161415aff717b6a740c0aeb377b7d3c8006fd580edf3ddc7e3742168f4054b | Text extraction only; reading order and visual layout not independently reviewed; no OCR\. |
| pdf\-text | 6b9131452cb1d4cfb8e7e066c7f7b8f6add4eb1c0e18de49aab9e9d3685aeeaa | apple\-pdfkit\-text | 2026\-11\-16T02:20:26\.934Z | 0 full elapsed days | [evidence/pdf\-text\.txt](evidence/pdf-text.txt) | 9f161415aff717b6a740c0aeb377b7d3c8006fd580edf3ddc7e3742168f4054b | Text extraction only; reading order and visual layout not independently reviewed; no OCR\. |
| image\-only\-provenance | 36fb4ff15bba710c153ff3f38c75fc418defec09728c8cfc3af51b5bc479fc28 | apple\-pdfkit\-text | 2026\-11\-16T02:20:26\.934Z | 0 full elapsed days | [evidence/image\-only\-provenance\.json](evidence/image-only-provenance.json) | 9a1539567e4c016e1c9242a0a1e445aac4ac720ad2d57686843a8edab9b51a07 | No text layer extracted; visual/OCR capability still required\. Empty extraction is not empty source content\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
