# Khách hàng Ánh Dương &lt;script&gt;bad&lt;/script&gt; &amp; &quot;Team&quot; — Content Search Audit

Partial.

## Source age reference

Age reference: 2026\-11\-16T00:45:06\.985Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.


## Scope and coverage

Counts use unique owned content, not repeated placeholder rows\. Completion concerns audit coverage, not whether content is defect\-free\. Discovery completeness is a declared scope assertion\.

| Metric | Value |
| --- | --- |
| Campaign | 992e1984\-5e9e\-4c1a\-8554\-30151a72e453 |
| Declared items | 1 |
| Owned/attempted | 1 |
| Collected | 1 |
| Audited | 0 |
| Inventory complete | true |
| Mode | full |
| Unresolved items | 1 |
| Missing checks | 0 |
| Pending queue | 0 |
| Global rules unresolved | portfolio\-task\-gaps, portfolio\-duplication, portfolio\-contradictions, portfolio\-journey\-links |
| pending | 1 |
| audited | 0 |
| failed | 0 |
| blocked | 0 |
| unsupported | 0 |
| excluded | 0 |

## Dimension coverage

Supplied checks only; missing checks are reported separately\. No combined SEO/GEO score is calculated\.

| Dimension | Supplied | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 0 | 8 | 0 |
| aio | 3 | 0 | 3 | 0 |
| aeo | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |

## Global portfolio review

Attributed judgments remain subject to domain review\. Evidence hashes and valid references do not certify semantic truth or reviewer identity\.

| Rule | Status | Reason | Reviewer | Reviewed | Applicability reason |
| --- | --- | --- | --- | --- | --- |
| portfolio\-task\-gaps | unknown | Synthetic branding trial has no semantic assessment | fixture author | 2026\-11\-16T00:45:06\.845Z |  |
| portfolio\-duplication | unknown | Synthetic branding trial has no semantic assessment | fixture author | 2026\-11\-16T00:45:06\.845Z |  |
| portfolio\-contradictions | unknown | Synthetic branding trial has no semantic assessment | fixture author | 2026\-11\-16T00:45:06\.845Z |  |
| portfolio\-journey\-links | unknown | Synthetic branding trial has no semantic assessment | fixture author | 2026\-11\-16T00:45:06\.845Z |  |

## Priority backlog

Ordered by severity, then global findings and partition order\. Confidence is separate\. Each finding retains its scope; potentially overlapping findings are not silently merged\. Proposed actions are not executed\.

| Scope / finding | Severity | Confidence | Classification | Observation | Affected items | Recommendation | Action | Action origin | Action reason | Verification | Owner role | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Finding interpretation

0 local findings; 0 global findings\. Zero findings does not resolve unknown checks or demonstrate measured search visibility\.


## Evidence and partition reports

Evidence identifiers are scoped by partition\. Links resolve to the original validated snapshots; keep source campaign and receipt with this report when sharing\. Raw bodies are not embedded here\.

| Partition / evidence | Item | Kind | Captured | Age at report time | SHA\-256 | Artifact |
| --- | --- | --- | --- | --- | --- | --- |
| [parts/000001](../campaign/parts/000001/report.md) |  | Partition report |  |  |  |  |
| parts/000001:7cb1221f995ee2bbb5ba683115fe379ce92efb8376239393be5ec77e6daa0783 | 0ccdf43a98e32778985e94e16eb9b43626540914eb2bedca086ca5da6e42ea0d | content | 2026\-11\-16T00:45:06\.738Z | 0 full elapsed days | a811a8c8ea71b5bb1317bc3076c6233c257024341e7f4228346334c881e42c76 | [evidence/0ccdf43a98e32778985e94e16eb9b43626540914eb2bedca086ca5da6e42ea0d\.txt](../campaign/parts/000001/evidence/0ccdf43a98e32778985e94e16eb9b43626540914eb2bedca086ca5da6e42ea0d.txt) |

## Global context evidence

Context values and review source references are preserved in the linked receipt\. Validate its bound source before interpreting judgments\.

| Evidence | Kind | Locator | Collected | Age at report time | SHA\-256 | Receipt |
| --- | --- | --- | --- | --- | --- | --- |

## Remaining work

Resolve these queues and unknown checks before claiming full coverage\. Empty queues alone do not resolve unknown checks\.

| Kind | Item | Reason |
| --- | --- | --- |

## Measurements and interpretation

No visibility metrics are inferred or pooled by this report\. Consult explicitly supplied, dated, surface\-specific measurements in the underlying evidence\. Readiness is not measured mentions, citations, ranking or revenue; missing observations are unknown, not zero\.


## Visibility measurement status

SYNTHETIC FIXTURE DATA — not live visibility


## Visibility observations



| Engine | Surface | Model | Search | Locale/market | Cohort | Dates | Mention | Citation | Capture errors | Unknown mention/citation |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| fixture | api | unknown | enabled | vi\-VN/VN | accuracy@1 | 2026\-11\-15T23:35:23\.819Z – 2026\-11\-15T23:35:23\.819Z | Unavailable \(0 reviewed responses\) | Unavailable \(0 reviewed responses\) | 0 | 1/1 |

## Adjudicated AI\-answer accuracy



| Segment | Claim accuracy | Fully reviewed response accuracy | Unknown claims | Reviewed/unreviewed responses | Incomplete/empty/unresolved inventories |
| --- | --- | --- | --- | --- | --- |
| \[&quot;fixture&quot;,&quot;api&quot;,&quot;unknown&quot;,&quot;enabled&quot;,&quot;vi\-VN&quot;,&quot;VN&quot;,&quot;accuracy&quot;,&quot;1&quot;\] | 1/2 \(50\.0%\) | 0/1 \(0\.0%\) | 0 | 1/0 | 0/0/0 |

## Accuracy denominator

Claim accuracy uses correct/\(correct\+incorrect\) supplied material\-claim judgments; unknown claims are excluded and disclosed\. Response accuracy includes only complete, nonempty claim inventories without unknown verdicts; all claims must be correct\. Missing reviews and zero denominators are unavailable, never perfect\. These are reviewer assertions, not automatic fact checks or population estimates; inventory exclusion counts can overlap\.


## Measurement denominator

Captured responses with supplied non\-null annotations within each segment; capture errors and unknown annotations are disclosed separately\. Citation means at least one exact authorized brand\-host citation in a response, not share of all citations\.


## Measurement limitations

Artifact hashes verify supplied bytes, not capture authenticity or annotation correctness; Accuracy uses supplied material\-claim judgments, not automatic fact checking or population accuracy; no cross\-period uplift, causal attribution or market\-wide estimate is inferred; Only supplied exact brand hosts count; subdomains must be explicitly listed


## AI observation evidence



| Artifact |
| --- |
| [ai\-observation\-evidence\.json](ai-observation-evidence.json) |
| [ai\-observations\.jsonl](ai-observations.jsonl) |

## Search Console measurement interpretation

Supplied exports are separate from audit coverage and AI visibility\. No cross\-query totals or causal uplift are calculated\. Pagination exhaustion does not prove complete population coverage\. Missing rows are not zeros\. Hashes bind supplied data; they do not authenticate Google as its source\.


## Search Console export



| Field | Value |
| --- | --- |
| Source | gsc\-fixture |
| Property | sc\-domain:example\.com |
| Locator | &lt;script&gt;supplied locator&lt;/script&gt; |
| Captured | 2026\-11\-16T00:00:00Z |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Query and filters | \{&quot;aggregationType&quot;:&quot;auto&quot;,&quot;dataState&quot;:&quot;final&quot;,&quot;dimensions&quot;:\[&quot;page&quot;\],&quot;endDate&quot;:&quot;2026\-10\-31&quot;,&quot;startDate&quot;:&quot;2026\-10\-01&quot;,&quot;type&quot;:&quot;web&quot;\} |
| Query hash | d7e65e3023c73f84c7fac1ff23c359cd91a2ff3531a07e870c6a9aab3ec35bb0 |
| Date timezone | America/Los\_Angeles |
| Supplied rows | 1 |
| Pagination exhausted | No — more pages required |
| Population complete | Not established |
| Pending work | Last page reached its row limit; another response page is required |
| Evidence bundle | [search\-console\-evidence\.json](search-console-evidence.json) |

## Search Console response provenance



| Source | Page | Rows | Aggregation | Freshness metadata | Response SHA\-256 |
| --- | --- | --- | --- | --- | --- |
| gsc\-fixture | 0 | 1 | byPage | null | cb082782608169a4a175127c5e62f2ba6cb5702d310a2878e7fe24d63c45c25e |

## Analytics measurement interpretation

GA4 observations remain separate from Search Console, AI visibility and audit coverage\. No cross\-row or cross\-query totals, conversion attribution or causal uplift are inferred\. Original metric strings/types and provider aggregates are retained in the evidence bundle\. Pagination exhaustion does not establish complete tracking; missing metadata and rows remain unknown\.


## GA4 export



| Field | Value |
| --- | --- |
| Provider/source | google\-analytics\-data\-api/ga4\-fixture |
| Property | properties/123 |
| Locator | &lt;script&gt;analytics fixture&lt;/script&gt; |
| Captured | 2026\-11\-16T00:00:00Z |
| Data label | SYNTHETIC FIXTURE DATA — not live analytics |
| Query and filters | \{&quot;dateRanges&quot;:\[\{&quot;startDate&quot;:&quot;2026\-10\-01&quot;,&quot;endDate&quot;:&quot;2026\-10\-31&quot;\}\],&quot;dimensions&quot;:\[\{&quot;name&quot;:&quot;pagePath&quot;\}\],&quot;metrics&quot;:\[\{&quot;name&quot;:&quot;activeUsers&quot;\}\]\} |
| Query hash | b40e3f0dd4201269b9053cb7cb3be52ff0c44de258168c5da4c307d87c871e7d |
| Supplied rows | 1 |
| Pagination exhausted | Yes |
| Population complete | Not established |
| Pending work | None for supplied pagination; tracking limitations remain |
| Evidence bundle | [analytics\-evidence\.json](analytics-evidence.json) |

## GA4 response provenance and limitations



| Source | Page | Rows / declared rows | Metric types | Provider metadata \(null = unknown\) | Response SHA\-256 |
| --- | --- | --- | --- | --- | --- |
| ga4\-fixture | 0 | 1 / 1 | \[\{&quot;name&quot;:&quot;activeUsers&quot;,&quot;type&quot;:&quot;TYPE\_INTEGER&quot;\}\] | \{&quot;subjectToThresholding&quot;:true,&quot;timeZone&quot;:&quot;Asia/Ho\_Chi\_Minh&quot;,&quot;currencyCode&quot;:&quot;VND&quot;,&quot;samplingMetadatas&quot;:\[\{&quot;samplesReadCount&quot;:&quot;10&quot;,&quot;samplingSpaceSize&quot;:&quot;100&quot;\}\]\} | 996618bd4c8ff0d106bbccdd8fba1acf665c47ba9bfc6b1fea720c61440ae6d0 |

## Bing measurement interpretation

Mapped dashboard data; source authenticity and mapping accuracy require independent review; Citations are not answer\-level mention rates, rankings, traffic, answer accuracy or causality; Grounding queries are sampled retrieval phrases, not necessarily original user prompts; Topic ecosystem values remain approximate; opportunity citation ranges have no computed midpoint; Supported surfaces and supplied period remain explicit; no whole\-AI\-ecosystem coverage is inferred


## Bing export



| Field | Value |
| --- | --- |
| Provider/source | bing\-webmaster/bing\-fixture |
| Kind | ai\-performance\-mapped |
| Site | https://example\.com |
| Locator | &lt;script&gt;Bing fixture&lt;/script&gt; |
| Captured | 2026\-11\-16T00:00:00Z |
| Data label | SYNTHETIC FIXTURE DATA — not live Bing performance |
| Scope | \{&quot;locale&quot;:&quot;unknown&quot;,&quot;market&quot;:&quot;unknown&quot;,&quot;timezone&quot;:&quot;unknown&quot;,&quot;period&quot;:&quot;2026\-10&quot;,&quot;surfaces&quot;:&quot;Bing supported AI surfaces&quot;\} |
| Mapping attribution | \{&quot;method&quot;:&quot;fixture mapping&quot;,&quot;reviewer&quot;:&quot;fixture reviewer&quot;,&quot;reviewedAt&quot;:&quot;2026\-11\-16T00:00:00Z&quot;\} |
| Rows | 1 |
| Population complete | Not established |
| Response SHA\-256 | ca37b6da08af47e77cc387fead243aab811da0be64e202d17c1b0e4c18b07004 |
| Original source SHA\-256 | 14431fa803c18e63f200d0598e91ab1b096a3dfa386eb7867a6c1b36bfc27427 |
| Evidence bundle | [bing\-evidence\.json](bing-evidence.json) |

## Bing AI measurement precision



| Source | Precision | Metric cells \(not citation totals\) |
| --- | --- | --- |
| bing\-fixture | exact | 0 |
| bing\-fixture | approximate | 0 |
| bing\-fixture | range | 1 |
| bing\-fixture | unknown | 1 |

## Server\-log interpretation

Counts are accepted request lines, not sessions, people, unique visits or verified crawlers; Identical lines without request IDs remain separate observations; source rotation/overlap must be reviewed; User\-Agent is an unverified claim; no DNS/IP/bot authentication is performed; Requests/status codes do not prove indexing, content rendering, AI citation or answer accuracy; Scope, normalization and redaction are supplied assertions; source hashes do not authenticate the server


## Server\-log export



| Field | Value |
| --- | --- |
| Source | logs\-fixture |
| Locator | &lt;script&gt;log fixture&lt;/script&gt; |
| Captured | 2026\-11\-16T01:00:00Z |
| Data label | SYNTHETIC FIXTURE DATA — not live access logs |
| Scope | \{&quot;from&quot;:&quot;2026\-11\-16T00:00:00Z&quot;,&quot;to&quot;:&quot;2026\-11\-16T01:00:00Z&quot;,&quot;system&quot;:&quot;fixture&quot;,&quot;filters&quot;:&quot;none&quot;,&quot;exportComplete&quot;:true\} |
| Normalization/redaction | \{&quot;method&quot;:&quot;fixture JSONL&quot;,&quot;reviewer&quot;:&quot;fixture reviewer&quot;,&quot;redaction&quot;:&quot;no IPs or headers&quot;,&quot;limitations&quot;:\[&quot;synthetic&quot;\]\} |
| Accepted request lines | 1 |
| Rejected lines | 1 |
| Unknown status | 0 |
| Supplied export fully parsed | No — unresolved input |
| Source SHA\-256 | 66f411b7daa06ddfe99779fbff73b6286bf7f8b44098598f16214deedb7b5ef3 |
| Evidence bundle | [server\-log\-evidence\.json](server-log-evidence.json) |

## Server\-log pending work



| Source | Kind | Line | Reason |
| --- | --- | --- | --- |
| logs\-fixture | server\-log\-row | 2 | Unexpected token &\#39;i&\#39;, &quot;invalid fixture line&quot; is not valid JSON |

## Measurement source ages

As of 2026\-11\-16T00:45:06\.985Z; export/capture/review ages do not replace the underlying observation window\.

| Bundle | Source / observation | Date role | Date | Age at report time |
| --- | --- | --- | --- | --- |
| ai\-observation\-evidence\.json | one | Response captured | 2026\-11\-15T23:35:23\.819567\+00:00 | 0 full elapsed days |
| ai\-observation\-evidence\.json | one | Accuracy review | 2026\-11\-15T23:35:23\.819567\+00:00 | 0 full elapsed days |
| ai\-observation\-evidence\.json | one/seats/policy | Claim source captured | 2026\-11\-15T23:35:23\.819567\+00:00 | 0 full elapsed days |
| ai\-observation\-evidence\.json | one/export/policy | Claim source captured | 2026\-11\-15T23:35:23\.819567\+00:00 | 0 full elapsed days |
| search\-console\-evidence\.json | gsc\-fixture | Export captured | 2026\-11\-16T00:00:00Z | 0 full elapsed days |
| analytics\-evidence\.json | ga4\-fixture | Export captured | 2026\-11\-16T00:00:00Z | 0 full elapsed days |
| bing\-evidence\.json | bing\-fixture | Export captured | 2026\-11\-16T00:00:00Z | 0 full elapsed days |
| server\-log\-evidence\.json | logs\-fixture | Export captured | 2026\-11\-16T01:00:00Z | Unavailable: source date is after report time |

## Rule provenance

Sources and review dates belong to the validated packaged rule registry; they do not certify current search outcomes\.

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve missing local/global evidence, complete declared discovery, apply new immutable reviews and regenerate this report\. The current audit is partial\.

