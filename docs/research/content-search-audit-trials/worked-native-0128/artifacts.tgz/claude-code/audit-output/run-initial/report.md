# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:49:45\.451Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 4cf706d9\-b958\-48e2\-a2df\-236188d9a80e\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | local\-file | 2026\-11\-16T13:49:45\.434Z | 0 full elapsed days | [evidence/480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f\.txt](evidence/480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:49:45\.435Z | 0 full elapsed days | [evidence/4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef\.txt](evidence/4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | local\-file | 2026\-11\-16T13:49:45\.435Z | 0 full elapsed days | [evidence/5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f\.txt](evidence/5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a | f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | local\-file | 2026\-11\-16T13:49:45\.436Z | 0 full elapsed days | [evidence/f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8\.txt](evidence/f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
