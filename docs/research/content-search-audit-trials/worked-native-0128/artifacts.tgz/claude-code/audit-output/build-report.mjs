// Renders report.md with source quotations pulled directly from the target files,
// then writes the quote ledger for verify-quotes. Refuses to overwrite an existing report.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2]);
const out = path.join(root, "audit-output");
const reportPath = path.join(root, "report.md");
if (existsSync(reportPath)) throw new Error("report.md already exists");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const validation = JSON.parse(
  readFileSync(path.join(out, "validation.json"), "utf8"),
);
const cov = JSON.parse(
  readFileSync(path.join(out, "run-reviewed/coverage.json"), "utf8"),
);
const run = JSON.parse(readFileSync(path.join(out, "run-reviewed/run.json"), "utf8"));
const checks = readFileSync(path.join(out, "run-reviewed/checks.jsonl"), "utf8")
  .trim()
  .split("\n")
  .map((l) => JSON.parse(l));
const inventory = readFileSync(path.join(out, "run-reviewed/inventory.jsonl"), "utf8")
  .trim()
  .split("\n")
  .map((l) => JSON.parse(l));
const tally = { pass: 0, fail: 0, unknown: 0, "not-applicable": 0 };
for (const c of checks) tally[c.status] = (tally[c.status] ?? 0) + 1;

const files = {
  "01": "01-competitor-claims.md",
  "02": "02-measurement-windows.md",
  "03": "03-template-service-area.md",
  "04": "04-editorial-proof.md",
  ctx: "context.md",
};
const sources = {};
for (const [k, name] of Object.entries(files)) {
  const bytes = readFileSync(path.join(root, "targets", name));
  sources[k] = { name, hash: hash(bytes), lines: bytes.toString("utf8").split("\n") };
}
const ledger = [];
function Q(key, start, end = start) {
  const s = sources[key];
  const quote = s.lines.slice(start - 1, end).join(" ");
  const loc = start === end ? `${s.name}:${start}` : `${s.name}:${start}-${end}`;
  ledger.push({ key, start, end, quote });
  return `> ${quote} — \`${loc}\``;
}
const perItem = (key) => {
  const item = inventory.find((i) => path.basename(i.path) === files[key]);
  const mine = checks.filter((c) => c.itemId === item.itemId);
  const n = (s) => mine.filter((c) => c.status === s).length;
  return `${item.state} | ${n("fail")} | ${n("pass")} | ${n("unknown")}`;
};
const dim = (d) => {
  const x = cov.dimensions[d];
  return `${x.total} | ${x.completed} | ${x.unknown} | ${x.notApplicable}`;
};

const report = `# Content search audit — four synthetic dossiers

**Status: partial.** This is an offline, evidence-bounded review of four synthetic dossiers, not a full campaign and not a completed audit. The validator reports \`valid: ${validation.valid}\`, \`completionAllowed: ${validation.completionAllowed}\`.

## 1. Scope

- Declared scope: the four numbered dossiers in \`targets/\`, audited as four separate scenarios under \`targets/context.md\`. \`context.md\` is scope context, not a dossier, and is not in the denominator. \`reference-example/worked-review.mjs\` is not a target and is not in the denominator.
- Every organization, price, policy, metric and observation is synthetic. Owner-approved records are used as comparison evidence inside their own scenario only. Nothing here is independently verified live behavior.
- Evidence surface obtained: local Markdown text only. No URL was fetched, no account or credential was accessed, no target or installed skill was modified, and no tool was installed.
- Governing scope statements:

${Q("ctx", 3, 7)}

${Q("ctx", 10, 12)}

- "Inventory complete" in the run configuration means all four declared dossiers were enumerated. It does not mean the pages those dossiers describe were supplied in full. Only dossier 03 declares its own page inventory complete.

## 2. Validated coverage

Counts below are copied from the validated run revision (\`audit-output/run-reviewed/coverage.json\`, run \`${run.runId}\`), not from files read.

| Measure | Count |
| --- | --- |
| Declared items | ${cov.total} |
| In scope | ${cov.inScope} |
| Fully audited | ${cov.audited} |
| Pending | ${cov.states.pending} |
| Failed collection | ${cov.states.failed} |
| Blocked | ${cov.states.blocked} |
| Unsupported | ${cov.states.unsupported} |
| Excluded | ${cov.states.excluded} |
| Planned checks | ${checks.length} |
| Checks resolved as fail | ${tally.fail} |
| Checks resolved as pass | ${tally.pass} |
| Checks unknown | ${tally.unknown} |
| Missing checks | ${cov.missingChecks.length} |
| Material findings | 6 |

All four dossiers were collected and read in full, and all four remain **pending**: each still has required checks that the supplied evidence cannot resolve. Reading a dossier is not the same as fully auditing it.

| Dimension | Planned checks | Resolved | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| Content quality | ${dim("quality")} |
| SEO | ${dim("seo")} |
| AIO (AI search optimization) | ${dim("aio")} |
| AEO | ${dim("aeo")} |
| GEO | ${dim("geo")} |
| Portfolio | ${dim("portfolio")} |

AIO here means AI search optimization generally, not the Google product AI Overviews.

## 3. Dossier accounting

| Dossier | State | Failed checks | Passed checks | Unknown checks | Findings | Clean components |
| --- | --- | --- | --- | --- | --- | --- |
| \`01-competitor-claims.md\` | ${perItem("01")} | F1, F2 | /monthly-comparison caption |
| \`02-measurement-windows.md\` | ${perItem("02")} | F3, F4 | Verified-window caption; the count of 15 identified-referrer sessions |
| \`03-template-service-area.md\` | ${perItem("03")} | F5 | /north-delivery; /terms-v1 archive; retention of both regional pages |
| \`04-editorial-proof.md\` | ${perItem("04")} | F6 | Permissions FAQ; /status-codes (owner-attested, see section 6) |

A failed check is a resolved check. Each dossier is an aggregate of several components, so a failed item-level check does not make its clean components defective.

## 4. Material findings

Six findings, each consolidated across the dimensions it touches. Severity reflects the supplied evidence only. No ranking, traffic or citation effect is forecast.

### F1 — /compare assertion A denies Fir SSO against the supplied Fir SSO documentation

- Scenario and item: dossier 01, draft /compare, assertion A. Dimensions: content quality, AEO, AIO. Severity high, confidence high, observed.
- Draft claim:

${Q("01", 17)}

- Supplied record:

${Q("01", 12, 14)}

- Rationale: the supplied Fir SSO documentation states that SSO exists on one Fir plan under a seat condition, which contradicts a blanket denial. The pricing-table excerpt not mentioning SSO is an absence of mention, not proof of absence. For Fir's other plans the status is unknown rather than negative.
- Proposed action (recommendation only): remove the denial and the pricing-table proof wording. If SSO is mentioned at all, state only what the supplied documentation says, with its plan and seat-minimum conditions and the November 2026 US scope. Make no statement about Fir's other plans or about Cedar SSO; no record was supplied for either.
- Verification: re-read the revised assertion against the supplied SSO record above and confirm it does not deny Fir SSO, does not cite the pricing table as proof, and asserts nothing for plans lacking a supplied statement.

### F2 — /compare assertion B claims Cedar is cheaper on every billing option; the annual figures show the reverse

- Scenario and item: dossier 01, draft /compare, assertion B. Dimensions: content quality, AEO, AIO. Severity high, confidence high, observed.
- Draft claim:

${Q("01", 18)}

- Supplied records:

${Q("01", 6)}

${Q("01", 7)}

${Q("01", 8)}

${Q("01", 9)}

- Rationale: on monthly billing Cedar is lower (12 against 15). On annual billing Cedar is higher (10 against 9 per seat per month equivalent). The universal claim therefore fails on one of the two supplied billing options. Arithmetic checked with Node: 15 − 12 = 3 and 10 − 9 = 1.
- Proposed action: limit assertion B to monthly billing, and either omit annual billing or state that on the supplied annual options Fir is USD 1 less per seat per month equivalent. Keep the November 2026, US, USD before-tax and billing-period qualifiers. The clean /monthly-comparison caption (section 5) already shows acceptable scoping.
- Verification: recompute each billing option from the four price lines above and confirm every comparative statement holds for the billing period it names.

### F3 — Draft A divides full-month spend by one week of conversions and calls it October cost per conversion

- Scenario and item: dossier 02, Draft A. Dimension: content quality (measurement claim). Severity medium, confidence high, observed.
- Draft claim:

${Q("02", 10)}

- Supplied records:

${Q("02", 5)}

${Q("02", 6)}

${Q("02", 7)}

- Rationale: the division itself is arithmetically right (3000 ÷ 35 = 85.714…, checked with Node), but the numerator covers October 1–31 and the denominator covers October 1–7. Conversions for October 8–31 are missing, not zero, so the figure is not an October cost per conversion. The true full-month value is unknown; this audit does not estimate it.
- Proposed action: withdraw the USD 85.71 October figure. Report only the matched window, as the existing verified-window caption does, and state that October 8–31 is unmeasured. A full-October figure requires a conversion export covering October 8–31.
- Verification: confirm that numerator and denominator of any revised metric cover the same dates, campaign and currency, and that the unmeasured period is stated rather than treated as zero.

### F4 — Draft B claims proof of 150 AI-assistant sessions from 15 tracked sessions

- Scenario and item: dossier 02, Draft B. Dimension persisted: content quality. It is GEO-relevant as a measurement claim, but no GEO check can resolve without AI observations. Severity medium, confidence high, observed.
- Draft claim:

${Q("02", 17, 18)}

- Supplied record:

${Q("02", 14, 16)}

- Rationale: the supplied record supports exactly one descriptive fact, the 15 sessions with an identified AI-assistant referrer. The one-in-ten tracking rate, the total of 150 and the word for proof have no supplied basis: the record itself says no model of untracked influence and no complete session count exists. Unknown-origin sessions are neither AI sessions nor non-AI sessions.
- Proposed action: replace Draft B with the supported descriptive statement only (15 October sessions with an identified AI-assistant referrer; other sessions of unknown origin). Remove the total, the rate and the proof wording. Do not link these sessions to the campaign conversion counts, per the dossier's own instruction:

${Q("02", 20, 21)}

- Verification: check the revised sentence against the referral record above: only the 15 identified sessions are stated, unknown-origin sessions are not reclassified, and no conversion linkage is implied.

### F5 — /south-delivery promises same-day delivery; the approved policy is next-business-day only

- Scenario and item: dossier 03, page /south-delivery. Dimensions: content quality, AEO, AIO, portfolio. One issue, one finding. Severity high, confidence high, observed.
- Page passage:

${Q("03", 10, 11)}

- Approved policy:

${Q("03", 4, 5)}

- Rationale: the South page passage repeats the North terms and contradicts the current approved South policy. A customer or an answer engine reading the page would get the wrong service level for South. Why the passage is wrong (template carry-over or stale 2024 copy) is not established and is not asserted.
- Proposed action: replace the /south-delivery policy passage so that it states next-business-day delivery only. The approved policy supplies no South order cutoff or day-of-week condition, so obtain those from the policy owner before adding any; do not carry over the North 10:00 cutoff. Leave /north-delivery and /terms-v1 unchanged and keep both regional pages.
- Verification: compare the revised South passage with the approved policy above and confirm /north-delivery still matches. Live page, index and engine behavior stay unverified by this check.

### F6 — Landing-page draft guarantees 10-minute setup for every team

- Scenario and item: dossier 04, draft landing-page claim. Dimensions: content quality, AEO. Severity high, confidence high, observed.
- Draft claim:

${Q("04", 6)}

- Approved record:

${Q("04", 3, 5)}

- Rationale: three parts of the claim exceed the record. The record covers 20 observed sessions, not all teams. It reports a median, so by definition some sessions took longer, and it supplies no maximum or guarantee. The median is 15 minutes, not 10.
- Proposed action: replace the claim with the supported descriptive result (proposed wording, not a quotation: *In a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes.*). Do not state a guarantee, a maximum or a result for all teams unless the owner supplies a guarantee policy and supporting data.
- Verification: compare the revised claim with the approved record above for sample size, statistic, duration and absence of guarantee or universal wording.

## 5. Clean cases

These components were assessed and are supported by the supplied evidence. No finding is raised and no change is proposed.

**Dossier 01 — /monthly-comparison caption.** Scoped to the supplied monthly plans, per seat, before tax; 15 − 12 = 3 matches the price records quoted under F2. The owner's intended scope is narrow and the caption stays inside it.

${Q("01", 21)}

${Q("01", 22, 24)}

**Dossier 02 — verified-window caption.** Numerator and denominator share the October 1–7 window (700 ÷ 35 = 20, checked with Node) and the caption discloses the unmeasured remainder.

${Q("02", 11, 12)}

${Q("02", 8)}

**Dossier 02 — referral count.** The 15 identified-referrer sessions are a supported descriptive figure (quoted under F4). The absence of a model or incrementality test limits generalization and attribution; it does not make the count wrong.

**Dossier 03 — /north-delivery.** Matches the approved North policy quoted under F5. The second sentence follows from the stated window.

${Q("03", 8, 9)}

**Dossier 03 — /terms-v1 and shared layout.** A labeled, accurate 2024 archive is a legitimate version variant, not a contradiction with current policy. Two pages for two regions with an intentional shared layout is not a duplication defect, and no consolidation is proposed. The persisted portfolio-duplication check passes on this basis.

${Q("03", 13, 16)}

${Q("03", 18, 20)}

**Dossier 04 — permissions FAQ.** The answer names the permitted role directly and matches the approved policy; no extra conditions are needed for this question.

${Q("04", 9)}

${Q("04", 10, 13)}

**Dossier 04 — /status-codes.** No defect is raised. Terse style and the absence of a purchase call to action are owner-approved, and authorship is not inferred from style.

${Q("04", 15, 19)}

## 6. Uncertain or unresolved cases

These are unknowns, not defects and not zeros.

- Dossier 01: SSO status of Fir plans other than Enterprise, and of Cedar, is not supplied. Live prices were not verified. Conversion and engine observations are absent.
- Dossier 02: conversions for October 8–31 and therefore full-October cost per conversion are unmeasured. Total AI-assistant-originated sessions are unknown; the complete session count is not supplied.
- Dossier 03: any South order cutoff or day-of-week condition is not in the approved policy. Whether the two regional pages compete for the same queries cannot be assessed without query/page data; cannibalization is neither confirmed nor implied. The cause of the South error is not established, so the freshness check stays unknown.
- Dossier 04: the /status-codes table is clean by owner attestation only. Its content was not supplied, so its accuracy was not independently checked. The study's date and population are not supplied.
- All dossiers: quality-freshness is recorded as an explicit unknown. Task fit, metadata, retrievable facts, question coverage and answer context stay unknown because no audience context or real question set was supplied for the whole item, and hypothetical questions were not invented to force a verdict.

## 7. Missing measurements and coverage limits

- **GEO (${cov.dimensions.geo.unknown} of ${cov.dimensions.geo.total} checks unknown):** no AI response captures, citation annotations, mentions or prompt cohorts were supplied. Mention rate, citation rate and answer accuracy are unavailable, not zero. The dossier 02 referral count is a web-analytics figure, not an AI observation.
- **SEO (${cov.dimensions.seo.unknown} of ${cov.dimensions.seo.total} checks unknown):** no HTTP responses, index directives, canonical targets, metadata, link graph, structured data, locale map or rendered DOM were supplied. No rankings, keyword volume or index evidence exists.
- **AIO (${cov.dimensions.aio.unknown} of ${cov.dimensions.aio.total} unknown):** no crawler policy or publisher intent was supplied. Entity consistency was resolved only for dossiers 01 and 03, where a supplied record exists.
- **AEO (${cov.dimensions.aeo.unknown} of ${cov.dimensions.aeo.total} unknown):** answer evidence was resolved for dossiers 01, 03 and 04; question coverage and answer context need a real question set.
- **Portfolio (${cov.dimensions.portfolio.unknown} of ${cov.dimensions.portfolio.total} unknown):** resolved only for dossier 03, the one scenario with a declared complete page inventory. Dossiers are separate scenarios, so no cross-dossier comparison was made.
- **Content quality (${cov.dimensions.quality.unknown} of ${cov.dimensions.quality.total} unknown):** claims and non-empty text extraction resolved for all four; task fit, freshness and media remain unknown.
- No Search Console, GA4, Bing, server-log or AI-observation export was imported, because none was supplied.
- No overall score is given.

## 8. Report verification

- Every source quotation in this report appears on a blockquote line with a \`file:line\` locator. Quotations were generated from the target files and checked with the skill's quote verifier; the receipt is \`audit-output/quote-receipt.json\`. Multi-line quotations use whitespace normalization for line wraps only. Text labelled as proposed wording is not a quotation.
- The receipt covers the submitted spans. It does not certify that a quotation supports a finding; that judgment is the reviewer's.
- Derived quantities (3000 ÷ 35, 700 ÷ 35, 15 − 12, 10 − 9) were computed with Node.
- Artifact validation checks structure and evidence bindings, not the truth of semantic judgments.

## 9. Recovery path

To move any dossier from pending to audited, supply: full page text and metadata for each described page; HTTP response, index-directive, canonical, link-graph, structured-data, locale and rendered-DOM captures; crawler policy and publisher intent; audience context and a real question set; dated AI response observations with cohort metadata; and for dossier 02 a conversion export covering October 8–31. Then resume from \`audit-output/run-reviewed\`.

## 10. Artifacts

- \`audit-output/run-initial/\` — inventory run before review.
- \`audit-output/run-reviewed/\` — reviewed revision: inventory, evidence, checks, findings, coverage, helper-rendered report and action CSV.
- \`audit-output/review.json\`, \`audit-output/validation.json\`, \`audit-output/quotes.json\`, \`audit-output/quote-receipt.json\`.
`;

writeFileSync(reportPath, report, { flag: "wx" });
const lines = report.split("\n");
const quoteLines = lines
  .map((text, i) => ({ text, n: i + 1 }))
  .filter((l) => l.text.startsWith("> "));
if (quoteLines.length !== ledger.length)
  throw new Error(`Blockquote/ledger mismatch ${quoteLines.length}/${ledger.length}`);
const quotes = ledger.map((q, i) => {
  const s = sources[q.key];
  if (!quoteLines[i].text.includes(q.quote)) throw new Error("Order mismatch");
  return {
    quoteId: `Q${String(i + 1).padStart(2, "0")}-${q.key}-${q.start}`,
    source: `targets/${s.name}`,
    sourceLabel: s.name,
    sourceHash: s.hash,
    startLine: q.start,
    endLine: q.end,
    reportStartLine: quoteLines[i].n,
    reportEndLine: quoteLines[i].n,
    normalization: q.start === q.end ? "exact" : "whitespace",
    quote: q.quote,
  };
});
writeFileSync(
  path.join(out, "quotes.json"),
  JSON.stringify({ root, report: "report.md", reportHash: hash(report), quotes }, null, 2) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, reportLines: lines.length }));
