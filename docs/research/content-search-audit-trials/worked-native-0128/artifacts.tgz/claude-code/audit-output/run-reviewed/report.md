# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:52:14\.326Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run bec3f9d2\-4564\-4771\-9a77\-db59a9441d37\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1\-fir\-sso\-denial | /compare assertion A denies Fir SSO against the supplied Fir SSO documentation | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | update | reviewer\-proposal | The supplied SSO documentation directly contradicts the draft assertion and a pricing\-table omission is not proof of absence\. | Remove the denial and the pricing\-table proof wording from /compare assertion A\. If SSO is mentioned, state only what the supplied Fir SSO documentation says: SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats \(current November 2026 US scope\)\. Make no statement about Fir&\#39;s other plans or about Cedar SSO, because no record was supplied for either\. | Re\-read the revised assertion against 01\-competitor\-claims\.md:12\-14 and confirm it neither denies Fir SSO, cites the pricing table as proof, nor asserts SSO status for plans without a supplied statement\. This audit does not authorize changing the content\. | Content owner | small | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747, claims\-01, entity\-01 |
| F2\-every\-billing\-option | /compare assertion B claims Cedar is cheaper on every billing option; the annual figures show the reverse | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | update | reviewer\-proposal | The supplied annual prices \(Cedar USD 10, Fir USD 9 per seat per month equivalent\) contradict the universal claim\. | Limit assertion B to monthly billing, where Cedar is USD 12 and Fir USD 15 per seat per month, and either omit annual billing or state that on the supplied annual options Fir is USD 1 less per seat per month equivalent\. Keep the November 2026, US, USD before\-tax and billing\-period qualifiers\. The existing /monthly\-comparison caption already shows acceptable scope\. | Recompute each billing option from 01\-competitor\-claims\.md:6\-9 and confirm every comparative statement holds for the billing period it names\. | Content owner | small | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747, claims\-01, entity\-01 |
| F5\-south\-same\-day | /south\-delivery promises same\-day delivery; approved policy is next\-business\-day only | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency, portfolio\-contradictions | quality, aeo, aio, portfolio | high | high | observed | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | update | reviewer\-proposal | The current South page passage repeats the North terms and contradicts the current approved South policy\. | Replace the /south\-delivery policy passage so it states that South serves next\-business\-day delivery only\. The approved policy supplies no South order cutoff or day\-of\-week condition, so obtain those from the policy owner before adding any; do not carry over the North 10:00 cutoff\. Keep /north\-delivery and /terms\-v1 unchanged and keep both regional pages\. | Compare the revised /south\-delivery passage with 03\-template\-service\-area\.md:4\-5 and confirm /north\-delivery still matches\. Live page, index and engine behavior remain unverified by this check\. | Content owner | small | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, claims\-03, entity\-03, inventory\-map\-03 |
| F6\-setup\-guarantee | Landing\-page draft guarantees 10\-minute setup for every team; the record supports only a 15\-minute median over 20 sessions | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | update | reviewer\-proposal | The universal scope, the guarantee and the 10\-minute figure each exceed the approved product record\. | Replace the draft claim with the supported descriptive result: in a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes\. Do not state a guarantee, a maximum, or a result for all teams unless the owner supplies a guarantee policy and supporting data\. | Compare the revised claim with 04\-editorial\-proof\.md:3\-5 for sample size, statistic, duration and absence of guarantee or universal wording\. | Content owner | small | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a, claims\-04 |
| F3\-october\-cost\-window\-mismatch | Draft A divides full\-month spend by one week of conversions and labels it October cost per conversion | quality\-claims | quality | medium | high | observed | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | update | reviewer\-proposal | Numerator covers October 1\-31 and denominator October 1\-7; conversions for October 8\-31 are missing, not zero\. | Withdraw the USD 85\.71 October figure\. Report the matched window only, as the existing verified\-window caption does \(October 1\-7: USD 700 divided by 35 completed conversions is USD 20\), and state that October 8\-31 conversions are unmeasured\. A full\-October figure requires a conversion export covering October 8\-31\. | Confirm numerator and denominator in any revised metric cover the same dates, campaign and currency per 02\-measurement\-windows\.md:5\-8, and that the unmeasured period is stated rather than treated as zero\. | Analytics/reporting owner | small | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9, claims\-02 |
| F4\-ai\-sessions\-extrapolation | Draft B claims proof of 150 AI\-assistant sessions from 15 tracked sessions with an unsupported one\-in\-ten rate | quality\-claims | quality | medium | high | observed | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | update | reviewer\-proposal | No model of untracked AI influence, incrementality test or complete session count exists to support the multiplier or the proof claim\. | Replace Draft B with the supported descriptive statement: 15 October sessions have an identified AI\-assistant referrer and other sessions have unknown origin\. Remove the 150 total, the one\-in\-ten rate and the proof wording\. Do not link these sessions to the campaign conversion counts\. | Check the revised sentence against 02\-measurement\-windows\.md:14\-16 and 20\-21: only the 15 identified sessions are stated, unknown\-origin sessions are not counted as AI or as non\-AI, and no conversion linkage is implied\. | Analytics/reporting owner | small | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9, claims\-02 |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | pending | Snapshot review incomplete | 26 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | pending | Snapshot review incomplete | 26 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | pending | Snapshot review incomplete | 26 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-claims | quality | fail | Item\-wide verdict over four components\. Draft A \(line 10\) labels 3000/35 as October cost per conversion although conversions cover only October 1\-7 and October 8\-31 has no conversion data\. Draft B \(lines 17\-18\) asserts proof of 150 AI\-assistant sessions from 15 tracked sessions using a one\-in\-ten rate that no supplied model or complete session count supports\. The verified\-window caption \(lines 11\-12; 700/35 = 20, rest of month stated unmeasured\) is supported, and the count of 15 identified\-referrer sessions is a supported descriptive figure\. | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9, claims\-02 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-freshness | quality | unknown | Figures are scoped to a completed October 2026 window; no evidence about later restatement or export completeness beyond the stated windows was supplied\. | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9, claims\-02 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-02 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-claims | quality | fail | Item\-wide verdict over three declared pages\. /south\-delivery \(lines 10\-11\) promises same\-day delivery while the current approved policy \(lines 4\-5\) says South serves next\-business\-day delivery only\. /north\-delivery \(lines 8\-9\) matches the approved policy\. /terms\-v1 is an owner\-confirmed, clearly labeled and accurate 2024 archive and is not a defect\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, claims\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-freshness | quality | unknown | The /south\-delivery passage matches what the owner says was true under the 2024 contract, but whether it is stale copy or a template error is not established; the defect is recorded under quality\-claims\. /terms\-v1 is a labeled archive and /north\-delivery matches current policy\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, claims\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-entity\-consistency | aio | fail | The /south\-delivery service facts conflict with the approved South policy record; /north\-delivery is consistent with the North record\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, entity\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | aeo\-answer\-evidence | aeo | fail | The /south\-delivery passage answers the delivery\-speed question for South with a claim the approved policy contradicts\. The /north\-delivery answer is supported\. No question set was supplied, so coverage and context checks stay unknown\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, claims\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-duplication | portfolio | pass | The declared inventory is complete\. /north\-delivery and /south\-delivery serve different regions and the owner wants both retained; shared layout and generic contact wording are intentional; /terms\-v1 is a legitimate labeled version variant\. No query/page overlap or engine\-selection data exists, so cannibalization is neither confirmed nor implied\. The identical South policy passage is a factual error recorded under the contradiction finding, not a duplication defect, and no consolidation is proposed\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, inventory\-map\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-contradictions | portfolio | fail | Across the complete declared inventory, /south\-delivery carries the North service terms and contradicts the approved South record\. /terms\-v1 describing 2024 South same\-day service is a labeled historical version, not a contradiction, and /north\-delivery is consistent\. | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c, entity\-03, inventory\-map\-03 |
| 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-claims | quality | fail | Item\-wide verdict over three components\. /compare assertion A \(line 17\) denies Fir SSO and cites the pricing table as proof, while the supplied Fir SSO docs \(line 13\) state SAML SSO is available on Enterprise with a 20\-paid\-seat minimum\. /compare assertion B \(line 18\) claims Cedar is cheaper on every billing option, while the supplied annual figures are Cedar USD 10 versus Fir USD 9\. The /monthly\-comparison caption \(line 21\) is supported \(15 minus 12 is 3, monthly plans, before tax\) and stays clean\. | claims\-01, ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-freshness | quality | unknown | The owner states the records are current November 2026 US plans, but the date/market labelling carried by the /compare and /monthly\-comparison pages themselves is not supplied and no live pricing was verified\. | claims\-01, ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-01 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-entity\-consistency | aio | fail | Against the supplied plan/price/SSO record, /compare assertion A misstates Fir&\#39;s SSO availability and assertion B misstates the annual price relationship\. The monthly caption is consistent with the record\. | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747, entity\-01 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | aeo\-answer\-evidence | aeo | fail | Same two defects as quality\-claims: the comparative answer claims in /compare assertions A and B are contradicted by the supplied SSO documentation and annual prices\. The monthly caption&\#39;s answer claim is supported\. No question set was supplied, so question coverage and answer context stay unknown\. | claims\-01, ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-claims | quality | fail | Item\-wide verdict over three components\. The draft landing\-page claim \(line 6\) asserts a guarantee for every team at 10 minutes; the approved record \(lines 3\-5\) gives only a 15\-minute median over 20 observed sessions and supplies no guarantee, maximum or wider population estimate\. The permissions FAQ \(line 9\) matches the approved permissions policy exactly and stays clean\. The /status\-codes table is owner\-attested complete and accurate but its content was not supplied, so it is not independently verified and is not a defect\. | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a, claims\-04 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-freshness | quality | unknown | No dates or versions are supplied for the study, the permissions policy or the /status\-codes table\. | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a, claims\-04 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-04 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | aeo\-answer\-evidence | aeo | fail | The landing\-page setup\-time answer claim is unsupported by the approved product record\. The permissions FAQ answer is fully supported by the approved policy and needs no additional conditions\. | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a, claims\-04 |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |
| f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3d1bb110bb53a4f3baeb574c2ac7960dd09af1402bdc94c2f6347dd51dd09de9 | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | local\-file | 2026\-11\-16T13:49:45\.434Z | 0 full elapsed days | [evidence/480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f\.txt](evidence/480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cd6e220c389aa9839782561223b1323906db10f37c6f3b7d90fd1aac393d3f1c | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:49:45\.435Z | 0 full elapsed days | [evidence/4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef\.txt](evidence/4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ea58c1cc27086215665ee5de5fe7062e99eafe22736c7f8f25b6ad2768dc4747 | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | local\-file | 2026\-11\-16T13:49:45\.435Z | 0 full elapsed days | [evidence/5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f\.txt](evidence/5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 057b591f4d9055871e8d5c0aef06a9f9bf4a3a35ea803029b80d891fbff1323a | f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | local\-file | 2026\-11\-16T13:49:45\.436Z | 0 full elapsed days | [evidence/f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8\.txt](evidence/f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| text\-01 | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/text\-01\.txt](evidence/text-01.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Identity extraction of the collected plain\-text Markdown snapshot; no rendering performed |
| text\-02 | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/text\-02\.txt](evidence/text-02.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Identity extraction of the collected plain\-text Markdown snapshot; no rendering performed |
| text\-03 | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/text\-03\.txt](evidence/text-03.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Identity extraction of the collected plain\-text Markdown snapshot; no rendering performed |
| text\-04 | f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/text\-04\.txt](evidence/text-04.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Identity extraction of the collected plain\-text Markdown snapshot; no rendering performed |
| claims\-01 | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/claims\-01\.txt](evidence/claims-01.txt) | 799f21526c4a11079aef342b183b5852da3f9e0eab07fbb09e993b5efc953202 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| entity\-01 | 5276b7898e9d618504f46ce1bfcbc08acc910080ee6f901177102a5881d7c11f | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/entity\-01\.txt](evidence/entity-01.txt) | e903440b50bf9647595ba22623cf6f2807cd30759c97f1db1487de8ecd940b71 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| claims\-02 | 480069b349426786e713b9a0bfe0faa89020ff223af17c25841da50c9d63796f | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/claims\-02\.txt](evidence/claims-02.txt) | 0d26b01034afba45ec76799ea80e3643f0e0792f8e8dd6345e39281adcb59dd9 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| claims\-03 | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/claims\-03\.txt](evidence/claims-03.txt) | 312830fd3f22ff3963ba36ec4fb9a4326751cff290098f36ccaf5d6ddb6eb2c0 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| entity\-03 | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/entity\-03\.txt](evidence/entity-03.txt) | 79bee0ef2543091416e3d952c7a66d8d9d650f8b610721fb436901f540d35974 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| inventory\-map\-03 | 4e94e28dff90c59efed7c9de7c01102bbe5afdad050599404318f06f755d0cef | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/inventory\-map\-03\.txt](evidence/inventory-map-03.txt) | 0aca84d1a2e23eaf6abcfd59430bd9f1dc331d04308f8d8e8cbaa8779d342f91 | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |
| claims\-04 | f6e9e6e831437db24609714d7e546cb8a0be418901acd5f5714e692a603041e8 | local\-file | 2026\-11\-16T13:52:14\.222Z | 0 full elapsed days | [evidence/claims\-04\.txt](evidence/claims-04.txt) | 78d4580c3d60b1922c367cc6e26bb631b405a69417978bccde058403b33f73de | Synthetic owner\-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
