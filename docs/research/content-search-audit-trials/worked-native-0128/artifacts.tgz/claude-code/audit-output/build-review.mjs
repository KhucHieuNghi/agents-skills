// Host-authored review bundle for the four synthetic dossiers. Reads run-initial; writes review.json.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const [pkgArg, outArg] = process.argv.slice(2);
const pkg = path.resolve(pkgArg);
const out = path.resolve(outArg);
const { loadAuditData } = await import(
  pathToFileURL(path.join(pkg, "scripts/lib/validate.mjs"))
);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const audit = await loadAuditData(path.join(out, "run-initial"));
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 host review (content-search-audit skill)";

const byName = {};
for (const item of audit.inventory) {
  const name = path.basename(item.path);
  const snapshot = audit.evidence.find(
    (e) => e.itemId === item.itemId && e.kind === "content",
  );
  byName[name.slice(0, 2)] = { item, snapshot, name };
}

const artifacts = {};
const evidence = [];
function add(key, slug, kind, value, locator) {
  const { snapshot } = byName[key];
  const artifact = `evidence/${slug}.txt`;
  artifacts[artifact] = value;
  evidence.push({
    ...snapshot,
    evidenceId: slug,
    kind,
    artifact,
    value,
    snapshotHash: hash(value),
    byteLength: Buffer.byteLength(value),
    collectedAt: now,
    locator,
    sourceEvidenceIds: [snapshot.evidenceId],
    limitations: [
      "Synthetic owner-supplied statement preserved from the dossier; comparison evidence within this scenario only, not independently verified live behavior",
    ],
  });
  return slug;
}

// Extracted text: the Markdown source is itself plain text; identity extraction.
for (const key of ["01", "02", "03", "04"]) {
  const { snapshot } = byName[key];
  const slug = `text-${key}`;
  const artifact = `evidence/${slug}.txt`;
  artifacts[artifact] = snapshot.value;
  evidence.push({
    ...snapshot,
    evidenceId: slug,
    kind: "extracted-text",
    artifact,
    snapshotHash: hash(snapshot.value),
    collectedAt: now,
    sourceEvidenceIds: [snapshot.evidenceId],
    limitations: [
      "Identity extraction of the collected plain-text Markdown snapshot; no rendering performed",
    ],
  });
}

const c01 = add(
  "01",
  "claims-01",
  "claim-sources",
  "Synthetic owner-supplied records in 01-competitor-claims.md:3-14 (current November 2026 US plans, USD before tax): Cedar monthly USD 12 per seat per month, no seat minimum; Cedar annual USD 10 per seat per month equivalent; Fir monthly USD 15 per seat per month; Fir annual USD 9 per seat per month equivalent; figures exclude optional services and none is required. Fir pricing-table excerpt does not mention SSO; supplied current Fir SSO docs state SAML SSO is available on Enterprise with a minimum of 20 paid seats; no SSO statement is supplied for Fir's other plans. Comparison evidence only; not verified live pricing.",
  "01-competitor-claims.md:3-14",
);
const e01 = add(
  "01",
  "entity-01",
  "entity-record",
  "Synthetic owner-supplied plan/price/SSO records for Cedar and Fir, 01-competitor-claims.md:6-14, scoped to current November 2026 US plans in USD before tax. Used as the entity record for comparing the /compare draft assertions and the /monthly-comparison caption. Not an independently verified public record.",
  "01-competitor-claims.md:6-14",
);
const c02 = add(
  "02",
  "claims-02",
  "claim-sources",
  "Synthetic owner-supplied counts in 02-measurement-windows.md:3-8 and 14-16 (one campaign, USD, October 2026): spend complete for October 1-31 is USD 3000; conversion export covers only October 1-7 with 35 completed conversions; no conversion data exists for October 8-31; October 1-7 spend is USD 700. Independent referral report: 15 October sessions have an identified AI-assistant referrer; other sessions have unknown origin; no model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists. Not a live connector response.",
  "02-measurement-windows.md:3-16",
);
const c03 = add(
  "03",
  "claims-03",
  "claim-sources",
  "Synthetic owner-approved policy in 03-template-service-area.md:4-5: North serves same-day delivery, Monday-Friday, orders placed before 10:00 local time; South serves next-business-day delivery only. Owner context in 03-template-service-area.md:13-16: /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurate for the 2024 contract when South had same-day service, linking to the two current pages for new orders. Comparison evidence only; not verified live behavior.",
  "03-template-service-area.md:4-16",
);
const e03 = add(
  "03",
  "entity-03",
  "entity-record",
  "Synthetic owner-approved current service policy for the North and South regions, 03-template-service-area.md:4-5, used as the entity record for the /north-delivery and /south-delivery policy passages. Not an independently verified public record.",
  "03-template-service-area.md:4-5",
);
const m03 = add(
  "03",
  "inventory-map-03",
  "inventory-map",
  "Synthetic owner declaration in 03-template-service-area.md:3 and 18-20: the declared inventory is complete and consists of /north-delivery, /south-delivery and /terms-v1; the two current pages serve different regions and the owner wants both retained; shared layout and repeated generic contact wording are intentional; no ranking, query/page overlap, backlink, conversion or search-engine selection data exists.",
  "03-template-service-area.md:3-20",
);
const c04 = add(
  "04",
  "claims-04",
  "claim-sources",
  "Synthetic owner-approved records in 04-editorial-proof.md:3-5 and 10-13: for 20 observed onboarding sessions in a supplied study the median completion time was 15 minutes; no maximum time, guarantee, refund policy, percentile distribution or wider population estimate is supplied. Approved permissions policy: editors cannot delete a workspace and owners can; no additional conditions are needed to answer the permission question. Comparison evidence only.",
  "04-editorial-proof.md:3-13",
);

const id = (k) => byName[k].item.itemId;
const snap = (k) => byName[k].snapshot.evidenceId;
const review = (k, ruleId, status, reason, ids) => ({
  itemId: id(k),
  ruleId,
  status,
  reason,
  evidenceIds: [snap(k), ...ids],
  reviewer,
  reviewedAt: now,
});

const reviews = [
  // 01
  review(
    "01",
    "quality-claims",
    "fail",
    "Item-wide verdict over three components. /compare assertion A (line 17) denies Fir SSO and cites the pricing table as proof, while the supplied Fir SSO docs (line 13) state SAML SSO is available on Enterprise with a 20-paid-seat minimum. /compare assertion B (line 18) claims Cedar is cheaper on every billing option, while the supplied annual figures are Cedar USD 10 versus Fir USD 9. The /monthly-comparison caption (line 21) is supported (15 minus 12 is 3, monthly plans, before tax) and stays clean.",
    [c01],
  ),
  review(
    "01",
    "aeo-answer-evidence",
    "fail",
    "Same two defects as quality-claims: the comparative answer claims in /compare assertions A and B are contradicted by the supplied SSO documentation and annual prices. The monthly caption's answer claim is supported. No question set was supplied, so question coverage and answer context stay unknown.",
    [c01],
  ),
  review(
    "01",
    "aio-entity-consistency",
    "fail",
    "Against the supplied plan/price/SSO record, /compare assertion A misstates Fir's SSO availability and assertion B misstates the annual price relationship. The monthly caption is consistent with the record.",
    [e01],
  ),
  review(
    "01",
    "quality-freshness",
    "unknown",
    "The owner states the records are current November 2026 US plans, but the date/market labelling carried by the /compare and /monthly-comparison pages themselves is not supplied and no live pricing was verified.",
    [c01],
  ),
  // 02
  review(
    "02",
    "quality-claims",
    "fail",
    "Item-wide verdict over four components. Draft A (line 10) labels 3000/35 as October cost per conversion although conversions cover only October 1-7 and October 8-31 has no conversion data. Draft B (lines 17-18) asserts proof of 150 AI-assistant sessions from 15 tracked sessions using a one-in-ten rate that no supplied model or complete session count supports. The verified-window caption (lines 11-12; 700/35 = 20, rest of month stated unmeasured) is supported, and the count of 15 identified-referrer sessions is a supported descriptive figure.",
    [c02],
  ),
  review(
    "02",
    "quality-freshness",
    "unknown",
    "Figures are scoped to a completed October 2026 window; no evidence about later restatement or export completeness beyond the stated windows was supplied.",
    [c02],
  ),
  // 03
  review(
    "03",
    "quality-claims",
    "fail",
    "Item-wide verdict over three declared pages. /south-delivery (lines 10-11) promises same-day delivery while the current approved policy (lines 4-5) says South serves next-business-day delivery only. /north-delivery (lines 8-9) matches the approved policy. /terms-v1 is an owner-confirmed, clearly labeled and accurate 2024 archive and is not a defect.",
    [c03],
  ),
  review(
    "03",
    "aeo-answer-evidence",
    "fail",
    "The /south-delivery passage answers the delivery-speed question for South with a claim the approved policy contradicts. The /north-delivery answer is supported. No question set was supplied, so coverage and context checks stay unknown.",
    [c03],
  ),
  review(
    "03",
    "aio-entity-consistency",
    "fail",
    "The /south-delivery service facts conflict with the approved South policy record; /north-delivery is consistent with the North record.",
    [e03],
  ),
  review(
    "03",
    "portfolio-contradictions",
    "fail",
    "Across the complete declared inventory, /south-delivery carries the North service terms and contradicts the approved South record. /terms-v1 describing 2024 South same-day service is a labeled historical version, not a contradiction, and /north-delivery is consistent.",
    [e03, m03],
  ),
  review(
    "03",
    "portfolio-duplication",
    "pass",
    "The declared inventory is complete. /north-delivery and /south-delivery serve different regions and the owner wants both retained; shared layout and generic contact wording are intentional; /terms-v1 is a legitimate labeled version variant. No query/page overlap or engine-selection data exists, so cannibalization is neither confirmed nor implied. The identical South policy passage is a factual error recorded under the contradiction finding, not a duplication defect, and no consolidation is proposed.",
    [m03],
  ),
  review(
    "03",
    "quality-freshness",
    "unknown",
    "The /south-delivery passage matches what the owner says was true under the 2024 contract, but whether it is stale copy or a template error is not established; the defect is recorded under quality-claims. /terms-v1 is a labeled archive and /north-delivery matches current policy.",
    [c03],
  ),
  // 04
  review(
    "04",
    "quality-claims",
    "fail",
    "Item-wide verdict over three components. The draft landing-page claim (line 6) asserts a guarantee for every team at 10 minutes; the approved record (lines 3-5) gives only a 15-minute median over 20 observed sessions and supplies no guarantee, maximum or wider population estimate. The permissions FAQ (line 9) matches the approved permissions policy exactly and stays clean. The /status-codes table is owner-attested complete and accurate but its content was not supplied, so it is not independently verified and is not a defect.",
    [c04],
  ),
  review(
    "04",
    "aeo-answer-evidence",
    "fail",
    "The landing-page setup-time answer claim is unsupported by the approved product record. The permissions FAQ answer is fully supported by the approved policy and needs no additional conditions.",
    [c04],
  ),
  review(
    "04",
    "quality-freshness",
    "unknown",
    "No dates or versions are supplied for the study, the permissions policy or the /status-codes table.",
    [c04],
  ),
];

const finding = (o) => ({
  confidence: "high",
  classification: "observed",
  ownerRole: "Content owner",
  effort: "small",
  action: "update",
  ...o,
});
const findings = [
  finding({
    findingId: "F1-fir-sso-denial",
    title: "/compare assertion A denies Fir SSO against the supplied Fir SSO documentation",
    affectedItemIds: [id("01")],
    ruleIds: ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"],
    dimensions: ["quality", "aeo", "aio"],
    evidenceIds: [snap("01"), c01, e01],
    severity: "high",
    actionReason:
      "The supplied SSO documentation directly contradicts the draft assertion and a pricing-table omission is not proof of absence.",
    remediation:
      "Remove the denial and the pricing-table proof wording from /compare assertion A. If SSO is mentioned, state only what the supplied Fir SSO documentation says: SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats (current November 2026 US scope). Make no statement about Fir's other plans or about Cedar SSO, because no record was supplied for either.",
    verification:
      "Re-read the revised assertion against 01-competitor-claims.md:12-14 and confirm it neither denies Fir SSO, cites the pricing table as proof, nor asserts SSO status for plans without a supplied statement. This audit does not authorize changing the content.",
  }),
  finding({
    findingId: "F2-every-billing-option",
    title: "/compare assertion B claims Cedar is cheaper on every billing option; the annual figures show the reverse",
    affectedItemIds: [id("01")],
    ruleIds: ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"],
    dimensions: ["quality", "aeo", "aio"],
    evidenceIds: [snap("01"), c01, e01],
    severity: "high",
    actionReason:
      "The supplied annual prices (Cedar USD 10, Fir USD 9 per seat per month equivalent) contradict the universal claim.",
    remediation:
      "Limit assertion B to monthly billing, where Cedar is USD 12 and Fir USD 15 per seat per month, and either omit annual billing or state that on the supplied annual options Fir is USD 1 less per seat per month equivalent. Keep the November 2026, US, USD before-tax and billing-period qualifiers. The existing /monthly-comparison caption already shows acceptable scope.",
    verification:
      "Recompute each billing option from 01-competitor-claims.md:6-9 and confirm every comparative statement holds for the billing period it names.",
  }),
  finding({
    findingId: "F3-october-cost-window-mismatch",
    title: "Draft A divides full-month spend by one week of conversions and labels it October cost per conversion",
    affectedItemIds: [id("02")],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [snap("02"), c02],
    severity: "medium",
    ownerRole: "Analytics/reporting owner",
    actionReason:
      "Numerator covers October 1-31 and denominator October 1-7; conversions for October 8-31 are missing, not zero.",
    remediation:
      "Withdraw the USD 85.71 October figure. Report the matched window only, as the existing verified-window caption does (October 1-7: USD 700 divided by 35 completed conversions is USD 20), and state that October 8-31 conversions are unmeasured. A full-October figure requires a conversion export covering October 8-31.",
    verification:
      "Confirm numerator and denominator in any revised metric cover the same dates, campaign and currency per 02-measurement-windows.md:5-8, and that the unmeasured period is stated rather than treated as zero.",
  }),
  finding({
    findingId: "F4-ai-sessions-extrapolation",
    title: "Draft B claims proof of 150 AI-assistant sessions from 15 tracked sessions with an unsupported one-in-ten rate",
    affectedItemIds: [id("02")],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [snap("02"), c02],
    severity: "medium",
    ownerRole: "Analytics/reporting owner",
    actionReason:
      "No model of untracked AI influence, incrementality test or complete session count exists to support the multiplier or the proof claim.",
    remediation:
      "Replace Draft B with the supported descriptive statement: 15 October sessions have an identified AI-assistant referrer and other sessions have unknown origin. Remove the 150 total, the one-in-ten rate and the proof wording. Do not link these sessions to the campaign conversion counts.",
    verification:
      "Check the revised sentence against 02-measurement-windows.md:14-16 and 20-21: only the 15 identified sessions are stated, unknown-origin sessions are not counted as AI or as non-AI, and no conversion linkage is implied.",
  }),
  finding({
    findingId: "F5-south-same-day",
    title: "/south-delivery promises same-day delivery; approved policy is next-business-day only",
    affectedItemIds: [id("03")],
    ruleIds: [
      "quality-claims",
      "aeo-answer-evidence",
      "aio-entity-consistency",
      "portfolio-contradictions",
    ],
    dimensions: ["quality", "aeo", "aio", "portfolio"],
    evidenceIds: [snap("03"), c03, e03, m03],
    severity: "high",
    actionReason:
      "The current South page passage repeats the North terms and contradicts the current approved South policy.",
    remediation:
      "Replace the /south-delivery policy passage so it states that South serves next-business-day delivery only. The approved policy supplies no South order cutoff or day-of-week condition, so obtain those from the policy owner before adding any; do not carry over the North 10:00 cutoff. Keep /north-delivery and /terms-v1 unchanged and keep both regional pages.",
    verification:
      "Compare the revised /south-delivery passage with 03-template-service-area.md:4-5 and confirm /north-delivery still matches. Live page, index and engine behavior remain unverified by this check.",
  }),
  finding({
    findingId: "F6-setup-guarantee",
    title: "Landing-page draft guarantees 10-minute setup for every team; the record supports only a 15-minute median over 20 sessions",
    affectedItemIds: [id("04")],
    ruleIds: ["quality-claims", "aeo-answer-evidence"],
    dimensions: ["quality", "aeo"],
    evidenceIds: [snap("04"), c04],
    severity: "high",
    actionReason:
      "The universal scope, the guarantee and the 10-minute figure each exceed the approved product record.",
    remediation:
      "Replace the draft claim with the supported descriptive result: in a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes. Do not state a guarantee, a maximum, or a result for all teams unless the owner supplies a guarantee policy and supporting data.",
    verification:
      "Compare the revised claim with 04-editorial-proof.md:3-5 for sample size, statistic, duration and absence of guarantee or universal wording.",
  }),
];

await writeFile(
  path.join(out, "review.json"),
  JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n",
);
console.log(JSON.stringify({ reviews: reviews.length, findings: findings.length, evidence: evidence.length, now }));
