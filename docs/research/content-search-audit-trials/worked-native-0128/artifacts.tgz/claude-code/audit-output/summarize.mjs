// Prints validation and check summary for a run directory.
import { readFileSync } from "node:fs";
import path from "node:path";
const out = path.resolve(process.argv[2]);
console.log(3000 / 35, 700 / 35, 15 - 12, 10 - 9);
const v = JSON.parse(readFileSync(path.join(out, "validation.json"), "utf8"));
console.log(
  JSON.stringify({
    valid: v.valid,
    completionAllowed: v.completionAllowed,
    errors: v.errors,
    coverage: { ...v.coverage, remainingItemIds: undefined },
  }),
);
const checks = readFileSync(path.join(out, "run-reviewed/checks.jsonl"), "utf8")
  .trim()
  .split("\n")
  .map((l) => JSON.parse(l));
const tally = {};
for (const c of checks) tally[c.status] = (tally[c.status] || 0) + 1;
console.log(checks.length, tally);
for (const c of checks)
  if (c.status !== "unknown" || c.reviewer)
    console.log(c.itemId.slice(0, 6), c.ruleId, c.status);
