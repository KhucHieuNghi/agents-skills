# Bounded offline snapshot audit (synthetic fixture)

Audit as of 2026-11-16. Skill: content-search-audit. Sources: `targets/context.md`, `targets/discovery.json` and five HTML snapshots. No URL was fetched, no credentials were used, and no inputs or skill files were modified. This is a bounded snapshot review, not a completed full campaign. Discovery receipt: [discovery-receipt.json](discovery-receipt.json), the unmodified output of `audit.mjs discover targets/discovery.json`.

## 1. Scope, inventory and provenance accounting

Discovery result: `inventoryComplete: false`. The pending queue has one entry, `missing-source` for `analytics` ("Expected source snapshot not supplied"). The three supplied sources are each marked complete with 0 rejected rows.

| Source | Kind | Accepted rows | Rejected rows | Snapshot hash (prefix) |
|---|---|---|---|---|
| sitemap | sitemap-xml | 5 | 0 | fd8b4f7e… |
| cms | records | 2 | 0 | ff80dc12… |
| repository-map | records | 5 | 0 | d8ce5230… |
| analytics | (expected, not supplied) | – | – | – |

Totals: 12 source rows merged into 5 inventory items. The CMS alias `…/en/basic?utm_source=cms` merged into `…/en/basic` because `utm_source` is the only declared tracking parameter. `?version=1` was kept as a distinct item.

| Item (URL) | Snapshot file | Sources | Locale | State |
|---|---|---|---|---|
| https://fixture.example/en/basic | en-basic.html | cms, repository-map, sitemap | en | read and reviewed |
| https://fixture.example/vi/basic | vi-basic.html | cms, repository-map, sitemap | vi | read and reviewed |
| https://fixture.example/en/refund | en-refund.html | repository-map, sitemap | unknown in discovery, `en` per `<html lang>` | read and reviewed |
| https://fixture.example/vi/refund | vi-refund.html | repository-map, sitemap | unknown in discovery, `vi` per `<html lang>` | read and reviewed |
| https://fixture.example/en/basic?version=1 | en-basic-v1.html | repository-map, sitemap | unknown in discovery, `en` per `<html lang>` | read and reviewed |

Counts: declared 5, snapshots inspected 5, excluded 0, blocked 0, failed 0, unsupported 0. The URL-to-file mapping comes from `context.md`, not from the helper. I did not run `start`, `review` or `validate`, so no run-folder check records exist. "Reviewed" below means I read the snapshot manually. The helper's per-item state is still `pending`.

## 2. Material findings

### F1. Vietnamese Basic page states 8 seats; the product owner confirms 3 (content quality / answer quality). Severity high, confidence high, observed

- **Affected:** https://fixture.example/vi/basic (`targets/vi-basic.html`, line 15). Cross-item support comes from https://fixture.example/en/basic (`targets/en-basic.html`, line 20) and `targets/context.md`.
- **Quotation, vi-basic.html:** "Basic bao gồm 8 chỗ ở mọi thị trường. Phí xuất dữ liệu là 5 USD." In English: "Basic includes 8 seats in every market. Export fee is 5 USD."
- **Quotation, en-basic.html:** "Basic includes 3 seats in every market. Export costs USD 5."
- **Quotation, context.md:** "the 2026 Basic global plan has 3 seats in all markets; export costs USD 5."
- **Rationale:** The two pages are declared alternate translations of the same product and version. The seat count differs, 8 against 3. The owner's statement matches the English page. The export price (USD 5) matches on both pages. A search or answer engine could return either number for the same plan, and the 8-seat answer would be wrong.
- **Proposed change (not applied):** Change "8 chỗ" to "3 chỗ" in the Vietnamese page body. The content owner should confirm the wording.
- **Verification:** Re-collect the snapshot and compare the seat number with en-basic.html. Search all Vietnamese Basic 2026 content for other occurrences of "8 chỗ". That search was not run here because only these five snapshots were supplied.

### F2. Hreflang annotations are not reciprocal for the Basic pair (technical SEO / international). Severity medium, confidence high for the snapshot, observed

- **Affected:** https://fixture.example/vi/basic (`targets/vi-basic.html`, lines 7–11). The en page is the cross-item dependency (`targets/en-basic.html`, lines 7–16).
- **Quotation, en-basic.html:** `hreflang="vi"` with `href="https://fixture.example/vi/basic"`. The page also has `hreflang="en"`.
- **Quotation, vi-basic.html:** its only alternate is `hreflang="vi"` with `href="https://fixture.example/vi/basic"`. There is no `hreflang="en"` link.
- **Rationale:** `context.md` declares the pair intended alternates and says both snapshots are "complete for their link annotations". So the missing return link on the Vietnamese page is a real gap in the supplied snapshot, not a capture artifact. Hreflang pairs need confirmation in both directions. The en page points to vi, but vi does not point back to en. I am not claiming a ranking effect or that search engines ignore the annotation.
- **Proposed change (not applied):** Add `<link rel="alternate" hreflang="en" href="https://fixture.example/en/basic" />` to vi-basic.html. Optionally add `x-default`; that is a policy choice, not a defect.
- **Verification:** Re-collect both pages and check that each lists itself and the other. Then check Search Console international targeting or index status once an export exists. None was supplied.

## 3. Clean and uncertain cases

**Clean (no finding):**
- **Refund pair:** en-refund.html ("This policy applies only to UK purchases: request a refund within 14 days.") and vi-refund.html ("Chỉ áp dụng cho giao dịch tại Việt Nam: yêu cầu hoàn tiền trong vòng 7 ngày." In English: "Applies only to transactions in Vietnam: request a refund within 7 days.") differ in duration (14 against 7 days), but context.md says they are separate policies and the policy owner approves each duration. Each states its jurisdiction. No contradiction is claimed. Neither has hreflang, and none is required because they are not translations.
- **Archived version:** en-basic-v1.html states "This historical version included 2 seats." That differs from the 3 seats on the current page, but it is deliberately retained and labelled as archived 2025. It links to the current plan (`href="https://fixture.example/en/basic"`). Its canonical points to itself (`?version=1`), so it is not merged into the current version. Clean.
- **Canonicals:** all five pages have a self-referencing canonical that matches the mapped URL.
- **Title and H1:** each page has a descriptive title and an H1 that matches it in meaning.
- **Language attributes:** `<html lang>` matches each URL's language segment.
- **Tracking parameter handling:** `utm_source` was normalized and `version=1` was preserved, as declared.

**Uncertain, no finding raised:**
- **Locale of en-refund:** the page is under `/en/` but applies only to UK purchases. Whether "English" visitors from other markets need a pointer to another policy is a business decision. The pages do not show a defect.
- **Discovery locale for refund and v1 items:** the helper reports "unknown" because the CMS records do not list those items. This reflects the CMS export and is not a page defect.
- **Other quality dimensions:** the pages are very short. There are no meta descriptions, structured data, author, date or FAQ content. Whether this matters depends on business purpose, and no evidence of an effect was supplied. I treat these as observations, not findings. No schema or answer-format checks beyond text reading were performed.
- **AIO / GEO:** whether the pages are cited or mentioned by AI surfaces is unknown. I distinguish AI search optimization from the Google product AI Overviews, and neither was measured.

## 4. Six-dimension assessment

| Dimension | Result |
|---|---|
| Content quality | F1; the other pages are consistent with the owner statement |
| SEO / technical | F2; canonicals clean; HTTP headers, robots and index status unmeasured |
| AI search optimization (AIO) | Readiness limited to plain static text. Behavior with AI crawlers unmeasured |
| Answer quality (AEO) | The Vietnamese seat answer is wrong (F1). The other facts match context.md |
| Generative visibility (GEO) | No AI observations supplied, so mentions, citations and accuracy are unmeasured |
| Cross-content relationships | F1, F2; refund pair and archived version clean |

## 5. Missing measurements

- **Analytics:** the expected source was not supplied (no export, no credentials). Absence is not zero traffic. No traffic or conversion data is claimed.
- **Search Console and Bing:** no exports.
- **Server logs:** none.
- **AI observations:** none supplied. No mention, citation or ranking data is invented.
- **HTTP headers, index status, rendered browser output:** none supplied (stated in context.md).

## 6. Coverage limitations

- Discovery is `inventoryComplete: false` because the analytics source is missing. Full coverage is not claimed.
- This is a snapshot review of five synthetic files. It is not a live capture or a full campaign. Pages not in the supplied sources would not be found.
- No `start`, `review`, `validate` or `coverage` artifacts were produced, so no semantic checks are certified by helper artifacts. Findings are manual reading, cross-checked against context.md.
- Source dates are 2026-11-15 (collection). The audit date is 2026-11-16. No dates were computed from them.
- Priorities (high, medium) are my judgment of impact, not measured. No SEO or GEO score is given and no ranking outcome is promised.
- Proposed changes are recommendations only. Nothing was implemented.
