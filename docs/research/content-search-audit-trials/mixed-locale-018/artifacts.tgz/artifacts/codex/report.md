# Bounded content-search audit

**Scope date:** 2026-11-16 · **Review ID:** fixture-snapshot-2026-11-16 · **Evidence:** synthetic local files.

Two material findings affect the current Basic plan pair. The Vietnamese page gives an incorrect seat count and omits the reciprocal English hreflang annotation. The jurisdiction-specific refund pages and historical Basic page have no supported material defect within this review.

## Inventory and provenance

I read all seven files in `targets/`: five HTML snapshots, the [scope and owner decisions](targets/context.md), and the [discovery input](targets/discovery.json). The review covers English and Vietnamese readers comparing the Basic plan, checking refund eligibility and deadlines, or consulting historical plan documentation. The URLs below identify the supplied snapshots.

I ran `rtk proxy node .agents/skills/content-search-audit/scripts/audit.mjs discover targets/discovery.json` and saved its unmodified stdout as the [discovery receipt](discovery-receipt.json). The three supplied sources each report the collection timestamp `2026-11-15T00:00:00Z`.

| Expected source | Locator | Accepted rows | Rejected rows | Receipt status |
|---|---|---:|---:|---|
| Sitemap | `supplied:sitemap` | 5 | 0 | Processed, declared complete, no child sitemaps |
| CMS | `supplied:cms` | 2 | 0 | Processed, declared complete |
| Repository map | `supplied:repository-map` | 5 | 0 | Processed, declared complete |
| Analytics | Unavailable | — | — | One `missing-source` queue entry |

The 12 accepted rows resolve to five unique URL identities. Only `utm_source` is designated tracking. The CMS alias `https://fixture.example/en/basic?utm_source=cms` is preserved in the receipt under the current English URL. The `?version=1` query is retained as a distinct historical identity. Although the input has `scopeComplete: true`, the helper returned `inventoryComplete: false` because analytics was expected and absent. The receipt preserves all source hashes, full item IDs, original aliases and declared candidates.

| URL | Local HTML and SHA-256 | Discovery membership | HTML language and task |
|---|---|---|---|
| `https://fixture.example/en/basic` | [en-basic.html](targets/en-basic.html) · `b30765113debdc76af6cbf775ffd66a93e6601f483bdb6d7079a282be32a20d8` | Sitemap, CMS, repository map | `en`, current plan seats and export fee |
| `https://fixture.example/vi/basic` | [vi-basic.html](targets/vi-basic.html) · `16a58031ad3d909ff32983b8293463834154d3e2e2f458cbd02e8ba4fd573fa7` | Sitemap, CMS, repository map | `vi`, same current plan and task |
| `https://fixture.example/en/basic?version=1` | [en-basic-v1.html](targets/en-basic-v1.html) · `2d73d4cf1974ad205f6c9b9a9ea1bd4193c3d22c8223b99f313423f8b8f095e6` | Sitemap, repository map | `en`, archive lookup and path to current plan |
| `https://fixture.example/en/refund` | [en-refund.html](targets/en-refund.html) · `b3f744f0cb3691b20c49bad00eb92d5bbedf01b5fa8ca364a163000a9d344ab7` | Sitemap, repository map | `en`, UK refund scope and request window |
| `https://fixture.example/vi/refund` | [vi-refund.html](targets/vi-refund.html) · `41279f63f592b9fe4813b62e38845adc6ba3ed1f13523ff681a7c02e0fa330aa` | Sitemap, repository map | `vi`, Vietnam refund scope and request window |

The CMS supplies locale and self-canonical candidates for the two current Basic URLs. The other three have unknown locale in the discovery receipt because the source rows lack that field. Their HTML languages come from the local snapshots. All five HTML documents declare a canonical equal to their mapped URL. The HTML capture timestamps were unspecified.

- `targets/context.md` SHA-256 `ee077e68f1fae739d7b2b1bab4382a24a910c0cfa4c8a7bbbce1f792a6ba4a9b`
- `targets/discovery.json` SHA-256 `2d1e18bfc4569b39541d19875fe6b1d5732122698091ff5b9299d0a13c2b4da4`

## Material findings

### F1 · Correct the Vietnamese Basic seat count

**Priority high · Confidence high · Content quality, AEO, AIO and portfolio.**

**Affected:** [vi-basic.html, line 15](targets/vi-basic.html#L15), `https://fixture.example/vi/basic`. Cross-content comparison: [en-basic.html, line 20](targets/en-basic.html#L20), `https://fixture.example/en/basic`.

- Vietnamese snapshot: “Basic bao gồm 8 chỗ ở mọi thị trường. Phí xuất dữ liệu là 5 USD.”
- English snapshot: “Basic includes 3 seats in every market. Export costs USD 5.”
- Owner evidence: “The product owner confirms that the 2026 Basic global plan has 3 seats in all markets;” ([context.md, lines 3–6](targets/context.md#L3)).

The Vietnamese copy gives a materially wrong answer about a plan entitlement that readers may use to decide whether Basic fits their team. A system extracting the Vietnamese passage would encounter the same conflicting fact. Both pages already state the owner-approved USD 5 export fee.

**Proposed change:** The Vietnamese content owner should change the visible seat count to “Basic bao gồm 3 chỗ ở mọi thị trường.” **Verification:** Reopen the revised 2026 English and Vietnamese snapshots and check that each answers “How many seats does Basic include?” with three seats in every market and gives USD 5 as the export fee. Use the owner decision as the reference and check the historical page independently against its stated version.

### F2 · Add the English hreflang return annotation to Vietnamese Basic

**Priority medium · Confidence high for the snapshot omission · SEO and portfolio.**

**Affected pair:** [en-basic.html, lines 7–16](targets/en-basic.html#L7), `https://fixture.example/en/basic`, and [vi-basic.html, lines 7–12](targets/vi-basic.html#L7), `https://fixture.example/vi/basic`. The scope declares that the two are “intended alternate” translations and states “Both supplied HTML snapshots are complete” for their link annotations. [Scope, lines 4–7](targets/context.md#L4)

The English head includes a Vietnamese alternate:

```html
    <link
      rel="alternate"
      hreflang="vi"
      href="https://fixture.example/vi/basic"
    />
```

The same literal element in the Vietnamese head is its only alternate, so that head declares itself and supplies no English return. The pair's annotations therefore describe the intended locale relationship in only one direction. The supplied evidence establishes the markup asymmetry. Actual search-engine interpretation is unknown.

**Proposed change:** The SEO/template owner should add `<link rel="alternate" hreflang="en" href="https://fixture.example/en/basic" />` to the Vietnamese head. **Verification:** Parse each revised head and check that both declare exactly the same two absolute language alternates, including the respective self-references, and that each canonical matches its own mapped URL.

## Clean and uncertain cases

- **Refund jurisdiction and duration.** The UK text says “This policy applies only to UK purchases: request a refund within 14 days.” The Vietnamese paragraph reads as follows in the source. The scope confirms separate jurisdictions and owner-approved durations. The difference is intentional, and the absence of a mutual hreflang relationship fits that policy scope. Both paragraphs directly answer where and within how many days. Refund submission channels, timing triggers and other conditions lack supporting policy evidence in the fixture, so the review makes no claim about whether these pages fully explain the refund workflow. [UK snapshot, line 11](targets/en-refund.html#L11) · [Vietnam snapshot, lines 11–12](targets/vi-refund.html#L11) · [Scope, lines 10–11](targets/context.md#L10)

  ```text
      Chỉ áp dụng cho giao dịch tại Việt Nam: yêu cầu hoàn tiền trong vòng 7
      ngày.
  ```

- **Historical Basic.** The heading “Archived 2025 Basic plan” and the passage “This historical version included 2 seats. For the current 2026 plan, see” establish different version applicability and lead into the “Basic 2026” link. Its target matches the supplied current English URL. The context explicitly calls `version=1` “deliberately retained historical documentation”. Keeping its self-canonical and distinct query identity fits that intent. The two-seat historical claim is sourced to the archive itself. [Historical snapshot, lines 5–12](targets/en-basic-v1.html#L5) · [Scope, lines 11–12](targets/context.md#L11)
- **Navigation and discovery.** The archive-to-current link is the only body hyperlink in the five snapshots. Its mapped destination is available for offline inspection. The other captured link relationships are canonical and alternate annotations. Wider internal navigation, live link health and orphan status are unknown. Search cannibalization would require query-to-page evidence.
- **Raw HTML controls.** Titles and H1s align with the five page tasks and their declared languages. No meta description, robots meta directive or structured-data markup appears in these files. Their absence alone does not establish a material defect, and renderer-injected markup and HTTP-level controls are unknown.

## Six-dimension assessment

| Dimension | Bounded outcome |
|---|---|
| Content quality | F1 contradicts the supplied product-owner decision. Current English seats and both export fees agree with it. Refund durations accord with scope. Historical seats apply to the archive only. |
| SEO | F2 is an observed reciprocal annotation gap. All five source canonicals match their mapped URLs, and all five appear in the supplied sitemap. Live response, rendering, engine-selected canonical and index status remain unknown. |
| AIO | F1 creates inconsistent retrievable source facts for the same product and year. The refund and archive copy supply applicability context. Actual crawler access, retrieval and citation behavior are unmeasured. |
| AEO | F1 provides the wrong answer to the inferred Basic seat question. The current English page directly answers seats and fee, and both refund pages directly answer jurisdiction and window. The question set comes from the supplied copy and scope. Customer query or support evidence was unavailable. |
| GEO | No measured surface or valid AI-answer observation was supplied. Mentions, citations, recommendations and answer accuracy are unavailable. F1 is a source-readiness concern. |
| Portfolio | F1 and F2 concern the intended current translation pair. The historical Basic page serves a distinct version task and points to its successor. The refund pages serve distinct jurisdictional tasks. |

## Missing measurements and coverage limits

**Coverage accounting:** 5 declared URL identities, all 5 in scope and manually inspected for the bounded snapshot review. There were 0 unread snapshots, 0 exclusions, 0 blocked or failed local reads and 0 unsupported snapshot formats. In the helper receipt all 5 records retain their discovery-stage `pending` state, with 0 formally audited campaign items and 1 separate pending discovery-source entry for analytics. There is no supplied-snapshot review backlog.

- **Analytics and search:** Obtain a dated offline analytics landing-page export to address the discovery queue, and separately obtain scoped GA4, Search Console and Bing evidence to evaluate traffic, queries, impressions, clicks, index evidence and conversions where available. Filter and reconcile by URL, query variant, period, locale and market. No metric is inferred from the missing source.
- **Technical:** Supplied HTTP status, redirect chains, response headers, robots captures and rendered DOM would allow verification of access, directives and rendered annotations. Field or lab performance evidence and a broader navigation inventory would resolve separate performance and link-graph questions. Nothing here establishes live eligibility or indexing.
- **AI measurement:** With authorization or supplied captures, compare fixed English and Vietnamese question cohorts on named surfaces, using Basic seats and price, jurisdiction-specific refunds and current versus archived plan. Preserve the exact prompts, responses, citation URLs, locale, surface, search mode and timestamps across repetitions. Report mentions and citations separately by surface with their denominators, and adjudicate factual claims against the owner decisions and version-specific evidence. Server-log exports could inform crawler activity separately. No surface was measured in this audit.

This report records manual judgments on the supplied evidence. No campaign was run, no registry-wide semantic check artifacts were produced, and no live site, platform or credential was accessed. The missing discovery source and the unavailable live, measurement and semantic evidence leave full campaign coverage unresolved.
