# Content audit — Content Search Audit

Partial.

## Scope and coverage

Counts use unique owned content, not repeated placeholder rows\. Completion concerns audit coverage, not whether content is defect\-free\. Discovery completeness is a declared scope assertion\.

| Metric | Value |
| --- | --- |
| Campaign | 2d04e04e\-afea\-4c97\-aa3d\-2957f07858e7 |
| Declared items | 1 |
| Owned/attempted | 1 |
| Collected | 1 |
| Audited | 0 |
| Inventory complete | true |
| Mode | full |
| Unresolved items | 1 |
| Missing checks | 0 |
| Pending queue | 0 |
| Global rules unresolved | portfolio\-task\-gaps, portfolio\-duplication, portfolio\-contradictions, portfolio\-journey\-links |
| pending | 1 |
| audited | 0 |
| failed | 0 |
| blocked | 0 |
| unsupported | 0 |
| excluded | 0 |

## Dimension coverage

Supplied checks only; missing checks are reported separately\. No combined SEO/GEO score is calculated\.

| Dimension | Supplied | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 5 | 0 | 5 | 0 |
| seo | 8 | 0 | 8 | 0 |
| aio | 3 | 0 | 3 | 0 |
| aeo | 3 | 0 | 3 | 0 |
| geo | 3 | 0 | 3 | 0 |
| portfolio | 4 | 0 | 4 | 0 |

## Global portfolio review

Attributed judgments remain subject to domain review\. Evidence hashes and valid references do not certify semantic truth or reviewer identity\.

| Rule | Status | Reason | Reviewer | Reviewed | Applicability reason |
| --- | --- | --- | --- | --- | --- |

## Priority backlog

Ordered by severity, then global findings and partition order\. Confidence is separate\. Each finding retains its scope; potentially overlapping findings are not silently merged\. Proposed actions are not executed\.

| Scope / finding | Severity | Confidence | Classification | Observation | Affected items | Recommendation | Verification | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Finding interpretation

0 local findings; 0 global findings\. Zero findings does not resolve unknown checks or demonstrate measured search visibility\.


## Evidence and partition reports

Evidence identifiers are scoped by partition\. Links resolve to the original validated snapshots; keep source campaign and receipt with this report when sharing\. Raw bodies are not embedded here\.

| Partition / evidence | Item | Kind | Captured | SHA\-256 | Artifact |
| --- | --- | --- | --- | --- | --- |
| [parts/000001](../campaign/parts/000001/report.md) |  | Partition report |  |  |  |
| parts/000001:0c6d961f2629d96fa53d915252de3b2fb95a2aab8b5a7f67c451ad48712e9b5a | 67b148365e2fadb9a433c47e1adc99d4d76ef2c73ee60e01c21741aa6fc3e9c0 | content | 2026\-11\-15T23:39:59\.939Z | cb7f59e0854bc77fb225701f8ad31e0f16a76f07333513f76eebb950bc3517ca | [evidence/67b148365e2fadb9a433c47e1adc99d4d76ef2c73ee60e01c21741aa6fc3e9c0\.txt](../campaign/parts/000001/evidence/67b148365e2fadb9a433c47e1adc99d4d76ef2c73ee60e01c21741aa6fc3e9c0.txt) |

## Global context evidence

Context values and review source references are preserved in the linked receipt\. Validate its bound source before interpreting judgments\.

| Evidence | Kind | Locator | Collected | SHA\-256 | Receipt |
| --- | --- | --- | --- | --- | --- |

## Remaining work

Resolve these queues and unknown checks before claiming full coverage\. Empty queues alone do not resolve unknown checks\.

| Kind | Item | Reason |
| --- | --- | --- |

## Measurements and interpretation

No visibility metrics are inferred or pooled by this report\. Consult explicitly supplied, dated, surface\-specific measurements in the underlying evidence\. Readiness is not measured mentions, citations, ranking or revenue; missing observations are unknown, not zero\.


## Visibility measurement status

SYNTHETIC FIXTURE DATA — not live visibility


## Visibility observations



| Engine | Surface | Model | Search | Locale/market | Cohort | Dates | Mention | Citation | Capture errors | Unknown mention/citation |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| fixture | api | unknown | enabled | vi\-VN/VN | accuracy@1 | 2026\-11\-15T23:35:23\.819Z – 2026\-11\-15T23:35:23\.819Z | Unavailable \(0 reviewed responses\) | Unavailable \(0 reviewed responses\) | 0 | 2/2 |

## Adjudicated AI\-answer accuracy



| Segment | Claim accuracy | Fully reviewed response accuracy | Unknown claims | Reviewed/unreviewed responses | Incomplete/empty/unresolved inventories |
| --- | --- | --- | --- | --- | --- |
| \[&quot;fixture&quot;,&quot;api&quot;,&quot;unknown&quot;,&quot;enabled&quot;,&quot;vi\-VN&quot;,&quot;VN&quot;,&quot;accuracy&quot;,&quot;1&quot;\] | 1/2 \(50\.0%\) | 0/1 \(0\.0%\) | 0 | 1/1 | 0/0/0 |

## Accuracy denominator

Claim accuracy uses correct/\(correct\+incorrect\) supplied material\-claim judgments; unknown claims are excluded and disclosed\. Response accuracy includes only complete, nonempty claim inventories without unknown verdicts; all claims must be correct\. Missing reviews and zero denominators are unavailable, never perfect\. These are reviewer assertions, not automatic fact checks or population estimates; inventory exclusion counts can overlap\.


## Measurement denominator

Captured responses with supplied non\-null annotations within each segment; capture errors and unknown annotations are disclosed separately\. Citation means at least one exact authorized brand\-host citation in a response, not share of all citations\.


## Measurement limitations

Artifact hashes verify supplied bytes, not capture authenticity or annotation correctness; Accuracy uses supplied material\-claim judgments, not automatic fact checking or population accuracy; no cross\-period uplift, causal attribution or market\-wide estimate is inferred; Only supplied exact brand hosts count; subdomains must be explicitly listed


## AI observation evidence



| Artifact |
| --- |
| [ai\-observation\-evidence\.json](ai-observation-evidence.json) |

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.


## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.


## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.


## Server\-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.


## Next steps

Resolve missing local/global evidence, complete declared discovery, apply new immutable reviews and regenerate this report\. The current audit is partial\.

