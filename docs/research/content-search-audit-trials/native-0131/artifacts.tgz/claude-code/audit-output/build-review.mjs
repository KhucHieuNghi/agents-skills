import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const run = process.argv[2], out = process.argv[3];
const hash = (v) => createHash("sha256").update(v).digest("hex");
const inv = readFileSync(run + "/inventory.jsonl", "utf8").trim().split("\n").map(JSON.parse);
const ev = readFileSync(run + "/evidence.jsonl", "utf8").trim().split("\n").map(JSON.parse);
const now = new Date().toISOString();
const reviewer = "claude-agent-host-review";
const item = (n) => inv.find((i) => i.path.includes("/" + n + "-"));
const snap = (it) => ev.find((e) => e.itemId === it.itemId && e.kind === "content");
const artifacts = {}, evidence = [], reviews = [], findings = [];
const LIM = "Synthetic owner-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior.";
function add(n, kind, slug, locator, value) {
  const it = item(n), s = snap(it);
  const id = `d${n}-${slug}`;
  const artifact = `evidence/${id}.txt`;
  artifacts[artifact] = value;
  evidence.push({ ...s, evidenceId: id, kind, artifact, value, snapshotHash: hash(value), byteLength: Buffer.byteLength(value),
    collectedAt: now, locator, method: "host-attributed-context", limitations: [LIM], sourceEvidenceIds: [s.evidenceId] });
  return id;
}
function review(n, ruleId, status, reason, ids) {
  const it = item(n);
  reviews.push({ itemId: it.itemId, ruleId, status, reason, evidenceIds: [snap(it).evidenceId, ...ids], reviewer, reviewedAt: now });
}
function finding(n, f) {
  const it = item(n);
  findings.push({ affectedItemIds: [it.itemId], classification: "observed", confidence: "high", ownerRole: "Content owner", effort: "small",
    ...f, evidenceIds: [snap(it).evidenceId, ...f.evidenceIds] });
}
// extracted text for every item (identity extraction of UTF-8 Markdown source)
for (const n of ["01", "02", "03", "04"]) {
  const it = item(n), s = snap(it);
  const id = `d${n}-extracted-text`, artifact = `evidence/${id}.txt`;
  artifacts[artifact] = s.value;
  evidence.push({ ...s, evidenceId: id, kind: "extracted-text", artifact, snapshotHash: hash(s.value), collectedAt: now,
    method: "identity-text-extraction", limitations: ["Identity extraction of the UTF-8 Markdown dossier text; not a rendered page or live capture."], sourceEvidenceIds: [s.evidenceId] });
}
// 01
const c1 = add("01", "claim-sources", "claim-sources", "01-competitor-claims.md:3-14",
  "Owner-supplied synthetic records, current November 2026 US plans, USD before tax (01-competitor-claims.md:3-14): Cedar monthly USD 12 per seat per month, no seat minimum; Cedar annual USD 10 per seat per month equivalent; Fir monthly USD 15 per seat per month; Fir annual USD 9 per seat per month equivalent; figures exclude optional services and none is required. Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: \"SAML SSO is available on Enterprise, with a minimum of 20 paid seats.\" No SSO statement is supplied for Fir's other plans.");
review("01", "quality-claims", "fail",
  "Components: /compare assertion A (line 17), /compare assertion B (line 18), /monthly-comparison caption (lines 20-23). A conflicts with the supplied Fir SSO documentation (line 13) and treats a pricing-table omission as proof. B is false for annual billing (Cedar USD 10 vs Fir USD 9 per seat per month equivalent) though true for monthly (USD 12 vs USD 15). The monthly caption is supported (15 - 12 = 3, monthly plans, before tax) and stays clean.", [c1]);
finding("01", { findingId: "d01-fir-sso-claim", title: "/compare assertion A denies Fir SSO against the supplied Fir SSO documentation", ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c1], severity: "high",
  remediation: "Proposal only: remove assertion A or replace it with the supplied fact, e.g. that Fir's supplied SSO documentation states SAML SSO is available on Enterprise with a minimum of 20 paid seats. Do not state that other Fir plans lack SSO; no statement is supplied for them.",
  verification: "Compare the revised complete assertion with 01-competitor-claims.md:12-14; confirm it attributes the SSO fact to the SSO documentation, keeps the Enterprise and 20-paid-seat conditions, and makes no claim from the pricing table's silence." });
finding("01", { findingId: "d01-every-billing-option", title: "/compare assertion B claims Cedar is cheaper on every billing option; the supplied annual figures show Fir lower", ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c1], severity: "high",
  remediation: "Proposal only: limit the claim to monthly billing (Cedar USD 12 vs Fir USD 15 per seat per month, before tax, November 2026 US plans) and state the annual figures accurately (Cedar USD 10 vs Fir USD 9 per seat per month equivalent), or remove the superlative.",
  verification: "Recompute each billing option from 01-competitor-claims.md:6-9 and confirm the revised wording is true for every option it names, with market, tax, date and billing scope retained." });
// 02
const c2 = add("02", "claim-sources", "claim-sources", "02-measurement-windows.md:3-16",
  "Owner-supplied synthetic counts, one campaign, USD, October 2026 (02-measurement-windows.md:3-8): spend complete for October 1-31 USD 3000; conversion export covers only October 1-7 with 35 completed conversions; no conversion data exists for October 8-31; October 1-7 spend USD 700. Independent referral report (lines 14-16): 15 October sessions have an identified AI-assistant referrer; other sessions have unknown origin; no model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists. Lines 20-21: do not combine the campaign conversion counts with the referral report; no citation annotations or generated answer captures supplied.");
review("02", "quality-claims", "fail",
  "Components: Draft A (line 10), verified-window caption (lines 11-12), referral observation (lines 14-15), Draft B (lines 17-18). Draft A divides full-month spend (October 1-31) by conversions measured only for October 1-7 and labels the result an October figure; October 8-31 conversions are unmeasured, not zero. Draft B asserts a one-in-ten tracking rate and a 150-session total with no supplied model or complete session count. The verified-window caption (700 / 35 = 20, October 1-7, remainder unmeasured) and the 15 identified-referrer sessions are supported and stay clean.", [c2]);
finding("02", { findingId: "d02-mismatched-windows", title: "Draft A reports an October cost per conversion from full-month spend and seven days of conversions", ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c2], severity: "high", ownerRole: "Analytics owner",
  remediation: "Proposal only: withdraw Draft A and report the matched-window figure already in the verified-window caption (October 1-7: USD 700 / 35 completed conversions = USD 20), stating that October 8-31 conversions are unmeasured. Report a full-month figure only after a conversion export covering October 8-31 is supplied.",
  verification: "Confirm numerator and denominator cover the same dates in the revised statement and recompute the division from 02-measurement-windows.md:5-8; confirm no wording treats October 8-31 conversions as zero." });
finding("02", { findingId: "d02-ai-referral-extrapolation", title: "Draft B extrapolates 15 identified AI-referrer sessions to 150 using an unsupplied one-in-ten tracking rate", ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c2], severity: "medium", ownerRole: "Analytics owner",
  remediation: "Proposal only: restate Draft B as the observation only, i.e. that 15 October sessions have an identified AI-assistant referrer and other sessions have unknown origin; remove 'prove', the 150 total and the one-in-ten rate unless a documented estimation model is supplied.",
  verification: "Check the revised statement against 02-measurement-windows.md:14-16: it should contain only the 15-session count and the unknown-origin caveat, and not be joined to the campaign conversion counts." });
// 03
const c3 = add("03", "claim-sources", "claim-sources", "03-template-service-area.md:4-5",
  "Owner-approved current policy (03-template-service-area.md:4-5): North serves same-day delivery, Monday-Friday, orders placed before 10:00 local time. South serves next-business-day delivery only. Lines 13-16: /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurately describing the 2024 service contract when South had same-day service, linking to the two current pages for new orders.");
const e3 = add("03", "entity-record", "entity-record", "03-template-service-area.md:4-5",
  "Owner-approved service record used as the authoritative comparison basis for this scenario (03-template-service-area.md:4-5): North = same-day delivery, Monday-Friday, orders placed before 10:00 local time; South = next-business-day delivery only.");
const m3 = add("03", "inventory-map", "inventory-map", "03-template-service-area.md:3-19",
  "Declared complete inventory (03-template-service-area.md:3): /north-delivery (current, North region), /south-delivery (current, South region), /terms-v1 (labeled 2024 archive for old orders, links to both current pages). Lines 18-19: the two current pages serve different regions, the owner wants both retained, shared layout and repeated generic contact wording are intentional. Only the policy passages are supplied as complete page text.");
review("03", "quality-claims", "fail",
  "Components: /north-delivery passage (lines 8-9), /south-delivery passage (lines 10-11), /terms-v1 description (lines 13-16). /south-delivery states same-day delivery while the approved current policy says South is next-business-day only. /north-delivery matches the approved policy. /terms-v1 is owner-confirmed as an accurate, labeled 2024 archive and stays clean.", [c3]);
review("03", "portfolio-contradictions", "fail",
  "Within the declared complete inventory, the current /south-delivery passage contradicts the approved service record for South. /north-delivery agrees with the record. /terms-v1 describing 2024 South same-day service is a labeled historical version, not a contradiction of current policy.", [e3, m3]);
review("03", "portfolio-duplication", "pass",
  "The three declared pages cover distinct tasks: North region, South region and a labeled 2024 archive for old orders. Owner context states the shared layout and repeated generic contact wording are intentional and both regional pages are to be retained. No query/page overlap or engine-selection data exists, so no cannibalization or consolidation is established. The wrongly repeated policy sentence on /south-delivery is recorded as a factual contradiction, not as a duplication defect. Limitation: only the policy passages were supplied as page text.", [m3]);
finding("03", { findingId: "d03-south-same-day", title: "/south-delivery promises same-day delivery; approved current policy for South is next-business-day only", ruleIds: ["quality-claims", "portfolio-contradictions"], dimensions: ["quality", "portfolio"], evidenceIds: [c3, e3, m3], severity: "high",
  remediation: "Proposal only: replace the /south-delivery policy passage with the approved South policy (next-business-day delivery only). Do not carry over the Monday-Friday, 10:00 cutoff or 'later delivery date' wording unless the owner supplies South-specific conditions. Keep /north-delivery, /terms-v1 and the shared layout unchanged.",
  verification: "Compare the revised /south-delivery passage with 03-template-service-area.md:4-5; confirm /north-delivery still matches line 4 and /terms-v1 remains labeled as the 2024 archive linking to both current pages." });
// 04
const c4 = add("04", "claim-sources", "claim-sources", "04-editorial-proof.md:3-13",
  "Approved product record (04-editorial-proof.md:3-5): for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes; the owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate. Approved permissions policy (lines 10-13): editors cannot delete a workspace and owners can; no additional conditions are needed to answer the permission question. /status-codes (lines 15-18): owner states the table is complete and accurate for its declared technical task; terse style and absence of a purchase CTA are approved.");
const q4 = add("04", "question-set", "question-set", "04-editorial-proof.md:8-13",
  "Sole supplied question (04-editorial-proof.md:9): \"Can editors delete the workspace?\" Declared task (lines 12-13): identify the permitted role, not perform the deletion procedure. No question is supplied for the landing-page claim or for /status-codes.");
review("04", "quality-claims", "fail",
  "Components: landing-page claim (line 6), permissions FAQ (line 9), /status-codes (lines 15-18). The landing claim asserts a universal guarantee of 10 minutes; the only supplied record is a median of 15 minutes across 20 observed sessions with no guarantee, maximum, distribution or population estimate. The FAQ answer matches the approved permissions policy. /status-codes is owner-confirmed complete and accurate for its declared task; the table itself was not supplied for independent inspection.", [c4]);
const aeoScope = "The only supplied question is the permissions FAQ question; the landing-page claim and /status-codes have no supplied question and are assessed under other rules. ";
review("04", "aeo-question-coverage", "pass", aeoScope + "The FAQ answers the question directly ('No. Only workspace owners can delete it.') and the declared task is to identify the permitted role, which the answer does.", [q4]);
review("04", "aeo-answer-context", "pass", aeoScope + "The answer names both the excluded role (editors) and the permitted role (workspace owners); owner context states no additional conditions are needed for this question.", [q4]);
review("04", "aeo-answer-evidence", "pass", aeoScope + "The FAQ answer matches the approved permissions policy, which states that editors cannot delete a workspace and owners can.", [c4]);
finding("04", { findingId: "d04-setup-guarantee", title: "Landing-page claim guarantees 10-minute setup for every team; the supplied record is a 15-minute median over 20 observed sessions", ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c4], severity: "high",
  remediation: "Proposal only: remove 'every team', 'guaranteed' and '10 minutes'. If a time is stated, use the supplied statistic with its scope, e.g. that in a supplied study of 20 observed onboarding sessions the median completion time was 15 minutes. No content change is authorized by this audit.",
  verification: "Compare the revised claim with 04-editorial-proof.md:3-5: statistic (median), value (15 minutes), sample (20 observed sessions) must match, with no guarantee, maximum or population-wide wording unless the owner supplies supporting records." });
writeFileSync(out, JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log(now, reviews.length, findings.length, evidence.length);
