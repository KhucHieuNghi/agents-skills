# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:27:38\.035Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 0f183701\-6474\-4c80\-a777\-d753aa74e8da\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | local\-file | 2026\-11\-16T17:27:37\.977Z | 0 full elapsed days | [evidence/63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f\.txt](evidence/63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | local\-file | 2026\-11\-16T17:27:37\.980Z | 0 full elapsed days | [evidence/6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291\.txt](evidence/6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | local\-file | 2026\-11\-16T17:27:37\.982Z | 0 full elapsed days | [evidence/76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14\.txt](evidence/76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | local\-file | 2026\-11\-16T17:27:37\.985Z | 0 full elapsed days | [evidence/9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a\.txt](evidence/9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
