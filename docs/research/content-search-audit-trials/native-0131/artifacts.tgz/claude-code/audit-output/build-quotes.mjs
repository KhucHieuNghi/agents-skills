import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const root = process.argv[2];
const hash = (b) => createHash("sha256").update(b).digest("hex");
const rep = readFileSync(root + "/report.md");
const lines = rep.toString("utf8").split("\n");
const quotes = [];
const OV = {
  "01-competitor-claims.md:12": "Fir pricing-table excerpt does not mention SSO.",
  "03-template-service-area.md:18": "The two current pages serve different regions and the owner wants both retained. Shared layout and repeated generic contact wording are intentional.",
  "04-editorial-proof.md:15": "Separate reference page /status-codes has a complete, accurate table for its declared technical task.",
};
const re = /`(0\d-[\w-]+\.md):(\d+)(?:-(\d+))?` — /g;
lines.forEach((line, i) => {
  for (const m of line.matchAll(re)) {
    const src = readFileSync(`${root}/targets/${m[1]}`);
    const s = +m[2], e = +(m[3] || m[2]);
    let quote = src.toString("utf8").split("\n").slice(s - 1, e).join(" ").replace(/\s+/g, " ").trim();
    const o = OV[`${m[1]}:${s}`]; if (o) { if (!quote.includes(o)) throw new Error("override not in source range"); quote = o; }
    quotes.push({ quoteId: `q${quotes.length + 1}`, source: `targets/${m[1]}`, sourceLabel: m[1], sourceHash: hash(src),
      startLine: s, endLine: e, reportStartLine: i + 1, reportEndLine: i + 1, normalization: "whitespace", quote });
  }
});
writeFileSync("quotes.json", JSON.stringify({ root, report: "report.md", reportHash: hash(rep), quotes }, null, 2) + "\n");
console.log(quotes.length);
