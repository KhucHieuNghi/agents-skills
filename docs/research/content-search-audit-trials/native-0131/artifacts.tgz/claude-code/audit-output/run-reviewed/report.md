# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:29:18\.254Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run d7b47bae\-f805\-49f3\-bcb9\-0cf4135599b1\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| d01\-every\-billing\-option | /compare assertion B claims Cedar is cheaper on every billing option; the supplied annual figures show Fir lower | quality\-claims | quality | high | high | observed | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: limit the claim to monthly billing \(Cedar USD 12 vs Fir USD 15 per seat per month, before tax, November 2026 US plans\) and state the annual figures accurately \(Cedar USD 10 vs Fir USD 9 per seat per month equivalent\), or remove the superlative\. | Recompute each billing option from 01\-competitor\-claims\.md:6\-9 and confirm the revised wording is true for every option it names, with market, tax, date and billing scope retained\. | Content owner | small | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce, d01\-claim\-sources |
| d01\-fir\-sso\-claim | /compare assertion A denies Fir SSO against the supplied Fir SSO documentation | quality\-claims | quality | high | high | observed | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: remove assertion A or replace it with the supplied fact, e\.g\. that Fir&\#39;s supplied SSO documentation states SAML SSO is available on Enterprise with a minimum of 20 paid seats\. Do not state that other Fir plans lack SSO; no statement is supplied for them\. | Compare the revised complete assertion with 01\-competitor\-claims\.md:12\-14; confirm it attributes the SSO fact to the SSO documentation, keeps the Enterprise and 20\-paid\-seat conditions, and makes no claim from the pricing table&\#39;s silence\. | Content owner | small | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce, d01\-claim\-sources |
| d02\-mismatched\-windows | Draft A reports an October cost per conversion from full\-month spend and seven days of conversions | quality\-claims | quality | high | high | observed | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: withdraw Draft A and report the matched\-window figure already in the verified\-window caption \(October 1\-7: USD 700 / 35 completed conversions = USD 20\), stating that October 8\-31 conversions are unmeasured\. Report a full\-month figure only after a conversion export covering October 8\-31 is supplied\. | Confirm numerator and denominator cover the same dates in the revised statement and recompute the division from 02\-measurement\-windows\.md:5\-8; confirm no wording treats October 8\-31 conversions as zero\. | Analytics owner | small | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b, d02\-claim\-sources |
| d03\-south\-same\-day | /south\-delivery promises same\-day delivery; approved current policy for South is next\-business\-day only | quality\-claims, portfolio\-contradictions | quality, portfolio | high | high | observed | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: replace the /south\-delivery policy passage with the approved South policy \(next\-business\-day delivery only\)\. Do not carry over the Monday\-Friday, 10:00 cutoff or &\#39;later delivery date&\#39; wording unless the owner supplies South\-specific conditions\. Keep /north\-delivery, /terms\-v1 and the shared layout unchanged\. | Compare the revised /south\-delivery passage with 03\-template\-service\-area\.md:4\-5; confirm /north\-delivery still matches line 4 and /terms\-v1 remains labeled as the 2024 archive linking to both current pages\. | Content owner | small | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962, d03\-claim\-sources, d03\-entity\-record, d03\-inventory\-map |
| d04\-setup\-guarantee | Landing\-page claim guarantees 10\-minute setup for every team; the supplied record is a 15\-minute median over 20 observed sessions | quality\-claims | quality | high | high | observed | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: remove &\#39;every team&\#39;, &\#39;guaranteed&\#39; and &\#39;10 minutes&\#39;\. If a time is stated, use the supplied statistic with its scope, e\.g\. that in a supplied study of 20 observed onboarding sessions the median completion time was 15 minutes\. No content change is authorized by this audit\. | Compare the revised claim with 04\-editorial\-proof\.md:3\-5: statistic \(median\), value \(15 minutes\), sample \(20 observed sessions\) must match, with no guarantee, maximum or population\-wide wording unless the owner supplies supporting records\. | Content owner | small | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be, d04\-claim\-sources |
| d02\-ai\-referral\-extrapolation | Draft B extrapolates 15 identified AI\-referrer sessions to 150 using an unsupplied one\-in\-ten tracking rate | quality\-claims | quality | medium | high | observed | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Proposal only: restate Draft B as the observation only, i\.e\. that 15 October sessions have an identified AI\-assistant referrer and other sessions have unknown origin; remove &\#39;prove&\#39;, the 150 total and the one\-in\-ten rate unless a documented estimation model is supplied\. | Check the revised statement against 02\-measurement\-windows\.md:14\-16: it should contain only the 15\-session count and the unknown\-origin caveat, and not be joined to the campaign conversion counts\. | Analytics owner | small | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b, d02\-claim\-sources |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | pending | Snapshot review incomplete | 26 |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | pending | Snapshot review incomplete | 26 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | pending | Snapshot review incomplete | 26 |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-claims | quality | fail | Components: Draft A \(line 10\), verified\-window caption \(lines 11\-12\), referral observation \(lines 14\-15\), Draft B \(lines 17\-18\)\. Draft A divides full\-month spend \(October 1\-31\) by conversions measured only for October 1\-7 and labels the result an October figure; October 8\-31 conversions are unmeasured, not zero\. Draft B asserts a one\-in\-ten tracking rate and a 150\-session total with no supplied model or complete session count\. The verified\-window caption \(700 / 35 = 20, October 1\-7, remainder unmeasured\) and the 15 identified\-referrer sessions are supported and stay clean\. | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b, d02\-claim\-sources |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d02\-extracted\-text |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-claims | quality | fail | Components: landing\-page claim \(line 6\), permissions FAQ \(line 9\), /status\-codes \(lines 15\-18\)\. The landing claim asserts a universal guarantee of 10 minutes; the only supplied record is a median of 15 minutes across 20 observed sessions with no guarantee, maximum, distribution or population estimate\. The FAQ answer matches the approved permissions policy\. /status\-codes is owner\-confirmed complete and accurate for its declared task; the table itself was not supplied for independent inspection\. | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be, d04\-claim\-sources |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d04\-extracted\-text |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-question\-coverage | aeo | pass | The only supplied question is the permissions FAQ question; the landing\-page claim and /status\-codes have no supplied question and are assessed under other rules\. The FAQ answers the question directly \(&\#39;No\. Only workspace owners can delete it\.&\#39;\) and the declared task is to identify the permitted role, which the answer does\. | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be, d04\-question\-set |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-answer\-context | aeo | pass | The only supplied question is the permissions FAQ question; the landing\-page claim and /status\-codes have no supplied question and are assessed under other rules\. The answer names both the excluded role \(editors\) and the permitted role \(workspace owners\); owner context states no additional conditions are needed for this question\. | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be, d04\-question\-set |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | aeo\-answer\-evidence | aeo | pass | The only supplied question is the permissions FAQ question; the landing\-page claim and /status\-codes have no supplied question and are assessed under other rules\. The FAQ answer matches the approved permissions policy, which states that editors cannot delete a workspace and owners can\. | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be, d04\-claim\-sources |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-claims | quality | fail | Components: /north\-delivery passage \(lines 8\-9\), /south\-delivery passage \(lines 10\-11\), /terms\-v1 description \(lines 13\-16\)\. /south\-delivery states same\-day delivery while the approved current policy says South is next\-business\-day only\. /north\-delivery matches the approved policy\. /terms\-v1 is owner\-confirmed as an accurate, labeled 2024 archive and stays clean\. | d03\-claim\-sources, f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d03\-extracted\-text |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-duplication | portfolio | pass | The three declared pages cover distinct tasks: North region, South region and a labeled 2024 archive for old orders\. Owner context states the shared layout and repeated generic contact wording are intentional and both regional pages are to be retained\. No query/page overlap or engine\-selection data exists, so no cannibalization or consolidation is established\. The wrongly repeated policy sentence on /south\-delivery is recorded as a factual contradiction, not as a duplication defect\. Limitation: only the policy passages were supplied as page text\. | d03\-inventory\-map, f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-contradictions | portfolio | fail | Within the declared complete inventory, the current /south\-delivery passage contradicts the approved service record for South\. /north\-delivery agrees with the record\. /terms\-v1 describing 2024 South same\-day service is a labeled historical version, not a contradiction of current policy\. | d03\-entity\-record, d03\-inventory\-map, f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-claims | quality | fail | Components: /compare assertion A \(line 17\), /compare assertion B \(line 18\), /monthly\-comparison caption \(lines 20\-23\)\. A conflicts with the supplied Fir SSO documentation \(line 13\) and treats a pricing\-table omission as proof\. B is false for annual billing \(Cedar USD 10 vs Fir USD 9 per seat per month equivalent\) though true for monthly \(USD 12 vs USD 15\)\. The monthly caption is supported \(15 \- 12 = 3, monthly plans, before tax\) and stays clean\. | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce, d01\-claim\-sources |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d01\-extracted\-text |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |
| 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1b5c251972841a6a2657c9c1031c273205883517a3855960776a3065031db83b | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | local\-file | 2026\-11\-16T17:27:37\.977Z | 0 full elapsed days | [evidence/63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f\.txt](evidence/63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3aa4589ad52dbe9ed0e40277351343cf6f628077f36bc708af14dfd236af86be | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | local\-file | 2026\-11\-16T17:27:37\.980Z | 0 full elapsed days | [evidence/6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291\.txt](evidence/6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f0dd8f8cf15e7920b3a02ab5e2a4c8e1ca9509f923c3c31843eaff0292428962 | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | local\-file | 2026\-11\-16T17:27:37\.982Z | 0 full elapsed days | [evidence/76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14\.txt](evidence/76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 34bcc0cbd0999d5acb59d61d691fc37d8402f8807aba95bf7a02589a43dcd0ce | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | local\-file | 2026\-11\-16T17:27:37\.985Z | 0 full elapsed days | [evidence/9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a\.txt](evidence/9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d01\-extracted\-text | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | identity\-text\-extraction | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d01\-extracted\-text\.txt](evidence/d01-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Identity extraction of the UTF\-8 Markdown dossier text; not a rendered page or live capture\. |
| d02\-extracted\-text | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | identity\-text\-extraction | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d02\-extracted\-text\.txt](evidence/d02-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Identity extraction of the UTF\-8 Markdown dossier text; not a rendered page or live capture\. |
| d03\-extracted\-text | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | identity\-text\-extraction | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d03\-extracted\-text\.txt](evidence/d03-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Identity extraction of the UTF\-8 Markdown dossier text; not a rendered page or live capture\. |
| d04\-extracted\-text | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | identity\-text\-extraction | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d04\-extracted\-text\.txt](evidence/d04-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Identity extraction of the UTF\-8 Markdown dossier text; not a rendered page or live capture\. |
| d01\-claim\-sources | 9736ec1cd2436dfb79aeb2693bcd2137d4c7763af8efb0c69a742deb1131595a | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d01\-claim\-sources\.txt](evidence/d01-claim-sources.txt) | cda563668c99a8e27f222d91bb014dbb473fdfe090c60a894671dfde7e3b0b4a | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d02\-claim\-sources | 63e5dadabb3bd67f7b0cac5463a41450c65e2550818b768ee8eb5fff21d3ce6f | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d02\-claim\-sources\.txt](evidence/d02-claim-sources.txt) | b0290dfb42fb0e4280c2ee988c040494fa1a944bab42815fda777057a1034fe1 | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d03\-claim\-sources | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d03\-claim\-sources\.txt](evidence/d03-claim-sources.txt) | dc2910f411b1db0f4ae9f4d23f863332cd3b83f637cbe81133fa50eb7eb4e159 | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d03\-entity\-record | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d03\-entity\-record\.txt](evidence/d03-entity-record.txt) | 7fec3362bf63a471abf4f7811c2e382f57e69e9bb48ce6bfae2b198ea92765b0 | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d03\-inventory\-map | 76f7c36084ed5e639d669e90440d7341d1bd385057b84c223602cecd7ae88e14 | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d03\-inventory\-map\.txt](evidence/d03-inventory-map.txt) | cf7e85a95491a1342ba72508a227ce207ad6f40220582db0a259b7da66fc558d | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d04\-claim\-sources | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d04\-claim\-sources\.txt](evidence/d04-claim-sources.txt) | d24fc83e854d48dbc7dc20d15ae5d10628b6c3c12df6f99f8cc7ed4140331275 | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| d04\-question\-set | 6e8ae44a0d67bd9ee8f00d5e2dd082c0c3042c6c721c5a05fac28da1bf346291 | host\-attributed\-context | 2026\-11\-16T17:29:18\.120Z | 0 full elapsed days | [evidence/d04\-question\-set\.txt](evidence/d04-question-set.txt) | 8d5e5b420ab8eac68c2f9381af5680d5a441ea77b5663024df7c80a90f6007e8 | Synthetic owner\-supplied statement inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
