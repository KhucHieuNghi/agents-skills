import fs from "node:fs";
import { createHash } from "node:crypto";
const lines = (file) => fs.readFileSync(file, "utf8").trimEnd().split("\n").map(JSON.parse);
const snapshots = lines("audit-artifacts/initial/evidence.jsonl").sort((a,b) => a.locator.localeCompare(b.locator));
const registry = JSON.parse(fs.readFileSync(".agents/skills/content-search-audit/rules/core.json")).rules;
const hash = (s) => createHash("sha256").update(s).digest("hex");
const findings = [
  [1,"fir-sso","The comparison denies Fir SSO",["quality-claims","aio-entity-consistency","aeo-answer-evidence"],"The supplied pricing excerpt is silent, and the supplied current product documentation explicitly supports Enterprise SAML SSO subject to a 20 paid-seat minimum.","State the documented Enterprise entitlement and paid-seat minimum for the November 2026 US scope. Leave other plans unverified.","Compare the full revised assertion with dossier lines 12–14 and check the Enterprise plan and seat qualifiers.","Product marketing","medium"],
  [1,"billing-options","The price comparison overgeneralizes across billing options",["quality-claims","aio-entity-consistency","aeo-answer-evidence"],"The monthly per-seat price favors Cedar, while the annual per-seat monthly equivalent favors Fir.","Present monthly and annual billing separately with USD before tax, per-seat units, and annual monthly-equivalent language.","Recalculate matched monthly and annual comparisons from lines 3–10. Preserve the supported monthly caption.","Product marketing","medium"],
  [2,"conversion-window","The October CPA uses mismatched date windows",["quality-claims"],"Full-month spend is divided by first-week conversions, with no conversion data for the rest of October.","Report the October 1–7 matched-window CPA and identify full October CPA as unavailable from the supplied rows.","Reconcile identical date windows, campaign, currency and completed-conversion definition; recalculate 700 divided by 35.","Campaign reporting","high"],
  [2,"referral-extrapolation","The AI referral total relies on an unsupported multiplier",["quality-claims"],"The report records 15 identified-referrer sessions and supplies no validated 10% tracking rate or causal basis.","Report the 15 October sessions with an identified AI-assistant referrer and leave unknown-origin sessions unattributed.","Tie the count to the independent referral rows and require an evidenced measurement model before estimating missed referrals.","Analytics","high"],
  [3,"south-delivery","The South page publishes the wrong delivery policy",["quality-task-fit","quality-claims","aio-entity-consistency","aeo-answer-evidence","portfolio-contradictions"],"The supplied complete South passage offers same-day service while the approved current South policy specifies next-business-day delivery only. The North and 2024 archive contexts support their own policies.","Replace the current South passage with the approved next-business-day-only policy and verify region and version inputs in the shared template.","Compare each current passage against the approved regional policy, including North’s weekday cutoff, and confirm the 2024 archive continues to route new orders to the current pages.","Service content owner","high"],
  [4,"setup-guarantee","The setup guarantee exceeds the onboarding evidence",["quality-claims","aeo-answer-evidence"],"The landing page states a universal 10-minute guarantee; the supplied study records a median of 15 minutes across 20 observed sessions and supplies no guarantee.","Report the observed median and sample size, or omit the quantified claim.","Match the entire revised claim to the approved study record and check that it carries no unsupported guarantee or extrapolation.","Product marketing","high"],
];
const bundle = {artifacts:{},evidence:[],reviews:[],findings:[]};
const now = new Date().toISOString();
const lookup = new Map();
const scope = fs.readFileSync("targets/context.md","utf8");
function add(n, kind, excerpt, locator, limitations) {
  const snapshot = snapshots[n-1];
  const evidenceId = ["dossier",n,kind].join("-");
  const artifact = "evidence/" + evidenceId + ".txt";
  const {byteLength, ...base} = snapshot;
  bundle.artifacts[artifact] = excerpt;
  bundle.evidence.push({...base, evidenceId, kind, artifact, value:excerpt, snapshotHash:hash(excerpt), collectedAt:now, locator, limitations, sourceEvidenceIds:[snapshot.evidenceId]});
  lookup.set(n + ":" + kind,evidenceId);
}
function source(n, kind, ranges) {
  const snapshot = snapshots[n-1];
  const name = snapshot.locator.split("/").at(-1);
  const locator = ranges.map(([a,b]) => name + ":" + a + (a === b ? "" : "-" + b)).join(", ");
  const excerpt = ranges.map(([a,b]) => snapshot.value.split("\n").slice(a-1,b).join("\n")).join("\n\n");
  add(n,kind,excerpt,locator,["Synthetic dossier evidence supplied by task owner; scope is local to this scenario."]);
}
for (const [i, snapshot] of snapshots.entries()) {
  const n = i + 1;
  add(n,"extracted-text",snapshot.value,"Text of " + snapshot.locator,["Identity extraction from inert UTF-8 Markdown; checks only nonempty text."]);
  add(n,"scope-context",scope,"targets/context.md:1-17",["Supplied scope and authorization; context is not an audited content item."]);
}
source(1,"claim-sources",[[3,14],[20,24]]);
source(1,"entity-record",[[3,14]]);
source(2,"claim-sources",[[3,8],[14,16],[20,21]]);
source(3,"claim-sources",[[3,6],[13,16]]);
source(3,"entity-record",[[4,5],[13,16]]);
source(3,"inventory-map",[[3,3],[13,20]]);
source(3,"audience-context",[[3,6],[13,20]]);
source(4,"claim-sources",[[3,5],[8,18]]);
source(4,"question-set",[[8,13]]);
function evidenceFor(n, ruleIds) {
  const kinds = new Set(registry.filter(r => ruleIds.includes(r.ruleId)).flatMap(r => r.requiredEvidence));
  return [...kinds].map(kind => {
    const id = kind === "content" ? snapshots[n-1].evidenceId : lookup.get(n + ":" + kind);
    if (!id) throw Error("Missing " + n + " " + kind);
    return id;
  });
}
function assess(n,ruleId,status,reason) {
  bundle.reviews.push({itemId:snapshots[n-1].itemId,ruleId,status,reason,evidenceIds:evidenceFor(n,[ruleId]),reviewer:"Offline dossier audit",reviewedAt:now});
}
for (const [n,findingId,title,ruleIds,reason,remediation,verification,ownerRole,severity] of findings) {
  bundle.findings.push({findingId,title,affectedItemIds:[snapshots[n-1].itemId],ruleIds,dimensions:[...new Set(registry.filter(r=>ruleIds.includes(r.ruleId)).map(r=>r.dimension))],evidenceIds:evidenceFor(n,ruleIds),severity,confidence:"high",classification:"observed",remediation,verification,ownerRole,effort:"small"});
}
for (let n=1;n<=4;n++) {
  for (const ruleId of new Set(findings.filter(f=>f[0]===n).flatMap(f=>f[3]))) {
    assess(n,ruleId,"fail",findings.filter(f=>f[0]===n && f[3].includes(ruleId)).map(f=>f[4]).join(" "));
  }
}
assess(3,"portfolio-duplication","pass","The complete three-item regional scenario has distinct North and South tasks and a separately labeled archive for 2024 orders. Shared structure/contact wording is intentional. No search overlap data supports a cannibalization judgment.");
assess(4,"aeo-question-coverage","pass","The only supplied question set concerns which role can delete a workspace. The complete FAQ answers it, and the landing claim and status-code reference serve different tasks. Broader answer support is assessed separately.");
fs.writeFileSync("audit-artifacts/review.json", JSON.stringify(bundle,null,2) + "\n");
console.log({monthlyUSD:15-12,annualMonthlyEquivalentUSD:10-9,misalignedQuotient:(3000/35).toFixed(2),matchedCPA:700/35});
