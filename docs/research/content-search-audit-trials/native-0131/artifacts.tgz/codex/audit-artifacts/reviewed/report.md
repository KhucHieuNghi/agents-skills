# Four independent synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:28:36\.116Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 29288d5a\-bb9f\-41d5\-99a6\-78f6737df15e\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| conversion\-window | The October CPA uses mismatched date windows | quality\-claims | quality | high | high | observed | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Report the October 1–7 matched\-window CPA and identify full October CPA as unavailable from the supplied rows\. | Reconcile identical date windows, campaign, currency and completed\-conversion definition; recalculate 700 divided by 35\. | Campaign reporting | small | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6, dossier\-2\-claim\-sources |
| referral\-extrapolation | The AI referral total relies on an unsupported multiplier | quality\-claims | quality | high | high | observed | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Report the 15 October sessions with an identified AI\-assistant referrer and leave unknown\-origin sessions unattributed\. | Tie the count to the independent referral rows and require an evidenced measurement model before estimating missed referrals\. | Analytics | small | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6, dossier\-2\-claim\-sources |
| setup\-guarantee | The setup guarantee exceeds the onboarding evidence | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Report the observed median and sample size, or omit the quantified claim\. | Match the entire revised claim to the approved study record and check that it carries no unsupported guarantee or extrapolation\. | Product marketing | small | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed, dossier\-4\-claim\-sources |
| south\-delivery | The South page publishes the wrong delivery policy | quality\-task\-fit, quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence, portfolio\-contradictions | quality, aio, aeo, portfolio | high | high | observed | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Replace the current South passage with the approved next\-business\-day\-only policy and verify region and version inputs in the shared template\. | Compare each current passage against the approved regional policy, including North’s weekday cutoff, and confirm the 2024 archive continues to route new orders to the current pages\. | Service content owner | small | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-audience\-context, dossier\-3\-claim\-sources, dossier\-3\-entity\-record, dossier\-3\-inventory\-map |
| billing\-options | The price comparison overgeneralizes across billing options | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | medium | high | observed | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Present monthly and annual billing separately with USD before tax, per\-seat units, and annual monthly\-equivalent language\. | Recalculate matched monthly and annual comparisons from lines 3–10\. Preserve the supported monthly caption\. | Product marketing | small | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba, dossier\-1\-claim\-sources, dossier\-1\-entity\-record |
| fir\-sso | The comparison denies Fir SSO | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | medium | high | observed | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | State the documented Enterprise entitlement and paid\-seat minimum for the November 2026 US scope\. Leave other plans unverified\. | Compare the full revised assertion with dossier lines 12–14 and check the Enterprise plan and seat qualifiers\. | Product marketing | small | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba, dossier\-1\-claim\-sources, dossier\-1\-entity\-record |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 4 | 8 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 9 | 11 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | pending | Snapshot review incomplete | 26 |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | pending | Snapshot review incomplete | 26 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | pending | Snapshot review incomplete | 26 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | quality\-claims | quality | fail | The supplied pricing excerpt is silent, and the supplied current product documentation explicitly supports Enterprise SAML SSO subject to a 20 paid\-seat minimum\. The monthly per\-seat price favors Cedar, while the annual per\-seat monthly equivalent favors Fir\. | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba, dossier\-1\-claim\-sources |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-1\-extracted\-text |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aio\-entity\-consistency | aio | fail | The supplied pricing excerpt is silent, and the supplied current product documentation explicitly supports Enterprise SAML SSO subject to a 20 paid\-seat minimum\. The monthly per\-seat price favors Cedar, while the annual per\-seat monthly equivalent favors Fir\. | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba, dossier\-1\-entity\-record |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | aeo\-answer\-evidence | aeo | fail | The supplied pricing excerpt is silent, and the supplied current product documentation explicitly supports Enterprise SAML SSO subject to a 20 paid\-seat minimum\. The monthly per\-seat price favors Cedar, while the annual per\-seat monthly equivalent favors Fir\. | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba, dossier\-1\-claim\-sources |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | quality\-claims | quality | fail | The landing page states a universal 10\-minute guarantee; the supplied study records a median of 15 minutes across 20 observed sessions and supplies no guarantee\. | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed, dossier\-4\-claim\-sources |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-4\-extracted\-text |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aeo\-question\-coverage | aeo | pass | The only supplied question set concerns which role can delete a workspace\. The complete FAQ answers it, and the landing claim and status\-code reference serve different tasks\. Broader answer support is assessed separately\. | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed, dossier\-4\-question\-set |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | aeo\-answer\-evidence | aeo | fail | The landing page states a universal 10\-minute guarantee; the supplied study records a median of 15 minutes across 20 observed sessions and supplies no guarantee\. | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed, dossier\-4\-claim\-sources |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | quality\-task\-fit | quality | fail | The supplied complete South passage offers same\-day service while the approved current South policy specifies next\-business\-day delivery only\. The North and 2024 archive contexts support their own policies\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-audience\-context |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | quality\-claims | quality | fail | The supplied complete South passage offers same\-day service while the approved current South policy specifies next\-business\-day delivery only\. The North and 2024 archive contexts support their own policies\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-claim\-sources |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-3\-extracted\-text |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aio\-entity\-consistency | aio | fail | The supplied complete South passage offers same\-day service while the approved current South policy specifies next\-business\-day delivery only\. The North and 2024 archive contexts support their own policies\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-entity\-record |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | aeo\-answer\-evidence | aeo | fail | The supplied complete South passage offers same\-day service while the approved current South policy specifies next\-business\-day delivery only\. The North and 2024 archive contexts support their own policies\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-claim\-sources |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | portfolio\-duplication | portfolio | pass | The complete three\-item regional scenario has distinct North and South tasks and a separately labeled archive for 2024 orders\. Shared structure/contact wording is intentional\. No search overlap data supports a cannibalization judgment\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-inventory\-map |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | portfolio\-contradictions | portfolio | fail | The supplied complete South passage offers same\-day service while the approved current South policy specifies next\-business\-day delivery only\. The North and 2024 archive contexts support their own policies\. | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4, dossier\-3\-entity\-record, dossier\-3\-inventory\-map |
| e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | quality\-claims | quality | fail | Full\-month spend is divided by first\-week conversions, with no conversion data for the rest of October\. The report records 15 identified\-referrer sessions and supplies no validated 10% tracking rate or causal basis\. | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6, dossier\-2\-claim\-sources |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dossier\-2\-extracted\-text |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |
| fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 537a18f2b78661aabdcdfdf9fb86d3f9ac44ce0f45a90ad497eddd2b95710bba | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | local\-file | 2026\-11\-16T17:27:26\.912Z | 0 full elapsed days | [evidence/181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf\.txt](evidence/181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 621281895e6eec5be5dd0a71e3057f480401084b67ed24b19ab66ef06e71d7ed | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | local\-file | 2026\-11\-16T17:27:26\.930Z | 0 full elapsed days | [evidence/b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8\.txt](evidence/b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0315012f85e0b2662d0d011d7c94533e2cb232b46439264a9e352375dd9c30e4 | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:27:26\.936Z | 0 full elapsed days | [evidence/e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50\.txt](evidence/e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2afb5f78de21dbf7603e4045e8d56248aab933604a6af7b3d0cd7eb58958c3a6 | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | local\-file | 2026\-11\-16T17:27:26\.943Z | 0 full elapsed days | [evidence/fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae\.txt](evidence/fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dossier\-1\-extracted\-text | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-1\-extracted\-text\.txt](evidence/dossier-1-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Identity extraction from inert UTF\-8 Markdown; checks only nonempty text\. |
| dossier\-1\-scope\-context | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-1\-scope\-context\.txt](evidence/dossier-1-scope-context.txt) | 300a81403b0666bc540a18d33815a9b5b65ae68dbbd76446e1bcba02996a63cc | Supplied scope and authorization; context is not an audited content item\. |
| dossier\-2\-extracted\-text | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-2\-extracted\-text\.txt](evidence/dossier-2-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Identity extraction from inert UTF\-8 Markdown; checks only nonempty text\. |
| dossier\-2\-scope\-context | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-2\-scope\-context\.txt](evidence/dossier-2-scope-context.txt) | 300a81403b0666bc540a18d33815a9b5b65ae68dbbd76446e1bcba02996a63cc | Supplied scope and authorization; context is not an audited content item\. |
| dossier\-3\-extracted\-text | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-extracted\-text\.txt](evidence/dossier-3-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Identity extraction from inert UTF\-8 Markdown; checks only nonempty text\. |
| dossier\-3\-scope\-context | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-scope\-context\.txt](evidence/dossier-3-scope-context.txt) | 300a81403b0666bc540a18d33815a9b5b65ae68dbbd76446e1bcba02996a63cc | Supplied scope and authorization; context is not an audited content item\. |
| dossier\-4\-extracted\-text | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-4\-extracted\-text\.txt](evidence/dossier-4-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Identity extraction from inert UTF\-8 Markdown; checks only nonempty text\. |
| dossier\-4\-scope\-context | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-4\-scope\-context\.txt](evidence/dossier-4-scope-context.txt) | 300a81403b0666bc540a18d33815a9b5b65ae68dbbd76446e1bcba02996a63cc | Supplied scope and authorization; context is not an audited content item\. |
| dossier\-1\-claim\-sources | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-1\-claim\-sources\.txt](evidence/dossier-1-claim-sources.txt) | a1855e988c2afeecde6433653800a1838ebbcefef7d62e99ee4fdb9070ff1c0e | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-1\-entity\-record | 181b3ae9b17a02203f6a37afc75fe4839ca46b9815cf7da60df7eee1add02ddf | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-1\-entity\-record\.txt](evidence/dossier-1-entity-record.txt) | 658452583dbf5ddd4076ccf73f235a54072ce859ff1e8d57e5ed46fc11102b5a | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-2\-claim\-sources | fdab04262021a6a011577a08055c2fcfedba6174b3520f4e7457ef2eb6ef0dae | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-2\-claim\-sources\.txt](evidence/dossier-2-claim-sources.txt) | 744f2f6af08b3c7e947eb8f5fe8e3348d527e4735896dd69ec802c3f6b1bfaa7 | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-3\-claim\-sources | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-claim\-sources\.txt](evidence/dossier-3-claim-sources.txt) | 5eab2c10c7eb9fdf898c7d9c246bb358d64827b5b4bd760c3ae78bc678dafeae | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-3\-entity\-record | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-entity\-record\.txt](evidence/dossier-3-entity-record.txt) | bf20970ad5f326afb1fed8c053beaae2e782006ce6b426576a8481ac67dd6ae5 | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-3\-inventory\-map | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-inventory\-map\.txt](evidence/dossier-3-inventory-map.txt) | 7275d17e3262b11a627da164c570f192d1ef727156f484477d49546893280023 | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-3\-audience\-context | e8966a8eab3fd1af1fc41ec4db07caf56a03207eb509c0218005b201146b4d50 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-3\-audience\-context\.txt](evidence/dossier-3-audience-context.txt) | 9d74e8f507caaa6b2c1bd6711d7766361c9d40d39555e774635b76b07c1dc02a | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-4\-claim\-sources | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-4\-claim\-sources\.txt](evidence/dossier-4-claim-sources.txt) | 71e2e7ea078cb13a06aba2cece685f552b3ca42124187f26b30af7faf194d524 | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |
| dossier\-4\-question\-set | b4b5a8133ea6df9f901c1ee66a844c517fe8b1222d6ee0bda0f2e15f88007ea8 | local\-file | 2026\-11\-16T17:28:35\.991Z | 0 full elapsed days | [evidence/dossier\-4\-question\-set\.txt](evidence/dossier-4-question-set.txt) | 1f89ad46d0a2bfdb5ddb4e7f4c7723d99999c180e6923b190a37f35276915238 | Synthetic dossier evidence supplied by task owner; scope is local to this scenario\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
