// Auditor-authored helper: builds the quote ledger from the tagged quotations in the final report.
// The quote text is taken from the REPORT (what was typed), then verified against source lines
// by the skill's verify-quotes command. Usage: node build-ledger.mjs PROJECT_ROOT OUTPUT_JSON
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const [root, outFile] = process.argv.slice(2);
if (!root || !outFile) throw new Error("Usage: PROJECT_ROOT OUTPUT_JSON");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = await readFile(path.join(root, "report.md"));
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const tag = /\*\*\[(Q\d+)\]\*\* `([^`:]+):(\d+)(?:-(\d+))?`/;
const sourceHashes = new Map();
const quotes = [];
for (let i = 0; i < lines.length; i++) {
  const match = tag.exec(lines[i]);
  if (!match) continue;
  const [, quoteId, label, start, end] = match;
  const source = `targets/${label}`;
  if (!sourceHashes.has(source))
    sourceHashes.set(source, hash(await readFile(path.join(root, source))));
  const next = lines[i + 1].trimStart();
  let quote;
  let last;
  if (next.startsWith("> ")) {
    quote = next.slice(2);
    last = i + 1;
  } else if (next.startsWith("```")) {
    const body = [];
    let j = i + 2;
    while (!lines[j].trimStart().startsWith("```")) body.push(lines[j++]);
    quote = body.join("\n");
    last = j;
  } else throw new Error(`Unrecognized quote block after ${quoteId}`);
  quotes.push({
    quoteId,
    source,
    sourceLabel: label,
    sourceHash: sourceHashes.get(source),
    startLine: Number(start),
    endLine: Number(end ?? start),
    reportStartLine: i + 1,
    reportEndLine: last + 1,
    normalization: "whitespace",
    quote,
  });
}
await writeFile(
  outFile,
  JSON.stringify(
    { root, report: "report.md", reportHash: hash(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(JSON.stringify({ outFile, quotes: quotes.length, ids: quotes.map((q) => q.quoteId) }));
