// Auditor-authored helper: builds the attributed review bundle from the initial run.
// Reads only the run's own collected snapshots; never modifies targets or the skill.
// Usage: node build-review.mjs INITIAL_RUN_DIR OUTPUT_REVIEW_JSON
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const [runDir, outFile] = process.argv.slice(2);
if (!runDir || !outFile) throw new Error("Usage: RUN_DIR OUTPUT_JSON");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jsonl = async (name) =>
  (await readFile(path.join(runDir, name), "utf8"))
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));

const inventory = await jsonl("inventory.jsonl");
const evidence = await jsonl("evidence.jsonl");
const item = (suffix) => inventory.find((i) => i.path.endsWith(suffix));
const routing = item("01-routing.md");
const markup = item("02-markup.md");
const content = (it) =>
  evidence.find((e) => e.itemId === it.itemId && e.kind === "content");
const rc = content(routing);
const mc = content(markup);
const now = new Date().toISOString();
const reviewer = "Claude (host review, content-search-audit skill)";

const artifacts = {};
const added = [];
function add(it, src, id, kind, locator, value, limitations, method) {
  const isJson = typeof value !== "string";
  const body = isJson ? JSON.stringify(value) : value;
  const artifact = `evidence/${id}.${isJson ? "json" : "txt"}`;
  artifacts[artifact] = body;
  added.push({
    evidenceId: id,
    itemId: it.itemId,
    kind,
    method,
    collectedAt: now,
    locator,
    snapshotHash: hash(body),
    byteLength: Buffer.byteLength(body),
    redaction: "none; synthetic supplied dossier content retained locally",
    limitations,
    sourceEvidenceIds: [src.evidenceId],
    artifact,
    encoding: isJson ? "json" : "utf8",
    value,
  });
  return id;
}
const derived = "derived-from-supplied-dossier-snapshot";
const synthetic =
  "Synthetic owner-supplied dossier statement; an approved comparison basis for this audit, not independent verification of live behaviour";

// ---------- Routing dossier (01-routing.md) ----------
const rLines = rc.value.split("\n");
const rSpan = (a, b) => rLines.slice(a - 1, b).join("\n");

add(
  routing,
  rc,
  "routing-publisher-intent",
  "publisher-intent",
  "01-routing.md:5-10; 01-routing.md:52-55",
  `Owner intent preserved from the task dossier (synthetic).\n01-routing.md:5-10:\n${rSpan(5, 10)}\n01-routing.md:52-55:\n${rSpan(52, 55)}`,
  [
    synthetic,
    "Intent is stated for Googlebot and the two guide URLs only; no intent is stated for other crawlers, AI-specific crawlers, snippets or training use",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-crawler-policy",
  "crawler-policy",
  "01-routing.md:12-20",
  `Supplied robots.txt export (section A), 01-routing.md:12-20:\n${rSpan(12, 20)}`,
  [
    synthetic,
    "robots.txt capture time, HTTP status and fetch user agent are not stated; the file was not requested by this audit",
    "A robots.txt rule is a crawl directive; it is not evidence of what Googlebot actually crawled or indexed",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-canonical-targets",
  "canonical-targets",
  "01-routing.md:33; 01-routing.md:46; 01-routing.md:52-55; 01-routing.md:8-10",
  `Declared canonical and related routing signals in the supplied capture.\n` +
    `Current guide /guide/current, 01-routing.md:33:\n${rSpan(33, 33)}\n` +
    `Sitemap export, 01-routing.md:46:\n${rSpan(46, 46)}\n` +
    `Archive /guide/2024 and redirect state, 01-routing.md:52-55:\n${rSpan(52, 55)}\n` +
    `Missing engine data, 01-routing.md:8-10:\n${rSpan(8, 10)}`,
  [
    synthetic,
    "Declared canonicals only; engine-selected canonical is unavailable",
    "Only Content-Type is shown among response headers; whether an HTTP Link canonical header exists is not established",
    "The archive self-canonical is narrated by the dossier, not shown as captured markup",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-http-response",
  "http-response",
  "01-routing.md:24-27; 01-routing.md:52; 01-routing.md:9-10",
  {
    status: 200,
    url: "https://routing.example.test/guide/current",
    statusLine: "HTTP/1.1 200 OK",
    contentType: "text/html; charset=utf-8",
    captureUserAgent: "ordinary browser user agent, not Googlebot (dossier lines 9-10)",
    otherComponents: [
      {
        url: "/guide/2024",
        status: 200,
        basis: "narrated in dossier line 52 ('The archive returns HTTP 200'), no captured header block",
      },
    ],
    synthetic: true,
  },
  [
    synthetic,
    "Captured by an ordinary browser user agent, not Googlebot; the response served to Googlebot is unknown",
    "Capture timestamp is not stated in the dossier",
    "HTTP 200 does not establish crawlability under robots.txt, index status or rendered completeness",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-claim-sources",
  "claim-sources",
  "01-routing.md:5; 01-routing.md:52-54",
  `Owner statements usable as a comparison basis for guide claims (synthetic).\n01-routing.md:5:\n${rSpan(5, 5)}\n01-routing.md:52-54:\n${rSpan(52, 54)}`,
  [
    synthetic,
    "The owner confirms the archive statement for its historical scope and names the approved current guide as of 2026-11-16; no separate record confirms the current entitlement value of 3 seats",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-entity-record",
  "entity-record",
  "01-routing.md:5-7; 01-routing.md:37; 01-routing.md:52-54",
  `Version/entitlement record assembled from the dossier (synthetic).\n` +
    `Approved current guide as of 2026-11-16: /guide/current (01-routing.md:5).\n` +
    `Historical guide: /guide/2024, to remain accessible and clearly labeled, not preferred (01-routing.md:6-7).\n` +
    `Current guide visible claim (01-routing.md:37): ${rSpan(37, 37).trim()}\n` +
    `Archive visible claim and owner confirmation (01-routing.md:52-54):\n${rSpan(52, 54)}`,
  [
    synthetic,
    "Owner-supplied version roles; the current entitlement value is the page's own claim and is not separately confirmed",
  ],
  derived,
);
add(
  routing,
  rc,
  "routing-inventory-map",
  "inventory-map",
  "01-routing.md:12-55",
  `Component map of the routing dossier (one inventory item, four supplied components).\n` +
    `A robots.txt export, lines 12-20: crawl policy for routing.example.test.\n` +
    `B /guide/current response and raw HTML, lines 22-40: approved current public product guide.\n` +
    `C sitemap export, lines 42-48: lists /guide/current only.\n` +
    `D /guide/2024 archive and owner context, lines 50-55: historical document, narrated not captured as markup.\n` +
    `Relationship: B and D are current and historical versions of the product guide; the owner requires both to remain accessible.`,
  [
    "Auditor-derived map of the supplied dossier only; it does not enumerate the live site",
    "Component D body, title and links are not supplied beyond one visible statement",
  ],
  "auditor-derived-map",
);
add(
  routing,
  rc,
  "routing-extracted-text",
  "extracted-text",
  "01-routing.md:1-55",
  rc.value,
  [
    "Identity extraction of the UTF-8 Markdown dossier; it is not rendered page text of either guide URL",
  ],
  "identity-text-extraction",
);

// ---------- Markup dossier (02-markup.md) ----------
const mLines = mc.value.split("\n");
const mSpan = (a, b) => mLines.slice(a - 1, b).join("\n");
// Strict JSON syntax check of the supplied data blocks (data parsing only; no target script is executed).
function strictJson(textBlock) {
  try {
    JSON.parse(textBlock);
    return "parses as strict JSON (RFC 8259)";
  } catch (error) {
    return `does NOT parse as strict JSON (RFC 8259): ${error.message}`;
  }
}
const blockA = mSpan(14, 18);
const blockB = mSpan(29, 33);
add(
  markup,
  mc,
  "markup-schema-extraction",
  "schema-extraction",
  "02-markup.md:13-19; 02-markup.md:28-34",
  `JSON-LD blocks extracted verbatim from the supplied raw-source excerpts (synthetic).\n` +
    `Page A, 02-markup.md:13-19:\n${mSpan(13, 19)}\n` +
    `Strict syntax check of the object at lines 14-18 with Node JSON.parse: ${strictJson(blockA)}\n` +
    `Page B, 02-markup.md:28-34:\n${mSpan(28, 34)}\n` +
    `Strict syntax check of the object at lines 29-33 with Node JSON.parse: ${strictJson(blockB)}\n` +
    `Visible text for comparison: Page A 02-markup.md:9-10; Page B 02-markup.md:24-25.`,
  [
    synthetic,
    "Raw-source excerpts only; no rendered DOM, no other markup formats and no rich-result test output are supplied",
    "A strict JSON syntax result does not establish how any particular search or AI consumer handles the block",
  ],
  "verbatim-extraction-plus-strict-json-parse",
);
add(
  markup,
  mc,
  "markup-http-response",
  "http-response",
  "02-markup.md:4",
  {
    status: 200,
    basis: "Dossier statement at line 4: 'Both pages return HTTP 200.'",
    pages: ["Page A: current library overview", "Page B: current export reference"],
    synthetic: true,
  },
  [
    synthetic,
    "Narrated status for both pages; no header block, URL, user agent or capture time is supplied",
    "HTTP 200 does not establish index status or rendered content",
  ],
  derived,
);
add(
  markup,
  mc,
  "markup-publisher-intent",
  "publisher-intent",
  "02-markup.md:37-40",
  `Owner request preserved from the task dossier (synthetic), 02-markup.md:37-40:\n${mSpan(37, 40)}`,
  [
    synthetic,
    "States the desired markup outcome only; no indexing, crawler or snippet intent is stated",
  ],
  derived,
);
add(
  markup,
  mc,
  "markup-inventory-map",
  "inventory-map",
  "02-markup.md:7-34",
  `Component map of the markup dossier (one inventory item, two supplied pages of one English documentation site).\n` +
    `Page A, lines 7-20: current library overview; visible heading "Cedar Library".\n` +
    `Page B, lines 22-35: current export reference; visible heading "Export reference".\n` +
    `Relationship: an overview page and a task-specific reference page for the same library.`,
  [
    "Auditor-derived map of the supplied dossier only; it does not enumerate the documentation site",
    "Only the heading, one visible sentence and one JSON-LD block are supplied per page",
  ],
  "auditor-derived-map",
);
add(
  markup,
  mc,
  "markup-extracted-text",
  "extracted-text",
  "02-markup.md:1-40",
  mc.value,
  [
    "Identity extraction of the UTF-8 Markdown dossier; it is not rendered page text of either documentation page",
  ],
  "identity-text-extraction",
);

// ---------- Reviews ----------
const reviews = [];
const R = routing.itemId;
const M = markup.itemId;
const review = (itemId, base, ruleId, status, reason, ids = []) =>
  reviews.push({
    itemId,
    ruleId,
    status,
    reason,
    evidenceIds: [base.evidenceId, ...ids],
    reviewer,
    reviewedAt: now,
  });
const r = (...a) => review(R, rc, ...a);
const m = (...a) => review(M, mc, ...a);

// Routing: failures
r(
  "seo-index-controls",
  "fail",
  "Component A (robots.txt, lines 15-16) disallows /guide/current for Googlebot, while the owner states (lines 7-8) that Googlebot should crawl the current guide. The Googlebot group is the specific group for that crawler, so the wildcard Allow (lines 18-19) does not apply to it. Clean within this rule: no noindex or snippet directive appears in the captured current-guide HTML, and the archive path is not disallowed. Unknown: Googlebot's actual crawl and index state, the response served to Googlebot, and any X-Robots-Tag header (only Content-Type is shown).",
  ["routing-http-response", "routing-publisher-intent", "routing-crawler-policy"],
);
r(
  "aio-crawler-policy",
  "fail",
  "Same defect as seo-index-controls, consolidated in finding F1: the only crawler for which the owner states an intent is Googlebot, and the supplied robots.txt blocks it from the current guide. Google-search AI features draw on Google's search crawl per the packaged method baseline reviewed 2026-11-16, so the block also bears on that surface. No owner intent is stated for other search, training or user-triggered AI crawlers; the wildcard group is left unassessed for them and no change is proposed.",
  ["routing-crawler-policy", "routing-publisher-intent"],
);
r(
  "seo-canonical",
  "fail",
  "Component B (line 33) declares the archive /guide/2024 as canonical for /guide/current, while the owner states (lines 5-7) that /guide/current is the approved guide and the archive is not the preferred current guide. The sitemap lists /guide/current (line 46), so the sitemap and the page's own canonical disagree. Clean components: the sitemap entry matches owner intent; the archive's self-canonical (line 53) is consistent with keeping it as a separate historical document. Unknown: engine-selected canonical (no data), any HTTP Link canonical header.",
  ["routing-canonical-targets", "routing-publisher-intent"],
);
// Routing: clean
r(
  "portfolio-duplication",
  "pass",
  "The current guide and the 2024 archive are owner-designated version variants with different, explicitly scoped statements (current 3 seats; 2024 archive, former 2 seats). The owner requires the archive to stay accessible, so no consolidation is proposed. Caveat: the archive body is supplied only as one narrated statement; this verdict covers the supplied components.",
  ["routing-inventory-map"],
);
r(
  "portfolio-contradictions",
  "pass",
  "No contradiction: 'Current entitlement: 3 seats' (line 37) and '2024 archive — former entitlement: 2 seats' (lines 52-53) carry different explicit time scopes, and the owner confirms the archive statement is accurate for its historical scope. Caveat: the current value of 3 seats is not separately confirmed (see quality-claims, unknown). The conflicting canonical signal is a routing defect recorded under seo-canonical, not a content contradiction.",
  ["routing-entity-record", "routing-inventory-map"],
);
// Routing: unresolved
const rUnknown = {
  "quality-task-fit":
    "No audience task beyond 'public product guide' is supplied and both guide bodies are fixture-sized; fit cannot be judged.",
  "quality-claims":
    "Archive claim (2 seats, former) is supported by the owner statement at lines 53-54. The current guide's '3 seats' (line 37) has no separate supporting record in the dossier; it is unverified, not contradicted. Item-wide verdict stays unknown.",
  "quality-freshness":
    "Version labelling is explicit for both guides and the archive is confirmed accurate for its historical scope; whether '3 seats' is the current value is not separately evidenced, so the item-wide verdict stays unknown.",
  "quality-accessible-media":
    "The captured current-guide HTML (lines 30-39) contains no media elements; the archive body is not supplied. No media inventory exists for the item.",
  "seo-metadata":
    "Current guide title and h1 (lines 32, 36) both read 'Current product guide', consistent with the owner's designation; no meta description is in the capture. Archive title/metadata are not supplied. No audience context beyond 'public product guide'.",
  "seo-internal-links":
    "No link graph. The captured current-guide HTML contains no links; archive markup is not supplied, so whether the two guides link to each other is unknown.",
  "seo-structured-data":
    "No structured data appears in the captured current-guide raw HTML; none is requested by the owner; archive markup and rendered DOM are not supplied. Raw absence is not a defect.",
  "seo-locales":
    "html lang='en' on the current guide; no locale variants or locale map are supplied.",
  "seo-rendering":
    "No rendered DOM is supplied. The captured current-guide HTML contains no scripts; archive markup is not supplied.",
  "aio-entity-consistency":
    "Version roles are consistent in the visible text, but no authoritative product/entitlement record confirms the current value.",
  "aio-retrievable-facts":
    "The entitlement fact is present in plain captured HTML, but no audience/task context is supplied to judge which facts are needed; retrieval by any engine is unmeasured.",
  "aeo-question-coverage": "No question set is supplied.",
  "aeo-answer-context": "No question set is supplied.",
  "aeo-answer-evidence":
    "No question set or separate source for the current entitlement claim is supplied.",
  "geo-observed-presence":
    "No AI response observations are supplied; visibility is unmeasured, not zero.",
  "geo-answer-accuracy": "No AI response observations are supplied.",
  "geo-cohort-validity": "No AI response observations or prompt cohort are supplied.",
  "portfolio-task-gaps": "No question set or demand evidence is supplied.",
  "portfolio-journey-links":
    "No link graph or audience context; navigation between current guide and archive is not shown.",
};
for (const [ruleId, reason] of Object.entries(rUnknown)) r(ruleId, "unknown", reason);

// Markup: failure
m(
  "seo-structured-data",
  "fail",
  "Page A's JSON-LD object (lines 14-18) has a trailing comma after the name member (line 17), so the block is not valid JSON and a strict parser rejects it; the owner asks for correct machine-readable descriptions (lines 37-38). Clean component: Page B's block (lines 28-34) parses, uses WebPage, and its name matches the visible heading 'Export reference'. Page A's intended type and name also match its visible heading; only the syntax is defective. No Product, FAQPage, review or rating markup is present or proposed. Unknown: rendered DOM, how any specific consumer handles the malformed block, rich-result eligibility (not requested, not tested).",
  ["markup-schema-extraction", "markup-publisher-intent"],
);
// Markup: clean
m(
  "portfolio-duplication",
  "pass",
  "Page A (library overview) and Page B (export reference) serve distinct purposes per their supplied labels, headings and visible sentences; no duplication is indicated and no consolidation is proposed. Caveat: only one visible sentence per page is supplied.",
  ["markup-inventory-map"],
);
const mUnknown = {
  "quality-task-fit":
    "Only a heading and one sentence per page are supplied and no audience task is stated; fit cannot be judged.",
  "quality-claims":
    "'maintained by Cedar Tools' (lines 9-10) has no supporting record in the dossier; unverified, not contradicted.",
  "quality-freshness":
    "Both pages are labelled current by the dossier; no version or date record is supplied.",
  "quality-accessible-media": "No media inventory or full page source is supplied.",
  "seo-index-controls":
    "No index or snippet directives, robots policy or indexing intent are supplied; indexed state is stated as not supplied (line 5).",
  "seo-canonical": "No canonical declarations or URLs are supplied.",
  "seo-metadata":
    "Title elements and descriptions are not supplied; only visible headings. No audience context.",
  "seo-internal-links": "No links or link graph are supplied.",
  "seo-locales": "The site is described as English; no locale variants or locale map are supplied.",
  "seo-rendering":
    "No rendered snapshots are supplied (lines 39-40); whether rendering alters the JSON-LD is unknown.",
  "aio-crawler-policy": "No crawler policy or crawler intent is supplied.",
  "aio-entity-consistency":
    "'Cedar Library' is used consistently in Page A's heading, text and JSON-LD name and in Page B's text; no authoritative entity record is supplied to compare against.",
  "aio-retrievable-facts":
    "The supplied visible sentences are plain text, but no audience/task context is supplied; retrieval by any engine is unmeasured.",
  "aeo-question-coverage": "No question set is supplied.",
  "aeo-answer-context": "No question set is supplied.",
  "aeo-answer-evidence": "No question set or claim sources are supplied.",
  "geo-observed-presence":
    "No AI-answer observations are supplied (line 5); visibility is unmeasured, not zero.",
  "geo-answer-accuracy": "No AI-answer observations are supplied.",
  "geo-cohort-validity": "No AI-answer observations or prompt cohort are supplied.",
  "portfolio-task-gaps": "No question set or demand evidence is supplied.",
  "portfolio-contradictions":
    "No conflicting claims are visible between the two pages, but no authoritative entity record is supplied to resolve against.",
  "portfolio-journey-links": "No link graph or audience context is supplied.",
};
for (const [ruleId, reason] of Object.entries(mUnknown)) m(ruleId, "unknown", reason);

// ---------- Findings ----------
const findings = [
  {
    findingId: "F1-googlebot-blocked-from-current-guide",
    title:
      "robots.txt blocks Googlebot from the current guide the owner wants crawled (SEO + AIO, one issue)",
    affectedItemIds: [R],
    affectedComponents: ["01-routing.md section A robots.txt", "/guide/current"],
    ruleIds: ["seo-index-controls", "aio-crawler-policy"],
    dimensions: ["seo", "aio"],
    evidenceIds: [
      rc.evidenceId,
      "routing-crawler-policy",
      "routing-publisher-intent",
      "routing-http-response",
    ],
    severity: "high",
    confidence: "high",
    classification: "observed",
    observation:
      "robots.txt lines 15-16 give Googlebot its own group with 'Disallow: /guide/current'; the owner states Googlebot should crawl the current guide. Observed as a directive/intent conflict in the supplied export; Googlebot's actual crawl and index state are not measured.",
    remediation:
      "Proposal only (owner has not authorized config edits): in a separately authorized change, remove the 'Disallow: /guide/current' line from the Googlebot group, keeping any other Googlebot restrictions the owner intends. Leave the wildcard group and the archive untouched. Coordinate with F2, because once crawling is allowed Googlebot will read the current guide's canonical.",
    verification:
      "Re-read the revised robots.txt export and confirm that no rule in the group applying to Googlebot matches the path /guide/current. Then obtain owner-supplied evidence of a Googlebot-identified fetch of /guide/current (for example normalized server-log rows); availability of any search-engine console report is not verified in this offline audit.",
    ownerRole: "Web platform / technical SEO owner of robots.txt",
    effort: "small",
    action: "update",
    actionReason:
      "The supplied directive directly contradicts the stated crawl intent; the change is a one-line policy edit that requires separate owner authorization.",
  },
  {
    findingId: "F2-current-guide-canonical-points-to-archive",
    title: "Current guide declares the 2024 archive as its canonical",
    affectedItemIds: [R],
    affectedComponents: ["/guide/current raw HTML head"],
    ruleIds: ["seo-canonical"],
    dimensions: ["seo"],
    evidenceIds: [rc.evidenceId, "routing-canonical-targets", "routing-publisher-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    observation:
      "Line 33 of the captured /guide/current HTML names /guide/2024 as canonical, although the owner designates /guide/current as the approved guide and the archive as not preferred. The sitemap lists /guide/current. Engine-selected canonical is unavailable.",
    remediation:
      "Proposal only: in a separately authorized change, set the canonical on /guide/current to https://routing.example.test/guide/current. Keep the archive at HTTP 200 with its self-canonical and historical label; do not add a redirect or delete it.",
    verification:
      "Re-capture the raw HTML of /guide/current and confirm exactly one rel=canonical whose href is the /guide/current URL; confirm the archive still self-canonicalizes and the sitemap entry is unchanged. Engine-selected canonical can be confirmed only from owner-supplied engine data, which is currently unavailable.",
    ownerRole: "Web platform / template owner for the guide pages",
    effort: "small",
    action: "update",
    actionReason:
      "The declared canonical contradicts the owner's stated preferred URL and the sitemap; correcting it is a single-attribute change requiring separate owner authorization.",
  },
  {
    findingId: "F3-page-a-jsonld-trailing-comma",
    title: "Page A JSON-LD is not valid JSON (trailing comma)",
    affectedItemIds: [M],
    affectedComponents: ["Page A: current library overview"],
    ruleIds: ["seo-structured-data"],
    dimensions: ["seo"],
    evidenceIds: [mc.evidenceId, "markup-schema-extraction", "markup-publisher-intent"],
    severity: "medium",
    confidence: "high",
    classification: "observed",
    observation:
      "The JSON-LD object on Page A ends its last member with a comma before the closing brace; strict JSON parsing rejects it. Page B's block is syntactically valid and consistent with its visible heading.",
    remediation:
      "Proposal only: remove the trailing comma after the name member in Page A's JSON-LD so the object ends with \"name\": \"Cedar Library\" followed by the closing brace. Keep @type WebPage; do not add Product, FAQPage, review or rating markup.",
    verification:
      "Extract the revised block from Page A's raw source and parse it with a strict JSON parser; confirm @type is WebPage and name equals the visible heading 'Cedar Library'. Rendered output and consumer handling need a supplied rendered snapshot or test output, which this audit does not have.",
    ownerRole: "Documentation site template / front-end owner",
    effort: "small",
    action: "update",
    actionReason:
      "The owner asks for correct machine-readable descriptions and the supplied block fails strict JSON syntax; the fix is a one-character edit.",
  },
];

await writeFile(
  outFile,
  JSON.stringify({ artifacts, evidence: added, reviews, findings }, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    outFile,
    reviewedAt: now,
    evidenceAdded: added.length,
    reviews: reviews.length,
    findings: findings.length,
    jsonCheckA: strictJson(blockA),
    jsonCheckB: strictJson(blockB),
  }),
);
