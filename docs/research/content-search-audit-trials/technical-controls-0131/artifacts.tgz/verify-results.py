from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).resolve().parent
pre=json.loads((root/'preflight.json').read_text())
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for host,prefix in [('codex','.agents'),('claude-code','.claude')]:
 project=root/host
 changed=[name for name,digest in pre['inputs'][host].items() if not (project/name).is_file() or h(project/name)!=digest]
 runs=[]
 for manifest in project.rglob('run.json'):
  if prefix in manifest.parts:continue
  try:data=json.loads(manifest.read_text())
  except (ValueError,UnicodeError):continue
  if not isinstance(data,dict) or not data.get('runId'):continue
  command=['rtk','proxy','node',str(project/prefix/'skills/content-search-audit/scripts/audit.mjs'),'validate',str(manifest.parent)]
  p=subprocess.run(command,capture_output=True,text=True)
  try:v=json.loads(p.stdout)
  except ValueError:v={'stdout':p.stdout,'stderr':p.stderr}
  checks=[json.loads(line) for line in (manifest.parent/'checks.jsonl').read_text().splitlines() if line]
  findings=json.loads((manifest.parent/'findings.json').read_text())
  runs.append({'directory':str(manifest.parent.relative_to(project)),'exitCode':p.returncode,'validation':v,'checkStatuses':{status:sum(c['status']==status for c in checks) for status in ['pass','fail','unknown','not-applicable']},'findings':findings})
 results[host]={'changedOriginalFiles':changed,'originalFileCount':len(pre['inputs'][host]),'runs':runs}
(root/'independent-validation.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({host:{'changed':v['changedOriginalFiles'],'runs':len(v['runs']),'valid':all(r['exitCode']==0 and r['validation'].get('valid') for r in v['runs'])} for host,v in results.items()}))
