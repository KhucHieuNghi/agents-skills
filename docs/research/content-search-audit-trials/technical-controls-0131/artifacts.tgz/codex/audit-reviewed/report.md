# Independent synthetic scenarios — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:03:14\.753Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 5cc762ce\-bb1a\-4436\-8a4c\-14d6bf07ce14\. 3 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F01 | Googlebot blocked from the current guide | aio\-crawler\-policy | aio | high | high | observed | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | update | reviewer\-proposal | Restores a crawl prerequisite for the approved current guide\. | For /guide/current, remove or narrow the specific Googlebot disallow through an approved configuration change\. Preserve unrelated rules\. | Evaluate /guide/current against the revised robots groups for Googlebot with an offline rule test\. With later authorized evidence, confirm deployed rules and actual crawler access separately\. | Web platform | small | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e, 01\-owner\-intent, 01\-robots\-policy |
| F02 | Current guide declares the historical guide as canonical | seo\-canonical | seo | high | high | observed | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | update | reviewer\-proposal | Aligns declared signals with the current and historical page roles\. | Set /guide/current to self\-canonical\. Keep it in the sitemap\. Retain /guide/2024 as a labeled historical page with its own canonical\. | Compare revised HTML, any HTTP Link canonicals, sitemap and archive declarations\. If authorized later, check the engine\-selected canonical after recrawl\. | Web platform | small | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e, 01\-canonical\-signals, 01\-owner\-intent |
| F03 | Library overview JSON\-LD is malformed | seo\-structured\-data | seo | medium | high | observed | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | update | reviewer\-proposal | Restores a parseable machine\-readable description for the overview\. | Remove the trailing comma after the final name property in Page A\. Retain WebPage and the visible matching name\. | Strict\-parse the revised script payload, compare type/name with visible content, and repeat on Page B as a regression check\. Inspect rendered output only if later supplied\. | Documentation engineering | small | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619, 02\-raw\-jsonld, 02\-owner\-intent |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 3 | 5 | 0 |
| quality | 10 | 2 | 8 | 0 |
| seo | 16 | 4 | 12 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | pending | Snapshot review incomplete | 26 |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 02\-dossier\-text |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 02\-supplied\-status |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-structured\-data | seo | fail | The overview JSON\-LD fails strict JSON parsing at the final property comma\. The export reference parses and its WebPage name matches its reported heading\. Rendered/other markup and feature eligibility remain unknown\. | 02\-owner\-intent, 02\-raw\-jsonld, c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | portfolio\-duplication | portfolio | pass | Library overview and export reference serve different tasks in the declared portfolio\. The shared product name does not establish duplication\. | 02\-documentation\-roles, c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 01\-dossier\-text |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 01\-supplied\-guide\-status |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-canonical | seo | fail | The current guide declares the historical URL despite current\-guide approval and sitemap membership\. The archive self\-canonical is consistent with its historical scope\. | 01\-canonical\-signals, 01\-owner\-intent, feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aio\-crawler\-policy | aio | fail | The explicit Googlebot group disallows /guide/current despite the owner’s stated crawl intent\. The wildcard allow and ordinary\-browser 200 do not override it\. | 01\-owner\-intent, 01\-robots\-policy, feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | portfolio\-duplication | portfolio | pass | Current and historical guide serve distinct version scopes in the supplied inventory\. The conflicting canonical is tracked separately\. | 01\-guide\-roles, feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | portfolio\-contradictions | portfolio | pass | The observed current and former entitlement statements apply to different time scopes\. The owner expressly supports the historical statement\. No same\-scope factual contradiction is observed in the supplied components\. | 01\-entitlement\-scopes, 01\-guide\-roles, feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |
| 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| c29fd25941918f631d9c1d4e01b612d5a947bd2b9f7f0d1181b468ec2bb36619 | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | local\-file | 2026\-11\-16T17:01:50\.910Z | 0 full elapsed days | [evidence/0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988\.txt](evidence/0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| feffa6a10d8e5f1f6f207678a999e194a7d55268755c37fa47a6e16c0483a17e | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | local\-file | 2026\-11\-16T17:01:50\.914Z | 0 full elapsed days | [evidence/4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556\.txt](evidence/4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 02\-dossier\-text | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/02\-dossier\-text\.txt](evidence/02-dossier-text.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Verbatim UTF\-8 Markdown dossier text extraction\. This captures readability of the supplied file only\. |
| 01\-dossier\-text | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-dossier\-text\.txt](evidence/01-dossier-text.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Verbatim UTF\-8 Markdown dossier text extraction\. This captures readability of the supplied file only\. |
| 01\-owner\-intent | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-owner\-intent\.txt](evidence/01-owner-intent.txt) | 8076824170e6f1b2e464d67f8b2d2729221ca1fbb10bb8f8baf502a2acce435c | Synthetic owner\-supplied intent\. Approval is dated 2026\-11\-16\. Original HTTP capture timestamp is unspecified\. |
| 01\-robots\-policy | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-robots\-policy\.txt](evidence/01-robots-policy.txt) | eecfd728c2e354c9b29450b5e0014fee24cb006492b051207222a982e86eccac | Supplied robots\.txt export\. Googlebot\-specific group takes precedence over the wildcard group\. No live crawler capture\. |
| 01\-canonical\-signals | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-canonical\-signals\.txt](evidence/01-canonical-signals.txt) | 71130131ffa281b708b51f61478d18e97becfce0b8d2e3b45f1246de81e02f2f | Comparison of owner intent, current HTML canonical, sitemap entry and owner\-summarized archive response\. Engine selection unknown\. |
| 02\-owner\-intent | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/02\-owner\-intent\.txt](evidence/02-owner-intent.txt) | 08adeb40f15e67bd8d3795ab5582e1691190c6e757c7790dad6724e5dd721afe | Synthetic owner scope for descriptive documentation markup\. Original capture date and user agent are unspecified\. |
| 02\-supplied\-status | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/02\-supplied\-status\.txt](evidence/02-supplied-status.txt) | 08efee1d5bbc2252621fc1632620abb48829c22ca9652408676d1aaf97c20ae8 | Owner\-supplied synthetic summary explicitly covers HTTP 200 for both documentation pages\. No headers or independent transport capture\. |
| 01\-supplied\-guide\-status | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-supplied\-guide\-status\.txt](evidence/01-supplied-guide-status.txt) | 12d75ae63eb61df8a186777e57f9478f5d29ede29d4137e964658e0b5452907e | The current guide raw excerpt and archive summary both report status 200 for the ordinary browser capture\. Scope is the two guide pages, not the robots or sitemap export\. |
| 02\-raw\-jsonld | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/02\-raw\-jsonld\.txt](evidence/02-raw-jsonld.txt) | 15b2099b353da2070fe7f75c609ecc399550de13cf5ef8c66c46bb4cb98fd029 | A: strict JSON parse fails with Illegal trailing comma before end of object at dossier line 17, after the final property comma\. B: strict JSON parse succeeds; type WebPage; name Export reference\. Inert text parse only\. No external context resolution, DOM or rich\-result validation\. |
| 01\-guide\-roles | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-guide\-roles\.txt](evidence/01-guide-roles.txt) | 874ccd566302eb69f50a14b5bb963317fe01f194e37a112831823fd946cec5e2 | The current guide serves current reference and the archive serves explicitly historical reference\. Documents have different temporal tasks\. |
| 01\-entitlement\-scopes | 4edf0983717ba29ea620114ac90381879b48c0d5ae2dc7023a951e963e1df556 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/01\-entitlement\-scopes\.txt](evidence/01-entitlement-scopes.txt) | c82d2c7d74e93e97d96d4fe15c116c6eec388952d5f3c3989ba2939a14248d0d | Fixture evidence distinguishes current product guide and former 2024 entitlement\. Independent approval of the current numeric claim is unspecified\. |
| 02\-documentation\-roles | 0c77b2eceab53bde91156dfe0c3d743f03ba8562e99c37174eef63c1f6161988 | offline dossier review | 2026\-11\-16T17:03:04\.706053\+00:00 | 0 full elapsed days | [evidence/02\-documentation\-roles\.txt](evidence/02-documentation-roles.txt) | 2ae92df315de00db4b02d33b89f6298a109bf322df77c48e36c10b1ff2e1b48c | The current library overview and current export reference identify distinct documentation tasks\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
