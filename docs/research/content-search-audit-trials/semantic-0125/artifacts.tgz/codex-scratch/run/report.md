# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:04:57\.984Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 59d2e28c\-d34b\-4237\-9785\-400f328639dd\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 12 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |
| ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 279ef4d3875578005420701b207882ee4a51746ea40adacf68e1c51a2352edfc | 037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523 | local\-file | 2026\-11\-16T05:04:57\.955Z | 0 full elapsed days | [evidence/037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523\.txt](evidence/037311b43ed4c8f8ddf57aca30f09a0edbcf02af0ce1f0367fcbead2bb668523.txt) | 2bd30cae13ab9eff230bb9c13d318fa32ce702b113584a3ce6e5db4d976b4ecc | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 43c44aedf50ab98aefe8660ecfa89791efcbf6cafb79ad2da522f5911e6317b9 | 16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47 | local\-file | 2026\-11\-16T05:04:57\.956Z | 0 full elapsed days | [evidence/16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47\.txt](evidence/16ac2c18726d9fbd2e43141d0d8e00bab411bc9424fd61e23bd5e3abfdb3ad47.txt) | 5a198a42fc6f132e1f4f98817df5a198057f80443420ed994d4d3131cb8cd215 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| abb771d6ed19f723855dce1368ae387a6aac2641b9ab134c193a2808a52cad9b | 3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425 | local\-file | 2026\-11\-16T05:04:57\.957Z | 0 full elapsed days | [evidence/3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425\.txt](evidence/3c0bf2d21bcec0d4e69e6abf3df547424cbcf92e20e45944ec0b55ee57dbe425.txt) | 50be6989ed10fd804cfde5625492d3478f647082ce565977442dac28bd642de3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8d341ad4ff890070150f89c387887bd7d2a9931df19d36905106033c296d61e9 | 443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150 | local\-file | 2026\-11\-16T05:04:57\.958Z | 0 full elapsed days | [evidence/443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150\.txt](evidence/443e442f9584a36fb3eb196ea153ab8f0d09e132f2384fdf9ad5b10cfb350150.txt) | 1e72cc33165bbba8ca8592f4478214b04a1271a60712de923fdeccf0f4d589eb | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 76d7bffda8c15c3762ff9c1ae7a0c6f1645304cb99c26a614527b09e531b4e32 | 757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb | local\-file | 2026\-11\-16T05:04:57\.959Z | 0 full elapsed days | [evidence/757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb\.txt](evidence/757ea7ed8929e7466b7e99af7caae3f90374048ac9fea7c5e45c1dc948d437cb.txt) | ad91638d3f17cf37a002b5bc4ea17e1d1f522a6588dbcd6aa5c3862771c9df76 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2e5789f167723f42615141c7b1724e9f19c2c30b3828fae476fdfae0e7118553 | 787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f | local\-file | 2026\-11\-16T05:04:57\.959Z | 0 full elapsed days | [evidence/787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f\.txt](evidence/787f1032591ffc74413685e3c7a480bc35a30fbc45a2150c3bb5087cdd768a7f.txt) | e6cc869f7d95f9d524bd04dca3b502a55ec88b2895d4e37a16cfd8357d12ef0c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3cbe950e6a10d7b731f00bf915a89ccca63e9bd951412bf0c78d3c54835ab25e | 83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23 | local\-file | 2026\-11\-16T05:04:57\.960Z | 0 full elapsed days | [evidence/83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23\.txt](evidence/83b9636442ea427224ac7aba59d9d6aad7cc234f69c7662fd9b48c6f83065e23.txt) | 9bc4f76dfdab0441083bb58f17ad149ce1b929f94beb5059f09c6c3d83c74fe4 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f694081e54c37cd3502b801e84d5eb71f19528fce15254532ef900cc184f134d | 84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02 | local\-file | 2026\-11\-16T05:04:57\.961Z | 0 full elapsed days | [evidence/84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02\.txt](evidence/84aedccfbb36990ac78b0efee807c1dae935fc4dbecc478ef19be84ad7d13d02.txt) | 8d17fb603574e1796b920a6925107d3fc427052a0fff785b5f8db2b471e343b2 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2eadb8208dddc82941f26cd7ce0da95a67275e7432857cfcdf00f48669ff4325 | 9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159 | local\-file | 2026\-11\-16T05:04:57\.961Z | 0 full elapsed days | [evidence/9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159\.txt](evidence/9eff71e96870f68b12fb77e5f9ea639dbe53c4e443385a0a0e8158d626258159.txt) | f90849aa2078d7c6c74624fa0f0f3444b1cd4347e4bfbac090377d1cd81dc076 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| badf5ebbc346b2ac98bc81b8a7d3012c26854e55b07240e42a776f23ccb4af7b | ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11 | local\-file | 2026\-11\-16T05:04:57\.962Z | 0 full elapsed days | [evidence/ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11\.txt](evidence/ca84f17d6c2e7acffc156372c6b4d201a3196f42683e11bc08c4f2e9af42db11.txt) | 2a2d0e4a22b4b3a09440411a11a3dd9e77c6fa50c8dada692678608aad23b6ff | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 951d933e86b61c91c5be4334f148371d8bdc3bff956064d6844c553c5b25cd2c | f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c | local\-file | 2026\-11\-16T05:04:57\.963Z | 0 full elapsed days | [evidence/f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c\.txt](evidence/f687b9ba9a02f77d518071b96873f629035856b20b75d9b7a2f192822fdf087c.txt) | 80c44010302521f51554e2e958d3657549ac6dee069c516f43e0213bbefcaee5 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 01ce3cd75eb08eb6ff26704cabe172c093c4306f4f8a4006f5dd45570f04949d | ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378 | local\-file | 2026\-11\-16T05:04:57\.963Z | 0 full elapsed days | [evidence/ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378\.txt](evidence/ff176286431edef2196879e4f0d81c9aee6a454d71c629e785dcfd785f7b5378.txt) | 717ecc72264390677d2949b16ed69f1bb008e083faabe2cc4290da44696a5687 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
