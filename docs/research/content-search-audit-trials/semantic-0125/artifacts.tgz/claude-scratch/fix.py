p='report.md';t=open(p).read()
t=t.replace('"Image I1 is a functional download link, destination /annual-report.pdf."','"Image I1 is a functional download link, destination /annual-report.pdf. Its entire"')
t=t.replace('"The adjacent accessible table contains all chart values and units. The owner" (confirms equivalence)','"The adjacent accessible table contains all chart values and units. The owner" (continuing at line 12, confirms equivalence)')
open(p,'w').write(t)
