import json,hashlib,sys
root=sys.argv[1]
def h(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
rep=open(root+'/report.md').read().split('\n')
Q=[("01-setup.md",3,5,"accepting the emailed invitation, signing in, opening Settings > Activation, and entering the one-time code. All steps are required."),
("01-setup.md",9,9,"Sign in. Open Settings > Activation. Enter the one-time code."),
("01-setup.md",12,13,"Accept your emailed invitation. Sign in. Open Settings > Activation. Enter the one-time code."),
("02-media.md",7,9,"Image I1 is a functional download link, destination /annual-report.pdf. Its entire accessible name is alt=\"Company logo\". No adjacent label or aria-label exists."),
("02-media.md",16,17,"The supplied transcript, complete for spoken audio, is: \"Choose the highlighted row.\""),
("02-media.md",18,19,"There is no other descriptive transcript or equivalent instruction for this visual selection."),
("03-titles.md",3,5,"Page /monthly title: \"Basic plan: USD 19 per month\". Its complete visible main content: \"Basic monthly plan: USD 29 before tax.\" Approved current price for this same market and billing period: USD 29 before tax."),
("04-links.md",14,16,"Captured /retired-check: HTTP 404. It is the target of \"Run the current diagnostic\" on /troubleshoot. Approved replacement /diagnostic: HTTP 200, same needed diagnostic."),
("04-links.md",10,11,"No page in this declared section links to /glossary. Publisher intent is that all four pages be discoverable from /guide through section links."),
("05-render.md",3,4,"To disable renewal, open Billing and select Disable renewal."),
("05-render.md",9,9,"Approved task requires selecting Disable renewal after opening Billing."),
("06-facts.md",3,4,"A single export can contain up to 5000 records."),
("06-facts.md",8,9,"Example Archive supports CSV and JSON export. Start from Export."),
("06-facts.md",10,10,"There is no other text, table, image or linked limit reference on that article."),
("07-questions.md",8,8,"/device-id complete body: \"Find the device ID in Settings > Device > ID.\""),
("07-questions.md",9,9,"/device-list complete body: \"Open Settings > Devices to see registered devices.\""),
("07-questions.md",10,11,"open Settings > Devices, select the lost device, choose Revoke, then confirm."),
("08-answers.md",3,4,"authenticated administrators can revoke a workspace token immediately; revocation cannot be undone."),
("08-answers.md",9,10,"\"The token stops working immediately. You can undo this later.\""),
("09-overlap.md",15,15,"Customer instruction: propose actions only. Do not delete, merge, publish or redirect."),
("10-journey.md",5,5,"/compare states \"Select a plan to continue to purchase\" but its only href is /units-reference."),
("11-periods.md",13,14,"\"B improved over A in this fixed API cohort. Comparing A with D proves our content edits caused brand visibility to quadruple across the market.\""),
("11-periods.md",15,15,"No citation annotations, conversions, causal control or wider population sample exist."),
("12-markup.md",3,4,"{\"@context\":\"https://schema.org\",\"@type\":\"Product\",\"name\":\"Example\",}"),
("12-markup.md",6,6,"The trailing comma is present in the supplied bytes."),
("12-markup.md",12,12,"Draft assertion about B: \"Valid JSON syntax and matching price guarantee a rich result.\""),
]
out=[]
for i,(f,s,e,q) in enumerate(Q):
    src=open(f"{root}/targets/{f}").read().split('\n')
    loc=f"{f}:{s}-{e}" if s!=e else f"{f}:{s}"
    # find report block containing quote-ish and locator
    import re
    qn=' '.join(q.split())
    rs=None
    for j,l in enumerate(rep):
        if loc in l:
            blk=' '.join(' '.join(rep[j:j+1]).split())
            rs=j+1;break
    out.append(dict(quoteId=f"q{i}",source=f"targets/{f}",sourceLabel=f,sourceHash=h(f"{root}/targets/{f}"),startLine=s,endLine=e,reportStartLine=rs,reportEndLine=rs,normalization="whitespace",quote=q))
json.dump(dict(root=root,report="report.md",reportHash=h(root+'/report.md'),quotes=out),open('/tmp/qv/bundle.json','w'),indent=1)
