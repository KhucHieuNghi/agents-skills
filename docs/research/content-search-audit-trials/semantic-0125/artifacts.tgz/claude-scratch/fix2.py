p='report.md';t=open(p).read()
t=t.replace('Unsubmitted quotations are listed in the receipt notes, if any.','14 line quotes were verified. Manually checked, not in the ledger: the transcript fragment "Choose the highlighted row." (`02-media.md:16-17`) and the inline alt values.')
open(p,'w').write(t)
