from pathlib import Path
from urllib.parse import urlsplit,unquote
import html,json,re,sys
project=Path(sys.argv[1]);records=[]
for p in sorted(project.rglob("*")):
 if not p.is_file() or any(x in p.parts for x in [".claude",".agents",".agent-skills",".git","targets"]):continue
 if p.suffix not in [".html",".md"]:continue
 text=p.read_text()
 refs=re.findall(r'(?:href|src)="([^"]+)"',text) if p.suffix==".html" else re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',text)
 local=[]
 for ref in refs:
  ref=html.unescape(ref).strip().strip("<>")
  parsed=urlsplit(ref)
  if parsed.scheme or parsed.netloc or not parsed.path:continue
  destination=p.parent/unquote(parsed.path)
  local.append({"reference":ref,"exists":destination.exists()})
 records.append({"report":str(p.relative_to(project)),"localReferences":local,"missingReferences":[r for r in local if not r["exists"]]})
result={"schemaVersion":1,"scope":"Local href/src and Markdown destinations in all generated HTML/Markdown outside installed package; no network requests, no claims about prose semantics", "valid":all(not r["missingReferences"] for r in records),"reports":records}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"valid":result["valid"],"documents":len(records),"references":sum(len(r["localReferences"]) for r in records),"missing":sum(len(r["missingReferences"]) for r in records)}))
