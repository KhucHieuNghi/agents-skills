import { readFileSync } from "node:fs";
import path from "node:path";
const run = process.argv[2];
const jl = (f) =>
  readFileSync(path.join(run, f), "utf8")
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inv = jl("inventory.jsonl");
const ev = jl("evidence.jsonl");
const checks = jl("checks.jsonl");
console.log("INVENTORY[0]", JSON.stringify(inv[0], null, 1));
console.log("INVENTORY[last-ish blocked]", JSON.stringify(inv.find((i) => i.status !== "pending") ?? inv.at(-1), null, 1));
for (const i of inv) console.log(i.itemId.slice(0, 8), i.status, i.uri ?? i.path, i.type);
console.log("EVIDENCE[0]", JSON.stringify({ ...ev[0], value: String(ev[0].value).slice(0, 80) }, null, 1));
for (const e of ev) console.log(e.evidenceId, e.itemId.slice(0, 8), e.kind, e.locator);
console.log("CHECK[0]", JSON.stringify(checks[0], null, 1));
const st = {};
for (const c of checks) st[c.status] = (st[c.status] ?? 0) + 1;
console.log(st);
console.log(checks.filter((c) => c.status !== "unknown").map((c) => [c.itemId.slice(0, 8), c.ruleId, c.status, c.reason]));
console.log(readFileSync(path.join(run, "findings.json"), "utf8").slice(0, 1500));
