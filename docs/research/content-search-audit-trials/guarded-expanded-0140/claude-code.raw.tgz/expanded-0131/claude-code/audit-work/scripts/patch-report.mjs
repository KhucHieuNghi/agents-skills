import { readFileSync, writeFileSync } from "node:fs";
const file = process.argv[2];
const before = readFileSync(file, "utf8");
const from =
  "- **Quotations:** every quotation below is on one line with its `file:line` locator and was checked by the skill's quote verifier against the source lines (receipt: `audit-work/quote-receipt.json`).";
const to =
  "- **Quotations:** the 30 evidence quotations below each sit on one line with a `file:line` locator and all 30 passed the skill's quote verifier against those source lines (receipt: `audit-work/quote-receipt.json`). Short inline fragments in the prose (for example the title \"Example app\" from line 9 of dossier 06, or \"this month\") are not in that ledger; they were checked by reading the cited dossier. The hidden comment in dossier 10 is paraphrased, not quoted.";
if (before.split(from).length !== 2) throw new Error("expected exactly one match");
writeFileSync(file, before.replace(from, to));
console.log("patched");
