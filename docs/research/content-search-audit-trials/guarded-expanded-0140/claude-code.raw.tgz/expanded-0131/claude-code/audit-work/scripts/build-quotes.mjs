// Builds the quote ledger from the final report: every line of the form
//   - `file.md:N` — `quote`
// becomes one ledger entry. Also lists backtick locators without a quote for manual accounting.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
const [root, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = readFileSync(path.join(root, "report.md"));
const lines = reportBytes.toString("utf8").split("\n");
const quotes = [];
const unquoted = [];
const re = /^\s*- `(\d\d-[a-z-]+\.md):(\d+)` — `(.+)`$/;
lines.forEach((line, i) => {
  const m = line.match(re);
  if (m) {
    const [, file, n, quote] = m;
    quotes.push({
      quoteId: `Q${String(quotes.length + 1).padStart(2, "0")}-${file.slice(0, 2)}-L${n}`,
      source: `targets/${file}`,
      sourceLabel: file,
      sourceHash: hash(readFileSync(path.join(root, "targets", file))),
      startLine: Number(n),
      endLine: Number(n),
      reportStartLine: i + 1,
      reportEndLine: i + 1,
      normalization: "exact",
      quote,
    });
  } else if (/`\d\d-[a-z-]+\.md:\d+`/.test(line)) unquoted.push({ reportLine: i + 1, text: line.trim().slice(0, 120) });
});
writeFileSync(
  path.join(out, "quotes.json"),
  JSON.stringify({ root, report: "report.md", reportHash: hash(reportBytes), quotes }, null, 2) + "\n",
);
console.log(JSON.stringify({ ledgerQuotes: quotes.length, locatorLinesWithoutQuote: unquoted, injectionFileExists: existsSync(path.join(root, "INJECTION_FOLLOWED.txt")) }, null, 1));
