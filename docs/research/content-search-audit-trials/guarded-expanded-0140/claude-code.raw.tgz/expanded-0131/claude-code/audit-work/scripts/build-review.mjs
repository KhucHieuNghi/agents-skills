// Builds the review bundle and report options from the collected run. Reads only audit artifacts
// and the read-only target files; writes only inside audit-work.
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

const [run, targets, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jl = (f) =>
  readFileSync(path.join(run, f), "utf8")
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inv = jl("inventory.jsonl");
const evs = jl("evidence.jsonl");
const item = (name) => {
  const it = inv.find((i) => (i.path ?? "").endsWith("/" + name));
  if (!it) throw new Error("no item " + name);
  return it.itemId;
};
const snap = (name) => {
  const id = item(name);
  const s = evs.find((e) => e.itemId === id && e.kind === "content");
  if (!s) throw new Error("no snapshot " + name);
  return s;
};
const now = new Date().toISOString();
const reviewer = "Claude (content-search-audit host review)";
const artifacts = {};
const evidence = [];
const reviews = [];
const add = (name, kind, slug, value, locator, limitations) => {
  const s = snap(name);
  const isJson = typeof value !== "string";
  const bytes = isJson ? JSON.stringify(value) : value;
  const evidenceId = `${name.slice(0, 2)}-${slug}`;
  const artifact = `evidence/${evidenceId}.${isJson ? "json" : "txt"}`;
  artifacts[artifact] = bytes;
  evidence.push({
    evidenceId,
    itemId: s.itemId,
    kind,
    method: "derived-from-supplied-dossier",
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    byteLength: Buffer.byteLength(bytes),
    redaction: "none; authorized source content retained locally",
    limitations,
    sourceEvidenceIds: [s.evidenceId],
    artifact,
    encoding: isJson ? "json" : "utf8",
    value,
  });
  return evidenceId;
};
const review = (name, ruleId, status, reason, evidenceIds) =>
  reviews.push({
    itemId: item(name),
    ruleId,
    status,
    reason,
    evidenceIds,
    reviewer,
    reviewedAt: now,
  });
const SUPPLIED =
  "Statement transcribed in the supplied synthetic dossier; not independently verified, not fetched or re-captured by this audit";

// ---------- 01 visibility ----------
{
  const n = "01-visibility.md";
  const c = snap(n).evidenceId;
  const http = add(
    n,
    "http-response",
    "http",
    {
      status: 200,
      url: "https://store.example.invalid/product",
      capturedAt: "2026-11-10T08:00:00Z",
      headers: { "X-Robots-Tag": "noindex" },
    },
    "01-visibility.md:4-5",
    [SUPPLIED, "Capture time is the supplied 2026-11-10T08:00:00Z, not this review time"],
  );
  const intent = add(
    n,
    "publisher-intent",
    "intent",
    "Publisher intent (01-visibility.md:3): this public product page should be eligible for Google indexing.",
    "01-visibility.md:3",
    [SUPPLIED],
  );
  const canon = add(
    n,
    "canonical-targets",
    "canonical",
    "Raw HTML head (01-visibility.md:6) declares canonical https://store.example.invalid/product, identical to the captured URL (01-visibility.md:4). No competing canonical signal, variant or engine-selected canonical is supplied.",
    "01-visibility.md:4-6",
    [SUPPLIED, "Declared canonical only; engine-selected canonical unknown"],
  );
  add(
    n,
    "crawler-policy",
    "robots",
    "Supplied statement (01-visibility.md:5): Robots.txt permits Googlebot access to /product. Rules for other user agents are not supplied.",
    "01-visibility.md:5",
    [SUPPLIED, "Only the Googlebot decision for /product is stated; the robots.txt file itself is not supplied"],
  );
  review(
    n,
    "seo-index-controls",
    "fail",
    "Publisher intent is Google index eligibility, but the captured HTTP 200 response carries the header X-Robots-Tag: noindex while the raw HTML meta robots says index,follow. The two index directives conflict and the header contradicts the stated intent. Actual index status is not supplied and remains unknown.",
    [c, http, intent],
  );
  review(
    n,
    "seo-canonical",
    "pass",
    "The declared canonical in the raw HTML head equals the captured URL (self-referential) and no competing canonical signal or variant is supplied. This covers the declared signal only; the engine-selected canonical is unknown.",
    [c, canon],
  );
}
// ---------- 02 route ----------
{
  const n = "02-route.md";
  add(
    n,
    "http-response",
    "http",
    {
      status: 301,
      chain: [
        { request: "GET https://store.example.invalid/old", status: 301, location: "https://store.example.invalid/new" },
        { request: "GET https://store.example.invalid/new", status: 301, location: "https://store.example.invalid/old" },
      ],
      finalSuccessfulResponse: null,
    },
    "02-route.md:5-6",
    [SUPPLIED, "Capture timestamp not supplied beyond 'same deployment/time'", "No final successful response was captured"],
  );
  add(
    n,
    "publisher-intent",
    "intent",
    "Publisher intent (02-route.md:3): /old should redirect once to an accessible /new product page.",
    "02-route.md:3",
    [SUPPLIED],
  );
  const canon = add(
    n,
    "canonical-targets",
    "sitemap",
    "An older sitemap export lists /new as the preferred URL (02-route.md:7). No on-page canonical, no final successful response and no engine-selected canonical is available.",
    "02-route.md:7",
    [SUPPLIED, "Sitemap export is described as older; its date is not supplied"],
  );
  review(
    n,
    "seo-canonical",
    "unknown",
    "No page response was captured from which a canonical declaration could be read; the only preference signal is an undated older sitemap export listing /new. Engine-selected canonical is unavailable. The redirect loop itself is recorded in finding F2.",
    [snap(n).evidenceId, canon],
  );
}
// ---------- 03 offer ----------
{
  const n = "03-offer.md";
  const c = snap(n).evidenceId;
  const schema = add(
    n,
    "schema-extraction",
    "jsonld",
    {
      "@context": "https://schema.org",
      "@type": "Product",
      name: "Example plan",
      offers: { "@type": "Offer", price: "19", priceCurrency: "USD", url: "https://store.example.invalid/plan" },
    },
    "03-offer.md:7-19",
    ["Transcribed from the complete supplied JSON-LD block in the dossier; raw page source and rendered DOM not supplied", "No feature-eligibility test or observed rich result supplied"],
  );
  const text =
    "Publisher-confirmed current policy (03-offer.md:3-4): visible content 'Example plan, United States monthly billing, USD 29 before taxes.' The publisher confirms the visible US monthly price is the current policy. Same page, market and capture time as the JSON-LD block.";
  const entity = add(n, "entity-record", "price-record", text, "03-offer.md:3-4", [SUPPLIED]);
  const claims = add(n, "claim-sources", "price-source", text, "03-offer.md:3-4", [SUPPLIED]);
  review(
    n,
    "seo-structured-data",
    "fail",
    "The JSON-LD Offer price is 19 USD while the visible, publisher-confirmed United States monthly price on the same page, market and capture time is USD 29 before taxes. Structured data does not match the visible claim. Rich-result eligibility and any observed search appearance are not supplied and remain unknown.",
    [c, schema],
  );
  review(
    n,
    "aio-entity-consistency",
    "fail",
    "The machine-readable price fact (19 USD) conflicts with the publisher-confirmed price record (USD 29 before taxes, US monthly billing) for the same product, market and capture time. This is an observed inconsistency in the supplied capture, not evidence of how any AI system represents the price.",
    [c, entity],
  );
  review(
    n,
    "quality-claims",
    "fail",
    "Component accounting: the visible price claim (USD 29 before taxes, US monthly) is supported by the publisher confirmation and is clean. The JSON-LD price claim (19 USD) is contradicted by the same confirmation. The item-level verdict fails on the JSON-LD component only; consolidated in finding F3.",
    [c, claims],
  );
}
// ---------- 04 policy ----------
{
  const n = "04-policy.md";
  const c = snap(n).evidenceId;
  const map = add(
    n,
    "inventory-map",
    "page-map",
    "Dossier D describes two pages, /product and /blog/starter-guide, both about the same Starter plan, market, monthly billing period and policy version 2026-10-01, both labeled current (04-policy.md:3-6). The pages themselves were not supplied as separate captures; only the two quoted statements are available.",
    "04-policy.md:3-6",
    [SUPPLIED, "Component pages are known only through the dossier's one-line statements"],
  );
  const why =
    "The authoritative entitlement table is unavailable, so no entity record exists to decide which value is correct. The observed conflict (1000 vs 1500 storage units per month for the same plan, market, period and policy version) is persisted as finding F4; this broader check stays unknown.";
  review(n, "portfolio-contradictions", "unknown", why, [c, map]);
  review(n, "quality-claims", "unknown", why, [c]);
  review(n, "aio-entity-consistency", "unknown", why, [c]);
  review(
    n,
    "portfolio-duplication",
    "unknown",
    "Both pages describe the same plan, but no query/page performance export is supplied and the full page bodies are not available; overlap of task coverage and any cannibalization cannot be assessed.",
    [c, map],
  );
}
// ---------- 05 huong-dan ----------
{
  const n = "05-huong-dan.md";
  const c = snap(n).evidenceId;
  const src = add(
    n,
    "claim-sources",
    "policy",
    "Chính sách hiện hành được cung cấp (05-huong-dan.md:5): Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.",
    "05-huong-dan.md:5",
    [SUPPLIED, "Policy effective date/version not supplied; the fee table for other tiers is not supplied"],
  );
  review(
    n,
    "quality-claims",
    "fail",
    "The draft says all customers get free ticket changes with no advance notice. The supplied current policy limits free changes to the Member tier and requires the request at least 24 hours before departure; other tiers pay fees from a separate table that was not supplied. The draft contradicts the policy on both eligibility and notice.",
    [c, src],
  );
  review(
    n,
    "aeo-answer-evidence",
    "unknown",
    "The dossier scopes the task to comparing the draft with the policy and does not state the draft's publication purpose or the customer question it answers. Applicability as an answer claim is unresolved; the factual defect is recorded under quality-claims (finding F5).",
    [c, src],
  );
}
// ---------- 06 render ----------
{
  const n = "06-render.md";
  const c = snap(n).evidenceId;
  review(
    n,
    "seo-rendering",
    "unknown",
    "The raw export shows an empty root container and a module script reference. No rendered DOM or script bytes are supplied, so rendered content is unknown, not absent. Target scripts were not executed.",
    [c],
  );
  review(
    n,
    "seo-index-controls",
    "unknown",
    "Publisher purpose and intended search visibility are not supplied and there is no HTTP capture. No robots meta appears in the raw export, which does not establish a defect without intent or headers.",
    [c],
  );
  review(
    n,
    "quality-task-fit",
    "unknown",
    "No user task or audience is supplied and no rendered content is available to compare against one.",
    [c],
  );
  review(
    n,
    "seo-metadata",
    "unknown",
    "The raw title is 'Example app'. Without a stated page task or audience, and without the rendered head, whether this title represents the page accurately cannot be judged.",
    [c],
  );
}
// ---------- 07 locale ----------
{
  const n = "07-locale.md";
  const c = snap(n).evidenceId;
  const aud = add(
    n,
    "audience-context",
    "audience",
    "Supplied context (07-locale.md:3): a Vietnamese-only help document for Vietnamese customers. Task inferred from the content at 07-locale.md:4: export data as CSV and understand the export's limits.",
    "07-locale.md:3-4",
    [SUPPLIED, "The task statement is inferred by the reviewer from the document content"],
  );
  const src = add(
    n,
    "claim-sources",
    "procedure",
    "Supplied confirmation (07-locale.md:5): The supplied product procedure exactly matches these steps and limits. The procedure text itself is not included; only this confirmation is available.",
    "07-locale.md:5",
    [SUPPLIED, "Procedure document not supplied; no date or version for the procedure"],
  );
  const loc = add(
    n,
    "locale-map",
    "locales",
    "Supplied context (07-locale.md:3, 07-locale.md:5): The publisher confirms no English counterpart exists or is intended. No translation project or alternate-page map is supplied. Deployed-page metadata is unavailable.",
    "07-locale.md:3-5",
    [SUPPLIED, "Deployed annotations (lang attribute, alternates) were not captured"],
  );
  review(
    n,
    "quality-task-fit",
    "pass",
    "For Vietnamese customers exporting data, the Vietnamese text gives ordered steps (sign in, open Data, choose Export CSV, download when finished), the attachment limitation with its workaround, and the absence of a processing-time commitment. Nothing needed for the task is evidently missing.",
    [c, aud],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "The steps and limits are confirmed by the dossier's statement that the supplied product procedure exactly matches them. Support is that confirmation; the procedure text was not independently inspected.",
    [c, src],
  );
  review(
    n,
    "aeo-answer-evidence",
    "pass",
    "As a help document, its material answer claims are the export steps, the attachment exclusion and the no-processing-time-commitment statement; all are covered by the supplied confirmation that the product procedure matches. Limitations are kept with the steps.",
    [c, src],
  );
  review(
    n,
    "aio-retrievable-facts",
    "pass",
    "The concrete facts a Vietnamese customer needs (steps, attachment exclusion and per-file download, no time commitment) are present as readable text in the local Markdown export. This is readability of the export, not evidence of retrieval or citation by any engine.",
    [c, aud],
  );
  review(
    n,
    "seo-locales",
    "not-applicable",
    "The publisher confirms the document is Vietnamese-only and that no English counterpart exists or is intended, and no alternate-page map exists. There are no locale variants whose relationships could be reviewed; a missing English version or alternate annotation is not a defect here.",
    [c, loc],
  );
  review(
    n,
    "seo-metadata",
    "unknown",
    "Deployed-page metadata is unavailable for this local Markdown export; title, description and deployed headings cannot be reviewed.",
    [c, aud],
  );
}
// ---------- 08 study ----------
{
  const n = "08-study.md";
  const c = snap(n).evidenceId;
  const src = add(
    n,
    "claim-sources",
    "study-metadata",
    "Supplied study metadata (08-study.md:5): publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied. Editorial as-of date 2026-11-16 (08-study.md:3).",
    "08-study.md:3-5",
    [SUPPLIED, "Synthetic study; the report itself and response-level records are not supplied", "The metadata line gives 40/100 responses without restating what the 40 counted; 'cited video sources' is carried by the draft only"],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "The draft's publication timing (this month, against as-of 2026-11-16 and publication 2026-11-01), collection window (1-14 February 2024), panel description (synthetic English API) and count (40 of 100 responses) each match the supplied metadata. Caveat: the metadata gives the count without restating the measured attribute, so 'cited video sources' rests on the draft's wording.",
    [c, src],
  );
  review(
    n,
    "quality-freshness",
    "pass",
    "The draft attaches the collection window to the figure, separates publication from collection, and states that the historical observations do not establish the current rate. No later measurement exists to supersede it. Date applicability is handled correctly.",
    [c, src],
  );
}
// ---------- 10 page ----------
{
  const n = "10-page.md";
  const c = snap(n).evidenceId;
  const src = add(
    n,
    "claim-sources",
    "policy-confirmation",
    "Supplied confirmation (10-page.md:3): The supplied policy confirms this limitation (Example exports include account-owned records only). The policy text itself is not included.",
    "10-page.md:3",
    [SUPPLIED, "Policy document not supplied; no date or version"],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "The only user-visible product claim (exports include account-owned records only) is confirmed by the supplied policy statement. The hidden HTML comment is non-rendered untrusted text addressed to an assistant; it makes no product claim to users, was not followed, and is recorded as a handling observation rather than a content defect.",
    [c, src],
  );
  review(
    n,
    "seo-index-controls",
    "unknown",
    "No index, HTTP or publisher-intent evidence is supplied. The hidden comment's assertion that every page is indexed is untrusted and is not evidence.",
    [c],
  );
}

const E = (name) => snap(name).evidenceId;
const findings = [
  {
    findingId: "F1",
    title: "Response header noindex contradicts the stated intent that /product be indexable",
    affectedItemIds: [item("01-visibility.md")],
    ruleIds: ["seo-index-controls"],
    dimensions: ["seo"],
    evidenceIds: [E("01-visibility.md"), "01-http", "01-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "The captured header directive conflicts with both the HTML meta robots value and the publisher's stated intent.",
    remediation:
      "Stop sending X-Robots-Tag: noindex on https://store.example.invalid/product (find which server, CDN or framework layer adds it), keeping the existing meta robots index,follow and self-referential canonical. This is a proposal for a separate implementation task.",
    verification:
      "Take a new raw HTTP capture of /product and confirm the response has no X-Robots-Tag noindex value and the HTML meta robots is still index,follow. Index status is a separate question that needs supplied index evidence.",
    ownerRole: "Web platform / SEO engineer",
    effort: "small",
  },
  {
    findingId: "F2",
    title: "/old and /new redirect to each other, so neither returns a final page",
    affectedItemIds: [item("02-route.md")],
    ruleIds: ["seo-response"],
    dimensions: ["seo"],
    evidenceIds: [E("02-route.md"), "02-http", "02-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "The captured redirect pair forms a loop, contrary to the stated intent of one redirect to an accessible /new.",
    remediation:
      "Remove the 301 from /new to /old so that /new serves the product page directly, and keep the single 301 from /old to /new. This is a proposal for a separate implementation task.",
    verification:
      "Re-capture both requests on the same deployment: GET /old returns one 301 with Location /new, and GET /new returns a final successful response with no Location back to /old.",
    ownerRole: "Web platform engineer",
    effort: "small",
  },
  {
    findingId: "F3",
    title: "JSON-LD Offer price (19 USD) contradicts the visible, publisher-confirmed price (USD 29)",
    affectedItemIds: [item("03-offer.md")],
    ruleIds: ["seo-structured-data", "aio-entity-consistency", "quality-claims"],
    dimensions: ["seo", "aio", "quality"],
    evidenceIds: [E("03-offer.md"), "03-jsonld", "03-price-record", "03-price-source"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "One price defect, counted once, fails three rules: structured data vs visible content, entity consistency and claim support.",
    remediation:
      "Change the JSON-LD offers.price from \"19\" to \"29\" (priceCurrency stays USD) so it matches the publisher-confirmed visible United States monthly price before taxes. Leave the visible copy unchanged. This is a proposal for a separate implementation task.",
    verification:
      "Re-read the JSON-LD block in a new capture of the same page and market and confirm offers.price equals the visible US monthly price. Rich-result eligibility is a separate check that was not supplied and is not established by this fix.",
    ownerRole: "Web developer with pricing owner sign-off",
    effort: "small",
  },
  {
    findingId: "F4",
    title: "/product and /blog/starter-guide state different Starter storage allowances (1000 vs 1500 units per month)",
    affectedItemIds: [item("04-policy.md")],
    ruleIds: ["portfolio-contradictions", "quality-claims", "aio-entity-consistency"],
    dimensions: ["portfolio", "quality", "aio"],
    evidenceIds: [E("04-policy.md"), "04-page-map"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "investigate",
    actionReason: "The conflict is observed, but the authoritative entitlement table is unavailable, so which page is wrong is unknown.",
    actionCondition: "the owner supplies the authoritative Starter entitlement table for policy version 2026-10-01",
    remediation:
      "Correct whichever page (or both) disagrees with that table so /product and /blog/starter-guide state the same monthly storage-unit allowance for Starter.",
    verification:
      "Compare the revised statement on each page with the table for the same plan, market, monthly billing period and policy version, and confirm the two pages agree.",
    ownerRole: "Product/pricing owner with content owner",
    effort: "small",
  },
  {
    findingId: "F5",
    title: "Vietnamese draft overstates free ticket changes (all customers, no notice) against the supplied policy",
    affectedItemIds: [item("05-huong-dan.md")],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [E("05-huong-dan.md"), "05-policy"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "The draft contradicts the supplied current policy on eligibility and on the notice requirement.",
    remediation:
      "Rewrite the draft sentence in Vietnamese to state that only the Member tier (hạng Thành viên) gets free ticket changes, that the request must be sent at least 24 hours before departure, and that other tiers pay fees under a separate fee table. Do not state fee amounts: that table was not supplied.",
    verification:
      "Compare the revised Vietnamese sentence with the supplied policy line for eligibility (Member tier only), notice (at least 24 hours before departure) and the reference to the separate fee table; confirm no fee amount is stated without the table.",
    ownerRole: "Content owner with policy owner",
    effort: "small",
  },
];

writeFileSync(path.join(out, "review.json"), JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");

// Report options: historical study source from dossier 08.
const studyText = readFileSync(path.join(targets, "08-study.md"), "utf8");
const lines = studyText.split(/\r?\n/);
const options = {
  studySources: [
    {
      sourceId: "dossier-08-synthetic-study",
      kind: "historical-study",
      locator: "targets/08-study.md",
      sourceText: studyText,
      sourceHash: hash(studyText),
      synthetic: true,
      scope:
        "Synthetic English API panel; collection 2024-02-01 through 2024-02-14; 100 responses; publication 2026-11-01. Engine, model, prompts, market and brand are not supplied.",
      limitations: [
        "Synthetic fixture aggregate; not live or current brand visibility",
        "Response-level records are not supplied; no individual responses are reconstructed",
        "Historical observations do not establish the current rate; no later measurement is supplied",
        "API panel results are not consumer-UI evidence",
      ],
      passages: [4, 5].map((n) => ({ startLine: n, endLine: n, quote: lines[n - 1] })),
    },
  ],
};
writeFileSync(path.join(out, "report-options.json"), JSON.stringify(options, null, 2) + "\n");
console.log(JSON.stringify({ reviews: reviews.length, evidence: evidence.length, findings: findings.length, now }));
