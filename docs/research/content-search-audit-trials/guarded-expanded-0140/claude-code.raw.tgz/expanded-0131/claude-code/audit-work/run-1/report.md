# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:22:14\.628Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run e82ed2bd\-cdc0\-4cf0\-b143\-525735a4fe1c\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |
| efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 9574f871b9eea01ee87c383012be3afb39384eda40ef42ed22f3c5d3ffc905af | 03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6 | local\-file | 2026\-11\-18T08:22:14\.382Z | 0 full elapsed days | [evidence/03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6\.txt](evidence/03c76bfcc8c4c1a2572987855c80dc27fc8e10c3d8f9de61628d3e3ff6c7dfb6.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| eeb6ec72dbc5a5ad9d6dffd17a410497860bf0b18f3de715f6cdfd434dae3b3b | 0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504 | local\-file | 2026\-11\-18T08:22:14\.385Z | 0 full elapsed days | [evidence/0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504\.txt](evidence/0ecaa44ddbb9b518df5b55c3a701a59486da34340853f00e02941c3a652c1504.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0b5698ab80e3cc38ed87fdb3f41b534ce94e06e0a5d262ba0f9d8debc0ac6561 | 5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821 | local\-file | 2026\-11\-18T08:22:14\.389Z | 0 full elapsed days | [evidence/5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821\.txt](evidence/5aa7b557074d337dc79295138fe9016bd343f399c8520467a58a7e7ef4173821.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c3136ea6f3c9be12047aacd36e423dd2d487d3907a72b9a017cfa1a46363c57c | 615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef | local\-file | 2026\-11\-18T08:22:14\.391Z | 0 full elapsed days | [evidence/615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef\.txt](evidence/615692800d75ded3cfe162b56eb6cd1be24278aec2d68af79481944e1c47ffef.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8d09cbd7c5dc2aa5595fa1cfb21f73811f4a01034c74fa3b2e792b3c214666bc | 67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf | local\-file | 2026\-11\-18T08:22:14\.400Z | 0 full elapsed days | [evidence/67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf\.txt](evidence/67676fb8b53f03628e91114781eff2ea98bc092e31bc06e7744f1e661e9a5dbf.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 102cd382fc97ea1da499c5a5d320466e36ec2f6b9714aeadab51b6f2e779d2f6 | ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9 | local\-file | 2026\-11\-18T08:22:14\.405Z | 0 full elapsed days | [evidence/ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9\.txt](evidence/ad558df5336fb8e2d75d9c9d355e2024add4ae1d19f6abc1a5545adf5ba030a9.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 542602ab67ef4d7a9cf97d7d7db5bfcb1cc379b78e12ad89be30144f8131b607 | b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c | local\-file | 2026\-11\-18T08:22:14\.409Z | 0 full elapsed days | [evidence/b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c\.txt](evidence/b67d266a23890676f5c8f5b6416977a3f34b800620f13f621f89bd07f7051b0c.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 1ffcefe99ef3890842b93d783bb87e699dea8d250e629e696f869f188a4d09b0 | d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3 | local\-file | 2026\-11\-18T08:22:14\.414Z | 0 full elapsed days | [evidence/d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3\.txt](evidence/d0f5928fb07ffa389e5864817576a126c75412ada9dae9e84f4400406b1722d3.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f466b2e4c56a9592e037e0d7c5611831c47cdf4891282ea47bb0f84dc4d4609e | d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812 | local\-file | 2026\-11\-18T08:22:14\.416Z | 0 full elapsed days | [evidence/d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812\.txt](evidence/d6354cd7a0b5ecc8817a1fb3bd8142b84a2400b10a141dde321214e850daf812.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a7a84a8ac00d641f41b42b1b32fb86bcfdc2b2ec553757509340405a2243d89a | efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e | local\-file | 2026\-11\-18T08:22:14\.421Z | 0 full elapsed days | [evidence/efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e\.txt](evidence/efe10add88118a73b0afb46a188df00999053cbe7cbd3239c3521fcab0f0474e.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
