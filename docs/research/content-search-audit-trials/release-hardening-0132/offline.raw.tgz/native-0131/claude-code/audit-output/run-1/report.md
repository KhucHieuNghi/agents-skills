# Synthetic audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:14:32\.331Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 66ad18e9\-3203\-4283\-8601\-0b4c3e3693b1\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | local\-file | 2026\-11\-17T16:14:32\.314Z | 0 full elapsed days | [evidence/06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a\.txt](evidence/06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 | 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | local\-file | 2026\-11\-17T16:14:32\.316Z | 0 full elapsed days | [evidence/157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827\.txt](evidence/157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | local\-file | 2026\-11\-17T16:14:32\.316Z | 0 full elapsed days | [evidence/dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0\.txt](evidence/dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | local\-file | 2026\-11\-17T16:14:32\.317Z | 0 full elapsed days | [evidence/e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52\.txt](evidence/e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
