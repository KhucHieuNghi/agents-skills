import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const hash = (v) => createHash("sha256").update(v).digest("hex");
const run = process.argv[2];
const L = (f) => readFileSync(`${run}/${f}`, "utf8").trim().split("\n").map(JSON.parse);
const inv = L("inventory.jsonl"), ev = L("evidence.jsonl");
const now = new Date().toISOString();
const item = (n) => inv.find((i) => i.path.includes(`/targets/${n}-`));
const snap = (id) => ev.find((e) => e.itemId === id && e.kind === "content");
const artifacts = {}, evidence = [], reviews = [], findings = [];
const add = (n, kind, slug, locator, value) => {
  const it = item(n), s = snap(it.itemId);
  const rec = { ...s, evidenceId: `d${n}-${slug}`, kind, artifact: `evidence/d${n}-${slug}.txt`, value,
    snapshotHash: hash(value), collectedAt: now, locator, sourceEvidenceIds: [s.evidenceId],
    limitations: ["Synthetic owner-supplied comparison record preserved from the dossier; not independently verified live behaviour"] };
  delete rec.byteLength;
  artifacts[rec.artifact] = value; evidence.push(rec); return rec.evidenceId;
};
const rev = (n, ruleId, status, reason, ids) => reviews.push({ itemId: item(n).itemId, ruleId, status, reason,
  evidenceIds: [snap(item(n).itemId).evidenceId, ...ids], reviewer: "claude-content-search-audit-host", reviewedAt: now });
const fin = (n, id, title, ruleIds, dimensions, ids, severity, remediation, verification, ownerRole) => findings.push({
  findingId: id, title, affectedItemIds: [item(n).itemId], ruleIds, dimensions,
  evidenceIds: [snap(item(n).itemId).evidenceId, ...ids], severity, confidence: "high", classification: "observed",
  remediation, verification, ownerRole, effort: "small", action: "update",
  actionReason: "Draft assertion conflicts with or exceeds the owner-supplied record in the same dossier; proposal only, no content change authorized." });

// extracted text (deterministic rule recomputed by helper)
for (const n of ["01", "02", "03", "04"]) add(n, "extracted-text", "text", item(n).path, snap(item(n).itemId).value);

// 01
const c1 = add("01", "claim-sources", "claims", "01-competitor-claims.md:3-14",
 "Owner-supplied synthetic records, 01-competitor-claims.md:3-14 (current November 2026 US plans, USD before tax): Cedar USD 12 per seat per month billed monthly, no seat minimum; Cedar annual USD 10 per seat per month equivalent billed annually; Fir monthly USD 15; Fir annual USD 9 per seat per month equivalent billed annually. Fir pricing-table excerpt does not mention SSO; supplied Fir SSO docs: SAML SSO is available on Enterprise, with a minimum of 20 paid seats. No SSO statement supplied for Fir's other plans.");
const e1 = add("01", "entity-record", "entity", "01-competitor-claims.md:6-9",
 "Owner-supplied synthetic price records, 01-competitor-claims.md:6-9: Cedar 12 monthly / 10 annual-equivalent; Fir 15 monthly / 9 annual-equivalent, USD per seat per month, US, November 2026, before tax.");
rev("01", "quality-claims", "fail", "Draft /compare assertion A (line 17) says Fir has no SSO, contradicted by the supplied Fir SSO docs (line 13); assertion B (line 18) says Cedar is cheaper on every billing option, contradicted on annual billing (10 vs 9, lines 7 and 9). The /monthly-comparison caption (line 21) is supported (15 - 12 = 3) and stays clean.", [c1]);
rev("01", "aeo-answer-evidence", "fail", "Assertions A and B are the comparison answers on the draft /compare page and lack source support (lines 17-18 vs 7, 9, 13). The scoped monthly caption (line 21) is supported. No question set was supplied; coverage/context checks stay unknown.", [c1]);
rev("01", "aio-entity-consistency", "fail", "Draft assertion B's price ordering conflicts with the owner price record for annual billing (Cedar 10 vs Fir 9). Monthly ordering is consistent.", [e1]);
fin("01", "d01-fir-sso", "Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation",
 ["quality-claims", "aeo-answer-evidence"], ["quality", "aeo"], [c1], "high",
 "Proposal: remove assertion A or replace it with a statement limited to the supplied docs (SAML SSO on Fir Enterprise, minimum 20 paid seats), without asserting anything about Fir's other plans or citing the pricing table as proof.",
 "Re-read the revised sentence against 01-competitor-claims.md:12-14; it must not claim absence of SSO and must not rely on the pricing-table excerpt.", "Content owner with legal/competitive-claims reviewer");
fin("01", "d01-every-billing-option", "Draft /compare assertion B claims Cedar is cheaper on every billing option; the annual record shows Fir lower",
 ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [c1, e1], "high",
 "Proposal: limit the claim to monthly billing (as the /monthly-comparison caption already does) or state both options with their figures, keeping November 2026, US, USD-before-tax scope.",
 "Recompute each billing option from 01-competitor-claims.md:6-9 and confirm the revised wording makes no claim covering annual billing in Cedar's favour.", "Content owner");

// 02
const c2 = add("02", "claim-sources", "claims", "02-measurement-windows.md:3-16",
 "Owner-supplied synthetic counts, 02-measurement-windows.md:3-16: one campaign, USD, October 2026. Spend complete October 1-31: USD 3000. Conversion export covers only October 1-7: 35 completed conversions; no conversion data for October 8-31. October 1-7 spend USD 700. Independent referral report: 15 October sessions with identified AI-assistant referrer; other sessions unknown origin; no estimating model, incrementality test, complete session count or conversion linkage.");
rev("02", "quality-claims", "fail", "Draft A (line 10) divides full-month spend (3000, line 5) by conversions from October 1-7 only (35, line 6) and labels it October cost per conversion; conversions for October 8-31 do not exist (line 7). Draft B (lines 17-18) asserts 150 total sessions and a one-in-ten tracking rate with no supplied model (lines 15-16). The October 1-7 caption (lines 11-12) is supported (700 / 35 = 20) and stays clean.", [c2]);
fin("02", "d02-cpa-window-mismatch", "Draft A reports an October cost per conversion from full-month spend and seven days of conversions",
 ["quality-claims"], ["quality"], [c2], "high",
 "Proposal: drop the full-month figure; report only the October 1-7 figure already in the verified-window caption and state that October 8-31 conversions are unmeasured.",
 "Confirm numerator and denominator cover the same dates in the supplied rows (02-measurement-windows.md:5-8); a full-month figure needs a conversion export covering October 8-31, which is a new supply, not a reconstruction.", "Reporting/analytics owner");
fin("02", "d02-ai-referral-extrapolation", "Draft B says 15 tracked sessions prove 150 AI-generated sessions using an unsupplied one-in-ten rate",
 ["quality-claims"], ["quality"], [c2], "medium",
 "Proposal: report the observed count only (15 October sessions with an identified AI-assistant referrer; other sessions of unknown origin) and remove the 150 total, the tracking rate and the word prove.",
 "Check the revised sentence contains only quantities present in 02-measurement-windows.md:14-16 and keeps the referral report separate from the campaign conversion counts (lines 20-21).", "Reporting/analytics owner");

// 03
const c3 = add("03", "claim-sources", "policy", "03-template-service-area.md:3-16",
 "Owner-supplied synthetic policy, 03-template-service-area.md:3-16: declared inventory complete (/north-delivery, /south-delivery, /terms-v1). Current approved policy: North same-day delivery Monday-Friday for orders placed before 10:00 local time; South next-business-day delivery only. /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurate for the 2024 contract when South had same-day service, linking to the two current pages.");
const e3 = add("03", "entity-record", "entity", "03-template-service-area.md:4-5",
 "Owner-approved current service record, 03-template-service-area.md:4-5: North same-day Monday-Friday before 10:00 local time; South next-business-day delivery only.");
rev("03", "quality-claims", "fail", "The current /south-delivery passage (lines 10-11) states same-day delivery for South; the current approved policy (line 5) is next-business-day only. /north-delivery (lines 8-9) matches policy (lines 4-5). /terms-v1 is an owner-confirmed labeled 2024 archive (lines 13-16) and stays clean.", [c3]);
rev("03", "aeo-answer-evidence", "fail", "The /south-delivery policy passage is the page's delivery-timing answer and is contradicted by approved policy (lines 10-11 vs 5). North passage supported. No question set supplied; other AEO checks unknown.", [c3]);
rev("03", "aio-entity-consistency", "fail", "The South service fact on /south-delivery conflicts with the owner-approved service record (line 5). North is consistent; the 2024 archive is a labeled version variant, not a conflict.", [e3]);
fin("03", "d03-south-same-day", "/south-delivery states same-day delivery; current approved policy for South is next-business-day only",
 ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], ["quality", "aeo", "aio"], [c3, e3], "high",
 "Proposal: replace the South passage with the approved South policy (next-business-day delivery only). Any cut-off time or day restriction for South must come from the owner; none is supplied. Leave /north-delivery and /terms-v1 unchanged and keep both regional pages.",
 "Compare the revised /south-delivery passage with 03-template-service-area.md:4-5 and confirm /north-delivery and /terms-v1 are unchanged.", "Content owner with operations/policy owner");

// 04
const c4 = add("04", "claim-sources", "record", "04-editorial-proof.md:3-18",
 "Owner-supplied synthetic records, 04-editorial-proof.md:3-18: for 20 observed onboarding sessions in a supplied study the median completion time was 15 minutes; no maximum time, guarantee, refund policy, percentile distribution or wider population estimate supplied. Approved permissions policy: editors cannot delete a workspace and owners can; no additional conditions. /status-codes: complete, accurate table for its declared technical task; terse style and absence of purchase CTA approved by documentation owner.");
rev("04", "quality-claims", "fail", "The draft landing-page claim (line 6) asserts a guarantee, a 10-minute bound and universal scope; the approved record (lines 3-5) supplies only a 15-minute median over 20 observed sessions and no guarantee, maximum or population estimate. The permissions FAQ (line 9) matches approved policy (lines 10-12). /status-codes is owner-attested accurate (lines 15-18); its table is not supplied.", [c4]);
rev("04", "aeo-answer-evidence", "fail", "The landing-page setup-time promise is a material answer claim without source support (line 6 vs 3-5). The permissions FAQ answer is supported and stays clean (lines 9-12).", [c4]);
fin("04", "d04-setup-guarantee", "Draft landing-page claim guarantees every team a 10-minute setup; the record supports only a 15-minute median over 20 sessions",
 ["quality-claims", "aeo-answer-evidence"], ["quality", "aeo"], [c4], "high",
 "Proposal: remove the guarantee, the 10-minute figure and the universal scope; if a timing statement is wanted, restate the supplied statistic with its sample (median 15 minutes across 20 observed onboarding sessions). A guarantee needs an owner-approved guarantee policy, which is not supplied.",
 "Compare the revised claim with 04-editorial-proof.md:3-5: statistic, unit, sample and absence of guarantee language must match the record. Leave the FAQ and /status-codes unchanged.", "Content owner with product/legal reviewer");

writeFileSync("review.json", JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log("arith", 3000/35, 700/35, 15-12, 10-9, now);
