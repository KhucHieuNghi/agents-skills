import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const root = process.argv[2];
const hash = (b) => createHash("sha256").update(b).digest("hex");
const rep = readFileSync(`${root}/report.md`);
const lines = rep.toString("utf8").split("\n");
const quotes = []; const ws = (s) => s.replace(/\s+/g, " ").trim();
lines.forEach((line, i) => {
  const m = line.match(/^> `(0\d-[a-z-]+\.md):(\d+)(?:-(\d+))?` — (.*)$/);
  if (!m) return;
  const [, file, a, b, quote] = m;
  const src = readFileSync(`${root}/targets/${file}`);
  const span = ws(src.toString("utf8").split("\n").slice(a - 1, (b || a)).join(" "));
  if (!span.includes(ws(quote))) console.log("MISMATCH", i + 1, file, a, b);
  if (span !== ws(quote)) console.log("partial-span", i + 1, JSON.stringify(span), "||", JSON.stringify(ws(quote)));
  quotes.push({ quoteId: `q${quotes.length + 1}-L${i + 1}`, source: `targets/${file}`, sourceLabel: file, sourceHash: hash(src),
    startLine: +a, endLine: +(b || a), reportStartLine: i + 1, reportEndLine: i + 1, normalization: "whitespace", quote: quote.trim() });
});
writeFileSync("quotes.json", JSON.stringify({ root, report: "report.md", reportHash: hash(rep), quotes }, null, 2) + "\n");
console.log("quotes", quotes.length, "blockquote lines", lines.filter((l) => l.startsWith(">")).length);
