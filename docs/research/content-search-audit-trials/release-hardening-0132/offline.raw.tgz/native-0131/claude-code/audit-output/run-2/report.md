# Synthetic audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:16:06\.146Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run c9ab0623\-b06d\-46a0\-af03\-c158fdac8976\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| d01\-every\-billing\-option | Draft /compare assertion B claims Cedar is cheaper on every billing option; the annual record shows Fir lower | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: limit the claim to monthly billing \(as the /monthly\-comparison caption already does\) or state both options with their figures, keeping November 2026, US, USD\-before\-tax scope\. | Recompute each billing option from 01\-competitor\-claims\.md:6\-9 and confirm the revised wording makes no claim covering annual billing in Cedar&\#39;s favour\. | Content owner | small | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645, d01\-claims, d01\-entity |
| d01\-fir\-sso | Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: remove assertion A or replace it with a statement limited to the supplied docs \(SAML SSO on Fir Enterprise, minimum 20 paid seats\), without asserting anything about Fir&\#39;s other plans or citing the pricing table as proof\. | Re\-read the revised sentence against 01\-competitor\-claims\.md:12\-14; it must not claim absence of SSO and must not rely on the pricing\-table excerpt\. | Content owner with legal/competitive\-claims reviewer | small | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645, d01\-claims |
| d02\-cpa\-window\-mismatch | Draft A reports an October cost per conversion from full\-month spend and seven days of conversions | quality\-claims | quality | high | high | observed | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: drop the full\-month figure; report only the October 1\-7 figure already in the verified\-window caption and state that October 8\-31 conversions are unmeasured\. | Confirm numerator and denominator cover the same dates in the supplied rows \(02\-measurement\-windows\.md:5\-8\); a full\-month figure needs a conversion export covering October 8\-31, which is a new supply, not a reconstruction\. | Reporting/analytics owner | small | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35, d02\-claims |
| d03\-south\-same\-day | /south\-delivery states same\-day delivery; current approved policy for South is next\-business\-day only | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: replace the South passage with the approved South policy \(next\-business\-day delivery only\)\. Any cut\-off time or day restriction for South must come from the owner; none is supplied\. Leave /north\-delivery and /terms\-v1 unchanged and keep both regional pages\. | Compare the revised /south\-delivery passage with 03\-template\-service\-area\.md:4\-5 and confirm /north\-delivery and /terms\-v1 are unchanged\. | Content owner with operations/policy owner | small | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795, d03\-policy, d03\-entity |
| d04\-setup\-guarantee | Draft landing\-page claim guarantees every team a 10\-minute setup; the record supports only a 15\-minute median over 20 sessions | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: remove the guarantee, the 10\-minute figure and the universal scope; if a timing statement is wanted, restate the supplied statistic with its sample \(median 15 minutes across 20 observed onboarding sessions\)\. A guarantee needs an owner\-approved guarantee policy, which is not supplied\. | Compare the revised claim with 04\-editorial\-proof\.md:3\-5: statistic, unit, sample and absence of guarantee language must match the record\. Leave the FAQ and /status\-codes unchanged\. | Content owner with product/legal reviewer | small | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199, d04\-record |
| d02\-ai\-referral\-extrapolation | Draft B says 15 tracked sessions prove 150 AI\-generated sessions using an unsupplied one\-in\-ten rate | quality\-claims | quality | medium | high | observed | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | update | reviewer\-proposal | Draft assertion conflicts with or exceeds the owner\-supplied record in the same dossier; proposal only, no content change authorized\. | Proposal: report the observed count only \(15 October sessions with an identified AI\-assistant referrer; other sessions of unknown origin\) and remove the 150 total, the tracking rate and the word prove\. | Check the revised sentence contains only quantities present in 02\-measurement\-windows\.md:14\-16 and keeps the referral report separate from the campaign conversion counts \(lines 20\-21\)\. | Reporting/analytics owner | small | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35, d02\-claims |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | pending | Snapshot review incomplete | 26 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | pending | Snapshot review incomplete | 26 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | pending | Snapshot review incomplete | 26 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-claims | quality | fail | Draft A \(line 10\) divides full\-month spend \(3000, line 5\) by conversions from October 1\-7 only \(35, line 6\) and labels it October cost per conversion; conversions for October 8\-31 do not exist \(line 7\)\. Draft B \(lines 17\-18\) asserts 150 total sessions and a one\-in\-ten tracking rate with no supplied model \(lines 15\-16\)\. The October 1\-7 caption \(lines 11\-12\) is supported \(700 / 35 = 20\) and stays clean\. | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35, d02\-claims |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d02\-text |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-claims | quality | fail | The draft landing\-page claim \(line 6\) asserts a guarantee, a 10\-minute bound and universal scope; the approved record \(lines 3\-5\) supplies only a 15\-minute median over 20 observed sessions and no guarantee, maximum or population estimate\. The permissions FAQ \(line 9\) matches approved policy \(lines 10\-12\)\. /status\-codes is owner\-attested accurate \(lines 15\-18\); its table is not supplied\. | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199, d04\-record |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d04\-text |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | aeo\-answer\-evidence | aeo | fail | The landing\-page setup\-time promise is a material answer claim without source support \(line 6 vs 3\-5\)\. The permissions FAQ answer is supported and stays clean \(lines 9\-12\)\. | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199, d04\-record |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-claims | quality | fail | The current /south\-delivery passage \(lines 10\-11\) states same\-day delivery for South; the current approved policy \(line 5\) is next\-business\-day only\. /north\-delivery \(lines 8\-9\) matches policy \(lines 4\-5\)\. /terms\-v1 is an owner\-confirmed labeled 2024 archive \(lines 13\-16\) and stays clean\. | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795, d03\-policy |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d03\-text |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-entity\-consistency | aio | fail | The South service fact on /south\-delivery conflicts with the owner\-approved service record \(line 5\)\. North is consistent; the 2024 archive is a labeled version variant, not a conflict\. | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795, d03\-entity |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | aeo\-answer\-evidence | aeo | fail | The /south\-delivery policy passage is the page&\#39;s delivery\-timing answer and is contradicted by approved policy \(lines 10\-11 vs 5\)\. North passage supported\. No question set supplied; other AEO checks unknown\. | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795, d03\-policy |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-claims | quality | fail | Draft /compare assertion A \(line 17\) says Fir has no SSO, contradicted by the supplied Fir SSO docs \(line 13\); assertion B \(line 18\) says Cedar is cheaper on every billing option, contradicted on annual billing \(10 vs 9, lines 7 and 9\)\. The /monthly\-comparison caption \(line 21\) is supported \(15 \- 12 = 3\) and stays clean\. | d01\-claims, ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d01\-text |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-entity\-consistency | aio | fail | Draft assertion B&\#39;s price ordering conflicts with the owner price record for annual billing \(Cedar 10 vs Fir 9\)\. Monthly ordering is consistent\. | d01\-entity, ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | aeo\-answer\-evidence | aeo | fail | Assertions A and B are the comparison answers on the draft /compare page and lack source support \(lines 17\-18 vs 7, 9, 13\)\. The scoped monthly caption \(line 21\) is supported\. No question set was supplied; coverage/context checks stay unknown\. | d01\-claims, ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |
| e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 96a03c36611131ac89b2d29b3bb8c90d9b05f11325ab64cf36de3ddd7e57fb35 | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | local\-file | 2026\-11\-17T16:14:32\.314Z | 0 full elapsed days | [evidence/06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a\.txt](evidence/06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c14e5bc7d0620f037673b28d4193a512a914b1cd8224a60b3064930ad46be199 | 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | local\-file | 2026\-11\-17T16:14:32\.316Z | 0 full elapsed days | [evidence/157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827\.txt](evidence/157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 10c35ecaf057edd7bdc55570eb60863518f92f477b3ced8c349d790423e19795 | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | local\-file | 2026\-11\-17T16:14:32\.316Z | 0 full elapsed days | [evidence/dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0\.txt](evidence/dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ea92180427c7332beaf5edef30e857fa026cf09d8d16094b29967a9e21618645 | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | local\-file | 2026\-11\-17T16:14:32\.317Z | 0 full elapsed days | [evidence/e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52\.txt](evidence/e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d01\-text | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d01\-text\.txt](evidence/d01-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d02\-text | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d02\-text\.txt](evidence/d02-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d03\-text | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d03\-text\.txt](evidence/d03-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d04\-text | 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d04\-text\.txt](evidence/d04-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d01\-claims | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d01\-claims\.txt](evidence/d01-claims.txt) | b0fbf9adb70f08f7b46108db1c91c69245181da9e380fd60212c8a76af061e80 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d01\-entity | e3b81bafa5b18eecc498e9fd7dff5a27aab17c20b68a810109e65becc324aa52 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d01\-entity\.txt](evidence/d01-entity.txt) | ca5fa176fa23c61a3895acdf793828a5146101b634a24282e46117961616390a | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d02\-claims | 06bf742233ea00ef6f25db5da608eb405448fdd03ffb813a4caf1674a055d53a | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d02\-claims\.txt](evidence/d02-claims.txt) | 2a382711e7e8eb4072223605cf09ec6635285b20f4a53e26a097041e6888b1d2 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d03\-policy | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d03\-policy\.txt](evidence/d03-policy.txt) | 39b50509734f3033078a9acdf15bf5af0d08af2b3f35c485ab1e971d1bc430d6 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d03\-entity | dc59d22eb7bdc61345bac3f924dae2e1c9d88a6af31757d53f2bed3d9b2adae0 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d03\-entity\.txt](evidence/d03-entity.txt) | eaf68d6a5fa9353492e945673508a61725fe6efa4a901496e4ea22fd541227f6 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |
| d04\-record | 157e98ec9d53d1b8492302c82693360d2d55869aca305c6bcb679371462bc827 | local\-file | 2026\-11\-17T16:16:06\.037Z | 0 full elapsed days | [evidence/d04\-record\.txt](evidence/d04-record.txt) | ff366cc444bbd9014623c1c3019feff82cdc422a2e12f247cafe471097390457 | Synthetic owner\-supplied comparison record preserved from the dossier; not independently verified live behaviour |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
