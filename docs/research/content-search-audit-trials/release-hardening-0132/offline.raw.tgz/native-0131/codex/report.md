# Offline content and search audit

**Partial audit.** All four declared dossiers were collected and inspected in full. The validated run records **0 fully audited, 4 pending, 0 failed, 0 blocked, 0 unsupported and 0 excluded**. There are **6 material findings**. Pending refers to unresolved audit checks. The four dossiers are separate synthetic scenarios. The fifth file, [context.md](targets/context.md), supplies scope and instructions and was read in full. It is outside the four-item audit denominator.

The inventory is complete for the supplied files. The paths and drafts named inside them are components of those files. Only dossier 03 declares a complete scenario-level page inventory. Owner-approved records support comparisons within their synthetic scenario. No URLs were fetched, accounts accessed, or source files changed.

## Findings and verification

### 01 · Competitor claims

**F1 · Fir SSO denial on `/compare`** · Medium · Content quality, AIO, AEO

- Draft, 01-competitor-claims.md:17 — “Fir has no SSO, as its pricing table proves.”
- Supplied current Fir documentation, 01-competitor-claims.md:13 — “SAML SSO is available on Enterprise, with a minimum of 20 paid seats.”
- The pricing excerpt's silence cannot establish absence. The supplied docs contradict the categorical denial and leave other plans unspecified (01-competitor-claims.md:12-14). The claim can mislead an evaluator screening for SSO.
- State the Enterprise SAML SSO availability and minimum of 20 paid seats. Verify the revised assertion against the supplied documentation, retaining both qualifiers and avoiding implications about other plans.

**F2 · Universal price advantage on `/compare`** · Medium · Content quality, AIO, AEO

- Draft, 01-competitor-claims.md:18 — “Cedar is cheaper per seat than Fir on every billing option.”
- For the supplied November 2026 US plans, USD before tax, the monthly rates are Cedar USD 12 and Fir USD 15 per seat per month. Annual-billed monthly equivalents are Cedar USD 10 and Fir USD 9. Cedar saves USD 3 on the monthly comparison and costs USD 1 more on the annual equivalent. Optional services are excluded and none is required in the supplied comparison (01-competitor-claims.md:3-10).
- Present both billing comparisons with their units and scope. Verify each row against the supplied figures, including billing cadence, and avoid extending the figures to total cost, feature parity or unlisted plans.

**Supported component.** The separate `/monthly-comparison` caption is correct within its expressly limited scope. 01-competitor-claims.md:21 — “On the supplied monthly plans, Cedar is USD 3 less per seat per month before tax.” Cedar’s monthly no-seat-minimum detail is supplied separately (01-competitor-claims.md:6). The record gives no basis for a broader customer-level cost or conversion claim.

### 02 · Measurement windows

**F3 · Mismatched October cost-per-conversion windows in Draft A** · Medium · Content quality

- Draft, 02-measurement-windows.md:10 — “October cost per conversion was USD 85.71, from 3000 divided by 35.”
- USD 3,000 covers October 1–31, 2026, while 35 completed conversions cover October 1–7. USD 85.71 is the rounded quotient of those inputs, but it cannot establish a full-month rate. Spend for October 1–7 is USD 700, which yields USD 20 per completed conversion for that window. Conversion data for October 8–31 is missing (02-measurement-windows.md:3-8).
- Use the existing first-week caption wherever the draft currently claims an October rate. Verify the campaign, currency, dates and conversion definition match for numerator and denominator. Compute a full-month value only with complete comparable October conversion data.

**F4 · Unsupported AI referral extrapolation in Draft B** · Medium · Content quality, with a GEO measurement limitation

- Draft, 02-measurement-windows.md:17-18 — “These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked.”
- The independent synthetic referral report identifies 15 October sessions with an AI-assistant referrer. Other sessions have unknown origin. The dossier supplies no evidence for the one-in-ten tracking factor, a complete session count, an incrementality test or conversion linkage (02-measurement-windows.md:14-21). The observed referrer count supports neither a total estimate nor causal attribution.
- Report the 15 identified sessions and the unknown origin of other sessions. Keep the referral report separate from the campaign conversion counts. Verify the reported count against the independent source and require a separately validated attribution method before estimating total influence or incremental outcomes.

**Supported component.** The aligned caption accurately preserves its window and missingness. 02-measurement-windows.md:11-12 — “For October 1–7, observed cost per completed conversion was USD 20 (700 divided by 35). The rest of the month is unmeasured.”

### 03 · Service-area template

**F5 · Wrong current South delivery promise on `/south-delivery`** · High · Content quality, AIO, AEO, portfolio

- Current South passage, 03-template-service-area.md:10-11 — “South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date.”
- Approved South policy, 03-template-service-area.md:5 — “South serves next-business-day delivery only.”
- The current South page repeats North's service rule. The mismatch can cause customers to plan around unavailable same-day service and makes the supplied South answer unreliable when read independently.
- Replace the South passage with the approved next-business-day rule. Verify both complete current passages against their own regional policies and confirm the archive still identifies the 2024 contract and links to both current pages.

**Supported components.** North’s complete passage matches the approved Monday–Friday same-day service for orders before 10:00 local time and addresses orders outside that window (03-template-service-area.md:4-9). The owner confirms that `/terms-v1` accurately covers old orders under the 2024 contract, when South had same-day service, and directs new orders to the current pages (03-template-service-area.md:13-16). Both current regional pages serve distinct tasks. The shared layout and generic contact wording provide no basis for merging them or alleging cannibalization. Search selection and query/page behavior are unavailable (03-template-service-area.md:18-20).

### 04 · Editorial proof

**F6 · Unsupported universal setup guarantee on the draft landing page** · High · Content quality, AEO

- Draft, 04-editorial-proof.md:6 — “Every team is guaranteed to finish setup in 10 minutes.”
- Approved evidence, 04-editorial-proof.md:3-5 — “Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.”
- The draft offers a decision-facing setup-time answer stronger than the study supports. The median describes the observed sessions. A universal deadline and guarantee require separate evidence.
- Withdraw the guarantee. If citing the study, attribute a median of 15 minutes across 20 observed onboarding sessions. Check the revised sentence against the supplied study summary for the sample size, statistic and scope, and check that no ceiling, refund or universal promise is implied.

**Supported components.** The permissions FAQ fully answers which role can delete a workspace. 04-editorial-proof.md:9 — “Can editors delete the workspace? No. Only workspace owners can delete it.” The approved policy confirms both parts and the task requires no deletion walkthrough (04-editorial-proof.md:10-13). The owner attests that `/status-codes` is complete and accurate for its technical reference task. Its table rows were not reproduced in the dossier, so their accuracy was not independently checked. Terse style, punctuation and the absence of a purchase CTA are consistent with the stated documentation task. There is no authorship or user-task failure evidence (04-editorial-proof.md:15-19).

## Six-dimension assessment by dossier

The task descriptions below come from the supplied copy and owner scope. The language of the supplied excerpts is English. Audience and market beyond the stated scope are unknown.

| Dossier and task | Content quality | SEO | AIO readiness | AEO answer quality | GEO visibility | Portfolio |
|---|---|---|---|---|---|---|
| 01 · Evaluate US plan pricing and SSO | F1–F2. Monthly caption supported. Other Fir plan SSO unknown. | Component paths and excerpts only. Metadata, crawl, index and link signals unavailable. | Pricing and entitlement conflicts in the draft. The monthly caption preserves billing scope. Access and retrieval unknown. | Decision-facing SSO and all-billing answers fail factual support. Monthly answer is scoped. Wider question coverage unknown. | No engine responses or conversions supplied. | The limited caption and broader comparison serve identifiable evaluation tasks. Preserve their scopes. Broader inventory, links and demand unknown. |
| 02 · Interpret October 2026 USD campaign and referral reporting | F3–F4. Aligned first-week caption supported. | Reporting excerpts provide no publishing or technical search evidence. | The aligned caption can be read with its window. The draft window and referral inference could mislead if reused. Publication intent and retrieval unknown. | The first-week caption is self-contained. Draft metrics require the corrections above. No supplied audience question set or search answer target. | 15 identified referral sessions are supplied. Response-level presence, citations and accuracy are unmeasured. | Campaign outcome reporting and independent referral reporting serve distinct tasks. Keep evidence separate. Wider portfolio coverage unknown. |
| 03 · Choose a delivery date or consult terms for an old order | F5. North current policy and historical archive supported. | Archive-to-current links are owner-reported. Actual targets, metadata, index directives and engine treatment unknown. | Current South conflicts with the policy record. Region and version distinguish the other passages. Retrieval unmeasured. | The complete South passage gives the wrong delivery expectation. North answers within its window. Broader demand unknown. | No response captures, rankings or query/page behavior supplied. | Three declared pages cover two regions and a separate historical task. Correct South and retain all three. Full link behavior and demand gaps unknown. |
| 04 · Evaluate setup time, identify permissions, look up status codes | F6. FAQ supported. Reference table owner-attested. | Actual title, headings, metadata, directives, links and rendering unavailable. | The FAQ supports a standalone answer. The landing claim would misstate the study if reused. Reference table extraction and crawler access unknown. | The supplied editor question is fully answered. The landing-page setup answer fails evidence review. The status reference is a separate technical task. | No response captures or visibility metrics supplied. | Landing decision, permission lookup and status lookup are distinct tasks. No supplied evidence for an acquisition gap or broader consolidation. |

## Measurements and remaining coverage

The only supplied quantitative observations are synthetic and scoped. Dossier 02 supplies October spend, a one-week conversion count and spend subtotal, and an independent referral count. Dossier 04 supplies a study sample size and median for the observed sessions. Dossier 01 supplies pricing records. There are no Search Console, GA4, Bing, server-log or AI-response exports to import. Rankings, keyword volume, query/page overlap, index status, live retrieval, AI mentions, citations, recommendations and answer accuracy are unavailable. The referral count cannot populate any of those measures.

For a later authorized review, use supplied dated HTML, headers, rendered snapshots and crawl/link inventories to test response, directives, canonical, metadata, links, structured data, locale and rendering checks. Use the publisher's intent and agent-specific controls for crawler checks. Complete page/media inventories, approved claim sources, task evidence and customer question sets would support the remaining quality, AIO, AEO and portfolio decisions. Collect October 8–31 conversions on the same basis as October 1–7 before testing monthly cost per conversion. For AI visibility, use versioned task-based prompt cohorts and preserved response artifacts. Retain market, language, engine, surface, search mode, model if available, dates and repetitions. Count and report mentions, citations and adjudicated claim accuracy with their own denominators and missingness. No live surface was measured in this audit.

| Dimension | Required checks | Resolved | Unknown |
|---|---:|---:|---:|
| Content quality | 20 | 9 | 11 |
| SEO | 32 | 0 | 32 |
| AIO | 12 | 2 | 10 |
| AEO | 12 | 4 | 8 |
| GEO | 12 | 0 | 12 |
| Portfolio | 16 | 2 | 14 |
| **Total** | **104** | **17** | **87** |

The validator found no missing check records or queued discovery work. The 87 unknown checks prevent full completion. The scenario assessments above preserve supported component observations even where the corresponding whole-dossier rule remains open. See the [validated coverage](audit-validation.json), [reviewed run](audit-reviewed/coverage.json) and [quote verification receipt](quote-receipt.json).
