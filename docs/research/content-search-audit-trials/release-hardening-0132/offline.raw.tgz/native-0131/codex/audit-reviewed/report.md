# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:15:17\.762Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 4e8dac88\-8ed6\-43b4\-a836\-a008e47284bb\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| setup\-guarantee | Setup\-time guarantee exceeds the onboarding study | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the universal 10\-minute guarantee\. If reporting the study, state the 15\-minute median across 20 observed sessions\. | Verify the exact sample size and statistic against lines 3–5 and check that the revised copy makes no guarantee or wider\-population claim\. | Content or reporting owner | small | 04\-claim\-sources, aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| south\-policy | South current page states the wrong service level | quality\-claims, quality\-task\-fit, aeo\-answer\-evidence, aio\-entity\-consistency, portfolio\-contradictions | quality, aeo, aio, portfolio | high | high | observed | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Replace the copied service rule with next\-business\-day delivery only and retain region and archive distinctions\. | Compare revised South and North passages with approved policy, and confirm the archive remains labeled 2024 and links to both current pages\. | Content or reporting owner | small | 03\-audience\-context, 03\-claim\-sources, 03\-entity\-record, 03\-inventory\-map, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| billing\-comparison | Universal price advantage reverses on annual billing | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | medium | high | observed | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Show the supplied monthly and annual\-billed rates independently with US, USD, pre\-tax and time scope\. | Compare both revised billing rows with lines 3–10 and confirm monthly Cedar advantage is USD 3 and annual Fir advantage is USD 1 per seat per month equivalent\. | Content or reporting owner | small | 01\-claim\-sources, 01\-entity\-record, 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| conversion\-window | October cost per conversion uses mismatched windows | quality\-claims | quality | medium | high | observed | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Use the aligned October 1–7 cost per completed conversion and label October 8–31 unmeasured\. | Verify same campaign, currency, dates and conversion definition in numerator and denominator before recomputing\. | Content or reporting owner | small | 02\-claim\-sources, bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| fir\-sso | Fir SSO denial contradicts the supplied Enterprise documentation | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | medium | high | observed | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | State Enterprise SAML SSO and the 20 paid\-seat minimum\. Treat other plans as unspecified in the supplied records\. | Check the final claim against lines 12–14, retaining plan, SAML and seat minimum\. | Content or reporting owner | small | 01\-claim\-sources, 01\-entity\-record, 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| referral\-extrapolation | Tracked AI referrals are extrapolated without an attribution model | quality\-claims | quality | medium | high | observed | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Report the 15 identified October sessions, unknown origin of other sessions, and unavailable total AI influence\. | Match the reported count to the referral record and ensure no multiplier, causal or conversion assertion is implied\. | Content or reporting owner | small | 02\-claim\-sources, bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 4 | 8 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 9 | 11 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | pending | Snapshot review incomplete | 26 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | pending | Snapshot review incomplete | 26 |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | pending | Snapshot review incomplete | 26 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | quality\-task\-fit | quality | fail | The complete current South policy passage conflicts with the approved South policy\. North matches its current policy\. The clearly labeled 2024 archive describes a separate contract\. | 03\-audience\-context, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | quality\-claims | quality | fail | The complete current South policy passage conflicts with the approved South policy\. North matches its current policy\. The clearly labeled 2024 archive describes a separate contract\. | 03\-claim\-sources, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 03\-extracted\-text |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aio\-entity\-consistency | aio | fail | The complete current South policy passage conflicts with the approved South policy\. North matches its current policy\. The clearly labeled 2024 archive describes a separate contract\. | 03\-entity\-record, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | aeo\-answer\-evidence | aeo | fail | The complete current South policy passage conflicts with the approved South policy\. North matches its current policy\. The clearly labeled 2024 archive describes a separate contract\. | 03\-claim\-sources, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | portfolio\-duplication | portfolio | pass | The complete declared three\-page map supports distinct region and time tasks\. Shared layout and generic contact language are intentional\. The wrong South rule is recorded under the policy finding\. | 03\-inventory\-map, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | portfolio\-contradictions | portfolio | fail | The complete current South policy passage conflicts with the approved South policy\. North matches its current policy\. The clearly labeled 2024 archive describes a separate contract\. | 03\-entity\-record, 03\-inventory\-map, 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | quality\-claims | quality | fail | The decision\-facing SSO and all\-billing assertions in /compare conflict with the supplied November 2026 US records\. The separate monthly caption agrees with the monthly records\. | 01\-claim\-sources, 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 01\-extracted\-text |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aio\-entity\-consistency | aio | fail | The decision\-facing SSO and all\-billing assertions in /compare conflict with the supplied November 2026 US records\. The separate monthly caption agrees with the monthly records\. | 01\-entity\-record, 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | aeo\-answer\-evidence | aeo | fail | The decision\-facing SSO and all\-billing assertions in /compare conflict with the supplied November 2026 US records\. The separate monthly caption agrees with the monthly records\. | 01\-claim\-sources, 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | quality\-claims | quality | fail | Draft A mixes monthly spend with one week of conversion data; Draft B asserts a total and tracking rate without evidence\. The aligned first\-week caption is supported\. | 02\-claim\-sources, bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 02\-extracted\-text |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | quality\-claims | quality | fail | The landing page gives a decision\-facing setup\-time answer as a universal guarantee\. The approved evidence only gives an observed median\. The separate permission FAQ matches its policy and the status\-code table is owner\-attested\. | 04\-claim\-sources, aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 04\-extracted\-text |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aeo\-question\-coverage | aeo | pass | The entire supplied explicit question set contains the editor permission question\. The FAQ directly answers it with the correct owner role\. The adjacent setup promise is assessed under factual support, and the status\-code reference is a separate technical task\. | 04\-question\-set, aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | aeo\-answer\-evidence | aeo | fail | The landing page gives a decision\-facing setup\-time answer as a universal guarantee\. The approved evidence only gives an observed median\. The separate permission FAQ matches its policy and the status\-code table is owner\-attested\. | 04\-claim\-sources, aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |
| aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 19567a732defaa89b7081b33278481c0ce01c3f178e84b404b4203e5cc901383 | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:14:21\.834Z | 0 full elapsed days | [evidence/3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8\.txt](evidence/3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3c81dc3f2516235ca89ede0853bd259b0bfbe7d3dfabd0b1a3a0f16fab73b627 | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | local\-file | 2026\-11\-17T16:14:21\.836Z | 0 full elapsed days | [evidence/8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795\.txt](evidence/8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| bf3ac425a61a9ec4eac994e890d1b0a630f293bf1160bf068dbe19fc8a6491dd | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | local\-file | 2026\-11\-17T16:14:21\.837Z | 0 full elapsed days | [evidence/8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde\.txt](evidence/8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| aec96d126872515c8d9aa4935604034871e89e748af017f02c945357247307f9 | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | local\-file | 2026\-11\-17T16:14:21\.838Z | 0 full elapsed days | [evidence/aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0\.txt](evidence/aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 03\-claim\-sources | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/03\-claim\-sources\.txt](evidence/03-claim-sources.txt) | 910e0cb6ab291ec82f61e5031f446f33286a2f03b5e94b90c1ec0b0a9c69d342 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 03\-entity\-record | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/03\-entity\-record\.txt](evidence/03-entity-record.txt) | 910e0cb6ab291ec82f61e5031f446f33286a2f03b5e94b90c1ec0b0a9c69d342 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 03\-inventory\-map | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/03\-inventory\-map\.txt](evidence/03-inventory-map.txt) | 78ad5ded84584cacbe7f5931968bda1b9a777c7857b597035e863f8af658482a | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 03\-audience\-context | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/03\-audience\-context\.txt](evidence/03-audience-context.txt) | 78ad5ded84584cacbe7f5931968bda1b9a777c7857b597035e863f8af658482a | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 03\-extracted\-text | 3a1f6deb3afac7ef5958dbb458511c447098928f82268005b00946217541cad8 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/03\-extracted\-text\.txt](evidence/03-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 01\-claim\-sources | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/01\-claim\-sources\.txt](evidence/01-claim-sources.txt) | 6cfa66eeb3a8c71dbb4dfde0e787615be14a976daf49a59622dd3ee9cefc0bcc | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 01\-entity\-record | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/01\-entity\-record\.txt](evidence/01-entity-record.txt) | 6cfa66eeb3a8c71dbb4dfde0e787615be14a976daf49a59622dd3ee9cefc0bcc | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 01\-audience\-context | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/01\-audience\-context\.txt](evidence/01-audience-context.txt) | 7a758cdf337c83ea2f5ac7e33eec7e294aebe064e4e5e670f5482e785e100690 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 01\-extracted\-text | 8644e0d96861584bd659e2e60297eeb390c73fac26fc468f94ea56ae24de7795 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/01\-extracted\-text\.txt](evidence/01-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 02\-claim\-sources | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/02\-claim\-sources\.txt](evidence/02-claim-sources.txt) | 329b11dc2b4606def000a01d5e95020a3960eabf78e0a83bfc06173366dbfaa5 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 02\-audience\-context | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/02\-audience\-context\.txt](evidence/02-audience-context.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 02\-extracted\-text | 8b9d127014f473162b5efe2a6fa09f4e53b9b2046668bb935413536d0c511bde | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/02\-extracted\-text\.txt](evidence/02-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 04\-claim\-sources | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/04\-claim\-sources\.txt](evidence/04-claim-sources.txt) | 2650c5d9db85561c5312c64531adcfa3e8f68da10be9aacb76b5c306ef256c8e | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 04\-question\-set | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/04\-question\-set\.txt](evidence/04-question-set.txt) | 9cfa13def3b25d421c999cfc938b28a8203ce3a80feb3156f41575940095013a | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 04\-audience\-context | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/04\-audience\-context\.txt](evidence/04-audience-context.txt) | 6b0bf235b828e47d84e597d34510b141a2570cacd03f02d35a11da3f4c0b9216 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |
| 04\-extracted\-text | aa19e8ee939442de95ee332688b65549d1cb37d3d50920fd531664f62da250a0 | local\-file | 2026\-11\-17T16:15:17\.634092\+00:00 | 0 full elapsed days | [evidence/04\-extracted\-text\.txt](evidence/04-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Attributed excerpt from the supplied synthetic dossier\. Live behavior was unverified\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
