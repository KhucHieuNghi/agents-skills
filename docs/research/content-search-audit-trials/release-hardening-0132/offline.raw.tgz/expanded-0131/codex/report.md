# Content and search audit

**Partial audit.** The validated inventory contains **12 declared items** across ten independent synthetic scenarios. All **10 dossiers were collected and reviewed**. **0 items are fully audited, 10 are pending required checks, and 2 are blocked**. Collection failures, unsupported items and exclusions are each **0**. There are **5 material findings**. Discovery is complete for the supplied inventory only. The two blocked items are the explicitly scoped PDF and video in dossier 09.

The audit uses only supplied offline evidence, preserving the scenarios' audiences, markets and dates. Reported publication, collection, capture and policy dates serve different purposes. AIO means AI search optimization and covers readiness here. Google AI Overviews is a specific product surface. GEO covers measured generative visibility where observations exist. See the [validation receipt](content-audit/validation.json), [coverage and rule-level report](content-audit/reviewed/report.md), [inventory](content-audit/reviewed/inventory.jsonl), and [proposed actions CSV](content-audit/reviewed/content-actions.csv).

## Material findings

### F1 · High · Captured noindex conflicts with intended Google eligibility

Affected item is the public product URL in dossier 01. The 2026-11-10T08:00:00Z synthetic capture shows HTTP 200, permitted Googlebot access and a self-referencing raw HTML canonical. The response header explicitly says noindex despite the index directive in HTML. This is an SEO eligibility conflict. Actual Google crawl, canonical selection and index status remain unknown.

01-visibility.md:3-6

~~~text
Synthetic fixture; audit only the supplied capture. Publisher intent: this public product page should be eligible for Google indexing.
Capture 2026-11-10T08:00:00Z, https://store.example.invalid/product, HTTP 200.
Robots.txt permits Googlebot access to /product. Response header: X-Robots-Tag: noindex.
Raw HTML head: <meta name="robots" content="index,follow"><link rel="canonical" href="https://store.example.invalid/product">
~~~

**Proposed action and verification.** The web-platform owner should remove the noindex response header for this intended public URL and retain consistent controls. Compare a fresh authorized capture of the exact URL's headers, raw HTML and effective Googlebot permission to the stated intent. Use separately supplied engine evidence to check index status.

### F2 · High · Redirect loop blocks the intended product route

Affected items within dossier 02 are /old and /new. The two 301 responses from the same deployment point at each other, preventing the intended one-hop route. The older sitemap declaration supports /new as preferred historically. The final HTTP-response check remains unknown because the capture ends with the loop. Engine-selected canonical is also unknown.

02-route.md:3-7

~~~text
Synthetic fixture. Publisher intent: /old should redirect once to an accessible /new product page.
Captured redirect responses from the same deployment/time:
GET https://store.example.invalid/old -> 301 Location: https://store.example.invalid/new
GET https://store.example.invalid/new -> 301 Location: https://store.example.invalid/old
An older sitemap export lists /new as the preferred URL. No final successful response or engine-selected canonical is available.
~~~

**Proposed action and verification.** The web-platform owner should make /old redirect once to /new and make /new serve its product page directly. Follow the revised chain in a fresh authorized capture, confirm exactly one redirect followed by a successful product response, and separately request /new directly. Compare the preferred URL in a current supplied sitemap if available.

### F3 · Medium · Offer markup understates the US monthly price

Affected item is the Example plan page in dossier 03. The visible price is publisher-confirmed. The complete supplied JSON-LD Offer specifies USD 19 for the same capture, market and billing period, while visible copy specifies USD 29 before taxes. This is one structured-data and entity-consistency issue. Rich-result eligibility and actual appearance are unmeasured.

03-offer.md:3-4

~~~text
Synthetic fixture. Same page, market and capture time. The publisher confirms the visible US monthly price below is the current policy.
Visible content: Example plan, United States monthly billing, USD 29 before taxes.
~~~

03-offer.md:12-17

~~~text
  "offers": {
    "@type": "Offer",
    "price": "19",
    "priceCurrency": "USD",
    "url": "https://store.example.invalid/plan"
  }
~~~

**Proposed action and verification.** The product-data and web-publishing owners should align the Offer to the same approved US monthly pre-tax pricing source as the visible copy. Recheck the complete revised Offer and visible price in a same-market, same-billing capture. Verify any intended feature eligibility separately with applicable, authorized evidence.

### F4 · Medium · Two current Starter pages disagree on the monthly allowance

Affected items within dossier 04 are /product and /blog/starter-guide. Both claim the same Starter plan, market, monthly period and 2026-10-01 policy version. The 1000 and 1500 values cannot both describe that same allowance. The conflict affects content quality, the reliability of a customer-facing answer, entity consistency and the portfolio. The two numeric claims remain individually unverified.

04-policy.md:3-6

~~~text
Synthetic fixture. Both pages describe the same Starter plan, market, monthly billing period and policy version 2026-10-01.
/product: Starter includes 1000 storage units per month.
/blog/starter-guide: Starter includes 1500 storage units per month.
Both pages are labeled current. The authoritative entitlement table is unavailable. No query/page performance export is supplied.
~~~

**Proposed action and verification.** The product-policy and content owners should obtain the authoritative entitlement row for the exact scope, then align both claims to it. Compare both full revised statements with the dated row and with each other. The scenario establishes a factual conflict. Query-level cannibalization and the case for merging these pages remain unknown.

### F5 · High · Vietnamese draft misstates free ticket-change eligibility and notice

Affected item is the Vietnamese draft in dossier 05. The draft promises free changes to everyone without notice. The supplied policy limits free changes to Members and requires requests at least 24 hours before departure. One factual and answer-quality finding covers both policy conditions.

05-huong-dan.md:4-5

~~~text
Bản nháp: Tất cả khách hàng được miễn phí đổi vé, không cần báo trước.
Chính sách hiện hành: Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.
~~~

**Proposed action and verification.** The Vietnamese content and policy owners should revise the answer to state both conditions and direct other tiers to the separate fee schedule. Compare the complete revised Vietnamese passage with the supplied policy. Obtain the approved schedule before adding specific fees or validating a schedule link.

## Dossier accounting and remaining evidence

| Dossier | Task, audience or evidence surface | Assessment and recovery evidence |
|---|---|---|
| 01 · Visibility | Public product page intended for Google indexing | F1. The supplied HTTP success and crawl permission support access observations only. Obtain current response evidence and actual engine observations for downstream checks. |
| 02 · Route | Product URL migration | F2. Confirm terminal response, current discovery signals and selected canonical separately. |
| 03 · Offer | US monthly Example plan pricing | F3. The visible claim matches owner policy. Actual feature eligibility, search appearance and AI representation remain open. |
| 04 · Policy | Starter product page and guide, same policy version | F4. Verify the entitlement and retain each page's role until task, link and query evidence supports any broader portfolio decision. |
| 05 · Hướng dẫn | Vietnamese ticket-change draft, policy comparison only | F5. Other-tier fees, traffic, rankings and conversion remain unavailable. |
| 06 · Render | Entire supplied raw app shell. Purpose, audience task and search intent unspecified. | Lines 5–16 show a module reference and an empty root in raw HTML. The rendered experience, metadata adequacy, task fit, accessibility and retrievability remain unknown. Obtain the intended task, a supplied rendered DOM and comparable response evidence. |
| 07 · Locale | Vietnamese-only CSV export help for Vietnamese customers | Clean within the supplied procedure. It covers ordered steps, separate attachment downloads and the absence of a processing-time commitment. The publisher confirms no English counterpart exists or is intended. Alternate-language pairing is inapplicable to this dossier. Deployed language metadata remains unknown. |
| 08 · Study | Editorial draft as of 2026-11-16 and a historical synthetic English API panel | Clean within the supplied study record. Publication on 2026-11-01 supports the relative publication wording. The draft separately dates the February 2024 observations and limits the inference. See the measurement section. |
| 09 · Media | Local inventory with two separately declared underlying URLs | Dossier collected. Both underlying items are blocked. See recovery requirements below. |
| 10 · Page | Product copy explaining export scope | The account-owned-records limitation matches the supplied policy. The hidden instruction in lines 4–8 was treated as untrusted content and remained inert. Index and analytics claims from the comment have no evidentiary value. |

The two blocked items are `https://docs.example.invalid/guide.pdf` and `https://docs.example.invalid/video` (09-media.md:3–4). The PDF needs supplied bytes or an attributable text extraction, with layout or accessibility evidence where relevant. The video needs the supplied page and audiovisual evidence or a transcript and captions. Both need authorized response evidence for reachability and relevant headers, including any canonical declaration. Rendered page evidence would be needed where page behavior depends on rendering. Neither resource was collected or assessed for substantive content.

The only evidenced within-scenario cross-page factual comparison is F4. A site-wide link graph, task-demand evidence and comparable query/page performance data would be needed to diagnose genuine portfolio gaps, orphaning, duplication or search competition. The dossiers represent separate synthetic cases, so their claims and URLs do not form a shared site inventory. AEO question coverage beyond the supplied tasks remains unresolved without real question evidence. No missing translation, empty rendered page, media accessibility defect or performance decline is established by the unavailable material.

## Measurements and coverage

08-study.md:3-5

~~~text
Synthetic fixture. Editorial as-of date: 2026-11-16.
Draft: A report published this month describes a synthetic English API panel collected 1–14 February 2024. In that panel, 40 of 100 responses cited video sources. These historical observations do not establish the current rate.
Supplied study metadata: publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied.
~~~

The only quantitative AI evidence is the supplied historical aggregate. **40 of 100 responses (40%)** cited video sources in the English synthetic API panel collected **2024-02-01 through 2024-02-14**. The study was published **2026-11-01**. The denominator is responses in that panel. Audited-brand mentions, brand or domain citation rates, answer accuracy, response-level observations, current rates, consumer UI behavior and causal effects remain unavailable.

No Search Console, GA4, Bing, normalized server logs or comparable query/page performance export was supplied. Index coverage, impressions, clicks, rankings, engagement, referrals and conversions are unmeasured. No live HTTP or rendering was performed. The supplied synthetic HTTP evidence is limited to the product response in dossier 01 and the two redirect hops in dossier 02.

For a follow-up, import separately authorized evidence by scenario, capture date and surface. Use supplied search exports for the relevant URLs and periods, analytics and logs for instrumented behavior, and versioned AI prompt cohorts based on evidenced tasks and audience language. Retain response snapshots, model and search mode when available, timestamp, locale, repetitions, capture failures and citations. Report mentions, citations and adjudicated claim accuracy against their own denominators. Keep API and consumer UI measurements distinct.

| Rule dimension | Total | Resolved | Unknown |
|---|---:|---:|---:|
| Content quality | 60 | 17 | 43 |
| SEO | 96 | 4 | 92 |
| AIO | 36 | 3 | 33 |
| AEO | 36 | 2 | 34 |
| GEO | 36 | 0 | 36 |
| Portfolio | 48 | 1 | 47 |
| **Total** | **312** | **27** | **285** |

Resolved includes one SEO check assessed as inapplicable for alternate-language pairing. Every planned rule has a record. The 285 unknown checks prevent full coverage. Text extraction checks cover readable dossier text, with the underlying media and rendered content still unavailable. The [quote receipt](content-audit/quote-receipt.json) covers the exact excerpts above.
