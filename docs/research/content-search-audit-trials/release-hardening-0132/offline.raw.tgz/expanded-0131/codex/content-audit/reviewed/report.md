# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:19:52\.775Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 46ebbdc8\-bfba\-4256\-a190\-5825403ebd05\. 5 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | Index directive conflicts with intended Google eligibility | seo\-index\-controls | seo | high | high | observed | 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Remove the noindex response header for the intended public product URL\. Preserve consistent index directives\. | Compare a fresh authorized response header and HTML capture with publisher intent\. Check actual Google index evidence separately\. | Web platform | small | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e, 01\-http\-response, 01\-publisher\-intent |
| F2 | Redirect pair loops between /old and /new | seo\-response | seo | high | high | observed | 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Configure /old to redirect once to /new and make /new serve its product page directly\. | Inspect a same\-deployment capture starting at /old for exactly one redirect followed by a successful /new response, and confirm /new also succeeds directly\. | Web platform | small | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231, 02\-redirect\-chain |
| F5 | Draft overstates free ticket\-change eligibility | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Specify Member\-only free changes and a request at least 24 hours before departure\. Direct other tiers to the separate fee schedule without inventing amounts\. | Compare the complete revised Vietnamese answer with all supplied policy conditions\. Verify any fee amounts or link separately against the approved schedule\. | Vietnamese content and policy | small | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f, 05\-claim\-sources |
| F3 | Offer markup understates the US monthly price | seo\-structured\-data, aio\-entity\-consistency | seo, aio | medium | high | observed | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Set the Offer price to USD 29 before taxes for the US monthly Example plan, ideally using the same approved data source as visible copy\. | Compare the full revised Offer with the policy and visible content in a same\-market, same\-billing capture\. Assess feature eligibility separately if evidence becomes available\. | Product data and web publishing | small | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c, 03\-schema\-extraction, 03\-entity\-record |
| F4 | Current Starter pages disagree on the monthly entitlement | portfolio\-contradictions, aio\-entity\-consistency | portfolio, aio | medium | high | observed | af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | investigate | reviewer\-proposal | The authoritative entitlement must be established before either page is edited\. | Obtain the authoritative entitlement table for the stated market, billing period and policy version, then align both pages to the confirmed allowance\. | Compare both complete revised claims against the applicable authoritative row and each other\. | Product policy and content | medium | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c, 04\-entity\-record, 04\-inventory\-map |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 2 | 34 | 0 |
| aio | 36 | 3 | 33 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 1 | 47 | 0 |
| quality | 60 | 17 | 43 | 0 |
| seo | 96 | 3 | 92 | 1 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | pending | Snapshot review incomplete | 26 |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | pending | Snapshot review incomplete | 26 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | pending | Snapshot review incomplete | 26 |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | pending | Snapshot review incomplete | 26 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | pending | Snapshot review incomplete | 26 |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | pending | Snapshot review incomplete | 26 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | pending | Snapshot review incomplete | 26 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | pending | Snapshot review incomplete | 26 |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | pending | Snapshot review incomplete | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 06\-extracted\-text |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | seo\-rendering | seo | unknown | The raw shell contains an empty root and a module reference\. Rendered DOM and intended task are unavailable\. | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | quality\-claims | quality | fail | The draft misstates both the eligible tier and required notice relative to the supplied policy\. | 05\-claim\-sources, 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 05\-extracted\-text |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | aeo\-answer\-evidence | aeo | fail | The draft misstates both the eligible tier and required notice relative to the supplied policy\. | 05\-claim\-sources, 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | quality\-task\-fit | quality | pass | The supplied Vietnamese procedure gives the export steps and explains how to access excluded attachments\. | 07\-audience\-context, 07\-claim\-sources, 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | quality\-claims | quality | pass | The supplied product procedure confirms the steps and limitations, including the absence of a processing\-time commitment\. | 07\-claim\-sources, 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 07\-extracted\-text |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-locales | seo | not\-applicable | The entire supplied Vietnamese\-only document has no existing or intended alternate\-language counterpart\. Deployed metadata remains unavailable\. | 07\-audience\-context, 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aio\-retrievable\-facts | aio | pass | The supplied Vietnamese help text presents the procedure and its limits together\. | 07\-audience\-context, 07\-claim\-sources, 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | aeo\-answer\-evidence | aeo | pass | All material procedural statements match the supplied product procedure\. | 07\-claim\-sources, 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | quality\-claims | quality | pass | The publisher confirms the supplied visible US monthly price before taxes\. | 03\-claim\-sources, 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 03\-extracted\-text |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-structured\-data | seo | fail | The complete supplied Offer has USD 19 while visible approved US monthly pricing is USD 29\. | 03\-entity\-record, 03\-schema\-extraction, 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aio\-entity\-consistency | aio | fail | The same market, billing period and plan have different prices in visible copy and markup\. | 03\-entity\-record, 03\-schema\-extraction, 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 02\-extracted\-text |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-response | seo | unknown | The two supplied 301 hops establish a loop\. A final response status was never captured\. | 02\-redirect\-chain, 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 01\-extracted\-text |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | 01\-http\-response |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-index\-controls | seo | fail | HTTP header declares noindex despite intended Google eligibility and permissive HTML meta\. | 01\-http\-response, 01\-publisher\-intent, 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 09\-extracted\-text |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | quality\-claims | quality | pass | The only supplied user\-visible claim agrees with the supplied export policy\. The hidden comment is inert audit data\. | 10\-claim\-sources, b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 10\-extracted\-text |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | quality\-claims | quality | unknown | The supplied entitlement assertions disagree and the authoritative table is unavailable\. | 04\-entity\-record, 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 04\-extracted\-text |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aio\-entity\-consistency | aio | fail | The two current pages conflict for the same plan, market, billing period and 2026\-10\-01 version\. The authoritative quantity is unknown\. | 04\-entity\-record, 04\-inventory\-map, 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | portfolio\-contradictions | portfolio | fail | The two current pages conflict for the same plan, market, billing period and 2026\-10\-01 version\. The authoritative quantity is unknown\. | 04\-entity\-record, 04\-inventory\-map, 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | quality\-claims | quality | pass | At the supplied editorial as\-of date, the November 2026 publication, February 2024 collection and 40/100 historical synthetic API result are correctly scoped\. | 08\-claim\-sources, e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | quality\-freshness | quality | pass | At the supplied editorial as\-of date, the November 2026 publication, February 2024 collection and 40/100 historical synthetic API result are correctly scoped\. | 08\-claim\-sources, e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 08\-extracted\-text |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | geo\-observed\-presence | geo | unknown | Historical aggregate video\-source citations are supplied, without response\-level, audited\-brand or current visibility data\. | 08\-claim\-sources, e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |
| f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 662d9099ec9a5b8e9c503d7538be35e3d2aab0515e3fa9ade2c84341436b00be | 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | local\-file | 2026\-11\-17T16:18:37\.177Z | 0 full elapsed days | [evidence/4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc\.txt](evidence/4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2d89f12a66119c83c83a3f36fc54f9e29c83f2cf3b9a4f9b5fd5dec0863b152f | 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | local\-file | 2026\-11\-17T16:18:37\.178Z | 0 full elapsed days | [evidence/524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d\.txt](evidence/524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 719e5f833394cbf657e57c776a0d1c832c0240bff0d1ab0551939dbb99cdc328 | 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | local\-file | 2026\-11\-17T16:18:37\.179Z | 0 full elapsed days | [evidence/6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b\.txt](evidence/6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 225d1a5feb41509d39f8e3867fad7543fd26ce84f23b5b7bb04a1343d6f7f61c | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | local\-file | 2026\-11\-17T16:18:37\.179Z | 0 full elapsed days | [evidence/7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b\.txt](evidence/7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 24ecdb59ad7f889b6d404af759872fe33808e7f0b4b4ed78c0b7fe611099c231 | 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | local\-file | 2026\-11\-17T16:18:37\.180Z | 0 full elapsed days | [evidence/93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a\.txt](evidence/93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 014bd3638e167b9df91c5dd8d33d0017f2ef6d9be29d0af3779d6955b61eac6e | 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | local\-file | 2026\-11\-17T16:18:37\.180Z | 0 full elapsed days | [evidence/988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801\.txt](evidence/988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 33657a5f940b9d7ec4d4d8b62832ef291db4fa925ea51888bc96170e5491ba61 | 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | local\-file | 2026\-11\-17T16:18:37\.181Z | 0 full elapsed days | [evidence/9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b\.txt](evidence/9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b904a480548281812d08375d35337313b3fc9a6b8ffc2e1aacdfe1ea7152f724 | ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | local\-file | 2026\-11\-17T16:18:37\.181Z | 0 full elapsed days | [evidence/ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61\.txt](evidence/ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 65b07db84f6d51be569e345d9f302f4c66ffc3385624f994f840b4822a32001c | af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | local\-file | 2026\-11\-17T16:18:37\.182Z | 0 full elapsed days | [evidence/af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c\.txt](evidence/af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e92b3dbb473ee0f0eb763f1bbaa212acff38d98e18e676f606e81ac5cbc7921c | f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | local\-file | 2026\-11\-17T16:18:37\.182Z | 0 full elapsed days | [evidence/f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae\.txt](evidence/f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 06\-extracted\-text | 4b5b9772399642f461f42e71a74f247c04f5d2ce095d63f43c7c22c2057c42fc | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/06\-extracted\-text\.txt](evidence/06-extracted-text.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 05\-extracted\-text | 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/05\-extracted\-text\.txt](evidence/05-extracted-text.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 07\-extracted\-text | 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/07\-extracted\-text\.txt](evidence/07-extracted-text.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 03\-extracted\-text | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/03\-extracted\-text\.txt](evidence/03-extracted-text.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 02\-extracted\-text | 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/02\-extracted\-text\.txt](evidence/02-extracted-text.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 01\-extracted\-text | 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/01\-extracted\-text\.txt](evidence/01-extracted-text.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 09\-extracted\-text | 9ded35b67cc9946f69f0d7a3afdc921d22af02a3c81ca2114f2e5e3bb40b9e0b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/09\-extracted\-text\.txt](evidence/09-extracted-text.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 10\-extracted\-text | ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/10\-extracted\-text\.txt](evidence/10-extracted-text.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 04\-extracted\-text | af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/04\-extracted\-text\.txt](evidence/04-extracted-text.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 08\-extracted\-text | f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/08\-extracted\-text\.txt](evidence/08-extracted-text.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 01\-http\-response | 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | reviewer\-attributed\-local\-snapshot | 2026\-11\-10T08:00:00Z | 7 full elapsed days | [evidence/01\-http\-response\.txt](evidence/01-http-response.txt) | 1380ddeb438edf7057de453d308246b1383f8d280e999a8a5db7ab423ca884e8 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 01\-publisher\-intent | 988b80f48e3632c0dcb6e7a8db36d191afcb7a3e8d795d6e6413dab9c20e8801 | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/01\-publisher\-intent\.txt](evidence/01-publisher-intent.txt) | 6491cc6cb87f119295f1040d067369385e0c55afc1a4ee93afcad58455900682 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 02\-redirect\-chain | 93a0343f7dde6559496e7ee46e0aa3b4c625054e4bbd78f01f19edd10b0bdf9a | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/02\-redirect\-chain\.txt](evidence/02-redirect-chain.txt) | 93f7550b19248c18462c0549afcc5582316b288bbb509ca8781bf95047048774 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 03\-schema\-extraction | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/03\-schema\-extraction\.txt](evidence/03-schema-extraction.txt) | 0c522356b25041d496d85210dae7c21b789759cc375e8c170bfa026ccf25c81d | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 03\-entity\-record | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/03\-entity\-record\.txt](evidence/03-entity-record.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 03\-claim\-sources | 7fb266d8d87cdf8f30c31acfd657207c0232e7512a0743d924aa550588d50a4b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/03\-claim\-sources\.txt](evidence/03-claim-sources.txt) | de50feb7865ea52ba6765143a36324a52674ac353dbb0f627545e837dd4feccf | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 04\-entity\-record | af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/04\-entity\-record\.txt](evidence/04-entity-record.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 04\-inventory\-map | af04a0119d21537c87c9c2cb9c808a9e57ab31a1f8ab6291fe76299a5cfc543c | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/04\-inventory\-map\.txt](evidence/04-inventory-map.txt) | 8184e8a1ca63b41259e61a47a245556872a8fbfb79321884a2c6a54072cb83de | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 05\-claim\-sources | 524d10583db9f0113aa119fa4534632da3d2eb722826db5ccead5708ee3c291d | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/05\-claim\-sources\.txt](evidence/05-claim-sources.txt) | bc434248948c0ea46a3aaeb7b5b108fb1460a7e5ba4f78367ca4dc2d93cee88f | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 07\-audience\-context | 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/07\-audience\-context\.txt](evidence/07-audience-context.txt) | 58e51d0700fe2112fa585b218c15b7b68b099d280cdcfa18e478501a33eb7c74 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 07\-claim\-sources | 6cc7ccedf01d1670867cb4af97c5a30bc7cb55b043cbb91d360f4cb90d58230b | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/07\-claim\-sources\.txt](evidence/07-claim-sources.txt) | 7148637143c17a923c83788e641a724c8f19a65bf61ef2cc1df2a894b4ac510a | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 08\-claim\-sources | f16e9ca8f60fedcd9d50051b19da4f451436aaabf6c82e2a2432503a045c66ae | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/08\-claim\-sources\.txt](evidence/08-claim-sources.txt) | 749dce32ef7348fbc3c7f42a62add989bba7a0be4e2a1213982997c0a69e0b08 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |
| 10\-claim\-sources | ad2d4b86f03789118557562528107f77a7730fa76ad58f7a4341b8f169aaab61 | reviewer\-attributed\-local\-snapshot | 2026\-11\-17T16:19:52\.607Z | 0 full elapsed days | [evidence/10\-claim\-sources\.txt](evidence/10-claim-sources.txt) | b94e91e595390959f1fb4562f3ed903c7b6301e3d305f5a4e467bc13025cbef5 | Supplied synthetic dossier evidence only\. Derived from the captured local snapshot\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
