import fs from 'node:fs';
import {createHash} from 'node:crypto';
const hash = v => createHash('sha256').update(v).digest('hex');
const quotes = [];
const files = fs.readdirSync('targets');
const reportLines = [];
for(const line of fs.readFileSync('content-audit/narrative.txt','utf8').split('\n')) {
 const m = /^\{\{(\d\d):(\d+)(?:-(\d+))?\}\}$/.exec(line);
 if(!m){reportLines.push(line);continue;}
 const [,n,a,b=a]=m, startLine=Number(a), endLine=Number(b);
 const sourceLabel=files.find(x=>x.startsWith(n+'-'));
 const source='targets/'+sourceLabel;
 const bytes=fs.readFileSync(source);
 const quote=bytes.toString('utf8').split('\n').slice(startLine-1,endLine).join('\n');
 const reportStartLine=reportLines.length+1;
 reportLines.push(sourceLabel+':'+a+(b===a?'':'-'+b),'','~~~text',...quote.split('\n'),'~~~','');
 quotes.push({quoteId:'Q'+(quotes.length+1),source,sourceLabel,sourceHash:hash(bytes),startLine,endLine,reportStartLine,reportEndLine:reportLines.length,quote});
}
const report=reportLines.join('\n').replaceAll(/\n{3,}/g,'\n\n');
const finalLines=report.split('\n');
for(const q of quotes){
 const locator=q.sourceLabel+':'+q.startLine+(q.startLine===q.endLine?'':'-'+q.endLine);
 q.reportStartLine=finalLines.indexOf(locator)+1;
 q.reportEndLine=q.reportStartLine+q.endLine-q.startLine+3;
}
fs.writeFileSync('report.md',report);
fs.writeFileSync('content-audit/quotes.json',JSON.stringify({root:process.cwd(),report:'report.md',reportHash:hash(report),quotes},null,2));
