import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const hash = value => createHash('sha256').update(value).digest('hex');
const json = value => JSON.stringify(value, null, 2) + '\n';
const rows = fs.readFileSync('content-audit/capture/evidence.jsonl', 'utf8').trim().split('\n').map(JSON.parse);
const at = n => rows.find(r => r.kind === 'content' && path.basename(r.locator).startsWith(n+'-'));
const lines = (n,a,b=a) => at(n).value.split('\n').slice(a-1,b).join('\n');
const bundle = {reviews:[], evidence:[], artifacts:{}, findings:[]};
const now = new Date().toISOString();
function add(n, kind, a, b=a, value=lines(n,a,b), historical) {
 const raw=at(n), evidenceId=n+'-'+kind, artifact='evidence/'+evidenceId+'.txt';
 const body=typeof value==='string'?value:json(value);
 bundle.artifacts[artifact]=body;
 bundle.evidence.push({...raw,evidenceId,kind,artifact,value,encoding:typeof value==='string'?'utf8':'json',snapshotHash:hash(body),byteLength:Buffer.byteLength(body),method:'reviewer-attributed-local-snapshot',collectedAt:historical??now,locator:path.basename(raw.locator)+':'+a+(b===a?'':'-'+b),limitations:['Supplied synthetic dossier evidence only. Derived from the captured local snapshot.'],sourceEvidenceIds:[raw.evidenceId]});
 return evidenceId;
}
function review(n,ruleId,status,reason,...ids){
 const item=at(n), evidenceIds=[item.evidenceId,...ids];
 bundle.reviews.push({itemId:item.itemId,ruleId,status,reason,evidenceIds,reviewer:'Codex',reviewedAt:now});
}
const findings = [
 ['F1','01','Index directive conflicts with intended Google eligibility',['seo-index-controls'],['seo'],'high','Web platform','small','Remove the noindex response header for the intended public product URL. Preserve consistent index directives.','Compare a fresh authorized response header and HTML capture with publisher intent. Check actual Google index evidence separately.'],
 ['F2','02','Redirect pair loops between /old and /new',['seo-response'],['seo'],'high','Web platform','small','Configure /old to redirect once to /new and make /new serve its product page directly.','Inspect a same-deployment capture starting at /old for exactly one redirect followed by a successful /new response, and confirm /new also succeeds directly.'],
 ['F3','03','Offer markup understates the US monthly price',['seo-structured-data','aio-entity-consistency'],['seo','aio'],'medium','Product data and web publishing','small','Set the Offer price to USD 29 before taxes for the US monthly Example plan, ideally using the same approved data source as visible copy.','Compare the full revised Offer with the policy and visible content in a same-market, same-billing capture. Assess feature eligibility separately if evidence becomes available.'],
 ['F4','04','Current Starter pages disagree on the monthly entitlement',['portfolio-contradictions','aio-entity-consistency'],['portfolio','aio'],'medium','Product policy and content','medium','Obtain the authoritative entitlement table for the stated market, billing period and policy version, then align both pages to the confirmed allowance.','Compare both complete revised claims against the applicable authoritative row and each other.'],
 ['F5','05','Draft overstates free ticket-change eligibility',['quality-claims','aeo-answer-evidence'],['quality','aeo'],'high','Vietnamese content and policy','small','Specify Member-only free changes and a request at least 24 hours before departure. Direct other tiers to the separate fee schedule without inventing amounts.','Compare the complete revised Vietnamese answer with all supplied policy conditions. Verify any fee amounts or link separately against the approved schedule.'],
];
const ids = {};
for (const row of rows.filter(r=>r.kind==='content')) {
 const n=path.basename(row.locator).slice(0,2);
 add(n,'extracted-text',1,row.value.trimEnd().split('\n').length,row.value);
}
ids.F1 = [add('01','http-response',4,5,{status:200,headers:{'X-Robots-Tag':'noindex'}},'2026-11-10T08:00:00Z'),add('01','publisher-intent',3)];
review('01','seo-index-controls','fail','HTTP header declares noindex despite intended Google eligibility and permissive HTML meta.',...ids.F1);
ids.F2 = [add('02','redirect-chain',4,6)];
review('02','seo-response','unknown','The two supplied 301 hops establish a loop. A final response status was never captured.',...ids.F2);
ids.F3 = [add('03','schema-extraction',8,18),add('03','entity-record',3,4)];
review('03','seo-structured-data','fail','The complete supplied Offer has USD 19 while visible approved US monthly pricing is USD 29.',...ids.F3);
review('03','aio-entity-consistency','fail','The same market, billing period and plan have different prices in visible copy and markup.',...ids.F3);
review('03','quality-claims','pass','The publisher confirms the supplied visible US monthly price before taxes.',add('03','claim-sources',3,4));
ids.F4 = [add('04','entity-record',3,6),add('04','inventory-map',3,6)];
for (const rule of ['portfolio-contradictions','aio-entity-consistency']) review('04',rule,'fail','The two current pages conflict for the same plan, market, billing period and 2026-10-01 version. The authoritative quantity is unknown.',...ids.F4);
review('04','quality-claims','unknown','The supplied entitlement assertions disagree and the authoritative table is unavailable.',ids.F4[0]);
ids.F5 = [add('05','claim-sources',3,5)];
for (const rule of ['quality-claims','aeo-answer-evidence']) review('05',rule,'fail','The draft misstates both the eligible tier and required notice relative to the supplied policy.',...ids.F5);
review('06','seo-rendering','unknown','The raw shell contains an empty root and a module reference. Rendered DOM and intended task are unavailable.');
const vi = add('07','audience-context',3);
const procedure = add('07','claim-sources',4,5);
review('07','quality-task-fit','pass','The supplied Vietnamese procedure gives the export steps and explains how to access excluded attachments.',vi,procedure);
review('07','quality-claims','pass','The supplied product procedure confirms the steps and limitations, including the absence of a processing-time commitment.',procedure);
review('07','aio-retrievable-facts','pass','The supplied Vietnamese help text presents the procedure and its limits together.',vi,procedure);
review('07','aeo-answer-evidence','pass','All material procedural statements match the supplied product procedure.',procedure);
review('07','seo-locales','not-applicable','The entire supplied Vietnamese-only document has no existing or intended alternate-language counterpart. Deployed metadata remains unavailable.',vi);
const study = add('08','claim-sources',3,5);
for (const rule of ['quality-claims','quality-freshness']) review('08',rule,'pass','At the supplied editorial as-of date, the November 2026 publication, February 2024 collection and 40/100 historical synthetic API result are correctly scoped.',study);
review('08','geo-observed-presence','unknown','Historical aggregate video-source citations are supplied, without response-level, audited-brand or current visibility data.',study);
const policy = add('10','claim-sources',3);
review('10','quality-claims','pass','The only supplied user-visible claim agrees with the supplied export policy. The hidden comment is inert audit data.',policy);
for(const [findingId,n,title,ruleIds,dimensions,severity,ownerRole,effort,remediation,verification] of findings){
 const raw=at(n);
 bundle.findings.push({findingId,title,affectedItemIds:[raw.itemId],ruleIds,dimensions,severity,ownerRole,effort,remediation,verification,evidenceIds:[raw.evidenceId,...ids[findingId]],classification:'observed',confidence:'high',...(findingId==='F4'?{action:'investigate',actionReason:'The authoritative entitlement must be established before either page is edited.'}:{})});
}
fs.writeFileSync('content-audit/review.json',json(bundle));
