// Renders report.md from the template, inserting quotations read from the
// supplied dossiers by file and line, and writes the quote-verification ledger.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, templateFile, reportName, ledgerFile] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const cache = new Map();
const source = (name) => {
  if (!cache.has(name)) {
    const bytes = readFileSync(path.join(root, "targets", name));
    cache.set(name, { hash: hash(bytes), lines: bytes.toString("utf8").split(/\r?\n/) });
  }
  return cache.get(name);
};
const template = readFileSync(templateFile, "utf8");
const count = (template.match(/\{\{[QL]:/g) || []).length;
const quotes = [];
const out = template.split("\n").map((line, index) =>
  line
    .replace(/\{\{QCOUNT\}\}/g, String(count))
    .replace(/\{\{(Q|L):([^:}]+):(\d+)(?::(.*?))?\}\}/g, (_, kind, name, n, text) => {
      const src = source(name);
      const full = src.lines[Number(n) - 1];
      if (full === undefined) throw new Error(`No line ${name}:${n}`);
      const quote = kind === "L" ? full.trim() : text;
      if (!quote || !full.includes(quote)) throw new Error(`Quote not on ${name}:${n}: ${quote}`);
      if (quote.includes("`")) throw new Error("Backtick in quote");
      quotes.push({
        quoteId: `q${String(quotes.length + 1).padStart(2, "0")}-${name.slice(0, 2)}-L${n}`,
        source: `targets/${name}`,
        sourceLabel: name,
        sourceHash: src.hash,
        startLine: Number(n),
        endLine: Number(n),
        reportStartLine: index + 1,
        reportEndLine: index + 1,
        normalization: "exact",
        quote,
      });
      return `\`${name}:${n}\` \`${quote}\``;
    }),
);
const report = out.join("\n");
if (/\{\{/.test(report)) throw new Error("Unrendered placeholder");
if (quotes.length !== count) throw new Error("Quote count mismatch");
writeFileSync(path.join(root, reportName), report, { flag: "wx" });
writeFileSync(
  ledgerFile,
  JSON.stringify({ root, report: reportName, reportHash: hash(Buffer.from(report, "utf8")), quotes }, null, 2) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length }));
