# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:18:49\.833Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 86f2729e\-8778\-46f0\-9516\-39d0c32b3a18\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-locales | seo | unknown | Missing required evidence: locale\-map | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| b23ffa313928e36dfad1760e042f74c457591e57ecf8eab33961aab7ea540bf9 | 41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e | local\-file | 2026\-11\-17T16:18:49\.810Z | 0 full elapsed days | [evidence/41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e\.txt](evidence/41bd650cd9dac18aa6d3ba2772b96b79b8944cad6a664168d97c0b49422f3f4e.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 9e1ac5fd35a83429548bdeab05891c8194eb295cb1d787f8fa855de65f257015 | 45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26 | local\-file | 2026\-11\-17T16:18:49\.810Z | 0 full elapsed days | [evidence/45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26\.txt](evidence/45d18218fc4c3185437df69fd0bf51bc6574483db35e5803924d881016310f26.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| bfd771923830ee8af296543f2af067dd9d3e97d72684824b40a94e6ea4f252d6 | 6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b | local\-file | 2026\-11\-17T16:18:49\.811Z | 0 full elapsed days | [evidence/6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b\.txt](evidence/6887c9f54fde8f7eadfc7c37fb21af73ce5e5aa9fa37c99e7d20ca0f9b49f37b.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 66aabfa95f7ae1c6232bb368176553408a39e69d9072dbf94987d991e6f5764c | 6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99 | local\-file | 2026\-11\-17T16:18:49\.812Z | 0 full elapsed days | [evidence/6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99\.txt](evidence/6b0d44b06b459ac90a32828333655924fa2e8bf9f374e6757a94e6841f1eaa99.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| fbd2242e31b43026925f83321afaeda4dcdc5b4188e7ca1a5d456259677ecd79 | 84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da | local\-file | 2026\-11\-17T16:18:49\.813Z | 0 full elapsed days | [evidence/84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da\.txt](evidence/84385d1729b4fd064fd1887c0649646945e90dfe1e068a39ee5dfbc3a65735da.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c8ff7b5c60b2ba744788b0a173bdd0daaba749c1aa173288c9e86da2dd2197e5 | 8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2 | local\-file | 2026\-11\-17T16:18:49\.813Z | 0 full elapsed days | [evidence/8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2\.txt](evidence/8a74825635f28fff085d861d67b0666b3fdc4cdd5f630ac4a1fc86c050386bd2.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3ceb493796f107580263086eb9b23cc7fd75671e15071c829f8647b096597f70 | a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92 | local\-file | 2026\-11\-17T16:18:49\.814Z | 0 full elapsed days | [evidence/a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92\.txt](evidence/a689830862aca2b0d0a234a761692817851d682c4a27701770acb60b25770d92.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| aaae46b1320a72592198bf15e1fb787a968d02be5395fdb1c8207c9209910837 | bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8 | local\-file | 2026\-11\-17T16:18:49\.814Z | 0 full elapsed days | [evidence/bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8\.txt](evidence/bc33ca65c7b8500cc29e3954bb54fee734d434b2b6f7d86492cb9df016755ed8.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 39b9af76053cc2fb04e8cfc7a4c39324f1a853fa694e0996dc0471adce896b0d | d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557 | local\-file | 2026\-11\-17T16:18:49\.815Z | 0 full elapsed days | [evidence/d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557\.txt](evidence/d613b94425890bcb63c11fee22ec116b0c310ad814f2d3752f78931c5a86c557.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 258700a31cf9fea52c0b1c327ae05e5041006cd296c2f19c46f7c022c4b6a118 | e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c | local\-file | 2026\-11\-17T16:18:49\.815Z | 0 full elapsed days | [evidence/e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c\.txt](evidence/e3eef0e536c5c057b30650b4f07e157e8e41ea43bba0b7cfc73ace17dd1b8c2c.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
