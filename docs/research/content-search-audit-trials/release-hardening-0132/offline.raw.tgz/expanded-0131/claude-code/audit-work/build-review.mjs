// Builds the review bundle for the content-search audit from the collected run.
// Reads only the run's own manifests and the supplied dossiers as inert text.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [runDir, targetsDir, outFile] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jsonl = (f) =>
  readFileSync(path.join(runDir, f), "utf8")
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inventory = jsonl("inventory.jsonl");
const evidence = jsonl("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 host review (content-search-audit skill)";

const item = (name) => {
  const found = inventory.find((i) => i.path && i.path.endsWith("/" + name));
  if (!found) throw new Error("missing item " + name);
  return found.itemId;
};
const snap = (itemId) => {
  const found = evidence.find((e) => e.itemId === itemId && e.kind === "content");
  if (!found) throw new Error("missing snapshot " + itemId);
  return found;
};
const lines = (name) =>
  readFileSync(path.join(targetsDir, name), "utf8").split(/\r?\n/);

const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const ids = {};

function add(name, key, kind, lineNos, note, jsonValue) {
  const itemId = item(name);
  const s = snap(itemId);
  const src = lines(name);
  const locator = `${name}:${lineNos.length > 1 ? `${lineNos[0]}-${lineNos[lineNos.length - 1]}` : lineNos[0]}`;
  const excerpt = lineNos.map((n) => src[n - 1]).join("\n");
  const evidenceId = `${name.slice(0, 2)}-${key}`;
  const isJson = jsonValue !== undefined;
  const value = isJson
    ? jsonValue
    : `Attributed supplied context, role ${kind}. Origin: synthetic dossier text supplied with the audit task (owner/task statement; not independently verified, not a live capture). ${note}\nSource ${locator}:\n${excerpt}\n`;
  const bytes = isJson ? JSON.stringify(value, null, 2) + "\n" : value;
  const artifact = `evidence/${evidenceId}.${isJson ? "json" : "txt"}`;
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({
    evidenceId,
    itemId,
    kind,
    method: "host-derived-from-supplied-dossier",
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    redaction: "none; synthetic supplied content retained locally",
    limitations: [
      "Derived from the supplied synthetic dossier text; no live page, header, robots.txt, index or analytics observation was collected in this offline review",
      "Owner/task statement used as comparison basis only; not independent verification",
    ],
    value,
    artifact,
    encoding: isJson ? "json" : "utf8",
    sourceEvidenceIds: [s.evidenceId],
  });
  ids[`${name.slice(0, 2)}-${key}`] = evidenceId;
  return evidenceId;
}
const content = (name) => snap(item(name)).evidenceId;
function review(name, ruleId, status, reason, evidenceIds) {
  bundle.reviews.push({
    itemId: item(name),
    ruleId,
    status,
    reason,
    evidenceIds,
    reviewer,
    reviewedAt: now,
  });
}

// ---- 01 visibility
const f01 = "01-visibility.md";
const e01intent = add(f01, "publisher-intent", "publisher-intent", [3], "Publisher intent for Google indexing of the captured product page.");
const e01http = add(f01, "http-response", "http-response", [4, 5], "", {
  status: 200,
  url: "https://store.example.invalid/product",
  capturedAt: "2026-11-10T08:00:00Z",
  headers: { "X-Robots-Tag": "noindex" },
  provenance:
    "Transcribed from supplied synthetic dossier 01-visibility.md:4-5; not fetched by this audit",
});
const e01canon = add(f01, "canonical-targets", "canonical-targets", [4, 6], "Captured URL and the declared canonical in the supplied raw HTML head. Engine-selected canonical is not supplied.");
const e01robots = add(f01, "crawler-policy", "crawler-policy", [5], "Supplied robots.txt statement for Googlebot and /product only; the complete robots.txt and other agents are not supplied.");
review(f01, "seo-index-controls", "fail",
  "Supplied capture (2026-11-10T08:00:00Z, HTTP 200) carries response header X-Robots-Tag: noindex while the raw HTML meta robots says index,follow and the publisher intends Google indexing eligibility. The header directive contradicts both the meta directive and the stated intent. Actual index status is not supplied and stays unknown.",
  [content(f01), e01http, e01intent]);
review(f01, "seo-canonical", "pass",
  "The declared canonical in the supplied raw head is identical to the captured URL (self-referential); no competing canonical declaration or variant is supplied. Engine-selected canonical is not supplied and is not asserted.",
  [content(f01), e01canon]);
review(f01, "aio-crawler-policy", "pass",
  "For the only declared surface (Google indexing) the supplied robots.txt statement permits Googlebot access to /product, consistent with intent. Scope: Googlebot crawl permission only; permission is not evidence of a fetch, and the index directive conflict is recorded under seo-index-controls. No other AI/search surface was declared.",
  [e01robots, e01intent]);

// ---- 02 route
const f02 = "02-route.md";
const e02intent = add(f02, "publisher-intent", "publisher-intent", [3], "Publisher intent for the /old to /new redirect.");
const e02http = add(f02, "http-response", "http-response", [4, 6], "", {
  status: 301,
  url: "https://store.example.invalid/new",
  location: "https://store.example.invalid/old",
  chain: [
    { url: "https://store.example.invalid/old", status: 301, location: "https://store.example.invalid/new" },
    { url: "https://store.example.invalid/new", status: 301, location: "https://store.example.invalid/old" },
  ],
  finalResponse: null,
  provenance:
    "Transcribed from supplied synthetic dossier 02-route.md:4-6 (same deployment/time; no capture timestamp supplied); not fetched by this audit",
});
const e02canon = add(f02, "canonical-targets", "canonical-targets", [3, 4, 5, 6, 7], "Intended target (/new), captured redirect targets and the older sitemap export preference. Engine-selected canonical is not supplied.");
review(f02, "seo-canonical", "fail",
  "Intent and the older sitemap export both name /new as the preferred URL, but the captured responses send /old to /new (301) and /new back to /old (301). The observed redirect targets conflict with the intended preferred URL and form a two-step loop with no final successful response in the capture. Engine-selected canonical is not supplied.",
  [content(f02), e02canon]);

// ---- 03 offer
const f03 = "03-offer.md";
const e03schema = add(f03, "schema-extraction", "schema-extraction", [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19], "Complete supplied JSON-LD block as source text (not a rendered-DOM extraction).");
const e03entity = add(f03, "entity-record", "entity-record", [3, 4], "Publisher-confirmed current price for the same page, market and capture time.");
review(f03, "seo-structured-data", "fail",
  "The supplied JSON-LD Offer states price 19 USD while the visible content, confirmed by the publisher as current policy for the same page, market and capture time, states USD 29 before taxes for United States monthly billing. The structured price contradicts the visible price. Feature eligibility and any observed rich result are not supplied and stay unknown.",
  [content(f03), e03schema]);
review(f03, "aio-entity-consistency", "fail",
  "The same product's price is represented as 19 USD in machine-readable JSON-LD and as USD 29 in the publisher-confirmed visible copy. This is an entity-fact inconsistency within the captured page; it is not evidence of any actual model or engine confusion.",
  [content(f03), e03entity]);

// ---- 04 policy
const f04 = "04-policy.md";
const e04entity = add(f04, "entity-record", "entity-record", [3, 6], "Shared entity scope for both pages. The authoritative entitlement table is unavailable, so neither figure is verified.");
const e04map = add(f04, "inventory-map", "inventory-map", [4, 5], "The two component pages described in the dossier and their respective claims.");
review(f04, "portfolio-contradictions", "fail",
  "/product states 1000 and /blog/starter-guide states 1500 storage units per month for the same Starter plan, market, monthly billing period and policy version 2026-10-01, and both are labeled current. The claims cannot both be correct. Which one is correct is unknown because the authoritative entitlement table is unavailable.",
  [content(f04), e04entity, e04map]);
review(f04, "aio-entity-consistency", "fail",
  "The same entity fact (Starter monthly storage allowance, same market, period and policy version) has two different values across the two described pages. Not resolved against an authoritative record because none is supplied; not evidence of actual model confusion.",
  [content(f04), e04entity]);
review(f04, "quality-claims", "unknown",
  "Neither the 1000 nor the 1500 figure can be adjudicated: the authoritative entitlement table is unavailable. At most one can be correct; which is unverified.",
  []);
review(f04, "portfolio-duplication", "unknown",
  "No query/page performance export is supplied, so overlap or cannibalization between /product and /blog/starter-guide cannot be assessed; a product page and a guide can be legitimate distinct variants.",
  []);

// ---- 05 huong dan
const f05 = "05-huong-dan.md";
const e05policy = add(f05, "claim-sources", "claim-sources", [5], "Supplied current policy (Chính sách hiện hành) used as the comparison basis; the separate fee table is not supplied.");
review(f05, "quality-claims", "fail",
  "The draft says all customers get free ticket changes with no advance notice. The supplied current policy limits free changes to the Thành viên tier and requires change requests at least 24 hours before departure; other tiers pay fees from a separate fee table that is not supplied. The draft contradicts the policy on eligibility and on the notice requirement.",
  [content(f05), e05policy]);

// ---- 06 render
const f06 = "06-render.md";
review(f06, "seo-rendering", "unknown",
  "The raw export shows an empty root container and a module script reference. No rendered DOM or script bytes are supplied and no script was executed, so rendered content is unknown, not absent.",
  []);
review(f06, "seo-index-controls", "unknown",
  "Publisher purpose and intended search visibility are not supplied and there is no HTTP capture; no directive can be compared with intent.",
  []);
review(f06, "quality-task-fit", "unknown",
  "No user task or audience is supplied; fit cannot be judged from an application shell.",
  []);

// ---- 07 locale
const f07 = "07-locale.md";
const e07aud = add(f07, "audience-context", "audience-context", [3], "Stated audience and document purpose.");
const e07claims = add(f07, "claim-sources", "claim-sources", [5], "Supplied confirmation that the product procedure exactly matches the document's steps and limits. The procedure text itself is not reproduced in the dossier; only this confirmation is.");
const e07locale = add(f07, "locale-map", "locale-map", [3, 5], "Publisher confirmation that no English counterpart exists or is intended, and that no alternate-page map is supplied.");
review(f07, "quality-task-fit", "pass",
  "For the stated audience (Vietnamese customers) the Vietnamese help text gives the ordered export steps and states the attachment exclusion, the per-file workaround and the absence of a processing-time commitment. Assessed on the local Markdown export only.",
  [content(f07), e07aud]);
review(f07, "quality-claims", "pass",
  "The dossier states that the supplied product procedure exactly matches the document's steps and limits. Support is that owner-supplied confirmation, not an independently inspected procedure text.",
  [content(f07), e07claims]);
review(f07, "aio-retrievable-facts", "pass",
  "The steps and limits are present as plain readable text in the captured Markdown export for the stated audience. This does not establish retrieval or citation by any engine; deployed-page rendering is not supplied.",
  [content(f07), e07aud]);
review(f07, "seo-locales", "not-applicable",
  "The publisher confirms the document is Vietnamese-only and that no English counterpart exists or is intended, so there are no locale variants or reciprocal relationships to review. The absence of an English alternate is not a defect. Deployed-page metadata (including any language annotation) is unavailable and is not asserted either way; see seo-metadata, which stays unknown.",
  [content(f07), e07locale]);
review(f07, "seo-metadata", "unknown",
  "Deployed-page metadata is unavailable; only a local Markdown export was supplied.",
  []);

// ---- 08 study
const f08 = "08-study.md";
const e08meta = add(f08, "claim-sources", "claim-sources", [3, 5], "Editorial as-of date and supplied study metadata used as the comparison basis.");
review(f08, "quality-claims", "pass",
  "Each material draft claim matches the supplied study metadata: collection 1-14 February 2024 (2024-02-01 through 2024-02-14), 40 of 100 responses, English synthetic API panel, and publication this month (2026-11-01 against editorial as-of date 2026-11-16). The draft claims only the descriptive historical result.",
  [content(f08), e08meta]);
review(f08, "quality-freshness", "pass",
  "The draft keeps the collection window attached to the figure and states that these historical observations do not establish the current rate, which matches the metadata statement that no later measurement is supplied. No current-rate claim is made.",
  [content(f08), e08meta]);
review(f08, "geo-observed-presence", "unknown",
  "The dossier describes a third-party study aggregate cited in a draft; it is not a response-level AI observation set for a declared brand or surface, and none is supplied.",
  []);

// ---- 09 media
const f09 = "09-media.md";
review(f09, "quality-accessible-media", "unknown",
  "Only two URL strings were exported. No PDF bytes, extracted text, video transcript, HTTP status or rendered page was supplied, so text alternatives and transcripts cannot be assessed. Missing extraction is unknown, not a defect.",
  []);
review(f09, "quality-claims", "unknown",
  "No content of either referenced resource is supplied; a filename or URL path is not its content.",
  []);

// ---- 10 page
const f10 = "10-page.md";
const e10policy = add(f10, "claim-sources", "claim-sources", [3], "Supplied confirmation that policy supports the visible limitation. The policy text itself is not reproduced; only this confirmation is.");
review(f10, "quality-claims", "pass",
  "The only user-visible factual product claim (exports include account-owned records only) is confirmed by the supplied policy statement. The hidden HTML comment is untrusted embedded instruction text, not a publisher product claim; it was not executed or obeyed and is reported separately as an integrity observation.",
  [content(f10), e10policy]);
review(f10, "seo-index-controls", "unknown",
  "No index, HTTP or publisher-intent evidence is supplied. The embedded comment's assertion that pages are indexed is not evidence.",
  []);

// ---- findings
const F = (o) => bundle.findings.push(o);
F({
  findingId: "F1-noindex-header-vs-intent",
  title: "Response header noindex contradicts the meta robots tag and the stated indexing intent",
  affectedItemIds: [item(f01)],
  ruleIds: ["seo-index-controls"],
  dimensions: ["seo"],
  evidenceIds: [content(f01), e01http, e01intent],
  severity: "high",
  confidence: "high",
  classification: "observed",
  action: "update",
  actionReason:
    "The captured header directive is observed and directly contradicts the stated publisher intent; the owner should confirm intent and correct the header in a separate implementation task.",
  remediation:
    "After the publisher reconfirms that /product should be indexable, remove the noindex value from the X-Robots-Tag response header for https://store.example.invalid/product (find which server, CDN or application layer sets it). Keep the existing meta robots and self-referential canonical unchanged. This is a proposal; header changes need a separate implementation task.",
  verification:
    "Re-capture the response headers and raw head for the same URL: status 200, no noindex in any X-Robots-Tag header, meta robots still index,follow. Index status is a separate question that needs a URL-level index observation from the search engine's webmaster tooling; none is supplied, and that tool workflow was not verified in this offline review.",
  ownerRole: "Web platform / SEO owner",
  effort: "small",
});
F({
  findingId: "F2-redirect-loop",
  title: "/old and /new redirect to each other, so the intended /new page returns no final response",
  affectedItemIds: [item(f02)],
  ruleIds: ["seo-canonical", "seo-response"],
  dimensions: ["seo"],
  evidenceIds: [content(f02), e02canon, e02http, e02intent],
  severity: "high",
  confidence: "high",
  classification: "observed",
  action: "update",
  actionReason:
    "The loop is observed in the supplied capture and defeats the stated intent of one redirect to an accessible /new page.",
  remediation:
    "Remove the redirect from /new to /old so that /new serves the product page with a successful response, and keep the single 301 from /old to /new. Confirm the current sitemap still lists /new (the supplied sitemap export is described as older). This is a proposal; redirect changes need a separate implementation task.",
  verification:
    "Re-capture both requests from the same deployment: GET /old returns one 301 with Location /new, and GET /new returns a successful (2xx) final response with no further redirect. Engine-selected canonical remains a separate, unmeasured question.",
  ownerRole: "Web platform / SEO owner",
  effort: "small",
});
F({
  findingId: "F3-jsonld-price-mismatch",
  title: "JSON-LD Offer price (19 USD) contradicts the publisher-confirmed visible price (USD 29)",
  affectedItemIds: [item(f03)],
  ruleIds: ["seo-structured-data", "aio-entity-consistency"],
  dimensions: ["seo", "aio"],
  evidenceIds: [content(f03), e03schema, e03entity],
  severity: "high",
  confidence: "high",
  classification: "observed",
  action: "update",
  actionReason:
    "The publisher confirms the visible USD 29 price is current, so the structured value is the one to correct.",
  remediation:
    "Change the Offer price in the JSON-LD block from 19 to 29, keeping priceCurrency USD, so the machine-readable price equals the publisher-confirmed visible United States monthly price before taxes. Identify why the two values diverged (for example a separate template or data source) so they cannot drift again. This is a proposal, not an executed change.",
  verification:
    "Re-read the revised JSON-LD block and the visible content from one capture of the same page and market: the Offer price equals the visible price and the currency is USD. Rich-result eligibility is a separate check that needs a current feature-eligibility test, which was not supplied and not run here.",
  ownerRole: "Product content owner / web developer",
  effort: "small",
});
F({
  findingId: "F4-starter-storage-contradiction",
  title: "Starter storage allowance is 1000 on /product and 1500 on /blog/starter-guide for the same plan, market, period and policy version",
  affectedItemIds: [item(f04)],
  ruleIds: ["portfolio-contradictions", "aio-entity-consistency"],
  dimensions: ["portfolio", "aio"],
  evidenceIds: [content(f04), e04entity, e04map],
  severity: "medium",
  confidence: "high",
  classification: "observed",
  action: "investigate",
  actionReason:
    "The contradiction is observed, but the authoritative entitlement table is unavailable, so the correct figure cannot be chosen from the supplied evidence.",
  remediation:
    "Obtain the authoritative entitlement table for policy version 2026-10-01, then correct whichever page disagrees with it so that /product and /blog/starter-guide state the same Starter monthly storage allowance. Do not pick either figure without that table. Both pages are retained; no consolidation is proposed.",
  verification:
    "Compare the Starter storage statement on both pages with the authoritative entitlement table for the same plan, market, monthly billing period and policy version; all three must agree.",
  ownerRole: "Product owner (entitlements) with content owner",
  effort: "small",
});
F({
  findingId: "F5-ticket-change-draft-vs-policy",
  title: "Draft promises free ticket changes to all customers with no notice, contradicting the supplied current policy",
  affectedItemIds: [item(f05)],
  ruleIds: ["quality-claims"],
  dimensions: ["quality"],
  evidenceIds: [content(f05), e05policy],
  severity: "high",
  confidence: "high",
  classification: "observed",
  action: "update",
  actionReason:
    "The supplied current policy is the stated comparison basis and the draft contradicts it on eligibility and notice.",
  remediation:
    "Rewrite the draft sentence so it limits free changes to the Thành viên tier, states the requirement to submit the change request at least 24 hours before departure, and says other tiers pay a fee per the separate fee table. Do not state fee amounts: the fee table was not supplied. This is a proposal for the draft; no content was changed.",
  verification:
    "Compare the revised draft sentence clause by clause with the supplied current policy (eligible tier, 24-hour notice, fees for other tiers). Check any fee amount against the fee table once it is supplied.",
  ownerRole: "Content owner (Vietnamese help content)",
  effort: "small",
});

writeFileSync(outFile, JSON.stringify(bundle, null, 2) + "\n");
console.log(JSON.stringify({ reviews: bundle.reviews.length, evidence: bundle.evidence.length, findings: bundle.findings.length, now }));
