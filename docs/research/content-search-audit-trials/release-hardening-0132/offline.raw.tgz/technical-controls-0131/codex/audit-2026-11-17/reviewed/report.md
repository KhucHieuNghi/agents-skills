# Synthetic routing and markup dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:08:47\.453Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run bdf74e04\-c40f\-4a22\-800a\-17a72aa502cf\. 2 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| current\-guide\-routing | Current\-guide crawl and canonical controls conflict with owner intent | aio\-crawler\-policy, seo\-canonical | seo, aio | high | high | observed | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | update | reviewer\-proposal | Align independent crawl and canonical controls with the same approved route while retaining the historical version\. | Permit Googlebot to crawl /guide/current and align its canonical to its own approved URL\. Keep the sitemap current entry and preserve the accessible, visibly historical, self\-canonical /guide/2024\. | Evaluate the effective robots rule for Googlebot and the exact current path, inspect the current and archive response canonicals and sitemap, and confirm archive accessibility and labeling\. Separately corroborate subsequent Googlebot fetch and engine\-selected canonical with owner\-supplied evidence if available\. | Web platform owner | small | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e, 01\-routing\-crawler\-policy, 01\-routing\-publisher\-intent, 01\-routing\-canonical\-targets |
| cedar\-overview\-jsonld | Trailing comma breaks Page A JSON\-LD | seo\-structured\-data | seo | medium | high | observed | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | update | reviewer\-proposal | Restore a parseable machine\-readable description for the overview\. | Remove the trailing comma after Page A’s final name field\. Retain the descriptive WebPage type and Page B’s valid block\. | Parse the revised script body as strict JSON and compare its WebPage name to the visible heading\. Run the same check on the unchanged Page B fixture\. | Documentation template maintainer | small | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b, 02\-markup\-schema\-extraction, 02\-markup\-publisher\-intent |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 2 | 6 | 0 |
| quality | 10 | 2 | 8 | 0 |
| seo | 16 | 2 | 14 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | pending | Snapshot review incomplete | 26 |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 02\-markup\-extracted\-text |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-structured\-data | seo | fail | Page A supplied WebPage JSON\-LD is invalid strict JSON because of a trailing comma after its last member\. Page B parses and its WebPage name matches the supplied heading\. Other markup and search feature outcomes are unknown\. | 02\-markup\-publisher\-intent, 02\-markup\-schema\-extraction, 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | portfolio\-duplication | portfolio | pass | The supplied headings and introductions distinguish the library overview from the export reference\. | 02\-markup\-inventory\-map, 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 01\-routing\-extracted\-text |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-index\-controls | seo | unknown | The Googlebot crawl restriction is assessed under crawler policy\. Complete index and snippet directives and observed index state are unavailable\. | 01\-routing\-crawler\-policy, 01\-routing\-publisher\-intent, ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-canonical | seo | fail | Captured current HTML points to the historical archive while the sitemap lists the owner\-approved current URL\. The archive self\-canonical is consistent with its historical purpose\. | 01\-routing\-canonical\-targets, 01\-routing\-publisher\-intent, ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aio\-crawler\-policy | aio | fail | The applicable Googlebot group disallows the approved current URL\. The wildcard allowance does not override that group\. The current path restriction does not cover the archive\. | 01\-routing\-crawler\-policy, 01\-routing\-publisher\-intent, ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | portfolio\-duplication | portfolio | pass | The two supplied guide variants serve distinct current and historical tasks and have distinguishable labels in the supplied content\. | 01\-routing\-inventory\-map, ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |
| e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0ed570fccb7cf4b3ee87f41b1b991180c2fe9813d717dbaa7a2118aca78d874b | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | local\-file | 2026\-11\-17T16:07:29\.920Z | 0 full elapsed days | [evidence/847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117\.txt](evidence/847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ec2a367ded35dbf3a1d8bcfab339c3378c942b602a856413f9b3fdbad57b675e | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:07:29\.928Z | 0 full elapsed days | [evidence/e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196\.txt](evidence/e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 02\-markup\-extracted\-text | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/02\-markup\-extracted\-text\.txt](evidence/02-markup-extracted-text.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 01\-routing\-extracted\-text | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/01\-routing\-extracted\-text\.txt](evidence/01-routing-extracted-text.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 01\-routing\-publisher\-intent | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/01\-routing\-publisher\-intent\.txt](evidence/01-routing-publisher-intent.txt) | e580287cc78b3035fc63ac2687aa8425a3c4a04a2295a9789a4a6561f097d3b7 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 01\-routing\-crawler\-policy | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/01\-routing\-crawler\-policy\.txt](evidence/01-routing-crawler-policy.txt) | 78689a7ff9bac1dda21bb33c160896e610763d51a9aa6d9cbf4e4b150ea3b545 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 01\-routing\-canonical\-targets | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/01\-routing\-canonical\-targets\.txt](evidence/01-routing-canonical-targets.txt) | d91ef9a41251810375a71a69c45d2efa2f9b19ab12a7f922e9434141ebaf0444 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 01\-routing\-inventory\-map | e4be997b1d864541f035d6dd02c3db050ac36b6e3969d72bff096ff8d59c2196 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/01\-routing\-inventory\-map\.txt](evidence/01-routing-inventory-map.txt) | db723dbdc0f597d65426aebf66d58cff6cf99642cf6969f573838094c7049577 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 02\-markup\-schema\-extraction | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/02\-markup\-schema\-extraction\.txt](evidence/02-markup-schema-extraction.txt) | 0b6f19d8ed1a99bf94ce29778def9228d88c48d64dec3ee6c580dffc60213092 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 02\-markup\-publisher\-intent | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/02\-markup\-publisher\-intent\.txt](evidence/02-markup-publisher-intent.txt) | 55990e80b9a1bcb60f41f7afd166c55d5467455c1d8ca5b7f70bd09c3682973a | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |
| 02\-markup\-inventory\-map | 847272118a37d9639f853257df05d23306e3a45e8fc1c386f5059d11a7052117 | local\-file | 2026\-11\-17T16:08:47\.231Z | 0 full elapsed days | [evidence/02\-markup\-inventory\-map\.txt](evidence/02-markup-inventory-map.txt) | f93bf74d3af7c520c179abb1053bb6bfaacb3036e99f68e469fba1855c25c9c9 | Derived from owner\-supplied synthetic evidence\. Underlying capture time unspecified\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
