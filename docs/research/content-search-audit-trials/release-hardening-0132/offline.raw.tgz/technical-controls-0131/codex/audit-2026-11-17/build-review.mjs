import fs from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

const root = "audit-2026-11-17";
const snapshots = fs.readFileSync(`${root}/initial/evidence.jsonl`, "utf8")
  .trim().split("\n").map(line => JSON.parse(line));
const routing = snapshots.find(s => s.locator.endsWith("01-routing.md"));
const markup = snapshots.find(s => s.locator.endsWith("02-markup.md"));
const bundle = { evidence: [], artifacts: {}, reviews: [], findings: [] };
const now = new Date().toISOString();

function derive(snapshot, kind, lines, value) {
  const name = path.basename(snapshot.locator, ".md");
  const evidenceId = `${name}-${kind}`;
  const artifact = `evidence/${evidenceId}.txt`;
  bundle.artifacts[artifact] = value;
  bundle.evidence.push({
    ...snapshot, evidenceId, kind, value, artifact, collectedAt: now,
    locator: `${path.basename(snapshot.locator)}:${lines}`,
    byteLength: Buffer.byteLength(value),
    snapshotHash: createHash("sha256").update(value).digest("hex"),
    sourceEvidenceIds: [snapshot.evidenceId],
    limitations: ["Derived from owner-supplied synthetic evidence. Underlying capture time unspecified."],
  });
  return evidenceId;
}

function review(snapshot, ruleId, status, reason, ids = []) {
  bundle.reviews.push({
    itemId: snapshot.itemId, ruleId, status, reason,
    evidenceIds: [snapshot.evidenceId, ...ids],
    reviewer: "Codex offline dossier review", reviewedAt: now,
  });
}

function finding(snapshot, values) {
  bundle.findings.push({
    ...values, affectedItemIds: [snapshot.itemId],
    evidenceIds: [...new Set(bundle.reviews.filter(r => r.itemId === snapshot.itemId &&
      values.ruleIds.includes(r.ruleId)).flatMap(r => r.evidenceIds))],
    confidence: "high", classification: "observed", action: "update",
  });
}

for (const snapshot of snapshots) {
  derive(snapshot, "extracted-text", `1-${snapshot.value.trimEnd().split("\n").length}`, snapshot.value);
}

const routingIntent = derive(routing, "publisher-intent", "5-10, 50-55",
  "As of 2026-11-16 the owner approves /guide/current and wants Googlebot to crawl it. /guide/2024 must remain accessible and clearly historical. The response was captured with an ordinary browser user agent.");
const crawler = derive(routing, "crawler-policy", "12-20",
  routing.value.split("\n").slice(14, 19).join("\n"));
const canonical = derive(routing, "canonical-targets", "5-10, 22-55",
  "Owner-approved current: /guide/current. Browser capture: current HTTP 200 and HTML canonical points to /guide/2024. Sitemap names /guide/current. Owner dossier reports archive HTTP 200, historical label and archive self-canonical. Engine selection unavailable.");
const routingMap = derive(routing, "inventory-map", "5-8, 22-55",
  "Current customer guidance and historical reference are distinguishable version tasks. Current page reports 3 seats and archive reports former 2 seats.");

review(routing, "aio-crawler-policy", "fail",
  "The applicable Googlebot group disallows the approved current URL. The wildcard allowance does not override that group. The current path restriction does not cover the archive.", [crawler, routingIntent]);
review(routing, "seo-canonical", "fail",
  "Captured current HTML points to the historical archive while the sitemap lists the owner-approved current URL. The archive self-canonical is consistent with its historical purpose.", [canonical, routingIntent]);
review(routing, "portfolio-duplication", "pass",
  "The two supplied guide variants serve distinct current and historical tasks and have distinguishable labels in the supplied content.", [routingMap]);
review(routing, "seo-index-controls", "unknown",
  "The Googlebot crawl restriction is assessed under crawler policy. Complete index and snippet directives and observed index state are unavailable.", [crawler, routingIntent]);
finding(routing, {
  findingId: "current-guide-routing", title: "Current-guide crawl and canonical controls conflict with owner intent",
  ruleIds: ["aio-crawler-policy", "seo-canonical"], dimensions: ["seo", "aio"], severity: "high",
  remediation: "Permit Googlebot to crawl /guide/current and align its canonical to its own approved URL. Keep the sitemap current entry and preserve the accessible, visibly historical, self-canonical /guide/2024.",
  verification: "Evaluate the effective robots rule for Googlebot and the exact current path, inspect the current and archive response canonicals and sitemap, and confirm archive accessibility and labeling. Separately corroborate subsequent Googlebot fetch and engine-selected canonical with owner-supplied evidence if available.",
  ownerRole: "Web platform owner", effort: "small",
  actionReason: "Align independent crawl and canonical controls with the same approved route while retaining the historical version.",
});

const blocks = [...markup.value.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)];
const parseResults = blocks.map(([, body], i) => {
  const page = ["A", "B"][i];
  try {
    return { page, body, strictJson: "pass", parsed: JSON.parse(body) };
  } catch (error) {
    return { page, body, strictJson: "fail", parseError: error.message };
  }
});
if (parseResults.map(r => r.strictJson).join(",") !== "fail,pass") {
  throw new Error("Unexpected strict JSON comparison");
}
const schema = derive(markup, "schema-extraction", "7-40", JSON.stringify(parseResults, null, 2));
const markupIntent = derive(markup, "publisher-intent", "37-40",
  "Owner seeks correct machine-readable descriptions of documentation pages. No specific rich-result eligibility or Product, FAQPage, reviews or ratings requested.");
const markupMap = derive(markup, "inventory-map", "7-40",
  "English software documentation: Page A introduces Cedar Library and names Cedar Tools as the maintainer; Page B is a distinct export reference for Cedar Library.");
review(markup, "seo-structured-data", "fail",
  "Page A supplied WebPage JSON-LD is invalid strict JSON because of a trailing comma after its last member. Page B parses and its WebPage name matches the supplied heading. Other markup and search feature outcomes are unknown.", [schema, markupIntent]);
review(markup, "portfolio-duplication", "pass",
  "The supplied headings and introductions distinguish the library overview from the export reference.", [markupMap]);
finding(markup, {
  findingId: "cedar-overview-jsonld", title: "Trailing comma breaks Page A JSON-LD",
  ruleIds: ["seo-structured-data"], dimensions: ["seo"], severity: "medium",
  remediation: "Remove the trailing comma after Page A’s final name field. Retain the descriptive WebPage type and Page B’s valid block.",
  verification: "Parse the revised script body as strict JSON and compare its WebPage name to the visible heading. Run the same check on the unchanged Page B fixture.",
  ownerRole: "Documentation template maintainer", effort: "small",
  actionReason: "Restore a parseable machine-readable description for the overview.",
});

fs.writeFileSync(`${root}/review.json`, JSON.stringify(bundle, null, 2) + "\n");
