// Builds the attributed review bundle for this audit run. Target files are read
// as inert text only; JSON-LD blocks are parsed as data, never executed.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import process from "node:process";

const [projectRoot, runDirectory, outputFile] = process.argv.slice(2);
const hash = (value) => createHash("sha256").update(value).digest("hex");
const now = new Date().toISOString();
const reviewer = "Claude (content-search-audit host review, offline)";

const evidenceLines = readFileSync(
  path.join(runDirectory, "evidence.jsonl"),
  "utf8",
)
  .trim()
  .split("\n")
  .map((line) => JSON.parse(line));
const routingPath = path.join(projectRoot, "targets/01-routing.md");
const markupPath = path.join(projectRoot, "targets/02-markup.md");
const contentFor = (file) =>
  evidenceLines.find((r) => r.kind === "content" && r.locator === file);
const rContent = contentFor(routingPath);
const mContent = contentFor(markupPath);
if (!rContent || !mContent) throw new Error("Collected content not found");
const R = rContent.itemId;
const M = mContent.itemId;
const rText = readFileSync(routingPath, "utf8");
const mText = readFileSync(markupPath, "utf8");
if (hash(rText) !== rContent.snapshotHash || hash(mText) !== mContent.snapshotHash)
  throw new Error("Target changed since collection");
const lines = (text, a, b) => text.split("\n").slice(a - 1, b).join("\n");

const artifacts = {};
const evidence = [];
function add(id, source, kind, value, locator, method, limitations) {
  const json = typeof value !== "string";
  const artifactText = json ? JSON.stringify(value) : value;
  const artifact = `evidence/${id}.${json ? "json" : "txt"}`;
  artifacts[artifact] = artifactText;
  evidence.push({
    evidenceId: id,
    itemId: source.itemId,
    kind,
    method,
    collectedAt: now,
    locator,
    snapshotHash: hash(artifactText),
    redaction: "none; synthetic supplied dossier text retained locally",
    limitations,
    sourceEvidenceIds: [source.evidenceId],
    artifact,
    encoding: json ? "json" : "utf8",
    value,
  });
  return id;
}
const derived = "derived by host reviewer from the collected local dossier snapshot";
const synthetic = "Synthetic owner-supplied dossier; not independently verified and not a live capture";

// ---------- Routing dossier ----------
add("routing-extracted-text", rContent, "extracted-text", rText, "01-routing.md:1-55",
  "identity extraction of UTF-8 Markdown source text", [
    synthetic,
    "Text of the dossier, not rendered text of the described pages",
  ]);
add("routing-http-response", rContent, "http-response", {
  status: 200,
  url: "https://routing.example.test/guide/current",
  statusLine: lines(rText, 25, 25),
  capturedHeaders: [lines(rText, 26, 26)],
  captureUserAgent: "ordinary browser user agent, not Googlebot (01-routing.md:8-10)",
  relatedComponents: [
    { url: "/guide/2024", status: 200, basis: "dossier prose, 01-routing.md:52" },
  ],
}, "01-routing.md:24-27 and 01-routing.md:52", derived, [
  synthetic,
  "Captured by an ordinary browser user agent; the response served to Googlebot is not observed",
  "Only the status line and Content-Type header are supplied; other headers such as X-Robots-Tag or Link are unknown",
  "No capture timestamp is supplied for the response",
]);
add("routing-publisher-intent", rContent, "publisher-intent",
  [
    "Owner/task statements preserved verbatim from the supplied dossier (01-routing.md:5-10 and 01-routing.md:55).",
    lines(rText, 5, 10),
    lines(rText, 55, 55),
  ].join("\n\n"),
  "01-routing.md:5-10, 01-routing.md:55", derived, [
    synthetic,
    "Owner policy is an approved comparison basis dated 2026-11-16, not independent verification",
    "No intent is stated for crawlers other than Googlebot or for any AI-specific surface",
  ]);
add("routing-crawler-policy", rContent, "crawler-policy", {
  robotsUrl: "https://routing.example.test/robots.txt",
  robotsText: lines(rText, 15, 19),
  evaluation: [
    {
      agent: "Googlebot",
      path: "/guide/current",
      matchedGroup: "User-agent: Googlebot",
      matchedRule: "Disallow: /guide/current",
      effectiveDecision: "disallow",
    },
    {
      agent: "Googlebot",
      path: "/guide/2024",
      matchedGroup: "User-agent: Googlebot",
      matchedRule: null,
      effectiveDecision: "allow (no rule in the selected group matches this path)",
    },
    {
      agent: "any agent without its own group",
      path: "/guide/current",
      matchedGroup: "User-agent: *",
      matchedRule: "Allow: /",
      effectiveDecision: "allow",
    },
  ],
  basis:
    "Robots Exclusion Protocol group selection: a crawler uses the group whose user-agent line most specifically matches it and does not merge the * group. Applied by the reviewer from the supplied text; platform documentation was not re-read in this offline audit.",
}, "01-routing.md:12-20", derived, [
  synthetic,
  "Policy text only; no server log or crawl record shows what Googlebot actually requested",
  "Whether the same robots.txt body is served to every user agent is not observed",
  "Disallow rules match by path prefix; other URLs beginning /guide/current are not in the supplied inventory",
]);
add("routing-canonical-targets", rContent, "canonical-targets", {
  ownerPreferredCurrentGuide: "/guide/current (approved as of 2026-11-16, 01-routing.md:5)",
  declarations: [
    {
      page: "/guide/current",
      signal: "rel=canonical in captured raw HTML",
      target: "https://routing.example.test/guide/2024",
      locator: "01-routing.md:33",
    },
    {
      page: "/guide/2024",
      signal: "self-canonical, described in dossier prose",
      target: "/guide/2024",
      locator: "01-routing.md:53",
    },
    {
      page: "sitemap export",
      signal: "sitemap loc",
      target: "https://routing.example.test/guide/current",
      locator: "01-routing.md:46",
    },
  ],
  redirects: "No current-guide redirect is present in the supplied capture (01-routing.md:54-55)",
  engineSelectedCanonical: "unknown; no Search Console or engine-selected canonical data (01-routing.md:8-9)",
}, "01-routing.md:5-9, 33, 46, 52-55", derived, [
  synthetic,
  "Declared signals only; the canonical any engine selected is not observed",
  "The archive's canonical is described in prose; its markup is not supplied",
  "HTTP Link headers are not supplied",
]);
add("routing-entity-record", rContent, "entity-record",
  [
    "Owner-supplied record of which guide is current and of the archive's scope (01-routing.md:5-7 and 01-routing.md:52-54).",
    lines(rText, 5, 7),
    lines(rText, 52, 54),
  ].join("\n\n"),
  "01-routing.md:5-7, 01-routing.md:52-54", derived, [
    synthetic,
    "The owner confirms the archive statement for its historical scope; the owner does not separately confirm the value in 'Current entitlement: 3 seats.'",
  ]);
add("routing-inventory-map", rContent, "inventory-map", {
  scope: "Components described inside the one supplied dossier item; not a live-site inventory",
  components: [
    { id: "A", what: "robots.txt", locator: "01-routing.md:12-20" },
    { id: "B", what: "current guide /guide/current: response and raw HTML", locator: "01-routing.md:22-40", purpose: "approved current product guide" },
    { id: "C", what: "sitemap export", locator: "01-routing.md:42-48" },
    { id: "D", what: "archive /guide/2024 and owner context (prose description)", locator: "01-routing.md:50-55", purpose: "labelled historical document" },
  ],
}, "01-routing.md:12-55", derived, [
  synthetic,
  "Complete for the supplied dossier only; other site pages, links and sitemaps are unknown",
]);

// ---------- Markup dossier ----------
function parse(text) {
  try {
    return { parses: true, parsed: JSON.parse(text) };
  } catch (error) {
    return { parses: false, error: String(error.message) };
  }
}
const blockA = lines(mText, 14, 18);
const blockB = lines(mText, 29, 33);
const parseA = parse(blockA);
const parseB = parse(blockB);
add("markup-extracted-text", mContent, "extracted-text", mText, "02-markup.md:1-40",
  "identity extraction of UTF-8 Markdown source text", [
    synthetic,
    "Text of the dossier, not rendered text of the described pages",
  ]);
add("markup-http-response", mContent, "http-response", {
  status: 200,
  scope: "Page A and Page B",
  basis: lines(mText, 4, 4),
}, "02-markup.md:4", derived, [
  synthetic,
  "Status reported in dossier prose; no headers, URLs, user agent or capture time supplied",
]);
add("markup-publisher-intent", mContent, "publisher-intent",
  [
    "Owner/task statements preserved verbatim from the supplied dossier (02-markup.md:3-5 and 02-markup.md:37-40).",
    lines(mText, 3, 5),
    lines(mText, 37, 40),
  ].join("\n\n"),
  "02-markup.md:3-5, 02-markup.md:37-40", derived, [
    synthetic,
    "Owner request is the comparison basis; it is not independent verification of the site",
  ]);
add("markup-schema-extraction", mContent, "schema-extraction", {
  parser: `Strict JSON.parse (Node ${process.version}) applied to the text between the script tags, as data`,
  pages: [
    {
      page: "Page A: current library overview",
      locator: "02-markup.md:13-19",
      jsonText: blockA,
      result: parseA,
      visibleHeading: "Cedar Library",
    },
    {
      page: "Page B: current export reference",
      locator: "02-markup.md:28-34",
      jsonText: blockB,
      result: parseB,
      visibleHeading: "Export reference",
    },
  ],
}, "02-markup.md:13-19, 02-markup.md:28-34", derived, [
  synthetic,
  "Raw source blocks only; no rendered DOM and no other markup formats are supplied",
  "Strict JSON syntax result; how any particular search engine handles the block is not observed",
  "No rich-result test was supplied or requested",
]);
add("markup-inventory-map", mContent, "inventory-map", {
  scope: "Pages described inside the one supplied dossier item; not a live-site inventory",
  components: [
    { id: "Page A", what: "current library overview", heading: "Cedar Library", locator: "02-markup.md:7-20" },
    { id: "Page B", what: "current export reference", heading: "Export reference", locator: "02-markup.md:22-35" },
  ],
}, "02-markup.md:7-35", derived, [
  synthetic,
  "Complete for the supplied dossier only; URLs, links and other site pages are not supplied",
]);

// ---------- Reviews ----------
const reviews = [];
const review = (itemId, ruleId, status, reason, evidenceIds) =>
  reviews.push({ itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
const rc = rContent.evidenceId;
const mc = mContent.evidenceId;

review(R, "seo-index-controls", "fail",
  "Owner wants Googlebot to crawl the current guide, but the supplied robots.txt Googlebot group contains 'Disallow: /guide/current'; that group, not the '*' group, governs Googlebot. No noindex directive appears in the captured raw HTML or the two supplied response lines; the failure is the crawl control conflicting with intent. Archive /guide/2024 is not disallowed. Actual Googlebot fetches and index state are not observed.",
  [rc, "routing-http-response", "routing-publisher-intent", "routing-crawler-policy"]);
review(R, "aio-crawler-policy", "fail",
  "Same defect as seo-index-controls (one finding): the effective robots decision for Googlebot on /guide/current is disallow, contrary to the owner's stated crawl intent. Other agents fall under 'User-agent: *' with 'Allow: /'; no owner intent is stated for them, so no change is proposed for that group. No AI surface, retrieval or citation is observed.",
  ["routing-crawler-policy", "routing-publisher-intent"]);
review(R, "seo-canonical", "fail",
  "The approved current guide's captured rel=canonical names /guide/2024, the archive the owner says is not the preferred current guide. The sitemap lists /guide/current, so declared signals conflict. Clean components: the archive self-canonical and the sitemap entry match owner intent. Engine-selected canonical is unknown.",
  [rc, "routing-canonical-targets", "routing-publisher-intent"]);
review(R, "portfolio-duplication", "pass",
  "Within the supplied dossier the current guide and the 2024 archive are legitimate version variants with different stated entitlements; the owner requires both to stay accessible. No consolidation, redirect or removal is warranted or authorized. The canonical declaration that conflates them is tracked once under seo-canonical. Live-site inventory beyond the dossier is unknown.",
  [rc, "routing-inventory-map"]);
review(R, "portfolio-contradictions", "pass",
  "'Current entitlement: 3 seats.' (current guide) and '2024 archive — former entitlement: 2 seats.' (archive) differ by explicit version scope; the owner states the archive statement is accurate for its historical scope. A dated difference is not a contradiction. Whether 3 seats is itself correct is a separate, unresolved quality-claims question.",
  [rc, "routing-entity-record", "routing-inventory-map"]);
const unknownsR = {
  "quality-task-fit": "Audience and user task for the guide are not supplied; only a one-line body is captured for the current guide and one sentence for the archive.",
  "quality-claims": "The owner confirms the archive's 'former entitlement: 2 seats' for its historical scope (clean component). No dated authoritative source is supplied for 'Current entitlement: 3 seats.'; it is unverified, not shown false.",
  "quality-freshness": "Owner approval of /guide/current is dated 2026-11-16, but no page dates, capture times or source for the current entitlement value are supplied.",
  "quality-accessible-media": "No media appears in the captured current-guide HTML; the archive's markup and any media inventory are not supplied.",
  "seo-metadata": "Clean component: the current guide's title and h1 both read 'Current product guide'. Archive title/metadata, descriptions and audience context are not supplied, so the item-wide check stays unresolved.",
  "seo-internal-links": "Clean component: the sitemap export lists /guide/current. No internal link graph is supplied; no link appears in the captured HTML, and the archive's links are unknown. No orphan conclusion is drawn.",
  "seo-structured-data": "No structured data appears in the captured current-guide raw HTML and none was requested; the archive source and rendered DOM are not supplied.",
  "seo-locales": "The current guide declares lang=\"en\"; no locale variants or hreflang map are supplied.",
  "seo-rendering": "No rendered DOM was supplied and no browser capture is authorized offline; raw HTML only.",
  "aio-entity-consistency": "No product/entity record beyond the owner's guide-status statement is supplied; the product name and the current entitlement value cannot be compared with an authoritative record.",
  "aio-retrievable-facts": "The entitlement sentence is present in raw HTML, but audience context and target AI surface are not supplied; retrieval is not observed.",
  "aeo-question-coverage": "No customer question set is supplied; none is invented.",
  "aeo-answer-context": "No customer question set is supplied; none is invented.",
  "aeo-answer-evidence": "No dated source for the current entitlement claim is supplied; see quality-claims.",
  "geo-observed-presence": "No AI response observations are supplied; visibility is unmeasured, not zero.",
  "geo-answer-accuracy": "No AI response observations are supplied.",
  "geo-cohort-validity": "No AI observation cohort or prompt set is supplied.",
  "portfolio-task-gaps": "No question set or demand evidence is supplied; no gap is asserted.",
  "portfolio-journey-links": "No link graph or audience context is supplied; whether the archive links to the current guide is unknown.",
};
for (const [ruleId, reason] of Object.entries(unknownsR)) review(R, ruleId, "unknown", reason, [rc]);

review(M, "seo-structured-data", "fail",
  `Page A's JSON-LD block is not valid JSON: a comma follows the last member ("name": "Cedar Library",) before the closing brace; strict parsing fails (${parseA.error}). The owner asks for correct machine-readable descriptions. Clean component: Page B's block parses, declares WebPage and its name equals the visible heading 'Export reference'. Neither page uses Product, FAQPage, review or rating markup. Rendered DOM and engine handling are not observed; rich-result eligibility was not requested or tested.`,
  [mc, "markup-schema-extraction", "markup-publisher-intent"]);
review(M, "portfolio-duplication", "pass",
  "The two supplied pages serve distinct declared tasks: Page A is the library overview ('Cedar Library') and Page B the export reference ('Export reference'). No overlap requiring consolidation is evidenced. Only short visible-text excerpts are supplied; live-site inventory beyond the dossier is unknown.",
  [mc, "markup-inventory-map"]);
const unknownsM = {
  "quality-task-fit": "Audience and task evidence are not supplied; only one visible sentence per page is quoted.",
  "quality-claims": "'maintained by Cedar Tools' has no supplied authoritative source; unverified, not shown false.",
  "quality-freshness": "Both pages are labelled current by the dossier, but no dates, versions or sources are supplied.",
  "quality-accessible-media": "No media inventory is supplied.",
  "seo-index-controls": "Both pages return HTTP 200 per the dossier; no robots, meta robots, headers or index intent beyond documentation use are supplied. Indexed state is explicitly not supplied.",
  "seo-canonical": "No canonical declarations, URLs or Link headers are supplied.",
  "seo-metadata": "Visible headings are supplied; title elements, descriptions and audience context are not.",
  "seo-internal-links": "No link graph or page links are supplied.",
  "seo-locales": "The site is described as English; no locale variants or annotations are supplied.",
  "seo-rendering": "No rendered snapshots are supplied and no browser capture is authorized offline.",
  "aio-crawler-policy": "No crawler policy or AI-surface intent is supplied.",
  "aio-entity-consistency": "Observation only: 'Cedar Library' is used consistently in Page A's heading, text and intended JSON-LD name and in Page B's text. No authoritative entity record is supplied to resolve the check.",
  "aio-retrievable-facts": "Visible text is quoted in the dossier, but audience context and captured page text are not supplied; retrieval is not observed.",
  "aeo-question-coverage": "No customer question set is supplied; none is invented.",
  "aeo-answer-context": "No customer question set is supplied; none is invented.",
  "aeo-answer-evidence": "No claim sources are supplied.",
  "geo-observed-presence": "No AI-answer observations are supplied; visibility is unmeasured, not zero.",
  "geo-answer-accuracy": "No AI-answer observations are supplied.",
  "geo-cohort-validity": "No AI observation cohort or prompt set is supplied.",
  "portfolio-task-gaps": "No question set or demand evidence is supplied; no gap is asserted.",
  "portfolio-contradictions": "No conflicting claim is observed between the two supplied excerpts, but no authoritative entity record is supplied to resolve the check.",
  "portfolio-journey-links": "No link graph or audience context is supplied.",
};
for (const [ruleId, reason] of Object.entries(unknownsM)) review(M, ruleId, "unknown", reason, [mc]);

// ---------- Findings ----------
const findings = [
  {
    findingId: "F1-googlebot-disallowed-current-guide",
    title: "robots.txt disallows Googlebot from the approved current guide, contrary to owner crawl intent",
    affectedItemIds: [R],
    ruleIds: ["seo-index-controls", "aio-crawler-policy"],
    dimensions: ["seo", "aio"],
    evidenceIds: [rc, "routing-crawler-policy", "routing-publisher-intent", "routing-http-response"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "Proposal only. The owner has not authorized config edits; a separate implementation task and approval are required.",
    remediation:
      "Proposed, not executed: revise robots.txt so the effective decision for Googlebot on /guide/current is allow, for example by removing 'Disallow: /guide/current' from the Googlebot group (or removing that group if it has no other purpose so 'User-agent: *' / 'Allow: /' applies). Leave the '*' group and access to /guide/2024 unchanged. Sequence with F2 so that a newly crawlable current guide does not present a canonical naming the archive.",
    verification:
      "Re-read the revised robots.txt text: select the group that applies to Googlebot and confirm no Disallow rule in it prefix-matches /guide/current, and that /guide/2024 remains allowed. Any revision meeting that condition passes. This verifies permission only; an actual Googlebot fetch needs owner-supplied crawl evidence (for example verified server-log requests) from a later collection period. No named diagnostic tool workflow was verified offline.",
    ownerRole: "Site/SEO owner with robots.txt change authority",
    effort: "small",
  },
  {
    findingId: "F2-current-guide-canonical-names-archive",
    title: "Approved current guide declares the 2024 archive as its canonical, conflicting with the sitemap and owner preference",
    affectedItemIds: [R],
    ruleIds: ["seo-canonical"],
    dimensions: ["seo"],
    evidenceIds: [rc, "routing-canonical-targets", "routing-publisher-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "Proposal only. The owner has not authorized config edits, redirects or deletion; a separate implementation task and approval are required.",
    remediation:
      "Proposed, not executed: change the current guide's rel=canonical href to https://routing.example.test/guide/current, matching the sitemap loc. Keep the archive at /guide/2024 accessible, labelled and self-canonical; do not redirect or delete either page.",
    verification:
      "Re-capture the current guide's raw HTML and confirm its single rel=canonical href equals the sitemap loc https://routing.example.test/guide/current; confirm the archive still returns 200, keeps its 2024 label and its self-canonical. This verifies the declared signal only; which URL an engine selects as canonical remains unknown until the owner supplies engine data from a later period.",
    ownerRole: "Site/SEO owner with template change authority",
    effort: "small",
  },
  {
    findingId: "F3-page-a-jsonld-invalid-json",
    title: "Page A JSON-LD is not valid JSON (comma after the last member), so its machine-readable description cannot be parsed strictly",
    affectedItemIds: [M],
    ruleIds: ["seo-structured-data"],
    dimensions: ["seo"],
    evidenceIds: [mc, "markup-schema-extraction", "markup-publisher-intent"],
    severity: "medium",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "Proposal only. The audit does not modify source content; the content owner must approve and implement.",
    remediation:
      "Proposed, not executed: on Page A remove the comma after \"name\": \"Cedar Library\" so the object ends with that member. Keep @type WebPage and the name as they are. Leave Page B unchanged. Do not add Product, FAQPage, review or rating markup.",
    verification:
      "Take the text between the script tags from Page A's revised raw source and parse it as data with a strict JSON parser; it must parse, with @context https://schema.org, @type WebPage and name equal to the visible heading 'Cedar Library'. Page B must still parse unchanged. This checks syntax and visible-text agreement only, not rendered output, engine handling or any rich-result eligibility.",
    ownerRole: "Documentation site developer / content owner",
    effort: "small",
  },
];

writeFileSync(outputFile, JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log(JSON.stringify({ now, R, M, parseA, parseB, reviews: reviews.length, evidence: evidence.length, findings: findings.length }, null, 2));
