// Builds the quote ledger from the numbered quotation blocks in the final report.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import process from "node:process";

const [root, outputFile] = process.argv.slice(2);
const hash = (value) => createHash("sha256").update(value).digest("hex");
const reportBytes = readFileSync(path.join(root, "report.md"));
const report = reportBytes.toString("utf8").split("\n");
const sources = {};
for (const name of ["01-routing.md", "02-markup.md"])
  sources[name] = hash(readFileSync(path.join(root, "targets", name)));
const quotes = [];
for (let i = 0; i < report.length; i += 1) {
  const match = report[i].match(
    /^\s*\*\*(Q\d+)\*\* — `([^:`]+):(\d+)(?:-(\d+))?`\s*$/,
  );
  if (!match) continue;
  if (!/^\s*```text$/.test(report[i + 1])) throw new Error(`No fence after ${match[1]}`);
  let end = i + 2;
  while (!/^\s*```$/.test(report[end])) end += 1;
  quotes.push({
    quoteId: match[1],
    source: `targets/${match[2]}`,
    sourceLabel: match[2],
    sourceHash: sources[match[2]],
    startLine: Number(match[3]),
    endLine: Number(match[4] ?? match[3]),
    reportStartLine: i + 1,
    reportEndLine: end + 1,
    normalization: "whitespace",
    quote: report.slice(i + 2, end).join("\n"),
  });
}
writeFileSync(
  outputFile,
  JSON.stringify(
    { root, report: "report.md", reportHash: hash(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, ids: quotes.map((q) => q.quoteId).sort() }));
