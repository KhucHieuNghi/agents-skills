// Read-only inert text view of collected content snapshots (no script execution).
import fs from 'node:fs';
const P = process.argv[2];
const want = process.argv.slice(3);
const ev = fs.readFileSync(P + '/evidence.jsonl', 'utf8').trim().split('\n').map(JSON.parse);
for (const e of ev.filter((x) => x.kind === 'content')) {
  if (want.length && !want.some((w) => e.itemId.startsWith(w))) continue;
  const t = e.value;
  console.log('\n=====', e.itemId.slice(0, 8), e.locator, 'chars', t.length);
  const count = (re) => (t.match(re) || []).length;
  console.log('tags:', JSON.stringify({ script: count(/<script\b/gi), jsonld: count(/application\/ld\+json/gi), iframe: count(/<iframe\b/gi), template: count(/<template\b/gi), noscript: count(/<noscript\b/gi), img: count(/<img\b/gi), svg: count(/<svg\b/gi), video: count(/<video\b/gi), h1: count(/<h1\b/gi), metaRobots: count(/<meta[^>]+name="robots"/gi), form: count(/<form\b/gi) }));
  for (const m of t.matchAll(/<script\b[^>]*>/gi)) console.log('  SCRIPT', m[0].slice(0, 200));
  for (const m of t.matchAll(/<img\b[^>]*>/gi)) console.log('  IMG', m[0].slice(0, 300));
  for (const m of t.matchAll(/<svg\b[^>]*>/gi)) console.log('  SVG', m[0].slice(0, 200));
  let b = t.slice(t.indexOf('<body'));
  b = b.replace(/<script\b[\s\S]*?<\/script>/gi, ' [SCRIPT] ').replace(/<style\b[\s\S]*?<\/style>/gi, '').replace(/<svg\b[\s\S]*?<\/svg>/gi, ' [SVG] ');
  b = b.replace(/<a\b[^>]*href="([^"]*)"[^>]*>/gi, ' [A $1] ').replace(/<\/a>/gi, ' [/A] ');
  b = b.replace(/<(h[1-6])\b[^>]*>/gi, '\n\n#$1 ').replace(/<(p|li|tr|section|article|div|dt|dd|pre|summary|details|footer|header|nav|main|table|ul|ol|button)\b[^>]*>/gi, '\n').replace(/<[^>]+>/g, '');
  b = b.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  console.log(b.split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n'));
}
