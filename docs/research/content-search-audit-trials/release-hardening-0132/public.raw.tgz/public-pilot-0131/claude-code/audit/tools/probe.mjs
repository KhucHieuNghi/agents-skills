// Static (inert) probes over collected snapshots: ids, fragment targets, link targets, aria/figure markup.
import fs from 'node:fs';
const P = process.argv[2];
const L = (f) => fs.readFileSync(P + '/' + f, 'utf8').trim().split('\n').map(JSON.parse);
const inv = L('inventory.jsonl'); const ev = L('evidence.jsonl');
const byUri = new Map(inv.map((i) => [i.uri, i]));
const content = new Map(ev.filter((e) => e.kind === 'content').map((e) => [e.itemId, e]));
const http = new Map(ev.filter((e) => e.kind === 'http-response').map((e) => [e.itemId, e]));
const ids = new Map();
for (const [id, e] of content) ids.set(id, new Set([...e.value.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1])));
for (const i of inv) {
  const e = content.get(i.itemId); const h = http.get(i.itemId).value;
  const base = h.finalUrl || i.uri;
  console.log('\n==', i.itemId.slice(0, 8), i.uri, '-> final', h.finalUrl, 'ids:', [...ids.get(i.itemId)].join(','));
  const probs = [];
  for (const m of e.value.matchAll(/<a\b[^>]*\shref="([^"]*)"/g)) {
    let u; try { u = new URL(m[1].replace(/&amp;/g, '&'), base); } catch { probs.push('BAD ' + m[1]); continue; }
    if (u.origin !== 'https://nkskills.getgroove.me') continue;
    const frag = u.hash.slice(1); u.hash = '';
    const t = byUri.get(u.href);
    if (!t) { probs.push('NOT-IN-INVENTORY ' + m[1]); continue; }
    // fragment target is resolved against the final representation of the target item
    if (frag && !ids.get(t.itemId).has(frag)) probs.push('MISSING-FRAGMENT ' + m[1]);
  }
  console.log(probs.length ? probs.join('\n') : 'all internal anchors resolve (page + fragment)');
}
const show = (id, re, n = 400) => { const t = content.get(inv.find((i) => i.itemId.startsWith(id)).itemId).value; for (const m of t.matchAll(re)) console.log('  @' + m.index, JSON.stringify(t.slice(Math.max(0, m.index - 150), m.index + n))); };
console.log('\n-- VI catalog eyebrow'); show('cc34ba76', /DANH MỤ/g, 80);
console.log('\n-- aria-hidden / role=img / figure / sr-only in EN home');
const t = content.get(inv.find((i) => i.itemId.startsWith('ec35d79a')).itemId).value;
for (const m of t.matchAll(/<[a-z0-9]+\b[^>]*(aria-hidden|role="img"|aria-label|aria-labelledby|class="[^"]*(sr-only|visually-hidden)[^"]*")[^>]*>/g)) console.log('  @' + m.index, m[0].slice(0, 260));
for (const m of t.matchAll(/<(figure|figcaption|template|details|summary)\b[^>]*>/g)) console.log('  @' + m.index, m[0].slice(0, 200));
console.log('\n-- 02 Solution Skills context (EN home)'); show('ec35d79a', /Solution Skills<\/span>|02<\/|>02 /g, 300);
