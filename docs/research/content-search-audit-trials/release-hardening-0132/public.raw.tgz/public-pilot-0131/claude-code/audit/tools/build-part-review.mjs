// Builds the per-part review bundle for the NKSkills pilot from collected snapshots.
// Inert text processing only: no target script is executed and nothing is fetched.
// Every pass/fail below is bound to an assertion over the captured source; if the
// source does not show the stated fact, the script throws instead of emitting a verdict.
import fs from 'node:fs';
import { createHash } from 'node:crypto';

const [campaignDir, indexDir, outFile] = process.argv.slice(2);
const P = campaignDir + '/parts/000001';
const L = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map(JSON.parse);
const sha = (s) => createHash('sha256').update(s).digest('hex');
const index = JSON.parse(fs.readFileSync(indexDir + '/index.json', 'utf8'));
const inv = L(P + '/inventory.jsonl');
const ev = L(P + '/evidence.jsonl');
const ORIGIN = 'https://nkskills.getgroove.me';
const now = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), Claude Code host agent, content-search-audit pilot review';
const OWNER_CONTEXT =
  'NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied.';
const must = (cond, msg) => { if (!cond) throw new Error('Assertion failed: ' + msg); };
const decode = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");

const items = inv.map((i) => {
  const of = (kind) => ev.filter((e) => e.itemId === i.itemId && e.kind === kind);
  const content = of('content')[0];
  const http = of('http-response')[0];
  const policy = of('crawler-policy');
  const html = content.value;
  const isHtml = /text\/html/.test(http.value.headers['content-type'] || '');
  const finalUrl = http.value.redirects.length ? content.locator : i.uri;
  const attr = (re) => (html.match(re) || [])[1] ?? null;
  const head = {
    htmlLang: attr(/<html[^>]*\slang="([^"]*)"/),
    title: attr(/<title>([^<]*)<\/title>/),
    description: attr(/<meta name="description" content="([^"]*)"/),
    canonical: attr(/<link rel="canonical" href="([^"]*)"/),
    ogUrl: attr(/<meta property="og:url" content="([^"]*)"/),
    ogTitle: attr(/<meta property="og:title" content="([^"]*)"/),
    ogImage: attr(/<meta property="og:image" content="([^"]*)"/),
    metaRobots: attr(/<meta[^>]*name="robots"[^>]*content="([^"]*)"/),
    hreflang: [...html.matchAll(/<link rel="alternate" hreflang="([^"]*)" href="([^"]*)"/g)].map((m) => ({ hreflang: m[1], href: m[2] })),
  };
  const anchors = isHtml
    ? [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/g)].map((m) => {
        const href = decode((m[1].match(/\shref="([^"]*)"/) || [])[1] ?? '');
        const u = new URL(href, finalUrl);
        const fragment = u.hash.slice(1); u.hash = '';
        return { href, resolved: u.href, fragment, internal: u.origin === ORIGIN, text: decode(m[2].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim(), offset: m.index };
      })
    : [];
  const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
  return { ...i, short: i.itemId.slice(0, 8), content, http, policy, html, isHtml, finalUrl, head, anchors, ids };
});
const byUri = new Map(items.map((i) => [i.uri, i]));
const get = (uri) => { const i = byUri.get(uri); must(i, 'inventory has ' + uri); return i; };
const U = (p) => ORIGIN + p;
const ROOT = get(U('/')), HOME_EN = get(U('/en/')), HOME_VI = get(U('/vi/'));
const CAT_EN = get(U('/en/catalog/')), CAT_VI = get(U('/vi/catalog/'));
const SOL_EN = get(U('/en/solutions/codebase-onboarding/')), SOL_VI = get(U('/vi/solutions/codebase-onboarding/'));
const GC_EN = get(U('/en/guides/codex/')), GC_VI = get(U('/vi/guides/codex/'));
const GCC_EN = get(U('/en/guides/claude-code/')), GCC_VI = get(U('/vi/guides/claude-code/'));
const LIC = get(U('/licenses/README.txt'));
const HTML_ITEMS = items.filter((i) => i.isHtml);
must(HTML_ITEMS.length === 11 && !LIC.isHtml, '11 HTML items and one plain-text item');
must(ROOT.html === HOME_EN.html && ROOT.http.value.redirects[0].status === 308, 'root is a 308 alias with content identical to /en/');
const HOMES = [ROOT, HOME_EN, HOME_VI];
const purpose = new Map([[ROOT, 'root URL; 308 redirect alias of the English home page'], [HOME_EN, 'home / product overview (en)'], [HOME_VI, 'home / product overview (vi)'], [CAT_EN, 'skill catalog (en)'], [CAT_VI, 'skill catalog (vi)'], [SOL_EN, 'solution detail: codebase-onboarding (en)'], [SOL_VI, 'solution detail: codebase-onboarding (vi)'], [GC_EN, 'install/use guide for Codex (en)'], [GC_VI, 'install/use guide for Codex (vi)'], [GCC_EN, 'install/use guide for Claude Code (en)'], [GCC_VI, 'install/use guide for Claude Code (vi)'], [LIC, 'font licence notice (plain text, English, linked from both locales)']]);
const counterpartOf = (i) => {
  if (!i.isHtml) return null;
  const eff = new URL(i.finalUrl).pathname;
  const other = eff.startsWith('/en/') ? eff.replace(/^\/en\//, '/vi/') : eff.replace(/^\/vi\//, '/en/');
  return get(U(other));
};

// ---------- derived evidence ----------
const evidence = []; const artifacts = {};
const ids = new Map();
function add(item, kind, value, sources, limitations, method = 'host-derived-static-extraction', locator) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n';
  const evidenceId = `pilot-r1-${item.short}-${kind}`;
  const artifact = `evidence/${evidenceId}.txt`;
  artifacts[artifact] = text;
  evidence.push({
    evidenceId, itemId: item.itemId, kind, value: text, method,
    locator: locator ?? `${item.uri} (derived ${kind} from captured raw source)`,
    collectedAt: now, snapshotHash: sha(text), artifact, encoding: 'utf8',
    sourceEvidenceIds: [...new Set(sources)],
    redaction: 'No credentials or private data; derived from anonymous public snapshots',
    limitations,
  });
  ids.set(item.short + ':' + kind, evidenceId);
  return evidenceId;
}
const id = (item, kind) => { const v = ids.get(item.short + ':' + kind); must(v, 'evidence ' + item.short + ' ' + kind); return v; };
const RAW_LIMIT = 'Derived from the anonymous raw HTTP source only; no script execution, no rendered DOM';

const extractText = (i) => {
  if (!i.isHtml) return i.html;
  let b = i.html.slice(i.html.indexOf('<body'));
  b = b.replace(/<script\b[\s\S]*?<\/script>/gi, ' ').replace(/<style\b[\s\S]*?<\/style>/gi, ' ').replace(/<template\b[\s\S]*?<\/template>/gi, ' ');
  b = b.replace(/<\/?(h[1-6]|p|li|tr|section|article|div|dt|dd|pre|summary|details|footer|header|nav|main|table|ul|ol|figure|figcaption|br)\b[^>]*>/gi, '\n').replace(/<[^>]+>/g, ' ');
  return decode(b).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n') + '\n';
};
const allHtmlContent = HTML_ITEMS.map((i) => i.content.evidenceId);
const inventoryMap = items.map((i) => ({ itemId: i.itemId, uri: i.uri, finalUrl: i.finalUrl, htmlLang: i.head.htmlLang, purpose: purpose.get(i), localeCounterpart: counterpartOf(i)?.uri ?? null, title: i.head.title }));

// Site-stated entity facts (publisher's own pages; not an independently authoritative record)
const strip = (i, lang) => {
  const m = i.html.match(/<div class="proof-strip"[^>]*>([\s\S]*?)<a /);
  must(m, 'proof strip in ' + i.uri);
  return decode(m[1].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
};
const workCards = (i) => [...i.html.matchAll(/<span>NK \/ SOLUTION (\d{3})<\/span><span>(v[\d.]+)<\/span><\/div><span class="status-pill[^"]*">([^<]*)<\/span><h3>([^<]*)<\/h3>/g)].map((m) => ({ no: m[1], version: m[2], status: m[3], name: m[4] }));
const catalogStats = (i) => [...i.html.matchAll(/<a href="#(solutions|upstreams|security-upstreams|method)"[^>]*>([\s\S]*?)<\/a>/g)].map((m) => decode(m[2].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim());
const catalogSolutions = (i) => { const sec = i.html.slice(i.html.indexOf('id="solutions"'), i.html.indexOf('id="upstreams"')); return [...sec.matchAll(/<h3>([\s\S]*?)<\/h3>/g)].map((m) => decode(m[1].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim()); };
const facts = {
  homeEnStrip: strip(HOME_EN), homeViStrip: strip(HOME_VI),
  homeEnCards: workCards(HOME_EN), homeViCards: workCards(HOME_VI),
  catEnStats: catalogStats(CAT_EN), catViStats: catalogStats(CAT_VI),
  catEnSolutions: catalogSolutions(CAT_EN), catViSolutions: catalogSolutions(CAT_VI),
};
must(facts.homeEnStrip === '02 Solution Skills 01 technical release 01 evaluation candidate', 'EN strip text: ' + facts.homeEnStrip);
must(facts.homeViStrip === '02 Solution Skills 01 bản kỹ thuật 01 ứng viên đánh giá', 'VI strip text: ' + facts.homeViStrip);
for (const c of [facts.homeEnCards, facts.homeViCards]) {
  must(c.length === 3 && c.map((x) => x.name).join('|') === 'Codebase onboarding|Problem presentation|Content search audit', 'three solution cards');
  must(c.map((x) => x.version).join('|') === 'v1.1.0|v0.1.0|v0.1.31', 'card versions');
}
must(facts.homeEnCards.filter((x) => x.status === 'EVALUATION CANDIDATE').length === 2 && facts.homeViCards.filter((x) => x.status === 'ỨNG VIÊN ĐÁNH GIÁ').length === 2, 'two evaluation candidates listed on each home page');
must(facts.catEnStats[0] === '03 Solution Skills' && facts.catViStats[0] === '03 Solution Skills', 'catalog says 03 Solution Skills');
must(facts.catEnSolutions.join('|') === 'Codebase onboarding 1.1.0|Problem presentation 0.1.0|Content search audit 0.1.31' && facts.catViSolutions.join('|') === facts.catEnSolutions.join('|'), 'catalog lists three solution skills with the same versions');
must(/NKSKILLS \/ DANH MỤ<\/p>/.test(CAT_VI.html) && /NKSKILLS \/ CATALOG<\/p>/.test(CAT_EN.html), 'catalog eyebrow strings');
for (const g of [GC_EN, GC_VI, GCC_EN, GCC_VI]) {
  must(g.html.includes('build/codebase-onboarding-1.1.0') && g.html.includes('build/problem-presentation-0.1.0') && g.html.includes('build/content-search-audit-0.1.31'), 'guide versions ' + g.uri);
}
for (const s of [SOL_EN, SOL_VI]) must(s.html.includes('SOLUTION SKILL v1.1.0') || /v1\.1\.0/.test(s.html), 'solution page version');
const entityRecordText = (i) => [
  'ENTITY RECORD FOR CROSS-PAGE COMPARISON (two parts; neither is an independently authoritative product registry)',
  '',
  'Part A. Owner-supplied context (verbatim from the audit task statement, recorded ' + now + '):',
  '  "' + OWNER_CONTEXT + '"',
  '',
  'Part B. Publisher-stated facts extracted from the captured pages of the same campaign (raw source, captured 2026-11-17):',
  `  B1 ${HOME_EN.uri} status strip (aria-label "Catalog status"): "${facts.homeEnStrip}"`,
  `  B2 ${HOME_VI.uri} status strip: "${facts.homeViStrip}"`,
  `  B3 ${HOME_EN.uri} solution cards: ${facts.homeEnCards.map((c) => `${c.no} ${c.name} ${c.version} [${c.status}]`).join('; ')}`,
  `  B4 ${HOME_VI.uri} solution cards: ${facts.homeViCards.map((c) => `${c.no} ${c.name} ${c.version} [${c.status}]`).join('; ')}`,
  `  B5 ${CAT_EN.uri} header counters: ${facts.catEnStats.join(' | ')}; Solution Skills listed: ${facts.catEnSolutions.join('; ')}`,
  `  B6 ${CAT_VI.uri} header counters: ${facts.catViStats.join(' | ')}; Solution Skills listed: ${facts.catViSolutions.join('; ')}`,
  `  B7 ${SOL_EN.uri} and ${SOL_VI.uri}: Solution Skill v1.1.0, technical release, three components (codebase-onboarding-c4, html-docs-standard, Hallmark)`,
  '  B8 all four guides: build paths codebase-onboarding-1.1.0, problem-presentation-0.1.0, content-search-audit-0.1.31; hosts Codex and Claude Code',
  `  B9 ${ROOT.uri} is a 308 redirect to ${HOME_EN.uri} with byte-identical content`,
  '',
  'Not available: the GitHub records the site cites (catalog.yaml, release records, manifests) are outside the single authorized origin and were not collected. Which side of any on-site conflict is correct therefore cannot be resolved here.',
  `Bound to inventory item ${i.uri}.`,
  '',
].join('\n');

for (const i of items) {
  const own = [i.content.evidenceId];
  add(i, 'extracted-text', extractText(i), own, [i.isHtml ? 'Visible body text of the raw HTML source with tags removed, basic entities decoded, block elements split into lines; script, style and inert template contents are excluded; head metadata is not included' : 'Plain-text response body reproduced unchanged', 'Not a rendered-DOM text extraction']);
  add(i, 'canonical-targets', {
    requestedUrl: i.uri, finalUrl: i.finalUrl, redirects: i.http.value.redirects, status: i.http.value.status,
    declaredCanonical: i.head.canonical, ogUrl: i.head.ogUrl, hreflangAlternates: i.head.hreflang,
    httpLinkHeader: i.http.value.headers.link ?? null, retainedHeaderNames: Object.keys(i.http.value.headers),
    note: 'The collector retains the Link and X-Robots-Tag response headers when present; neither appears in this capture. sitemap.xml (declared in robots.txt) was not collected, so sitemap membership is not part of this record.',
  }, [...own, i.http.evidenceId], [RAW_LIMIT, 'A declared canonical is not an engine-selected canonical']);
  const cp = counterpartOf(i);
  add(i, 'locale-map', {
    uri: i.uri, finalUrl: i.finalUrl, htmlLang: i.head.htmlLang, hreflangAlternates: i.head.hreflang,
    counterpart: cp ? { uri: cp.uri, htmlLang: cp.head.htmlLang, hreflangAlternates: cp.head.hreflang, canonical: cp.head.canonical } : null,
    visibleLanguageSwitchLinks: i.anchors.filter((a) => cp && a.resolved === cp.uri).map((a) => ({ href: a.href, text: a.text })),
    inlinksFromLocales: [...new Set(items.filter((o) => o.anchors.some((a) => a.resolved === i.uri)).map((o) => o.head.htmlLang))],
  }, cp ? [...own, cp.content.evidenceId] : [...own, ...allHtmlContent], [RAW_LIMIT, 'Declared annotations only; engine-selected language results are not observed']);
  const internal = new Map();
  for (const a of i.anchors.filter((x) => x.internal)) {
    const key = a.resolved + '#' + a.fragment; const t = byUri.get(a.resolved);
    const fragmentFound = a.fragment ? !!t && t.ids.has(a.fragment) : null;
    const cur = internal.get(key) ?? { href: a.href, resolved: a.resolved, fragment: a.fragment || null, targetInInventory: !!t, targetItemId: t?.itemId ?? null, targetHttpStatus: t?.http.value.status ?? null, targetFinalUrl: t?.finalUrl ?? null, fragmentFound, anchorTexts: [], count: 0 };
    cur.count++; if (a.text && !cur.anchorTexts.includes(a.text)) cur.anchorTexts.push(a.text);
    internal.set(key, cur);
  }
  const inl = items.filter((o) => o !== i && o.anchors.some((a) => a.resolved === i.uri));
  const targets = [...new Set([...internal.values()].map((x) => byUri.get(x.resolved)).filter(Boolean))];
  i.graph = {
    uri: i.uri, finalUrl: i.finalUrl,
    internalAnchorTargets: [...internal.values()],
    externalAnchorTargets: [...new Set(i.anchors.filter((a) => !a.internal).map((a) => a.resolved))],
    inlinks: inl.map((o) => ({ from: o.uri, anchors: o.anchors.filter((a) => a.resolved === i.uri).length })),
    note: 'Anchor (a href) hyperlinks in captured raw source of the 12 inventory items only. External targets are listed, not fetched (outside the single allowed origin). Target status is the campaign capture of that inventory item. Stylesheet, font, script and image URLs are not hyperlinks and are not part of this graph. The graph is incomplete by declaration: sitemap, CMS, orphan pages and rendered navigation were not supplied.',
  };
  add(i, 'link-graph', i.graph, [...own, ...inl.map((o) => o.content.evidenceId), ...targets.flatMap((t) => [t.content.evidenceId, t.http.evidenceId])], [RAW_LIMIT, 'Incomplete graph cannot prove that a page is or is not orphaned']);
  i.schema = { jsonLdScriptBlocks: (i.html.match(/application\/ld\+json/gi) || []).length, microdataItemscopeAttributes: (i.html.match(/\sitemscope\b/gi) || []).length, rdfaTypeofAttributes: (i.html.match(/\stypeof="/gi) || []).length, openGraph: { 'og:type': (i.html.match(/<meta property="og:type" content="([^"]*)"/) || [])[1] ?? null, 'og:title': i.head.ogTitle, 'og:url': i.head.ogUrl, 'og:image': i.head.ogImage } };
  add(i, 'schema-extraction', { ...i.schema, note: 'Counts of structured-data carriers in the captured raw source. Open Graph meta tags are listed for context; they are not schema.org structured data.' }, own, [RAW_LIMIT, 'Raw absence does not establish rendered absence']);
  i.media = {
    img: [...i.html.matchAll(/<a\b([^>]*)>\s*(<img\b[^>]*>)|(<img\b[^>]*>)/g)].map((m) => { const tag = m[2] ?? m[3]; return { src: (tag.match(/\ssrc="([^"]*)"/) || [])[1], alt: (tag.match(/\salt="([^"]*)"/) || [])[1] ?? null, insideLinkWithAriaLabel: m[1] ? (m[1].match(/aria-label="([^"]*)"/) || [])[1] ?? null : null }; }),
    roleImg: [...i.html.matchAll(/<[a-z]+\b[^>]*role="img"[^>]*>/g)].map((m) => { const lab = (m[0].match(/aria-label="([^"]*)"/) || [])[1] ?? null; const d = (m[0].match(/aria-describedby="([^"]*)"/) || [])[1] ?? null; const dm = d ? i.html.match(new RegExp('id="' + d + '"[^>]*>([\\s\\S]*?)<\\/')) : null; return { ariaLabel: lab, describedBy: d, descriptionText: dm ? decode(dm[1].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim() : null }; }),
    ariaHiddenVisualContainers: [...i.html.matchAll(/<div class="([^"]*visual[^"]*)" aria-hidden="true">/g)].map((m) => m[1]),
    counts: Object.fromEntries(['svg', 'video', 'audio', 'iframe', 'picture', 'canvas', 'object', 'embed'].map((t) => [t, (i.html.match(new RegExp('<' + t + '\\b', 'gi')) || []).length])),
    ogImage: i.head.ogImage,
    note: 'og:image is a social preview URL referenced in metadata; the image file was not collected or inspected.',
  };
  add(i, 'media-inventory', i.media, own, [RAW_LIMIT, 'CSS background images and script-inserted media are not visible in this inventory']);
  add(i, 'audience-context', [
    'Owner-supplied audience and business context, verbatim from the audit task statement (recorded ' + now + '):',
    '  "' + OWNER_CONTEXT + '"',
    '',
    'Scope of this record: brand-level audience (people using Codex or Claude Code; English and Vietnamese readers) and business purpose.',
    'Not supplied: page-level intended tasks, personas, a customer question set, target AI search surfaces, markets beyond the two languages.',
    'Any page-level task named in a review is inferred from that page\'s own title and headings and is labelled as inferred.',
    `Bound to inventory item ${i.uri}.`, '',
  ].join('\n'), own, ['Owner statement is an approved comparison basis for this audit, not independently verified', 'Brand-level only; no page-level task or question evidence'], 'owner-supplied-context', 'audit task statement (business context sentence), bound to ' + i.uri);
  add(i, 'entity-record', entityRecordText(i), [...new Set([...own, ...allHtmlContent])], ['Part A is owner-supplied and unverified; Part B is the publisher\'s own captured pages, not an independent registry', 'External GitHub records cited by the site were not collected'], 'owner-supplied-context-plus-static-extraction', 'audit task statement and captured pages of this campaign, bound to ' + i.uri);
  add(i, 'inventory-map', { boundTo: i.uri, declaredInventoryItems: inventoryMap.length, scopeComplete: false, map: inventoryMap, note: 'Purpose labels are reviewer classifications from each page\'s own title and headings. The inventory is the static-link discovery result only; CMS records, orphan pages, sitemap entries and rendered navigation are not included.' }, [...new Set([...own, ...items.map((x) => x.content.evidenceId)])], [RAW_LIMIT, 'Purpose labels are reviewer classifications, not owner-declared']);
}

// ---------- fact assertions behind verdicts ----------
const canonicalOk = (i) => i.head.canonical === i.finalUrl && i.head.ogUrl === i.finalUrl;
const localeOk = (i) => {
  const cp = counterpartOf(i); const lang = new URL(i.finalUrl).pathname.slice(1, 3);
  const want = (x) => JSON.stringify(x.head.hreflang.map((h) => h.hreflang + '=' + h.href).sort());
  const enUri = lang === 'en' ? i.finalUrl : cp.uri, viUri = lang === 'vi' ? i.finalUrl : cp.uri;
  const expected = JSON.stringify([`en=${enUri}`, `vi=${viUri}`, `x-default=${enUri}`].sort());
  return i.head.htmlLang === lang && cp.head.htmlLang !== lang && want(i) === expected && want(cp) === expected && i.anchors.some((a) => a.resolved === cp.uri) && cp.anchors.some((a) => a.resolved === i.finalUrl);
};
const linksOk = (i) => i.graph.internalAnchorTargets.every((t) => t.targetInInventory && t.targetHttpStatus === 200 && t.fragmentFound !== false);
const mediaOk = (i) => i.media.img.length === 1 && i.media.img[0].src === '/brand/nkskills-mark.svg' && i.media.img[0].alt === '' && !!i.media.img[0].insideLinkWithAriaLabel && i.media.roleImg.every((r) => r.ariaLabel && r.descriptionText && r.descriptionText.length > 40) && Object.values(i.media.counts).every((n) => n === 0);
for (const i of HTML_ITEMS) {
  must(canonicalOk(i), 'canonical consistent ' + i.uri);
  must(localeOk(i), 'locale reciprocal ' + i.uri);
  must(linksOk(i), 'internal links resolve ' + i.uri);
  must(mediaOk(i), 'media inventory ' + i.uri + ' ' + JSON.stringify(i.media));
  must(i.schema.jsonLdScriptBlocks === 0 && i.schema.microdataItemscopeAttributes === 0 && i.schema.rdfaTypeofAttributes === 0, 'no structured data ' + i.uri);
  must(i.head.metaRobots === null && !('x-robots-tag' in i.http.value.headers), 'no robots directives ' + i.uri);
  must(i.policy.every((p) => p.value.decision.allowed === true), 'robots allowed');
}
must(new Set(HTML_ITEMS.filter((i) => i !== ROOT).map((i) => i.head.title)).size === 10 && new Set(HTML_ITEMS.filter((i) => i !== ROOT).map((i) => i.head.description)).size === 10, 'titles and descriptions unique across the ten localized pages');
must(LIC.graph.inlinks.length === 11 && LIC.anchors.length === 0, 'licence notice inlinks');
// journey facts
const toCodexAudit = (i, lang) => i.anchors.filter((a) => a.resolved === U(`/${lang}/guides/codex/`) && a.fragment === 'content-search-audit');
const toClaudeAudit = (i, lang) => i.anchors.filter((a) => a.resolved === U(`/${lang}/guides/claude-code/`) && a.fragment === 'content-search-audit');
for (const [i, lang] of [[ROOT, 'en'], [HOME_EN, 'en'], [HOME_VI, 'vi'], [CAT_EN, 'en'], [CAT_VI, 'vi']]) must(toCodexAudit(i, lang).length === 1 && toClaudeAudit(i, lang).length === 0, 'content-search-audit CTA goes only to the Codex guide on ' + i.uri);
for (const [g, lang] of [[GC_EN, 'en'], [GC_VI, 'vi']]) must(!g.anchors.some((a) => a.resolved === U(`/${lang}/guides/claude-code/`)) && g.ids.has('content-search-audit'), 'Codex guide has no link to the Claude Code guide ' + g.uri);
for (const g of [GCC_EN, GCC_VI]) must(g.ids.has('content-search-audit') && g.html.includes('--target claude-code'), 'Claude Code guide has its own content-search-audit section');
for (const [s, lang] of [[SOL_EN, 'en'], [SOL_VI, 'vi']]) must(s.anchors.some((a) => a.resolved === U(`/${lang}/guides/codex/`)) && s.anchors.some((a) => a.resolved === U(`/${lang}/guides/claude-code/`)), 'solution page links both guides');
for (const [h, lang] of [[HOME_EN, 'en'], [HOME_VI, 'vi']]) must(h.anchors.some((a) => a.resolved === U(`/${lang}/guides/codex/`) && !a.fragment) && h.anchors.some((a) => a.resolved === U(`/${lang}/guides/claude-code/`)), 'home links both guides for onboarding');

// ---------- reviews ----------
const reviews = [];
const R = (i, ruleId, status, reason, kinds) => reviews.push({ itemId: i.itemId, ruleId, status, reason, evidenceIds: kinds.map((k) => (k === 'content' ? i.content.evidenceId : k === 'http-response' ? i.http.evidenceId : k === 'crawler-policy' ? i.policy[0].evidenceId : id(i, k))), reviewer: REVIEWER, reviewedAt: now });
const NO_CLAIM_SRC = 'No dated claim sources are in evidence: the records this page cites (GitHub release records, manifests, catalog.yaml, technical guide) are outside the single authorized origin and were not collected, and no owner-approved fact sheet was supplied.';
const isHome = (i) => HOMES.includes(i);
const isGuide = (i) => [GC_EN, GC_VI, GCC_EN, GCC_VI].includes(i);
const journeyFail = new Set([ROOT, HOME_EN, HOME_VI, CAT_EN, CAT_VI, GC_EN, GC_VI]);
const langOf = (i) => new URL(i.finalUrl).pathname.slice(1, 3);

for (const i of items) {
  const lic = i === LIC;
  // quality
  R(i, 'quality-task-fit', 'unknown', lic
    ? 'Only brand-level audience context was supplied; no intended task for this licence notice is evidenced. Observed: the notice names three fonts, their authors and licence (SIL OFL 1.1) and refers to three full-notice files by bare filename (fraunces-OFL.txt, source-sans-3-OFL.txt, ibm-plex-mono-OFL.txt) that are not hyperlinks and were not captured.'
    : `Only brand-level audience context was supplied (Codex/Claude Code users, English and Vietnamese); the page-level intended task is not evidenced and is only inferable from the page itself (${purpose.get(i)}). ${isGuide(i) ? 'Observed in source: ordered prerequisite, build, install, run and review sections with commands. codegraph and rtk are listed as prerequisites without on-page setup steps, and the page defers archive/digest verification to an external technical guide that was not collected, so task completeness cannot be judged.' : 'Whether the content is sufficient for that task also depends on external GitHub documents that were not collected.'} Left unresolved rather than inferred.`, ['content', 'audience-context']);
  R(i, 'quality-claims', 'unknown', NO_CLAIM_SRC + (isHome(i) ? ' The on-site Solution Skill count conflict is recorded under aio-entity-consistency and portfolio-contradictions, not double-counted here.' : '') + ' Unverifiable is not false.', ['content']);
  R(i, 'quality-freshness', 'unknown', (lic ? 'No dated source for the font licence statements is in evidence.' : 'Version and status statements (for example 1.1.0, 0.1.0, 0.1.31) are present, but no dated authoritative record was collected to check their current applicability; the capture carries no Last-Modified header and the pages show no publication or update date.'), ['content', 'http-response']);
  if (lic) R(i, 'quality-accessible-media', 'not-applicable', 'The item is a text/plain response of 377 characters; the media inventory shows no image, video, audio or embedded media, so there is no informative media needing a text alternative.', ['content', 'media-inventory', 'http-response']);
  else R(i, 'quality-accessible-media', 'pass', `Raw-source media inventory: the only img is the brand mark /brand/nkskills-mark.svg with empty alt inside the home link that carries aria-label "${i.media.img[0].insideLinkWithAriaLabel}" (decorative, name supplied by the link). ${i.media.roleImg.length ? `The workflow diagram is exposed as role="img" with aria-label "${i.media.roleImg[0].ariaLabel}" and an aria-describedby text description of its four steps; the illustrative card visuals (${i.media.ariaHiddenVisualContainers.length}) are aria-hidden. ` : ''}No svg, video, audio, iframe, picture or canvas elements. Caveats: the og:image file was not collected, and CSS or script-inserted media are not visible in raw source.${langOf(i) === 'vi' && isHome(i) ? ' The aria-hidden illustrative visuals keep English labels on the Vietnamese page.' : ''}`, ['content', 'media-inventory']);
  // seo
  R(i, 'seo-index-controls', 'unknown', `Publisher indexing intent was not supplied. Observed only: ${lic ? 'no X-Robots-Tag header in the capture' : 'no meta robots element in raw source and no X-Robots-Tag header in the capture'}; robots.txt has "User-agent: *" / "Allow: /". These observations do not establish intent, rendered directives or index status.`, ['content', 'http-response', 'crawler-policy']);
  if (lic) R(i, 'seo-canonical', 'unknown', 'The capture has no HTTP Link header, so no canonical is declared for this text/plain resource, and no variant of it is in the inventory. Whether the publisher intends a canonical or wants the notice indexed at all is not evidenced; no conflict is observed.', ['content', 'canonical-targets']);
  else R(i, 'seo-canonical', 'pass', (i === ROOT ? `The root URL answers 308 to ${i.finalUrl}; the served document declares canonical ${i.head.canonical}, equal to the redirect target and to og:url. ` : `Declared canonical ${i.head.canonical} equals the captured final URL and og:url (self-referential). `) + `The ${langOf(i) === 'en' ? 'Vietnamese' : 'English'} counterpart declares its own self-canonical, so the locale variants are not collapsed. No HTTP Link header competes. Limits: raw source only; sitemap.xml membership was not inspected (not collected); the engine-selected canonical is unknown.`, ['content', 'canonical-targets']);
  if (lic) R(i, 'seo-metadata', 'unknown', 'A text/plain resource has no title or meta description; its first line "NKSkills site font notices" describes it. No audience task for this notice is evidenced, so accuracy of representation is not judged.', ['content', 'audience-context']);
  else R(i, 'seo-metadata', 'pass', `Title "${i.head.title}" and the meta description describe the page's own main content and language (${purpose.get(i)}); og:title equals the title. Titles and descriptions are unique across the ten localized pages${i === ROOT ? ' (this root item is the redirect alias of /en/ and shares its document)' : ''}; one h1. Judged against the brand-level audience context only; the page task is inferred from the page. ${isHome(i) ? 'Caveat: the description names two Solution Skills (codebase-onboarding and problem-presentation) while the page lists three; that omission is tracked with the count finding rather than as misleading metadata.' : isGuide(i) ? 'Caveat (optional improvement, not a failure): title and description mention codebase onboarding and the presentation candidate but not the Content search audit section (id content-search-audit) that the home and catalog pages deep-link to.' : i === CAT_VI ? 'Caveat: the visible eyebrow above the h1 reads "NKSKILLS / DANH MỤ" (English page: "NKSKILLS / CATALOG"), apparently a truncated "DANH MỤC"; body copy, not metadata.' : ''}`.trim(), ['content', 'audience-context']);
  if (lic) R(i, 'seo-internal-links', 'unknown', 'The notice is reachable: 11 inventory items link to it from their footers and it returned 200. It contains no hyperlinks (plain text). The three full-notice files it names by filename are not links, were not discovered or captured, and their availability is unverified.', ['content', 'link-graph']);
  else R(i, 'seo-internal-links', 'pass', `All ${i.graph.internalAnchorTargets.length} distinct internal anchor targets in the raw source resolve to inventory items captured with HTTP 200, and every fragment target exists as an id in the captured target document. ${i === ROOT ? 'This is the discovery seed (it redirects to /en/, which other pages link).' : `${i.graph.inlinks.length} other inventory items link to this URL.`} ${i.graph.externalAnchorTargets.length} distinct external targets (GitHub) are listed but not checked: they are outside the allowed origin. Limits: declared static graph only; orphan status and sitemap coverage cannot be judged.`, ['content', 'link-graph']);
  R(i, 'seo-structured-data', 'unknown', lic ? 'Plain-text resource; no structured data carrier is possible in the body and none is declared in retained headers. Applicability to a licence notice is not evidenced either way.' : 'The captured raw source contains no JSON-LD block, no microdata itemscope and no RDFa typeof (Open Graph meta tags only). Raw absence does not establish rendered absence, and no rendered DOM was captured, so there is nothing to compare with visible claims and no basis to call the rule not applicable.', ['content', 'schema-extraction']);
  if (lic) R(i, 'seo-locales', 'unknown', 'One English plain-text notice is linked from both the English and Vietnamese footers; it declares no alternates. Whether a Vietnamese variant is intended is not evidenced.', ['content', 'locale-map']);
  else R(i, 'seo-locales', 'pass', `html lang="${i.head.htmlLang}" matches the ${i === ROOT ? 'redirect target' : 'URL'} locale. The document declares hreflang en, vi and x-default (x-default = the English URL) including a self-reference, and the ${langOf(i) === 'en' ? 'Vietnamese' : 'English'} counterpart ${counterpartOf(i).uri} declares the identical set (reciprocal). Each side has a self-canonical and a visible language-switch link to the other. The two versions carry the same sections, versions and status statements. ${i === HOME_VI ? 'Caveat: aria-hidden illustrative visuals keep English labels. ' : i === CAT_VI ? 'Caveat: eyebrow "NKSKILLS / DANH MỤ" appears truncated compared with the English "NKSKILLS / CATALOG". ' : ''}Declared annotations only; engine language selection is not observed.`, ['content', 'locale-map']);
  R(i, 'seo-rendering', 'unknown', lic ? 'No rendered capture exists; browser execution was not authorized for this pilot. A plain-text body is not script-dependent, but no rendered evidence is attached to support a verdict.' : `No rendered DOM was captured: browser and script execution were excluded from this pilot. The raw source references ${(i.html.match(/<script\b/gi) || []).length} script element(s)${isHome(i) ? ' (/scripts/prompt-picker.js for the prompt selector with four inert template variants, and the Cloudflare Insights beacon)' : ' (the Cloudflare Insights beacon)'}; their effect on content or navigation is unobserved.`, ['content']);
  // aio
  R(i, 'aio-crawler-policy', 'unknown', 'Publisher intent for search discovery, AI training crawlers and user-triggered retrieval was not supplied. Observed: robots.txt (200) contains only "User-agent: *", "Allow: /" and a Sitemap line, with no agent-specific group; the audit collector was allowed for this URL. Permission is not evidence of any crawler fetch.', ['crawler-policy']);
  if (isHome(i)) R(i, 'aio-entity-consistency', 'fail', `The status strip labelled "Catalog status" states "${langOf(i) === 'en' ? facts.homeEnStrip : facts.homeViStrip}", but the same document lists three Solution Skills (001 Codebase onboarding v1.1.0, 002 Problem presentation v0.1.0, 003 Content search audit v0.1.31), two of them marked as evaluation candidates, and the ${langOf(i) === 'en' ? 'English' : 'Vietnamese'} catalog page states "03 Solution Skills" and lists the same three. Names, versions, statuses and hosts otherwise agree across pages. The correct count cannot be confirmed against the external catalog.yaml (not collected); the on-site conflict itself is established.`, ['content', 'entity-record']);
  else R(i, 'aio-entity-consistency', 'unknown', lic ? 'The notice names the site as NKSkills, consistent with the owner context; it carries no product facts. No authoritative entity record beyond the one-sentence owner context is in evidence.' : 'Brand name, host names (Codex, Claude Code), Solution Skill names, versions and statuses on this page agree with the other captured pages and with the owner context sentence. A full comparison against authoritative records (catalog.yaml, release records, manifests on GitHub) is not possible because they were not collected, so this is not resolved as a pass.', ['content', 'entity-record']);
  if (lic) R(i, 'aio-retrievable-facts', 'unknown', 'No audience need for this licence notice is evidenced. Observed: font names, authors and licence are readable plain text.', ['content', 'audience-context']);
  else R(i, 'aio-retrievable-facts', 'pass', `The facts a Codex or Claude Code reader would need from this page are present as readable text in the raw server response, without script execution: ${isHome(i) ? 'what NKSkills is, the three Solution Skills with versions and release status, supported hosts, install outline, the default starter prompt, limits and four FAQ answers' : isGuide(i) ? 'prerequisites, build and install commands with the host target, the invocation token, versions, distribution status and stated limits' : i === CAT_EN || i === CAT_VI ? 'Solution Skill names, versions and status, and each upstream skill with licence, short commit and source link' : 'version and release status, the three components, outputs, prerequisites and current limits'}. ${isHome(i) ? 'The three non-default prompt variants sit in inert template elements. The Solution Skill count is stated inconsistently (see the count finding). ' : ''}Readable facts do not prove retrieval or citation by any engine; "needed" is judged from brand-level audience context only.`, ['content', 'audience-context']);
  // aeo
  const NOQ = 'No question set from search, support, sales or customer evidence was supplied.';
  R(i, 'aeo-question-coverage', 'unknown', NOQ + (isHome(i) ? ' The page carries four publisher-authored FAQ questions; they are not customer question evidence and are not used to resolve this check.' : ' Hypothetical questions were not invented to resolve this check.'), ['content']);
  R(i, 'aeo-answer-context', 'unknown', NOQ + (isHome(i) ? ' Observation only: each of the four FAQ answers restates its subject and condition in the answer text.' : ''), ['content']);
  R(i, 'aeo-answer-evidence', 'unknown', NO_CLAIM_SRC, ['content']);
  // geo
  for (const r of ['geo-observed-presence', 'geo-answer-accuracy', 'geo-cohort-validity']) R(i, r, 'unknown', 'No AI response observations, prompt cohort or dated claim sources were supplied or collected. Mentions, citations and answer accuracy on any AI search surface are unmeasured, not zero.', []);
  // portfolio (local view of this item)
  R(i, 'portfolio-task-gaps', 'unknown', 'No customer question set or demand evidence was supplied, and discovery is declared incomplete (static links only), so task gaps cannot be separated from speculation.', ['content', 'inventory-map']);
  R(i, 'portfolio-duplication', 'pass', i === ROOT ? 'This URL is a 308 redirect to /en/ and serves the byte-identical document; a redirect alias with a canonical pointing to /en/, not a competing duplicate.' : i === HOME_EN ? 'Overlaps only with the root URL (which redirects here) and with its Vietnamese locale variant, each with distinct canonical and reciprocal hreflang; both are legitimate variants.' : lic ? 'No other inventory item covers font licence notices.' : isGuide(i) ? 'Overlaps closely with the sibling host guide and with its locale variant. The host guides differ in the install target value and invocation token for the named host, and the locale variants are reciprocal hreflang alternates with self-canonicals; these are legitimate host and locale variants. Whether the two host guides compete for the same queries is unknown without query data.' : 'The only overlapping item is its locale variant, which has its own self-canonical and reciprocal hreflang; a legitimate locale variant. No other inventory item covers the same task.', ['content', 'inventory-map']);
  if (isHome(i)) R(i, 'portfolio-contradictions', 'fail', `This page's status strip ("${langOf(i) === 'en' ? facts.homeEnStrip : facts.homeViStrip}") conflicts with its own three solution cards (two evaluation candidates) and with the catalog page's "03 Solution Skills". Same date, same market, same product set, so this is a contradiction rather than a version or market difference. Unresolved against the external catalog.yaml.`, ['content', 'entity-record', 'inventory-map']);
  else R(i, 'portfolio-contradictions', 'pass', (i === CAT_EN || i === CAT_VI ? 'Internally consistent: the "03 Solution Skills" counter matches the three listed, and the "15 Upstream Skills" counter matches the 9 general plus 6 security entries listed. Its conflict with the home page strip ("02 Solution Skills") is recorded on the home items, where the internal inconsistency sits. ' : lic ? 'Its statements (three open-licensed fonts) do not conflict with any other captured page. ' : '') + 'Versions (1.1.0, 0.1.0, 0.1.31), release statuses, supported hosts, prerequisites and the "no direct-download archive" statement on this page agree with every other captured page that states them. Compared across the captured pages and the owner context only; external records were not collected.' + (isGuide(i) ? ' Minor in-page wording: the prerequisites note places the Problem presentation trial "at the end of this guide" although the Content search audit and review sections follow it.' : ''), ['content', 'entity-record', 'inventory-map']);
  if (journeyFail.has(i)) R(i, 'portfolio-journey-links', 'fail', isGuide(i)
    ? 'This Codex guide is the only landing target of the Content search audit "Install and use" links on the home and catalog pages, and it has no link to the Claude Code guide, which holds the equivalent section with the Claude Code target and invocation. A Claude Code reader arriving here sees only Codex instructions and must go back through the home page install section to find the sibling guide.'
    : `The Content search audit entry on this page links only to the Codex guide (/${langOf(i)}/guides/codex/#content-search-audit). The Claude Code guide has its own section with the same id, but nothing on this page links to it for this skill${isHome(i) ? ', although the same page states that both hosts are supported and links both guides for codebase onboarding' : ''}. Other navigation on the page resolves and offers a next step.`, ['content', 'link-graph', 'audience-context']);
  else if (lic) R(i, 'portfolio-journey-links', 'unknown', 'A plain-text notice cannot carry navigation; whether a way back to the site matters for its readers is not evidenced.', ['content', 'link-graph', 'audience-context']);
  else R(i, 'portfolio-journey-links', 'pass', i === SOL_EN || i === SOL_VI ? 'The page links both host guides as the next step, the release record, the manifest and the technical setup guide (external), plus home, catalog and the locale switch; all internal targets resolve.' : 'This Claude Code guide links back to the home install section and the starter prompt, onward to the release record, evaluation and technical guide (external), and to its locale variant; all internal targets resolve. It is not the target of the single-host Content search audit links.', ['content', 'link-graph', 'audience-context']);
}

// ---------- findings ----------
const eids = (list, kinds) => list.flatMap((i) => kinds.map((k) => (k === 'content' ? i.content.evidenceId : id(i, k))));
const journeyItems = [ROOT, HOME_EN, HOME_VI, CAT_EN, CAT_VI, GC_EN, GC_VI];
const findings = [
  {
    findingId: 'pilot-solution-skill-count-conflict',
    title: 'Home page status strip says 02 Solution Skills while the page and catalog list three',
    affectedItemIds: HOMES.map((i) => i.itemId),
    ruleIds: ['aio-entity-consistency', 'portfolio-contradictions'],
    dimensions: ['aio', 'portfolio'],
    evidenceIds: eids(HOMES, ['content', 'entity-record', 'inventory-map']),
    severity: 'medium', confidence: 'high', classification: 'observed',
    remediation: 'Reconcile the home page status strip (English and Vietnamese) with the catalog source of truth. If three Solution Skills are current, state three with one technical release and two evaluation candidates; if the strip is meant to count something narrower, label it so. Review the home meta description, which names only two Solution Skills, in the same pass. Proposal only; no site change was made.',
    verification: 'Re-read the revised /en/ and /vi/ source: the strip counts must equal the number and statuses of the solution cards on the same page and the "Solution Skills" counter and list on /en/catalog/ and /vi/catalog/, and all must match catalog.yaml in the repository.',
    ownerRole: 'Site content owner (role not supplied; inferred)', effort: 'small',
    action: 'update', actionReason: 'The conflict is visible in captured source on both locales; which number is correct must be confirmed against catalog.yaml, which was not collected.',
  },
  {
    findingId: 'pilot-content-search-audit-single-host-path',
    title: 'Content search audit install links lead only to the Codex guide, which has no link to the Claude Code guide',
    affectedItemIds: journeyItems.map((i) => i.itemId),
    ruleIds: ['portfolio-journey-links'],
    dimensions: ['portfolio'],
    evidenceIds: eids(journeyItems, ['content', 'link-graph', 'audience-context']),
    severity: 'low', confidence: 'medium', classification: 'observed',
    remediation: 'On the home and catalog entries for Content search audit, offer both host guides (as the codebase-onboarding entry on the home page already does), or add a visible cross-link between the Codex and Claude Code guides near the host-specific sections. Apply to both locales. Proposal only; no site change was made.',
    verification: 'Re-read the revised source of /en/, /vi/, /en/catalog/ and /vi/catalog/: the Content search audit entry must reach /{locale}/guides/claude-code/#content-search-audit either directly or through a link on the Codex guide, and both targets must return 200 with that id present. Rendered navigation was not inspected in this pilot, so confirm in a browser as well.',
    ownerRole: 'Site content owner (role not supplied; inferred)', effort: 'small',
    action: 'update', actionReason: 'Observed in raw source on both locales; reader impact is inferred from the stated two-host audience, and no analytics were supplied to size it.',
  },
];

const bundle = {
  schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash,
  parts: [{ path: 'parts/000001', sourceSnapshotHash: index.partSnapshotHashes['parts/000001'], bundle: { reviews, evidence, artifacts, findings } }],
};
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2) + '\n', { flag: 'wx' });
const tally = {}; for (const r of reviews) tally[r.status] = (tally[r.status] || 0) + 1;
console.log(JSON.stringify({ outFile, reviewedAt: now, reviews: reviews.length, tally, evidence: evidence.length, findings: findings.length, facts }, null, 1));
