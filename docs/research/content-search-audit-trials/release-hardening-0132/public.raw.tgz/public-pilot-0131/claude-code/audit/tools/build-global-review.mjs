// Builds the global portfolio review bundle from the reviewed campaign revision (r1).
// Reads persisted evidence only; no network access and no target script execution.
import fs from 'node:fs';
import { createHash } from 'node:crypto';
const [campaignDir, indexDir, outFile] = process.argv.slice(2);
const sha = (s) => createHash('sha256').update(s).digest('hex');
const L = (f) => fs.readFileSync(f, 'utf8').trim().split('\n').map(JSON.parse);
const index = JSON.parse(fs.readFileSync(indexDir + '/index.json', 'utf8'));
const PART = 'parts/000001';
const inv = L(`${campaignDir}/${PART}/inventory.jsonl`);
const ev = L(`${campaignDir}/${PART}/evidence.jsonl`);
const checks = L(`${campaignDir}/${PART}/checks.jsonl`);
const now = new Date().toISOString();
const REVIEWER = 'Claude Fable 5.2 (claude-fable-5-2), Claude Code host agent, content-search-audit pilot review';
const U = (p) => 'https://nkskills.getgroove.me' + p;
const item = (p) => { const i = inv.find((x) => x.uri === U(p)); if (!i) throw new Error('missing ' + p); return i; };
const one = (i, kind) => { const e = ev.find((x) => x.itemId === i.itemId && x.kind === kind); if (!e) throw new Error(`missing ${kind} ${i.uri}`); return e; };
const ref = (e) => ({ part: PART, evidenceId: e.evidenceId });
const allIds = inv.map((i) => i.itemId);
const contentRefs = inv.map((i) => ref(one(i, 'content')));
const failed = (ruleId) => checks.filter((c) => c.ruleId === ruleId && c.status === 'fail').map((c) => c.itemId);
const homes = ['/', '/en/', '/vi/'].map(item);
const journey = ['/', '/en/', '/vi/', '/en/catalog/', '/vi/catalog/', '/en/guides/codex/', '/vi/guides/codex/'].map(item);
const same = (a, b) => JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());
if (!same(failed('portfolio-contradictions'), homes.map((i) => i.itemId))) throw new Error('local contradiction failures differ from expected home items');
if (!same(failed('portfolio-journey-links'), journey.map((i) => i.itemId))) throw new Error('local journey failures differ from expected items');
if (failed('portfolio-duplication').length) throw new Error('unexpected local duplication failure');

const ctx = (evidenceId, kind, value, locator, sources) => ({ evidenceId, kind, value, snapshotHash: sha(value), locator, collectedAt: now, sourceReferences: sources });
const invMapSrc = one(item('/en/'), 'inventory-map');
const entSrc = one(item('/en/'), 'entity-record');
const audSrc = one(item('/en/'), 'audience-context');
const graphs = inv.map((i) => one(i, 'link-graph'));
const graphSummary = graphs.map((g) => { const v = JSON.parse(g.value); return { uri: v.uri, finalUrl: v.finalUrl, internalTargets: v.internalAnchorTargets.map((t) => t.resolved + (t.fragment ? '#' + t.fragment : '') + ` [in inventory: ${t.targetInInventory}, status: ${t.targetHttpStatus}, fragment found: ${t.fragmentFound}]`), externalTargetCount: v.externalAnchorTargets.length, inlinksFrom: v.inlinks.map((x) => x.from) }; });
const contextEvidence = [
  ctx('pilot-global-inventory-map', 'inventory-map', 'Campaign-level copy of the per-item inventory map (12 declared items, scopeComplete=false). Purpose labels are reviewer classifications from page titles and headings; CMS records, orphan pages, sitemap entries and rendered navigation are not included.\n\n' + invMapSrc.value, 'derived from captured raw source of all 12 inventory items in ' + PART, [ref(invMapSrc), ...contentRefs]),
  ctx('pilot-global-entity-record', 'entity-record', 'Campaign-level copy of the entity record used for cross-page comparison. Part A is owner-supplied context; Part B is the publisher\'s own captured pages. Neither is an independent registry; the GitHub records cited by the site were not collected.\n\n' + entSrc.value, 'audit task statement and captured pages of this campaign', [ref(entSrc), ...contentRefs]),
  ctx('pilot-global-link-graph', 'link-graph', 'Campaign-level summary of anchor hyperlinks in the captured raw source of the 12 inventory items. External targets are counted, not fetched. Incomplete by declaration: sitemap, CMS, orphan pages and rendered navigation were not supplied.\n\n' + JSON.stringify(graphSummary, null, 2) + '\n', 'derived from captured raw source of all 12 inventory items in ' + PART, [...graphs.map(ref), ...contentRefs]),
  ctx('pilot-global-audience-context', 'audience-context', 'Campaign-level copy of the owner-supplied audience context (brand level only; no page-level tasks, personas or question set were supplied).\n\n' + audSrc.value, 'audit task statement (business context sentence)', [ref(audSrc)]),
];
const reviews = [
  { ruleId: 'portfolio-task-gaps', status: 'unknown', itemIds: allIds, evidenceReferences: contentRefs, contextEvidenceIds: ['pilot-global-inventory-map'],
    reason: 'No customer question set, search query export, support themes or demand evidence was supplied, and discovery is declared incomplete (static links from the home page only; CMS, orphan pages, sitemap and rendered navigation not supplied). Observed inventory by purpose: home (en, vi, plus the root redirect alias), catalog (en, vi), one solution detail page for codebase-onboarding (en, vi), host guides for Codex and Claude Code (en, vi) and one font licence notice. Problem presentation and Content search audit have no on-site detail page; whether that is a gap needs demand evidence and is left exploratory.' },
  { ruleId: 'portfolio-duplication', status: 'pass', itemIds: allIds, evidenceReferences: contentRefs, contextEvidenceIds: ['pilot-global-inventory-map'],
    reason: 'Across the 12 declared items the only overlaps are legitimate variants: (1) the root URL is a 308 redirect alias of /en/ serving the identical document whose canonical is /en/; (2) five English/Vietnamese pairs, each with self-canonicals and reciprocal hreflang; (3) the Codex and Claude Code guides in each locale, which share structure but differ in the install target value and invocation token for the named host. No two items serve the same task for the same audience, host and locale. Limits: declared static-link inventory only; whether the two host guides compete for the same queries is unknown without query data, and no consolidation is proposed.' },
  { ruleId: 'portfolio-contradictions', status: 'fail', itemIds: allIds, evidenceReferences: contentRefs, contextEvidenceIds: ['pilot-global-entity-record', 'pilot-global-inventory-map'],
    reason: 'One material cross-page conflict: the English and Vietnamese home pages (and the root alias) state "02 Solution Skills", one technical release and one evaluation candidate in the status strip, while the same pages list three Solution Skills with two evaluation candidates and both catalog pages state "03 Solution Skills" and list three. Same capture date, product set and market, so not a date or market difference. All other compared claims agree across the pages that state them: versions 1.1.0, 0.1.0 and 0.1.31, release statuses, supported hosts, prerequisites, three components for codebase-onboarding and the absence of a direct-download archive. The conflict is not resolved against catalog.yaml, which is outside the authorized origin.' },
  { ruleId: 'portfolio-journey-links', status: 'fail', itemIds: allIds, evidenceReferences: [...contentRefs, ...graphs.map(ref)], contextEvidenceIds: ['pilot-global-link-graph', 'pilot-global-audience-context'],
    reason: 'Navigation between related tasks mostly holds in the captured source: every internal anchor target and fragment resolves, the home and solution pages link both host guides for codebase onboarding, and guides link back to the starter prompt and onward to release records. One break for the stated two-host audience: the Content search audit entries on the home and catalog pages (both locales) link only to the Codex guide section, and the Codex guides have no link to the Claude Code guides, which hold the equivalent section. The licence notice is plain text without navigation (not counted as a defect). Rendered navigation was not inspected.' },
];
const findings = [
  { findingId: 'pilot-global-solution-skill-count-conflict', ruleId: 'portfolio-contradictions', severity: 'medium', confidence: 'high',
    observation: 'Home pages (en, vi, and the root alias) show "02 Solution Skills / 01 technical release / 01 evaluation candidate" in the status strip while listing three Solution Skills (two evaluation candidates) on the same page; the catalog pages state "03 Solution Skills" and list the same three.',
    recommendation: 'Reconcile the home status strip in both locales with the catalog source of truth (catalog.yaml), and review the home meta description that names only two Solution Skills. Proposal only; no site change was made by this audit.',
    verification: 'Re-read the revised /en/ and /vi/ source and compare the strip counts with the solution cards on the same page, the catalog counters and lists, and catalog.yaml.',
    ownerRole: 'Site content owner (role not supplied; inferred)', effort: 'small', action: 'update', actionReason: 'Conflict is visible in captured source on both locales; the correct number must be confirmed against catalog.yaml, which was not collected.',
    affectedItemIds: homes.map((i) => i.itemId), evidenceReferences: homes.map((i) => ref(one(i, 'content'))).concat(['/en/catalog/', '/vi/catalog/'].map((p) => ref(one(item(p), 'content')))) },
  { findingId: 'pilot-global-content-search-audit-single-host-path', ruleId: 'portfolio-journey-links', severity: 'low', confidence: 'medium',
    observation: 'On the home and catalog pages in both locales the Content search audit entry links only to /{locale}/guides/codex/#content-search-audit. The Claude Code guides carry a section with the same id, but neither those entries nor the Codex guides link to it.',
    recommendation: 'Offer both host guides from the Content search audit entries, or cross-link the two host guides. Apply to both locales. Proposal only; no site change was made by this audit.',
    verification: 'Re-read the revised source of the home, catalog and Codex guide pages in both locales and confirm a path to /{locale}/guides/claude-code/#content-search-audit that returns 200 with that id present; confirm in a browser because rendered navigation was not inspected.',
    ownerRole: 'Site content owner (role not supplied; inferred)', effort: 'small', action: 'update', actionReason: 'Observed in raw source on both locales; reader impact is inferred from the stated two-host audience and is not sized by analytics.',
    affectedItemIds: journey.map((i) => i.itemId), evidenceReferences: journey.flatMap((i) => [ref(one(i, 'content')), ref(one(i, 'link-graph'))]) },
];
for (const r of reviews) Object.assign(r, { reviewer: REVIEWER, reviewedAt: now }); // attribution required by the global review contract (attempt 1 omitted it and was rejected)
const bundle = { schemaVersion: 1, campaignId: index.campaignId, sourceManifestHash: index.sourceManifestHash, partSnapshotHashes: index.partSnapshotHashes, contextEvidence, reviews, findings };
fs.writeFileSync(outFile, JSON.stringify(bundle, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ outFile, reviewedAt: now, reviews: reviews.map((r) => r.ruleId + '=' + r.status), findings: findings.length }));
