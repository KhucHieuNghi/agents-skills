// Writes the supplementary pilot summary and its quote ledger from validated artifacts.
import fs from 'node:fs';
import { createHash } from 'node:crypto';
const root = process.argv[2];
const sha = (b) => createHash('sha256').update(b).digest('hex');
const cov = JSON.parse(fs.readFileSync(root + '/audit/report-r1/coverage.json', 'utf8'));
const c = cov.itemCoverage;
const E = 'audit/campaign-r1/parts/000001/evidence/';
const Q = [
  ['Q1', 'pilot-r1-ec35d79a-extracted-text.txt', 21, '02 Solution Skills 01 technical release 01 evaluation candidate', 'English home (/en/), status strip'],
  ['Q2', 'pilot-r1-8cf45780-extracted-text.txt', 21, '02 Solution Skills 01 bản kỹ thuật 01 ứng viên đánh giá', 'Vietnamese home (/vi/), status strip'],
  ['Q3', 'pilot-r1-f66acb16-extracted-text.txt', 7, '03 Solution Skills 15 Upstream Skills 06 Security sources 01 Versioning model', 'English catalog, header counters'],
  ['Q4', 'pilot-r1-cc34ba76-extracted-text.txt', 7, '03 Solution Skills 15 Upstream Skills 06 Nguồn bảo mật 01 Cách quản lý', 'Vietnamese catalog, header counters'],
  ['Q5', 'pilot-r1-cc34ba76-extracted-text.txt', 4, 'NKSKILLS / DANH MỤ', 'Vietnamese catalog, eyebrow above the h1'],
  ['Q6', 'pilot-r1-f66acb16-extracted-text.txt', 4, 'NKSKILLS / CATALOG', 'English catalog, eyebrow above the h1'],
];
const lines = [];
const P = (s = '') => lines.push(s);
P('# NKSkills public pilot: supplementary summary');
P();
P('Status: **partial**. This note accompanies the helper-rendered report in `audit/report-r1/`; counts are copied from its validated `coverage.json`.');
P();
P('## Coverage (campaign ' + cov.campaignId + ')');
P();
P(`- Declared items: ${c.total}; collected: ${c.collected}; fully audited: ${c.audited}`);
P(`- Pending: ${c.states.pending}; failed: ${c.states.failed}; blocked: ${c.states.blocked}; unsupported: ${c.states.unsupported}; excluded: ${c.states.excluded}`);
P(`- Missing checks: ${c.missingChecks}; pending queue entries: ${c.pendingQueue.length}; completionAllowed: ${cov.completionAllowed}; unresolved global rules: ${cov.unresolvedRuleIds.join(', ')}`);
P('- Every item was collected and read, but none is fully audited: each still has checks that need evidence this pilot did not have.');
P();
P('## Source quotations');
P();
P('Quotations are from the derived extracted-text artifacts (raw HTML with tags replaced by spaces; for example the wordmark reads "NK Skills"). Each is bound to the file and line shown.');
P();
const quotes = [];
for (const [idq, file, line, quote, where] of Q) {
  const start = lines.length + 1;
  P(`- ${idq} (${where}): "${quote}" at ${file}:${line}`);
  quotes.push({ quoteId: idq, source: E + file, sourceLabel: file, sourceHash: sha(fs.readFileSync(root + '/' + E + file)), startLine: line, endLine: line, reportStartLine: start, reportEndLine: start, normalization: 'exact', quote });
}
P();
P('## Findings');
P();
P('1. Solution Skill count conflict (medium severity, high confidence, observed). Q1 and Q2 state two Solution Skills with one evaluation candidate; the same home pages list three solution cards with two evaluation candidates, and Q3 and Q4 state three. Not resolved against catalog.yaml, which is outside the authorized origin.');
P('2. Content search audit install path (low severity, medium confidence, observed). The home and catalog entries link only to the Codex guide section; the Codex guides have no link to the Claude Code guides, which carry the equivalent section. Rendered navigation was not inspected.');
P();
P('Observation without a failed check: Q5 appears truncated compared with Q6 (probably "DANH MỤC"). It is recorded as a caveat on the Vietnamese catalog reviews, not as a finding.');
P();
P('## Not measured');
P();
P('Rankings, indexing, crawler logs, AI citations or mentions, and conversions are unknown. No Search Console, analytics, server-log or AI-response data was supplied. Readiness observations are not visibility measurements.');
P();
P('## Ledger scope');
P();
P('The quote ledger covers the six quotations Q1 to Q6 above and nothing else. The helper-rendered report contains reviewer reason text that repeats these strings; that report was not submitted to the quote verifier.');
const report = lines.join('\n') + '\n';
fs.writeFileSync(root + '/audit/pilot-summary.md', report, { flag: 'wx' });
fs.writeFileSync(root + '/audit/bundles/quote-ledger.json', JSON.stringify({ root, report: 'audit/pilot-summary.md', reportHash: sha(report), quotes }, null, 2) + '\n', { flag: 'wx' });
console.log('written', lines.length, 'lines');
