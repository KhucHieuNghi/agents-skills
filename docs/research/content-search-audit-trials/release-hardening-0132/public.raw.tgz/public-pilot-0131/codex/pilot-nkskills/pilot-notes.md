# NKSkills public pilot notes

The sole origin was https://nkskills.getgroove.me. The declared collection used static source hyperlinks, a maximum of 30 page captures and depth 5. The initial process exited successfully at its one-page budget, as confirmed by the harness. The helper validated the copied source before replay. Its registered provenance paths are retained in the original receipt. The discovery union embeds the continuation receipt and declares incomplete scope. CMS, orphan-page and rendered-navigation evidence was unavailable.

## Coverage and evidence

The continuation retained one successful root capture ending at /en/ after a 308 and attempted six depth-1 URLs. All six attempts failed at DNS resolution. The resulting frontier has zero count or depth deferrals. The six failed URL paths are /en/catalog/, /vi/, /en/solutions/codebase-onboarding/, /en/guides/codex/, /en/guides/claude-code/ and /licenses/README.txt. The receipt also preserves one rendering gap and 11 external link exclusions covering nine unique URLs. Campaign discovery adds source-incomplete and scope-unconfirmed for nine queue entries in total.

The campaign attempted all eight declared URL identities, including / and /en/. All eight failed DNS resolution in this environment. There were zero fresh collections, fully audited items, pending items, blocked items, unsupported items and inventory exclusions. There are 208 planned checks, one assessed failure, 207 unknown and zero missing check records. All four portfolio judgments remain unknown. See [validated coverage](customer-report/coverage.json).

The one historical English homepage body was reviewed across six dimensions. Its status strip counts two Solution Skills and one evaluation candidate, while its three numbered cards include two evaluation candidates. Confirm the intended catalog scope, then align the strip and cards or label the subset. Compare the final counts with the approved inventory and the equivalent Vietnamese copy. The English and Vietnamese starter templates in the captured source preserve the same prerequisites, version and stop conditions for each host. The separate Vietnamese page and reciprocal locale annotations remain unverified. The historical raw HTML declares /en/ canonical and identifies English, Vietnamese and x-default alternatives. These observations describe source signals as captured. [Count evidence](reviewed/parts/000001/evidence/home-count-comparison.txt) · [Historical capture](continued-discovery/captures/000001/capture.json)

## Recovery

Once the packaged collector can resolve the authorized public origin, replay the validated continuation into a new directory with the existing explicit budgets. This retries the six failed discovery URLs and follows any newly observed in-scope static links within those limits.

```sh
rtk proxy node .agents/skills/content-search-audit/scripts/audit.mjs discovery-resume pilot-nkskills/continued-discovery pilot-nkskills/discovery-after-dns pilot-nkskills/budgets.json
```

Validate the new discovery, build a new union and collect it into a fresh campaign so all declared items are attempted again. Use current raw responses to verify destination availability, anchors and English/Vietnamese reciprocity. Rendered navigation and interactions require separately authorized rendered snapshots. A CMS or publisher URL inventory would address discovery beyond the declared static navigation.

No measurements were supplied. Rankings and indexing need dated search and URL-level index evidence. Crawler activity needs dated request logs. AEO demand needs real English and Vietnamese search or support questions. GEO needs dated, surface-specific response captures with prompt versions, locales, repetitions, citations and adjudicated claims. Conversions need attributable landing-page and conversion data. AIO refers to AI search optimization. Google AI Overviews was unmeasured.
