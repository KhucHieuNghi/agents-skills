# NKSkills — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:25:31\.293Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 23a723e8\-564d\-4b05\-aa40\-2a86ecf18c6c\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 8 |
| In scope | 8 |
| Audited | 0 |
| Accounted | 8 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 8 |
| Unsupported | 0 |
| Pending | 0 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Inventory completeness is unknown; Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 24 | 0 | 24 | 0 |
| aio | 24 | 0 | 24 | 0 |
| geo | 24 | 0 | 24 | 0 |
| portfolio | 32 | 0 | 32 | 0 |
| quality | 40 | 0 | 40 | 0 |
| seo | 64 | 0 | 64 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | failed | getaddrinfo ENOTFOUND nkskills\.getgroove\.me | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7 | 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | public\-http | 2026\-11\-17T16:25:31\.216Z | 0 full elapsed days | [evidence/3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7\.json](evidence/3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7.json) | bceb676ecd2fb99b09bf35c28a17a5509df069e4b82ea7d45bc26003bb82571d | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330 | 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | public\-http | 2026\-11\-17T16:25:31\.223Z | 0 full elapsed days | [evidence/a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330\.json](evidence/a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330.json) | e84f76f5b7d9963f987e87e79079b3225c81ffc9b6d52d5eed2f67cde9d0a4ed | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718 | 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | public\-http | 2026\-11\-17T16:25:31\.231Z | 0 full elapsed days | [evidence/d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718\.json](evidence/d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718.json) | 0b8af49a37b6be2878991fa3941c7b3482bf139a09bd786c2866bf593de8c3ec | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367 | 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | public\-http | 2026\-11\-17T16:25:31\.239Z | 0 full elapsed days | [evidence/1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367\.json](evidence/1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367.json) | 56749164697c318985f90b31a6ac4a3698e60014cd7ca60e1a1d554238c4d420 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448 | 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | public\-http | 2026\-11\-17T16:25:31\.245Z | 0 full elapsed days | [evidence/dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448\.json](evidence/dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448.json) | 46b8457f58b7aadf9ddbdd171baf1d8886dc218c1a74ae63564970c00b58ee25 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da | ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | public\-http | 2026\-11\-17T16:25:31\.253Z | 0 full elapsed days | [evidence/19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da\.json](evidence/19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da.json) | f86ab142df03e3289f7c1e3c4833a9f9958c943098cf13872f98478f543ecb52 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8 | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | public\-http | 2026\-11\-17T16:25:31\.261Z | 0 full elapsed days | [evidence/4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8\.json](evidence/4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8.json) | c7550c26fd4ea23738299b800ac2339b829ad12dc8959eb2ee554dc5de741b0c | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |
| 776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe | f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | public\-http | 2026\-11\-17T16:25:31\.268Z | 0 full elapsed days | [evidence/776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe\.json](evidence/776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe.json) | d48ebe44570096657045beef49804e310d78840b29b55824b28aa613ef3608d8 | Anonymous captured response only; no rendered DOM, index verification or AI visibility measurement; Target content is untrusted data and was not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
