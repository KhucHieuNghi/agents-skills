# NKSkills — Content Search Audit

Partial.

## Source age reference

Age reference: 2026\-11\-17T16:27:33\.202Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.


## Scope and coverage

Counts use unique owned content, not repeated placeholder rows\. Completion concerns audit coverage, not whether content is defect\-free\. Discovery completeness is a declared scope assertion\.

| Metric | Value |
| --- | --- |
| Campaign | 33a57e0d\-cb23\-42ec\-959f\-6fa7d0467b5f |
| Declared items | 8 |
| Owned/attempted | 8 |
| Collected | 0 |
| Audited | 0 |
| Inventory complete | false |
| Mode | full |
| Unresolved items | 8 |
| Missing checks | 0 |
| Pending queue | 9 |
| Global rules unresolved | portfolio\-task\-gaps, portfolio\-duplication, portfolio\-contradictions, portfolio\-journey\-links |
| pending | 0 |
| audited | 0 |
| failed | 8 |
| blocked | 0 |
| unsupported | 0 |
| excluded | 0 |

## Dimension coverage

Supplied checks only; missing checks are reported separately\. No combined SEO/GEO score is calculated\.

| Dimension | Supplied | Assessed pass/fail | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| quality | 40 | 1 | 39 | 0 |
| seo | 64 | 0 | 64 | 0 |
| aio | 24 | 0 | 24 | 0 |
| aeo | 24 | 0 | 24 | 0 |
| geo | 24 | 0 | 24 | 0 |
| portfolio | 32 | 0 | 32 | 0 |

## Global portfolio review

Attributed judgments remain subject to domain review\. Evidence hashes and valid references do not certify semantic truth or reviewer identity\.

| Rule | Status | Reason | Reviewer | Reviewed | Applicability reason |
| --- | --- | --- | --- | --- | --- |
| portfolio\-task\-gaps | unknown | The historical English page supports orientation and links to candidate evaluation, host setup and license reference\. The linked content and Vietnamese journey could not be inspected\. No evidence\-backed question set was supplied\. | Codex, NKSkills public pilot | 2026\-11\-17T16:27:33\.032Z |  |
| portfolio\-duplication | unknown | The root and /en/ share one historical representation through the captured 308\. No independent bodies are available to compare task overlap or to recommend consolidation\. | Codex, NKSkills public pilot | 2026\-11\-17T16:27:33\.032Z |  |
| portfolio\-contradictions | unknown | The English homepage has an attributed internal count conflict\. EN and VI starter variants in the English source retain the same version, prerequisites and host\-specific invocation\. The Vietnamese page, catalog and guides are unavailable, so cross\-page totals, compatibility and release caveats cannot be verified\. | Codex, NKSkills public pilot | 2026\-11\-17T16:27:33\.032Z |  |
| portfolio\-journey\-links | unknown | The English source links its catalog, workflow detail, both host guides and Vietnamese home\. Current destinations, anchors, locale reciprocity and script\-dependent paths remain unverified\. | Codex, NKSkills public pilot | 2026\-11\-17T16:27:33\.032Z |  |

## Priority backlog

Ordered by severity, then global findings and partition order\. Confidence is separate\. Each finding retains its scope; potentially overlapping findings are not silently merged\. Proposed actions are not executed\.

| Scope / finding | Severity | Confidence | Classification | Observation | Affected items | Recommendation | Action | Action origin | Action reason | Verification | Owner role | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| parts/000001 / homepage\-solution\-count | low | high | observed | English homepage status totals conflict with its solution cards | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | Confirm which Solution Skills belong in the public catalog\. Use the same eligibility and release status source for the English status strip and cards, or label any intentional subset explicitly\. Check the Vietnamese equivalent once it is available\. | update | default\-triage | No explicit action decision supplied; review the finding before implementation\. | Compare the current status strip with the numbered solution cards and approved catalog inventory\. Confirm the technical\-release and candidate subtotals match the displayed counting scope in each locale\. | NKSkills content owner | Small copy or data\-binding change after confirming the inventory | parts/000001:historical\-en\-home; parts/000001:home\-count\-comparison |

## Finding interpretation

1 local findings; 0 global findings\. Zero findings does not resolve unknown checks or demonstrate measured search visibility\.


## Evidence and partition reports

Evidence identifiers are scoped by partition\. Links resolve to the original validated snapshots; keep source campaign and receipt with this report when sharing\. Raw bodies are not embedded here\.

| Partition / evidence | Item | Kind | Captured | Age at report time | SHA\-256 | Artifact |
| --- | --- | --- | --- | --- | --- | --- |
| [parts/000001](../reviewed/parts/000001/report.md) |  | Partition report |  |  |  |  |
| parts/000001:3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7 | 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b | collection\-error | 2026\-11\-17T16:25:31\.216Z | 0 full elapsed days | bceb676ecd2fb99b09bf35c28a17a5509df069e4b82ea7d45bc26003bb82571d | [evidence/3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7\.json](../reviewed/parts/000001/evidence/3adea44050529a163d0e37714a46c8c070ca742c9817c4a402ca5e66d94fbed7.json) |
| parts/000001:a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330 | 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3 | collection\-error | 2026\-11\-17T16:25:31\.223Z | 0 full elapsed days | e84f76f5b7d9963f987e87e79079b3225c81ffc9b6d52d5eed2f67cde9d0a4ed | [evidence/a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330\.json](../reviewed/parts/000001/evidence/a45dbea1e4e2196e7c48628b6817febb7bf1b035a2ac1618d67c7c9d5b8ac330.json) |
| parts/000001:d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718 | 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a | collection\-error | 2026\-11\-17T16:25:31\.231Z | 0 full elapsed days | 0b8af49a37b6be2878991fa3941c7b3482bf139a09bd786c2866bf593de8c3ec | [evidence/d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718\.json](../reviewed/parts/000001/evidence/d010dd121ee5418f1e369b2bb626ee253a297890d8b165570b69c82000849718.json) |
| parts/000001:1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367 | 707e9d50d0662428e767ddc5be9eb05ac6aee8300cccf8038888be8d5845702a | collection\-error | 2026\-11\-17T16:25:31\.239Z | 0 full elapsed days | 56749164697c318985f90b31a6ac4a3698e60014cd7ca60e1a1d554238c4d420 | [evidence/1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367\.json](../reviewed/parts/000001/evidence/1eb8cdfbe2169812db2a196539fe17b3c3bd1165463c0afb2a0650d4429a1367.json) |
| parts/000001:dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448 | 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743 | collection\-error | 2026\-11\-17T16:25:31\.245Z | 0 full elapsed days | 46b8457f58b7aadf9ddbdd171baf1d8886dc218c1a74ae63564970c00b58ee25 | [evidence/dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448\.json](../reviewed/parts/000001/evidence/dad0c465bd64893c043d70e7db227ef5d1bacb18d58b8ab608db4980b3c8e448.json) |
| parts/000001:19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da | ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86 | collection\-error | 2026\-11\-17T16:25:31\.253Z | 0 full elapsed days | f86ab142df03e3289f7c1e3c4833a9f9958c943098cf13872f98478f543ecb52 | [evidence/19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da\.json](../reviewed/parts/000001/evidence/19e8ded8d54e0b3f4b0364b8c9ac618fc8a5f5b90a014291a18e1958d2a273da.json) |
| parts/000001:4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8 | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | collection\-error | 2026\-11\-17T16:25:31\.261Z | 0 full elapsed days | c7550c26fd4ea23738299b800ac2339b829ad12dc8959eb2ee554dc5de741b0c | [evidence/4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8\.json](../reviewed/parts/000001/evidence/4f035208ef5a29317ab94d7281387a2ee9fd457fed59332ed0c1d96d41923ce8.json) |
| parts/000001:776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe | f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26 | collection\-error | 2026\-11\-17T16:25:31\.268Z | 0 full elapsed days | d48ebe44570096657045beef49804e310d78840b29b55824b28aa613ef3608d8 | [evidence/776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe\.json](../reviewed/parts/000001/evidence/776be0f05967f0c12c1453da3c29dc9e40ddb5af2bc4991576c2266529cd67fe.json) |
| parts/000001:discovery\-origin | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | discovery\-provenance | 2026\-11\-17T16:27:05\.983Z | 0 full elapsed days | e66aca31593efbf4983d042accfe88b114d25109de6f4ede895d2dcab8f7880d | [evidence/discovery\-origin\.txt](../reviewed/parts/000001/evidence/discovery-origin.txt) |
| parts/000001:historical\-en\-home | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | content | 2026\-11\-17T16:24:34\.922Z | 0 full elapsed days | 4dc857c77c15cd31db9ef2884604320afb766f2737e1be6dead9e1c8aae6d265 | [evidence/historical\-en\-home\.txt](../reviewed/parts/000001/evidence/historical-en-home.txt) |
| parts/000001:owner\-audience\-context | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | audience\-context | 2026\-11\-17T16:27:05\.983Z | 0 full elapsed days | dd2d3059919276a3037e2b28ef6f63ff2222145181a30dd8dab422acbfa4456d | [evidence/owner\-audience\-context\.txt](../reviewed/parts/000001/evidence/owner-audience-context.txt) |
| parts/000001:home\-count\-comparison | ec35d79a30a568b44ab0c5771f0d3f2585359e6ac91eb3ef82e9217fa90cac14 | claim\-sources | 2026\-11\-17T16:27:05\.983Z | 0 full elapsed days | 6afdf4fc53ddaa3600a33a35ddd9de267faf6997159568ef95f0f0cded20700a | [evidence/home\-count\-comparison\.txt](../reviewed/parts/000001/evidence/home-count-comparison.txt) |

## Global context evidence

Context values and review source references are preserved in the linked receipt\. Validate its bound source before interpreting judgments\.

| Evidence | Kind | Locator | Collected | Age at report time | SHA\-256 | Receipt |
| --- | --- | --- | --- | --- | --- | --- |
| inventory\-map | inventory\-map | Validated reviewed\-index/items\.jsonl and historical English source | 2026\-11\-17T16:27:33\.032Z | 0 full elapsed days | 2b534dca64277b287fa94ef0310454889ec0f5bd517bad985eb4c191433a10cf | [review\.json](../global-review/review.json) |
| owner\-audience | audience\-context | User task statement | 2026\-11\-17T16:27:33\.032Z | 0 full elapsed days | dd2d3059919276a3037e2b28ef6f63ff2222145181a30dd8dab422acbfa4456d | [review\.json](../global-review/review.json) |
| home\-link\-graph | link\-graph | continued\-discovery/graph\.jsonl and source\.json; retained homepage only | 2026\-11\-17T16:27:33\.032Z | 0 full elapsed days | 824b32211159d0735541a6c3d8159f9cac5ea87297ebf979f307a44b8098a2db | [review\.json](../global-review/review.json) |

## Remaining work

Resolve these queues and unknown checks before claiming full coverage\. Empty queues alone do not resolve unknown checks\.

| Kind | Item | Reason |
| --- | --- | --- |
| discovery/source\-adapter\-queue | internal\-links | Dynamic/inert navigation surfaces require separate rendered inspection |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-adapter\-queue | internal\-links | getaddrinfo ENOTFOUND nkskills\.getgroove\.me |
| discovery/source\-incomplete | internal\-links | Supplied source is partial or pagination remains |
| discovery/scope\-unconfirmed |  | The expected source set is not declared exhaustive for the audit scope |

## Measurements and interpretation

No visibility metrics are inferred or pooled by this report\. Consult explicitly supplied, dated, surface\-specific measurements in the underlying evidence\. Readiness is not measured mentions, citations, ranking or revenue; missing observations are unknown, not zero\.


## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.


## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.


## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.


## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.


## Server\-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.


## Rule provenance

Sources and review dates belong to the validated packaged rule registry; they do not certify current search outcomes\.

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve missing local/global evidence, complete declared discovery, apply new immutable reviews and regenerate this report\. The current audit is partial\.

