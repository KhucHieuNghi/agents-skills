# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-17T16:25:11\.000Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 71006711\-6380\-44a5\-93c1\-2aac5398189e\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 3 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 2 | 13 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | pending | Snapshot review incomplete | 26 |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | image\-ocr\-text |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | export\-text |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 8d96e5a03f0573c762f3daff8124df3ddad83ae8344c50d049326a644adca39f | 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | local\-file | 2026\-11\-17T16:22:41\.742Z | 0 full elapsed days | [evidence/6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9\.txt](evidence/6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| export\-provenance | b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | Apple PDFKit | 2026\-11\-17T16:23:21\.697Z | 0 full elapsed days | [evidence/export\-provenance\.json](evidence/export-provenance.json) | 454eac8d890cf2ba5c07f491c92b11bf240535069cebde3a7f7b75250e2e64ac | Native page text visually checked against both Poppler 26\.05\.0 rasters\. No live platform behavior or accessibility conformance tested\. |
| export\-content | b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | Apple PDFKit | 2026\-11\-17T16:23:21\.697Z | 0 full elapsed days | [evidence/export\-content\.txt](evidence/export-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native page text visually checked against both Poppler 26\.05\.0 rasters\. No live platform behavior or accessibility conformance tested\. |
| export\-text | b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | Apple PDFKit | 2026\-11\-17T16:23:21\.697Z | 0 full elapsed days | [evidence/export\-text\.txt](evidence/export-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native page text visually checked against both Poppler 26\.05\.0 rasters\. No live platform behavior or accessibility conformance tested\. |
| image\-pdfkit\-attempt | 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | Apple PDFKit 1\.0 build 1451\.3\.3 | 2026\-11\-17T16:23:21\.697Z | 0 full elapsed days | [evidence/image\-pdfkit\-attempt\.json](evidence/image-pdfkit-attempt.json) | 16b101d3ec08f1612fde043e9055267d773b533099ab91404ab53945115e206e | Empty native extraction\. Raster confirms visible content\. This diagnostic is separate from the OCR extraction\. |
| image\-ocr\-provenance | 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | Tesseract English OCR on Poppler pdftoppm raster | 2026\-11\-17T16:23:24\.558Z | 0 full elapsed days | [evidence/image\-ocr\-provenance\.json](evidence/image-ocr-provenance.json) | f306537fb895a1e0d4e14989fc73592cf547a84ca389bd70920035b9f277b3c4 | Page rasterized at 180 dpi\. The one OCR sentence was visually checked against the raster\. The original PDF has no recovered native text and OCR does not provide it with a text layer\. |
| image\-ocr\-content | 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | Tesseract English OCR on Poppler pdftoppm raster | 2026\-11\-17T16:23:24\.558Z | 0 full elapsed days | [evidence/image\-ocr\-content\.txt](evidence/image-ocr-content.txt) | cc27bc317e0dbd1486c7b7aa21123b8ad3ae64403e9d75b92e205a1c071df9eb | Page rasterized at 180 dpi\. The one OCR sentence was visually checked against the raster\. The original PDF has no recovered native text and OCR does not provide it with a text layer\. |
| image\-ocr\-text | 184a2648c1c5f343cdac77154b4aebc21362039342dd08523536b4203993d114 | Tesseract English OCR on Poppler pdftoppm raster | 2026\-11\-17T16:23:24\.558Z | 0 full elapsed days | [evidence/image\-ocr\-text\.txt](evidence/image-ocr-text.txt) | cc27bc317e0dbd1486c7b7aa21123b8ad3ae64403e9d75b92e205a1c071df9eb | Page rasterized at 180 dpi\. The one OCR sentence was visually checked against the raster\. The original PDF has no recovered native text and OCR does not provide it with a text layer\. |
| chrome\-attempt | 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | Google Chrome headless, fresh local profile | 2026\-11\-17T16:24:07\.537Z | 0 full elapsed days | [evidence/chrome\-attempt\.txt](evidence/chrome-attempt.txt) | adb5308d8684a9fabdab42f1f2b197f7355533cfc84ec1d49e1d558bc489496b | Signal 6, no stdout or stderr\. No render\-ready capture\. |
| owner\-renewal\-task | 6a15b3723ce383dfd22bc1c01dee510ee07f26cef0030c1418af4cfc20c751f9 | User task statement | 2026\-11\-17T16:25:10\.837Z | 0 full elapsed days | [evidence/owner\-renewal\-task\.txt](evidence/owner-renewal-task.txt) | adab8c8eda241b2665790201c992f207ecc612eb795810a5dcfd27992acbcc06 | Owner\-approved fixture context\. |
| owner\-export\-policy | b44eaa55fe54fd4795d3f231132437a19e624646a5a355c9dc8d1c6884c16c48 | User task statement | 2026\-11\-17T16:25:10\.837Z | 0 full elapsed days | [evidence/owner\-export\-policy\.txt](evidence/owner-export-policy.txt) | f054ace0847583a114d71ba1df5ece1eabfe6a7631094cdd6286edc90522c545 | Approved scope for comparison during this audit\. No independent product verification\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 1 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
