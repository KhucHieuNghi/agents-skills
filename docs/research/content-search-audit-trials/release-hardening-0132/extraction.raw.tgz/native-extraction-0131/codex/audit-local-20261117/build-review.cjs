const fs = require("node:fs");
const {createHash} = require("node:crypto");
const root = "audit-local-20261117/";
const read = name => fs.readFileSync(root + name, "utf8");
const rows = name => read(name).trim().split("\n").map(JSON.parse);
const item = name => rows("initial/inventory.jsonl").find(row => row.path.endsWith("/" + name)).itemId;
const html = item("render.html");
const doc = item("document.pdf");
const image = item("image-only.pdf");
const raw = rows("initial/evidence.jsonl")[0].evidenceId;
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const now = new Date().toISOString();
const reviewer = "Codex local fixture review";
const bundle = () => ({artifacts: {}, evidence: [], reviews: []});
const recovery = {...bundle(), collectionRecoveries: []};
let out = recovery;
function evidence(itemId, evidenceId, kind, value, method, locator, limitations, sourceEvidenceIds = [], collectedAt = now) {
  const encoding = typeof value === "string" ? "utf8" : "json";
  const artifact = "evidence/" + evidenceId + (encoding === "json" ? ".json" : ".txt");
  const bytes = encoding === "json" ? JSON.stringify(value, null, 2) + "\n" : value;
  out.artifacts[artifact] = bytes;
  out.evidence.push({itemId, evidenceId, kind, value, method, locator, limitations, sourceEvidenceIds, collectedAt,
    artifact, encoding, snapshotHash: hash(bytes), redaction: "none; authorized fixture evidence"});
  return evidenceId;
}
function checkpoint(name) {
  fs.writeFileSync(root + name, JSON.stringify(out, null, 2) + "\n", {flag: "wx"});
}
function fileTime(name) { return fs.statSync(root + name).mtime.toISOString(); }
function recover(itemId, prefix, path, pages, extractor, limitations, collectedAt, sourceIds = []) {
  const original = fs.readFileSync(path);
  const manifestEvidenceId = evidence(itemId, prefix + "-provenance", "extraction-provenance",
    {schemaVersion: 1, sourceSha256: hash(original), sourceByteLength: original.length, extractor,
      pageCount: pages.length, pages, coverage: "complete", limitations},
    extractor.name, path + " pages 1–" + pages.length, limitations, sourceIds, collectedAt);
  const text = pages.map(page => page.text).join("\f");
  const locator = path + " pages 1–" + pages.length + " in order, form-feed separated";
  const contentEvidenceId = evidence(itemId, prefix + "-content", "content", text, extractor.name,
    locator, limitations, [manifestEvidenceId], collectedAt);
  const textEvidenceId = evidence(itemId, prefix + "-text", "extracted-text", text, extractor.name,
    locator, limitations, [contentEvidenceId], collectedAt);
  recovery.collectionRecoveries.push({itemId, manifestEvidenceId, contentEvidenceId, textEvidenceId,
    reviewer, reviewedAt: now, reason: "Every page was processed and its text and order were compared with local page rasters."});
  return contentEvidenceId;
}
const [nativeDoc, nativeImage] = rows("pdfkit.jsonl");
const docText = recover(doc, "export", nativeDoc.path, nativeDoc.pages, {name: "Apple PDFKit", version: "1.0 (build 1451.3.3, macOS 26.3)"},
  ["Native page text visually checked against both Poppler 26.05.0 rasters. No live platform behavior or accessibility conformance tested."], fileTime("pdfkit.jsonl"));
const empty = evidence(image, "image-pdfkit-attempt", "extraction-diagnostic", nativeImage, "Apple PDFKit 1.0 build 1451.3.3",
  "targets/image-only.pdf p. 1", ["Empty native extraction. Raster confirms visible content. This diagnostic is separate from the OCR extraction."], [], fileTime("pdfkit.jsonl"));
const imageText = recover(image, "image-ocr", nativeImage.path, [{page: 1, text: read("image-ocr.txt")}],
  {name: "Tesseract English OCR on Poppler pdftoppm raster", version: "Tesseract 5.5.1 / Poppler 26.05.0"},
  ["Page rasterized at 180 dpi. The one OCR sentence was visually checked against the raster. The original PDF has no recovered native text and OCR does not provide it with a text layer."],
  fileTime("image-ocr.txt"), [empty]);
const browser = evidence(html, "chrome-attempt", "render-attempt", read("browser-attempt.txt"),
  "Google Chrome headless, fresh local profile", "targets/render.html, file URL",
  ["Signal 6, no stdout or stderr. No render-ready capture."], [raw], fileTime("browser-attempt.txt"));
const renewal = "Approved renewal task requires opening Billing and selecting Disable renewal. The owner confirms that document.documentElement.dataset.auditReady === \"true\" means the content has finished rendering.";
const audience = evidence(html, "owner-renewal-task", "audience-context", renewal, "User task statement",
  "Audit request, approved renewal task and readiness contract", ["Owner-approved fixture context."], [raw]);
const policy = "Approved export policy: current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.";
const ownerPolicy = evidence(doc, "owner-export-policy", "claim-sources", policy, "User task statement",
  "Audit request, approved export policy and language scope", ["Approved scope for comparison during this audit. No independent product verification."], [docText]);
checkpoint("recovery.json");
out = {...bundle(), findings: []};
function review(itemId, ruleId, status, reason, evidenceIds) {
  out.reviews.push({itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now});
}
function finding(findingId, title, itemId, ruleId, dimension, evidenceIds, classification, severity, remediation, verification) {
  out.findings.push({findingId, title, affectedItemIds: [itemId], ruleIds: [ruleId], dimensions: [dimension],
    evidenceIds, classification, severity, confidence: "high", remediation, verification, ownerRole: "Fixture content owner", effort: "small"});
}
const renderReason = "The original main contains both steps. Source inspection shows that the callback writes only the first step before setting the owner-defined readiness marker. The Chrome attempt aborted before a DOM was obtained.";
review(html, "seo-rendering", "unknown", renderReason, [raw, browser, audience]);
review(html, "quality-task-fit", "unknown", renderReason + " Final user-facing task completeness remains unobserved.", [raw, browser, audience]);
review(html, "aio-retrievable-facts", "unknown", "Both renewal instructions are present as initial HTML. Their availability in the completed DOM remains unobserved.", [raw, browser, audience]);
finding("renewal-source-overwrites-step", "Renewal callback drops the final instruction in source", html,
  "seo-rendering", "seo", [raw, browser, audience], "inferred", "medium",
  "Keep both required instructions in the final task content when the readiness marker is set.",
  "Reopen revised source, then capture the main text in a fresh authorized browser profile after document.documentElement.dataset.auditReady === \"true\" and verify both required steps in order.");
const claimReason = "The English page states the per-export cap and current VN scope. The Vietnamese page repeats the same cap and adds the absence of a surcharge. Both pages agree with the owner-approved current VN policy. Complementary language emphasis is approved.";
review(doc, "quality-claims", "pass", claimReason, [docText, ownerPolicy]);
review(doc, "quality-freshness", "pass", "Within the approved current VN fixture scope, the two pages agree with the current policy supplied for the audit. The English page already names the plan scope and the Vietnamese page supplies the approved fee detail.", [docText, ownerPolicy]);
review(doc, "aeo-answer-evidence", "pass", claimReason, [docText, ownerPolicy]);
const docContext = evidence(doc, "export-task-context", "audience-context",
  "The two pages address readers checking export terms on current VN plans. This task is inferred from the export headings and policy sentences, bounded by the owner-approved policy and language instructions.",
  "Local editorial review of both pages and the user task statement", "targets/document.pdf pp. 1–2",
  ["Audience task is inferred. No customer-demand data was supplied."], [docText, ownerPolicy]);
review(doc, "quality-task-fit", "pass", "Together the short English and Vietnamese sections state the applicable scope, cap and price condition for the inferred export policy lookup task. The owner permits complementary locale emphasis.", [docText, docContext]);
review(doc, "aio-retrievable-facts", "pass", "Native text preserves headings, the cap in both languages, the current VN scope on p. 1 and the fee condition on p. 2. This is local text readiness.", [docText, docContext]);
const media = evidence(image, "image-media-inventory", "media-inventory",
  {page: 1, structure: read("image-structure.txt"), tagObject: read("image-tag-object.txt"),
    comparison: "Only one visible sentence, carried by the image. Poppler shows one Figure with empty structure text. Its PDF structure element (12 0 obj) has neither Alt nor ActualText. PDFKit yielded empty native text. OCR matched the visible sentence."},
  "Visual raster inspection, Poppler pdfinfo 26.05.0 structure output, PDF object inspection, PDFKit and OCR comparison",
  "targets/image-only.pdf p. 1, tagged Figure object 12 0",
  ["No end-to-end assistive technology test. External audit OCR is a derivative."], [imageText, empty]);
review(image, "quality-accessible-media", "fail", "The only informative image contains the entire sentence and the source provides no equivalent in the Figure tag or native page text.", [imageText, media, empty]);
finding("image-missing-text-equivalent", "Image-only PDF lacks a text equivalent for its sentence", image,
  "quality-accessible-media", "quality", [imageText, media, empty], "observed", "medium",
  "Publish the sentence as selectable tagged text or add an equivalent accessible text alternative to the tagged Figure.",
  "Reinspect the revised PDF structure and page. Confirm that the complete visible sentence is exposed in the accessible reading order and matches the image.");
checkpoint("semantic-review.json");
