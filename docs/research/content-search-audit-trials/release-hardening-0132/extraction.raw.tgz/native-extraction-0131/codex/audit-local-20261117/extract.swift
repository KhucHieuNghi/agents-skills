import Foundation
import PDFKit
for path in CommandLine.arguments.dropFirst() {
    guard let pdf = PDFDocument(url: URL(fileURLWithPath: path)) else {
        FileHandle.standardError.write(Data("Cannot open \(path)\n".utf8))
        exit(1)
    }
    let pages = (0..<pdf.pageCount).map { index in
        ["page": index + 1, "text": pdf.page(at: index)?.string ?? ""] as [String: Any]
    }
    let record: [String: Any] = ["path": path, "pageCount": pdf.pageCount, "pages": pages]
    print(String(decoding: try JSONSerialization.data(withJSONObject: record), as: UTF8.self))
}
