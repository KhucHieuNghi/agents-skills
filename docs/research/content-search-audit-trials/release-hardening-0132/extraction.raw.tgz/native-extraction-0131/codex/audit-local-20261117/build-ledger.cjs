const fs = require("node:fs");
const crypto = require("node:crypto");
const root = process.cwd();
const dir = "audit-local-20261117/";
const report = dir + "audit-narrative.md";
const read = path => fs.readFileSync(path, "utf8");
const hash = path => crypto.createHash("sha256").update(fs.readFileSync(path)).digest("hex");
const definitions = [
  ["renewal-initial", "targets/render.html", "render.html", 1, 1, "Open Billing. Select Disable renewal."],
  ["english-export", dir + "reviewed/evidence/export-content.txt", "export-content.txt", 2, 3, "A single export contains at most 5000 records. Applies to current VN plans."],
  ["vietnamese-export", dir + "reviewed/evidence/export-content.txt", "export-content.txt", 4, 5, "Mỗi lần xuất tối đa 5000 bản ghi. Không cần thanh toán thêm."],
  ["image-sentence", dir + "reviewed/evidence/image-ocr-content.txt", "image-ocr-content.txt", 1, 1, "Image-only document: a separate OCR capability is needed."]
];
const lines = read(report).split("\n");
const quotes = definitions.map(([quoteId, source, sourceLabel, startLine, endLine, quote]) => {
  const line = lines.findIndex(entry => entry.includes(quote)) + 1;
  return {quoteId, source, sourceLabel, sourceHash: hash(source), startLine, endLine,
    reportStartLine: line, reportEndLine: line, normalization: "whitespace", quote};
});
fs.writeFileSync(dir + "quotes.json", JSON.stringify({root, report, reportHash: hash(report), quotes}, null, 2) + "\n", {flag: "wx"});
