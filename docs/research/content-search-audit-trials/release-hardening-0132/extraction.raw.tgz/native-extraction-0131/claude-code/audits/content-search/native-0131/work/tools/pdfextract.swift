import Foundation
import PDFKit
// Read-only PDFKit text-layer extraction. No OCR. Prints JSON.
let path = CommandLine.arguments[1]
let url = URL(fileURLWithPath: path)
guard let data = try? Data(contentsOf: url) else { FileHandle.standardError.write("read-failed\n".data(using: .utf8)!); exit(2) }
guard let doc = PDFDocument(data: data) else { FileHandle.standardError.write("pdfkit-open-failed\n".data(using: .utf8)!); exit(3) }
var pages: [[String: Any]] = []
for i in 0..<doc.pageCount {
  let page = doc.page(at: i)
  let text = page?.string
  let b = page?.bounds(for: .mediaBox) ?? .zero
  var annots = 0
  if let p = page { annots = p.annotations.count }
  pages.append(["page": i + 1, "text": text ?? NSNull(), "textIsNil": text == nil, "utf16Length": (text ?? "").utf16.count, "mediaBox": [b.origin.x, b.origin.y, b.size.width, b.size.height], "annotations": annots])
}
let os = ProcessInfo.processInfo.operatingSystemVersionString
let pk = Bundle(for: PDFDocument.self).infoDictionary
let out: [String: Any] = [
  "byteLength": data.count, "pageCount": doc.pageCount, "isEncrypted": doc.isEncrypted, "isLocked": doc.isLocked,
  "allowsCopying": doc.allowsCopying,
  "documentAttributes": (doc.documentAttributes ?? [:]).reduce(into: [String: String]()) { $0["\($1.key)"] = "\($1.value)" },
  "pdfkitBundleVersion": pk?["CFBundleVersion"] as? String ?? "unknown",
  "pdfkitShortVersion": pk?["CFBundleShortVersionString"] as? String ?? "unknown",
  "os": os, "pages": pages]
let j = try! JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(j)
