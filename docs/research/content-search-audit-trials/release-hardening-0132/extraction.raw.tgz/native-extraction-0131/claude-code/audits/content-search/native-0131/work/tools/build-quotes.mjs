import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [root, out] = process.argv.slice(2);
const h = (f) => createHash("sha256").update(readFileSync(path.join(root, f))).digest("hex");
const report = "audits/content-search/native-0131/audit-narrative.md";
const R = "audits/content-search/native-0131/run-reviewed-r2/evidence/";
const lines = readFileSync(path.join(root, report), "utf8").split("\n");
const q = [
  ["F1-raw-main", "targets/render.html", "render.html", 1, `<main id="task">Open Billing. Select Disable renewal.</main>`],
  ["F1-script", "targets/render.html", "render.html", 1, `document.getElementById('task').textContent = 'Open Billing.'; document.documentElement.dataset.auditReady = 'true';`],
  ["F1-ready", R + "render-rendered-dom.txt", "render-rendered-dom.txt", 2, `<html lang="en" data-audit-ready="true">`],
  ["F1-rendered-main", R + "render-rendered-dom.txt", "render-rendered-dom.txt", 2, `<main id="task">Open Billing.</main>`],
  ["F2-ocr", R + "image-only-ocr-content.txt", "image-only-ocr-content.txt", 1, `Image-only document: a separate OCR capability is needed.`],
  ["C1-en-limit", R + "document-recovered-content.txt", "document-recovered-content.txt", 2, `A single export contains at most 5000 records.`],
  ["C1-en-scope", R + "document-recovered-content.txt", "document-recovered-content.txt", 3, `Applies to current VN plans.`],
  ["C1-vi-limit", R + "document-recovered-content.txt", "document-recovered-content.txt", 4, `Mỗi lần xuất tối đa 5000 bản ghi.`],
  ["C1-vi-charge", R + "document-recovered-content.txt", "document-recovered-content.txt", 5, `Không cần thanh toán thêm.`],
];
const quotes = q.map(([quoteId, source, sourceLabel, line, quote]) => {
  const loc = `${sourceLabel}:${line} — \`${quote}\``;
  const idx = lines.findIndex((l) => l.includes(loc));
  if (idx < 0) throw new Error("report line not found: " + quoteId);
  return { quoteId, source, sourceLabel, sourceHash: h(source), startLine: line, endLine: line, reportStartLine: idx + 1, reportEndLine: idx + 1, normalization: "exact", quote };
});
writeFileSync(out, JSON.stringify({ root, report, reportHash: h(report), quotes }, null, 2) + "\n");
