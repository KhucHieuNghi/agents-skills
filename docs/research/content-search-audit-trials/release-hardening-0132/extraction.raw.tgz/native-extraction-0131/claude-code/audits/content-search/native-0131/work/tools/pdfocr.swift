import Foundation
import PDFKit
import Vision
import AppKit
// Renders each PDF page to a bitmap (PDFKit) and runs on-device Vision OCR. Read-only on the source.
let path = CommandLine.arguments[1]
let outPrefix = CommandLine.arguments[2]
let langs = CommandLine.arguments.count > 3 ? CommandLine.arguments[3].split(separator: ",").map(String.init) : ["en-US"]
guard let doc = PDFDocument(url: URL(fileURLWithPath: path)) else { exit(3) }
var pages: [[String: Any]] = []
for i in 0..<doc.pageCount {
  guard let page = doc.page(at: i) else { continue }
  let b = page.bounds(for: .mediaBox)
  let scale: CGFloat = 3
  let w = Int(b.width * scale), h = Int(b.height * scale)
  let cs = CGColorSpaceCreateDeviceRGB()
  let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
  ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1)); ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
  ctx.scaleBy(x: scale, y: scale)
  page.draw(with: .mediaBox, to: ctx)
  let img = ctx.makeImage()!
  let rep = NSBitmapImageRep(cgImage: img)
  try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: "\(outPrefix)-p\(i+1).png"))
  let req = VNRecognizeTextRequest()
  req.recognitionLevel = .accurate
  req.usesLanguageCorrection = true
  req.recognitionLanguages = langs
  var err = ""
  do { try VNImageRequestHandler(cgImage: img, options: [:]).perform([req]) } catch { err = "\(error)" }
  var lines: [[String: Any]] = []
  for o in (req.results ?? []) {
    if let c = o.topCandidates(1).first {
      let bb = o.boundingBox
      lines.append(["text": c.string, "confidence": c.confidence, "box": [bb.origin.x, bb.origin.y, bb.size.width, bb.size.height]])
    }
  }
  pages.append(["page": i+1, "pixelSize": [w, h], "lines": lines, "error": err, "revision": req.revision])
}
let out: [String: Any] = ["languages": langs, "pages": pages, "os": ProcessInfo.processInfo.operatingSystemVersionString,
  "visionBundleVersion": Bundle(for: VNRecognizeTextRequest.self).infoDictionary?["CFBundleVersion"] as? String ?? "unknown"]
FileHandle.standardOutput.write(try! JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys]))
