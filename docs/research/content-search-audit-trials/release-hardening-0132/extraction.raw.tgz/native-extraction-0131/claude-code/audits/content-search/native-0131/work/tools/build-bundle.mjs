// Builds review bundles from captured work artifacts. Usage: node build-bundle.mjs STAGE WORKDIR PROJECT OUT.json
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, statSync } from "node:fs";
import path from "node:path";
const [stage, W, P, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const now = new Date().toISOString();
const mtime = (f) => statSync(f).mtime.toISOString();
const reviewer = "Claude Fable 5.2 (claude-fable-5-2), host agent for content-search-audit";
const HTML = "8a1d2f435430906ab011a2152e6cf227cb1e1f03ababd00659a8a454a7c7fbe0";
const DOC = "b69bd53fc5052578e3d375aee559216e5a4a828cd7042bc8278356e1e7bc4c64";
const IMG = "0a4ab62f41e0036c28d3d56a35ddf6156098fd7d64c637780ec6dc688ea65e7b";
const HTML_CONTENT = "a054fadc5aa7c4f1b058539e0b2739559fb4258cceaeb69bae1c6d82619006da";
const artifacts = {}, evidence = [];
function ev(evidenceId, itemId, kind, method, collectedAt, locator, value, limitations, sourceEvidenceIds, encoding = "utf8") {
  const artifact = `evidence/${evidenceId}.${encoding === "json" ? "json" : "txt"}`;
  const bytes = encoding === "json" ? JSON.stringify(value, null, 2) + "\n" : value;
  artifacts[artifact] = bytes;
  evidence.push({ evidenceId, itemId, kind, method, collectedAt, locator, snapshotHash: hash(bytes), byteLength: Buffer.byteLength(bytes),
    redaction: "none; authorized controlled fixture content retained locally", limitations, sourceEvidenceIds, artifact, encoding, value });
  return evidenceId;
}
const rv = (itemId, ruleId, status, reason, evidenceIds) => ({ itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
const ownerLimits = ["Owner/task statement supplied with the audit request; an approved comparison basis, not independent verification of platform behaviour or a public source", "No effective date was supplied; 'current' is as stated by the owner at request time"];
const bundle = { reviews: [], evidence, artifacts, findings: [], collectionRecoveries: [] };
const pdfkit = (name) => JSON.parse(readFileSync(path.join(W, "pdf", `${name}.pdfkit.json`), "utf8"));
const extractorVersion = (j) => `PDFKit.framework CFBundleVersion ${j.pdfkitBundleVersion} on macOS ${j.os}`;

if (stage === "1") {
  // ---------- render.html ----------
  const domFile = path.join(W, "browser/rendered-dom.html");
  const dom = readFileSync(domFile, "utf8");
  const chrome = readFileSync(path.join(W, "browser/chrome-version.txt"), "utf8").trim();
  const DOMID = ev("render-rendered-dom", HTML, "rendered-dom", "authorized-local-headless-chrome-dump-dom", mtime(domFile),
    "file:// load of targets/render.html; serialized document after virtual time budget", dom,
    [`${chrome}, --headless=new, fresh empty --user-data-dir, extensions/background networking/component update/sync disabled, browser sandbox left enabled, --virtual-time-budget=5000 --dump-dom`,
     "Readiness was not polled interactively; the serialized DOM itself carries data-audit-ready=\"true\" on the html element, which is the owner-confirmed render-ready signal (dataset values are strings)",
     "Single local capture in one browser build; not evidence of any search-engine or AI crawler rendering, indexing or eligibility",
     "Serialized DOM, not a screenshot; visual presentation was not assessed"], [HTML_CONTENT]);
  const task = "Owner/task statement (audit request, 2026-11-17): \"Approved renewal task requires opening Billing and selecting Disable renewal.\" Readiness contract (same request): \"The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering.\"";
  const AUD = ev("render-owner-renewal-task", HTML, "audience-context", "owner-statement-in-audit-request", now, "audit request text: approved renewal task and readiness contract", task,
    [...ownerLimits, "States the intended user task only; no audience segment, market or language was supplied"], []);
  const txt = "Open Billing.";
  const TXT = ev("render-rendered-main-text", HTML, "extracted-text", "host-derived text content of body (script element excluded) from the captured rendered DOM", now,
    "render-rendered-dom: <main id=\"task\"> text content at ready state", txt,
    ["Derived by the host from the serialized rendered DOM, not by a browser innerText call", "Represents the ready-state rendered surface only; the raw source <main> text differs ('Open Billing. Select Disable renewal.')", "Nonempty text does not establish completeness or quality", "The <title> text 'Controlled render fixture' is head metadata and is not included"], [DOMID]);
  const mediaH = { schemaVersion: 1, surfacesInspected: ["raw HTML source (content snapshot)", "rendered DOM at ready state"], mediaElements: { img: 0, picture: 0, svg: 0, video: 0, audio: 0, canvas: 0, object: 0, embed: 0, iframe: 0 }, cssBackgroundImages: 0, note: "The document contains only html, head, meta, title, body, main and script elements on both surfaces; CSP default-src 'none' also permits no image loads." };
  const MEDH = ev("render-media-inventory", HTML, "media-inventory", "host inspection of raw source and rendered DOM element inventory", now, "targets/render.html:1 and render-rendered-dom", mediaH,
    ["Element inventory by reading the two captured surfaces; no visual screenshot comparison"], [HTML_CONTENT, DOMID], "json");
  bundle.reviews.push(
    rv(HTML, "quality-task-fit", "fail", "The owner-approved task has two steps: open Billing, then select Disable renewal. The raw source <main> states both ('Open Billing. Select Disable renewal.'), but the inline script replaces the <main> text with 'Open Billing.' before setting the ready signal. In the authorized Chrome capture, with data-audit-ready=\"true\" present, <main> contains only 'Open Billing.'; the 'Select Disable renewal' step is absent, so a reader of the rendered page cannot complete the approved task from it. Scope: the item has one content component (<main id=\"task\">); the <title> does not carry the task.", [HTML_CONTENT, AUD, DOMID]),
    rv(HTML, "seo-rendering", "fail", "Raw source and rendered DOM differ materially in main content: raw <main> = 'Open Billing. Select Disable renewal.'; rendered <main> at the owner-defined ready state = 'Open Billing.'. Script execution removes a task step instead of preserving or adding content. Observed in local headless Chrome 157 only; how any search engine renders or indexes this page is unknown and no such evidence was supplied.", [HTML_CONTENT, DOMID]),
    rv(HTML, "quality-accessible-media", "not-applicable", "Neither the raw source nor the rendered DOM contains any image, video, audio, canvas, SVG, embedded object or CSS background image, so there is no informative media requiring a text alternative anywhere in the item.", [HTML_CONTENT, MEDH, DOMID]),
    rv(HTML, "aio-retrievable-facts", "unknown", "The raw source contains both approved task steps while the rendered DOM contains only the first. Which surface a retrieval system would read is not established: no crawler, engine-rendering or AI observation evidence was supplied. The rendered-surface loss is recorded once under quality-task-fit/seo-rendering rather than double-counted here.", [HTML_CONTENT, AUD, DOMID]),
    rv(HTML, "seo-metadata", "unknown", "Observation only: the <title> is 'Controlled render fixture', there is no meta description and no heading, and the title does not name the renewal task. Whether this fixture label is the intended title is not established by the supplied task statement, and no audience/search-intent context beyond the task was supplied, so no defect is asserted.", [HTML_CONTENT, AUD, DOMID]),
    rv(HTML, "quality-claims", "unknown", "The page contains instructions rather than independently checkable factual claims; the only supplied basis is the approved task, which is applied under quality-task-fit. No claim source about the actual product UI (that Billing contains a 'Disable renewal' control) was supplied, so the instructions' factual accuracy is unverified, not false.", [HTML_CONTENT, AUD]),
  );
  bundle.findings.push({
    findingId: "render-ready-state-drops-disable-renewal-step",
    title: "render.html: ready-state rendered page omits the approved 'Select Disable renewal' step",
    affectedItemIds: [HTML], ruleIds: ["quality-task-fit", "seo-rendering"], dimensions: ["quality", "seo"],
    evidenceIds: [HTML_CONTENT, AUD, DOMID], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal for the content/front-end owner (not executed by this audit): change the inline script in targets/render.html so the <main id=\"task\"> content at the ready state retains both approved steps, i.e. it must not overwrite 'Open Billing. Select Disable renewal.' with 'Open Billing.' before setting data-audit-ready.",
    verification: "Reload the revised file in a fresh isolated browser profile, wait until document.documentElement.dataset.auditReady === 'true' (string comparison), then confirm the text of <main id=\"task\"> instructs the reader both to open Billing and to select Disable renewal, and that raw-source and rendered main text no longer differ in task steps. This verifies local browser rendering only, not search-engine rendering or indexing.",
    ownerRole: "Content owner with front-end developer", effort: "small",
    action: "update", actionReason: "Observed loss of an owner-approved task step on the rendered surface; a small script/content correction restores it.",
  });

  // ---------- document.pdf ----------
  const j = pdfkit("document");
  const pages = j.pages.map((p) => ({ page: p.page, text: p.text }));
  const joined = pages.map((p) => p.text).join("\f");
  const t = mtime(path.join(W, "pdf/document.pdfkit.json"));
  const manifest = { schemaVersion: 1, sourceSha256: hash(readFileSync(path.join(P, "targets/document.pdf"))), sourceByteLength: j.byteLength,
    extractor: { name: "Apple PDFKit PDFPage.string (native text layer, no OCR) via macOS Swift", version: extractorVersion(j) },
    pageCount: j.pageCount, pages, coverage: "complete",
    limitations: ["Native text-layer extraction; reading order as returned by PDFKit, not independently certified", "No OCR was used for this extraction; text was cross-checked by the host against a PDFKit page render and an Apple Vision OCR pass (work/ocr/document.vision.json), which returned the same six lines", "PDF metadata as reported by PDFKit: Title 'document.html', Producer 'Skia/PDF m157', created 2026-11-16 01:47:42 +0000; unencrypted; 0 annotations", "Manifest assertions are host-attributed evidence, not independent verification of page count, completeness or text fidelity"] };
  const MAN = ev("document-extraction-manifest", DOC, "extraction-provenance", "macos-swift-pdfkit-text-layer", t, "targets/document.pdf pages 1-2", manifest, manifest.limitations, [], "json");
  const CON = ev("document-recovered-content", DOC, "content", "macos-swift-pdfkit-text-layer", t, "targets/document.pdf pages 1-2 (form feed separates pages)", joined,
    ["Recovered text layer, not the original PDF bytes; layout, fonts and visual emphasis are not represented", "Local file; no HTTP response, public reachability or index status"], [MAN]);
  const TX = ev("document-extracted-text", DOC, "extracted-text", "macos-swift-pdfkit-text-layer", t, "targets/document.pdf pages 1-2 (form feed separates pages)", joined,
    ["Identical to the recovered content snapshot; native text layer, no OCR", "Nonempty text does not establish quality or completeness"], [CON]);
  const policy = "Owner/task statement (audit request, 2026-11-17): \"Approved export policy: current VN plans support at most 5000 records per export, with no extra charge.\" Owner scope note (same request): \"English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.\"";
  const POL = ev("document-owner-export-policy", DOC, "claim-sources", "owner-statement-in-audit-request", now, "audit request text: approved export policy and translation scope note", policy, ownerLimits, []);
  const mediaD = { schemaVersion: 1, method: "raw PDF object scan plus PDFKit page render review", imageXObjects: 0, fontsReferenced: true, textShowingOperators: { page1: 5, page2: 3 }, annotations: 0, figureStructureElements: 0, note: "Both pages consist of text drawn with embedded fonts; no image XObject or Figure structure element is present." };
  const MEDD = ev("document-media-inventory", DOC, "media-inventory", "host byte-level PDF object scan and PDFKit render inspection", now, "targets/document.pdf objects and content streams", mediaD,
    ["Marker scan of PDF objects and Flate-decoded streams by the host; not a full PDF/UA conformance check"], [CON], "json");
  bundle.collectionRecoveries.push({ itemId: DOC, manifestEvidenceId: MAN, contentEvidenceId: CON, textEvidenceId: TX, reviewer, reviewedAt: now,
    reason: "Both declared pages (2 of 2) returned nonempty native text through PDFKit; page 1 English (3 lines), page 2 Vietnamese (3 lines). Source SHA-256 and byte length bound to the original targets/document.pdf. Text layer only, no OCR; reading order not certified; host cross-check against rendered pages found no additional visible text." });
  bundle.reviews.push(
    rv(DOC, "quality-claims", "pass", "All material claims on both pages match the owner-approved policy. Page 1 (English): 'A single export contains at most 5000 records.' and 'Applies to current VN plans.' match 'current VN plans support at most 5000 records per export'. Page 2 (Vietnamese): 'Mỗi lần xuất tối đa 5000 bản ghi.' (each export at most 5000 records) and 'Không cần thanh toán thêm.' (no additional payment needed) match the 5000 limit and 'no extra charge'. The English page omits the charge statement and the Vietnamese page omits the plan scope; the owner states the language pages may emphasise different aspects and translation completeness is not required, so these are not defects. Support is the owner's approved policy, not an independently verified source.", [CON, POL]),
    rv(DOC, "quality-freshness", "pass", "The version/market qualifier in the content ('Applies to current VN plans.', page 1) matches the approved policy's scope (current VN plans), supplied by the owner with this request. Neither page states a superseded limit, date or plan version. Caveats: the PDF and the policy carry no effective date, and the Vietnamese page does not restate plan scope (not required by the owner).", [CON, POL]),
    rv(DOC, "quality-accessible-media", "not-applicable", "The PDF contains no image XObjects or figure elements on either page; both pages are text drawn with embedded fonts and are fully represented in the text layer, so no informative media requires a text alternative.", [CON, MEDD]),
    rv(DOC, "aeo-answer-evidence", "unknown", "The page's claims are supported by the approved policy (see quality-claims), but no customer question or answer task for this document was supplied, so whether these passages are 'answer claims' under AEO is unresolved; no question is invented.", [CON, POL]),
    rv(DOC, "seo-locales", "unknown", "The single PDF holds an English page and a Vietnamese page. No locale map, hreflang/HTTP header evidence or intended locale targeting was supplied, and the inventory locale is 'unknown', so locale relationships cannot be assessed. Different emphasis between the two language pages is owner-accepted.", [CON]),
  );
} else if (stage === "2") {
  // ---------- image-only.pdf: OCR-attributed recovery ----------
  const j = pdfkit("image-only");
  const ocrFile = path.join(W, "ocr/image-only.vision.json");
  const o = JSON.parse(readFileSync(ocrFile, "utf8"));
  const pages = o.pages.map((p) => ({ page: p.page, text: p.lines.map((l) => l.text).join("\n") }));
  const joined = pages.map((p) => p.text).join("\f");
  const t = mtime(ocrFile);
  const lim = ["OCR output, not native PDF text: PDFKit PDFPage.string returned nil for the only page (no text layer, no fonts in the file)", "Recognised from a 3x PDFKit raster of the page (1836x2376 px) with VNRecognizeTextRequest, accurate level, language en-US, language correction on; one line recognised with reported confidence 1.0", "OCR can misread or miss characters; the host compared the single recognised line with the rendered page image (work/ocr/image-only-p1.png) and saw no other visible text", "Manifest assertions are host-attributed evidence, not independent verification of page count, completeness or text fidelity"];
  const manifest = { schemaVersion: 1, sourceSha256: hash(readFileSync(path.join(P, "targets/image-only.pdf"))), sourceByteLength: j.byteLength,
    extractor: { name: "Apple Vision VNRecognizeTextRequest OCR over a PDFKit page raster, via macOS Swift", version: `Vision.framework CFBundleVersion ${o.visionBundleVersion}, request revision ${o.pages[0].revision}; ${extractorVersion(j)}` },
    pageCount: j.pageCount, pages, coverage: "complete", limitations: lim };
  const MAN = ev("image-only-ocr-manifest", IMG, "extraction-provenance", "macos-swift-vision-ocr-of-pdfkit-raster", t, "targets/image-only.pdf page 1", manifest, lim, [], "json");
  const CON = ev("image-only-ocr-content", IMG, "content", "macos-swift-vision-ocr-of-pdfkit-raster", t, "targets/image-only.pdf page 1", joined,
    ["OCR-derived text, not the original PDF bytes and not a native text layer", "Local file; no HTTP response, public reachability or index status"], [MAN]);
  const TX = ev("image-only-ocr-text", IMG, "extracted-text", "macos-swift-vision-ocr-of-pdfkit-raster", t, "targets/image-only.pdf page 1", joined,
    ["OCR-derived; a nonempty result here does not mean the PDF exposes machine-readable text: native PDFKit extraction returned no text", "Nonempty text does not establish quality or completeness"], [CON]);
  const media = { schemaVersion: 1, method: "PDFKit native extraction, raw PDF object scan and PDFKit render review", pageCount: 1, nativeTextLayer: { pdfkitPageStringIsNil: true, fontsReferenced: false, textShowingOperators: 0 },
    media: [{ page: 1, type: "image XObject painted on the page (one 'Do' operator; second image object is its soft mask)", informative: true, visibleContent: "one line of rendered text (see OCR content)", structureTag: "/Figure present", altEntries: 0, actualTextEntries: 0 }],
    note: "The page's only content is a bitmap of text. The file is tagged (/StructTreeRoot, /MarkInfo, /Lang present) but the Figure carries no /Alt or /ActualText, and there is no text layer." };
  const MED = ev("image-only-media-inventory", IMG, "media-inventory", "host byte-level PDF object scan, PDFKit native extraction and render inspection", now, "targets/image-only.pdf objects and content stream", media,
    ["Marker scan of PDF objects and Flate-decoded streams by the host; not a full PDF/UA conformance check", "No assistive technology or search-engine/AI ingestion was tested"], [CON], "json");
  bundle.collectionRecoveries.push({ itemId: IMG, manifestEvidenceId: MAN, contentEvidenceId: CON, textEvidenceId: TX, reviewer, reviewedAt: now,
    reason: "Native PDFKit extraction returned no text for the single page, so the item stayed unsupported in revision 1. This recovery is OCR-attributed: Apple Vision recognised one line on the only page (1 of 1 pages, nonempty), which the host confirmed against the rendered page image. Source SHA-256 and byte length bound to the original targets/image-only.pdf. OCR text is not a native text layer and its fidelity is not certified." });
  bundle.reviews.push(
    rv(IMG, "quality-accessible-media", "fail", "The item's only content is an informative image: a bitmap showing one line of text. The PDF has no text layer (PDFKit returns no page text; no fonts or text operators in the file) and the tagged Figure has no /Alt or /ActualText entry, so no text alternative exists for the informative image. The text became readable only through OCR. Scope: single page, single image; nothing else on the page.", [CON, MED]),
  );
  delete bundle.findings; // set below with full replacement list
  const prev = JSON.parse(readFileSync(process.argv[6], "utf8"));
  bundle.findings = [...prev, {
    findingId: "image-only-pdf-no-text-alternative",
    title: "image-only.pdf: text exists only as a bitmap, with no text layer or alternative text",
    affectedItemIds: [IMG], ruleIds: ["quality-accessible-media"], dimensions: ["quality"],
    evidenceIds: [CON, MED], severity: "medium", confidence: "high", classification: "observed",
    remediation: "Proposal for the document owner (not executed by this audit): regenerate targets/image-only.pdf from its authoring source so the sentence is real text (a text layer), or, if it must stay an image, add equivalent alternative text to the Figure and/or publish the same sentence as text alongside it.",
    verification: "Re-run a native text-layer extraction (for example PDFKit PDFPage.string, no OCR) on the revised file and confirm it returns the page's sentence, or confirm the Figure structure element carries an /Alt or /ActualText entry equal in meaning to the visible text. This verifies local extractability only, not how a search engine or AI system ingests the file.",
    ownerRole: "Document owner", effort: "small",
    action: "update", actionReason: "Observed absence of any machine-readable text or text alternative for the page's only informative content.",
  }];
} else throw new Error("stage");
if (!bundle.collectionRecoveries.length) delete bundle.collectionRecoveries;
writeFileSync(out, JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ out, reviews: bundle.reviews.length, evidence: evidence.length, findings: bundle.findings.length, now }));
