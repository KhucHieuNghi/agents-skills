# Offline content search audit

The declared inventory contains four synthetic dossiers. All four and the scope file were read end to end. The scope file governs the audit and is outside the four-item denominator. Named pages, captions and drafts are components of their respective dossier. The scenarios use separate evidence, and owner-supplied records support comparisons within each scenario.

**Partial audit.** 4 declared and in scope, 0 fully audited, 4 pending, 0 excluded, 0 blocked, 0 failed collection and 0 unsupported. All four dossiers were collected successfully. The offline review leaves required checks unresolved. The validator found no missing check records or queued discovery work within the declared inventory.

| Dimension | Resolved checks | Unresolved checks |
|---|---:|---:|
| Content quality | 8 | 12 |
| SEO | 0 | 32 |
| AIO | 2 | 10 |
| AEO | 5 | 7 |
| GEO | 0 | 12 |
| Portfolio | 2 | 14 |

17 of 104 planned checks resolved, with 87 unresolved. Resolved checks include supported failures. [Validated delivery summary](audit-evidence/validated/delivery-summary.md) · [Validation receipt](audit-evidence/validation.json) · [Findings and actions](audit-evidence/validated/content-actions.csv).

## Six material findings

### F1 · Correct Fir's SSO claim on /compare

- Draft A, 01-competitor-claims.md:17 — “Fir has no SSO, as its pricing table proves.”
- Supplied current Fir documentation, 01-competitor-claims.md:13 — “SAML SSO is available on Enterprise, with a minimum of 20 paid seats.”

**Quality, AIO and AEO.** In the November 2026 US plan comparison, the pricing-table omission cannot establish feature absence. The supplied documentation directly contradicts the blanket claim and gives an Enterprise seat threshold. Availability on other Fir plans remains unknown. This could mislead buyers evaluating SSO eligibility.

**Action and verification.** Replace the blanket claim with the documented Enterprise SAML SSO availability and 20-paid-seat minimum. Compare the entire revised assertion with the supplied documentation and check that other plans are left unspecified.

### F2 · Correct the all-options price comparison on /compare

- Draft B, 01-competitor-claims.md:18 — “Cedar is cheaper per seat than Fir on every billing option.”
- Pricing evidence, 01-competitor-claims.md:6-10 — “Our Cedar plan: USD 12 per seat per month, billed monthly, no seat minimum. Our annual option: USD 10 per seat per month equivalent, billed annually. Competitor Fir monthly option: USD 15 per seat per month, billed monthly. Fir annual option: USD 9 per seat per month equivalent, billed annually. These figures exclude optional services; no optional service is required here.”

**Quality, AIO and AEO.** Cedar costs USD 3 less on monthly billing and USD 1 more per seat per month equivalent on annual billing. The annual result contradicts the universal claim. The comparison is for supplied November 2026 US plans, before tax and excluding optional services.

**Action and verification.** Show monthly billing and annual-billed equivalents separately. Recompute both differences against the supplied prices and confirm that the revised text preserves billing basis, units and scope. The separate /monthly-comparison caption already scopes its USD 3 difference correctly and makes no total-cost, feature-equivalence or universal-superiority claim (01-competitor-claims.md:20-24).

### F3 · Match spend and conversion windows in reporting Draft A

- Draft A, 02-measurement-windows.md:10 — “October cost per conversion was USD 85.71, from 3000 divided by 35.”
- Supplied rows, 02-measurement-windows.md:5-8 — “Spend is complete for October 1–31: USD 3000. Conversion export covers only October 1–7: 35 completed conversions. No conversion data exists for October 8–31. The same spend export gives October 1–7 spend of USD 700.”

**Quality.** The division rounds correctly. Its numerator covers October 1–31 and its denominator covers October 1–7, so the quotient cannot represent the October 2026 campaign. The separate verified-window caption accurately gives USD 20 per completed conversion for October 1–7 and marks the rest of the month unmeasured (02-measurement-windows.md:11-12).

**Action and verification.** Use that verified-window caption in place of Draft A. Reconcile the campaign, USD spend, conversion definition and dates, and recalculate 700 ÷ 35. Report a monthly figure only if the same campaign's completed conversion data covers all of October. Keep the separate referral evidence outside this calculation.

### F4 · Remove the unsupported referral multiplier in reporting Draft B

- Draft B, 02-measurement-windows.md:17-18 — “These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked.”
- Supplied referral evidence, 02-measurement-windows.md:14-16 — “Independent referral report: 15 October sessions have an identified AI-assistant referrer. Other sessions have unknown origin. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.”

**Quality and GEO measurement interpretation.** The 15 identified-referrer sessions are a supported descriptive result. The asserted 10% tracking rate and implied total of 150 lack evidence. Referral labels also cannot establish incremental sessions, response citations or conversions.

**Action and verification.** Report 15 identified AI-assistant referrer sessions in October and preserve the unknown origin of other sessions. Reconcile that count with the supplied referral report. Check that the revised text makes no extrapolation, share, causal or conversion claim. Keep it separate from the campaign conversion report (02-measurement-windows.md:20-21).

### F5 · Replace the incorrect current policy on /south-delivery

- Current South copy, 03-template-service-area.md:10-11 — “South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date.”
- Approved current policy, 03-template-service-area.md:4-5 — “Current approved policy: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.”

**Quality, AIO, AEO and portfolio.** The South passage repeats the North promise even though the current policies differ. It gives customers an incorrect delivery expectation and provides an incorrect stand-alone service answer. The affected policy is South's. North's supplied passage matches the North conditions (03-template-service-area.md:8-9).

**Action and verification.** Replace the complete South passage with next-business-day-only wording, removing the North-specific timing and outside-window sentence. Compare both current pages separately against the approved regional policy. Retain both regional pages and the clearly labeled 2024 archive for old orders. The archive's historical South policy was accurate for its contract, and the owner describes links from it to both current pages for new orders (03-template-service-area.md:13-20). Shared layout and contact wording supply no evidence of harmful duplication or search cannibalization.

### F6 · Replace the landing page's universal setup guarantee

- Draft, 04-editorial-proof.md:6 — “Every team is guaranteed to finish setup in 10 minutes.”
- Approved product record, 04-editorial-proof.md:3-5 — “Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.”

**Quality, AIO and AEO.** The landing-page copy answers how long setup takes with an unconditional promise. An observed median of 15 minutes in 20 onboarding sessions supplies no basis for a 10-minute universal guarantee. The study date, population beyond the observed sessions and broader distribution are unknown.

**Action and verification.** Remove the guarantee. If timing is useful, present the median and sample size together, attributed to the supplied study. Confirm the revised passage preserves the metric, units and sample and adds no maximum, promise, refund term or broader estimate.

## Six-dimension review by dossier

| Scenario and intended task | Content quality | SEO | AIO readiness | AEO answer quality | GEO | Portfolio |
|---|---|---|---|---|---|---|
| 01 · US plan evaluation on /compare and monthly price comparison | F1–F2. Monthly caption supported within its stated scope. | Draft excerpts leave page metadata, indexing, links and search behavior unknown. | Competitor eligibility and price claims need correction before reuse. Access and retrieval unknown. | SSO and price claims directly answer buying questions. Monthly caption is self-contained. No demand-derived question set. | No generated response or conversion observations. | The monthly-only caption serves a narrower comparison task. The supplied components provide no basis for consolidation or a site-wide gap finding. |
| 02 · October campaign reporting and independent AI referral reporting | F3–F4. The verified-window cost and observed referral count are supported within their separate scopes. | No public search objective or page evidence supplied for the reporting excerpts. | Date alignment and attribution qualifiers are important if the text is reused. Search access and retrieval unknown. | The separate cost caption retains its denominator scope and caveat. No answer-targeting brief or question set supplied. | Referrer count is synthetic referral evidence. F4 concerns interpretation. Mentions, citations, answer accuracy and incremental effects are unmeasured. | Separate reporting tasks. No public content map or demand evidence. |
| 03 · Check current delivery by region or consult a 2024 contract | F5. North's policy and the appropriately scoped archive are supported. | Intent supports separate regional pages and an archive. Canonicals, indexing, links as implemented and query overlap remain unknown. | South gives a conflicting service fact. North and the archived contract retain their respective regional and historical context. | The complete South passage gives an incorrect delivery answer. North communicates days, cutoff, local time and the outside-window consequence. No broader question set. | Search selection and generated representation unmeasured. | Complete three-component inventory for this scenario. Keep regional and archive roles distinct. The owner describes the archive's new-order link path. |
| 04 · Evaluate onboarding time, check a permission or look up a status code | F6. The permissions FAQ is correct. The owner attests that the reference table is complete and accurate. | No page metadata, index evidence or search objective supplied for the technical reference. | The unsupported timing promise is extractable but unreliable. The FAQ clearly identifies the authorized role. | The FAQ answers the full role-identification question with no further condition or deletion steps needed. The setup claim separately fails answer evidence. | No generated responses or visibility observations. | The landing page, FAQ and technical reference serve different tasks. Terse reference wording, punctuation and absent purchase CTA supply no defect for the declared task. Authorship is unknown. |

- Permissions FAQ, 04-editorial-proof.md:9 — “Can editors delete the workspace? No. Only workspace owners can delete it.”

The approved permissions policy supports that complete answer (04-editorial-proof.md:10-13). The status-code assessment relies on the owner description because the table rows were not supplied for independent inspection (04-editorial-proof.md:15-19).

## Measurement inventory and recovery

The supplied synthetic measurements are the October campaign spend and partial-window conversion counts, the independent October referral count, and the onboarding study aggregate. Spend and conversions share a usable window of October 1–7, 2026. No conversion count is available for October 8–31. The referral report supplies no session denominator or attribution model. The onboarding aggregate covers 20 observed sessions with a 15-minute median and an unspecified collection window.

No Search Console, Bing, GA4, normalized server-log or response-level AI export was supplied. Rankings, keyword demand, index state, mentions, citations, recommendations, AI answer accuracy and attributable business outcomes are unavailable. AIO means AI search optimization here. Google AI Overviews is one possible measurement surface, and none of the scenarios specifies or supplies an observed AI surface.

To resolve technical SEO and crawler checks in a later authorized review, use dated captures of HTTP status, redirects and headers, source and rendered DOM, robots and publisher intent, canonicals and variant maps, link and sitemap inventory, structured data and index evidence. Obtain complete component snapshots where excerpts leave task, metadata or media coverage unknown. Use actual customer questions and query/page data to assess question coverage, journey gaps and possible search overlap.

For a later GEO baseline, define a scenario-specific prompt set from evidenced user tasks, market and language. Record surface and mode, prompt, locale, timestamp, individual response and capture method. Keep Google AI Overviews, other search-enabled surfaces and non-search answers separate if they are in scope. Compare stable cohorts with explicit denominators and capture failures. Record mentions, cited URLs and recommendations separately, and judge factual accuracy against the relevant dated plan, service policy or product evidence. Use separately scoped referral and conversion records for business outcomes.
