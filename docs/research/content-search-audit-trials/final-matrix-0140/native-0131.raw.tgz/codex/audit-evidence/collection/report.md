# Four offline synthetic scenarios — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:25:03\.718Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 057a70f2\-c205\-4c16\-b7c2\-6e8b01c2b38d\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |
| eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| d612d742c8f55e17fa46fa3d5804a931cdda02a17d745a41aeb22b5528d7cf7a | cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad | local\-file | 2026\-11\-18T08:25:03\.703Z | 0 full elapsed days | [evidence/cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad\.txt](evidence/cf075d76c65fb4f24f5be58f6329d298a7b31bac716a59b731868658e57636ad.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 96f54c58a608ad7be3959d861eb2c682c23d450e5bb15b26211411fa5da50910 | d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d | local\-file | 2026\-11\-18T08:25:03\.704Z | 0 full elapsed days | [evidence/d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d\.txt](evidence/d95e8e567e437cce55d4b796b23d2d568efa50110a5603f6893367fa8366af0d.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e02d6d30833829506f8d66168fdbf190b721d0a48a7265da6a9bbfa0e46cefe3 | e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2 | local\-file | 2026\-11\-18T08:25:03\.705Z | 0 full elapsed days | [evidence/e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2\.txt](evidence/e25a155fafd1c92a88636b06055f616f401787d2793349d0e05fca9af39760b2.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 11b9fac22ad2278f0848cccf87923cae31a59e703d92933018aba9d0104a1cf9 | eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69 | local\-file | 2026\-11\-18T08:25:03\.705Z | 0 full elapsed days | [evidence/eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69\.txt](evidence/eca3f9a705dde89c093d8db20107a123c460bfbf5f578b04285a440cb8cfbb69.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
