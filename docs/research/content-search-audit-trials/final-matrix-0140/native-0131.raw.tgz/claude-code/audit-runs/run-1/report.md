# Synthetic dossiers — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:25:49\.785Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 71de9bd7\-09f6\-4c83\-bfd9\-573c0c9c7078\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | local\-file | 2026\-11\-18T08:25:49\.767Z | 0 full elapsed days | [evidence/079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1\.txt](evidence/079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | local\-file | 2026\-11\-18T08:25:49\.769Z | 0 full elapsed days | [evidence/3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4\.txt](evidence/3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | local\-file | 2026\-11\-18T08:25:49\.770Z | 0 full elapsed days | [evidence/84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b\.txt](evidence/84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | local\-file | 2026\-11\-18T08:25:49\.770Z | 0 full elapsed days | [evidence/f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61\.txt](evidence/f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
