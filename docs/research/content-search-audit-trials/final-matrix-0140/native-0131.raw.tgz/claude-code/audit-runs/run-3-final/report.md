# Synthetic dossiers — Content Search Audit

## Delivery summary

Partial\. 4 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 2; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:28:59\.781Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 755435ab\-ad98\-49f4\-820b\-cbda7c30965a\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1\-fir\-sso\-absence | Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation | quality\-claims, aio\-entity\-consistency | quality, aio | high | high | observed | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | update | reviewer\-proposal | A competitor capability is denied while the supplied documentation states it exists on one plan\. | Proposed: remove the no\-SSO assertion and the pricing\-table\-proves reasoning from draft /compare\. If SSO is discussed, state only what the supplied docs say: SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats\. Make no SSO statement about Fir&\#39;s other plans unless the owner supplies a source\. | Re\-read the revised /compare draft against the supplied Fir SSO docs quotation at 01\-competitor\-claims\.md:12\-14 and confirm no absence claim relies on the pricing\-table excerpt\. | Content owner | small | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab, d01\-claim\-sources, d01\-entity\-record |
| F2\-cedar\-every\-billing\-option | Draft /compare assertion B says Cedar is cheaper on every billing option; the supplied annual figures show Fir lower | quality\-claims, aio\-entity\-consistency | quality, aio | high | high | observed | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | update | reviewer\-proposal | The universal comparative claim is contradicted by one of the two supplied billing options\. | Proposed: limit the claim to monthly billing \(Cedar USD 12 versus Fir USD 15 per seat per month\), or state both options including that on annual billing Fir is USD 9 and Cedar USD 10 per seat per month equivalent\. Keep the November 2026, US, USD before\-tax scope\. | Compare each billing option named in the revised sentence with the four supplied prices at 01\-competitor\-claims\.md:6\-9; the /monthly\-comparison caption needs no change\. | Content owner | small | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab, d01\-claim\-sources, d01\-entity\-record |
| F3\-october\-cost\-window\-mismatch | Draft A reports an October cost per conversion from full\-month spend and seven days of conversions | quality\-claims | quality | high | high | observed | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | update | reviewer\-proposal | Numerator and denominator cover different date windows, so the labeled monthly metric is unsupported\. | Proposed: withdraw the October figure\. Report only the matched window already in the verified\-window caption \(October 1\-7: USD 700 / 35 completed conversions = USD 20\) and label October 8\-31 cost per conversion unmeasured\. A full\-month figure cannot be computed from the supplied data\. | In the revised sentence, confirm spend and conversions cover the same dates and recompute the quotient from the supplied rows at 02\-measurement\-windows\.md:5\-8\. | Reporting owner | small | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d, d02\-claim\-sources |
| F5\-south\-delivery\-policy | /south\-delivery states same\-day delivery; the current approved policy for South is next\-business\-day only | quality\-claims, aio\-entity\-consistency, portfolio\-contradictions | quality, aio, portfolio | high | high | observed | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | update | reviewer\-proposal | A current customer\-facing service promise conflicts with the approved policy for that region\. | Proposed: replace the /south\-delivery policy passage with the approved South policy, next\-business\-day delivery only\. Do not carry over the Monday\-Friday or 10:00 wording unless the owner confirms South ordering conditions\. Leave /north\-delivery and the /terms\-v1 archive unchanged and retain both regional pages\. | Compare the revised /south\-delivery passage with the approved policy at 03\-template\-service\-area\.md:4\-5; confirm /north\-delivery still matches and /terms\-v1 remains labeled as the 2024 archive\. | Content owner | small | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-claim\-sources, d03\-entity\-record, d03\-inventory\-map |
| F6\-setup\-time\-guarantee | Draft landing\-page claim guarantees 10\-minute setup for every team; the record supports only a 15\-minute median across 20 sessions | quality\-claims | quality | high | high | observed | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | update | reviewer\-proposal | The guarantee, the universal scope and the 10\-minute figure each lack a supplied source\. | Proposed: remove the guarantee, the every\-team scope and the 10\-minute figure\. If a time is stated, use the supplied statistic with its scope: a median completion time of 15 minutes across 20 observed onboarding sessions in the supplied study\. Leave the permissions FAQ and /status\-codes unchanged\. | Compare the revised claim with the approved product record at 04\-editorial\-proof\.md:3\-5 and confirm no guarantee, maximum or population\-wide statement remains without an owner\-supplied policy or study\. | Content owner | small | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-claim\-sources |
| F4\-ai\-sessions\-extrapolation | Draft B extrapolates 15 tracked AI\-referrer sessions to 150 with an unsupported tracking rate and the word prove | quality\-claims, geo\-observed\-presence | quality, geo | medium | high | observed | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | update | reviewer\-proposal | The descriptive count is supported; the total, the tracking rate and the causal wording are not\. | Proposed: state only the observation that 15 October sessions had an identified AI\-assistant referrer and that other sessions have unknown origin\. Remove the 150 total, the one\-in\-ten rate and the proof wording unless the owner supplies a documented estimation model or measured tracking rate\. Do not combine with the campaign conversion counts\. | Confirm every number in the revised sentence appears in the supplied referral report at 02\-measurement\-windows\.md:14\-16 and that no total, rate or causal claim remains without a supplied source\. | Reporting owner | small | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d, d02\-claim\-sources |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 2 | 10 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 1 | 15 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Supplied historical measurement evidence

Historical study sources are attached below\. Their quoted measurements are not current brand observations\. Hashes and exact passages bind supplied bytes, not authenticity, sampling validity or semantic interpretation\. No response\-level observations or performance forecasts are manufactured from aggregates\.

## Historical study source

| Field | Value |
| --- | --- |
| Source | d02\-campaign\-and\-referral\-rows |
| Kind | historical\-study |
| Locator | targets/02\-measurement\-windows\.md |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Synthetic owner\-supplied counts for one campaign in USD, October 2026: spend October 1\-31, conversions October 1\-7 only; separate referral report of October sessions with an identified AI\-assistant referrer\. Interface, locale and market not stated\. |
| Source SHA\-256 | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 |
| Limitations | Not a live connector response; authenticity not verified; Conversions for October 8\-31 are missing, not zero; Referral count has no complete session denominator, tracking\-rate model or conversion linkage; Campaign conversions and the referral report must not be combined; No AI answer captures or citation annotations; no visibility rate can be derived |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| d02\-campaign\-and\-referral\-rows | 3–8 | Scope: one campaign, one currency \(USD\), completed October 2026 reporting window\. All figures are synthetic owner\-supplied counts, not a live connector response\. Spend is complete for October 1–31: USD 3000\. Conversion export covers only October 1–7: 35 completed conversions\. No conversion data exists for October 8–31\. The same spend export gives October 1–7 spend of USD 700\. |
| d02\-campaign\-and\-referral\-rows | 14–16 | Independent referral report: 15 October sessions have an identified AI\-assistant referrer\. Other sessions have unknown origin\. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists\. |
| d02\-campaign\-and\-referral\-rows | 20–21 | Do not combine the campaign conversion counts with the independent referral report\. No citation annotations or generated answer captures are supplied\. |

## Historical study source

| Field | Value |
| --- | --- |
| Source | d04\-onboarding\-study |
| Kind | historical\-study |
| Locator | targets/04\-editorial\-proof\.md |
| Data label | SYNTHETIC FIXTURE DATA — not live performance |
| Reviewer\-supplied scope | Synthetic owner\-approved product record: 20 observed onboarding sessions in a supplied study; collection window, population and locale not stated\. |
| Source SHA\-256 | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 |
| Limitations | Only a median is supplied; no maximum, percentile distribution or wider population estimate; Collection window unknown; Not AI visibility or search performance evidence |
| Evidence bundle | [study\-evidence\.json](study-evidence.json) |

## Exact study passages

| Source | Lines | Verbatim passage |
| --- | --- | --- |
| d04\-onboarding\-study | 3–5 | Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes\. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate\. |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | pending | Snapshot review incomplete | 26 |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | pending | Snapshot review incomplete | 26 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | pending | Snapshot review incomplete | 26 |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-claims | quality | fail | The draft landing\-page claim guarantees every team finishes setup in 10 minutes\. The approved record supplies only a 15\-minute median across 20 observed sessions and no guarantee, maximum or wider population estimate\. The permissions FAQ component matches the approved permissions policy, and the /status\-codes table is owner\-confirmed complete and accurate for its declared task\. | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-claim\-sources |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-claim\-sources |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d04\-extracted\-text |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-question\-coverage | aeo | pass | The only supplied question, whether editors can delete the workspace, is answered directly by the FAQ\. No questions are supplied for the landing\-page claim or /status\-codes, and none are invented, so those components have no bearing on this question\-specific check\. | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-question\-set |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-answer\-context | aeo | pass | The FAQ answer stands alone: it gives the negative answer and names the permitted role, and the approved policy states no additional conditions are needed for this permission question\. The supplied task is identifying the permitted role, not the deletion procedure\. | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-question\-set |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | aeo\-answer\-evidence | aeo | unknown | The FAQ answer component is supported by the approved permissions policy\. Item\-wide verdict withheld: no supplied question or task establishes the landing\-page setup\-time claim as an answer claim, so its AEO applicability is unresolved; its lack of support is recorded under quality\-claims\. | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-claim\-sources |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | d04\-claim\-sources |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations | d04\-question\-set |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753, d04\-question\-set |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-claims | quality | fail | Draft /compare assertion A states Fir has no SSO, while the supplied Fir SSO docs state SAML SSO is available on Enterprise with a 20 paid seat minimum; a pricing\-table excerpt that does not mention SSO proves no absence\. Assertion B claims Cedar is cheaper on every billing option, but supplied annual figures are Cedar USD 10 versus Fir USD 9 per seat per month equivalent\. The /monthly\-comparison caption component is supported \(USD 15 minus USD 12 on monthly billing\)\. | d01\-claim\-sources, df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | d01\-claim\-sources, df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d01\-extracted\-text |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-entity\-consistency | aio | fail | Draft assertions A and B state Fir SSO availability and Cedar/Fir relative price inconsistently with the supplied entity record for the same November 2026 US plans\. This is the same defect as the quality\-claims failure, not a separate issue\. The monthly caption is consistent with the record\. | d01\-entity\-record, df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | d01\-claim\-sources, df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | d01\-claim\-sources |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: inventory\-map | d01\-entity\-record, df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-claims | quality | fail | /south\-delivery states same\-day delivery Monday\-Friday for orders before 10:00, while the current approved policy says South serves next\-business\-day delivery only\. /north\-delivery matches the approved policy\. /terms\-v1 is an owner\-confirmed labeled 2024 archive whose text was not supplied; its described date\-scoped claim is not treated as a defect\. | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-claim\-sources |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-claim\-sources |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d03\-extracted\-text |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-entity\-consistency | aio | fail | The /south\-delivery passage attributes North&\#39;s same\-day service to South, inconsistent with the approved entity record for South\. Same defect as the quality\-claims failure\. North passage is consistent; the 2024 archive is a date\-scoped version, not an inconsistency\. | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-entity\-record |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-claim\-sources |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | d03\-claim\-sources |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: question\-set | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-inventory\-map |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-duplication | portfolio | pass | The two current pages serve different regions and the owner wants both retained; /terms\-v1 is a labeled 2024 version variant kept for old orders\. These are legitimate region and version variants\. Shared layout and repeated generic contact wording are intentional, and no query/page overlap data exists, so no cannibalization is asserted\. The incorrect South policy text is a factual defect recorded under quality\-claims, not a duplication defect\. Limitation: full page bodies were described, not supplied\. | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-inventory\-map |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-contradictions | portfolio | unknown | Observed: the current /south\-delivery passage conflicts with the approved policy record \(persisted in the consolidated finding\)\. Not resolved item\-wide because /terms\-v1 text and full page bodies were described but not supplied; the owner\-described 2024 South same\-day statement is date\-scoped and is not counted as a contradiction\. | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171, d03\-entity\-record, d03\-inventory\-map |
| 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-claims | quality | fail | Draft A divides October 1\-31 spend \(USD 3000\) by October 1\-7 conversions \(35\) and labels the result October cost per conversion; conversions for October 8\-31 do not exist in the supplied data\. Draft B says 15 tracked sessions prove 150 AI\-generated sessions using a one\-in\-ten tracking rate that no supplied model, test or count supports\. The verified\-window caption component is supported \(700 / 35 = 20, with the unmeasured remainder disclosed\)\. | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d, d02\-claim\-sources |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d, d02\-claim\-sources |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | d02\-extracted\-text |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d, d02\-claim\-sources |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | d02\-claim\-sources |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |
| f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 756e9921da0d03e1d6d7fdb36fcdfbe54b6d82ff4cec643db93d3a857c38a753 | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | local\-file | 2026\-11\-18T08:25:49\.767Z | 0 full elapsed days | [evidence/079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1\.txt](evidence/079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| df8c57cb5ae3bcc72e9c8904781defd1e0eae17dfef70ae97b46727cdc5c1fab | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | local\-file | 2026\-11\-18T08:25:49\.769Z | 0 full elapsed days | [evidence/3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4\.txt](evidence/3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0a42f4044487f77bfd82ae02b0410f7608033732d835230797e985e6872e9171 | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | local\-file | 2026\-11\-18T08:25:49\.770Z | 0 full elapsed days | [evidence/84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b\.txt](evidence/84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0089098eb8e16c36a75b1b5910054865b15e3888585be3b65e4042def1f9992d | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | local\-file | 2026\-11\-18T08:25:49\.770Z | 0 full elapsed days | [evidence/f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61\.txt](evidence/f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d01\-extracted\-text | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d01\-extracted\-text\.txt](evidence/d01-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Markdown source text reproduced unchanged; not rendered output; Nonempty text does not establish quality or completeness |
| d02\-extracted\-text | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d02\-extracted\-text\.txt](evidence/d02-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Markdown source text reproduced unchanged; not rendered output; Nonempty text does not establish quality or completeness |
| d03\-extracted\-text | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d03\-extracted\-text\.txt](evidence/d03-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Markdown source text reproduced unchanged; not rendered output; Nonempty text does not establish quality or completeness |
| d04\-extracted\-text | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d04\-extracted\-text\.txt](evidence/d04-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Markdown source text reproduced unchanged; not rendered output; Nonempty text does not establish quality or completeness |
| d01\-claim\-sources | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d01\-claim\-sources\.txt](evidence/d01-claim-sources.txt) | ea07d2e3d701fd2da3c60f6da7013a99ab26eb0ba68eef9a67d6752d249c78c3 | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d01\-entity\-record | 3c42cf1d810fbc0c6e06d0b1565998cdfec093bd71e4d0009a8c950b4f5095a4 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d01\-entity\-record\.txt](evidence/d01-entity-record.txt) | 2caad63d43e55194e88a048e2816123d227ddebc889af892e7f8e89f35f6378a | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d02\-claim\-sources | f78ea100a729ed25594fb2c37e35d6c2672863875b2bbf8c594b866f2eba8c61 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d02\-claim\-sources\.txt](evidence/d02-claim-sources.txt) | 2b6209f46d2712d3131e4aa6b8fca6b2d2ab408b8e953ed9db6932965dfe4186 | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d03\-claim\-sources | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d03\-claim\-sources\.txt](evidence/d03-claim-sources.txt) | a0f3fcfada6aaceed09a4c6e30b6f900870905fe0de92899cc1363775e17675a | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d03\-entity\-record | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d03\-entity\-record\.txt](evidence/d03-entity-record.txt) | 6825702cbbf3f32705a048e45f890318f27d32890c7a7bb480900d00f7f01923 | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d03\-inventory\-map | 84a2692f9f1acd62c47dc5a94f00a13300d106a035456171cedc64e3576ed98b | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d03\-inventory\-map\.txt](evidence/d03-inventory-map.txt) | 1202f2eacec74cd01d089ad3950d37df9dc4ac8d873b29817eb4991c108777be | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording; Completeness is the owner&\#39;s declaration for this synthetic scenario, not a crawl |
| d04\-claim\-sources | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d04\-claim\-sources\.txt](evidence/d04-claim-sources.txt) | 8f8a287f896734b4ec00662d78173f2a70d356b8c9c900f2f1d03c19209f9324 | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording |
| d04\-question\-set | 079d2a177a4ccaedfacf110be188de6508bd79ac300900faff1dc1638a3ac0e1 | host\-attributed\-context | 2026\-11\-18T08:28:47\.635Z | 0 full elapsed days | [evidence/d04\-question\-set\.txt](evidence/d04-question-set.txt) | ebb9a28dd84ee47e0f0a2cc9382d4b0318a5b0592c9d0d3717f92590d2653145 | Synthetic owner\-supplied comparison basis within this dossier only; not independently verified live behavior; Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording; One supplied question only; no search, support or sales question evidence |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
