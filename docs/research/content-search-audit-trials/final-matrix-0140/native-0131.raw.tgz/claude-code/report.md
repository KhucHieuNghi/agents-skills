# Content search audit: four synthetic dossiers

**Status: partial.** 4 declared dossiers; 0 fully audited; 4 pending. 6 material findings; 7 clean components. Every organization, price, policy, metric and observation is invented for this test, and each dossier is a separate scenario.

## 1. Summary

| Dossier | Material findings | Clean components | Item state |
| --- | --- | --- | --- |
| 01-competitor-claims.md | 2 (F1, F2) | 1 | pending |
| 02-measurement-windows.md | 2 (F3, F4) | 1 | pending |
| 03-template-service-area.md | 1 (F5) | 3 | pending |
| 04-editorial-proof.md | 1 (F6) | 2 | pending |
| **Total** | **6** | **7** | **0 audited, 4 pending** |

Priority order: F5, F1, F2, F6 and F3 are high severity; F4 is medium. All six are observed against owner-supplied records inside the same dossier. Those records are an approved comparison basis, not independently verified live behavior.

No dossier is fully audited, because most SEO, AIO, AEO, GEO and portfolio checks need evidence that was not supplied (section 6). This was a single four-item run, not a campaign. Nothing in the targets or the installed skill was changed, and no URL was fetched.

## 2. Scope and method

- **Scope:** the four numbered dossiers in `targets/`, following `targets/context.md`. Market, billing, audience and date scope are kept as each dossier states them. Nothing is carried between dossiers.
- **Inventory:** 4 items, declared complete for this scope. Dossiers stay as one item each; pages described inside a dossier are treated as components, not separate inventory items.
- **Evidence surface:** local Markdown text only. No live pages, HTTP responses, rendered DOM, crawler policy, index data, rankings, keyword volume, engine output or analytics accounts.
- **Run artifacts:** `audit-runs/run-3-final/` (validated: structurally valid, completion not allowed). It holds the inventory, evidence, 104 checks, 6 findings, coverage, action CSV and the generated report.
- **Quotations:** every source quotation in this report is a block quote carrying its file and line locator. All 22 were submitted to the skill's quote verifier; the receipt is `quote-receipt.json`. The verifier checks wording and location only, not meaning.
- **Arithmetic:** quotients and differences used below were computed by script, not from memory.

## 3. Material findings

### Dossier 01: competitor comparison (November 2026, US plans, USD before tax)

Supplied records used as the comparison basis:

> 01-competitor-claims.md:3-4 — All records concern current November 2026 US plans, USD before tax. The owner supplied the relevant pricing excerpts and quoted SSO documentation below.

> 01-competitor-claims.md:6-9 — Our Cedar plan: USD 12 per seat per month, billed monthly, no seat minimum. Our annual option: USD 10 per seat per month equivalent, billed annually. Competitor Fir monthly option: USD 15 per seat per month, billed monthly. Fir annual option: USD 9 per seat per month equivalent, billed annually.

> 01-competitor-claims.md:12-14 — Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: "SAML SSO is available on Enterprise, with a minimum of 20 paid seats." No SSO statement is supplied for Fir's other plans.

#### F1 (high): draft /compare assertion A denies Fir SSO against the supplied Fir documentation

> 01-competitor-claims.md:17 — A. "Fir has no SSO, as its pricing table proves."

- **Affected:** draft /compare, assertion A. Dimensions: content quality and AIO entity consistency (one issue, two labels).
- **Observation:** the supplied Fir SSO docs say SAML SSO exists on Enterprise with a 20 paid seat minimum (lines 12-14). The pricing-table excerpt is silent on SSO.
- **Rationale:** the assertion is contradicted for the Enterprise plan. Silence in a pricing excerpt is not proof of absence. For Fir's other plans no SSO statement is supplied, so their SSO status is unknown, not established as absent.
- **Proposed action:** remove the no-SSO assertion and the pricing-table reasoning. If SSO is mentioned, state only what the supplied docs say about Enterprise and its seat minimum. Say nothing about other Fir plans unless the owner supplies a source.
- **Verification:** re-read the revised draft against lines 12-14 and confirm no absence claim rests on the pricing-table excerpt.

#### F2 (high): draft /compare assertion B claims Cedar is cheaper on every billing option

> 01-competitor-claims.md:18 — B. "Cedar is cheaper per seat than Fir on every billing option."

- **Affected:** draft /compare, assertion B. Dimensions: content quality and AIO entity consistency.
- **Observation:** on monthly billing Cedar is USD 12 and Fir USD 15 per seat per month. On annual billing Cedar is USD 10 and Fir USD 9 per seat per month equivalent (lines 6-9).
- **Rationale:** the claim holds for monthly billing and fails for annual billing, where Fir is USD 1 lower per seat per month equivalent. The universal wording is contradicted by one of the two supplied options.
- **Proposed action:** limit the claim to monthly billing, or state both options including the annual figures. Keep the November 2026, US, before-tax scope.
- **Verification:** compare each billing option named in the revised sentence with the four prices at lines 6-9.

### Dossier 02: reporting draft (one campaign, USD, October 2026)

Supplied rows used as the comparison basis:

> 02-measurement-windows.md:5-8 — Spend is complete for October 1–31: USD 3000. Conversion export covers only October 1–7: 35 completed conversions. No conversion data exists for October 8–31. The same spend export gives October 1–7 spend of USD 700.

> 02-measurement-windows.md:14-16 — Independent referral report: 15 October sessions have an identified AI-assistant referrer. Other sessions have unknown origin. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.

> 02-measurement-windows.md:20-21 — Do not combine the campaign conversion counts with the independent referral report. No citation annotations or generated answer captures are supplied.

#### F3 (high): Draft A mixes full-month spend with seven days of conversions

> 02-measurement-windows.md:10 — Draft A: "October cost per conversion was USD 85.71, from 3000 divided by 35."

- **Affected:** Draft A. Dimension: content quality (measurement claim).
- **Observation:** the numerator is spend for October 1–31; the denominator is conversions for October 1–7 only. The division itself is arithmetically right (3000 / 35 = 85.71).
- **Rationale:** the two quantities cover different windows, so the result is not October cost per conversion. Conversions for October 8–31 are missing, not zero. The matched window gives USD 20 (700 / 35), so the draft figure is more than four times the only supported figure.
- **Proposed action:** withdraw the October figure. Report the October 1–7 figure with its window and label October 8–31 unmeasured. A full-month figure cannot be computed from the supplied data.
- **Verification:** confirm spend and conversions in the revised sentence cover the same dates, then recompute from lines 5-8.

#### F4 (medium): Draft B extrapolates 15 tracked sessions to 150 and calls it proof

> 02-measurement-windows.md:17-18 — Draft B: "These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked."

- **Affected:** Draft B. Dimensions: content quality and GEO measurement (one issue, two labels).
- **Observation:** 15 sessions with an identified AI-assistant referrer is a supported descriptive count. The dossier supplies no tracking-rate model, incrementality test, complete session count or conversion linkage (lines 14-16).
- **Rationale:** the one-in-ten rate has no supplied source, so the 150 total is 15 multiplied by an unsupported factor. Sessions of unknown origin are unknown, not AI-generated. The count of 15 itself is not in question.
- **Proposed action:** state only the observation of 15 sessions with an identified AI-assistant referrer and that other sessions have unknown origin. Remove the total, the rate and the proof wording unless the owner supplies a documented estimation model or measured tracking rate. Keep this report separate from the campaign conversions.
- **Verification:** confirm every number in the revised sentence appears at lines 14-16 and no total, rate or causal claim remains without a supplied source.

### Dossier 03: regional service pages

> 03-template-service-area.md:4-5 — Current approved policy: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.

#### F5 (high): /south-delivery promises same-day delivery; approved South policy is next-business-day only

> 03-template-service-area.md:10-11 — /south-delivery: "South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."

- **Affected:** /south-delivery policy passage only. Dimensions: content quality, AIO entity consistency and portfolio contradiction, consolidated into this one finding.
- **Observation:** the page states same-day service for South. The current approved policy gives South next-business-day delivery only (lines 4-5).
- **Rationale:** a current customer-facing service promise conflicts with the approved policy for that region. Apart from the region name, the South passage carries the North service terms; whether that came from the shared layout is an interpretation, not something the dossier states.
- **Proposed action:** replace the passage with the approved South policy. Do not carry over the Monday–Friday or 10:00 wording unless the owner confirms South ordering conditions, because none are supplied. Keep both regional pages and leave /north-delivery and /terms-v1 unchanged.
- **Verification:** compare the revised passage with lines 4-5; confirm /north-delivery still matches and /terms-v1 is still labeled as the 2024 archive.

### Dossier 04: onboarding copy and documentation

> 04-editorial-proof.md:3-5 — Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.

#### F6 (high): landing-page draft guarantees 10-minute setup for every team

> 04-editorial-proof.md:6 — Draft landing-page claim: "Every team is guaranteed to finish setup in 10 minutes."

- **Affected:** draft landing-page claim only. Dimension: content quality.
- **Observation:** the only supplied measurement is a 15-minute median across 20 observed sessions. No guarantee, maximum or wider population estimate is supplied.
- **Rationale:** three parts of the claim lack support: the guarantee, the every-team scope and the 10-minute figure. With 20 sessions, a 15-minute median means at least 10 of them took 15 minutes or longer, so the observed sessions themselves do not fit a 10-minute universal. The median says nothing about the slowest session or about teams outside the study.
- **Proposed action:** remove the guarantee, the universal scope and the 10-minute figure. If a time is stated, use the supplied statistic with its scope (median, 15 minutes, 20 observed sessions).
- **Verification:** compare the revised claim with lines 3-5 and confirm no guarantee, maximum or population-wide statement remains without an owner-supplied policy or study.

## 4. Clean components (no finding)

**01, /monthly-comparison caption: clean.**

> 01-competitor-claims.md:20-24 — Separate /monthly-comparison caption: "On the supplied monthly plans, Cedar is USD 3 less per seat per month before tax." The owner intends this caption to compare monthly billing only, without claiming total cost, equivalent features or superiority for every customer.

USD 15 minus USD 12 is USD 3, and the caption keeps the monthly and before-tax scope. Absence of engine or conversion data is not a defect in this caption.

**02, verified-window caption: clean.**

> 02-measurement-windows.md:11-12 — Separate verified-window caption: "For October 1–7, observed cost per completed conversion was USD 20 (700 divided by 35). The rest of the month is unmeasured."

Spend and conversions cover the same seven days, 700 / 35 is 20, and the unmeasured remainder is disclosed.

**03, /north-delivery: clean.**

> 03-template-service-area.md:8-9 — /north-delivery: "North: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."

The passage matches the approved North policy at lines 4-5.

**03, /terms-v1 archive: clean on the owner's description.**

> 03-template-service-area.md:13-16 — Owner confirms /terms-v1 is a clearly labeled 2024 archive kept for old orders. It accurately describes the 2024 service contract, when South had same-day service. It links to the two current pages for new orders. No mixed-version customer task or misleading current-policy label is present.

Its South same-day statement is scoped to 2024 and is not a contradiction of current policy. The archive text itself was not supplied, so this rests on the owner's confirmation.

**03, two regional pages with a shared layout: clean.**

> 03-template-service-area.md:18-20 — The two current pages serve different regions and the owner wants both retained. Shared layout and repeated generic contact wording are intentional. No ranking, query/page overlap, backlink, conversion or search-engine selection data exists.

These are legitimate regional variants. No duplication or cannibalization finding is raised, and no consolidation is proposed. The inventory for this scenario is owner-declared complete:

> 03-template-service-area.md:3 — The declared inventory is complete: /north-delivery, /south-delivery, /terms-v1.

**04, permissions FAQ: clean.**

> 04-editorial-proof.md:8-13 — Separate permissions FAQ, complete question and answer: "Can editors delete the workspace? No. Only workspace owners can delete it." The approved permissions policy states exactly that editors cannot delete a workspace and owners can. There are no additional conditions needed to answer this permission question. The task is to identify the permitted role, not perform the deletion procedure.

The answer matches the approved policy and is complete for the supplied question. No deletion steps or extra conditions are needed.

**04, /status-codes reference page: clean.**

> 04-editorial-proof.md:15-19 — Separate reference page /status-codes has a complete, accurate table for its declared technical task. Its terse language, punctuation and lack of a purchase CTA are approved by the documentation owner. No authorship evidence, readability failure, acquisition objective or user task failure was supplied for this page. Do not infer authorship from style.

Terse style and no purchase CTA are owner-approved for a reference page. No authorship inference is made. The table itself was not supplied, so its accuracy rests on the owner's statement.

## 5. Dimension assessment by dossier

"Unknown" means the evidence needed was not supplied; it does not mean a defect or a pass.

| Dimension | 01 competitor claims | 02 measurement windows | 03 service area | 04 editorial proof |
| --- | --- | --- | --- | --- |
| Content quality | Claims fail (F1, F2); caption clean. Task fit, freshness, media unknown | Claims fail (F3, F4); caption clean. Rest unknown | Claims fail (F5); North and archive clean. Rest unknown | Claims fail (F6); FAQ and /status-codes clean. Rest unknown |
| SEO | Unknown | Unknown | Unknown | Unknown |
| AIO | Entity consistency fails (F1, F2). Crawler policy, retrievable facts unknown | Unknown | Entity consistency fails (F5). Rest unknown | Unknown |
| AEO | Unknown (no question set) | Unknown (no question set) | Unknown (no question set) | Question coverage and answer context pass for the one supplied FAQ question. Answer evidence unknown item-wide; FAQ component supported |
| GEO | Unknown (no observations) | Unknown; F4 concerns AI-referral measurement, but no answer captures exist | Unknown | Unknown |
| Portfolio | Unknown (no inventory map) | Unknown | Duplication passes (legitimate variants). Contradictions unknown item-wide; the South conflict is in F5. Task gaps, journey links unknown | Unknown |

Readable-text extraction passed for all four dossiers. That shows the text is nonempty, nothing more.

Uncertain cases worth naming:

- **01:** SSO status of Fir plans other than Enterprise is unknown. Whether the comparison's date scope appears on the published page is unknown, since only two draft assertions and one caption were supplied.
- **02:** October 8–31 conversions and full-month cost per conversion are unmeasured. Total AI-assisted sessions are unknown.
- **03:** South ordering conditions (days, cutoff) under the current policy are not supplied. The /terms-v1 text and the shared contact wording were described, not supplied.
- **04:** No question or task was supplied for the landing-page claim, so it was not forced into an AEO failure. The slowest session, the distribution and the study's collection window are unknown.

## 6. Coverage, missing measurements and limits

Validated coverage from `audit-runs/run-3-final/coverage.json`:

| Measure | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Fully audited | 0 |
| Pending | 4 |
| Failed / blocked / unsupported / excluded | 0 / 0 / 0 / 0 |
| Planned checks | 104 (26 rules per dossier) |
| Resolved checks | 13 (6 fail, 7 pass) |
| Unknown checks | 91 |
| Persisted findings | 6 |
| Missing planned checks | 0 |
| Completion allowed by validator | No |

Resolved checks by dimension: quality 8 of 20, SEO 0 of 32, AIO 2 of 12, AEO 2 of 12, GEO 0 of 12, portfolio 1 of 16.

All four files were read in full, but reading is not the same as fully audited. Each item stays pending because required checks cannot be resolved from the supplied text.

Evidence not supplied, and what it blocks:

- **SEO (all 32 checks):** HTTP responses, index and canonical declarations, publisher intent, metadata, link graph, structured data, locale map, rendered DOM.
- **AIO:** crawler policy and publisher intent for every dossier; entity records for 02 and 04; audience context for retrievable-facts checks.
- **AEO:** question sets for 01, 02 and 03.
- **GEO (all 12 checks):** no AI answer captures, citations or mention annotations exist. Visibility, citation and answer-accuracy rates are unavailable, not zero.
- **Portfolio:** inventory maps for 01, 02 and 04; link graphs; question sets.
- **Search and business measurement:** no Search Console, GA4, Bing or server-log exports; no rankings, keyword volume, backlinks or conversions beyond the rows in dossier 02.

Measurements that were supplied, attached to the run as synthetic historical aggregates (`study-evidence.json`):

- **Dossier 02:** October 2026 spend, October 1–7 conversions and spend, and the count of 15 sessions with an identified AI-assistant referrer. These are owner-supplied synthetic counts, not a live connector response.
- **Dossier 04:** the 15-minute median across 20 observed onboarding sessions; collection window not stated.

Neither is AI visibility or search performance evidence, and neither produces a rate.

Other limits:

- Owner-approved records are the comparison basis within each scenario only. Nothing here verifies real pricing, documentation, policy or product behavior.
- Findings were judged by a single reviewer pass. Artifact validation confirms structure and bindings, not that a judgment is correct.
- The quote receipt covers the 22 block quotes in this file. Edits after verification would need a new receipt.
- No overall score, ranking forecast or uplift estimate is given.

Recovery path to full coverage: supply live or exported page captures with HTTP and metadata evidence, crawler policy and publisher intent, real question sets per page, an inventory map and link graph per scenario, and any AI answer observations. Then resume from `audit-runs/run-3-final/`.

## 7. Artifacts

- `audit-runs/run-3-final/`: final validated run (report, HTML, coverage, action CSV, findings, checks, evidence, study evidence).
- `audit-runs/run-1/` and `audit-runs/run-2-reviewed/`: earlier immutable revisions (collection, then review).
- `audit-work/validation.json`: validator output for the final run.
- `audit-work/`: run config, review bundle, report options and the two helper scripts.
- `quote-receipt.json`: quote verifier receipt for this report.
