// Builds review.json and report-options.json for the four synthetic dossiers.
// Reads the collected run and target files; writes only into audit-work/.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const work = path.dirname(fileURLToPath(import.meta.url));
const project = path.dirname(work);
const run = path.join(project, "audit-runs", "run-1");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jsonl = async (f) =>
  (await readFile(path.join(run, f), "utf8"))
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));

const inventory = await jsonl("inventory.jsonl");
const evidence = await jsonl("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "Claude (content-search-audit host review)";
const names = {
  d01: "01-competitor-claims.md",
  d02: "02-measurement-windows.md",
  d03: "03-template-service-area.md",
  d04: "04-editorial-proof.md",
};
const item = {},
  snap = {};
for (const [key, name] of Object.entries(names)) {
  const it = inventory.find((i) => path.basename(i.path) === name);
  if (!it) throw new Error(`Missing inventory item ${name}`);
  item[key] = it.itemId;
  snap[key] = evidence.find(
    (e) => e.itemId === it.itemId && e.kind === "content",
  );
  if (!snap[key]) throw new Error(`Missing content snapshot ${name}`);
}

const artifacts = {};
const added = [];
function add(key, suffix, kind, value, locator, limitations) {
  const evidenceId = `${key}-${suffix}`;
  const artifact = `evidence/${evidenceId}.txt`;
  artifacts[artifact] = value;
  added.push({
    ...snap[key],
    evidenceId,
    kind,
    method: "host-attributed-context",
    artifact,
    value,
    snapshotHash: hash(value),
    byteLength: Buffer.byteLength(value),
    collectedAt: now,
    locator,
    limitations,
    sourceEvidenceIds: [snap[key].evidenceId],
  });
  return evidenceId;
}
const ownerLimits = [
  "Synthetic owner-supplied comparison basis within this dossier only; not independently verified live behavior",
  "Attributed paraphrase preserved by the reviewer; the source snapshot remains the authority for wording",
];
const ids = {};
for (const key of Object.keys(names))
  ids[`${key}-text`] = add(
    key,
    "extracted-text",
    "extracted-text",
    snap[key].value,
    `${names[key]} (identity text extraction of the Markdown source snapshot)`,
    [
      "Markdown source text reproduced unchanged; not rendered output",
      "Nonempty text does not establish quality or completeness",
    ],
  );

// Dossier 01
const d01facts =
  "Synthetic owner-supplied records, 01-competitor-claims.md:3-14, scope: current November 2026 US plans, USD before tax, optional services excluded and none required. Cedar: USD 12 per seat per month billed monthly, no seat minimum; annual option USD 10 per seat per month equivalent billed annually. Fir: monthly option USD 15 per seat per month billed monthly; annual option USD 9 per seat per month equivalent billed annually. Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: SAML SSO is available on Enterprise, with a minimum of 20 paid seats. No SSO statement is supplied for Fir's other plans.";
ids.d01claims = add("d01", "claim-sources", "claim-sources", d01facts, "01-competitor-claims.md:3-14", ownerLimits);
ids.d01entity = add("d01", "entity-record", "entity-record", `Entity record for Cedar and Fir plans. ${d01facts}`, "01-competitor-claims.md:3-14", ownerLimits);
// Dossier 02
ids.d02claims = add(
  "d02",
  "claim-sources",
  "claim-sources",
  "Synthetic owner-supplied counts, 02-measurement-windows.md:3-8 and 14-16; one campaign, USD, completed October 2026 window; not a live connector response. Spend complete for October 1-31: USD 3000. Conversion export covers only October 1-7: 35 completed conversions. No conversion data exists for October 8-31. October 1-7 spend: USD 700. Independent referral report (not to be combined with campaign conversions): 15 October sessions have an identified AI-assistant referrer; other sessions have unknown origin; no model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.",
  "02-measurement-windows.md:3-8,14-16,20-21",
  ownerLimits,
);
// Dossier 03
const d03policy =
  "Synthetic owner-approved current policy, 03-template-service-area.md:4-5: North serves same-day delivery, Monday-Friday, orders placed before 10:00 local time. South serves next-business-day delivery only. Owner statement, lines 13-16: /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurately describing the 2024 service contract when South had same-day service, linking to the two current pages for new orders.";
ids.d03claims = add("d03", "claim-sources", "claim-sources", d03policy, "03-template-service-area.md:4-5,13-16", ownerLimits);
ids.d03entity = add("d03", "entity-record", "entity-record", `Entity record for North and South delivery service. ${d03policy}`, "03-template-service-area.md:4-5,13-16", ownerLimits);
ids.d03map = add(
  "d03",
  "inventory-map",
  "inventory-map",
  "Owner-declared complete inventory for this scenario, 03-template-service-area.md:3: /north-delivery, /south-delivery, /terms-v1. Roles, lines 6 and 13-19: /north-delivery and /south-delivery are current service pages for different regions sharing a layout, both to be retained; /terms-v1 is a labeled 2024 archive for old orders linking to both current pages. Only the two current policy passages are supplied as page text; /terms-v1 text and the repeated generic contact wording are described, not supplied.",
  "03-template-service-area.md:3,6,13-19",
  [...ownerLimits, "Completeness is the owner's declaration for this synthetic scenario, not a crawl"],
);
// Dossier 04
ids.d04claims = add(
  "d04",
  "claim-sources",
  "claim-sources",
  "Synthetic owner-approved records, 04-editorial-proof.md:3-5, 10-13, 15-18. Product record: for 20 observed onboarding sessions in a supplied study the median completion time was 15 minutes; no maximum time, guarantee, refund policy, percentile distribution or wider population estimate is supplied. Permissions policy: editors cannot delete a workspace and owners can; no additional conditions are needed for that permission question. /status-codes: owner states the table is complete and accurate for its declared technical task and approves its terse language, punctuation and lack of a purchase CTA.",
  "04-editorial-proof.md:3-5,10-13,15-18",
  ownerLimits,
);
ids.d04questions = add(
  "d04",
  "question-set",
  "question-set",
  "Supplied question, 04-editorial-proof.md:9: Can editors delete the workspace? Supplied task, lines 12-13: identify the permitted role, not perform the deletion procedure. No question is supplied for the landing-page claim or for /status-codes.",
  "04-editorial-proof.md:9,12-13",
  [...ownerLimits, "One supplied question only; no search, support or sales question evidence"],
);

const c = (key) => snap[key].evidenceId;
const review = (key, ruleId, status, reason, evidenceIds) => ({
  itemId: item[key],
  ruleId,
  status,
  reason,
  evidenceIds,
  reviewer,
  reviewedAt: now,
});
const reviews = [
  review("d01", "quality-claims", "fail", "Draft /compare assertion A states Fir has no SSO, while the supplied Fir SSO docs state SAML SSO is available on Enterprise with a 20 paid seat minimum; a pricing-table excerpt that does not mention SSO proves no absence. Assertion B claims Cedar is cheaper on every billing option, but supplied annual figures are Cedar USD 10 versus Fir USD 9 per seat per month equivalent. The /monthly-comparison caption component is supported (USD 15 minus USD 12 on monthly billing).", [c("d01"), ids.d01claims]),
  review("d01", "aio-entity-consistency", "fail", "Draft assertions A and B state Fir SSO availability and Cedar/Fir relative price inconsistently with the supplied entity record for the same November 2026 US plans. This is the same defect as the quality-claims failure, not a separate issue. The monthly caption is consistent with the record.", [c("d01"), ids.d01entity]),
  review("d02", "quality-claims", "fail", "Draft A divides October 1-31 spend (USD 3000) by October 1-7 conversions (35) and labels the result October cost per conversion; conversions for October 8-31 do not exist in the supplied data. Draft B says 15 tracked sessions prove 150 AI-generated sessions using a one-in-ten tracking rate that no supplied model, test or count supports. The verified-window caption component is supported (700 / 35 = 20, with the unmeasured remainder disclosed).", [c("d02"), ids.d02claims]),
  review("d03", "quality-claims", "fail", "/south-delivery states same-day delivery Monday-Friday for orders before 10:00, while the current approved policy says South serves next-business-day delivery only. /north-delivery matches the approved policy. /terms-v1 is an owner-confirmed labeled 2024 archive whose text was not supplied; its described date-scoped claim is not treated as a defect.", [c("d03"), ids.d03claims]),
  review("d03", "aio-entity-consistency", "fail", "The /south-delivery passage attributes North's same-day service to South, inconsistent with the approved entity record for South. Same defect as the quality-claims failure. North passage is consistent; the 2024 archive is a date-scoped version, not an inconsistency.", [c("d03"), ids.d03entity]),
  review("d03", "portfolio-duplication", "pass", "The two current pages serve different regions and the owner wants both retained; /terms-v1 is a labeled 2024 version variant kept for old orders. These are legitimate region and version variants. Shared layout and repeated generic contact wording are intentional, and no query/page overlap data exists, so no cannibalization is asserted. The incorrect South policy text is a factual defect recorded under quality-claims, not a duplication defect. Limitation: full page bodies were described, not supplied.", [c("d03"), ids.d03map]),
  review("d03", "portfolio-contradictions", "unknown", "Observed: the current /south-delivery passage conflicts with the approved policy record (persisted in the consolidated finding). Not resolved item-wide because /terms-v1 text and full page bodies were described but not supplied; the owner-described 2024 South same-day statement is date-scoped and is not counted as a contradiction.", [c("d03"), ids.d03entity, ids.d03map]),
  review("d04", "quality-claims", "fail", "The draft landing-page claim guarantees every team finishes setup in 10 minutes. The approved record supplies only a 15-minute median across 20 observed sessions and no guarantee, maximum or wider population estimate. The permissions FAQ component matches the approved permissions policy, and the /status-codes table is owner-confirmed complete and accurate for its declared task.", [c("d04"), ids.d04claims]),
  review("d04", "aeo-question-coverage", "pass", "The only supplied question, whether editors can delete the workspace, is answered directly by the FAQ. No questions are supplied for the landing-page claim or /status-codes, and none are invented, so those components have no bearing on this question-specific check.", [c("d04"), ids.d04questions]),
  review("d04", "aeo-answer-context", "pass", "The FAQ answer stands alone: it gives the negative answer and names the permitted role, and the approved policy states no additional conditions are needed for this permission question. The supplied task is identifying the permitted role, not the deletion procedure.", [c("d04"), ids.d04questions]),
  review("d04", "aeo-answer-evidence", "unknown", "The FAQ answer component is supported by the approved permissions policy. Item-wide verdict withheld: no supplied question or task establishes the landing-page setup-time claim as an answer claim, so its AEO applicability is unresolved; its lack of support is recorded under quality-claims.", [c("d04"), ids.d04claims]),
];

const finding = (f) => ({ ownerRole: "Content owner", effort: "small", classification: "observed", confidence: "high", action: "update", ...f });
const findings = [
  finding({
    findingId: "F1-fir-sso-absence",
    title: "Draft /compare assertion A denies Fir SSO against the supplied Fir SSO documentation",
    affectedItemIds: [item.d01],
    ruleIds: ["quality-claims", "aio-entity-consistency"],
    dimensions: ["quality", "aio"],
    evidenceIds: [c("d01"), ids.d01claims, ids.d01entity],
    severity: "high",
    actionReason: "A competitor capability is denied while the supplied documentation states it exists on one plan.",
    remediation: "Proposed: remove the no-SSO assertion and the pricing-table-proves reasoning from draft /compare. If SSO is discussed, state only what the supplied docs say: SAML SSO is available on Fir Enterprise with a minimum of 20 paid seats. Make no SSO statement about Fir's other plans unless the owner supplies a source.",
    verification: "Re-read the revised /compare draft against the supplied Fir SSO docs quotation at 01-competitor-claims.md:12-14 and confirm no absence claim relies on the pricing-table excerpt.",
  }),
  finding({
    findingId: "F2-cedar-every-billing-option",
    title: "Draft /compare assertion B says Cedar is cheaper on every billing option; the supplied annual figures show Fir lower",
    affectedItemIds: [item.d01],
    ruleIds: ["quality-claims", "aio-entity-consistency"],
    dimensions: ["quality", "aio"],
    evidenceIds: [c("d01"), ids.d01claims, ids.d01entity],
    severity: "high",
    actionReason: "The universal comparative claim is contradicted by one of the two supplied billing options.",
    remediation: "Proposed: limit the claim to monthly billing (Cedar USD 12 versus Fir USD 15 per seat per month), or state both options including that on annual billing Fir is USD 9 and Cedar USD 10 per seat per month equivalent. Keep the November 2026, US, USD before-tax scope.",
    verification: "Compare each billing option named in the revised sentence with the four supplied prices at 01-competitor-claims.md:6-9; the /monthly-comparison caption needs no change.",
  }),
  finding({
    findingId: "F3-october-cost-window-mismatch",
    title: "Draft A reports an October cost per conversion from full-month spend and seven days of conversions",
    affectedItemIds: [item.d02],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [c("d02"), ids.d02claims],
    severity: "high",
    ownerRole: "Reporting owner",
    actionReason: "Numerator and denominator cover different date windows, so the labeled monthly metric is unsupported.",
    remediation: "Proposed: withdraw the October figure. Report only the matched window already in the verified-window caption (October 1-7: USD 700 / 35 completed conversions = USD 20) and label October 8-31 cost per conversion unmeasured. A full-month figure cannot be computed from the supplied data.",
    verification: "In the revised sentence, confirm spend and conversions cover the same dates and recompute the quotient from the supplied rows at 02-measurement-windows.md:5-8.",
  }),
  finding({
    findingId: "F4-ai-sessions-extrapolation",
    title: "Draft B extrapolates 15 tracked AI-referrer sessions to 150 with an unsupported tracking rate and the word prove",
    affectedItemIds: [item.d02],
    ruleIds: ["quality-claims", "geo-observed-presence"],
    dimensions: ["quality", "geo"],
    evidenceIds: [c("d02"), ids.d02claims],
    severity: "medium",
    ownerRole: "Reporting owner",
    actionReason: "The descriptive count is supported; the total, the tracking rate and the causal wording are not.",
    remediation: "Proposed: state only the observation that 15 October sessions had an identified AI-assistant referrer and that other sessions have unknown origin. Remove the 150 total, the one-in-ten rate and the proof wording unless the owner supplies a documented estimation model or measured tracking rate. Do not combine with the campaign conversion counts.",
    verification: "Confirm every number in the revised sentence appears in the supplied referral report at 02-measurement-windows.md:14-16 and that no total, rate or causal claim remains without a supplied source.",
  }),
  finding({
    findingId: "F5-south-delivery-policy",
    title: "/south-delivery states same-day delivery; the current approved policy for South is next-business-day only",
    affectedItemIds: [item.d03],
    ruleIds: ["quality-claims", "aio-entity-consistency", "portfolio-contradictions"],
    dimensions: ["quality", "aio", "portfolio"],
    evidenceIds: [c("d03"), ids.d03claims, ids.d03entity, ids.d03map],
    severity: "high",
    actionReason: "A current customer-facing service promise conflicts with the approved policy for that region.",
    remediation: "Proposed: replace the /south-delivery policy passage with the approved South policy, next-business-day delivery only. Do not carry over the Monday-Friday or 10:00 wording unless the owner confirms South ordering conditions. Leave /north-delivery and the /terms-v1 archive unchanged and retain both regional pages.",
    verification: "Compare the revised /south-delivery passage with the approved policy at 03-template-service-area.md:4-5; confirm /north-delivery still matches and /terms-v1 remains labeled as the 2024 archive.",
  }),
  finding({
    findingId: "F6-setup-time-guarantee",
    title: "Draft landing-page claim guarantees 10-minute setup for every team; the record supports only a 15-minute median across 20 sessions",
    affectedItemIds: [item.d04],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [c("d04"), ids.d04claims],
    severity: "high",
    actionReason: "The guarantee, the universal scope and the 10-minute figure each lack a supplied source.",
    remediation: "Proposed: remove the guarantee, the every-team scope and the 10-minute figure. If a time is stated, use the supplied statistic with its scope: a median completion time of 15 minutes across 20 observed onboarding sessions in the supplied study. Leave the permissions FAQ and /status-codes unchanged.",
    verification: "Compare the revised claim with the approved product record at 04-editorial-proof.md:3-5 and confirm no guarantee, maximum or population-wide statement remains without an owner-supplied policy or study.",
  }),
];

await writeFile(
  path.join(work, "review.json"),
  JSON.stringify({ artifacts, evidence: added, reviews, findings }, null, 2) + "\n",
);

// Supplied measurement aggregates preserved as historical study sources.
async function study(sourceId, name, scope, ranges, limitations) {
  const sourceText = await readFile(path.join(project, "targets", name), "utf8");
  const lines = sourceText.split(/\r?\n/);
  return {
    sourceId,
    kind: "historical-study",
    locator: `targets/${name}`,
    sourceText,
    sourceHash: hash(sourceText),
    synthetic: true,
    scope,
    limitations,
    passages: ranges.map(([startLine, endLine]) => ({
      startLine,
      endLine,
      quote: lines.slice(startLine - 1, endLine).join("\n"),
    })),
  };
}
const options = {
  brandName: "Synthetic dossiers",
  studySources: [
    await study(
      "d02-campaign-and-referral-rows",
      names.d02,
      "Synthetic owner-supplied counts for one campaign in USD, October 2026: spend October 1-31, conversions October 1-7 only; separate referral report of October sessions with an identified AI-assistant referrer. Interface, locale and market not stated.",
      [[3, 8], [14, 16], [20, 21]],
      [
        "Not a live connector response; authenticity not verified",
        "Conversions for October 8-31 are missing, not zero",
        "Referral count has no complete session denominator, tracking-rate model or conversion linkage",
        "Campaign conversions and the referral report must not be combined",
        "No AI answer captures or citation annotations; no visibility rate can be derived",
      ],
    ),
    await study(
      "d04-onboarding-study",
      names.d04,
      "Synthetic owner-approved product record: 20 observed onboarding sessions in a supplied study; collection window, population and locale not stated.",
      [[3, 5]],
      [
        "Only a median is supplied; no maximum, percentile distribution or wider population estimate",
        "Collection window unknown",
        "Not AI visibility or search performance evidence",
      ],
    ),
  ],
};
await writeFile(path.join(work, "report-options.json"), JSON.stringify(options, null, 2) + "\n");

console.log(
  JSON.stringify(
    {
      wrote: ["review.json", "report-options.json"],
      reviewedAt: now,
      items: item,
      arithmetic: {
        "3000/35": Number((3000 / 35).toFixed(2)),
        "700/35": 700 / 35,
        "Fir monthly 15 - Cedar monthly 12": 15 - 12,
        "Cedar annual 10 - Fir annual 9": 10 - 9,
        "15 tracked x 10": 15 * 10,
        "October 8-31 day count": 31 - 8 + 1,
      },
    },
    null,
    2,
  ),
);
