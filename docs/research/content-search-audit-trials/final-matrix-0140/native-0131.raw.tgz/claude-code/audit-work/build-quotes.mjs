// Builds the quote ledger from every block-quote line in report.md.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const work = path.dirname(fileURLToPath(import.meta.url));
const project = path.dirname(work);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = await readFile(path.join(project, "report.md"));
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const quotes = [];
const unparsed = [];
const hashes = new Map();
for (const [index, line] of lines.entries()) {
  if (!line.startsWith(">")) continue;
  const match = /^> ([\w.-]+\.md):(\d+)(?:-(\d+))? — (.+)$/u.exec(line);
  if (!match) {
    unparsed.push(index + 1);
    continue;
  }
  const [, label, start, end, quote] = match;
  const source = `targets/${label}`;
  if (!hashes.has(source))
    hashes.set(source, hash(await readFile(path.join(project, source))));
  quotes.push({
    quoteId: `q${quotes.length + 1}-${label}-${start}`,
    source,
    sourceLabel: label,
    sourceHash: hashes.get(source),
    startLine: Number(start),
    endLine: Number(end ?? start),
    reportStartLine: index + 1,
    reportEndLine: index + 1,
    normalization: "whitespace",
    quote,
  });
}
// Any other double-quoted span in prose would be an unsubmitted quotation.
const proseQuoted = lines
  .map((line, index) => ({ line, n: index + 1 }))
  .filter(({ line }) => !line.startsWith(">") && /["“”]/u.test(line))
  .map(({ n }) => n);
await writeFile(
  path.join(work, "quotes.json"),
  JSON.stringify(
    { root: project, report: "report.md", reportHash: hash(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify(
    { quotes: quotes.length, unparsedBlockQuoteLines: unparsed, proseLinesWithQuoteMarks: proseQuoted },
    null,
    2,
  ),
);
