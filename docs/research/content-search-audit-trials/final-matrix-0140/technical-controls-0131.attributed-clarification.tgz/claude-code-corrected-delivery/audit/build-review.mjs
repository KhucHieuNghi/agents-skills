// Builds the review bundle from the collected snapshots of run-initial.
// Reads only audit artifacts; never modifies targets or the installed skill.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const run = path.join(here, "run-initial");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const evidence = (await readFile(path.join(run, "evidence.jsonl"), "utf8"))
  .split("\n")
  .filter((l) => l.trim())
  .map((l) => JSON.parse(l));
const routing = evidence.find((e) => e.locator.endsWith("01-routing.md"));
const markup = evidence.find((e) => e.locator.endsWith("02-markup.md"));
const R = routing.itemId;
const M = markup.itemId;
const rl = routing.value.split("\n");
const ml = markup.value.split("\n");
const span = (lines, a, b) => lines.slice(a - 1, b).join("\n");
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 (host agent, content-search-audit)";
const artifacts = {};
const added = [];
function add(id, source, kind, locator, value, limitations, method) {
  const json = typeof value !== "string";
  const bytes = json ? JSON.stringify(value, null, 2) + "\n" : value;
  const artifact = `evidence/${id}.${json ? "json" : "txt"}`;
  artifacts[artifact] = bytes;
  added.push({
    evidenceId: id,
    itemId: source.itemId,
    method,
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    redaction: "none; synthetic supplied content retained locally",
    limitations,
    kind,
    value,
    artifact,
    encoding: json ? "json" : "utf8",
    sourceEvidenceIds: [source.evidenceId],
  });
  return id;
}
const derived = "derived-from-supplied-dossier-snapshot";
const synthetic =
  "Synthetic owner-supplied dossier; not independently verified and not a live capture by this audit";

// ---- Item R: routing dossier ----
add(
  "routing-publisher-intent",
  routing,
  "publisher-intent",
  "targets/01-routing.md:5-10,55",
  `Owner-supplied context (verbatim lines 5-10):\n${span(rl, 5, 10)}\n\nOwner-supplied limit on action (verbatim line 55):\n${span(rl, 55, 55)}\n`,
  [
    synthetic,
    "Intent is dated 2026-11-16 by the owner; capture dates of the robots, HTTP and sitemap exports are not stated",
    "Intent is stated for Googlebot only; no intent is stated for other crawlers or AI surfaces",
  ],
  derived,
);
add(
  "routing-crawler-policy",
  routing,
  "crawler-policy",
  "targets/01-routing.md:12-20",
  `Supplied robots.txt export (verbatim lines 12-20):\n${span(rl, 12, 20)}\n\nAuditor reading (interpretation, not source text): the group naming Googlebot is the most specific match for Googlebot, so its only rule, Disallow: /guide/current, governs that agent; the wildcard group's Allow: / applies to agents without a more specific group. This is a reading of the supplied rules, not an observed Googlebot fetch.\n`,
  [
    synthetic,
    "Export capture date not stated; the live robots.txt was not fetched",
    "Rule evaluation shows permission only; it does not show that any crawler fetched or skipped a URL",
  ],
  derived,
);
add(
  "routing-canonical-targets",
  routing,
  "canonical-targets",
  "targets/01-routing.md:33,46,52-55",
  {
    declarations: [
      {
        page: "/guide/current",
        signal: "rel=canonical in supplied raw HTML",
        target: "https://routing.example.test/guide/2024",
        sourceLine: 33,
        verbatim: rl[32].trim(),
      },
      {
        page: "/guide/2024",
        signal: "self-canonical, as described in dossier narrative (raw HTML not supplied)",
        target: "/guide/2024",
        sourceLines: "52-53",
      },
    ],
    competingSignals: [
      {
        signal: "sitemap membership",
        url: "https://routing.example.test/guide/current",
        sourceLine: 46,
        verbatim: rl[45].trim(),
      },
      {
        signal: "redirect",
        observation: "No current-guide redirect is present in the supplied capture",
        sourceLines: "54-55",
      },
    ],
    ownerPreferredCurrentGuide: "/guide/current (owner statement dated 2026-11-16, line 5)",
    engineSelectedCanonical: "unknown; no Search Console or engine-selected canonical data supplied (lines 8-9)",
  },
  [
    synthetic,
    "Declared canonical only; engine-selected canonical is unknown",
    "Captured HTTP headers show only the status line and Content-Type; presence or absence of an HTTP Link canonical header beyond those lines is not established",
    "Raw source, not rendered DOM",
  ],
  derived,
);
add(
  "routing-http-response",
  routing,
  "http-response",
  "targets/01-routing.md:24-27,52",
  {
    status: 200,
    responses: [
      {
        url: "/guide/current",
        status: 200,
        surface: "supplied raw response capture, lines 24-27",
        verbatim: span(rl, 25, 26),
      },
      {
        url: "/guide/2024",
        status: 200,
        surface: "dossier narrative statement, line 52 (no raw response supplied)",
      },
    ],
    userAgent: "ordinary browser user agent, not Googlebot (lines 9-10)",
  },
  [
    synthetic,
    "Captured by a browser user agent; the response served to Googlebot is unknown",
    "Capture date not stated; HTTP 200 is not index evidence",
    "Aggregated record for two component pages that both report 200; the archive status is a narrative statement",
  ],
  derived,
);
add(
  "routing-inventory-map",
  routing,
  "inventory-map",
  "targets/01-routing.md:5-7,29-40,44-48,52-55",
  {
    scope: "Component pages described inside the single declared dossier item",
    components: [
      {
        url: "/guide/current",
        role: "approved current public product guide (owner, as of 2026-11-16)",
        inSuppliedSitemap: true,
        suppliedContent: "complete raw HTML fragment, lines 30-39",
        materialClaim: "Current entitlement: 3 seats.",
      },
      {
        url: "/guide/2024",
        role: "archived historical guide that must remain accessible and labelled; not the preferred current guide",
        inSuppliedSitemap: false,
        suppliedContent: "narrative description only, lines 52-55",
        materialClaim: "2024 archive — former entitlement: 2 seats.",
      },
    ],
  },
  [
    synthetic,
    "Map covers only pages described in the dossier; it does not establish the live site inventory or internal links",
    "Archive body is described, not supplied in full",
  ],
  derived,
);
add(
  "routing-entity-record",
  routing,
  "entity-record",
  "targets/01-routing.md:5-7,52-54",
  `Owner-supplied record used as the comparison basis (verbatim):\n${span(rl, 5, 7)}\n...\n${span(rl, 52, 54)}\n\nLimit: the owner approves /guide/current as the current guide and confirms the archive statement for its historical scope. No separate approved record of the current entitlement value is supplied.\n`,
  [
    synthetic,
    "Owner context is an approved comparison basis, not independent verification",
    "No dated approved record of the current entitlement quantity is supplied",
  ],
  derived,
);
add(
  "routing-claim-sources",
  routing,
  "claim-sources",
  "targets/01-routing.md:5,53-54",
  `Owner-supplied claim support (verbatim):\n${span(rl, 5, 5)}\n${span(rl, 53, 54)}\n\nCoverage: supports the archive's "former entitlement: 2 seats" statement for its explicit historical scope. Does not supply a source for the current guide's "Current entitlement: 3 seats."\n`,
  [
    synthetic,
    "No source supplied for the current entitlement value; that claim is unverifiable here, not false",
  ],
  derived,
);

// ---- Item M: markup dossier ----
function strictParse(text) {
  // Data-only syntax check of supplied JSON-LD text with the runtime's JSON parser.
  try {
    return { parses: true, value: JSON.parse(text) };
  } catch (error) {
    return { parses: false, error: String(error.message) };
  }
}
const blockA = span(ml, 14, 18);
const blockB = span(ml, 29, 33);
add(
  "markup-schema-extraction",
  markup,
  "schema-extraction",
  "targets/02-markup.md:13-19,28-34",
  {
    surface: "raw source blocks quoted in the dossier; not rendered DOM",
    pages: [
      {
        page: "Page A: current library overview",
        scriptLines: "13-19",
        jsonTextLines: "14-18",
        jsonText: blockA,
        strictJsonParse: strictParse(blockA),
        visibleHeading: "Cedar Library",
      },
      {
        page: "Page B: current export reference",
        scriptLines: "28-34",
        jsonTextLines: "29-33",
        jsonText: blockB,
        strictJsonParse: strictParse(blockB),
        visibleHeading: "Export reference",
      },
    ],
    parser: `Node.js ${process.version} JSON.parse on the quoted data text only; no target script was executed`,
  },
  [
    "Synthetic owner-supplied dossier; not a live capture by this audit",
    "Parse result is from one strict JSON parser; behaviour of any specific search or AI consumer was not observed",
    "No rendered snapshot, rich-result test or other markup format supplied",
  ],
  derived,
);
add(
  "markup-owner-context",
  markup,
  "owner-context",
  "targets/02-markup.md:3-5,37-40",
  `Owner-supplied context (verbatim lines 3-5):\n${span(ml, 3, 5)}\n\nOwner request (verbatim lines 37-40):\n${span(ml, 37, 40)}\n`,
  ["Synthetic owner-supplied statement; not independently verified"],
  derived,
);
add(
  "markup-http-response",
  markup,
  "http-response",
  "targets/02-markup.md:4",
  {
    status: 200,
    responses: [
      { page: "Page A", status: 200 },
      { page: "Page B", status: 200 },
    ],
    surface: "dossier narrative statement 'Both pages return HTTP 200.' (line 4); no raw response, URL, headers, user agent or capture date supplied",
  },
  [
    "Synthetic owner-supplied statement rather than a raw response capture",
    "HTTP 200 is not index evidence; headers and redirects unknown",
  ],
  derived,
);
add(
  "markup-locale-map",
  markup,
  "locale-map",
  "targets/02-markup.md:3",
  `Owner-supplied scope (verbatim line 3):\n${span(ml, 3, 3)}\n\nNo locale variants or alternate-language annotations are described for either page.\n`,
  [
    "Synthetic owner-supplied statement; the live site's locale structure was not inspected",
  ],
  derived,
);

const rv = (itemId, ruleId, status, reason, evidenceIds) => ({
  itemId,
  ruleId,
  status,
  reason,
  evidenceIds,
  reviewer,
  reviewedAt: now,
});
const rc = routing.evidenceId;
const mc = markup.evidenceId;
const reviews = [
  rv(
    R,
    "seo-index-controls",
    "fail",
    "Component /guide/current: the supplied robots.txt Googlebot group disallows /guide/current (01-routing.md:15-16) while the owner wants Googlebot to crawl the current guide (01-routing.md:7-8). The wildcard Allow: / group does not apply to Googlebot because a Googlebot-specific group exists. Clean components: no noindex/meta robots directive appears in the supplied current-guide raw HTML and no X-Robots-Tag appears in the two supplied header lines; the archive is reachable (200) as the owner requires. Unknown and not resolved here: index status, the response served to Googlebot, headers beyond those supplied, rendered directives.",
    [rc, "routing-http-response", "routing-publisher-intent", "routing-crawler-policy"],
  ),
  rv(
    R,
    "seo-canonical",
    "fail",
    "Component /guide/current: its supplied raw HTML declares rel=canonical to https://routing.example.test/guide/2024 (01-routing.md:33), the archive the owner says is not the preferred current guide (01-routing.md:5-7). Competing supplied signals: the sitemap lists /guide/current (01-routing.md:46) and no redirect is present. Clean component: the archive's self-canonical to /guide/2024 is consistent with keeping it as a labelled historical document. Engine-selected canonical is unknown.",
    [rc, "routing-canonical-targets", "routing-publisher-intent"],
  ),
  rv(
    R,
    "aio-crawler-policy",
    "fail",
    "Stated intended surface is Google crawling of the current guide via Googlebot; the supplied Googlebot group disallows that URL (01-routing.md:15-16 vs 7-8). Google AI features rely on Google Search crawling per the packaged method baseline (reviewed 2026-11-16, not re-fetched). Clean/unassessed components: other agents fall under User-agent: * Allow: / (01-routing.md:18-19); no owner intent is stated for AI-specific crawlers, so no defect or change is asserted for them. Permission is not evidence of any fetch, retrieval or citation.",
    ["routing-crawler-policy", "routing-publisher-intent"],
  ),
  rv(
    R,
    "portfolio-duplication",
    "pass",
    "The two described pages are distinct version variants, not duplicates: the current guide states 'Current entitlement: 3 seats.' and the archive is labelled '2024 archive — former entitlement: 2 seats.' The owner requires the archive to stay accessible and labelled. Both should be kept; no consolidation is proposed. Limit: the archive body is described rather than supplied in full; the contrary canonical declaration is handled under seo-canonical.",
    [rc, "routing-inventory-map"],
  ),
  rv(
    R,
    "portfolio-contradictions",
    "pass",
    "The differing entitlement values (3 seats current; 2 seats in the 2024 archive) are explicitly version-scoped, and the owner states the archive statement is accurate for its historical scope (01-routing.md:53-54), so they are not contradictory. Limit: assessment covers the material claims supplied in the dossier; the correctness of the current value against an approved record is not established (see quality-claims).",
    [rc, "routing-entity-record", "routing-inventory-map"],
  ),
  rv(
    R,
    "quality-claims",
    "unknown",
    "Archive claim 'former entitlement: 2 seats' is supported by the owner statement for its historical scope (clean component). The current guide's 'Current entitlement: 3 seats.' has no supplied approved record of the value; it is unverifiable here, not false. Needed: a dated approved entitlement record.",
    [rc, "routing-claim-sources"],
  ),
  rv(
    R,
    "quality-freshness",
    "unknown",
    "Both claims carry explicit version labels (current; 2024 archive), which is clean. Whether 3 seats is the current value, and when the supplied exports were captured relative to the owner's 2026-11-16 statement, is not established.",
    [rc, "routing-claim-sources"],
  ),
  rv(
    R,
    "aeo-answer-evidence",
    "unknown",
    "The only answer-like claim in the current guide is the entitlement value; its source support is not supplied and no question set establishes the answer task. Not assessed further.",
    [rc, "routing-claim-sources"],
  ),
  rv(
    R,
    "aio-entity-consistency",
    "unknown",
    "Visible facts are version-scoped and coherent across the two described pages (clean observation). No authoritative record of the current entitlement value is supplied, and the archive body is not supplied in full, so a full consistency verdict is not supported.",
    [rc, "routing-entity-record"],
  ),
  rv(
    M,
    "seo-structured-data",
    "fail",
    "Component Page A: the supplied JSON-LD object has a comma after its last member (\"name\": \"Cedar Library\",) directly before the closing brace (02-markup.md:14-18); JSON does not permit a trailing comma and a strict parse of the quoted text fails, so the block is not a correct machine-readable description as the owner asks (02-markup.md:37-38). Clean component Page B: its block (02-markup.md:29-33) parses, uses WebPage, and its name equals the visible heading 'Export reference'. No Product, FAQPage, review or rating markup is present or recommended. Unknown: rendered DOM, behaviour of specific consumers, rich-result eligibility (not requested).",
    [mc, "markup-schema-extraction", "markup-owner-context"],
  ),
  rv(
    M,
    "seo-locales",
    "not-applicable",
    "The owner states both pages belong to one English software documentation site (02-markup.md:3) and no locale variants or alternates are described, so there is no locale relationship to review in this item. This rests on the owner's statement; the live site was not inspected.",
    [mc, "markup-locale-map"],
  ),
];

const findings = [
  {
    findingId: "routing-googlebot-disallow-current-guide",
    title:
      "robots.txt disallows Googlebot from the current guide the owner wants Googlebot to crawl",
    affectedItemIds: [R],
    ruleIds: ["seo-index-controls", "aio-crawler-policy"],
    dimensions: ["seo", "aio"],
    evidenceIds: [rc, "routing-crawler-policy", "routing-publisher-intent", "routing-http-response"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "The supplied Googlebot rule directly contradicts the owner's stated crawl intent for /guide/current; one consolidated issue across SEO and AIO.",
    actionCondition:
      "the owner authorizes a robots.txt change in a separate implementation task (config edits are not currently authorized)",
    remediation:
      "Remove the 'Disallow: /guide/current' rule from the 'User-agent: Googlebot' group so that no rule disallows /guide/current for Googlebot. Do not change the wildcard group or add rules for other crawlers; no intent is stated for them. Keep /guide/2024 accessible.",
    verification:
      "Re-read the revised robots.txt export: select the group that applies to Googlebot and confirm no Disallow rule matches the path /guide/current. This confirms permission only. Whether Googlebot then fetches the page needs separately supplied evidence (server logs or a Search Console export), which is not available in this audit.",
    ownerRole: "Site/technical SEO owner",
    effort: "small",
  },
  {
    findingId: "routing-current-guide-canonical-to-archive",
    title:
      "Current guide declares the 2024 archive as its canonical, contrary to the owner's preferred current guide",
    affectedItemIds: [R],
    ruleIds: ["seo-canonical"],
    dimensions: ["seo"],
    evidenceIds: [rc, "routing-canonical-targets", "routing-publisher-intent"],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "The declared canonical names the archive the owner says is not the preferred current guide, and conflicts with the sitemap entry for /guide/current.",
    actionCondition:
      "the owner authorizes a change to the current guide's markup in a separate implementation task",
    remediation:
      "Change the rel=canonical on /guide/current to https://routing.example.test/guide/current. Leave the archive at /guide/2024 accessible, labelled and self-canonical; add no redirect and delete nothing.",
    verification:
      "Re-capture the raw HTML of /guide/current and confirm a single rel=canonical whose href is https://routing.example.test/guide/current; confirm the sitemap still lists /guide/current and the archive still returns 200 with its label and self-canonical. Engine-selected canonical remains unknown until engine data is supplied.",
    ownerRole: "Site/technical SEO owner",
    effort: "small",
  },
  {
    findingId: "markup-page-a-jsonld-trailing-comma",
    title: "Page A JSON-LD is not valid JSON (trailing comma after the name member)",
    affectedItemIds: [M],
    ruleIds: ["seo-structured-data"],
    dimensions: ["seo"],
    evidenceIds: [mc, "markup-schema-extraction", "markup-owner-context"],
    severity: "medium",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason:
      "The owner asks for correct machine-readable descriptions; Page A's block fails a strict JSON parse while Page B's is clean.",
    actionCondition:
      "the owner authorizes an edit to Page A's source in a separate implementation task",
    remediation:
      "On Page A, remove the comma after \"name\": \"Cedar Library\" so the object closes directly after that member. Keep @context https://schema.org, @type WebPage and the name matching the visible heading. Leave Page B unchanged. Do not add Product, FAQPage, review or rating markup.",
    verification:
      "Re-read the revised Page A raw source and parse the script block's text with a strict JSON parser; confirm it parses to an object with @context https://schema.org, @type WebPage and name 'Cedar Library' equal to the visible heading. Rendered output and any consumer-specific handling need a supplied rendered snapshot or test result.",
    ownerRole: "Documentation/web developer",
    effort: "small",
  },
];

await writeFile(
  path.join(here, "review.json"),
  JSON.stringify({ artifacts, evidence: added, reviews, findings }, null, 2) + "\n",
);
console.log(
  JSON.stringify(
    {
      written: "audit/review.json",
      reviewedAt: now,
      evidenceAdded: added.length,
      reviews: reviews.length,
      findings: findings.length,
      pageAParse: added.find((e) => e.evidenceId === "markup-schema-extraction").value.pages[0].strictJsonParse,
      pageBParse: added.find((e) => e.evidenceId === "markup-schema-extraction").value.pages[1].strictJsonParse,
    },
    null,
    2,
  ),
);
