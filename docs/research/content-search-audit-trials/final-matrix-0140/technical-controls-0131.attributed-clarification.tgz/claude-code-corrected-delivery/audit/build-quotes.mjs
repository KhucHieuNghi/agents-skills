// Builds the quote ledger from the final report.md: each [Qn] tag line carries a
// locator `file.md:a-b` and is followed by one fenced block holding the quotation.
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = await readFile(path.join(root, "report.md"));
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const sources = {};
const quotes = [];
for (let i = 0; i < lines.length; i++) {
  const tag = /^\[(Q\d+)\].*`(\d\d-[a-z]+\.md):(\d+)(?:-(\d+))?`$/.exec(lines[i]);
  if (!tag) continue;
  if (!lines[i + 1].startsWith("```")) throw new Error(`No fence after ${tag[1]}`);
  let end = i + 2;
  while (lines[end] !== "```") end++;
  const source = `targets/${tag[2]}`;
  sources[source] ??= hash(await readFile(path.join(root, source)));
  quotes.push({
    quoteId: tag[1],
    source,
    sourceLabel: tag[2],
    sourceHash: sources[source],
    startLine: Number(tag[3]),
    endLine: Number(tag[4] ?? tag[3]),
    reportStartLine: i + 1,
    reportEndLine: end + 1,
    normalization: "whitespace",
    quote: lines.slice(i + 2, end).join("\n"),
  });
}
const tags = lines.filter((l) => /^\[Q\d+\]/.test(l)).length;
if (tags !== quotes.length) throw new Error("Unparsed quote tag");
await writeFile(
  path.join(here, "quotes.json"),
  JSON.stringify(
    { root, report: "report.md", reportHash: hash(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, ids: quotes.map((q) => q.quoteId) }));
