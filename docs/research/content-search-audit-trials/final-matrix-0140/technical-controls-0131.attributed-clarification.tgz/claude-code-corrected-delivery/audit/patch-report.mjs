// One-off edit of the entry report: add the missing Q10 (H1) quotation block.
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const file = path.join(path.dirname(path.dirname(fileURLToPath(import.meta.url))), "report.md");
let text = await readFile(file, "utf8");
const edits = [
  [
    "[Q8] Archive and owner limits, `01-routing.md:52-55`",
    "[Q10] Current guide H1, `01-routing.md:36`\n```text\n<h1>Current product guide</h1>\n```\n\n[Q8] Archive and owner limits, `01-routing.md:52-55`",
  ],
  [
    "- Title (Q7) and the page's H1 carry the same wording and match the page's stated\n  role.",
    "- Title (Q7) and H1 (Q10) carry the same wording and match the page's stated\n  role.",
  ],
];
for (const [from, to] of edits) {
  if (text.split(from).length !== 2) throw new Error(`Expected exactly one match: ${from}`);
  text = text.replace(from, () => to);
}
await writeFile(file, text);
console.log(JSON.stringify({ edits: edits.length }));
