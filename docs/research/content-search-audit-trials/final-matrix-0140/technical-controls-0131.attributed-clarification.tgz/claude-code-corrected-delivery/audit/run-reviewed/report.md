# Synthetic dossiers — Content Search Audit

## Delivery summary

Partial\. 2 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:36:15\.869Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 0d1de2d3\-0fc7\-4f41\-ae5a\-d6bacc756080\. 3 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| routing\-current\-guide\-canonical\-to\-archive | Current guide declares the 2024 archive as its canonical, contrary to the owner&\#39;s preferred current guide | seo\-canonical | seo | high | high | observed | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | update | reviewer\-proposal | The declared canonical names the archive the owner says is not the preferred current guide, and conflicts with the sitemap entry for /guide/current\. | Only if the owner authorizes a change to the current guide&\#39;s markup in a separate implementation task: Change the rel=canonical on /guide/current to https://routing\.example\.test/guide/current\. Leave the archive at /guide/2024 accessible, labelled and self\-canonical; add no redirect and delete nothing\. | Only if the owner authorizes a change to the current guide&\#39;s markup in a separate implementation task: Re\-capture the raw HTML of /guide/current and confirm a single rel=canonical whose href is https://routing\.example\.test/guide/current; confirm the sitemap still lists /guide/current and the archive still returns 200 with its label and self\-canonical\. Engine\-selected canonical remains unknown until engine data is supplied\. | Site/technical SEO owner | small | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-canonical\-targets, routing\-publisher\-intent |
| routing\-googlebot\-disallow\-current\-guide | robots\.txt disallows Googlebot from the current guide the owner wants Googlebot to crawl | seo\-index\-controls, aio\-crawler\-policy | seo, aio | high | high | observed | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | update | reviewer\-proposal | The supplied Googlebot rule directly contradicts the owner&\#39;s stated crawl intent for /guide/current; one consolidated issue across SEO and AIO\. | Only if the owner authorizes a robots\.txt change in a separate implementation task \(config edits are not currently authorized\): Remove the &\#39;Disallow: /guide/current&\#39; rule from the &\#39;User\-agent: Googlebot&\#39; group so that no rule disallows /guide/current for Googlebot\. Do not change the wildcard group or add rules for other crawlers; no intent is stated for them\. Keep /guide/2024 accessible\. | Only if the owner authorizes a robots\.txt change in a separate implementation task \(config edits are not currently authorized\): Re\-read the revised robots\.txt export: select the group that applies to Googlebot and confirm no Disallow rule matches the path /guide/current\. This confirms permission only\. Whether Googlebot then fetches the page needs separately supplied evidence \(server logs or a Search Console export\), which is not available in this audit\. | Site/technical SEO owner | small | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-crawler\-policy, routing\-publisher\-intent, routing\-http\-response |
| markup\-page\-a\-jsonld\-trailing\-comma | Page A JSON\-LD is not valid JSON \(trailing comma after the name member\) | seo\-structured\-data | seo | medium | high | observed | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | update | reviewer\-proposal | The owner asks for correct machine\-readable descriptions; Page A&\#39;s block fails a strict JSON parse while Page B&\#39;s is clean\. | Only if the owner authorizes an edit to Page A&\#39;s source in a separate implementation task: On Page A, remove the comma after &quot;name&quot;: &quot;Cedar Library&quot; so the object closes directly after that member\. Keep @context https://schema\.org, @type WebPage and the name matching the visible heading\. Leave Page B unchanged\. Do not add Product, FAQPage, review or rating markup\. | Only if the owner authorizes an edit to Page A&\#39;s source in a separate implementation task: Re\-read the revised Page A raw source and parse the script block&\#39;s text with a strict JSON parser; confirm it parses to an object with @context https://schema\.org, @type WebPage and name &\#39;Cedar Library&\#39; equal to the visible heading\. Rendered output and any consumer\-specific handling need a supplied rendered snapshot or test result\. | Documentation/web developer | small | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b, markup\-schema\-extraction, markup\-owner\-context |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 2 | 6 | 0 |
| quality | 10 | 0 | 10 | 0 |
| seo | 16 | 5 | 10 | 1 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | pending | Snapshot review incomplete | 26 |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | quality\-claims | quality | unknown | Archive claim &\#39;former entitlement: 2 seats&\#39; is supported by the owner statement for its historical scope \(clean component\)\. The current guide&\#39;s &\#39;Current entitlement: 3 seats\.&\#39; has no supplied approved record of the value; it is unverifiable here, not false\. Needed: a dated approved entitlement record\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-claim\-sources |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | quality\-freshness | quality | unknown | Both claims carry explicit version labels \(current; 2024 archive\), which is clean\. Whether 3 seats is the current value, and when the supplied exports were captured relative to the owner&\#39;s 2026\-11\-16 statement, is not established\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-claim\-sources |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | routing\-http\-response |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-index\-controls | seo | fail | Component /guide/current: the supplied robots\.txt Googlebot group disallows /guide/current \(01\-routing\.md:15\-16\) while the owner wants Googlebot to crawl the current guide \(01\-routing\.md:7\-8\)\. The wildcard Allow: / group does not apply to Googlebot because a Googlebot\-specific group exists\. Clean components: no noindex/meta robots directive appears in the supplied current\-guide raw HTML and no X\-Robots\-Tag appears in the two supplied header lines; the archive is reachable \(200\) as the owner requires\. Unknown and not resolved here: index status, the response served to Googlebot, headers beyond those supplied, rendered directives\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-crawler\-policy, routing\-http\-response, routing\-publisher\-intent |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-canonical | seo | fail | Component /guide/current: its supplied raw HTML declares rel=canonical to https://routing\.example\.test/guide/2024 \(01\-routing\.md:33\), the archive the owner says is not the preferred current guide \(01\-routing\.md:5\-7\)\. Competing supplied signals: the sitemap lists /guide/current \(01\-routing\.md:46\) and no redirect is present\. Clean component: the archive&\#39;s self\-canonical to /guide/2024 is consistent with keeping it as a labelled historical document\. Engine\-selected canonical is unknown\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-canonical\-targets, routing\-publisher\-intent |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aio\-crawler\-policy | aio | fail | Stated intended surface is Google crawling of the current guide via Googlebot; the supplied Googlebot group disallows that URL \(01\-routing\.md:15\-16 vs 7\-8\)\. Google AI features rely on Google Search crawling per the packaged method baseline \(reviewed 2026\-11\-16, not re\-fetched\)\. Clean/unassessed components: other agents fall under User\-agent: \* Allow: / \(01\-routing\.md:18\-19\); no owner intent is stated for AI\-specific crawlers, so no defect or change is asserted for them\. Permission is not evidence of any fetch, retrieval or citation\. | routing\-crawler\-policy, routing\-publisher\-intent |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aio\-entity\-consistency | aio | unknown | Visible facts are version\-scoped and coherent across the two described pages \(clean observation\)\. No authoritative record of the current entitlement value is supplied, and the archive body is not supplied in full, so a full consistency verdict is not supported\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-entity\-record |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | aeo\-answer\-evidence | aeo | unknown | The only answer\-like claim in the current guide is the entitlement value; its source support is not supplied and no question set establishes the answer task\. Not assessed further\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-claim\-sources |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | routing\-claim\-sources |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: question\-set | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-inventory\-map |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | portfolio\-duplication | portfolio | pass | The two described pages are distinct version variants, not duplicates: the current guide states &\#39;Current entitlement: 3 seats\.&\#39; and the archive is labelled &\#39;2024 archive — former entitlement: 2 seats\.&\#39; The owner requires the archive to stay accessible and labelled\. Both should be kept; no consolidation is proposed\. Limit: the archive body is described rather than supplied in full; the contrary canonical declaration is handled under seo\-canonical\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-inventory\-map |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | portfolio\-contradictions | portfolio | pass | The differing entitlement values \(3 seats current; 2 seats in the 2024 archive\) are explicitly version\-scoped, and the owner states the archive statement is accurate for its historical scope \(01\-routing\.md:53\-54\), so they are not contradictory\. Limit: assessment covers the material claims supplied in the dossier; the correctness of the current value against an approved record is not established \(see quality\-claims\)\. | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0, routing\-entity\-record, routing\-inventory\-map |
| 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | markup\-http\-response |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-index\-controls | seo | unknown | Missing required evidence: publisher\-intent | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b, markup\-http\-response |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-structured\-data | seo | fail | Component Page A: the supplied JSON\-LD object has a comma after its last member \(&quot;name&quot;: &quot;Cedar Library&quot;,\) directly before the closing brace \(02\-markup\.md:14\-18\); JSON does not permit a trailing comma and a strict parse of the quoted text fails, so the block is not a correct machine\-readable description as the owner asks \(02\-markup\.md:37\-38\)\. Clean component Page B: its block \(02\-markup\.md:29\-33\) parses, uses WebPage, and its name equals the visible heading &\#39;Export reference&\#39;\. No Product, FAQPage, review or rating markup is present or recommended\. Unknown: rendered DOM, behaviour of specific consumers, rich\-result eligibility \(not requested\)\. | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b, markup\-owner\-context, markup\-schema\-extraction |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-locales | seo | not\-applicable | The owner states both pages belong to one English software documentation site \(02\-markup\.md:3\) and no locale variants or alternates are described, so there is no locale relationship to review in this item\. This rests on the owner&\#39;s statement; the live site was not inspected\. | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b, markup\-locale\-map |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |
| dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 63ae3154b92f430e024ffef07a639ccd290d4a2fab1343e6029362b79297aad0 | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | local\-file | 2026\-11\-18T08:32:21\.465Z | 0 full elapsed days | [evidence/27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200\.txt](evidence/27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 63c82cb738dac7882735da097e0cf6cfd91245f39680a31321b2c6bb50b6451b | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | local\-file | 2026\-11\-18T08:32:21\.467Z | 0 full elapsed days | [evidence/dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a\.txt](evidence/dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| routing\-publisher\-intent | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-publisher\-intent\.txt](evidence/routing-publisher-intent.txt) | bf0d8e3dbfd4a0dad4f57e60e5ea5baaec281b068266a2d5a97567fd396f3ce2 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Intent is dated 2026\-11\-16 by the owner; capture dates of the robots, HTTP and sitemap exports are not stated; Intent is stated for Googlebot only; no intent is stated for other crawlers or AI surfaces |
| routing\-crawler\-policy | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-crawler\-policy\.txt](evidence/routing-crawler-policy.txt) | 7e19a97ce5ad4b4cbdac7c06efb3d8d5e2d42b034d4a4c4ca2f711da9632a759 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Export capture date not stated; the live robots\.txt was not fetched; Rule evaluation shows permission only; it does not show that any crawler fetched or skipped a URL |
| routing\-canonical\-targets | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-canonical\-targets\.json](evidence/routing-canonical-targets.json) | fb1d64f32dccbe09460facda622cd784505a95a9774e92bd362c3357316b45f5 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Declared canonical only; engine\-selected canonical is unknown; Captured HTTP headers show only the status line and Content\-Type; presence or absence of an HTTP Link canonical header beyond those lines is not established; Raw source, not rendered DOM |
| routing\-http\-response | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-http\-response\.json](evidence/routing-http-response.json) | 13fd5d4befadae15bf6862a1de90e1ff55679b3e5ec958e8536492e8e48818bd | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Captured by a browser user agent; the response served to Googlebot is unknown; Capture date not stated; HTTP 200 is not index evidence; Aggregated record for two component pages that both report 200; the archive status is a narrative statement |
| routing\-inventory\-map | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-inventory\-map\.json](evidence/routing-inventory-map.json) | 399c80367a00b0cd60ed4d2847ee29e1ee21825ed9799f5e01bbcdbc3d10163c | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Map covers only pages described in the dossier; it does not establish the live site inventory or internal links; Archive body is described, not supplied in full |
| routing\-entity\-record | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-entity\-record\.txt](evidence/routing-entity-record.txt) | a3d4530fd124aa48386840d8d31117b12b684c57f842f383c1c76800cde2fb3f | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; Owner context is an approved comparison basis, not independent verification; No dated approved record of the current entitlement quantity is supplied |
| routing\-claim\-sources | 27de74b74d610a67e67a059f80e4d3e60cc7454ccef68cdbaea1ec9268494200 | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/routing\-claim\-sources\.txt](evidence/routing-claim-sources.txt) | c2f58703a1ee963c9843f785d353153c6926c995c0fd51b60bb4b04f8493a215 | Synthetic owner\-supplied dossier; not independently verified and not a live capture by this audit; No source supplied for the current entitlement value; that claim is unverifiable here, not false |
| markup\-schema\-extraction | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/markup\-schema\-extraction\.json](evidence/markup-schema-extraction.json) | 5c1d7dc5dbe8cff436569969a2d687efcae0b8442a7430217c0c64942ab288e4 | Synthetic owner\-supplied dossier; not a live capture by this audit; Parse result is from one strict JSON parser; behaviour of any specific search or AI consumer was not observed; No rendered snapshot, rich\-result test or other markup format supplied |
| markup\-owner\-context | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/markup\-owner\-context\.txt](evidence/markup-owner-context.txt) | 63c1a688c0aa32a8f41fc377956065b15f9790b4f4e50de84174f622780a71a9 | Synthetic owner\-supplied statement; not independently verified |
| markup\-http\-response | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/markup\-http\-response\.json](evidence/markup-http-response.json) | 87195f885e079c6acda528d0b6d99666e3ce99f863571ad3c2e5cf46bd35be5e | Synthetic owner\-supplied statement rather than a raw response capture; HTTP 200 is not index evidence; headers and redirects unknown |
| markup\-locale\-map | dea443ced41b1b38e9b3e0730215f58b00f072c464f2cb54649cb6e5b0bf838a | derived\-from\-supplied\-dossier\-snapshot | 2026\-11\-18T08:36:11\.906Z | 0 full elapsed days | [evidence/markup\-locale\-map\.txt](evidence/markup-locale-map.txt) | 9c9b517646f3383213f54251e500ba908959eed69ea4ba19634d550a47213e23 | Synthetic owner\-supplied statement; the live site&\#39;s locale structure was not inspected |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
