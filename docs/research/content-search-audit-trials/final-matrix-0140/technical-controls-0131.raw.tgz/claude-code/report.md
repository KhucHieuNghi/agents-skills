# Content search audit — routing and markup dossiers

Report date: 2026-11-18. Status: **partial** (validated; completion not allowed).
Both targets are synthetic, owner-supplied dossiers reviewed offline. They are
independent scenarios and are not compared with each other.

## 1. Summary

Validated coverage (from `audit/run-reviewed/coverage.json` and
`audit/validation.json`): 2 declared items; 0 fully audited; 2 pending; 0 failed,
0 blocked, 0 unsupported, 0 excluded. Both dossiers were read in full, but neither
counts as fully audited because required checks remain unresolved for lack of
evidence. No measurements were supplied or attached: no Search Console, GA4, Bing,
server-log or AI-response data. Missing measurements are unknown, not zero.

Of 52 planned checks (26 rules × 2 items): 4 fail, 4 pass, 1 not applicable,
43 unknown.

Three material findings are persisted (2 high, 1 medium). All are observed in the
supplied text, and all proposed actions are conditional on owner authorization:

| ID | Dossier | Finding | Dimensions | Severity |
| --- | --- | --- | --- | --- |
| F1 `routing-googlebot-disallow-current-guide` | 01-routing | robots.txt disallows Googlebot from the current guide the owner wants Googlebot to crawl | SEO + AIO (one consolidated issue) | high |
| F2 `routing-current-guide-canonical-to-archive` | 01-routing | Current guide declares the 2024 archive as its canonical | SEO | high |
| F3 `markup-page-a-jsonld-trailing-comma` | 02-markup | Page A JSON-LD is not valid JSON | SEO | medium |

No finding was raised for content quality, AEO, GEO or portfolio. Those dimensions
are either clean on the supplied evidence or unresolved (sections 5 and 6); none
was filled with a speculative defect.

## 2. Scope, sources and limits

- Declared inventory: `targets/01-routing.md` and `targets/02-markup.md`, each one
  inventory item. Each dossier describes several component pages; they stay one
  item each, and component-level results are reported below.
- Discovery is complete for the declared input set only. It says nothing about the
  completeness of either live site.
- Not done, by instruction: no URL was fetched, no credentials used, no target or
  skill file modified, no other skill invoked, no tool installed.
- Surfaces actually examined: owner-supplied text exports of robots.txt, one raw
  HTTP response with raw HTML, a sitemap fragment, two raw JSON-LD blocks, and
  owner narrative. No rendered DOM, no engine data, no live capture.
- Export capture dates are not stated in either dossier. The only source date is
  the owner's "As of 2026-11-16" statement in the routing dossier.
- Rule and method baselines are the packaged ones (reviewed 2026-11-16). Platform
  documentation was not re-read during this audit because network access is not
  authorized.

## 3. Material findings

### F1 — robots.txt disallows Googlebot from the current guide (SEO + AIO, high)

Affected: item `targets/01-routing.md`, component `/guide/current`.
Rules: `seo-index-controls` (fail), `aio-crawler-policy` (fail). This is one issue
recorded once; it is not counted separately per dimension.

[Q1] Owner intent, `01-routing.md:5-8`
```text
As of 2026-11-16, the approved public product guide is `/guide/current`. The archived `/guide/2024` must remain accessible as a clearly labeled historical document; it is not the preferred current guide. The owner wants Googlebot to crawl the current guide.
```

[Q2] Supplied robots.txt, Googlebot group, `01-routing.md:15-16`
```text
User-agent: Googlebot
Disallow: /guide/current
```

[Q3] Supplied robots.txt, wildcard group, `01-routing.md:18-19`
```text
User-agent: *
Allow: /
```

Rationale. A crawler follows the group that names it most specifically. Googlebot
therefore follows the group in Q2, whose only rule disallows the current guide; the
wildcard group in Q3 does not rescue it. That directly contradicts the intent in Q1.
The rule matches by path prefix, so it would also cover any URL beginning with that
path; no such URLs are supplied. The group-selection reading rests on the Robots
Exclusion Protocol as recalled, not on documentation re-read in this audit.

Why it is also an AIO issue. The packaged method baseline states that Google's AI
features rely on ordinary Google Search crawling, so the same rule is the access
barrier for that surface. No separate AI-specific defect exists.

What this does not establish. The disallow is a crawl permission. It does not show
that Googlebot attempted or skipped a fetch, and it does not show whether the URL
is indexed. See Q9 in section 5 for the user agent of the captured response.

Proposed action — only if the owner authorizes a robots.txt change in a separate
implementation task (config edits are not currently authorized, see Q8): remove
the disallow rule shown in Q2 from the Googlebot group so that no rule disallows
the current guide for Googlebot. Leave the wildcard group alone and add no rules
for other crawlers; no intent is stated for them. Keep the archive accessible.

Verification, under the same condition: re-read the revised robots.txt export,
select the group that applies to Googlebot and confirm no Disallow rule matches
the current-guide path. This confirms permission only. Whether Googlebot then
fetches the page needs separately supplied evidence such as server logs or a
Search Console export; neither is available here.

### F2 — Current guide declares the 2024 archive as canonical (SEO, high)

Affected: item `targets/01-routing.md`, component `/guide/current`.
Rule: `seo-canonical` (fail). Owner intent is Q1 above.

[Q4] Current guide raw HTML, `01-routing.md:33`
```text
<link rel="canonical" href="https://routing.example.test/guide/2024" />
```

[Q5] Sitemap export, `01-routing.md:46`
```text
<url><loc>https://routing.example.test/guide/current</loc></url>
```

Rationale. The current guide's own markup (Q4) names the archive as the preferred
URL, while the owner says the archive is not the preferred current guide (Q1). The
supplied signals also disagree with each other: the sitemap (Q5) lists the current
guide, and no redirect is present (Q8). The two pages are not duplicates either;
they carry different entitlement statements (Q6, Q8).

Relationship to F1. These are separate defects with separate fixes. They interact:
a crawler honoring the disallow in Q2 does not fetch the HTML that carries Q4, so
fixing F1 alone would expose the contrary canonical to Googlebot. Plan both
together.

What this does not establish. This is the declared canonical in raw source. Which
URL any engine selected is unknown (Q9). Only the status line and Content-Type
header are supplied, so a canonical in an HTTP Link header is neither shown nor
ruled out.

Proposed action — only if the owner authorizes a change to the current guide's
markup in a separate implementation task: point the current guide's rel=canonical
at `https://routing.example.test/guide/current` (proposed value, not a quotation).
Leave the archive accessible, labelled and self-canonical. Add no redirect and
delete nothing.

Verification, under the same condition: re-capture the current guide's raw HTML and
confirm a single rel=canonical with that href; confirm the sitemap still lists the
current guide and the archive still returns 200 with its label and self-canonical.
The engine-selected canonical stays unknown until engine data is supplied.

### F3 — Page A JSON-LD is not valid JSON (SEO, medium)

Affected: item `targets/02-markup.md`, component Page A (current library overview).
Rule: `seo-structured-data` (fail). Page B is clean (section 5).

[Q11] Page A raw source block, `02-markup.md:13-19`
```text
<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Cedar Library",
  }
</script>
```

[Q15] Owner request, `02-markup.md:37-40`
```text
The owner asks for correct machine-readable descriptions of these documentation pages. They have not requested Product, FAQPage, reviews, ratings or eligibility for a specific Google rich result. No other markup formats or rendered snapshots are supplied. Do not treat the documentation pages as product offers.
```

Rationale. In Q11 a comma follows the last member, directly before the closing
brace. JSON does not allow a trailing comma. A strict parse of the quoted data text
fails (Node.js `JSON.parse`: "Expected double-quoted property name in JSON at
position 97 (line 5 column 3)"; data was parsed as text, no target script was run).
A block that does not parse is not the correct machine-readable description the
owner asks for in Q15. The vocabulary itself is fine: the type and name match the
visible heading (Q13).

Severity is medium rather than high: the defect defeats the owner's stated goal for
one of two pages, but no search or AI consequence was measured and no rich-result
eligibility was requested.

What this does not establish. How any specific search or AI consumer handles the
malformed block was not observed. The rendered DOM was not supplied.

Proposed action — only if the owner authorizes an edit to Page A's source in a
separate implementation task: remove the comma after the name member so the object
closes directly after it. Keep the context, the WebPage type and the name. Leave
Page B unchanged. Do not add Product, FAQPage, review or rating markup.

Verification, under the same condition: re-read the revised Page A raw source and
parse the block's text with a strict JSON parser; confirm an object with the
schema.org context, type WebPage and a name equal to the visible heading. Rendered
output and consumer-specific handling need a supplied rendered snapshot or test
result. No named validation tool is prescribed, since tool availability could not
be checked offline.

## 4. Persisted backlog reconciliation

The three findings above match `audit/run-reviewed/findings.json` and
`audit/run-reviewed/content-actions.csv` by ID. Each carries its condition as
`actionCondition`. Nothing in the backlog has been implemented.

## 5. Clean cases

Routing dossier:

[Q6] Current guide body claim, `01-routing.md:37`
```text
<p>Current entitlement: 3 seats.</p>
```

[Q7] Current guide title, `01-routing.md:32`
```text
<title>Current product guide</title>
```

[Q10] Current guide H1, `01-routing.md:36`
```text
<h1>Current product guide</h1>
```

[Q8] Archive and owner limits, `01-routing.md:52-55`
```text
The archive returns HTTP 200 and visibly states “2024 archive — former entitlement: 2 seats.” Its self-canonical names `/guide/2024`. The archive statement is accurate for its explicit historical scope. No current-guide redirect is present in the supplied capture. The owner has not authorized deletion, redirects or config edits.
```

- Archive page: reachable, visibly labelled as a 2024 archive, self-canonical and
  accurate for its historical scope per the owner (Q8). This matches the owner's
  requirement in Q1. No change is proposed, and it must not be redirected or removed.
- 3 seats versus 2 seats is not a contradiction. The values are version-scoped
  (Q6 current, Q8 archive). `portfolio-contradictions` passes and
  `portfolio-duplication` passes: these are legitimate version variants to keep.
- Sitemap entry (Q5) is consistent with owner intent. The archive's absence from
  the supplied sitemap fragment is not a defect given it is not the preferred guide.
- Wildcard robots group (Q3): no defect asserted. No owner intent is stated for
  other crawlers, so no change is recommended.
- No noindex or meta robots directive appears in the supplied current-guide HTML,
  and none appears in the two supplied header lines.
- Title (Q7) and H1 (Q10) carry the same wording and match the page's stated
  role. This is an observation; `seo-metadata` stays unknown (section 6).
- `seo-response` passes for both dossiers on the supplied 200 statuses. For the
  routing dossier this is a browser-agent capture, not Googlebot (Q9).

Markup dossier:

[Q12] Page B raw source block, `02-markup.md:28-34`
```text
<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Export reference"
  }
</script>
```

[Q13] Page A visible text, `02-markup.md:9-10`
```text
Visible heading: “Cedar Library”. Visible text: “Reference documentation for Cedar Library, maintained by Cedar Tools.”
```

[Q14] Page B visible text, `02-markup.md:24-25`
```text
Visible heading: “Export reference”. Visible text: “Export reference for Cedar Library.”
```

- Page B: the block (Q12) parses as JSON, uses WebPage, and its name equals the
  visible heading (Q14). Clean; no change proposed.
- Neither page carries Product, FAQPage, review or rating markup, which matches the
  owner's instruction (Q15). None is recommended.
- The minimal WebPage description is sufficient for the stated request. Adding
  further properties would be optional and is not a finding.
- `seo-locales` is not applicable to this dossier: the owner describes one English
  site (Q16) and no locale variants.

## 6. Uncertain and unresolved

[Q9] Routing measurement limits, `01-routing.md:8-10`
```text
No Search Console or engine-selected canonical data is available. HTTP responses below were captured by an ordinary browser user agent, not Googlebot.
```

[Q16] Markup measurement limits, `02-markup.md:3-5`
```text
All evidence is synthetic and belongs to one English software documentation site. Offline review only; do not fetch schemas or URLs. Both pages return HTTP 200. No rich-result testing, indexed state or AI-answer observations are supplied.
```

- Whether "3 seats" is correct (Q6): unverifiable here, not false. The owner
  approves the guide URL but supplies no dated record of the entitlement value.
  `quality-claims`, `quality-freshness` and `aeo-answer-evidence` stay unknown.
- What Googlebot is actually served, whether either URL is indexed, and which
  canonical any engine selected: unknown (Q9).
- Whether the exports still reflect the site as of the owner's 2026-11-16
  statement: unknown; no capture dates are given.
- `aio-entity-consistency` (routing): supplied facts are coherent and
  version-scoped, but no authoritative record of the current value exists and the
  archive body is described rather than supplied. Left unknown.
- Rendered state of all pages, including whether scripts alter the JSON-LD:
  unknown; no rendered DOM supplied.
- Markup dossier canonical, index controls, crawler policy, internal links and
  metadata: no evidence supplied; unknown. Page titles are not supplied.
- Audience context and real user questions are absent from both dossiers, so task
  fit, metadata fit, retrievable-facts and AEO question coverage/context are
  unknown. No questions were invented.
- `quality-readable-text` is unknown for both items: no separate text extraction of
  the described pages was supplied, and the dossier was not relabelled as one.
- `quality-accessible-media`: no media inventory supplied; unknown.

## 7. Dimension summary

Counts are checks across both items, from validated coverage.

| Dimension | Checks | Pass/fail assessed | Not applicable | Unknown | Result |
| --- | --- | --- | --- | --- | --- |
| Content quality | 10 | 0 | 0 | 10 | No defect observed; claims unverifiable without an approved record |
| SEO | 16 | 5 | 1 | 10 | F1, F2, F3; response checks pass |
| AIO | 6 | 1 | 0 | 5 | F1 (shared with SEO); no AI-specific measurement |
| AEO | 6 | 0 | 0 | 6 | No question set supplied |
| GEO | 6 | 0 | 0 | 6 | No AI observations; unmeasured, not zero |
| Portfolio | 8 | 2 | 0 | 6 | Routing variants clean; markup dossier lacks evidence |

"AIO" here means AI search optimization generally, not the Google product named
AI Overviews. No overall score is given and no ranking or citation outcome is
forecast.

## 8. Missing measurements

Not supplied for either dossier: Search Console or other engine exports, analytics,
Bing data, server logs, AI response observations, rendered snapshots, link graphs,
audience or question evidence, rich-result test results. Consequently there are no
measured rankings, crawl events, index states, mentions or citations in this
report.

## 9. Recovery path

To resolve the 43 unknown checks, supply (per dossier as relevant): a dated approved
entitlement record; export capture dates; a Googlebot-agent or server-log view of
the current guide; engine-selected canonical data; rendered snapshots; an internal
link graph; audience and real question evidence; a media inventory; and, for GEO,
response-level AI observations with prompts, surfaces and dates. Then refresh the
run, re-review and re-validate. The audit must not be described as complete before
the validator allows completion.

## 10. Artifacts

- Packaged run (final revision): `audit/run-reviewed/` — `report.md`,
  `report.html`, `coverage.json`, `content-actions.csv`, `delivery-summary.md`,
  `findings.json`, `checks.jsonl`, `inventory.jsonl`, `evidence.jsonl`,
  `evidence/`, `run.json`, `config.json`.
- Initial collection run (unchanged): `audit/run-initial/`.
- Validation receipt: `audit/validation.json` (valid: true; completionAllowed:
  false; errors: none).
- Review bundle and its generator: `audit/review.json`, `audit/build-review.mjs`.
- Quote ledger and receipt: `audit/quotes.json`, `audit/quote-receipt.json`.

## 11. Quote verification

The 16 source quotations in this report are the fenced blocks tagged Q1–Q16. All
16 were submitted to the packaged quote verifier against their cited line ranges;
the receipt is `audit/quote-receipt.json`. The receipt covers submitted spans only
and does not certify that a quotation supports its finding. Short strings elsewhere
in this report (the parser error message, the proposed canonical value, rule and
finding IDs) are not source quotations.
