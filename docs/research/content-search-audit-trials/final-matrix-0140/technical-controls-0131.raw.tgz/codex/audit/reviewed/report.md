# Content audit — Content Search Audit

## Delivery summary

Partial\. 2 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:33:42\.694Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 7a4e66c3\-651b\-4ff0\-aded\-a0fb2c4c7f1a\. 3 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| routing\-canonical | Current guide declares the historical archive as canonical | seo\-canonical | seo | high | high | observed | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | update | reviewer\-proposal | Current guide declares the historical archive as canonical | Have the site owner make the current guide declare its approved current URL as canonical while preserving the historical guide and its self\-canonical\. | Compare a revised raw current response, sitemap and archive response for agreement with the approved current and historical roles\. Evaluate engine selection only with separate evidence\. | Site routing owner | small | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-canonical\-targets, routing\-publisher\-intent |
| routing\-googlebot\-access | Googlebot policy blocks the approved current guide | aio\-crawler\-policy | aio | high | high | observed | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | update | reviewer\-proposal | Googlebot policy blocks the approved current guide | Have the routing owner review and narrowly revise the Googlebot rules so the approved current path is allowed\. | Evaluate the exact current URL against the effective Googlebot group in a revised robots export\. Use separately supplied bot or engine evidence to evaluate subsequent crawling\. | Site routing owner | small | routing\-crawler\-policy, routing\-publisher\-intent |
| markup\-json\-syntax | Page A WebPage JSON\-LD fails strict parsing | seo\-structured\-data | seo | medium | high | observed | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | update | reviewer\-proposal | Page A WebPage JSON\-LD fails strict parsing | Remove the trailing comma after Page A&\#39;s final name property, preserving the generic documentation description\. | Parse the revised extracted JSON\-LD block with a strict JSON parser and compare its type and name with the visible overview\. Page B is a valid syntax comparison\. | Documentation template owner | small | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-schema\-extraction, markup\-publisher\-intent |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 0 | 6 | 0 |
| aio | 6 | 1 | 5 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 3 | 5 | 0 |
| quality | 10 | 2 | 8 | 0 |
| seo | 16 | 4 | 12 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | pending | Snapshot review incomplete | 26 |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | markup\-extracted\-text |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | markup\-http\-response |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-index\-controls | seo | unknown | Semantic review and applicability assessment required | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-http\-response, markup\-publisher\-intent |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-structured\-data | seo | fail | Page A has an illegal trailing comma after its final property, so its supplied JSON\-LD fails strict JSON parsing\. Page B parses, and its WebPage name matches its visible title\. | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-publisher\-intent, markup\-schema\-extraction |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy | markup\-publisher\-intent |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: question\-set | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-inventory\-map |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | portfolio\-duplication | portfolio | pass | The declared pair serves distinct library overview and export reference tasks\. | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-inventory\-map |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c, markup\-inventory\-map |
| 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | routing\-extracted\-text |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-response | seo | pass | Captured HTTP status 200; this does not establish index status or rendered content\. Nonfinal responses require follow\-up\. | routing\-http\-response |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-index\-controls | seo | unknown | Semantic review and applicability assessment required | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-http\-response, routing\-publisher\-intent |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-canonical | seo | fail | The approved current guide and sitemap point to /guide/current, while the current guide canonical points to the distinct 2024 archive\. The archive self\-canonical is consistent with its historical role\. | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-canonical\-targets, routing\-publisher\-intent |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aio\-crawler\-policy | aio | fail | The specifically matching Googlebot group disallows /guide/current against the stated intent\. The wildcard Allow does not override that group\. | routing\-crawler\-policy, routing\-publisher\-intent |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aio\-entity\-consistency | aio | unknown | Semantic review and applicability assessment required | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-entity\-record |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: question\-set | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-inventory\-map |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | portfolio\-duplication | portfolio | pass | The declared guide pair serves separate current and explicitly historical tasks\. | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-inventory\-map |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | portfolio\-contradictions | portfolio | pass | The two disclosed entitlement statements have distinct current and historical scopes\. The canonical issue is tracked separately as a technical signal conflict\. | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df, routing\-entity\-record, routing\-inventory\-map |
| b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 6be6dd618d0da1b5775f891ead6022d0f9c8c7b4e50baf46a0d647af6a87127c | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | local\-file | 2026\-11\-18T08:31:50\.224Z | 0 full elapsed days | [evidence/30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e\.txt](evidence/30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 273eec7686ff1202cabcfb786e870e087d6d906d2448341a148c33e54f8768df | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | local\-file | 2026\-11\-18T08:31:50\.225Z | 0 full elapsed days | [evidence/b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11\.txt](evidence/b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| markup\-extracted\-text | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/markup\-extracted\-text\.txt](evidence/markup-extracted-text.txt) | dc487c1fb9c61fcf7e21cb6c2eb7858b2363290f405a4a5f71482a536e288404 | Verbatim UTF\-8 dossier text\. No page rendering or independent page extraction\. |
| markup\-http\-response | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/markup\-http\-response\.json](evidence/markup-http-response.json) | 2bbd04195f449517ac29f3531b4d3a5e1fa03662fb4940a51844a9ddd28ef1ae | Both statuses are reported by the dossier; user agent, response headers and capture date unspecified\. |
| markup\-inventory\-map | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/markup\-inventory\-map\.txt](evidence/markup-inventory-map.txt) | ca5a8feac42db064cd07614b30f49734661b6d5dc2c440b96a658e58108e190b | Only the supplied scenario components; live site inventory unverified\. |
| markup\-schema\-extraction | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/markup\-schema\-extraction\.txt](evidence/markup-schema-extraction.txt) | 0be6f65dda3ffc237020183c50a3b9392940e10874e00462649ebeeffcd2f2d0 | Only the supplied raw blocks\. JSON syntax checked locally; no vocabulary fetch, rendered markup or engine tests\. |
| markup\-publisher\-intent | 30bba57fa3dac2ec24d31e95de5a73e7936b6addedbc2bccb4180c26bb221f4e | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/markup\-publisher\-intent\.txt](evidence/markup-publisher-intent.txt) | 7638d29b8e0bf1d8fcb41368d1cd55a829f1d80bd0ecbb478c6d8de0c944119a | Owner&\#39;s synthetic scope for generic documentation descriptions\. |
| routing\-extracted\-text | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-extracted\-text\.txt](evidence/routing-extracted-text.txt) | 6b0fd67da10ee0796c1bb35d156f209032a7f7780fa04e9c2553c3969bf85ba8 | Verbatim UTF\-8 dossier text\. No page rendering or independent page extraction\. |
| routing\-http\-response | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-http\-response\.json](evidence/routing-http-response.json) | 2039831f4e80b887bd29ad7e104b0d8ecd9691cbc8ceec636a50bdd65f81e401 | Both guide statuses are supplied ordinary\-browser observations; capture date unspecified\. |
| routing\-inventory\-map | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-inventory\-map\.txt](evidence/routing-inventory-map.txt) | 9bcbbf7321b8232f855c43b0d5636734b95b5b8f06dfe948aecf8d1d11f8d54d | Only the supplied scenario components; live site inventory unverified\. |
| routing\-publisher\-intent | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-publisher\-intent\.txt](evidence/routing-publisher-intent.txt) | 5cd80e4fe7f9bef65757e1a2292e53df1899a361adb0d6a1bae9f68232f29a57 | Synthetic owner context as of 2026\-11\-16; this is not a capture date\. |
| routing\-crawler\-policy | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-crawler\-policy\.txt](evidence/routing-crawler-policy.txt) | 78689a7ff9bac1dda21bb33c160896e610763d51a9aa6d9cbf4e4b150ea3b545 | Supplied robots snapshot; no live request or bot behavior observed\. |
| routing\-canonical\-targets | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-canonical\-targets\.txt](evidence/routing-canonical-targets.txt) | f79af56e4412b4d052263a5178636945a94717cf1520acc72610d71df30c71b8 | Supplied raw current canonical, sitemap entry and reported archive self\-canonical; engine selection unavailable\. |
| routing\-entity\-record | b42bbc33525a8840bbad9527f71ca2d3a968af8b9282738cc201c7233c310e11 | offline\-dossier\-derivation | 2026\-11\-18T08:33:42\.577Z | 0 full elapsed days | [evidence/routing\-entity\-record\.txt](evidence/routing-entity-record.txt) | 68d75d33f743695f7c8187e08d34be97d5dc3e7ecdfb774c64a75c4eb879e7c1 | Current seat count appears in the guide only; no independent dated current entitlement record\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
