const fs = require("node:fs");
const crypto = require("node:crypto");
const snapshots = fs.readFileSync("audit/collected/evidence.jsonl", "utf8")
  .trim().split("\n").map(JSON.parse);
const now = new Date().toISOString();
const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };

for (const snapshot of snapshots) {
  const routing = snapshot.locator.endsWith("01-routing.md");
  const file = routing ? "01-routing.md" : "02-markup.md";
  const prefix = routing ? "routing" : "markup";
  const ids = { content: snapshot.evidenceId };
  const raw = fs.readFileSync("audit/collected/" + snapshot.artifact, "utf8");
  const lines = raw.split("\n");
  const span = (first, last) => lines.slice(first - 1, last).join("\n");
  function add(kind, range, value, limitation, encoding = "utf8") {
    const evidenceId = prefix + "-" + kind;
    const artifact = "evidence/" + evidenceId + (encoding === "json" ? ".json" : ".txt");
    const bytes = encoding === "json" ? JSON.stringify(value) : value;
    bundle.artifacts[artifact] = bytes;
    bundle.evidence.push({
      evidenceId, itemId: snapshot.itemId, kind, artifact, encoding, value,
      method: "offline-dossier-derivation", collectedAt: now,
      locator: file + ":" + range, redaction: "none", limitations: [limitation],
      snapshotHash: crypto.createHash("sha256").update(bytes).digest("hex"),
      byteLength: Buffer.byteLength(bytes), sourceEvidenceIds: [snapshot.evidenceId],
    });
    ids[kind] = evidenceId;
  }
  function review(ruleId, status, reason, ...kinds) {
    bundle.reviews.push({ itemId: snapshot.itemId, ruleId, status, reason,
      evidenceIds: kinds.map(k => ids[k]), reviewedAt: now, reviewer: "Offline audit reviewer" });
  }
  function finding(findingId, title, ruleIds, dimensions, severity, remediation, verification, ownerRole, ...kinds) {
    bundle.findings.push({ findingId, title, affectedItemIds: [snapshot.itemId], ruleIds,
      dimensions, severity, remediation, verification, ownerRole, effort: "small",
      evidenceIds: kinds.map(k => ids[k]), classification: "observed", confidence: "high",
      action: "update", actionReason: title });
  }
  add("extracted-text", "1-" + lines.filter((_, i) => i < lines.length - 1 || lines[i]).length,
    raw, "Verbatim UTF-8 dossier text. No page rendering or independent page extraction.");
  add("http-response", routing ? "8-10,24-27,50-55" : "3-5",
    { status: 200, components: routing ? ["/guide/current", "/guide/2024"] : ["Page A", "Page B"] },
    routing ? "Both guide statuses are supplied ordinary-browser observations; capture date unspecified." :
      "Both statuses are reported by the dossier; user agent, response headers and capture date unspecified.", "json");
  add("inventory-map", routing ? "5-10,22-55" : "7-40",
    routing ? "Current public guide: current entitlement reference. Historical guide: 2024 entitlement reference. Robots and sitemap are supporting exports." :
      "Page A: Cedar Library overview. Page B: Cedar Library export reference. Both English documentation; URLs unspecified.",
    "Only the supplied scenario components; live site inventory unverified.");
  review("portfolio-duplication", "pass", routing ?
    "The declared guide pair serves separate current and explicitly historical tasks." :
    "The declared pair serves distinct library overview and export reference tasks.", "content", "inventory-map");
  if (routing) {
    add("publisher-intent", "5-10,50-55", span(5,10) + "\n" + span(50,55),
      "Synthetic owner context as of 2026-11-16; this is not a capture date.");
    add("crawler-policy", "12-20", span(15,19), "Supplied robots snapshot; no live request or bot behavior observed.");
    add("canonical-targets", "22-55", span(22,55), "Supplied raw current canonical, sitemap entry and reported archive self-canonical; engine selection unavailable.");
    add("entity-record", "5-10,35-37,50-55", span(5,10) + "\n" + span(35,37) + "\n" + span(50,55),
      "Current seat count appears in the guide only; no independent dated current entitlement record.");
    review("aio-crawler-policy", "fail", "The specifically matching Googlebot group disallows /guide/current against the stated intent. The wildcard Allow does not override that group.", "crawler-policy", "publisher-intent");
    review("seo-canonical", "fail", "The approved current guide and sitemap point to /guide/current, while the current guide canonical points to the distinct 2024 archive. The archive self-canonical is consistent with its historical role.", "content", "canonical-targets", "publisher-intent");
    review("portfolio-contradictions", "pass", "The two disclosed entitlement statements have distinct current and historical scopes. The canonical issue is tracked separately as a technical signal conflict.", "content", "entity-record", "inventory-map");
    finding("routing-googlebot-access", "Googlebot policy blocks the approved current guide",
      ["aio-crawler-policy"], ["aio"], "high",
      "Have the routing owner review and narrowly revise the Googlebot rules so the approved current path is allowed.",
      "Evaluate the exact current URL against the effective Googlebot group in a revised robots export. Use separately supplied bot or engine evidence to evaluate subsequent crawling.",
      "Site routing owner", "crawler-policy", "publisher-intent");
    finding("routing-canonical", "Current guide declares the historical archive as canonical",
      ["seo-canonical"], ["seo"], "high",
      "Have the site owner make the current guide declare its approved current URL as canonical while preserving the historical guide and its self-canonical.",
      "Compare a revised raw current response, sitemap and archive response for agreement with the approved current and historical roles. Evaluate engine selection only with separate evidence.",
      "Site routing owner", "content", "canonical-targets", "publisher-intent");
  } else {
    const a = span(14,18);
    const b = span(29,33);
    let aValid = true;
    try { JSON.parse(a); } catch (error) {
      if (!(error instanceof SyntaxError)) throw error;
      aValid = false;
    }
    if (aValid || JSON.parse(b).name !== "Export reference") throw Error("Reassess source");
    add("schema-extraction", "9-34", JSON.stringify({
      A: { json: a, parses: false }, B: { json: b, parses: true },
    }, null, 2), "Only the supplied raw blocks. JSON syntax checked locally; no vocabulary fetch, rendered markup or engine tests.");
    add("publisher-intent", "37-40", span(37,40), "Owner's synthetic scope for generic documentation descriptions.");
    review("seo-structured-data", "fail", "Page A has an illegal trailing comma after its final property, so its supplied JSON-LD fails strict JSON parsing. Page B parses, and its WebPage name matches its visible title.", "content", "schema-extraction", "publisher-intent");
    finding("markup-json-syntax", "Page A WebPage JSON-LD fails strict parsing",
      ["seo-structured-data"], ["seo"], "medium",
      "Remove the trailing comma after Page A's final name property, preserving the generic documentation description.",
      "Parse the revised extracted JSON-LD block with a strict JSON parser and compare its type and name with the visible overview. Page B is a valid syntax comparison.",
      "Documentation template owner", "content", "schema-extraction", "publisher-intent");
  }
}
fs.writeFileSync("audit/review.json", JSON.stringify(bundle, null, 2) + "\n");
