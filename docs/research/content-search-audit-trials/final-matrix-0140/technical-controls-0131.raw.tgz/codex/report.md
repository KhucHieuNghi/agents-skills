# Offline content and search audit

**Partial audit.** Both declared dossiers were collected and reviewed. Validated coverage is **2 declared, 0 fully audited, 2 pending, 0 failed, 0 blocked, 0 unsupported and 0 excluded**. All 52 required checks are represented. Of these, 10 resolved and 42 remain unknown. There are **3 material findings**. The two dossiers are independent synthetic scenarios. The inventory is complete for the supplied files only; the four page components and the robots and sitemap exhibits are assessed within their respective dossier. No URLs were fetched, credentials accessed or source changes made.

[Packaged report](audit/reviewed/report.md) · [Offline HTML](audit/reviewed/report.html) · [Action backlog](audit/reviewed/content-actions.csv) · [Coverage](audit/reviewed/coverage.json) · [Validation](audit/validation.json) · [Quote receipt](audit/quote-receipt.json)

## Material findings

### 1. Googlebot is disallowed from the approved current guide · High

**Affected item:** Routing dossier, `https://routing.example.test/guide/current`. SEO crawl access and AIO readiness are affected by the same policy issue, counted once.

**Owner context, 01-routing.md:5-10**

```text
As of 2026-11-16, the approved public product guide is `/guide/current`.
The archived `/guide/2024` must remain accessible as a clearly labeled historical
document; it is not the preferred current guide. The owner wants Googlebot to
crawl the current guide. No Search Console or engine-selected canonical data is
available. HTTP responses below were captured by an ordinary browser user agent,
not Googlebot.
```

**Supplied robots snapshot, 01-routing.md:15-19**

```text
User-agent: Googlebot
Disallow: /guide/current

User-agent: *
Allow: /
```

The explicit Googlebot group applies to Googlebot, so the wildcard allowance does not override the matching disallow. The ordinary-browser 200 describes a different requester. This is a conflict with the owner's crawl intent in the supplied policy. Actual Googlebot fetches, indexing, and AI retrieval remain unknown.

**Action and verification.** Have the routing owner revise the applicable Googlebot rules narrowly enough to permit the approved current path. Evaluate the effective rules for the exact URL and user agent in a revised robots export. Separately use an authorized bot fetch record or verified crawler logs to assess actual crawling.

### 2. The current guide declares the archive as canonical · High

**Affected items:** Routing dossier, current guide and the canonical relationship to `https://routing.example.test/guide/2024`.

**Current guide raw HTML, 01-routing.md:33**

```html
    <link rel="canonical" href="https://routing.example.test/guide/2024" />
```

**Sitemap export, 01-routing.md:46**

```xml
  <url><loc>https://routing.example.test/guide/current</loc></url>
```

The current guide's canonical points to the explicitly historical document, while the sitemap names the approved current URL. That declaration conflicts with the owner intent dated 2026-11-16 and may send confusing signals about the preferred URL. The owner reports that the archive self-canonicalizes and that the supplied current response has no redirect. Search-engine selection remains unknown.

**Action and verification.** Have the routing owner align the current guide's canonical with its approved current URL and preserve the accessible, clearly labeled, self-canonical historical guide. Compare revised current and archive responses and the sitemap with the two intended roles. Assess selected canonical and index state separately if an engine export becomes available.

### 3. Page A JSON-LD fails strict JSON parsing · Medium

**Affected item:** Markup dossier, Page A, the Cedar Library overview. No page URL was supplied.

**Supplied raw source, 02-markup.md:13-19**

```html
<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Cedar Library",
  }
</script>
```

The comma after the final property makes the supplied JSON-LD block invalid JSON. A local strict parser rejected Page A and accepted Page B. This is one SEO and machine-readability finding. It establishes a problem in the supplied block and leaves actual consumer behavior, rendered markup and rich-result eligibility unknown.

**Action and verification.** Have the documentation template owner remove the comma and retain the generic page description. Parse the revised extracted script body with a strict JSON parser and compare the name and type with the visible overview. The owner asks for machine-readable documentation descriptions and has no stated Product, FAQPage, reviews, ratings or specific rich-result objective (02-markup.md:37-40).

## Clean cases and remaining uncertainty

| Component and role | Content, answer quality and portfolio observations | Technical and readiness limits |
| --- | --- | --- |
| Routing current guide, approved current entitlement reference | The supplied title and heading agree. The copy directly presents a current three-seat entitlement. Owner approval establishes the URL and role as of 2026-11-16. The seat count has no independent, dated entitlement record in the dossier. | Ordinary-browser HTTP 200 and sitemap inclusion are supplied observations. The crawler policy and canonical defects are tracked above. Index and snippet state, bot behavior, rendering, internal discovery and non-Google surfaces remain unverified. |
| Routing archive, historical entitlement reference | The two-seat statement is accurate for its explicitly historical 2024 scope per the dossier. The two seat counts describe different periods. Keep the two guide roles and their version labels. | Supplied archive HTTP 200 and reported self-canonical are consistent with its role. Capture date, full raw archive response and separate indexing evidence are absent. |
| Markup Page A, library overview | The visible heading and description consistently identify Cedar Library. Cedar Tools maintenance is stated in the excerpt; its authority and currency are unverified. Retain the overview role. | The raw JSON-LD syntax defect is tracked above. The dossier reports HTTP 200 for both pages. |
| Markup Page B, export reference | The heading and description identify a distinct reference task. The excerpt gives too little detail to assess whether the full page supports a user's export task. Retain the distinct reference role. | The supplied JSON parses, uses a generic WebPage type and its name agrees with the visible heading (02-markup.md:22-34). No rendered snapshot, rich-result test or engine decision is supplied. |

The routing capture date is unspecified. The markup dossier also leaves capture dates and the requester unspecified. Dossier ingestion timestamps in the package record the audit's local evidence handling. Neither dossier includes enough evidence for item-wide judgments about audience task success, claim freshness and support, or accessibility of informative media. The supplied passages permit limited observations about fact clarity and entity naming. Full metadata, index and snippet controls, internal links, locale variants, rendered state and broader entity consistency remain unresolved where the necessary evidence is missing.

## Measurements and evidence needed to close checks

- **AEO and portfolio demand.** No real question set, support themes or query-to-page data was supplied. Question coverage, extracted-answer context, demand gaps and journey links remain unknown. Supply dated entitlement records, actual customer questions, fuller source excerpts and a scoped link graph to assess answer support, discovery and task completion.
- **Technical SEO and AIO.** Supply dated responses with requester provenance, headers, raw and rendered snapshots, complete applicable crawler directives and relevant locale or internal link data. Separately supply Search Console or other engine URL evidence and verified crawler logs for actual crawl, indexing and canonical outcomes. AI search optimization here covers readiness; Google AI Overviews is a specific product with no observation in these dossiers.
- **GEO and performance.** No historical study aggregates, response-level AI observations, Search Console, GA4, Bing or server-log exports were supplied. Mentions, citations, AI answer accuracy, rankings, referrals and conversions are unmeasured. For a future authorized test, use versioned prompts derived from real questions, separate results by engine surface and locale, and retain timestamps, repetitions, exact responses and cited URLs. Report separate mention and citation denominators, and adjudicate changing claims against dated records. No results or rates can be inferred from the fixtures.

The [packaged check appendix](audit/reviewed/report.md) lists each unresolved rule and its evidence requirements. Validation establishes artifact consistency. The audit scope and available evidence leave completion unresolved.
