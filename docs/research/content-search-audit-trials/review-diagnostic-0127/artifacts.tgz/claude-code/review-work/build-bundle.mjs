import fs from "node:fs";
import { createHash } from "node:crypto";
const [runDir, outFile] = process.argv.slice(2);
const sha = (s) => createHash("sha256").update(s).digest("hex");
const inv = fs.readFileSync(`${runDir}/inventory.jsonl`, "utf8").trim().split("\n").map(JSON.parse);
const ev = fs.readFileSync(`${runDir}/evidence.jsonl`, "utf8").trim().split("\n").map(JSON.parse);
const now = new Date().toISOString();
const reviewer = "Claude Sonnet 5.5 (content-search-audit agent)";
const byName = {};
for (const i of inv) {
  const name = i.path.split("/").pop();
  const c = ev.find((e) => e.itemId === i.itemId && e.kind === "content");
  byName[name] = { itemId: i.itemId, content: c, lines: c.value.split("\n") };
}
const rng = (f, a, b) => byName[f].lines.slice(a - 1, b).join("\n");
const evidence = [], artifacts = {};
function add(file, kind, label, payload) {
  const t = byName[file];
  const text = JSON.stringify(payload);
  const id = sha(`${t.itemId}|${kind}|${label}|${text}`);
  const artifact = `evidence/${id}.json`;
  artifacts[artifact] = text;
  evidence.push({
    evidenceId: id, itemId: t.itemId, kind, method: "attributed-derivation-from-supplied-snapshot",
    collectedAt: now, locator: `targets/${file} (${label})`, snapshotHash: sha(text),
    redaction: "none; excerpts of authorized synthetic source content",
    limitations: ["Derived by the audit agent from the owner-supplied synthetic dossier; owner-approved records are scenario evidence, not independently verified live behavior", "No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot"],
    sourceEvidenceIds: [t.content.evidenceId], artifact, encoding: "json", value: payload,
  });
  return id;
}
const claimSrc = (file, label, claimLines, sourceLines, note) =>
  add(file, "claim-sources", label, {
    attribution: "owner-supplied synthetic dossier, quoted by audit agent",
    claim: { file, lines: claimLines.join("-"), text: rng(file, ...claimLines) },
    sources: sourceLines.map(([a, b]) => ({ file, lines: `${a}-${b}`, text: rng(file, a, b) })),
    note,
  });
const F = { 1: "01-competitor-claims.md", 2: "02-measurement-windows.md", 3: "03-template-service-area.md", 4: "04-editorial-proof.md" };
const e1a = claimSrc(F[1], "assertion A vs SSO docs", [17, 17], [[12, 14]], "Table silence is not proof of absence; supplied docs state SAML SSO on Enterprise.");
const e1b = claimSrc(F[1], "assertion B vs prices", [18, 18], [[3, 4], [6, 10]], "Monthly 12<15 but annual 10>9; arithmetic checked with bc.");
const e2a = claimSrc(F[2], "Draft A window mismatch", [10, 10], [[5, 8]], "Numerator covers Oct 1-31; denominator covers Oct 1-7. 3000/35=85.7142 (bc) is arithmetic only.");
const e2b = claimSrc(F[2], "Draft B untracked-share claim", [17, 18], [[14, 16], [20, 21]], "Only 15 identified AI-referrer sessions supplied; no tracking-rate model or incrementality test.");
const e3 = claimSrc(F[3], "south-delivery vs approved policy", [10, 11], [[4, 5], [8, 9]], "South page repeats the North same-day passage; approved South policy is next-business-day only.");
const e4 = claimSrc(F[4], "landing claim vs product record", [6, 6], [[3, 5]], "Supplied median is 15 min over 20 sessions; no guarantee, maximum or wider-population estimate.");
const e4faq = claimSrc(F[4], "permissions FAQ vs approved policy", [8, 9], [[10, 13]], "FAQ answer matches the approved permissions policy; no extra conditions needed.");
const e4q = add(F[4], "question-set", "owner-supplied FAQ question", { attribution: "owner-supplied", questions: [{ question: "Can editors delete the workspace?", lines: "8-9", faq: rng(F[4], 8, 9), taskStatement: rng(F[4], 10, 13) }] });
const R = (file, ruleId, status, reason, ids) => ({ itemId: byName[file].itemId, ruleId, status, reason, evidenceIds: ids, reviewer, reviewedAt: now });
const cid = (f) => byName[f].content.evidenceId;
const reviews = [
  R(F[1], "quality-claims", "fail", "Assertion A (line 17) says Fir has no SSO as its pricing table proves, but the supplied docs (lines 12-14) say SAML SSO is available on Enterprise with a minimum of 20 paid seats; a table that does not mention SSO cannot prove absence. Assertion B (line 18) says Cedar is cheaper on every billing option, but annual is USD 10 vs Fir USD 9 (lines 7, 9). The separate scoped monthly caption (lines 21-23; 15-12=3) is supported and is not part of this failure.", [cid(F[1]), e1a, e1b]),
  R(F[2], "quality-claims", "fail", "Draft A divides October 1-31 spend by a conversion count covering only October 1-7 (lines 5-6, 10), so the figure labelled October is unsupported; the arithmetic itself is right (3000/35=85.7142). Draft B (lines 17-18) states 15 tracked sessions prove 150 AI-generated sessions, but no tracking-rate model, incrementality test or complete session count exists (lines 14-16). The October 1-7 caption (lines 11-12; 700/35=20) is matched-window and supported.", [cid(F[2]), e2a, e2b]),
  R(F[3], "quality-claims", "fail", "The /south-delivery passage (lines 10-11) promises same-day delivery, contradicting the current approved policy that South serves next-business-day delivery only (lines 4-5). /north-delivery matches policy; /terms-v1 is an owner-confirmed labelled 2024 archive (lines 13-16) and is not a defect.", [cid(F[3]), e3]),
  R(F[4], "quality-claims", "fail", "The draft landing claim (line 6) says every team is guaranteed to finish setup in 10 minutes. The approved record (lines 3-5) gives a median of 15 minutes over 20 observed sessions and supplies no guarantee, maximum or wider-population estimate. The permissions FAQ (lines 8-13) and /status-codes (lines 15-19) are supported and are not part of this failure.", [cid(F[4]), e4]),
  R(F[4], "aeo-answer-context", "pass", "The FAQ question and answer (lines 8-9) are complete; the owner states no additional conditions are needed and the task is to identify the permitted role (lines 10-13). Scope: the FAQ only.", [cid(F[4]), e4q]),
  R(F[4], "aeo-answer-evidence", "pass", "The FAQ answer (lines 8-9) matches the approved permissions policy (lines 10-11). Scope: the FAQ only; the landing claim is assessed under quality-claims.", [cid(F[4]), e4faq]),
];
for (const rule of ["quality-claims", "quality-freshness", "aeo-answer-evidence"])
  reviews.push(R("context.md", rule, "not-applicable", "context.md is the owner's audit-scope statement (it directs auditing the four numbered dossiers as separate scenarios), not published content making claims to be sourced, dated or answered.", [cid("context.md")]));
const F_ = (findingId, title, file, ids, remediation, verification, reason) => ({
  findingId, title, affectedItemIds: [byName[file].itemId], ruleIds: ["quality-claims"], dimensions: ["quality"],
  evidenceIds: ids, severity: "high", confidence: "high", classification: "observed",
  remediation, verification, ownerRole: "Content owner", effort: "Small", action: "update", actionReason: reason,
});
const findings = [
  F_("F1", "01 /compare assertion A: 'no SSO' contradicts supplied documentation", F[1], [cid(F[1]), e1a], "Replace with an attributed, scoped statement: Fir documents SAML SSO on Enterprise with a minimum of 20 paid seats; make no claim about other plans.", "New text matches the quoted SSO docs, makes no 'proves' claim from the pricing table and no statement about plans with no supplied SSO statement; re-check current Fir docs before publishing.", "Claim contradicted by supplied documentation."),
  F_("F2", "01 /compare assertion B: 'every billing option' fails for annual billing", F[1], [cid(F[1]), e1b], "Restrict the claim to monthly billing (as the scoped monthly caption does) or state the annual figures neutrally.", "Recompute each compared option pair from the supplied figures; no 'every'/'all' wording remains; market, currency, tax and date scope stated.", "Universal claim fails on the annual option."),
  F_("F3", "02 Draft A: 31-day spend divided by 7-day conversions", F[2], [cid(F[2]), e2a], "Remove Draft A; use the matched October 1-7 figure or state the monthly figure is unavailable.", "Every ratio uses identical dates for numerator and denominator; text states October 8-31 conversions are unmeasured.", "Window mismatch makes the figure unsupported."),
  F_("F4", "02 Draft B: 'prove ... 150 sessions' has no evidence basis", F[2], [cid(F[2]), e2b], "Report that 15 October sessions had an identified AI-assistant referrer and other sessions have unknown origin; add an estimate only with a documented, labelled tracking-rate method.", "Every number traces to the referral report; no causal verb remains; conversions are not combined with referral data.", "Prove/generated wording and 150 total exceed evidence."),
  F_("F5", "03 /south-delivery states same-day delivery against approved South policy", F[3], [cid(F[3]), e3], "Rewrite the South passage to the approved next-business-day policy; keep both pages.", "South passage matches policy (no same-day wording); /north-delivery unchanged; /terms-v1 unchanged.", "Stale copied North text contradicts approved policy."),
  F_("F6", "04 landing claim 'guaranteed to finish setup in 10 minutes' exceeds the approved record", F[4], [cid(F[4]), e4], "Replace with the supported statement: in a study of 20 observed onboarding sessions, the median completion time was 15 minutes; no guarantee wording unless a policy and evidence exist.", "Text contains the 20-session scope and 15-minute median and no 'every', 'guaranteed' or 10-minute figure.", "Claim exceeds the supplied evidence."),
];
fs.writeFileSync(outFile, JSON.stringify({ reviews, evidence, artifacts, findings }, null, 2));
console.log(JSON.stringify({ reviews: reviews.length, evidence: evidence.length, findings: findings.length }));
