# Synthetic — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:55:52\.733Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 597ec0f2\-041b\-421b\-99fd\-18cf16fce7be\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 5 |
| In scope | 5 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 5 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | 01 /compare assertion A: &\#39;no SSO&\#39; contradicts supplied documentation | quality\-claims | quality | high | high | observed | 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | update | reviewer\-proposal | Claim contradicted by supplied documentation\. | Replace with an attributed, scoped statement: Fir documents SAML SSO on Enterprise with a minimum of 20 paid seats; make no claim about other plans\. | New text matches the quoted SSO docs, makes no &\#39;proves&\#39; claim from the pricing table and no statement about plans with no supplied SSO statement; re\-check current Fir docs before publishing\. | Content owner | Small | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714, ad5192291a1ec4c28889929a5a88bf087bef96e5fcaa629f7a86349c27602611 |
| F2 | 01 /compare assertion B: &\#39;every billing option&\#39; fails for annual billing | quality\-claims | quality | high | high | observed | 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | update | reviewer\-proposal | Universal claim fails on the annual option\. | Restrict the claim to monthly billing \(as the scoped monthly caption does\) or state the annual figures neutrally\. | Recompute each compared option pair from the supplied figures; no &\#39;every&\#39;/&\#39;all&\#39; wording remains; market, currency, tax and date scope stated\. | Content owner | Small | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714, 21fd79683eb85e5bb9b385a41d8a375ca168966ff19c0d4f6681074467dc2d54 |
| F3 | 02 Draft A: 31\-day spend divided by 7\-day conversions | quality\-claims | quality | high | high | observed | 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | update | reviewer\-proposal | Window mismatch makes the figure unsupported\. | Remove Draft A; use the matched October 1\-7 figure or state the monthly figure is unavailable\. | Every ratio uses identical dates for numerator and denominator; text states October 8\-31 conversions are unmeasured\. | Content owner | Small | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b, 8763fec1db82055818690f7b90063d0096716012e7114a0ea0f5ca3fa699cdf7 |
| F4 | 02 Draft B: &\#39;prove \.\.\. 150 sessions&\#39; has no evidence basis | quality\-claims | quality | high | high | observed | 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | update | reviewer\-proposal | Prove/generated wording and 150 total exceed evidence\. | Report that 15 October sessions had an identified AI\-assistant referrer and other sessions have unknown origin; add an estimate only with a documented, labelled tracking\-rate method\. | Every number traces to the referral report; no causal verb remains; conversions are not combined with referral data\. | Content owner | Small | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b, 499a4df2753dec54f849793bef70689865a656fd11e800cfe35052671c0b904d |
| F5 | 03 /south\-delivery states same\-day delivery against approved South policy | quality\-claims | quality | high | high | observed | 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | update | reviewer\-proposal | Stale copied North text contradicts approved policy\. | Rewrite the South passage to the approved next\-business\-day policy; keep both pages\. | South passage matches policy \(no same\-day wording\); /north\-delivery unchanged; /terms\-v1 unchanged\. | Content owner | Small | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b, 8a1450ee81aad704165880079e3182b512c9de26ed6f85b4f365287f9899c37a |
| F6 | 04 landing claim &\#39;guaranteed to finish setup in 10 minutes&\#39; exceeds the approved record | quality\-claims | quality | high | high | observed | c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | update | reviewer\-proposal | Claim exceeds the supplied evidence\. | Replace with the supported statement: in a study of 20 observed onboarding sessions, the median completion time was 15 minutes; no guarantee wording unless a policy and evidence exist\. | Text contains the 20\-session scope and 15\-minute median and no &\#39;every&\#39;, &\#39;guaranteed&\#39; or 10\-minute figure\. | Content owner | Small | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431, b95ebab6a6ca8220036f78694474d9cae0c37cbb28f4e9ba4fd5c2a7e1babfa4 |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 15 | 2 | 12 | 1 |
| aio | 15 | 0 | 15 | 0 |
| geo | 15 | 0 | 15 | 0 |
| portfolio | 20 | 0 | 20 | 0 |
| quality | 25 | 4 | 19 | 2 |
| seo | 40 | 0 | 40 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | pending | Snapshot review incomplete | 26 |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | pending | Snapshot review incomplete | 26 |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | pending | Snapshot review incomplete | 26 |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | pending | Snapshot review incomplete | 26 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | quality\-claims | quality | fail | Assertion A \(line 17\) says Fir has no SSO as its pricing table proves, but the supplied docs \(lines 12\-14\) say SAML SSO is available on Enterprise with a minimum of 20 paid seats; a table that does not mention SSO cannot prove absence\. Assertion B \(line 18\) says Cedar is cheaper on every billing option, but annual is USD 10 vs Fir USD 9 \(lines 7, 9\)\. The separate scoped monthly caption \(lines 21\-23; 15\-12=3\) is supported and is not part of this failure\. | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714, 21fd79683eb85e5bb9b385a41d8a375ca168966ff19c0d4f6681074467dc2d54, ad5192291a1ec4c28889929a5a88bf087bef96e5fcaa629f7a86349c27602611 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | quality\-claims | quality | fail | The /south\-delivery passage \(lines 10\-11\) promises same\-day delivery, contradicting the current approved policy that South serves next\-business\-day delivery only \(lines 4\-5\)\. /north\-delivery matches policy; /terms\-v1 is an owner\-confirmed labelled 2024 archive \(lines 13\-16\) and is not a defect\. | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b, 8a1450ee81aad704165880079e3182b512c9de26ed6f85b4f365287f9899c37a |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | quality\-claims | quality | not\-applicable | context\.md is the owner&\#39;s audit\-scope statement \(it directs auditing the four numbered dossiers as separate scenarios\), not published content making claims to be sourced, dated or answered\. | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | quality\-freshness | quality | not\-applicable | context\.md is the owner&\#39;s audit\-scope statement \(it directs auditing the four numbered dossiers as separate scenarios\), not published content making claims to be sourced, dated or answered\. | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | aeo\-answer\-evidence | aeo | not\-applicable | context\.md is the owner&\#39;s audit\-scope statement \(it directs auditing the four numbered dossiers as separate scenarios\), not published content making claims to be sourced, dated or answered\. | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | quality\-claims | quality | fail | Draft A divides October 1\-31 spend by a conversion count covering only October 1\-7 \(lines 5\-6, 10\), so the figure labelled October is unsupported; the arithmetic itself is right \(3000/35=85\.7142\)\. Draft B \(lines 17\-18\) states 15 tracked sessions prove 150 AI\-generated sessions, but no tracking\-rate model, incrementality test or complete session count exists \(lines 14\-16\)\. The October 1\-7 caption \(lines 11\-12; 700/35=20\) is matched\-window and supported\. | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b, 499a4df2753dec54f849793bef70689865a656fd11e800cfe35052671c0b904d, 8763fec1db82055818690f7b90063d0096716012e7114a0ea0f5ca3fa699cdf7 |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | quality\-claims | quality | fail | The draft landing claim \(line 6\) says every team is guaranteed to finish setup in 10 minutes\. The approved record \(lines 3\-5\) gives a median of 15 minutes over 20 observed sessions and supplies no guarantee, maximum or wider\-population estimate\. The permissions FAQ \(lines 8\-13\) and /status\-codes \(lines 15\-19\) are supported and are not part of this failure\. | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431, b95ebab6a6ca8220036f78694474d9cae0c37cbb28f4e9ba4fd5c2a7e1babfa4 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aeo\-answer\-context | aeo | pass | The FAQ question and answer \(lines 8\-9\) are complete; the owner states no additional conditions are needed and the task is to identify the permitted role \(lines 10\-13\)\. Scope: the FAQ only\. | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431, fb419e233a1a5fc246fc8a54dfffcebaf5a113d05ce1dc869763cad1ba8f3f3d |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | aeo\-answer\-evidence | aeo | pass | The FAQ answer \(lines 8\-9\) matches the approved permissions policy \(lines 10\-11\)\. Scope: the FAQ only; the landing claim is assessed under quality\-claims\. | 44bf1b16b38468b0ea45c11f2f2413626960bbe5960d71e3b3b23bbfcbf1bfd1, b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |
| c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 080d45656bc16aba3633da29b0ed42c75bae7d95182a3e88700c22bfbb88e714 | 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | local\-file | 2026\-11\-16T05:47:29\.464Z | 0 full elapsed days | [evidence/2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6\.txt](evidence/2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 470c2d60ec529b731c3169f44e9a5e2d68facda53dedf8e5b33471a932113a1b | 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | local\-file | 2026\-11\-16T05:47:29\.466Z | 0 full elapsed days | [evidence/44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab\.txt](evidence/44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f357aaf63dcbf5dd895d6e78c9cd9649abded116c862ebb5eedee98b6f55ad4b | 4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e | local\-file | 2026\-11\-16T05:47:29\.468Z | 0 full elapsed days | [evidence/4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e\.txt](evidence/4e34dc6801b8851ebf45fcaccfa6b136211aca28d16dbad9bd8c6ff6d346f54e.txt) | 300a81403b0666bc540a18d33815a9b5b65ae68dbbd76446e1bcba02996a63cc | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0ab89a660d508f801d6548275bd10234bc507010991521a40efbd73ae7f4674b | 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | local\-file | 2026\-11\-16T05:47:29\.469Z | 0 full elapsed days | [evidence/7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7\.txt](evidence/7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b57067715f0c3462c2e697ded7777d7971e21241d3e23c45d035db4b817d1431 | c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | local\-file | 2026\-11\-16T05:47:29\.470Z | 0 full elapsed days | [evidence/c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d\.txt](evidence/c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ad5192291a1ec4c28889929a5a88bf087bef96e5fcaa629f7a86349c27602611 | 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/ad5192291a1ec4c28889929a5a88bf087bef96e5fcaa629f7a86349c27602611\.json](evidence/ad5192291a1ec4c28889929a5a88bf087bef96e5fcaa629f7a86349c27602611.json) | 71ef7be378d37bd7e126f711fd162fe3aafac84727e68ca08d5d458569a6f12f | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| 21fd79683eb85e5bb9b385a41d8a375ca168966ff19c0d4f6681074467dc2d54 | 2a13eaa35a50340d2122b0c3cd3adbc2476aedc862e4aade8250ea1509ef15e6 | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/21fd79683eb85e5bb9b385a41d8a375ca168966ff19c0d4f6681074467dc2d54\.json](evidence/21fd79683eb85e5bb9b385a41d8a375ca168966ff19c0d4f6681074467dc2d54.json) | 1c471b95d6e556fa6688c10b90611abf63209f0821acf2582dbd2a25ec04e8ce | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| 8763fec1db82055818690f7b90063d0096716012e7114a0ea0f5ca3fa699cdf7 | 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/8763fec1db82055818690f7b90063d0096716012e7114a0ea0f5ca3fa699cdf7\.json](evidence/8763fec1db82055818690f7b90063d0096716012e7114a0ea0f5ca3fa699cdf7.json) | 45dbf056d902c607ea15ab3b1db0ed59c229a00f3c834d83b23384f31265d618 | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| 499a4df2753dec54f849793bef70689865a656fd11e800cfe35052671c0b904d | 7707c62b468ee5437aa2a15b9311ad6257cd0a4a861915bb73ec90a6944ab9f7 | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/499a4df2753dec54f849793bef70689865a656fd11e800cfe35052671c0b904d\.json](evidence/499a4df2753dec54f849793bef70689865a656fd11e800cfe35052671c0b904d.json) | 6faa13eccc0583161dda7417f60aa60b4e1819d210ecaa896325507e54218036 | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| 8a1450ee81aad704165880079e3182b512c9de26ed6f85b4f365287f9899c37a | 44cd5f06e408ef5cffc6f856f3008917b0f39a4a42dcb03e4c8cf611f503d7ab | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/8a1450ee81aad704165880079e3182b512c9de26ed6f85b4f365287f9899c37a\.json](evidence/8a1450ee81aad704165880079e3182b512c9de26ed6f85b4f365287f9899c37a.json) | ee8a5f451ef85f8ff65186fff9d144595a4e268d2a60cc312edd209543785ad1 | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| b95ebab6a6ca8220036f78694474d9cae0c37cbb28f4e9ba4fd5c2a7e1babfa4 | c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/b95ebab6a6ca8220036f78694474d9cae0c37cbb28f4e9ba4fd5c2a7e1babfa4\.json](evidence/b95ebab6a6ca8220036f78694474d9cae0c37cbb28f4e9ba4fd5c2a7e1babfa4.json) | 443461b09d37bbf22b49536ac10d81e25569044546895bb19a131fef15854322 | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| 44bf1b16b38468b0ea45c11f2f2413626960bbe5960d71e3b3b23bbfcbf1bfd1 | c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/44bf1b16b38468b0ea45c11f2f2413626960bbe5960d71e3b3b23bbfcbf1bfd1\.json](evidence/44bf1b16b38468b0ea45c11f2f2413626960bbe5960d71e3b3b23bbfcbf1bfd1.json) | 8c80f97ada85639f9374f9641fbc1463eb8caa3c9e2b8950e66c2846c1699115 | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |
| fb419e233a1a5fc246fc8a54dfffcebaf5a113d05ce1dc869763cad1ba8f3f3d | c152d4e506a4abd06464ee8ff436502667ae969e4ed0030f19e2177dd9e1800d | attributed\-derivation\-from\-supplied\-snapshot | 2026\-11\-16T05:55:52\.570Z | 0 full elapsed days | [evidence/fb419e233a1a5fc246fc8a54dfffcebaf5a113d05ce1dc869763cad1ba8f3f3d\.json](evidence/fb419e233a1a5fc246fc8a54dfffcebaf5a113d05ce1dc869763cad1ba8f3f3d.json) | a2b3cfed61f87c0741b254a552f7f2c8ad3874a7bb7a71a586ac2b56798393ae | Derived by the audit agent from the owner\-supplied synthetic dossier; owner\-approved records are scenario evidence, not independently verified live behavior; No URL was fetched; excerpts are verbatim line ranges of the retained content snapshot |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
