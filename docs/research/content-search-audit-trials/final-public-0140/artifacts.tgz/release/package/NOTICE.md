# content-search-audit 0.1.40 attribution

This release includes these pinned public components:

- Internal adapted sources and their license texts: [skills/content-search-audit/NOTICE.md](skills/content-search-audit/NOTICE.md).

Original components are covered by `LICENSE`.
Upstream license texts are in `licenses/`.
