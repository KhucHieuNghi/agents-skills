# https://nkskills.getgroove.me/licenses/README.txt
itemId: ca94fe429f9523a5cdb6bff1f7586f649cd2c166e36105e63019777c4c263d86
contentEvidence: 1b6ad064b40b30886119c80c38a808ea8061d3de3b21a95831bda858bb483dcc
httpEvidence: 3bafdafbe03b086de7e27770313aa6fef9131894745c8345bc9d545bb03fc749
robotsEvidence: 341668bea555a1d0866ee69420e30f9a3047f70ba4467a330e0acbbefc70a57c
bytes(chars): 377

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/plain",
  "content-length": "377",
  "etag": "\"bc0867bc99da578923ef408f6fbc7ee8\"",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/licenses/README.txt",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/licenses/README.txt",
   "collectedAt": "2026-11-18T08:24:27.308Z",
   "retryAfter": null
  }
 ],
 "wireHash": "a3e056507a37cff9d6b1b578645743dd0e727ca338252ef83e78b1bb3bdc9986"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:25.060Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:25.060Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## raw text
NKSkills site font notices

Fraunces is by The Fraunces Project Authors and is licensed under
SIL Open Font License 1.1. Full notice: fraunces-OFL.txt

Source Sans 3 is by Adobe and is licensed under SIL Open Font License 1.1.
Full notice: source-sans-3-OFL.txt

IBM Plex Mono is by IBM Corp. and is licensed under SIL Open Font License 1.1.
Full notice: ibm-plex-mono-OFL.txt

