// Builds the attributed global (portfolio) review bundle for the reviewed campaign
// revision. Local reads only; nothing is fetched and no page code is executed.
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PART = "parts/000001";
const campaign = path.join(pilot, "campaign-r2");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = async (f) =>
  (await readFile(path.join(campaign, PART, f), "utf8")).split("\n").filter(Boolean).map((l) => JSON.parse(l));
const index = JSON.parse(await readFile(path.join(pilot, "index-r2", "index.json"), "utf8"));
const inv = await lines("inventory.jsonl");
const ev = await lines("evidence.jsonl");
const checks = await lines("checks.jsonl");
const now = new Date().toISOString();
const reviewer =
  "Claude Fable 5.2 (claude-fable-5-2), AI host reviewer running the content-search-audit skill in Claude Code; judgments are not independently human-verified";
const ref = (evidenceId) => ({ part: PART, evidenceId });
const of = (itemId, kind) => ev.find((e) => e.itemId === itemId && e.kind === kind);
const itemIds = inv.map((i) => i.itemId);
assert.equal(itemIds.length, 12);
const contentRefs = itemIds.map((id) => ref(of(id, "content").evidenceId));
const uriOf = new Map(inv.map((i) => [i.itemId, i.uri]));

function context(evidenceId, kind, valueObject, locator, sourceReferences) {
  const value = typeof valueObject === "string" ? valueObject : JSON.stringify(valueObject, null, 1);
  return { evidenceId, kind, value, snapshotHash: hash(value), locator, collectedAt: now, sourceReferences };
}

// inventory map (from the per-item derived record; identical across items)
const invMap = of(itemIds[0], "inventory-map").value;
// link graph: unique internal edges + notable observations
const edges = [];
const csaLinks = [];
let fragmentChecks = 0;
for (const id of itemIds) {
  const g = of(id, "link-graph").value;
  for (const l of g.internalLinks) {
    edges.push(`${uriOf.get(id)} -> ${l.resolved}${l.fragment ? "#" + l.fragment : ""}`);
    if (l.fragment !== null) { fragmentChecks++; assert.equal(l.fragmentFoundInTargetSource, true); }
    if (l.fragment === "content-search-audit") csaLinks.push({ from: uriOf.get(id), to: l.resolved + "#" + l.fragment, text: l.text });
    assert.equal(l.targetStatus, 200);
  }
}
assert.ok(csaLinks.length >= 5 && csaLinks.every((l) => l.to.includes("/guides/codex/")));
const failedJourney = checks.filter((c) => c.ruleId === "portfolio-journey-links" && c.status === "fail").map((c) => c.itemId);
assert.equal(failedJourney.length, 5);

const contextEvidence = [
  context("g-inventory-map", "inventory-map", invMap, "campaign-r2 declared inventory (12 items), reviewer-classified purposes", contentRefs),
  context("g-link-graph", "link-graph", {
    scope: "static same-origin a[href] links among the 12 collected items; external and non-anchor resources not fetched",
    uniqueInternalEdges: [...new Set(edges)].sort(),
    fragmentTargetsChecked: fragmentChecks,
    allInternalTargetsCollectedWith200: true,
    contentSearchAuditCallToActionLinks: csaLinks,
    claudeCodeGuidesHaveSameSection: ["https://nkskills.getgroove.me/en/guides/claude-code/#content-search-audit", "https://nkskills.getgroove.me/vi/guides/claude-code/#content-search-audit"],
    noOnSiteDetailPage: ["Problem presentation (links go to the GitHub manifest and to guide section 05)", "Content search audit (links go to guide section 06)"],
    licenceReadmeUnlinkedReferences: of(inv.find((i) => i.uri.endsWith("README.txt")).itemId, "link-graph").value.plainTextFileReferencesNotHyperlinked,
  }, "derived from parts/000001 r2-link-graph-* records", [...contentRefs, ...itemIds.map((id) => ref(of(id, "link-graph").evidenceId))]),
  context("g-entity-record", "entity-record", {
    siteEntityTable: of(itemIds[0], "entity-record").value.siteEntityTable,
    perPageVersionStrings: Object.fromEntries(itemIds.map((id) => [uriOf.get(id), of(id, "entity-record").value.pageMentions.versionsFound])),
    note: "Reviewer-compiled from the site's own captured statements; not an authoritative external record",
  }, "derived from parts/000001 r2-entity-record-* records", [...contentRefs, ...itemIds.map((id) => ref(of(id, "entity-record").evidenceId))]),
  context("g-audience-context", "audience-context", of(itemIds[0], "audience-context").value, "user-task-statement:content-search-audit public pilot request, 2026-11-18", [ref(of(itemIds[0], "audience-context").evidenceId)]),
];

const reviews = [
  {
    ruleId: "portfolio-task-gaps", status: "unknown", reviewer, reviewedAt: now, itemIds,
    evidenceReferences: contentRefs, contextEvidenceIds: ["g-inventory-map", "g-audience-context"],
    reason: "No question set (search queries, support or sales questions) was supplied, so audience tasks cannot be mapped to the inventory with evidence. Observed without demand evidence, and therefore exploratory only: the inventory covers overview, catalog, one solution detail page (codebase onboarding) and two host guides in English and Vietnamese; Problem presentation and Content search audit have no on-site detail page. Whether that is a gap for real users is not established.",
  },
  {
    ruleId: "portfolio-duplication", status: "pass", reviewer, reviewedAt: now, itemIds,
    evidenceReferences: contentRefs, contextEvidenceIds: ["g-inventory-map"],
    reason: "Across the 12 collected items the only identical content is the root URL and /en/ (same content hash), which is a 308 redirect alias with the canonical on /en/. The five EN/VI pairs are declared reciprocal locale variants with self-canonicals. The Codex and Claude Code guides overlap heavily but differ in the task-relevant commands, directories and invocation tokens, so they are legitimate host variants. Home, catalog, solution page and guides serve distinct tasks. No consolidation is proposed. Limits: cannibalization needs query/page data that was not supplied, and items outside the static-link scope were not compared.",
  },
  {
    ruleId: "portfolio-contradictions", status: "pass", reviewer, reviewedAt: now, itemIds,
    evidenceReferences: [...contentRefs, ...itemIds.map((id) => ref(of(id, "entity-record").evidenceId))],
    contextEvidenceIds: ["g-entity-record", "g-inventory-map"],
    reason: "No conflicting material claim was found across the 12 snapshots or between English and Vietnamese counterparts: Solution Skill names, versions (1.1.0, 0.1.0, 0.1.32), release statuses, supported hosts, the three-component composition, the stated counts (03 Solution Skills; 15 upstream skills, matching 15 listed source cards; 06 security sources) and the no-direct-download statement agree wherever they appear. The differing phrasings of the commercial release gate express one status and are recorded as a clarity finding in the part review, not as a contradiction. Limits: claims were compared with each other, not with the GitHub release records or catalog.yaml, which are outside the authorized origin; the entity record is reviewer-compiled from the site itself.",
  },
  {
    ruleId: "portfolio-journey-links", status: "fail", reviewer, reviewedAt: now, itemIds,
    evidenceReferences: [...contentRefs, ...itemIds.map((id) => ref(of(id, "link-graph").evidenceId))],
    contextEvidenceIds: ["g-link-graph", "g-audience-context"],
    reason: "Most journeys in the static link graph are intact: home → solution page → either host guide, guides → home install section and starter prompt, catalog ↔ home, reciprocal language switches on every page, and all fragment targets exist. One journey is broken for one of the two supported hosts: every Content search audit call-to-action on the home and catalog pages (both languages, plus the root alias) links only to the Codex guide's #content-search-audit section, although the Claude Code guides carry the same section with different commands. Also observed, lower weight: the licence README names three notice files without links. Limits: static links only; rendered navigation and anything outside the 12 items were not inspected.",
  },
];
const findings = [
  {
    findingId: "global-csa-journey-codex-only",
    ruleId: "portfolio-journey-links",
    severity: "medium",
    confidence: "high",
    observation: "Site-wide, the Content search audit install path is reachable from home and catalog only via /{locale}/guides/codex/#content-search-audit (5 affected source pages including the root alias). A Claude Code user following it gets --target codex, .agents/skills/ and $content-search-audit instructions; the matching Claude Code section exists but is not linked from these entry points. This is the portfolio-level view of the per-item finding csa-cta-codex-only (same issue, not an additional defect).",
    recommendation: "Offer both host guides from every Content search audit entry point (home card, catalog entry), in English and Vietnamese, mirroring the host chooser already used for codebase onboarding.",
    verification: "Re-capture the home and catalog pages in both languages and confirm a static link to /{locale}/guides/claude-code/#content-search-audit exists beside the Codex link and resolves to an existing id.",
    action: "update",
    actionReason: "Observed in captured source of all five entry pages; the target section already exists.",
    ownerRole: "Site maintainer (page templates) — proposed, not confirmed by the owner",
    effort: "small",
    affectedItemIds: failedJourney,
    evidenceReferences: failedJourney.flatMap((id) => [ref(of(id, "content").evidenceId), ref(of(id, "link-graph").evidenceId)]),
  },
];
const bundle = {
  schemaVersion: 1,
  campaignId: index.campaignId,
  sourceManifestHash: index.sourceManifestHash,
  partSnapshotHashes: index.partSnapshotHashes,
  contextEvidence, reviews, findings,
};
const out = path.join(pilot, "bundles", "global-review-r2.json");
await writeFile(out, JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ written: out, builtAt: now, reviews: reviews.map((r) => [r.ruleId, r.status]), csaLinks, uniqueEdges: new Set(edges).size, fragmentChecks }, null, 1));
