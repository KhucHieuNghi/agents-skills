// Builds pilot configs from local artifacts only. No network access.
// Usage: node build-configs.mjs discover | campaign
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const mode = process.argv[2];
const discoverConfigPath = path.join(pilot, "configs", "discover-config.json");

if (mode === "discover") {
  const source = JSON.parse(
    await readFile(path.join(pilot, "discovery-continued", "source.json"), "utf8"),
  );
  const config = {
    expectedSourceIds: ["internal-links"],
    scopeComplete: false,
    sources: [source],
  };
  await writeFile(discoverConfigPath, JSON.stringify(config, null, 2) + "\n", {
    flag: "wx",
  });
  console.log(JSON.stringify({ written: discoverConfigPath, records: source.records.length }));
} else if (mode === "campaign") {
  const discovery = JSON.parse(await readFile(discoverConfigPath, "utf8"));
  const receipt = JSON.parse(
    await readFile(path.join(pilot, "receipts-04-discover.json"), "utf8"),
  );
  const config = {
    inputs: receipt.inputs,
    localRoots: [],
    inventoryComplete: receipt.inventoryComplete,
    mode: "full",
    brandName: "NKSkills",
    network: {
      allowedOrigins: ["https://nkskills.getgroove.me"],
      retries: 1,
    },
    discovery,
  };
  const out = path.join(pilot, "configs", "campaign-config.json");
  await writeFile(out, JSON.stringify(config, null, 2) + "\n", { flag: "wx" });
  console.log(
    JSON.stringify({
      written: out,
      inputs: config.inputs.length,
      inventoryComplete: config.inventoryComplete,
      receiptKeys: Object.keys(receipt),
      pendingQueue: receipt.pendingQueue?.length,
    }),
  );
} else {
  throw new Error("mode required");
}
