# https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/
itemId: 4b55d5cdc55a821e1f611908de6303ec17abbeff425cf178652ddb4c1d19ba46
contentEvidence: 6bcaa16886e81f1862606cccdd1821cc102c38c45252e8c116fc19e7b5fa56b5
httpEvidence: d71aa19e0a42bcbefa97001c535a0ca63faaa3eab33558b354d13d59a188d3b4
robotsEvidence: 70c52a2274a0da994e963ba36d7cadd75b6a93aa21b9683034d3b6939cfeee05
bytes(chars): 7029

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/",
   "collectedAt": "2026-11-18T08:24:07.853Z",
   "retryAfter": null
  }
 ],
 "wireHash": "c2180e00e5fb72b649d557514bbf3398e44dea099fc8a897c386c9d652b6ac46"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:06.390Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:06.390Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="vi">

## title
Codebase onboarding có dẫn chứng | NKSkills 1.1.0

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Tìm hiểu workflow codebase-onboarding, các thành phần được khóa phiên bản, điều kiện chạy, kiểm tra dẫn chứng và giới hạn xác minh hiện tại.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-vietnamese-full-normal.7BpKI3vF.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-vietnamese-wght-normal.BDs68eHQ.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<meta property="og:type" content="website">
<meta property="og:title" content="Codebase onboarding có dẫn chứng | NKSkills 1.1.0">
<meta property="og:description" content="Tìm hiểu workflow codebase-onboarding, các thành phần được khóa phiên bản, điều kiện chạy, kiểm tra dẫn chứng và giới hạn xác minh hiện tại.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-vi.png">
<meta property="og:url" content="https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Hiểu codebase lạ bằng dẫn chứng kiểm tra được.
h2: Đã khóa thành phần. Đang mở rộng đánh giá chất lượng.
h2: Một workflow, ba thành phần có thể truy vết
h3: codebase-onboarding-c4
h3: html-docs-standard
h3: Hallmark
h2: Đi từ luồng sản phẩm đến bản đồ kỹ thuật
h2: Điều kiện và giới hạn hiện tại

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Đến nội dung chính
/vi/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/#try-it | rel=null | hreflang=null | aria=null | Dùng thử
/en/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=Switch to English | EN
/vi/ | rel=null | hreflang=null | aria=null | NKSkills
/vi/guides/codex/ | rel=null | hreflang=null | aria=null | Hướng dẫn Codex
/vi/guides/claude-code/ | rel=null | hreflang=null | aria=null | Hướng dẫn Claude Code
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Đọc biên bản phát hành →
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/codebase-onboarding.yaml | rel=null | hreflang=null | aria=null | solutions/codebase-onboarding.yaml
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md | rel=null | hreflang=null | aria=null | Xem hướng dẫn kỹ thuật đầy đủ →
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Bản phát hành
/licenses/README.txt | rel=null | hreflang=null | aria=null | Giấy phép font
/en/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | English

## visible text by block (tags removed)
Đến nội dung chính
<div> NK Skills
<nav> Giải pháp Danh mục Dùng thử EN
<nav> NKSkills / Codebase onboarding
<p> SOLUTION SKILL v1.1.0
<h1> Hiểu codebase lạ bằng dẫn chứng kiểm tra được.
<p> Một luồng đọc và phân tích repository theo bằng chứng: từ hành trình sản phẩm đến sơ đồ C1/C2, trước khi đội ngũ bắt đầu sửa mã.
<div> Hướng dẫn Codex Hướng dẫn Claude Code
<aside> Bản kỹ thuật 1.1.0
<h2> Đã khóa thành phần. Đang mở rộng đánh giá chất lượng.
<p> Bản phát hành đã có digest, kiểm thử build và cài đặt. Chưa xác minh hiệu quả trên mọi repository của khách hàng.
</p> Đọc biên bản phát hành →
<p> THÀNH PHẦN
<h2> Một workflow, ba thành phần có thể truy vết
<article> 01
<h3> codebase-onboarding-c4
<p> Workflow gốc dẫn dắt hành trình sản phẩm và sơ đồ kiến trúc dựa trên file thật.
</p> NKSkills original
<article> 02
<h3> html-docs-standard
<p> Chuẩn tài liệu HTML có cấu trúc, dễ đọc và có thể kiểm tra.
</p> NKSkills original
<article> 03
<h3> Hallmark
<p> Upstream công khai hỗ trợ hoàn thiện phần trình bày; revision được khóa trong catalog.
</p> Pinned public upstream
<p> Kiểm tra manifest và revision upstream: solutions/codebase-onboarding.yaml
<p> KẾT QUẢ
<h2> Đi từ luồng sản phẩm đến bản đồ kỹ thuật
<p> Quick mode yêu cầu một hành trình nghiệp vụ chính cùng C1 và C2. Mỗi khẳng định cần dẫn chứng bằng file; giả định phải được ghi rõ.
<li> Hành trình sản phẩm có điểm bắt đầu và kết quả
<li> Sơ đồ C1 context và C2 container
<li> Dẫn chứng file và phân biệt suy luận
<li> Handoff Markdown/HTML có kiểm tra
<h2> Điều kiện và giới hạn hiện tại
<p> Cần cài Solution Skill, codegraph, rtk và có CodeGraph index hợp lệ tại root của repository. Chưa có archive tải trực tiếp; hướng dẫn hiện tại bắt đầu từ mã nguồn GitHub.
<p> Bản 1.1.0 là phát hành kỹ thuật. Độ chính xác của kết quả trên từng repository vẫn cần người dùng kiểm tra.
</p> Xem hướng dẫn kỹ thuật đầy đủ →
<div> NKSkills
<br> Skill workflow có phiên bản cho Codex và Claude Code.
<div> Danh mục Giải pháp GitHub Bản phát hành Giấy phép font English

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/en/solutions/codebase-onboarding/" lang="en" aria-label="Switch to English">
<span aria-hidden="true">
<a href="/en/solutions/codebase-onboarding/" lang="en">
