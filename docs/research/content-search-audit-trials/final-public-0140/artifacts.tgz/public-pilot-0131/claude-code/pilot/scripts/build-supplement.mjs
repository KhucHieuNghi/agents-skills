// Writes the supplemental narrative report and its quote ledger from validated
// local artifacts. Counts are read from helper outputs, never typed by hand.
// Local reads only; no network and no execution of captured content.
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const json = async (p) => JSON.parse(await readFile(path.join(pilot, p), "utf8"));
const partDir = "campaign-r2/parts/000001";
const jsonl = async (f) => (await readFile(path.join(pilot, partDir, f), "utf8")).split("\n").filter(Boolean).map((l) => JSON.parse(l));

const coverage = await json("report-r2/coverage.json");
const c = coverage.itemCoverage;
const reviewResult = await json("global-review-r2/review-result.json");
const source = await json("discovery-continued/source.json");
const initial = JSON.parse(await readFile(path.join(pilot, "..", "initial-discovery", "source.json"), "utf8"));
const discovery = await json("discovery-continued/discovery.json");
const inv = await jsonl("inventory.jsonl");
const ev = await jsonl("evidence.jsonl");
const checks = await jsonl("checks.jsonl");
const findings = await json(partDir + "/findings.json");
const O = "https://nkskills.getgroove.me";
const contentFile = (uriPath) => {
  const item = inv.find((i) => i.uri === O + uriPath);
  return ev.find((e) => e.itemId === item.itemId && e.kind === "content").artifact;
};
const queueKinds = {};
for (const q of c.pendingQueue) { const k = q.adapterKind ?? q.discoveryKind; queueKinds[k] = (queueKinds[k] ?? 0) + 1; }
const exclusionsUnique = [...new Set(source.exclusions.map((e) => e.locator))].sort();
const exclusionHosts = [...new Set(exclusionsUnique.map((u) => new URL(u).host))];
const statusCount = (ruleId) => {
  const t = { pass: 0, fail: 0, unknown: 0, "not-applicable": 0 };
  for (const k of checks.filter((x) => x.ruleId === ruleId)) t[k.status]++;
  return t;
};
const rules = [...new Set(checks.map((x) => x.ruleId))];
assert.equal(c.total, 12); assert.equal(discovery.frontier.length, 0);
assert.equal(source.pendingQueue.filter((q) => q.kind === "unvisited-page").length, 0);

const L = [];
const quotes = [];
const p = (...s) => L.push(...s);
function q(id, uriPath, text, normalization = "exact") {
  const artifact = contentFile(uriPath);
  const label = path.posix.basename(artifact);
  quotes.push({ id, source: `${partDir}/${artifact}`, label, text, normalization, uriPath, reportLine: L.length + 1 });
  L.push(`- ${uriPath} — \`${text}\` — source LOCATOR[${id}]`);
}

p("# NKSkills public pilot — supplemental audit narrative (revision r2)", "",
  "This narrative supplements the helper-generated artifacts; it does not replace them. Coverage numbers below are copied by script from `report-r2/coverage.json` and the validated campaign, not counted from prose.", "",
  "## Status", "",
  `**Partial.** ${c.total} declared items; ${c.collected} collected; ${c.audited} fully audited; pending ${c.states.pending}, failed ${c.states.failed}, blocked ${c.states.blocked}, unsupported ${c.states.unsupported}, excluded ${c.states.excluded}. Missing required checks: ${c.missingChecks}. Completion allowed: ${coverage.completionAllowed}. Global review complete: ${coverage.globalReviewComplete} (unresolved: ${reviewResult.unresolvedRuleIds.join(", ")}).`, "",
  "\"Collected\" means a raw HTTP snapshot was captured and read. No item is \"fully audited\" because every item still has unknown checks that need evidence this pilot was not given (see Evidence needs).", "",
  "## Scope and discovery", "",
  `- Authorized origin: ${O} only; anonymous public requests through the packaged collector; robots.txt, DNS and redirect rules enforced by the helper; no browser, no script execution.`,
  `- Initial discovery (immutable, \`initial-discovery/\`): validated first (\`receipts-01-discovery-validate.json\` in the project root, valid=true), ${initial.scope.visitedPages} page captured at maxPages=${initial.scope.maxPages}, ${initial.pendingQueue.filter((x) => x.kind === "unvisited-page").length} unvisited pages queued. Budget stop, not an interruption.`,
  `- Continued discovery (\`pilot/discovery-continued/\`): discovery-resume with maxPages=${source.scope.maxPages}, maxDepth=${source.scope.maxDepth}; ${source.scope.visitedPages} captures, ${source.records.length} inventory URLs, frontier ${discovery.frontier.length}. Reused from the original capture: ${discovery.recovery.reusedUrls.join(", ")}. Parent discovery ${discovery.recovery.parentDiscoveryId}.`,
  `- Count/depth budget: nothing remains pending for count or depth (0 unvisited-page entries; ${source.scope.visitedPages} of ${source.scope.maxPages} page budget used). No count/depth continuation is needed for this static-link scope.`,
  `- Discovery status is still partial and scopeComplete=false. Pending queue (${c.pendingQueue.length} entries): ${Object.entries(queueKinds).map(([k, n]) => `${k} × ${n}`).join("; ")}.`,
  `- External exclusions kept visible: ${exclusionsUnique.length} distinct URLs on ${exclusionHosts.join(", ")} (${source.exclusions.length} link occurrences) were recorded as graph edges and not fetched.`,
  "- Not in scope and not collected: `sitemap.xml` (declared in robots.txt), CSS, JavaScript files, fonts, images including og:image, the three licence notice files named in `/licenses/README.txt`, CMS records, orphan pages, rendered navigation.", "",
  "This is the declared static-link inventory, not a proven complete site inventory.", "",
  "## Findings (persisted in findings.json / content-actions.csv)", "",
  "Quotations are exact substrings of the captured raw response; locators point at the content snapshot file and line inside `pilot/" + partDir + "/`.", "",
  "### 1. csa-cta-codex-only — medium, observed (global view: global-csa-journey-codex-only, same issue)", "",
  "The Content search audit entry on the home and catalog pages links only to the Codex guide, in both languages. The Claude Code guides have the matching section but are not linked from those entries.", "");
q("cta-en-home", "/en/", `href="/en/guides/codex/#content-search-audit"`);
q("cta-vi-catalog", "/vi/catalog/", `href="/vi/guides/codex/#content-search-audit"`);
q("section-en-claude", "/en/guides/claude-code/", `id="content-search-audit"`);
p("", "Proposed: link both host guides from each entry. Verify by re-capturing the four pages and checking for a static link to the Claude Code section.", "",
  "### 2. guide-meta-intro-stale — low, observed", "",
  "All four guides contain a Content search audit section, but the description names two skills and the intro places the Problem presentation trial at the end of the guide, which it no longer is.", "");
q("guide-desc-en", "/en/guides/codex/", "Build and install NKSkills Solution Skills from GitHub source, then invoke codebase onboarding or the presentation evaluation candidate in Codex.");
q("guide-intro-en", "/en/guides/codex/", "The Problem presentation trial at the end of this guide has separate evaluation criteria.");
q("guide-intro-vi", "/vi/guides/codex/", "Phần thử Problem presentation ở cuối trang có điều kiện đánh giá riêng.");
p("", "Proposed: update description/og:description and the intro sentence in both languages. The `seo-metadata` check is recorded as fail for these four items only.", "",
  "### 3. gate-wording-ambiguous — low, inferred", "",
  "The same release status is worded two ways. The texts are observed; the risk that \"remains open\" is read as \"available\" is an inference, not an observed outcome.", "");
q("gate-en-card", "/en/", "The commercial release gate remains open.");
q("gate-en-faq", "/en/", "No. Version 0.1.0 is an evaluation candidate, and the commercial release gate remains open.");
q("gate-en-catalog", "/en/catalog/", "Create an offline HTML and PDF deck around one evidenced problem and decision. Commercial release gate remains open.");
q("gate-vi-faq", "/vi/", "Chưa. Bản 0.1.0 là ứng viên đánh giá; cổng phát hành thương mại vẫn mở.");
q("gate-vi-card", "/vi/", "Chưa qua cổng phát hành thương mại.");
q("gate-en-guide", "/en/guides/codex/", "Version 0.1.0 has not passed the commercial release gate.");
p("", "Proposed: use the \"has not passed\" / \"chưa qua\" form everywhere.", "",
  "### 4. license-notices-unlinked — low, inferred, conditional", "",
  "Only if the three notice files are meant to be publicly reachable next to README.txt: give their URLs. Their existence was not verified because they are not hyperlinked and were not fetched.", "");
q("readme-fraunces", "/licenses/README.txt", "Fraunces is by The Fraunces Project Authors and is licensed under SIL Open Font License 1.1. Full notice: fraunces-OFL.txt", "whitespace");
p("", "## Supported clean results (narrow, snapshot-level)", "",
  "These are attributed reviewer judgments on captured raw HTML; they are not index, ranking or rendering evidence.", "",
  "| Rule | pass | fail | unknown | not applicable |", "| --- | --- | --- | --- | --- |");
for (const r of rules) { const t = statusCount(r); p(`| ${r} | ${t.pass} | ${t.fail} | ${t.unknown} | ${t["not-applicable"]} |`); }
p("",
  "- HTTP: all 12 items returned a final HTTP 200; the root URL reaches /en/ through one 308 redirect.",
  "- Canonical and locale annotations (11 HTML items): one self-referential canonical each; hreflang en, vi and x-default declared and reciprocal between each EN/VI pair; html lang matches. Engine-selected canonical and language targeting were not observed.",
  "- Static internal links (11 HTML items): every same-origin link resolves to a collected 200 item and every fragment target exists in the captured target source.",
  "- Cross-page and EN/VI consistency: names, versions (1.1.0, 0.1.0, 0.1.32), release statuses, hosts and stated counts agree across all 12 snapshots. They were compared with each other, not with the GitHub release records.",
  "- Text extraction: nonempty for all 12 items (deterministic helper check).", "",
  "## Unknown, and the evidence needed", "",
  "| Unresolved | Why | Evidence that would resolve it |", "| --- | --- | --- |",
  "| quality-claims, quality-freshness, aeo-answer-evidence (12 items each) | No dated authoritative source was collected; release records, manifests and catalog.yaml are on github.com, outside the authorized origin | Owner-supplied or authorized copies of the release records/manifests with dates |",
  "| seo-index-controls, aio-crawler-policy (12 each) | Publisher intent not supplied. Observed only: robots.txt is `User-agent: *` / `Allow: /` with a sitemap line; no robots meta tag in raw HTML and no X-Robots-Tag header captured | A statement of which pages should be indexed and which crawler purposes (search, AI search, training, user-triggered fetch) are intended |",
  "| seo-rendering (12) and the 10 rendering-unreviewed queue entries | No browser capture was authorized; the home pages load /scripts/prompt-picker.js and hold alternative prompts in template elements | An authorized rendered-DOM capture of each page |",
  "| seo-structured-data (12) | No JSON-LD, microdata or RDFa found in raw source; rendered absence not established and no intent supplied | Rendered capture, plus the owner's intended structured data if any |",
  "| aeo-question-coverage, aeo-answer-context (12 each); portfolio-task-gaps (12 local + global) | No question set supplied; the site's own FAQ is not evidence of real user questions | Search queries, support or sales questions with provenance |",
  "| geo-observed-presence, geo-answer-accuracy, geo-cohort-validity (12 each) | No AI response observations supplied | Dated response-level observations per engine/surface with prompts |",
  "| quality-task-fit for the 4 guides | codegraph/rtk/CodeGraph index setup is delegated to a GitHub guide that was not collected | The technical guide content, or owner confirmation of the setup path |",
  "| /licenses/README.txt: 7 further checks | Plain-text notice; referenced notice files, stylesheets and intent not collected | The notice files and publisher intent |",
  "| Rankings, indexing, crawler logs, citations, conversions | Not supplied and not measurable from page snapshots | Search Console, Bing, server-log, analytics and AI-observation exports |", "",
  "## Optional observations (not findings)", "",
  "- The home meta description names two of the three Solution Skills shown on the page.",
  "- Vietnamese pages keep some English interface strings (for example aria-label values such as \"NKSkills home\" and \"hallmark source\", and the labels \"NKSkills original\" / \"Pinned public upstream\").",
  "- Guide step 04 has a stray comma after the host name in both languages, and the Vietnamese sentence refers to the token \"bên phải\" (on the right), which depends on layout.",
  "- Problem presentation and Content search audit have no on-site detail page; whether users need one is unknown without demand evidence.", "",
  "## Continuation", "",
  "1. No count/depth continuation is pending for the static-link scope.",
  "2. To extend discovery, start a separate `discover-sitemaps` run seeded with https://nkskills.getgroove.me/sitemap.xml (same allowed origin) and build a new campaign whose discovery lists both sources; this pilot's campaign is not retroactively completed by that.",
  "3. To clear the rendering queue, supply an authorized rendered capture for the 10 queued HTML URLs.",
  "4. To clear the page-extraction entry, authorize collection of the three notice files named in README.txt.", "",
  "## Helper outcome", "",
  "All helper commands used (discovery-validate, discovery-resume, discover, campaign, campaign-index, campaign-review-parts, campaign-review, campaign-review-validate, campaign-report, campaign-validate, validate, methods) exited 0. No helper or contract failure occurred. One reviewer-script assertion failed before any bundle was written (an inbound-link count of 10 was corrected to the observed 11) and was fixed in the pilot script, not in the skill.", "");

// resolve locators
const sourceCache = new Map();
const ledger = [];
for (const quote of quotes) {
  if (!sourceCache.has(quote.source)) sourceCache.set(quote.source, await readFile(path.join(pilot, quote.source), "utf8"));
  const text = sourceCache.get(quote.source);
  let startLine, endLine;
  if (quote.normalization === "exact") {
    const at = text.indexOf(quote.text);
    assert.ok(at >= 0, `quote not in source: ${quote.id}`);
    startLine = text.slice(0, at).split(/\r?\n/).length;
    endLine = startLine + quote.text.split(/\r?\n/).length - 1;
  } else {
    const srcLines = text.split(/\r?\n/);
    const norm = (s) => s.replace(/\s+/gu, " ").trim();
    let found = false;
    for (let s = 0; s < srcLines.length && !found; s++)
      for (let e = s; e < Math.min(srcLines.length, s + 3); e++)
        if (norm(srcLines.slice(s, e + 1).join("\n")).includes(norm(quote.text))) { startLine = s + 1; endLine = e + 1; found = true; break; }
    assert.ok(found, `quote not in source: ${quote.id}`);
  }
  const citation = `${quote.label}:${startLine}${endLine === startLine ? "" : `-${endLine}`}`;
  L[quote.reportLine - 1] = L[quote.reportLine - 1].replace(`LOCATOR[${quote.id}]`, `\`${citation}\``);
  ledger.push({
    quoteId: quote.id, source: quote.source, sourceLabel: quote.label, sourceHash: hash(await readFile(path.join(pilot, quote.source))),
    startLine, endLine, reportStartLine: quote.reportLine, reportEndLine: quote.reportLine, normalization: quote.normalization, quote: quote.text,
  });
}
const report = L.join("\n") + "\n";
const reportName = "supplemental-report-r2.md";
await writeFile(path.join(pilot, reportName), report, { flag: "wx" });
const bundle = { root: pilot, report: reportName, reportHash: hash(Buffer.from(report, "utf8")), quotes: ledger };
await writeFile(path.join(pilot, "bundles", "quotes-r2.json"), JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ report: path.join(pilot, reportName), quotes: ledger.length, findingsPersisted: findings.map((f) => f.findingId), queueKinds, exclusionsUnique: exclusionsUnique.length, exclusionOccurrences: source.exclusions.length, ruleTally: Object.fromEntries(rules.map((r) => [r, statusCount(r)])) }, null, 1));
