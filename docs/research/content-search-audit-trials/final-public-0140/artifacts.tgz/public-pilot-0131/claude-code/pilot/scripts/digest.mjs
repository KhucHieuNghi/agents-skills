// Inert text digest of collected snapshots for host review. Reads local campaign
// artifacts only. Target markup is parsed as text with regular expressions;
// no page script is executed and nothing is fetched.
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const part = path.join(pilot, "campaign-r1", "parts", "000001");
const out = path.join(pilot, "analysis");
await mkdir(out, { recursive: true });
const lines = async (f) =>
  (await readFile(path.join(part, f), "utf8")).split("\n").filter(Boolean).map((l) => JSON.parse(l));
const inv = await lines("inventory.jsonl");
const ev = await lines("evidence.jsonl");

const decode = (s) =>
  s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, " ");
const strip = (s) => decode(s.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
const attr = (tag, name) => {
  const m = tag.match(new RegExp(`\\s${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return m ? decode(m[2] ?? m[3] ?? m[4] ?? "") : null;
};

const summary = [];
for (const item of inv) {
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === "content");
  const http = mine.find((e) => e.kind === "http-response");
  const robots = mine.filter((e) => e.kind === "crawler-policy");
  const html = content.value;
  const slug = item.uri.replace("https://nkskills.getgroove.me", "").replace(/[^a-z0-9.]+/gi, "_") || "_";
  const o = [];
  o.push(`# ${item.uri}`, `itemId: ${item.itemId}`, `contentEvidence: ${content.evidenceId}`, `httpEvidence: ${http.evidenceId}`);
  o.push(`robotsEvidence: ${robots.map((r) => r.evidenceId).join(", ")}`, `bytes(chars): ${html.length}`, "");
  o.push("## http-response", JSON.stringify(http.value, null, 1), "");
  for (const r of robots) o.push("## crawler-policy", JSON.stringify(r.value, null, 1), "");
  const isHtml = /<html[\s>]/i.test(html);
  const rec = { uri: item.uri, itemId: item.itemId, contentEvidence: content.evidenceId, httpEvidence: http.evidenceId, robotsEvidence: robots.map((r) => r.evidenceId), isHtml };
  if (!isHtml) {
    o.push("## raw text", html);
  } else {
    const htmlTag = html.match(/<html[^>]*>/i)?.[0];
    rec.lang = htmlTag ? attr(htmlTag, "lang") : null;
    o.push("## html tag", htmlTag ?? "(none)", "");
    const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    rec.title = title ? decode(title[1]) : null;
    o.push("## title", rec.title ?? "(none)", "");
    o.push("## head meta/link/base tags");
    const headTags = html.match(/<(meta|link|base)\b[^>]*>/gi) ?? [];
    for (const t of headTags) o.push(t);
    rec.description = null; rec.canonical = []; rec.hreflang = []; rec.robotsMeta = [];
    for (const t of headTags) {
      const name = (attr(t, "name") ?? "").toLowerCase();
      const rel = (attr(t, "rel") ?? "").toLowerCase();
      if (name === "description") rec.description = attr(t, "content");
      if (name === "robots" || name === "googlebot") rec.robotsMeta.push(t);
      if (rel === "canonical") rec.canonical.push(attr(t, "href"));
      if (rel === "alternate" && attr(t, "hreflang")) rec.hreflang.push(`${attr(t, "hreflang")} -> ${attr(t, "href")}`);
    }
    o.push("", "## script elements (source text only; never executed)");
    const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
    rec.scripts = [];
    for (const s of scripts) {
      const type = attr("<x" + s[1] + ">", "type");
      const src = attr("<x" + s[1] + ">", "src");
      rec.scripts.push({ type, src, length: s[2].length });
      o.push(`- type=${type} src=${src} inlineLength=${s[2].length}`);
      if ((type ?? "").includes("ld+json")) o.push("  JSON-LD text: " + s[2]);
      else if (s[2].length) o.push("  inline text (first 600 chars): " + s[2].slice(0, 600));
    }
    o.push("", "## noscript/iframe/template/form/style counts");
    for (const t of ["noscript", "iframe", "template", "form", "style", "svg", "img", "video", "audio", "picture", "button", "details"]) {
      const n = (html.match(new RegExp(`<${t}\\b`, "gi")) ?? []).length;
      rec[`n_${t}`] = n;
      o.push(`${t}: ${n}`);
    }
    const body = html.replace(/<script\b[\s\S]*?<\/script>/gi, " ").replace(/<style\b[\s\S]*?<\/style>/gi, " ");
    o.push("", "## img/svg accessibility attributes");
    for (const t of body.match(/<(img|svg)\b[^>]*>/gi) ?? []) o.push(t.slice(0, 400));
    o.push("", "## headings");
    rec.headings = [];
    for (const h of body.matchAll(/<(h[1-6])\b[^>]*>([\s\S]*?)<\/\1>/gi)) {
      rec.headings.push(`${h[1]}: ${strip(h[2])}`);
      o.push(`${h[1]}: ${strip(h[2])}`);
    }
    o.push("", "## anchors (href | rel | target | text)");
    rec.links = [];
    for (const a of body.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
      const t = "<a" + a[1] + ">";
      const l = { href: attr(t, "href"), rel: attr(t, "rel"), hreflang: attr(t, "hreflang"), lang: attr(t, "lang"), aria: attr(t, "aria-label"), text: strip(a[2]) };
      rec.links.push(l);
      o.push(`${l.href} | rel=${l.rel} | hreflang=${l.hreflang} | aria=${l.aria} | ${l.text}`);
    }
    o.push("", "## visible text by block (tags removed)");
    const bodyOnly = body.replace(/^[\s\S]*?<body[^>]*>/i, "");
    const blocks = bodyOnly
      .replace(/<(\/)?(p|div|section|article|header|footer|nav|main|li|ul|ol|h[1-6]|tr|td|th|table|pre|dt|dd|dl|figure|figcaption|blockquote|br|summary|details|aside|code)\b[^>]*>/gi, (m, c, t) => `\n[${c ? "/" : ""}${t}]`)
      .split("\n")
      .map((l) => {
        const m = l.match(/^\[(\/?[a-z0-9]+)\]([\s\S]*)$/i);
        if (!m) return strip(l);
        const txt = strip(m[2]);
        return txt ? `<${m[1]}> ${txt}` : "";
      })
      .filter(Boolean);
    rec.textChars = blocks.join(" ").length;
    o.push(...blocks);
    o.push("", "## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)");
    for (const t of new Set(bodyOnly.match(/<[a-z0-9]+\b[^>]*\s(hidden|aria-hidden|lang|data-[a-z-]+)(=|\s|>)[^>]*>/gi) ?? [])) o.push(t.slice(0, 300));
  }
  await writeFile(path.join(out, `digest${slug}.md`), o.join("\n") + "\n");
  // raw source split at tag boundaries for line-addressable inspection
  await writeFile(path.join(out, `raw${slug}.txt`), html.replace(/></g, ">\n<"));
  summary.push(rec);
}
await writeFile(path.join(out, "summary.json"), JSON.stringify(summary, null, 1) + "\n");
for (const r of summary) {
  console.log(JSON.stringify({ uri: r.uri, lang: r.lang, title: r.title, description: r.description, canonical: r.canonical, hreflang: r.hreflang, robotsMeta: r.robotsMeta, scripts: r.scripts, textChars: r.textChars, n_img: r.n_img, n_svg: r.n_svg, n_iframe: r.n_iframe, n_template: r.n_template, n_noscript: r.n_noscript, n_form: r.n_form }));
}
