// Builds the per-part attributed review bundle from local campaign snapshots.
// Local reads only; captured markup is parsed as inert text (regular expressions).
// No page script is executed, nothing is fetched. Every pass/fail is gated by an
// assertion over the captured snapshot so a judgment cannot be emitted without
// the observation it depends on.
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const campaign = path.join(pilot, "campaign-r1");
const part = path.join(campaign, "parts", "000001");
const ORIGIN = "https://nkskills.getgroove.me";
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = async (f) =>
  (await readFile(path.join(part, f), "utf8")).split("\n").filter(Boolean).map((l) => JSON.parse(l));
const inv = await lines("inventory.jsonl");
const ev = await lines("evidence.jsonl");
const index = JSON.parse(await readFile(path.join(pilot, "index-r1", "index.json"), "utf8"));
const now = new Date().toISOString();
const reviewer =
  "Claude Fable 5.2 (claude-fable-5-2), AI host reviewer running the content-search-audit skill in Claude Code; judgments are not independently human-verified";

const decode = (s) =>
  s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, " ");
const strip = (s) => decode(s.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
const attr = (tag, name) => {
  const m = tag.match(new RegExp(`\\s${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return m ? decode(m[2] ?? m[3] ?? m[4] ?? "") : null;
};
const short = (id) => id.slice(0, 12);

// ---------- per-item facts ----------
const facts = new Map();
for (const item of inv) {
  const mine = ev.filter((e) => e.itemId === item.itemId);
  const content = mine.find((e) => e.kind === "content");
  const http = mine.find((e) => e.kind === "http-response");
  const robots = mine.filter((e) => e.kind === "crawler-policy");
  const html = content.value;
  const isHtml = /<html[\s>]/i.test(html) && /text\/html/.test(http.value.headers["content-type"] ?? "");
  const f = {
    item, content, http, robots, html, isHtml,
    finalUrl: http.value.url,
    status: http.value.status,
    redirects: http.value.redirects ?? [],
    linkHeader: http.value.headers.link ?? null,
    xRobotsTag: http.value.headers["x-robots-tag"] ?? null,
    contentType: http.value.headers["content-type"] ?? null,
  };
  if (isHtml) {
    const htmlTag = html.match(/<html[^>]*>/i)?.[0] ?? "";
    f.lang = attr(htmlTag, "lang");
    f.title = decode(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "");
    const headTags = html.match(/<(meta|link|base)\b[^>]*>/gi) ?? [];
    f.description = null; f.canonical = []; f.hreflang = {}; f.robotsMeta = []; f.og = {}; f.base = null;
    for (const t of headTags) {
      const name = (attr(t, "name") ?? "").toLowerCase();
      const rel = (attr(t, "rel") ?? "").toLowerCase();
      const prop = attr(t, "property");
      if (/^<base/i.test(t)) f.base = attr(t, "href");
      if (name === "description") f.description = attr(t, "content");
      if (name === "robots" || name === "googlebot") f.robotsMeta.push(attr(t, "content"));
      if (rel === "canonical") f.canonical.push(attr(t, "href"));
      if (rel === "alternate" && attr(t, "hreflang")) f.hreflang[attr(t, "hreflang")] = attr(t, "href");
      if (prop && prop.startsWith("og:")) f.og[prop] = attr(t, "content");
    }
    f.scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].map((s) => ({
      type: attr("<x" + s[1] + ">", "type"), src: attr("<x" + s[1] + ">", "src"), inlineLength: s[2].length,
    }));
    const body = html.replace(/<script\b[\s\S]*?<\/script>/gi, " ").replace(/<style\b[\s\S]*?<\/style>/gi, " ").replace(/^[\s\S]*?<body[^>]*>/i, "");
    f.body = body;
    f.ids = new Set([...body.matchAll(/\sid\s*=\s*"([^"]+)"/gi)].map((m) => m[1]));
    f.anchors = [...body.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map((a) => {
      const t = "<a" + a[1] + ">";
      return { href: attr(t, "href"), rel: attr(t, "rel"), ariaLabel: attr(t, "aria-label"), text: strip(a[2]) };
    });
    f.imgs = (body.match(/<img\b[^>]*>/gi) ?? []).map((t) => ({ src: attr(t, "src"), alt: attr(t, "alt"), hasAltAttribute: /\salt\s*=/.test(t) }));
    f.counts = {};
    for (const t of ["svg", "video", "audio", "iframe", "picture", "canvas", "object", "embed", "template", "noscript", "figure", "figcaption"])
      f.counts[t] = (body.match(new RegExp(`<${t}\\b`, "gi")) ?? []).length;
    f.ariaHiddenContainers = (body.match(/<[a-z0-9]+\b[^>]*aria-hidden="true"[^>]*>/gi) ?? []).length;
    f.schema = {
      jsonLdScripts: f.scripts.filter((s) => (s.type ?? "").includes("ld+json")).length,
      microdataItemscope: (body.match(/\sitemscope(\s|=|>)/gi) ?? []).length,
      microdataItemprop: (body.match(/\sitemprop\s*=/gi) ?? []).length,
      rdfaTypeof: (body.match(/\stypeof\s*=/gi) ?? []).length,
    };
    f.text = body
      .replace(/<(\/)?(p|div|section|article|header|footer|nav|main|li|ul|ol|h[1-6]|tr|td|th|table|pre|dt|dd|dl|figure|figcaption|blockquote|br|summary|details|aside|template)\b[^>]*>/gi, "\n")
      .split("\n").map(strip).filter(Boolean).join("\n");
  } else {
    f.text = html;
  }
  facts.set(item.itemId, f);
}
const byUri = new Map(inv.map((i) => [i.uri, i.itemId]));
const F = (uri) => facts.get(byUri.get(uri));
const htmlItems = inv.filter((i) => facts.get(i.itemId).isHtml);
assert.equal(inv.length, 12);
assert.equal(htmlItems.length, 11);

// ---------- link graph ----------
for (const f of facts.values()) {
  f.internal = []; f.external = []; f.nonHttp = [];
  if (!f.isHtml) continue;
  for (const a of f.anchors) {
    if (a.href === null) continue;
    let u;
    try { u = new URL(a.href, f.base ? new URL(f.base, f.finalUrl) : f.finalUrl); } catch { f.nonHttp.push(a.href); continue; }
    if (!/^https?:$/.test(u.protocol)) { f.nonHttp.push(a.href); continue; }
    if (u.origin !== ORIGIN) { f.external.push({ url: u.href, text: a.text || a.ariaLabel }); continue; }
    const fragment = u.hash ? decodeURIComponent(u.hash.slice(1)) : null;
    u.hash = "";
    const targetItemId = byUri.get(u.href) ?? null;
    const target = targetItemId ? facts.get(targetItemId) : null;
    f.internal.push({
      href: a.href, resolved: u.href, fragment, text: a.text || a.ariaLabel,
      targetItemId, targetStatus: target?.status ?? null,
      fragmentFoundInTargetSource: fragment === null ? null : target?.isHtml ? target.ids.has(fragment) : false,
    });
  }
}
for (const f of facts.values())
  f.inbound = [...facts.values()].filter((g) => g !== f && g.internal.some((l) => l.targetItemId === f.item.itemId)).map((g) => g.item.uri).sort();

// ---------- derived evidence ----------
const evidence = [];
const artifacts = {};
const reviews = [];
const eid = (kind, itemId) => `r2-${kind}-${short(itemId)}`;
function add(itemId, kind, value, locator, sourceEvidenceIds, limitations, method = "host-derived-analysis") {
  const isText = typeof value === "string";
  const bytes = isText ? value : JSON.stringify(value);
  const evidenceId = eid(kind, itemId);
  const artifact = `evidence/${evidenceId}.${isText ? "txt" : "json"}`;
  artifacts[artifact] = bytes;
  evidence.push({
    evidenceId, itemId, kind, value, method, locator, collectedAt: now,
    snapshotHash: hash(bytes), artifact, encoding: isText ? "utf8" : "json",
    sourceEvidenceIds: [...new Set(sourceEvidenceIds)],
    redaction: "Derived from public captured content or the audit request; no credentials, cookies or personal data added",
    limitations,
  });
  return evidenceId;
}
const derivedLimits = [
  "Derived by the host reviewer from the captured raw HTTP snapshot using inert regular-expression parsing; not a full HTML5 parser and not a rendered DOM",
  "Snapshot-time observation only; does not establish indexing, ranking, crawler behavior or AI visibility",
];
const AUDIENCE_TEXT =
  "Owner/task-supplied context preserved from the audit request received 2026-11-18 (user statement, not independently verified): " +
  "\"Business context: NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. " +
  "AIO means AI search optimization; no Google AI Overviews measurements are supplied.\" " +
  "The sole authorized public origin is https://nkskills.getgroove.me. No credentials, authenticated providers or analytics exports are supplied. " +
  "Reviewer inference (labelled, not supplied): the on-site task is to understand, evaluate, install and invoke NKSkills Solution Skills in Codex or Claude Code. " +
  "Not supplied: personas, search queries, customer questions, target AI surfaces, publisher indexing/crawler intent.";

const SITE_ENTITY_TABLE = {
  compiledBy: "host reviewer, from the 12 captured snapshots only",
  authoritativeRecordsNotCollected: [
    "github.com release records, manifests and catalog.yaml are linked from the pages but are outside the authorized origin and were not fetched",
  ],
  brand: { name: "NKSkills", logoText: "NK Skills", tagline: { en: "Versioned skill workflows for Codex and Claude Code.", vi: "Skill workflow có phiên bản cho Codex và Claude Code." } },
  hosts: ["Codex", "Claude Code"],
  solutionSkills: [
    { name: "Codebase onboarding", id: "codebase-onboarding", version: "1.1.0", status: "technical release", components: ["codebase-onboarding-c4", "html-docs-standard", "Hallmark"], invocation: { codex: "$codebase-onboarding-c4", "claude-code": "/codebase-onboarding-c4" } },
    { name: "Problem presentation", id: "problem-presentation", version: "0.1.0", status: "evaluation candidate; commercial release gate not passed", invocation: { codex: "$problem-presentation", "claude-code": "/problem-presentation" } },
    { name: "Content search audit", id: "content-search-audit", version: "0.1.32", status: "evaluation candidate", invocation: { codex: "$content-search-audit", "claude-code": "/content-search-audit" } },
  ],
  statedCounts: { solutionSkills: 3, upstreamSkills: 15, securitySources: 6 },
  distribution: "No published direct-download archive; build and install from GitHub source",
};
const KNOWN_VERSIONS = new Set(["1.1.0", "0.1.0", "0.1.32"]);

const purposeOf = (uri) =>
  uri === ORIGIN + "/" ? "root URL; 308 redirect alias of the English home page"
  : /\/(en|vi)\/$/.test(uri) ? "home / product overview"
  : uri.includes("/catalog/") ? "catalog of Solution Skills and tracked upstream skills"
  : uri.includes("/solutions/") ? "solution detail page (codebase onboarding)"
  : uri.includes("/guides/codex/") ? "install-and-use guide for the Codex host"
  : uri.includes("/guides/claude-code/") ? "install-and-use guide for the Claude Code host"
  : "plain-text font licence notice";
const inventoryMap = inv.map((i) => {
  const f = facts.get(i.itemId);
  return {
    itemId: i.itemId, uri: i.uri, finalUrl: f.finalUrl, mediaType: f.contentType,
    htmlLang: f.lang ?? null, purpose: purposeOf(i.uri), title: f.title ?? null,
    localeCounterpart: f.isHtml ? (f.lang === "en" ? f.hreflang.vi : f.hreflang.en) ?? null : null,
    contentHash: i.contentHash,
  };
}).sort((a, b) => a.uri.localeCompare(b.uri));
const allContentIds = inv.map((i) => facts.get(i.itemId).content.evidenceId);

const ids = new Map(); // itemId -> {kind: evidenceId}
for (const item of inv) {
  const f = facts.get(item.itemId);
  const own = [f.content.evidenceId, f.http.evidenceId];
  const k = {};
  k.content = f.content.evidenceId; k.http = f.http.evidenceId; k.robots = f.robots.map((r) => r.evidenceId);
  k["extracted-text"] = add(item.itemId, "extracted-text", f.text, item.uri, [f.content.evidenceId], [
    f.isHtml
      ? "Tag-stripped text of the captured raw HTML body: script/style elements removed, block boundaries as newlines, basic entities decoded; includes inert <template> text and aria-hidden text; not a rendered or visually ordered text"
      : "Verbatim captured text/plain body",
    "Nonempty text does not establish quality or completeness",
  ], "host-inert-text-extraction");
  k["audience-context"] = add(item.itemId, "audience-context", AUDIENCE_TEXT, "user-task-statement:content-search-audit public pilot request, 2026-11-18", [], [
    "Supplied by the requesting user in the audit task; an approved comparison basis, not independent verification of the business or of real user demand",
    "The intended on-page task is a labelled reviewer inference; no personas, queries or customer questions were supplied",
  ], "user-supplied-context");
  k["canonical-targets"] = add(item.itemId, "canonical-targets", (() => {
    const declared = f.isHtml ? f.canonical : [];
    const target = declared.length === 1 ? F(declared[0]) : null;
    return {
      requestedUri: item.uri, finalUrl: f.finalUrl, redirects: f.redirects, httpStatus: f.status,
      htmlCanonicalDeclarations: declared, httpLinkHeader: f.linkHeader,
      canonicalEqualsFinalUrl: declared.length === 1 ? declared[0] === f.finalUrl : null,
      canonicalTargetInInventory: target ? target.item.uri : null,
      canonicalTargetHttpStatus: target ? target.status : null,
      canonicalTargetSelfCanonical: target ? target.canonical.length === 1 && target.canonical[0] === target.finalUrl : null,
      ogUrl: f.og?.["og:url"] ?? null,
    };
  })(), item.uri, [...own, ...(f.isHtml && f.canonical.length === 1 && F(f.canonical[0]) ? [F(f.canonical[0]).content.evidenceId] : [])], [
    ...derivedLimits, "A declared canonical does not establish the engine-selected canonical; sitemap membership was not collected in this pilot",
  ]);
  if (f.isHtml) {
    const counterpartUri = f.lang === "en" ? f.hreflang.vi : f.hreflang.en;
    const cp = F(counterpartUri);
    k["locale-map"] = add(item.itemId, "locale-map", {
      requestedUri: item.uri, finalUrl: f.finalUrl, htmlLang: f.lang, hreflang: f.hreflang,
      selfReferenceMatchesFinalUrl: f.hreflang[f.lang] === f.finalUrl,
      counterpart: counterpartUri, counterpartHttpStatus: cp?.status ?? null, counterpartHtmlLang: cp?.lang ?? null,
      counterpartHreflang: cp?.hreflang ?? null,
      reciprocal: !!cp && JSON.stringify(cp.hreflang) === JSON.stringify(f.hreflang),
      xDefault: f.hreflang["x-default"] ?? null,
      languageSwitchLinksInBody: f.internal.filter((l) => l.resolved === counterpartUri).length,
    }, item.uri, [...own, ...(cp ? [cp.content.evidenceId] : [])], [
      ...derivedLimits, "Reciprocity was checked between captured annotations only; engine-selected language targeting was not observed",
    ]);
    k["media-inventory"] = add(item.itemId, "media-inventory", {
      imgElements: f.imgs, elementCounts: f.counts, ariaHiddenElements: f.ariaHiddenContainers,
      ogImage: f.og["og:image"] ?? null,
      notCollected: ["og:image file", "stylesheets (possible CSS background imagery)", "favicon", "web fonts"],
    }, item.uri, own, [...derivedLimits, "Only media referenced in the raw HTML markup is inventoried; CSS-delivered imagery and the og:image file were not fetched"]);
    k["schema-extraction"] = add(item.itemId, "schema-extraction", {
      ...f.schema, openGraph: f.og,
      scriptElements: f.scripts,
      note: "No application/ld+json script, microdata or RDFa attribute was found in the captured raw HTML body. Script elements are listed as source text references only and were never executed.",
    }, item.uri, own, [...derivedLimits, "Absence in raw source does not establish absence in a rendered DOM"]);
  }
  const targets = [...new Set(f.internal.map((l) => l.targetItemId).filter(Boolean))].map((id) => facts.get(id).content.evidenceId);
  k["link-graph"] = add(item.itemId, "link-graph", {
    requestedUri: item.uri, finalUrl: f.finalUrl,
    internalLinks: f.internal, externalLinksNotFetched: f.external, nonHttpLinks: f.nonHttp,
    inboundFromInventory: f.inbound,
    plainTextFileReferencesNotHyperlinked: f.isHtml ? [] : [...f.text.matchAll(/Full notice: (\S+)/g)].map((m) => m[1]),
  }, item.uri, [...own, ...targets], [
    ...derivedLimits,
    "Static a[href] links among the 12 collected items only; rendered navigation, sitemap entries and orphan pages are not covered",
    "External link targets and non-anchor resources (CSS, scripts, fonts, images) were not fetched or checked",
  ]);
  const versions = [...new Set(f.text.match(/\b\d+\.\d+\.\d+\b/g) ?? [])].sort();
  k["entity-record"] = add(item.itemId, "entity-record", {
    pageMentions: {
      versionsFound: versions,
      mentions: Object.fromEntries(["NKSkills", "NK Skills", "Codex", "Claude Code", "codebase-onboarding", "Codebase onboarding", "problem-presentation", "Problem presentation", "content-search-audit", "Content search audit", "Hallmark", "technical release", "evaluation candidate", "bản kỹ thuật", "ứng viên đánh giá"].map((n) => [n, f.text.split(n).length - 1])),
    },
    siteEntityTable: SITE_ENTITY_TABLE,
  }, item.uri, [f.content.evidenceId, ...allContentIds], [
    ...derivedLimits,
    "Reviewer-compiled cross-page table of the site's own statements; it is not an authoritative external entity record and does not verify the statements against the GitHub release records",
  ]);
  k["inventory-map"] = add(item.itemId, "inventory-map", { declaredInventory: inventoryMap, discoveryScope: "static a[href] navigation from https://nkskills.getgroove.me/ (maxPages=30, maxDepth=5); scopeComplete=false: CMS records, orphan pages, sitemap entries and rendered navigation not supplied" }, "campaign inventory: " + campaign, [f.content.evidenceId, ...allContentIds], [
    ...derivedLimits, "Purpose labels are reviewer classifications; the inventory is the declared static-link scope, not a proven complete site inventory",
  ]);
  ids.set(item.itemId, k);
}

// ---------- reviews ----------
const review = (itemId, ruleId, status, reason, evidenceIds) =>
  reviews.push({ itemId, ruleId, status, reason, evidenceIds: [...new Set(evidenceIds)], reviewer, reviewedAt: now });
const isGuide = (u) => u.includes("/guides/");
const isHome = (u) => /\/(en|vi)\/$/.test(u) || u === ORIGIN + "/";
const isCatalog = (u) => u.includes("/catalog/");
const isSolution = (u) => u.includes("/solutions/");
const journeyFail = [];
const guideStale = [];
const gateWording = [];

for (const item of htmlItems) {
  const f = facts.get(item.itemId), k = ids.get(item.itemId), u = item.uri;
  const viaRoot = u === ORIGIN + "/" ? " (requested root URL; content is the /en/ page reached through a 308 redirect)" : "";

  // media
  assert.equal(f.imgs.length, 1); assert.equal(f.imgs[0].alt, ""); assert.ok(f.imgs[0].hasAltAttribute);
  for (const t of ["svg", "video", "audio", "iframe", "picture", "canvas", "object", "embed"]) assert.equal(f.counts[t], 0);
  assert.ok(f.anchors.some((a) => a.ariaLabel === "NKSkills home"));
  review(item.itemId, "quality-accessible-media", "pass",
    `Raw HTML contains one img (${f.imgs[0].src}) with an explicit empty alt inside the home link that carries aria-label "NKSkills home", so the mark is decorative and the link keeps a text name. No svg, video, audio, iframe, picture, canvas, object or embed element is present; ${f.ariaHiddenContainers} aria-hidden decorative elements` +
    (f.counts.figure ? `; the ${f.counts.figure} figure element(s) carry a figcaption and an adjacent text description of the workflow diagram` : "") +
    `. Scope limit: CSS-delivered imagery, the og:image file and rendered output were not collected, so this covers media referenced in the captured markup only${viaRoot}.`,
    [k.content, k["media-inventory"]]);

  // canonical
  assert.equal(f.canonical.length, 1); assert.equal(f.canonical[0], f.finalUrl); assert.equal(f.linkHeader, null);
  const ct = F(f.canonical[0]); assert.ok(ct && ct.status === 200 && ct.canonical[0] === ct.finalUrl);
  review(item.itemId, "seo-canonical", "pass",
    `One rel=canonical is declared (${f.canonical[0]}) and equals the final response URL; that URL is in the inventory, returned HTTP 200 and declares itself canonical. No HTTP Link header was captured, og:url matches, and the EN/VI variants each self-canonicalise rather than pointing at the other locale` +
    (viaRoot ? `. The root URL 308-redirects to /en/, consistent with the declared canonical` : "") +
    `. Not established: the engine-selected canonical and sitemap consistency (sitemap.xml was not in this pilot's static-link scope).`,
    [k.content, k["canonical-targets"]]);
  assert.equal(f.og["og:url"], f.finalUrl);

  // locales
  const cpUri = f.lang === "en" ? f.hreflang.vi : f.hreflang.en; const cp = F(cpUri);
  assert.deepEqual(Object.keys(f.hreflang).sort(), ["en", "vi", "x-default"]);
  assert.equal(f.hreflang[f.lang], f.finalUrl); assert.ok(cp && cp.status === 200);
  assert.deepEqual(cp.hreflang, f.hreflang); assert.notEqual(cp.lang, f.lang);
  assert.equal(f.hreflang["x-default"], f.hreflang.en);
  assert.ok(f.internal.some((l) => l.resolved === cpUri));
  review(item.itemId, "seo-locales", "pass",
    `html lang="${f.lang}" matches the page language; hreflang declares en, vi and x-default (x-default = the en URL), the self-reference equals the final URL, and the counterpart ${cpUri} returned 200 with lang="${cp.lang}" and the identical reciprocal annotation set. Each variant self-canonicalises, so canonical and hreflang do not conflict, and a visible language-switch link to the counterpart is present${viaRoot}. Not established: engine-selected language results. Content parity between the two languages is reviewed under the entity and portfolio checks.`,
    [k.content, k["locale-map"]]);

  // internal links
  assert.ok(f.internal.length > 0);
  for (const l of f.internal) { assert.ok(l.targetItemId, `uncollected internal target ${l.resolved}`); assert.equal(l.targetStatus, 200); if (l.fragment !== null) assert.equal(l.fragmentFoundInTargetSource, true, `${u} -> ${l.href}`); }
  if (u !== ORIGIN + "/") assert.ok(f.inbound.length > 0);
  review(item.itemId, "seo-internal-links", "pass",
    `All ${f.internal.length} same-origin a[href] links in the raw HTML resolve to ${new Set(f.internal.map((l) => l.resolved)).size} collected inventory URLs that returned HTTP 200, and every fragment target (${[...new Set(f.internal.filter((l) => l.fragment).map((l) => "#" + l.fragment))].join(", ") || "none"}) exists as an id in the captured target source. ` +
    (u === ORIGIN + "/" ? `This is the crawl seed; it 308-redirects to /en/ and no collected page links to the bare root. ` : `The page has static inbound links from ${f.inbound.length} collected page(s). `) +
    `Scope limit: only the declared static-link graph of 12 items; ${new Set(f.external.map((e) => e.url)).size} distinct external (github.com) link targets and non-anchor resources were not fetched, and incomplete discovery cannot prove or exclude orphan pages.`,
    [k.content, k["link-graph"]]);

  // entity consistency
  const versions = [...new Set(f.text.match(/\b\d+\.\d+\.\d+\b/g) ?? [])];
  for (const v of versions) assert.ok(KNOWN_VERSIONS.has(v), `unexpected version ${v} on ${u}`);
  review(item.itemId, "aio-entity-consistency", "pass",
    `Entity facts on this page agree with the other collected pages: brand NKSkills, hosts Codex and Claude Code, and only the version strings ${versions.sort().join(", ") || "(none)"} appear, each matching the site-wide table (codebase onboarding 1.1.0 technical release; problem presentation 0.1.0 and content search audit 0.1.32 evaluation candidates). No conflicting name, version, host, status or limitation statement was found across the 12 snapshots or between the EN and VI counterparts${viaRoot}. Caveat persisted separately: the release-gate status is worded differently across pages (finding gate-wording-ambiguous). Not done: verification against the GitHub release records, which are outside the authorized origin; this is cross-page consistency, not factual verification.`,
    [k.content, k["entity-record"]]);

  // retrievable facts
  assert.ok(f.text.length > 1500);
  review(item.itemId, "aio-retrievable-facts", "pass",
    `The facts a ${f.lang === "vi" ? "Vietnamese" : "English"}-reading developer needs from this page (what the product/skill is, version and release status, supported hosts, ` +
    (isGuide(u) ? "prerequisites, build/install commands and invocation tokens" : isCatalog(u) ? "sources, licences and pinned revisions" : isSolution(u) ? "components, outputs, prerequisites and current limits" : "workflow model, install path and stated limits") +
    `) are present as plain text in the raw HTML response (${f.text.length} characters of extracted text) with their qualifying limits adjacent; they do not depend on script execution` +
    (f.counts.template ? `. The alternative starter-prompt variants sit in ${f.counts.template} inert template elements and need the page script to be shown; the default prompt is in the static markup` : "") +
    `${viaRoot}. Readable facts do not prove retrieval or citation by any engine; no AI surface was observed.`,
    [k.content, k["audience-context"]]);

  // duplication
  review(item.itemId, "portfolio-duplication", "pass",
    (u === ORIGIN + "/" ? `Byte-identical to the /en/ item (same content hash) because the root URL 308-redirects to /en/ and the canonical points there; this is an alias, not competing content. `
      : u === ORIGIN + "/en/" ? `The root URL item is byte-identical only because it redirects here; this page is the canonical target. `
      : isGuide(u) ? `Shares most structure with the other host's guide, but the differences are the task-relevant ones (install target flag, skills directory and invocation token), so the two guides are legitimate host variants. ` : "") +
    `Its ${f.lang === "en" ? "Vietnamese" : "English"} counterpart is a declared locale variant, not duplication, and no other collected item covers the same task for the same audience. Cannibalization cannot be assessed without query/page data.`,
    [k.content, k["inventory-map"]]);

  // contradictions
  review(item.itemId, "portfolio-contradictions", "pass",
    `No material claim on this page conflicts with another collected page or with its locale counterpart: versions, release statuses, host support, component count (3), stated counts (03 Solution Skills, 15 upstream skills, 06 security sources) and the no-direct-download distribution statement are consistent where they appear${viaRoot}. Wording differences about the commercial release gate express the same status and are recorded as a clarity finding, not a contradiction. Resolution against authoritative external records (GitHub release records, catalog.yaml) was not possible within the authorized origin.`,
    [k.content, k["entity-record"], k["inventory-map"]]);

  // metadata + task fit + journey by page type
  assert.ok(f.title && f.description);
  if (isGuide(u)) {
    const staleIntro = f.lang === "en" ? "The Problem presentation trial at the end of this guide has separate evaluation criteria." : "Phần thử Problem presentation ở cuối trang có điều kiện đánh giá riêng.";
    assert.ok(f.text.includes(staleIntro));
    assert.ok(f.ids.has("content-search-audit"));
    assert.ok(!/audit/i.test(f.description) && !/audit/i.test(f.title));
    assert.ok(f.text.indexOf("0.1.32") > f.text.indexOf(staleIntro));
    guideStale.push(item.itemId);
    review(item.itemId, "seo-metadata", "fail",
      `Title ("${f.title}") and h1 accurately name the page, but the meta description ("${f.description}") describes two of the three tasks the page serves: section 06 (id="content-search-audit", "Content search audit · 0.1.32"), which the home and catalog pages deep-link to, is not represented in the title, description or opening text. The prerequisites intro also says "${staleIntro}" although the Problem presentation section (05) is followed by the Content search audit section (06). Low severity: nothing is misleading about the two described tasks; the metadata and intro are incomplete/stale for the third.`,
      [k.content, k["audience-context"]]);
    review(item.itemId, "quality-task-fit", "unknown",
      `Inferred task: install and invoke NKSkills in ${u.includes("claude-code") ? "Claude Code" : "Codex"}. Supported components: prerequisites are listed, build/install commands are ordered, the install location and invocation tokens are given, and limits are stated. Unresolved component: obtaining and setting up codegraph, rtk and a valid CodeGraph index is delegated to the GitHub technical guide, which is outside the authorized origin and was not collected, so whether the page plus its linked setup material lets a new user complete the task is not established. One narrow defect is persisted separately (finding guide-meta-intro-stale).`,
      [k.content, k["audience-context"]]);
    assert.ok(f.internal.some((l) => l.fragment === "install") && f.internal.some((l) => l.fragment === "try-it"));
    review(item.itemId, "portfolio-journey-links", "pass",
      `From this guide a user can return to the home install section (#install) and the starter prompt (#try-it), switch language, reach the catalog, and follow in-context links to the technical setup, evaluation and release records on GitHub (external, not fetched). Next steps after installation are stated on the page. Observation, not a failure: the guide does not link to the other host's guide; the home page offers both.`,
      [k.content, k["link-graph"], k["audience-context"]]);
  } else {
    review(item.itemId, "seo-metadata", "pass",
      `Title ("${f.title}"), meta description and h1 describe this page's actual subject in the page language and are distinct from every other collected page of the same language${viaRoot ? " (the /en/ item shares them only because this URL redirects there)" : ""}. ` +
      (isHome(u) ? `Optional improvement, not a defect: the description names two of the three Solution Skills shown on the page (Content search audit 0.1.32 is not mentioned). ` : "") +
      `No fixed length or keyword rule was applied.`,
      [k.content, k["audience-context"]]);
    review(item.itemId, "quality-task-fit", "pass",
      `Inferred task (labelled inference; audience from the supplied context): ` +
      (isHome(u) ? `understand what NKSkills offers and choose a next step. The page states the model, the three Solution Skills with version and release status, the install path, a starter prompt with its safety conditions, limits, and an FAQ, with links onward to guides, catalog and solution page.`
        : isCatalog(u) ? `inspect which Solution Skills and upstream skills exist and their provenance. The page lists each Solution Skill with version/status and each tracked source with role, licence and pinned commit prefix, states what listing does and does not imply, and links to the full catalog.yaml record.`
        : `evaluate the codebase-onboarding Solution Skill before use. The page states the outcome, the three components and their origin, required outputs, prerequisites, distribution status and verification limits, with links to both host guides and the release record.`) +
      ` Clarity caveats are persisted as separate low-severity findings where applicable${viaRoot}.`,
      [k.content, k["audience-context"]]);
    const csa = f.internal.filter((l) => l.fragment === "content-search-audit");
    if (isHome(u) || isCatalog(u)) {
      assert.ok(csa.length >= 1 && csa.every((l) => l.resolved.includes("/guides/codex/")));
      assert.ok(F(ORIGIN + `/${f.lang}/guides/claude-code/`).ids.has("content-search-audit"));
      journeyFail.push(item.itemId);
      review(item.itemId, "portfolio-journey-links", "fail",
        `The only next-step link for Content search audit on this page ("${csa[0].text}" → ${csa[0].href}) goes to the Codex guide. The site states the skill supports both hosts and the Claude Code guide has the same section (id="content-search-audit") with different commands (--target claude-code, .claude/skills/, /content-search-audit), but no link from this page leads a Claude Code user to it. Other journeys on the page (codebase onboarding → solution page and both guides; catalog; language switch) are intact${viaRoot}.`,
        [k.content, k["link-graph"], k["audience-context"]]);
    } else {
      assert.ok(f.internal.some((l) => l.resolved.includes("/guides/codex/")) && f.internal.some((l) => l.resolved.includes("/guides/claude-code/")));
      review(item.itemId, "portfolio-journey-links", "pass",
        `The page links to both host guides as the next step, back to home and catalog, to its locale counterpart, and to the release record, manifest and technical setup on GitHub (external, not fetched).`,
        [k.content, k["link-graph"], k["audience-context"]]);
    }
  }
  if (!isGuide(u) && !isSolution(u)) {
    const en = f.lang === "en";
    const hit = en ? /commercial release gate remains open/i.test(f.text) : f.text.includes("cổng phát hành thương mại vẫn mở");
    if (hit) gateWording.push(item.itemId);
  }
}
// gate wording assertions (complete assertions in each source)
assert.ok(F(ORIGIN + "/en/").text.includes("The commercial release gate remains open."));
assert.ok(F(ORIGIN + "/en/").text.includes("No. Version 0.1.0 is an evaluation candidate, and the commercial release gate remains open."));
assert.ok(F(ORIGIN + "/en/catalog/").text.includes("Commercial release gate remains open."));
assert.ok(F(ORIGIN + "/vi/").text.includes("Chưa. Bản 0.1.0 là ứng viên đánh giá; cổng phát hành thương mại vẫn mở."));
assert.ok(F(ORIGIN + "/vi/").text.includes("Chưa qua cổng phát hành thương mại."));
assert.ok(F(ORIGIN + "/vi/catalog/").text.includes("Chưa qua cổng phát hành thương mại."));
assert.ok(F(ORIGIN + "/en/guides/codex/").text.includes("Version 0.1.0 has not passed the commercial release gate."));
assert.equal(gateWording.length, 4);
assert.equal(journeyFail.length, 5);
assert.equal(guideStale.length, 4);

// catalog card count vs stated 15
for (const loc of ["en", "vi"]) {
  const c = F(ORIGIN + `/${loc}/catalog/`);
  assert.equal(c.anchors.filter((a) => (a.ariaLabel ?? "").endsWith(" source")).length, 15);
  assert.ok(c.text.includes("15 Upstream Skills") && c.text.includes("03 Solution Skills"));
}

// README.txt
const readme = inv.find((i) => i.uri.endsWith("/licenses/README.txt"));
{
  const f = facts.get(readme.itemId), k = ids.get(readme.itemId);
  assert.equal(f.contentType, "text/plain"); assert.equal(f.linkHeader, null); assert.equal(f.xRobotsTag, null);
  assert.ok(!/https?:/.test(f.text));
  for (const n of ["fraunces-OFL.txt", "source-sans-3-OFL.txt", "ibm-plex-mono-OFL.txt"]) assert.ok(f.text.includes(`Full notice: ${n}`));
  assert.equal(f.inbound.length, 11);
  review(readme.itemId, "quality-accessible-media", "not-applicable",
    "The captured response is text/plain (377 bytes of font licence notices); a plain-text file cannot embed images, audio or video, so there is no media needing a text alternative or transcript.",
    [k.content, k.http]);
  review(readme.itemId, "seo-metadata", "not-applicable",
    "The captured response is text/plain; the format has no title element, meta description or heading markup to review. Its first line (\"NKSkills site font notices\") identifies the file.",
    [k.content, k.http]);
  review(readme.itemId, "quality-task-fit", "unknown",
    "The file names each font, its author and licence (SIL Open Font License 1.1). Each entry points to a \"Full notice\" file by bare filename only; those files are not hyperlinked, were not discoverable and were not collected, so whether a reader can reach the full licence texts is not established. The supplied audience context does not address this legal-notice task.",
    [k.content, k["audience-context"]]);
  review(readme.itemId, "seo-canonical", "unknown",
    "No canonical is declared: the response is text/plain and no HTTP Link header was captured. No duplicate or variant of this file is known in the collected inventory, but publisher intent for indexing/canonicalising a licence notice is not supplied, so no verdict is given.",
    [k.content, k["canonical-targets"]]);
  review(readme.itemId, "seo-internal-links", "unknown",
    "Inbound: linked from the footer of all 11 collected HTML items (the 10 /en/ and /vi/ pages plus the root URL, which serves the /en/ page). Outbound: none as hyperlinks; three notice files are referenced by filename only (fraunces-OFL.txt, source-sans-3-OFL.txt, ibm-plex-mono-OFL.txt). Their URLs were neither linked nor fetched (text/plain navigation needs its own adapter and remains in the discovery queue), so their existence is unverified.",
    [k.content, k["link-graph"]]);
  review(readme.itemId, "aio-entity-consistency", "unknown",
    "The file attributes three fonts to named authors under SIL OFL 1.1. The HTML pages preload Fraunces and Source Sans 3 font files; IBM Plex Mono usage and the actual font set could only be confirmed from stylesheets, which were not collected, and no authoritative licence record was supplied.",
    [k.content, k["entity-record"]]);
  review(readme.itemId, "aio-retrievable-facts", "unknown",
    "The font names, authors and licence are readable plain text, but the supplied audience context does not identify any needed facts for this legal notice and the full notices it refers to were not collected.",
    [k.content, k["audience-context"]]);
  review(readme.itemId, "portfolio-duplication", "pass",
    "The only collected item covering font licence notices; no overlapping item exists in the declared inventory. It is a single English plain-text file with no locale variant, linked from both language footers.",
    [k.content, k["inventory-map"]]);
  review(readme.itemId, "portfolio-contradictions", "pass",
    "Its claims (font names, authors, SIL OFL 1.1) are made nowhere else in the collected inventory, and nothing in the other 11 snapshots conflicts with them. The claims themselves were not verified against the full notice files or upstream font licences, which were not collected.",
    [k.content, k["entity-record"], k["inventory-map"]]);
  review(readme.itemId, "portfolio-journey-links", "unknown",
    "Reached from every page footer. As a plain-text file it has no navigation back to the site and its three \"Full notice\" references are not links; whether that matters to the audience is not established by the supplied context (finding license-notices-unlinked records the observation).",
    [k.content, k["link-graph"], k["audience-context"]]);
}

// ---------- findings ----------
const kOf = (id) => ids.get(id);
const findings = [
  {
    findingId: "csa-cta-codex-only",
    title: "Content search audit call-to-action sends users of both hosts to the Codex guide only",
    observation: "On the home pages (/, /en/, /vi/) and catalog pages (/en/catalog/, /vi/catalog/) the only link for installing Content search audit targets /{locale}/guides/codex/#content-search-audit. The Claude Code guides contain an equivalent section with different commands, but nothing on these pages links to it.",
    affectedItemIds: journeyFail,
    ruleIds: ["portfolio-journey-links"],
    dimensions: ["portfolio"],
    evidenceIds: journeyFail.flatMap((id) => [kOf(id).content, kOf(id)["link-graph"]]),
    severity: "medium",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "The link target is observed in the captured source of all five pages and the Claude Code section exists in the captured guides; adding the missing path is a small template change.",
    remediation: "On the Content search audit card (home) and catalog entry, offer both host guides, e.g. link to /{locale}/guides/codex/#content-search-audit and /{locale}/guides/claude-code/#content-search-audit, or link to a host-neutral chooser as is already done for codebase onboarding.",
    verification: "Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and confirm each Content search audit entry has a static link resolving to the Claude Code guide's #content-search-audit id as well as the Codex one, and that both fragment ids still exist in the guide sources.",
    ownerRole: "Site maintainer (page templates) — proposed, not confirmed by the owner",
    effort: "small",
  },
  {
    findingId: "guide-meta-intro-stale",
    title: "Guide descriptions and intro text predate the Content search audit section",
    observation: "All four guide pages have a section 06 for Content search audit 0.1.32 (deep-linked from home and catalog), but their title and meta description mention only codebase onboarding and the presentation candidate, and the prerequisites intro says the Problem presentation trial is 'at the end of this guide' / 'ở cuối trang', which is no longer the last section.",
    affectedItemIds: guideStale,
    ruleIds: ["seo-metadata", "quality-task-fit"],
    dimensions: ["seo", "quality"],
    evidenceIds: guideStale.flatMap((id) => [kOf(id).content, kOf(id)["audience-context"]]),
    severity: "low",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "Both the omission and the positional statement are observed in the captured source of all four guides.",
    remediation: "Update each guide's meta description (and og:description) to mention the content search audit install, and reword the prerequisites intro so it no longer says the Problem presentation trial is at the end of the guide (for example, name sections 05 and 06 explicitly). Apply the same change to the English and Vietnamese versions.",
    verification: "Re-capture the four guide URLs and confirm the description names all three installable skills and the intro sentence matches the actual section order; confirm EN and VI say the same thing.",
    ownerRole: "Site content owner — proposed, not confirmed by the owner",
    effort: "small",
  },
  {
    findingId: "gate-wording-ambiguous",
    title: "Problem presentation release status is phrased as an 'open gate' on some pages and 'has not passed the gate' on others",
    observation: "English home (card and FAQ) and English catalog say the commercial release gate 'remains open'; the Vietnamese home FAQ says 'cổng phát hành thương mại vẫn mở', while the Vietnamese home card and catalog say 'Chưa qua cổng phát hành thương mại' and the guides say the version 'has not passed the commercial release gate'. All express the same status, but 'gate remains open' can also be read as 'release is available'.",
    affectedItemIds: gateWording,
    ruleIds: ["quality-task-fit"],
    dimensions: ["quality"],
    evidenceIds: gateWording.flatMap((id) => [kOf(id).content, kOf(id)["entity-record"]]),
    severity: "low",
    confidence: "medium",
    classification: "inferred",
    action: "update",
    actionReason: "The differing phrasings are observed; that readers or answer engines misread 'remains open' is an inference, not an observed outcome.",
    remediation: "Use one unambiguous phrasing everywhere, matching the guides: EN 'has not passed the commercial release gate'; VI 'chưa qua cổng phát hành thương mại'. Change the English home card, home FAQ and catalog entry, and the Vietnamese home FAQ answer.",
    verification: "Re-capture /en/, /vi/, /en/catalog/ and /vi/catalog/ and search the text for 'remains open' and 'vẫn mở'; each Problem presentation status sentence should use the 'has not passed' / 'chưa qua' form.",
    ownerRole: "Site content owner — proposed, not confirmed by the owner",
    effort: "small",
  },
  {
    findingId: "license-notices-unlinked",
    title: "Font licence README names three full-notice files that are not linked and could not be verified",
    observation: "/licenses/README.txt says 'Full notice: fraunces-OFL.txt', 'Full notice: source-sans-3-OFL.txt' and 'Full notice: ibm-plex-mono-OFL.txt' as bare filenames. No collected page links to those files, so the static crawl did not discover or fetch them; their existence at /licenses/ is unverified.",
    affectedItemIds: [readme.itemId],
    ruleIds: ["seo-internal-links", "portfolio-journey-links"],
    dimensions: ["seo", "portfolio"],
    evidenceIds: [kOf(readme.itemId).content, kOf(readme.itemId)["link-graph"]],
    severity: "low",
    confidence: "medium",
    classification: "inferred",
    action: "investigate",
    actionReason: "The unlinked filenames are observed; whether the files exist and whether readers need direct links is not established by the captured evidence.",
    actionCondition: "the three notice files are meant to be publicly reachable next to README.txt",
    remediation: "Give the full URL of each notice in README.txt (or link the notices from an HTML licences page) so the full licence texts are reachable from the site footer path.",
    verification: "Fetch the three notice URLs in an authorized capture and confirm HTTP 200 with the SIL OFL 1.1 text, and confirm README.txt (or its replacement) points to them by resolvable URL.",
    ownerRole: "Site maintainer — proposed, not confirmed by the owner",
    effort: "small",
  },
];

const bundle = {
  schemaVersion: 1,
  campaignId: index.campaignId,
  sourceManifestHash: index.sourceManifestHash,
  parts: [{ path: "parts/000001", sourceSnapshotHash: index.partSnapshotHashes["parts/000001"], bundle: { reviews, evidence, artifacts, findings } }],
};
await mkdir(path.join(pilot, "bundles"), { recursive: true });
const out = path.join(pilot, "bundles", "part-review-r2.json");
await writeFile(out, JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
const tally = {};
for (const r of reviews) tally[`${r.ruleId}:${r.status}`] = (tally[`${r.ruleId}:${r.status}`] ?? 0) + 1;
console.log(JSON.stringify({ written: out, builtAt: now, reviews: reviews.length, evidence: evidence.length, findings: findings.map((f) => [f.findingId, f.affectedItemIds.length]), tally }, null, 1));
