# https://nkskills.getgroove.me/en/catalog/
itemId: f66acb165422f66719a813b9fd8e1a820a19fd4c2f7b5d992faaa699df582c26
contentEvidence: 5a5d590c6c69906f4df8412778c40f2fc03c7f034660ae682cbc01a0a7d9d62d
httpEvidence: ca89eea2c0fdec658d1aa8e2989b33a8c382d55e0040f7d1fa601b1d5ed46973
robotsEvidence: 9dbd51af808176d53c0396591184a7d2bfde4c9a939086850edc158ebb56051a
bytes(chars): 14502

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/en/catalog/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/en/catalog/",
   "collectedAt": "2026-11-18T08:24:33.888Z",
   "retryAfter": null
  }
 ],
 "wireHash": "6ee522c6d3047e111159daec48a86ea6a2cc5e45a1976d50c5944ec897e63822"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:33.627Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:33.627Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="en">

## title
Skill catalog | NKSkills

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Explore NKSkills Solution Skills and pinned public Upstream Skills, including sources, versions, licenses, and release status.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/en/catalog/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/catalog/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/catalog/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/catalog/">
<meta property="og:type" content="website">
<meta property="og:title" content="Skill catalog | NKSkills">
<meta property="og:description" content="Explore NKSkills Solution Skills and pinned public Upstream Skills, including sources, versions, licenses, and release status.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-en.png">
<meta property="og:url" content="https://nkskills.getgroove.me/en/catalog/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">
<link rel="stylesheet" href="/_astro/CatalogPage.BhNzWDKD.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: The skills behind the workflow.
h2: Workflows packaged around an outcome.
h3: Codebase onboarding 1.1.0
h3: Problem presentation 0.1.0
h3: Content search audit 0.1.32
h2: Public sources, precise revisions.
h3: Multiple sources, distinct jobs.
h2: Updates, with a review step.

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Skip to content
/en/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/#try-it | rel=null | hreflang=null | aria=null | Try it
/vi/catalog/ | rel=null | hreflang=null | aria=Chuyển sang tiếng Việt | VI
#solutions | rel=null | hreflang=null | aria=null | 03 Solution Skills
#upstreams | rel=null | hreflang=null | aria=null | 15 Upstream Skills
#security-upstreams | rel=null | hreflang=null | aria=null | 06 Security sources
#method | rel=null | hreflang=null | aria=null | 01 Versioning model
/en/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=View codebase onboarding solution | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/problem-presentation.yaml | rel=null | hreflang=null | aria=View problem presentation manifest | ↗
/en/guides/codex/#content-search-audit | rel=null | hreflang=null | aria=Install Content search audit | ↗
https://github.com/nutlope/hallmark/tree/13ac0ec7e148655948100b6396439e481361d690/skills/hallmark | rel=null | hreflang=null | aria=hallmark source | ↗
https://github.com/claude-office-skills/skills/tree/9c4c7d5cd2813a8936bf2c9fdb174ea883b85a11/html-slides | rel=null | hreflang=null | aria=html-slides-reference source | ↗
https://github.com/tt-a1i/archify/tree/88d1ae4498b6a1df610badf690c5406882622d15/archify | rel=null | hreflang=null | aria=archify source | ↗
https://github.com/cathrynlavery/diagram-design/tree/550fd66edff058bc73056c3416b76d69cfe865ba/skills/diagram-design | rel=null | hreflang=null | aria=diagram-design source | ↗
https://github.com/nicobailon/visual-explainer/tree/5a1b3c4d6e86c6d0225c6d8ee0972f4d02108be2/plugins/visual-explainer | rel=null | hreflang=null | aria=visual-explainer source | ↗
https://github.com/anthropics/skills/tree/dbd4588f9e1033efb41dad4bef2f7947c8993d44/skills/frontend-design | rel=null | hreflang=null | aria=frontend-design source | ↗
https://github.com/coreyhaines31/marketingskills/tree/365b412152b9542499ca1439426f7fc3cc92bb65/skills/copywriting | rel=null | hreflang=null | aria=copywriting source | ↗
https://github.com/Leonxlnx/taste-skill/tree/12af471f627f866411b4bd785b19646d3672784c/skills/taste-skill | rel=null | hreflang=null | aria=design-taste-frontend source | ↗
https://github.com/pbakaus/impeccable/tree/b7a89176e4e87422b40f98adabceb051dbb5448b/.agents/skills/impeccable | rel=null | hreflang=null | aria=impeccable source | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/research/security-upstreams.md | rel=null | hreflang=null | aria=null | Read the source review ↗
https://github.com/cloudflare/security-audit-skill/tree/c1c8a8c1471069fb0e188eeaff69b8e8db6564a8/skills/security-audit | rel=null | hreflang=null | aria=security-audit source | ↗
https://github.com/getsentry/skills/tree/0c464f411bdfb8d4c12314b36264d06cb2f60270/skills/security-review | rel=null | hreflang=null | aria=security-review source | ↗
https://github.com/addyosmani/agent-skills/tree/301b02b12bff98e4688e6984af6556802322bbde/skills/security-and-hardening | rel=null | hreflang=null | aria=security-and-hardening source | ↗
https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/security-best-practices | rel=null | hreflang=null | aria=security-best-practices source | ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/check-skills | rel=null | hreflang=null | aria=codex-security-check-skills source | ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/security-scan | rel=null | hreflang=null | aria=codex-security-scan source | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/catalog.yaml | rel=null | hreflang=null | aria=null | catalog.yaml ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/product-model.md | rel=null | hreflang=null | aria=null | Read the product model →
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Release record
/licenses/README.txt | rel=null | hreflang=null | aria=null | Font licenses
/vi/catalog/ | rel=null | hreflang=null | aria=null | Tiếng Việt

## visible text by block (tags removed)
Skip to content
<div> NK Skills
<nav> Solutions Catalog Try it VI
<p> NKSKILLS / CATALOG
<h1> The skills behind the workflow.
<p> NKSkills has two layers: Solution Skills define the outcome and sequence; Upstream Skills provide selected capabilities with pinned versions and recorded sources.
<div> 03 Solution Skills 15 Upstream Skills 06 Security sources 01 Versioning model
<p> 01 / SOLUTION SKILLS
<h2> Workflows packaged around an outcome.
<p> Each Solution Skill has its own version, component manifest, and verification criteria. These statuses reflect current evidence.
<div> 01 / TECHNICAL RELEASE
<h3> Codebase onboarding 1.1.0
<p> Trace a product journey, C1/C2 views, and file evidence before changing code.
<div> Codex Claude Code 3 components
</div> ↗
<div> 02 / EVALUATION CANDIDATE
<h3> Problem presentation 0.1.0
<p> Create an offline HTML and PDF deck around one evidenced problem and decision. Commercial release gate remains open.
<div> Codex Claude Code In evaluation
</div> ↗
<div> 03 / EVALUATION CANDIDATE
<h3> Content search audit 0.1.32
<p> One skill for content quality, SEO, AIO, AEO and GEO audits, with evidence, explicit coverage and prioritized actions. Review findings before applying changes.
<div> Codex Claude Code 1 skill
</div> ↗
<p> 02 / UPSTREAM SKILLS
<h2> Public sources, precise revisions.
<p> This catalog tracks source, commit, and license. Some skills help author this website; listing one here does not make it part of a released Solution Skill.
<div> hallmark Tracked source
<div> design documentation
<div> MIT
<code> 13ac0ec7e1
</div> ↗
<div> html-slides-reference Tracked source
<div> presentation slides
<div> MIT
<code> 9c4c7d5cd2
</div> ↗
<div> archify Tracked source
<div> diagrams architecture
<div> MIT
<code> 88d1ae4498
</div> ↗
<div> diagram-design Tracked source
<div> diagrams design
<div> MIT
<code> 550fd66edf
</div> ↗
<div> visual-explainer Tracked source
<div> presentation slides
<div> MIT
<code> 5a1b3c4d6e
</div> ↗
<div> frontend-design Authoring tool
<div> design frontend
<div> Apache-2.0
<code> dbd4588f9e
</div> ↗
<div> copywriting Authoring tool
<div> marketing copywriting
<div> MIT
<code> 365b412152
</div> ↗
<div> design-taste-frontend Authoring tool
<div> design frontend
<div> MIT
<code> 12af471f62
</div> ↗
<div> impeccable Recommended with Taste
<div> design frontend
<div> Apache-2.0
<code> b7a89176e4
</div> ↗
<p> TOPIC / SECURITY
<h3> Multiple sources, distinct jobs.
<p> Audit, review, hardening, and secure coding guidance are tracked separately. No security Solution Skill is released; licensing, runtime, and packaging still need review. Read the source review ↗
<div> security-audit Tracked security source
<div> security audit
<div> MIT
<code> c1c8a8c147
</div> ↗
<div> security-review Tracked security source
<div> security code-review
<div> Apache-2.0 with CC-BY-SA-4.0 reference material
<code> 0c464f411b
</div> ↗
<div> security-and-hardening Tracked security source
<div> security hardening
<div> MIT
<code> 301b02b12b
</div> ↗
<div> security-best-practices Tracked security source
<div> security best-practices
<div> Apache-2.0
<code> 49f948faa9
</div> ↗
<div> codex-security-check-skills Tracked security source
<div> security skill-review
<div> Apache-2.0
<code> 173483d7c6
</div> ↗
<div> codex-security-scan Tracked security source
<div> security audit
<div> Apache-2.0
<code> 173483d7c6
</div> ↗
<p> Source: repository catalog.yaml. Full commits, checksums, attribution, and local modifications are recorded there. catalog.yaml ↗
<p> 03 / VERSIONING
<h2> Updates, with a review step.
<p> We monitor upstream commits. A new commit becomes a candidate for license, content, and impact review. A Solution Skill changes only through its own versioned manifest and fresh verification evidence.
</p> Read the product model →
<div> NKSkills
<br> Versioned skill workflows for Codex and Claude Code.
<div> Catalog Solutions GitHub Release record Font licenses Tiếng Việt

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/vi/catalog/" lang="vi" aria-label="Chuyển sang tiếng Việt">
<a href="/vi/catalog/" lang="vi">
