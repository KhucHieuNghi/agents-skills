# https://nkskills.getgroove.me/
itemId: 609acd15dbbc2322c44f7c94b8edc4923f0c6cf9dbb1ac68de52591fff69241b
contentEvidence: 511ff49f67ad27e6c566302c37c386506d5dd6c75223c3c0a599db1723aa25e7
httpEvidence: bcdf3a3a7e7ae8dd7953ba7dd04a9e36beeda05343ad9ca2437a9aeec122c7c4
robotsEvidence: ca7601685eba6d4639f868dd27d7e87415c3f46d956135e2d6e00e8c85310094, 5b2494453de22a8f37427f70d9378167c1b8d6bbc682e30366e13e79b4e465cc
bytes(chars): 27123

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/en/",
 "redirects": [
  {
   "url": "https://nkskills.getgroove.me/",
   "status": 308
  }
 ],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/en/",
   "collectedAt": "2026-11-18T08:24:12.487Z",
   "retryAfter": null
  }
 ],
 "wireHash": "c3a8f052f6af9ed46223c7841e49d2753006e93be2bad7bc3678fabcc8795b6d"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:08.405Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:08.405Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:11.571Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:11.571Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="en">

## title
NKSkills | Versioned AI skill workflows for Codex and Claude Code

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Explore traceable Solution Skills for Codex and Claude Code: the codebase-onboarding technical release and the problem-presentation evaluation candidate.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/en/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/">
<meta property="og:type" content="website">
<meta property="og:title" content="NKSkills | Versioned AI skill workflows for Codex and Claude Code">
<meta property="og:description" content="Explore traceable Solution Skills for Codex and Claude Code: the codebase-onboarding technical release and the problem-presentation evaluation candidate.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-en.png">
<meta property="og:url" content="https://nkskills.getgroove.me/en/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">
<link rel="stylesheet" href="/_astro/LandingPage.BSh715S4.css">

## script elements (source text only; never executed)
- type=null src=/scripts/prompt-picker.js inlineLength=0
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 4
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 5
details: 4

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Many skills. One outcome.
h2: A skill can do a lot. A workflow should finish one.
h3: Choose the source
h3: Compose with intent
h3: Release with evidence
h2: Selected workflows.
h3: Codebase onboarding
h3: Problem presentation
h3: Content search audit
h3: Evidence before action.
h2: Every step leaves a trail.
h2: Bring a skill into your project.
h3: Choose a Solution Skill
h3: Build and verify the digest
h3: Install in your project, then invoke
h3: Choose the host you use.
h2: Start with one prompt.
h2: Curation with provenance.
h2: The right question. The right skill.
h3: security-audit
h3: security-review
h3: security-and-hardening
h3: security-best-practices
h3: codex-security-check-skills
h3: codex-security-scan
h2: Good to know before you start.
h2: Understand the system. Then change it.

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Skip to content
/en/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
#solutions | rel=null | hreflang=null | aria=null | Solutions
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/#try-it | rel=null | hreflang=null | aria=null | Try it
/vi/ | rel=null | hreflang=null | aria=Chuyển sang tiếng Việt | VI
#try-it | rel=null | hreflang=null | aria=null | Get the starter prompt ↗
#solutions | rel=null | hreflang=null | aria=null | Explore the solutions ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Read the release record ↗
/en/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | Explore the workflow ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Release record
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | View in the catalog ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/problem-presentation.yaml | rel=null | hreflang=null | aria=null | View manifest
/en/guides/codex/#content-search-audit | rel=null | hreflang=null | aria=null | Install and use ↗
/en/guides/codex/ | rel=null | hreflang=null | aria=null | Install for Codex ↗
/en/guides/claude-code/ | rel=null | hreflang=null | aria=null | Install for Claude Code ↗
/en/guides/codex/ | rel=null | hreflang=null | aria=null | Codex guide ↗
/en/guides/claude-code/ | rel=null | hreflang=null | aria=null | Claude Code guide ↗
/en/catalog/ | rel=null | hreflang=null | aria=null | Explore the full catalog ↗
/en/catalog/ | rel=null | hreflang=null | aria=Open catalog | ↗
https://github.com/cloudflare/security-audit-skill/tree/c1c8a8c1471069fb0e188eeaff69b8e8db6564a8/skills/security-audit | rel=null | hreflang=null | aria=null | View pinned source ↗
https://github.com/getsentry/skills/tree/0c464f411bdfb8d4c12314b36264d06cb2f60270/skills/security-review | rel=null | hreflang=null | aria=null | View pinned source ↗
https://github.com/addyosmani/agent-skills/tree/301b02b12bff98e4688e6984af6556802322bbde/skills/security-and-hardening | rel=null | hreflang=null | aria=null | View pinned source ↗
https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/security-best-practices | rel=null | hreflang=null | aria=null | View pinned source ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/check-skills | rel=null | hreflang=null | aria=null | View pinned source ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/security-scan | rel=null | hreflang=null | aria=null | View pinned source ↗
/en/catalog/#security-upstreams | rel=null | hreflang=null | aria=null | See catalog details ↗
#try-it | rel=null | hreflang=null | aria=null | Get the starter prompt ↗
/en/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | Explore solution ↗
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
#solutions | rel=null | hreflang=null | aria=null | Solutions
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Release record
/licenses/README.txt | rel=null | hreflang=null | aria=null | Font licenses
/vi/ | rel=null | hreflang=null | aria=null | Tiếng Việt

## visible text by block (tags removed)
Skip to content
<div> NK Skills
<nav> Solutions Catalog Try it VI
<p> NKSKILLS / VERSIONED SKILL WORKFLOWS
<h1> Many skills.
<br> One outcome.
<p> We compose version-pinned public skills with original workflows, so Codex and Claude Code can finish a complete job.
<div> Get the starter prompt ↗ Explore the solutions ↗
<div> Codex + Claude Code Traceable sources · Independent versions
<div> NK / COMPOSITION STUDIO 01 — 03
<div> CURATED COMPONENTS
<div> ✳ UPSTREAM / PINNED hallmark
<div> ↗ ORIGINAL / WORKFLOW codebase-onboarding-c4
<div> ▤ ORIGINAL / DOCUMENTS html-docs-standard
<div> →
<div> SOLUTION SKILL v1.1.0
</div> codebase
<br> onboarding
<p> Product journey · C1/C2 · File evidence
<div> Every component has a source, license, and revision. NK / VERIFIED INPUT
<div> 03 Solution Skills 01 technical release 02 evaluation candidates Read the release record ↗
<p> 01 / THE MODEL
<h2> A skill can do a lot.
<br> A workflow should finish one.
<p> NKSkills selects, composes, and verifies those capabilities around a clear outcome.
<article> 01 / SOURCE ✳
<h3> Choose the source
<p> Record each public skill's repository, commit, license, and local changes.
<article> 02 / COMPOSE ↗
<h3> Compose with intent
<p> Original workflow defines sequence, prerequisites, component roles, and output.
<article> 03 / VERIFY ✓
<h3> Release with evidence
<p> Each Solution Skill has its own version, component manifest, and verification limits.
<p> 02 / SOLUTION SKILLS
<h2> Selected workflows.
<p> Distinct workflows, one standard: trace the inputs and state what has been verified.
<div> NK / SOLUTION 001 v1.1.0
</div> TECHNICAL RELEASE
<h3> Codebase onboarding
<p> Understand an unfamiliar repository through a product journey, C1/C2 architecture, and file-level evidence before editing code.
<div> Explore the workflow ↗ Release record
<p> Build and installation checked; behavior quality across customer repositories is not broadly verified yet.
<div> CODEBASE / MAP 01 : 03
<div> PRODUCT JOURNEY From entry point
<br> to evidence.
<div> Actor → Entry → Service → Data
<div> C1 / CONTEXT System boundary
<div> C2 / CONTAINERS Responsibilities
<div> EVIDENCE / FILE PATHS / OPEN QUESTIONS
<div> NK / SOLUTION 002 v0.1.0
</div> EVALUATION CANDIDATE
<h3> Problem presentation
<p> Turn one evidenced problem into an offline HTML deck and matching PDF, with traceable sources and brand identity.
<div> View in the catalog ↗ View manifest
<p> The commercial release gate remains open.
<div> NK / PRESENTATION 01 — 03
</div> What is the
<br> real problem?
<div> 01 / PROBLEM 02 / EVIDENCE 03 / DECISION
</div> ILLUSTRATIVE OUTPUT FORMAT
<div> NK / SOLUTION 003 v0.1.32
</div> EVALUATION CANDIDATE
<h3> Content search audit
<p> One skill audits content quality, SEO, AIO, AEO and GEO. Evidence, assessed coverage and missing data stay together in the report.
<div> Install and use ↗
<p> Review conclusions before applying them. No automatic content edits or ranking guarantees.
<p> AUDIT OUTPUT
<h3> Evidence before action.
<p> HTML · Markdown · CSV
<p> One entrypoint · Five inherited methods · Two hosts
<p> 03 / FROM SOURCE TO OUTPUT
<h2> Every step leaves a trail.
<p> A new upstream revision is reviewed as a candidate; it does not silently change an existing release.
<div> 01 / SELECT
<p> Pin revisions and review licenses.
<div> 02 / COMPOSE
<p> Define sequence and output.
<div> 03 / VERIFY
<p> Record evidence and limits.
<div> NKSkills workflow codebase-onboarding 1.1.0
<div> Input Hallmark + original skills
<p> Source and revision recorded
<div> Solution Skill codebase-onboarding
<p> Version 1.1.0
<div> Host Codex or Claude Code
<p> Two supported hosts
<div> Output Cited journey and C1/C2 views
<p> Review before use
<p> Four steps: Hallmark and original skills have recorded sources and revisions; codebase-onboarding version 1.1.0 combines the components; Codex or Claude Code runs the workflow; the user reviews the cited journey and C1/C2 views before use.
<figcaption> From traceable components through a versioned Solution Skill to a codebase map that needs human review.
<p> 04 / INSTALL AND USE
<h2> Bring a skill into
<br> your project.
<p> Start with codebase-onboarding 1.1.0. Problem-presentation 0.1.0 can be tried separately but remains an evaluation candidate.
<li> 01
<h3> Choose a Solution Skill
<p> Read its release status and manifest before installing. A Solution Skill bundles its pinned components.
<li> 02
<h3> Build and verify the digest
<p> Clone NKSkills from GitHub, build from source, and use the digest printed by the build. A direct-download archive is not published yet.
<li> 03
<h3> Install in your project, then invoke
<p> Select Codex or Claude Code at install time. Open the target project in that host, invoke the skill, and review its output.
<aside> CODEX / CLAUDE CODE
<h3> Choose the host you use.
<p> Each guide includes the build and project install commands, plus the right skill invocation for that host.
<div> Install for Codex ↗ Install for Claude Code ↗
<p> 05 / TRY IT
<h2> Start with
<br> one prompt.
<p> Choose Codex or Claude Code, review the prompt, then copy. Install the skill from GitHub and prepare CodeGraph before running it.
<div> STARTER PROMPT codebase-onboarding@1.1.0
<div> Choose your host
<div> Codex Claude Code
<div> Prompt language
<div> English Tiếng Việt
</div> Selected prompt I want to understand this repository before changing it. Check whether NKSkills codebase-onboarding@1.1.0, codegraph, and rtk are available here, and whether codegraph status reports a valid index at this repository root. If anything is missing, explain the source-build and setup steps from https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md and stop before installing tools, creating an index, or editing files. If ready, use $codebase-onboarding-c4 in Quick mode. Map one primary product journey and C1/C2 architecture with file citations. Distinguish verified facts from inferences. Return findings in chat first; ask before accessing external systems or writing artifacts.
<div> Copy prompt ↗
<p> The prompt checks prerequisites first. The AI must stop before installing tools, creating an index, or editing files if setup is incomplete.
</p> I want to understand this repository before changing it. Check whether NKSkills codebase-onboarding@1.1.0, codegraph, and rtk are available here, and whether codegraph status reports a valid index at this repository root. If anything is missing, explain the source-build and setup steps from https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md and stop before installing tools, creating an index, or editing files. If ready, use $codebase-onboarding-c4 in Quick mode. Map one primary product journey and C1/C2 architecture with file citations. Distinguish verified facts from inferences. Return findings in chat first; ask before accessing external systems or writing artifacts. I want to understand this repository before changing it. Check whether NKSkills codebase-onboarding@1.1.0, codegraph, and rtk are available here, and whether codegraph status reports a valid index at this repository root. If anything is missing, explain the source-build and setup steps from https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md and stop before installing tools, creating an index, or editing files. If ready, use /codebase-onboarding-c4 in Quick mode. Map one primary product journey and C1/C2 architecture with file citations. Distinguish verified facts from inferences. Return findings in chat first; ask before accessing external systems or writing artifacts. Tôi muốn hiểu repository này trước khi sửa mã. Hãy kiểm tra NKSkills codebase-onboarding@1.1.0, codegraph và rtk đã sẵn sàng chưa, đồng thời xác nhận codegraph status báo index hợp lệ tại thư mục gốc của repository này. Nếu thiếu, hãy giải thích các bước build từ mã nguồn và thiết lập theo https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md rồi dừng trước khi cài công cụ, tạo index hoặc sửa file. Nếu đã sẵn sàng, dùng $codebase-onboarding-c4 ở chế độ Quick. Lập bản đồ một hành trình sản phẩm chính và kiến trúc C1/C2, dẫn chứng bằng đường dẫn file. Phân biệt sự thật đã kiểm tra với suy luận. Trả kết quả trong chat trước; hỏi trước khi truy cập hệ thống bên ngoài hoặc tạo artifact. Tôi muốn hiểu repository này trước khi sửa mã. Hãy kiểm tra NKSkills codebase-onboarding@1.1.0, codegraph và rtk đã sẵn sàng chưa, đồng thời xác nhận codegraph status báo index hợp lệ tại thư mục gốc của repository này. Nếu thiếu, hãy giải thích các bước build từ mã nguồn và thiết lập theo https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md rồi dừng trước khi cài công cụ, tạo index hoặc sửa file. Nếu đã sẵn sàng, dùng /codebase-onboarding-c4 ở chế độ Quick. Lập bản đồ một hành trình sản phẩm chính và kiến trúc C1/C2, dẫn chứng bằng đường dẫn file. Phân biệt sự thật đã kiểm tra với suy luận. Trả kết quả trong chat trước; hỏi trước khi truy cập hệ thống bên ngoài hoặc tạo artifact.
<div> Need to set up first? Codex guide ↗ Claude Code guide ↗
<p> 06 / THE CATALOG
<h2> Curation with
<br> provenance.
<p> Public sources, revisions, and licenses are tracked separately. A catalog entry is not itself a commercial release.
</p> Explore the full catalog ↗
<div> 01 / UPSTREAM hallmark In codebase onboarding
<div> 02 / UPSTREAM diagram-design In problem presentation candidate
<div> 03 / AUTHORING frontend-design + copywriting + design-taste-frontend Used to author this website
<div> 04 / RECOMMENDED PRACTICE Taste Skill + Impeccable Art direction → design review; not a Solution Skill
<div> + Sources, commits, licenses ↗
<p> 07 / SECURITY SOURCES
<h2> The right question.
<br> The right skill.
<p> Commit-pinned public skills cover different security tasks. These are tracked sources, not a released Solution Skill.
<div> 01 / AUDIT TRACKED UPSTREAM
<p> Cloudflare
<h3> security-audit
<p> A coverage-led codebase audit with independent finding verification. Full runs require isolated agents and a controlled sandbox.
</p> View pinned source ↗
<div> 02 / REVIEW TRACKED UPSTREAM
<p> Sentry
<h3> security-review
<p> Focused code review for high-confidence, exploitable findings. OWASP-derived references need a license review before bundling.
</p> View pinned source ↗
<div> 03 / HARDEN TRACKED UPSTREAM
<p> Addy Osmani
<h3> security-and-hardening
<p> Threat modeling and secure web implementation patterns. An external checklist still needs to be included for a standalone package.
</p> View pinned source ↗
<div> 04 / GUIDANCE TRACKED UPSTREAM
<p> OpenAI
<h3> security-best-practices
<p> Language and framework security guidance for Python, JavaScript/TypeScript, and Go. Host packaging still needs trials.
</p> View pinned source ↗
<div> 05 / SKILL REVIEW TRACKED UPSTREAM
<p> OpenAI
<h3> codex-security-check-skills
<p> Read-only review of skills before installation. Host compatibility and packaging require trials.
</p> View pinned source ↗
<div> 06 / SCAN TRACKED UPSTREAM
<p> OpenAI
<h3> codex-security-scan
<p> Repository vulnerability scan workflow requiring Codex Security plugin tools and external references. Tracked for evaluation.
</p> View pinned source ↗
<p> Scope, licenses, and runtime prerequisites are recorded per source. NKSkills has no installable security Solution Skill yet. See catalog details ↗
<p> 08 / FAQ
<h2> Good to know
<br> before you start.
<summary> Which hosts are supported?
<p> Codex and Claude Code. Each host has its own installation guide.
<summary> Do upstream updates change a Solution Skill automatically?
<p> No. We track sources, review new versions, then decide whether to issue a new Solution Skill release.
<summary> Is problem presentation commercially ready?
<p> No. Version 0.1.0 is an evaluation candidate, and the commercial release gate remains open.
<summary> Will the prompt change my code?
<p> The prompt asks for findings in chat first and approval before external access or artifact writes. If prerequisites are missing, the AI must stop before installing tools, indexing, or editing files.
<p> NKSKILLS / CODEBASE ONBOARDING
<h2> Understand the system.
<br> Then change it.
<p> Begin with a source-backed workflow for Codex or Claude Code.
<div> Get the starter prompt ↗ Explore solution ↗
<div> NKSkills
<br> Versioned skill workflows for Codex and Claude Code.
<div> Catalog Solutions GitHub Release record Font licenses Tiếng Việt

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/vi/" lang="vi" aria-label="Chuyển sang tiếng Việt">
<div class="hero-orb hero-orb-one" aria-hidden="true">
<div class="hero-orb hero-orb-two" aria-hidden="true">
<span class="hero-kicker-dot" aria-hidden="true">
<span aria-hidden="true">
<span class="caption-plus" aria-hidden="true">
<span class="caption-rule" aria-hidden="true">
<span class="chip-symbol" aria-hidden="true">
<span class="chip-symbol chip-symbol-blue" aria-hidden="true">
<span class="chip-symbol chip-symbol-green" aria-hidden="true">
<div class="board-arrow" aria-hidden="true">
<span class="model-glyph" aria-hidden="true">
<div class="work-visual architecture-visual" aria-hidden="true">
<div class="work-visual presentation-visual" aria-hidden="true">
<div class="prompt-picker" data-prompt-picker data-page-locale="en">
<div class="tab-list" role="group" aria-label="AI host" data-choice-group="host" data-active-index="0">
<button type="button" data-choice data-host="codex" aria-pressed="true">
<button type="button" data-choice data-host="claude-code" aria-pressed="false">
<div class="tab-list" role="group" aria-label="Prompt language" data-choice-group="locale" data-active-index="0">
<button type="button" data-choice data-locale="en" aria-pressed="true">
<button type="button" data-choice data-locale="vi" aria-pressed="false">
<button class="button copy-button" type="button" data-copy>Copy prompt<span aria-hidden="true">
<p class="copy-status" role="status" aria-live="polite" data-copy-status></p>
<template data-prompt-locale="en" data-prompt-host="codex">
<template data-prompt-locale="en" data-prompt-host="claude-code">
<template data-prompt-locale="vi" data-prompt-host="codex">
<template data-prompt-locale="vi" data-prompt-host="claude-code">
<a href="/vi/" lang="vi">
