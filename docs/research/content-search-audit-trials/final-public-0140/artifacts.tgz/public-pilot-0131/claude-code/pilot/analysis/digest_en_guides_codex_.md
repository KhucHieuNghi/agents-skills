# https://nkskills.getgroove.me/en/guides/codex/
itemId: 676e5eefb741ddfbf61cd980304e62293ae94c5478e8442cc5225bc0b039781a
contentEvidence: f0e309e97f716b9d6541d35dc466d2feec172cf3287e060cd7eec1503b9cf945
httpEvidence: f404ba4093be9aa4d47f49defa3c8e517812654d90301fac76de579ecfbd64b4
robotsEvidence: 9b637c83626d8b009b8489562c1bd35f2e2e5b907019a256bbc7f4c1c4937efe
bytes(chars): 9829

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/en/guides/codex/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/en/guides/codex/",
   "collectedAt": "2026-11-18T08:24:16.565Z",
   "retryAfter": null
  }
 ],
 "wireHash": "7af35e9e53a6c53290c5830eb76fa56ae5b9ccf2570c2027f6c22e2c5418515e"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:16.257Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:16.257Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="en">

## title
Install and use NKSkills in Codex | NKSkills guide

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Build and install NKSkills Solution Skills from GitHub source, then invoke codebase onboarding or the presentation evaluation candidate in Codex.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/en/guides/codex/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/guides/codex/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/guides/codex/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/guides/codex/">
<meta property="og:type" content="website">
<meta property="og:title" content="Install and use NKSkills in Codex | NKSkills guide">
<meta property="og:description" content="Build and install NKSkills Solution Skills from GitHub source, then invoke codebase onboarding or the presentation evaluation candidate in Codex.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-en.png">
<meta property="og:url" content="https://nkskills.getgroove.me/en/guides/codex/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Install and use NKSkills in Codex.
h2: Check prerequisites before running
h2: Build the installable package from source
h2: Add the skill to your target repository
h2: Verify and start Quick mode
h2: Try Problem presentation in a test project
h2: Audit content with one skill
h2: Review the result before relying on it

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Skip to content
/en/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/#try-it | rel=null | hreflang=null | aria=null | Try it
/vi/guides/codex/ | rel=null | hreflang=null | aria=Chuyển sang tiếng Việt | VI
/en/ | rel=null | hreflang=null | aria=null | NKSkills
/en/#install | rel=null | hreflang=null | aria=null | Install skills
/en/#try-it | rel=null | hreflang=null | aria=null | Get the starter prompt
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md | rel=null | hreflang=null | aria=null | Read archive and digest verification →
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/research/problem-presentation-solution-evaluation.md | rel=null | hreflang=null | aria=null | Read the current evaluation →
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/content-search-audit-0.1.32.md | rel=null | hreflang=null | aria=null | Read the release record and limits
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Read the 1.1.0 release limits →
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Release record
/licenses/README.txt | rel=null | hreflang=null | aria=null | Font licenses
/vi/guides/codex/ | rel=null | hreflang=null | aria=null | Tiếng Việt

## visible text by block (tags removed)
Skip to content
<div> NK Skills
<nav> Solutions Catalog Try it VI
<nav> NKSkills / Install skills / Codex
<p> USE GUIDE Codex
<h1> Install and use NKSkills in Codex.
<p> Start from public source, verify prerequisites, and invoke the skill only after it is installed in the project.
</p> Get the starter prompt
<aside> Distribution status
<p> There is no published direct-download archive. The steps below build and install from GitHub; the technical guide also covers archive verification and transfer.
<p> 01 / PREPARE
<h2> Check prerequisites before running
<p> The CodeGraph requirements below apply to codebase onboarding. The Problem presentation trial at the end of this guide has separate evaluation criteria.
<li> Node.js 22+, npm, Git
<li> codegraph, rtk
<li> Valid CodeGraph index at the target repository root (`codegraph status`)
<li> Permission to install the Solution Skill into the target project
<p> 02 / BUILD FROM GITHUB
<h2> Build the installable package from source
<p> Run these commands on your machine after cloning NKSkills. The last command prints the release digest; keep it for the project install step.
<code> git clone https://github.com/KhucHieuNghi/agents-skills.git
cd agents-skills
npm ci
npm run build
node dist/cli.js build-solution codebase-onboarding --output build/codebase-onboarding-1.1.0
</pre> Read archive and digest verification →
<p> 03 / INSTALL IN YOUR PROJECT
<h2> Add the skill to your target repository
<p> Replace the two sample values below with the printed digest and your project's absolute path. The CLI verifies the digest before writing skills to the project.
<code> release_digest="PASTE_DIGEST_FROM_BUILD_OUTPUT"
target_project="/absolute/path/to/your/project"
node dist/cli.js install-solution \
--release build/codebase-onboarding-1.1.0 \
--digest "$release_digest" \
--project "$target_project" \
--target codex
<p> Check .agent-skills/installed.json and the skills installed directly in
<code> .agents/skills/
</code> in the project.
<p> 04 / RUN THE SKILL
<h2> Verify and start Quick mode
<p> After installation, open the target repository and run `codegraph --version`, `rtk --version`, and `codegraph status`. Once the index is valid, open Codex, at that project and invoke the skill with the token shown here or use the starter prompt.
<div> Codex
<code> $codebase-onboarding-c4
<p> Ask for Quick mode to map a cited product journey and C1/C2 views.
<p> 05 / EVALUATION CANDIDATE
<h2> Try Problem presentation in a test project
<p> Version 0.1.0 has not passed the commercial release gate. Build it separately from the same source, use its new digest, and install it in a test project; do not reuse the onboarding digest.
<div> Codex
<code> $problem-presentation
<p> Describe one problem and its evidence. The skill asks for a company name and URL; without them, generated branding is marked provisional.
<code> node dist/cli.js build-solution problem-presentation --output build/problem-presentation-0.1.0
candidate_digest="PASTE_DIGEST_FROM_CANDIDATE_BUILD"
test_project="/absolute/path/to/a/test-project"
node dist/cli.js install-solution \
--release build/problem-presentation-0.1.0 \
--digest "$candidate_digest" \
--project "$test_project" \
--target codex
<p> Review the offline HTML, PDF, and provenance file before sharing. Read the current evaluation →
<p> 06 / CONTENT SEARCH AUDIT · 0.1.32
<h2> Audit content with one skill
<p> After cloning and building the CLI above, build this package separately and install it with the printed digest. Invoke one skill; no separate upstream skill installation is needed. Helpers require Node.js 22+; browser, PDF and measurement capabilities depend on authorized sources.
<code> node dist/cli.js build-solution content-search-audit --output build/content-search-audit-0.1.32
node dist/cli.js install-solution --release build/content-search-audit-0.1.32 --digest PASTE_DIGEST_FROM_BUILD_OUTPUT --project /absolute/path/to/project --target codex
<div> Codex
<code> $content-search-audit
<p> Provide the content folder or website, audience and purpose. Reports include HTML, Markdown, CSV, evidence and unresolved items.
<p> Evaluation candidate: audits can remain partial; no ranking or overall accuracy guarantee. Read the release record and limits
<h2> Review the result before relying on it
<p> Check file pointers, inference labels, and diagrams. The starter prompt asks the AI to seek approval before accessing external systems or writing artifacts.
</p> Read the 1.1.0 release limits →
<div> NKSkills
<br> Versioned skill workflows for Codex and Claude Code.
<div> Catalog Solutions GitHub Release record Font licenses Tiếng Việt

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/vi/guides/codex/" lang="vi" aria-label="Chuyển sang tiếng Việt">
<span aria-hidden="true">
<a href="/vi/guides/codex/" lang="vi">
