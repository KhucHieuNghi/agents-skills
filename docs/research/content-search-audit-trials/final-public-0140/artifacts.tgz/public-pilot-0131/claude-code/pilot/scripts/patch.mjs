// Applies exact-string replacements to one of this pilot's own scripts.
// Usage: node patch.mjs TARGET_FILE PATCHES.json   (PATCHES = [[from, to], ...])
import { readFile, writeFile } from "node:fs/promises";
const [target, patchFile] = process.argv.slice(2);
if (!target.includes("/pilot/scripts/")) throw new Error("Only pilot scripts may be patched");
let text = await readFile(target, "utf8");
for (const [from, to] of JSON.parse(await readFile(patchFile, "utf8"))) {
  const count = text.split(from).length - 1;
  if (count !== 1) throw new Error(`Expected exactly one match, found ${count}: ${from.slice(0, 60)}`);
  text = text.replace(from, () => to);
}
await writeFile(target, text);
console.log("patched", target);
