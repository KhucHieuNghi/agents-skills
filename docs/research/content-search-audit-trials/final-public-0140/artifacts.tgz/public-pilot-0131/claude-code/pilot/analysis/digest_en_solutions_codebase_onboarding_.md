# https://nkskills.getgroove.me/en/solutions/codebase-onboarding/
itemId: 6753671d30da27fb8c66d3cf6eed4c8bd0ec351e029b5d4811f444a7ba782bb3
contentEvidence: be4e698fc093f3f0e37d843faabc6cd42ddb3203d3fb059d66214be5fa93f5bb
httpEvidence: 89c959ef84886418edc6a4ee012ee675a8349d5488a40c196fd024f539ea9e40
robotsEvidence: 2a8917b95a1f5e00a3165a70411f7bcf634cfb12c1fe35145cd68ec09962616a
bytes(chars): 6693

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/en/solutions/codebase-onboarding/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/en/solutions/codebase-onboarding/",
   "collectedAt": "2026-11-18T08:24:14.207Z",
   "retryAfter": null
  }
 ],
 "wireHash": "79c43cd4573c5fdbb2799971edb489d380e75468cd47db9f702efdc810d587de"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:12.972Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:12.972Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="en">

## title
Codebase onboarding | NKSkills Solution Skill 1.1.0

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Explore the released codebase-onboarding workflow, its locked components, prerequisites, evidence gates, and current verification limits.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/solutions/codebase-onboarding/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<meta property="og:type" content="website">
<meta property="og:title" content="Codebase onboarding | NKSkills Solution Skill 1.1.0">
<meta property="og:description" content="Explore the released codebase-onboarding workflow, its locked components, prerequisites, evidence gates, and current verification limits.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-en.png">
<meta property="og:url" content="https://nkskills.getgroove.me/en/solutions/codebase-onboarding/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Understand an unfamiliar codebase with evidence.
h2: Components locked. Behavior evaluation continues.
h2: One workflow, three traceable components
h3: codebase-onboarding-c4
h3: html-docs-standard
h3: Hallmark
h2: From product flow to technical map
h2: Prerequisites and current limits

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Skip to content
/en/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/#try-it | rel=null | hreflang=null | aria=null | Try it
/vi/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=Chuyển sang tiếng Việt | VI
/en/ | rel=null | hreflang=null | aria=null | NKSkills
/en/guides/codex/ | rel=null | hreflang=null | aria=null | Use with Codex
/en/guides/claude-code/ | rel=null | hreflang=null | aria=null | Use with Claude Code
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Read the release record →
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/codebase-onboarding.yaml | rel=null | hreflang=null | aria=null | solutions/codebase-onboarding.yaml
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md | rel=null | hreflang=null | aria=null | Read the full technical setup →
/en/catalog/ | rel=null | hreflang=null | aria=null | Catalog
/en/catalog/#solutions | rel=null | hreflang=null | aria=null | Solutions
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Release record
/licenses/README.txt | rel=null | hreflang=null | aria=null | Font licenses
/vi/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | Tiếng Việt

## visible text by block (tags removed)
Skip to content
<div> NK Skills
<nav> Solutions Catalog Try it VI
<nav> NKSkills / Codebase onboarding
<p> SOLUTION SKILL v1.1.0
<h1> Understand an unfamiliar codebase with evidence.
<p> A source-backed path from product journey to C1/C2 architecture, before the team starts changing code.
<div> Use with Codex Use with Claude Code
<aside> Technical release 1.1.0
<h2> Components locked. Behavior evaluation continues.
<p> Build and installation are verified with digests. Model behavior has not been verified across every customer repository.
</p> Read the release record →
<p> COMPOSITION
<h2> One workflow, three traceable components
<article> 01
<h3> codebase-onboarding-c4
<p> Original workflow for product journey and source-backed architecture mapping.
</p> NKSkills original
<article> 02
<h3> html-docs-standard
<p> Structured, readable HTML handoff with local verification.
</p> NKSkills original
<article> 03
<h3> Hallmark
<p> Public upstream for presentation polish, pinned to an immutable revision.
</p> Pinned public upstream
<p> Inspect the manifest and upstream revision: solutions/codebase-onboarding.yaml
<p> OUTPUT
<h2> From product flow to technical map
<p> Quick mode requires a primary business journey plus C1 and C2 views. Factual claims need file pointers; assumptions are labelled.
<li> Product journey with entry and outcome
<li> C1 context and C2 container diagrams
<li> File citations and labelled inferences
<li> Verified Markdown/HTML handoff
<h2> Prerequisites and current limits
<p> You need the Solution Skill, codegraph, rtk, and a valid CodeGraph index at the repository root. No direct archive download is published; the current setup begins from GitHub source.
<p> Version 1.1.0 is a technical release. Results on each repository still need human review.
</p> Read the full technical setup →
<div> NKSkills
<br> Versioned skill workflows for Codex and Claude Code.
<div> Catalog Solutions GitHub Release record Font licenses Tiếng Việt

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/vi/solutions/codebase-onboarding/" lang="vi" aria-label="Chuyển sang tiếng Việt">
<span aria-hidden="true">
<a href="/vi/solutions/codebase-onboarding/" lang="vi">
