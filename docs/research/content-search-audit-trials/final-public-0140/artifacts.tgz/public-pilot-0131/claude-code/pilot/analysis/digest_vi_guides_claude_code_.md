# https://nkskills.getgroove.me/vi/guides/claude-code/
itemId: fb897aa3b0173b966c5d9b68506952e6bf9148f697be7d6125d9e803e3f86055
contentEvidence: 237226a17226a1eaff1476dde9faa2d5562aad8236bdbeff12910270d2b7bfb1
httpEvidence: 1f030f911e905c137b574e2d0f55831a9ac69d8b4a66e77854a1036acd860df5
robotsEvidence: ef77fdc3e49cc6baf297a0537449c29a25723a105b0367b03adfbad796949b15
bytes(chars): 9927

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/vi/guides/claude-code/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/vi/guides/claude-code/",
   "collectedAt": "2026-11-18T08:24:38.806Z",
   "retryAfter": null
  }
 ],
 "wireHash": "5b0bf6d2c0f367ddad9344a38dd13e90c8b402b241471f16a1059e68aac4040e"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:36.825Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:36.825Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="vi">

## title
Cài và dùng NKSkills trong Claude Code | Hướng dẫn NKSkills

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Build và cài NKSkills từ mã nguồn GitHub, rồi gọi codebase onboarding hoặc ứng viên problem presentation trong Claude Code.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-vietnamese-full-normal.7BpKI3vF.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-vietnamese-wght-normal.BDs68eHQ.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/vi/guides/claude-code/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/guides/claude-code/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/guides/claude-code/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/guides/claude-code/">
<meta property="og:type" content="website">
<meta property="og:title" content="Cài và dùng NKSkills trong Claude Code | Hướng dẫn NKSkills">
<meta property="og:description" content="Build và cài NKSkills từ mã nguồn GitHub, rồi gọi codebase onboarding hoặc ứng viên problem presentation trong Claude Code.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-vi.png">
<meta property="og:url" content="https://nkskills.getgroove.me/vi/guides/claude-code/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Cài và dùng NKSkills trong Claude Code.
h2: Kiểm tra điều kiện trước khi chạy
h2: Tạo gói cài từ source
h2: Tích hợp skill vào repository đích
h2: Xác minh và bắt đầu Quick mode
h2: Thử Problem presentation trong project thử nghiệm
h2: Audit nội dung bằng một skill
h2: Đọc kết quả trước khi dùng

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Đến nội dung chính
/vi/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/#try-it | rel=null | hreflang=null | aria=null | Dùng thử
/en/guides/claude-code/ | rel=null | hreflang=null | aria=Switch to English | EN
/vi/ | rel=null | hreflang=null | aria=null | NKSkills
/vi/#install | rel=null | hreflang=null | aria=null | Tích hợp skills
/vi/#try-it | rel=null | hreflang=null | aria=null | Đến prompt mẫu
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md | rel=null | hreflang=null | aria=null | Xem quy trình kiểm tra archive và digest →
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/research/problem-presentation-solution-evaluation.md | rel=null | hreflang=null | aria=null | Xem đánh giá hiện tại →
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/content-search-audit-0.1.32.md | rel=null | hreflang=null | aria=null | Đọc biên bản và giới hạn
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Xem giới hạn phát hành 1.1.0 →
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Bản phát hành
/licenses/README.txt | rel=null | hreflang=null | aria=null | Giấy phép font
/en/guides/claude-code/ | rel=null | hreflang=null | aria=null | English

## visible text by block (tags removed)
Đến nội dung chính
<div> NK Skills
<nav> Giải pháp Danh mục Dùng thử EN
<nav> NKSkills / Tích hợp skills / Claude Code
<p> HƯỚNG DẪN SỬ DỤNG Claude Code
<h1> Cài và dùng NKSkills trong Claude Code.
<p> Bắt đầu từ mã nguồn công khai, xác minh điều kiện chạy và chỉ dùng skill sau khi đã cài vào project.
</p> Đến prompt mẫu
<aside> Trạng thái phân phối
<p> Chưa có archive phát hành tải trực tiếp. Các bước dưới đây build và cài từ GitHub; hướng dẫn kỹ thuật giải thích thêm cách kiểm tra và chuyển giao archive.
<p> 01 / CHUẨN BỊ
<h2> Kiểm tra điều kiện trước khi chạy
<p> Các điều kiện CodeGraph dưới đây dành cho codebase onboarding. Phần thử Problem presentation ở cuối trang có điều kiện đánh giá riêng.
<li> Node.js 22+, npm, Git
<li> codegraph, rtk
<li> CodeGraph index hợp lệ tại root repository đích (`codegraph status`)
<li> Quyền cài Solution Skill vào project đích
<p> 02 / BUILD TỪ GITHUB
<h2> Tạo gói cài từ source
<p> Chạy tại máy của bạn sau khi clone NKSkills. Lệnh cuối in ra digest của gói; giữ giá trị đó cho bước cài vào project.
<code> git clone https://github.com/KhucHieuNghi/agents-skills.git
cd agents-skills
npm ci
npm run build
node dist/cli.js build-solution codebase-onboarding --output build/codebase-onboarding-1.1.0
</pre> Xem quy trình kiểm tra archive và digest →
<p> 03 / CÀI VÀO PROJECT
<h2> Tích hợp skill vào repository đích
<p> Thay hai giá trị mẫu bên dưới bằng digest vừa in ra và đường dẫn tuyệt đối của project. CLI kiểm tra digest trước khi ghi skill vào project.
<code> release_digest="PASTE_DIGEST_FROM_BUILD_OUTPUT"
target_project="/absolute/path/to/your/project"
node dist/cli.js install-solution \
--release build/codebase-onboarding-1.1.0 \
--digest "$release_digest" \
--project "$target_project" \
--target claude-code
<p> Kiểm tra .agent-skills/installed.json và thư mục skill được cài trực tiếp tại
<code> .claude/skills/
</code> trong project.
<p> 04 / CHẠY SKILL
<h2> Xác minh và bắt đầu Quick mode
<p> Sau khi cài, mở repository đích và chạy `codegraph --version`, `rtk --version`, `codegraph status`. Khi index hợp lệ, mở Claude Code, tại project đó, rồi gọi skill bằng token bên phải hoặc dùng prompt mẫu.
<div> Claude Code
<code> /codebase-onboarding-c4
<p> Yêu cầu chế độ Quick để tạo hành trình sản phẩm và C1/C2 có dẫn chứng.
<p> 05 / ỨNG VIÊN ĐÁNH GIÁ
<h2> Thử Problem presentation trong project thử nghiệm
<p> Bản 0.1.0 chưa qua cổng phát hành thương mại. Build riêng từ cùng source, lấy digest mới và cài vào project thử nghiệm; đừng dùng digest của codebase onboarding.
<div> Claude Code
<code> /problem-presentation
<p> Nêu một vấn đề cụ thể và nguồn bằng chứng. Skill sẽ hỏi tên công ty và URL; nếu không có, nhận diện tạo ra sẽ được đánh dấu tạm thời.
<code> node dist/cli.js build-solution problem-presentation --output build/problem-presentation-0.1.0
candidate_digest="PASTE_DIGEST_FROM_CANDIDATE_BUILD"
test_project="/absolute/path/to/a/test-project"
node dist/cli.js install-solution \
--release build/problem-presentation-0.1.0 \
--digest "$candidate_digest" \
--project "$test_project" \
--target claude-code
<p> Kiểm tra HTML ngoại tuyến, PDF và file provenance trước khi chia sẻ. Xem đánh giá hiện tại →
<p> 06 / CONTENT SEARCH AUDIT · 0.1.32
<h2> Audit nội dung bằng một skill
<p> Sau bước clone và build CLI ở trên, build riêng gói này rồi cài bằng digest được in ra. Chỉ cần gọi một skill; không cài thêm các skill upstream. Node.js 22+ là điều kiện của helper; browser, PDF và dữ liệu đo lường phụ thuộc nguồn được cấp quyền.
<code> node dist/cli.js build-solution content-search-audit --output build/content-search-audit-0.1.32
node dist/cli.js install-solution --release build/content-search-audit-0.1.32 --digest PASTE_DIGEST_FROM_BUILD_OUTPUT --project /absolute/path/to/project --target claude-code
<div> Claude Code
<code> /content-search-audit
<p> Nêu thư mục hoặc website cần audit, đối tượng đọc và mục tiêu. Báo cáo gồm HTML, Markdown, CSV, dẫn chứng và các mục còn thiếu dữ liệu.
<p> Ứng viên đánh giá: audit có thể chỉ hoàn thành một phần; chưa có cam kết ranking hoặc độ chính xác tổng thể. Đọc biên bản và giới hạn
<h2> Đọc kết quả trước khi dùng
<p> Kiểm tra đường dẫn file, các nhãn suy luận và sơ đồ. Prompt mẫu yêu cầu AI hỏi trước khi truy cập hệ thống bên ngoài hoặc ghi artifact.
</p> Xem giới hạn phát hành 1.1.0 →
<div> NKSkills
<br> Skill workflow có phiên bản cho Codex và Claude Code.
<div> Danh mục Giải pháp GitHub Bản phát hành Giấy phép font English

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/en/guides/claude-code/" lang="en" aria-label="Switch to English">
<span aria-hidden="true">
<a href="/en/guides/claude-code/" lang="en">
