# https://nkskills.getgroove.me/vi/
itemId: 8cf4578028c7856c4c6d4ba30a18df5b25646277176b0bf660819286face8743
contentEvidence: d2b299961e0f39d435474edb95697866de684b3a3b532057a4e66aabb4e52401
httpEvidence: 76588148e56440822552b6244e061895b63e6ab93e76e19bfbb563e33a0aea0c
robotsEvidence: f3f46815d6735f5063becf3287da44b582d4280c8491446d548887cb3b96ecf0
bytes(chars): 27528

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/vi/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/vi/",
   "collectedAt": "2026-11-18T08:24:22.776Z",
   "retryAfter": null
  }
 ],
 "wireHash": "c95cec23f9bd759db799c2473f828e091ade8d704e48a1a2bad9c50b6b4ef7c8"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:20.410Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:20.410Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="vi">

## title
NKSkills | AI skill workflow có phiên bản cho Codex và Claude Code

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Khám phá Solution Skills có thể truy vết nguồn cho Codex và Claude Code: codebase-onboarding bản kỹ thuật và problem-presentation đang đánh giá.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-vietnamese-full-normal.7BpKI3vF.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-vietnamese-wght-normal.BDs68eHQ.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/vi/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/">
<meta property="og:type" content="website">
<meta property="og:title" content="NKSkills | AI skill workflow có phiên bản cho Codex và Claude Code">
<meta property="og:description" content="Khám phá Solution Skills có thể truy vết nguồn cho Codex và Claude Code: codebase-onboarding bản kỹ thuật và problem-presentation đang đánh giá.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-vi.png">
<meta property="og:url" content="https://nkskills.getgroove.me/vi/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">
<link rel="stylesheet" href="/_astro/LandingPage.BSh715S4.css">

## script elements (source text only; never executed)
- type=null src=/scripts/prompt-picker.js inlineLength=0
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 4
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 5
details: 4

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Nhiều skills. Một kết quả.
h2: Một skill có thể làm nhiều việc. Một workflow phải hoàn thành một việc.
h3: Chọn đúng nguồn
h3: Kết hợp có chủ đích
h3: Phát hành có bằng chứng
h2: Workflows được chọn.
h3: Codebase onboarding
h3: Problem presentation
h3: Content search audit
h3: Dẫn chứng trước, hành động sau.
h2: Mỗi bước đều để lại dấu vết.
h2: Đưa skill vào project của bạn.
h3: Chọn Solution Skill
h3: Build và kiểm tra digest
h3: Cài vào project rồi gọi skill
h3: Chọn môi trường bạn đang dùng.
h2: Bắt đầu bằng một prompt.
h2: Tuyển chọn có nguồn gốc.
h2: Đúng câu hỏi. Đúng công cụ.
h3: security-audit
h3: security-review
h3: security-and-hardening
h3: security-best-practices
h3: codex-security-check-skills
h3: codex-security-scan
h2: Cần biết trước khi bắt đầu.
h2: Hiểu rõ hệ thống. Rồi hãy thay đổi nó.

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Đến nội dung chính
/vi/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
#solutions | rel=null | hreflang=null | aria=null | Giải pháp
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/#try-it | rel=null | hreflang=null | aria=null | Dùng thử
/en/ | rel=null | hreflang=null | aria=Switch to English | EN
#try-it | rel=null | hreflang=null | aria=null | Lấy prompt dùng thử ↗
#solutions | rel=null | hreflang=null | aria=null | Khám phá giải pháp ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Xem bằng chứng phát hành ↗
/vi/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | Khám phá workflow ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Biên bản phát hành
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Xem trong danh mục ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/problem-presentation.yaml | rel=null | hreflang=null | aria=null | Xem manifest
/vi/guides/codex/#content-search-audit | rel=null | hreflang=null | aria=null | Cài đặt và sử dụng ↗
/vi/guides/codex/ | rel=null | hreflang=null | aria=null | Cài cho Codex ↗
/vi/guides/claude-code/ | rel=null | hreflang=null | aria=null | Cài cho Claude Code ↗
/vi/guides/codex/ | rel=null | hreflang=null | aria=null | Hướng dẫn Codex ↗
/vi/guides/claude-code/ | rel=null | hreflang=null | aria=null | Hướng dẫn Claude Code ↗
/vi/catalog/ | rel=null | hreflang=null | aria=null | Mở toàn bộ danh mục ↗
/vi/catalog/ | rel=null | hreflang=null | aria=Mở danh mục | ↗
https://github.com/cloudflare/security-audit-skill/tree/c1c8a8c1471069fb0e188eeaff69b8e8db6564a8/skills/security-audit | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
https://github.com/getsentry/skills/tree/0c464f411bdfb8d4c12314b36264d06cb2f60270/skills/security-review | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
https://github.com/addyosmani/agent-skills/tree/301b02b12bff98e4688e6984af6556802322bbde/skills/security-and-hardening | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/security-best-practices | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/check-skills | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/security-scan | rel=null | hreflang=null | aria=null | Xem nguồn đã khóa phiên bản ↗
/vi/catalog/#security-upstreams | rel=null | hreflang=null | aria=null | Xem trong danh mục ↗
#try-it | rel=null | hreflang=null | aria=null | Lấy prompt dùng thử ↗
/vi/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=null | Xem giải pháp ↗
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
#solutions | rel=null | hreflang=null | aria=null | Giải pháp
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Bản phát hành
/licenses/README.txt | rel=null | hreflang=null | aria=null | Giấy phép font
/en/ | rel=null | hreflang=null | aria=null | English

## visible text by block (tags removed)
Đến nội dung chính
<div> NK Skills
<nav> Giải pháp Danh mục Dùng thử EN
<p> NKSKILLS / WORKFLOW CÓ PHIÊN BẢN
<h1> Nhiều skills.
<br> Một kết quả.
<p> Chúng tôi kết hợp skill công khai đã khóa phiên bản với workflow gốc, để Codex và Claude Code giải quyết trọn vẹn một công việc.
<div> Lấy prompt dùng thử ↗ Khám phá giải pháp ↗
<div> Codex + Claude Code Nguồn gốc rõ ràng · Phiên bản riêng
<div> NK / COMPOSITION STUDIO 01 — 03
<div> THÀNH PHẦN ĐƯỢC CHỌN
<div> ✳ UPSTREAM / PINNED hallmark
<div> ↗ ORIGINAL / WORKFLOW codebase-onboarding-c4
<div> ▤ ORIGINAL / DOCUMENTS html-docs-standard
<div> →
<div> SOLUTION SKILL v1.1.0
</div> codebase
<br> onboarding
<p> Hành trình sản phẩm · C1/C2 · Dẫn chứng theo file
<div> Mỗi thành phần có nguồn, giấy phép và revision. NK / VERIFIED INPUT
<div> 03 Solution Skills 01 bản kỹ thuật 02 ứng viên đánh giá Xem bằng chứng phát hành ↗
<p> 01 / CÁCH CHÚNG TÔI LÀM
<h2> Một skill có thể làm nhiều việc.
<br> Một workflow phải hoàn thành một việc.
<p> Giá trị của NKSkills nằm ở cách chọn, kết hợp và kiểm tra những năng lực đó cho một kết quả rõ ràng.
<article> 01 / SOURCE ✳
<h3> Chọn đúng nguồn
<p> Theo dõi repository, commit, giấy phép và thay đổi cục bộ của public skill.
<article> 02 / COMPOSE ↗
<h3> Kết hợp có chủ đích
<p> Workflow gốc xác định thứ tự, điều kiện chạy, vai trò từng skill và đầu ra.
<article> 03 / VERIFY ✓
<h3> Phát hành có bằng chứng
<p> Solution Skill có phiên bản, manifest thành phần và giới hạn xác minh riêng.
<p> 02 / SOLUTION SKILLS
<h2> Workflows được chọn.
<p> Các workflow có chung một nguyên tắc: biết rõ nguồn vào và thành thật về mức độ đã kiểm tra.
<div> NK / SOLUTION 001 v1.1.0
</div> BẢN PHÁT HÀNH KỸ THUẬT
<h3> Codebase onboarding
<p> Hiểu một repository lạ qua hành trình sản phẩm, kiến trúc C1/C2 và dẫn chứng theo file trước khi sửa mã.
<div> Khám phá workflow ↗ Biên bản phát hành
<p> Đã kiểm tra build và cài đặt; chất lượng hành vi trên nhiều codebase khách hàng chưa được xác minh rộng rãi.
<div> CODEBASE / MAP 01 : 03
<div> PRODUCT JOURNEY From entry point
<br> to evidence.
<div> Actor → Entry → Service → Data
<div> C1 / CONTEXT System boundary
<div> C2 / CONTAINERS Responsibilities
<div> EVIDENCE / FILE PATHS / OPEN QUESTIONS
<div> NK / SOLUTION 002 v0.1.0
</div> ỨNG VIÊN ĐÁNH GIÁ
<h3> Problem presentation
<p> Biến một vấn đề có dẫn chứng thành deck HTML chạy ngoại tuyến và bản PDF tương ứng, với nguồn và nhận diện thương hiệu có thể kiểm tra.
<div> Xem trong danh mục ↗ Xem manifest
<p> Chưa qua cổng phát hành thương mại.
<div> NK / PRESENTATION 01 — 03
</div> What is the
<br> real problem?
<div> 01 / PROBLEM 02 / EVIDENCE 03 / DECISION
</div> MINH HỌA ĐỊNH DẠNG ĐẦU RA
<div> NK / SOLUTION 003 v0.1.32
</div> ỨNG VIÊN ĐÁNH GIÁ
<h3> Content search audit
<p> Một skill kiểm tra chất lượng nội dung, SEO, AIO, AEO và GEO. Giữ dẫn chứng, phạm vi đã kiểm tra và các phần chưa đủ dữ liệu trong cùng báo cáo.
<div> Cài đặt và sử dụng ↗
<p> Review kết luận trước khi áp dụng. Không tự sửa nội dung hoặc bảo đảm ranking.
<p> ĐẦU RA AUDIT
<h3> Dẫn chứng trước, hành động sau.
<p> HTML · Markdown · CSV
<p> Một entrypoint · Năm phương pháp kế thừa · Hai host
<p> 03 / TỪ NGUỒN ĐẾN KẾT QUẢ
<h2> Mỗi bước đều để lại dấu vết.
<p> Upstream mới là ứng viên để xem xét, không tự động thay đổi Solution Skill đã phát hành.
<div> 01 / CHỌN
<p> Pin revision và kiểm tra giấy phép.
<div> 02 / GHÉP
<p> Định nghĩa trình tự và đầu ra.
<div> 03 / KIỂM TRA
<p> Ghi lại bằng chứng và giới hạn.
<div> NKSkills workflow codebase-onboarding 1.1.0
<div> Nguồn đầu vào Hallmark và skill gốc
<p> Nguồn và revision được ghi lại
<div> Solution Skill codebase-onboarding
<p> Bản phát hành 1.1.0
<div> Môi trường Codex hoặc Claude Code
<p> Hai môi trường được hỗ trợ
<div> Kết quả Hành trình có dẫn chứng và sơ đồ C1/C2
<p> Người dùng kiểm tra trước khi dùng
<p> Bốn bước: Hallmark và các skill gốc được ghi nguồn và revision; codebase-onboarding phiên bản 1.1.0 kết hợp các thành phần; Codex hoặc Claude Code chạy workflow; người dùng kiểm tra hành trình có dẫn chứng và sơ đồ C1/C2 trước khi sử dụng.
<figcaption> Từ thành phần đã truy vết, qua một Solution Skill có phiên bản, đến bản đồ codebase cần người dùng kiểm tra.
<p> 04 / TÍCH HỢP VÀ SỬ DỤNG
<h2> Đưa skill vào
<br> project của bạn.
<p> Bắt đầu với codebase-onboarding 1.1.0. Problem-presentation 0.1.0 có thể thử riêng nhưng vẫn là ứng viên đánh giá.
<li> 01
<h3> Chọn Solution Skill
<p> Xem trạng thái phát hành và manifest trước khi cài. Một Solution Skill mang theo các thành phần đã khóa phiên bản.
<li> 02
<h3> Build và kiểm tra digest
<p> Clone NKSkills từ GitHub, build gói từ source và dùng digest mà lệnh build trả về. Hiện chưa có archive tải trực tiếp.
<li> 03
<h3> Cài vào project rồi gọi skill
<p> Chọn Codex hoặc Claude Code khi cài. Mở project đích trong AI host, gọi skill và kiểm tra đầu ra trước khi sử dụng.
<aside> CODEX / CLAUDE CODE
<h3> Chọn môi trường bạn đang dùng.
<p> Mỗi hướng dẫn có lệnh build, cài vào repository và cú pháp gọi skill cho đúng môi trường.
<div> Cài cho Codex ↗ Cài cho Claude Code ↗
<p> 05 / DÙNG THỬ
<h2> Bắt đầu bằng
<br> một prompt.
<p> Chọn Codex hoặc Claude Code, xem prompt rồi sao chép. Cài skill từ GitHub và chuẩn bị CodeGraph trước khi chạy.
<div> PROMPT DÙNG THỬ codebase-onboarding@1.1.0
<div> Chọn môi trường
<div> Codex Claude Code
<div> Ngôn ngữ prompt
<div> English Tiếng Việt
</div> Prompt đã chọn Tôi muốn hiểu repository này trước khi sửa mã. Hãy kiểm tra NKSkills codebase-onboarding@1.1.0, codegraph và rtk đã sẵn sàng chưa, đồng thời xác nhận codegraph status báo index hợp lệ tại thư mục gốc của repository này. Nếu thiếu, hãy giải thích các bước build từ mã nguồn và thiết lập theo https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md rồi dừng trước khi cài công cụ, tạo index hoặc sửa file. Nếu đã sẵn sàng, dùng $codebase-onboarding-c4 ở chế độ Quick. Lập bản đồ một hành trình sản phẩm chính và kiến trúc C1/C2, dẫn chứng bằng đường dẫn file. Phân biệt sự thật đã kiểm tra với suy luận. Trả kết quả trong chat trước; hỏi trước khi truy cập hệ thống bên ngoài hoặc tạo artifact.
<div> Sao chép prompt ↗
<p> Prompt yêu cầu kiểm tra điều kiện. AI phải dừng trước khi cài công cụ, tạo index hoặc sửa file nếu môi trường chưa sẵn sàng.
</p> I want to understand this repository before changing it. Check whether NKSkills codebase-onboarding@1.1.0, codegraph, and rtk are available here, and whether codegraph status reports a valid index at this repository root. If anything is missing, explain the source-build and setup steps from https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md and stop before installing tools, creating an index, or editing files. If ready, use $codebase-onboarding-c4 in Quick mode. Map one primary product journey and C1/C2 architecture with file citations. Distinguish verified facts from inferences. Return findings in chat first; ask before accessing external systems or writing artifacts. I want to understand this repository before changing it. Check whether NKSkills codebase-onboarding@1.1.0, codegraph, and rtk are available here, and whether codegraph status reports a valid index at this repository root. If anything is missing, explain the source-build and setup steps from https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md and stop before installing tools, creating an index, or editing files. If ready, use /codebase-onboarding-c4 in Quick mode. Map one primary product journey and C1/C2 architecture with file citations. Distinguish verified facts from inferences. Return findings in chat first; ask before accessing external systems or writing artifacts. Tôi muốn hiểu repository này trước khi sửa mã. Hãy kiểm tra NKSkills codebase-onboarding@1.1.0, codegraph và rtk đã sẵn sàng chưa, đồng thời xác nhận codegraph status báo index hợp lệ tại thư mục gốc của repository này. Nếu thiếu, hãy giải thích các bước build từ mã nguồn và thiết lập theo https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md rồi dừng trước khi cài công cụ, tạo index hoặc sửa file. Nếu đã sẵn sàng, dùng $codebase-onboarding-c4 ở chế độ Quick. Lập bản đồ một hành trình sản phẩm chính và kiến trúc C1/C2, dẫn chứng bằng đường dẫn file. Phân biệt sự thật đã kiểm tra với suy luận. Trả kết quả trong chat trước; hỏi trước khi truy cập hệ thống bên ngoài hoặc tạo artifact. Tôi muốn hiểu repository này trước khi sửa mã. Hãy kiểm tra NKSkills codebase-onboarding@1.1.0, codegraph và rtk đã sẵn sàng chưa, đồng thời xác nhận codegraph status báo index hợp lệ tại thư mục gốc của repository này. Nếu thiếu, hãy giải thích các bước build từ mã nguồn và thiết lập theo https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/guides/technical-v1.md rồi dừng trước khi cài công cụ, tạo index hoặc sửa file. Nếu đã sẵn sàng, dùng /codebase-onboarding-c4 ở chế độ Quick. Lập bản đồ một hành trình sản phẩm chính và kiến trúc C1/C2, dẫn chứng bằng đường dẫn file. Phân biệt sự thật đã kiểm tra với suy luận. Trả kết quả trong chat trước; hỏi trước khi truy cập hệ thống bên ngoài hoặc tạo artifact.
<div> Cần cài đặt trước? Hướng dẫn Codex ↗ Hướng dẫn Claude Code ↗
<p> 06 / DANH MỤC
<h2> Tuyển chọn có
<br> nguồn gốc.
<p> Nguồn công khai, phiên bản và giấy phép được theo dõi riêng. Một skill xuất hiện trong catalog không có nghĩa là đã nằm trong bản phát hành thương mại.
</p> Mở toàn bộ danh mục ↗
<div> 01 / UPSTREAM hallmark Trong codebase onboarding
<div> 02 / UPSTREAM diagram-design Trong ứng viên problem presentation
<div> 03 / AUTHORING frontend-design + copywriting + design-taste-frontend Dùng để biên soạn website này
<div> 04 / QUY TRÌNH ĐỀ XUẤT Taste Skill + Impeccable Hướng thị giác → rà soát thiết kế; chưa là Solution Skill
<div> + Nguồn, commit, giấy phép ↗
<p> 07 / NGUỒN BẢO MẬT
<h2> Đúng câu hỏi.
<br> Đúng công cụ.
<p> Các public skills được khóa commit cho các công việc bảo mật khác nhau. Đây là nguồn đang theo dõi, chưa phải Solution Skill đã phát hành.
<div> 01 / AUDIT UPSTREAM ĐANG THEO DÕI
<p> Cloudflare
<h3> security-audit
<p> Audit codebase theo phạm vi bao phủ, với bước xác minh độc lập. Chạy đầy đủ cần agent tách biệt và sandbox được kiểm soát.
</p> Xem nguồn đã khóa phiên bản ↗
<div> 02 / REVIEW UPSTREAM ĐANG THEO DÕI
<p> Sentry
<h3> security-review
<p> Rà soát mã trong phạm vi cụ thể, chỉ báo cáo lỗ hổng có độ tin cậy cao. Tài liệu dẫn từ OWASP cần rà soát giấy phép trước khi đóng gói.
</p> Xem nguồn đã khóa phiên bản ↗
<div> 03 / HARDEN UPSTREAM ĐANG THEO DÕI
<p> Addy Osmani
<h3> security-and-hardening
<p> Mô hình đe dọa và các mẫu triển khai web an toàn. Checklist nằm ngoài thư mục skill cần được xử lý trước khi đóng gói độc lập.
</p> Xem nguồn đã khóa phiên bản ↗
<div> 04 / GUIDANCE UPSTREAM ĐANG THEO DÕI
<p> OpenAI
<h3> security-best-practices
<p> Hướng dẫn bảo mật theo ngôn ngữ và framework cho Python, JavaScript/TypeScript và Go. Cách đóng gói trên hai host vẫn cần thử nghiệm.
</p> Xem nguồn đã khóa phiên bản ↗
<div> 05 / SKILL REVIEW UPSTREAM ĐANG THEO DÕI
<p> OpenAI
<h3> codex-security-check-skills
<p> Rà soát skill trước khi cài đặt theo chế độ chỉ đọc. Cần thử nghiệm tương thích host và đóng gói.
</p> Xem nguồn đã khóa phiên bản ↗
<div> 06 / SCAN UPSTREAM ĐANG THEO DÕI
<p> OpenAI
<h3> codex-security-scan
<p> Quy trình quét lỗ hổng cần công cụ plugin Codex Security và tài liệu bên ngoài. Đang theo dõi để đánh giá.
</p> Xem nguồn đã khóa phiên bản ↗
<p> Phạm vi, giấy phép và điều kiện chạy được ghi rõ trong hồ sơ từng nguồn. Chưa có security Solution Skill để cài từ NKSkills. Xem trong danh mục ↗
<p> 08 / FAQ
<h2> Cần biết trước
<br> khi bắt đầu.
<summary> NKSkills hỗ trợ môi trường nào?
<p> Codex và Claude Code. Mỗi môi trường có hướng dẫn cài đặt riêng.
<summary> Upstream mới có tự cập nhật vào Solution Skill không?
<p> Không. Chúng tôi theo dõi nguồn, kiểm tra bản mới rồi mới quyết định có phát hành phiên bản Solution Skill mới hay không.
<summary> Problem presentation đã sẵn sàng thương mại chưa?
<p> Chưa. Bản 0.1.0 là ứng viên đánh giá; cổng phát hành thương mại vẫn mở.
<summary> Prompt có tự sửa code của tôi không?
<p> Prompt yêu cầu báo cáo trong chat trước và hỏi trước khi truy cập hệ thống ngoài hoặc ghi artifact. Nếu thiếu điều kiện chạy, AI phải dừng trước khi cài công cụ, tạo index hoặc sửa file.
<p> NKSKILLS / CODEBASE ONBOARDING
<h2> Hiểu rõ hệ thống.
<br> Rồi hãy thay đổi nó.
<p> Bắt đầu với workflow có dẫn chứng cho Codex hoặc Claude Code.
<div> Lấy prompt dùng thử ↗ Xem giải pháp ↗
<div> NKSkills
<br> Skill workflow có phiên bản cho Codex và Claude Code.
<div> Danh mục Giải pháp GitHub Bản phát hành Giấy phép font English

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/en/" lang="en" aria-label="Switch to English">
<div class="hero-orb hero-orb-one" aria-hidden="true">
<div class="hero-orb hero-orb-two" aria-hidden="true">
<span class="hero-kicker-dot" aria-hidden="true">
<span aria-hidden="true">
<span class="caption-plus" aria-hidden="true">
<span class="caption-rule" aria-hidden="true">
<span class="chip-symbol" aria-hidden="true">
<span class="chip-symbol chip-symbol-blue" aria-hidden="true">
<span class="chip-symbol chip-symbol-green" aria-hidden="true">
<div class="board-arrow" aria-hidden="true">
<span class="model-glyph" aria-hidden="true">
<div class="work-visual architecture-visual" aria-hidden="true">
<div class="work-visual presentation-visual" aria-hidden="true">
<div class="prompt-picker" data-prompt-picker data-page-locale="vi">
<div class="tab-list" role="group" aria-label="Môi trường AI" data-choice-group="host" data-active-index="0">
<button type="button" data-choice data-host="codex" aria-pressed="true">
<button type="button" data-choice data-host="claude-code" aria-pressed="false">
<div class="tab-list" role="group" aria-label="Ngôn ngữ prompt" data-choice-group="locale" data-active-index="1">
<button type="button" data-choice data-locale="en" aria-pressed="false">
<button type="button" data-choice data-locale="vi" aria-pressed="true">
<button class="button copy-button" type="button" data-copy>Sao chép prompt<span aria-hidden="true">
<p class="copy-status" role="status" aria-live="polite" data-copy-status></p>
<template data-prompt-locale="en" data-prompt-host="codex">
<template data-prompt-locale="en" data-prompt-host="claude-code">
<template data-prompt-locale="vi" data-prompt-host="codex">
<template data-prompt-locale="vi" data-prompt-host="claude-code">
<a href="/en/" lang="en">
