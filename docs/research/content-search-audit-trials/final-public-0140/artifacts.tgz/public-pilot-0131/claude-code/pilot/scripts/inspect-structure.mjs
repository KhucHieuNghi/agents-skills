// Prints the shape of campaign part manifests (local read only; no page code executed).
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const pilot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const part = path.join(pilot, process.argv[2] ?? "campaign-r1", "parts", "000001");
const trunc = (v) => {
  const s = typeof v === "string" ? v : JSON.stringify(v);
  return s.length > 300 ? s.slice(0, 300) + `…[${s.length}]` : s;
};
const lines = async (f) =>
  (await readFile(path.join(part, f), "utf8")).split("\n").filter(Boolean).map((l) => JSON.parse(l));

const inv = await lines("inventory.jsonl");
console.log("INVENTORY", inv.length);
for (const i of inv) console.log(JSON.stringify(i));
const ev = await lines("evidence.jsonl");
console.log("EVIDENCE", ev.length);
for (const e of ev.slice(0, 6)) {
  const o = {};
  for (const [k, v] of Object.entries(e)) o[k] = trunc(v);
  console.log(JSON.stringify(o, null, 1));
}
const byItem = {};
for (const e of ev) (byItem[e.itemId] ??= []).push(`${e.kind}:${e.evidenceId}`);
console.log(JSON.stringify(byItem, null, 1));
const checks = await lines("checks.jsonl");
console.log("CHECKS", checks.length);
console.log(JSON.stringify(checks[0]));
console.log(JSON.stringify(checks.filter((c) => c.status !== "unknown").map((c) => [c.itemId, c.ruleId, c.status])));
console.log("FINDINGS", await readFile(path.join(part, "findings.json"), "utf8"));
const camp = JSON.parse(await readFile(path.join(pilot, process.argv[2] ?? "campaign-r1", "campaign.json"), "utf8"));
const c2 = {};
for (const [k, v] of Object.entries(camp)) c2[k] = trunc(v);
console.log(JSON.stringify(c2, null, 1));
