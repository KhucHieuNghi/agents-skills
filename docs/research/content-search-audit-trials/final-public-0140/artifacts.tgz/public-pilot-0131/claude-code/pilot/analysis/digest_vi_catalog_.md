# https://nkskills.getgroove.me/vi/catalog/
itemId: cc34ba7630bc37b8c46b7aacb5e42e30dd427d971c3ccb3e2ddc0482f2f2017c
contentEvidence: f2b90c2eb52e5e11adfc6ac1834ff853386221b3e759a0b14ef51ea9fab2f921
httpEvidence: eebbdb892055b3003b71655dca012566b75235fc3b347e0a64fa96de4a38eee6
robotsEvidence: 6b050d43894fcc9f971726b23460c9ff6c79f73275734e2535e0374f89f5cd14
bytes(chars): 14869

## http-response
{
 "status": 200,
 "headers": {
  "content-type": "text/html",
  "cache-control": "public, max-age=0, must-revalidate"
 },
 "url": "https://nkskills.getgroove.me/vi/catalog/",
 "redirects": [],
 "attempts": [
  {
   "status": 200,
   "url": "https://nkskills.getgroove.me/vi/catalog/",
   "collectedAt": "2026-11-18T08:24:28.964Z",
   "retryAfter": null
  }
 ],
 "wireHash": "3cffc5db63206d234c0e73524457520e0ecf7ab0bc3ce95dc3c6a839b0f9abfd"
}

## crawler-policy
{
 "capture": {
  "url": "https://nkskills.getgroove.me/robots.txt",
  "status": 200,
  "body": "User-agent: *\nAllow: /\nSitemap: https://nkskills.getgroove.me/sitemap.xml\n",
  "error": null,
  "headers": {
   "content-type": "text/plain",
   "content-length": "74",
   "etag": "\"4cc78595f4f84b49086d8cd28f59de6a\"",
   "cache-control": "public, max-age=0, must-revalidate"
  },
  "redirects": [],
  "attempts": [
   {
    "status": 200,
    "url": "https://nkskills.getgroove.me/robots.txt",
    "collectedAt": "2026-11-18T08:24:28.662Z",
    "retryAfter": null
   }
  ],
  "wireHash": "c1ed52be4d81ba97b8ffda4952c5a30639a09de23798d583eca330bcbc2cb24a",
  "wireBase64": "VXNlci1hZ2VudDogKgpBbGxvdzogLwpTaXRlbWFwOiBodHRwczovL25rc2tpbGxzLmdldGdyb292ZS5tZS9zaXRlbWFwLnhtbAo=",
  "finalUrl": "https://nkskills.getgroove.me/robots.txt",
  "collectedAt": "2026-11-18T08:24:28.662Z"
 },
 "decision": {
  "crawlDelaySeconds": 0,
  "sitemaps": [
   "https://nkskills.getgroove.me/sitemap.xml"
  ],
  "diagnostics": [],
  "allowed": true,
  "reason": "Matched allow rule at line 2",
  "matchedRule": {
   "directive": "allow",
   "pattern": "/",
   "line": 2,
   "specificity": 1
  }
 }
}

## html tag
<html lang="vi">

## title
Danh mục skill | NKSkills

## head meta/link/base tags
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FFFDFB">
<meta name="description" content="Khám phá Solution Skills và Upstream Skills đã khóa phiên bản của NKSkills, cùng nguồn, phiên bản, giấy phép và trạng thái phát hành.">
<link rel="icon" type="image/svg+xml" href="/brand/favicon.svg">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-latin-full-normal.CFFu7zhK.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-latin-wght-normal.Bo_j9asI.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/fraunces-vietnamese-full-normal.7BpKI3vF.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" href="/_astro/source-sans-3-vietnamese-wght-normal.BDs68eHQ.woff2">
<link rel="canonical" href="https://nkskills.getgroove.me/vi/catalog/">
<link rel="alternate" hreflang="en" href="https://nkskills.getgroove.me/en/catalog/">
<link rel="alternate" hreflang="vi" href="https://nkskills.getgroove.me/vi/catalog/">
<link rel="alternate" hreflang="x-default" href="https://nkskills.getgroove.me/en/catalog/">
<meta property="og:type" content="website">
<meta property="og:title" content="Danh mục skill | NKSkills">
<meta property="og:description" content="Khám phá Solution Skills và Upstream Skills đã khóa phiên bản của NKSkills, cùng nguồn, phiên bản, giấy phép và trạng thái phát hành.">
<meta property="og:image" content="https://nkskills.getgroove.me/brand/og-vi.png">
<meta property="og:url" content="https://nkskills.getgroove.me/vi/catalog/">
<link rel="stylesheet" href="/_astro/Base.4pnhS-oP.css">
<link rel="stylesheet" href="/_astro/CatalogPage.BhNzWDKD.css">

## script elements (source text only; never executed)
- type=module src=https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092 inlineLength=0

## noscript/iframe/template/form/style counts
noscript: 0
iframe: 0
template: 0
form: 0
style: 0
svg: 0
img: 1
video: 0
audio: 0
picture: 0
button: 0
details: 0

## img/svg accessibility attributes
<img src="/brand/nkskills-mark.svg" width="42" height="42" alt="">

## headings
h1: Những skill đứng sau workflow.
h2: Workflow được đóng gói theo kết quả.
h3: Codebase onboarding 1.1.0
h3: Problem presentation 0.1.0
h3: Content search audit 0.1.32
h2: Nguồn công khai, phiên bản cụ thể.
h3: Nhiều nguồn, nhiều nhiệm vụ.
h2: Cập nhật có kiểm soát.

## anchors (href | rel | target | text)
#main-content | rel=null | hreflang=null | aria=null | Đến nội dung chính
/vi/ | rel=null | hreflang=null | aria=NKSkills home | NK Skills
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/#try-it | rel=null | hreflang=null | aria=null | Dùng thử
/en/catalog/ | rel=null | hreflang=null | aria=Switch to English | EN
#solutions | rel=null | hreflang=null | aria=null | 03 Solution Skills
#upstreams | rel=null | hreflang=null | aria=null | 15 Upstream Skills
#security-upstreams | rel=null | hreflang=null | aria=null | 06 Nguồn bảo mật
#method | rel=null | hreflang=null | aria=null | 01 Cách quản lý
/vi/solutions/codebase-onboarding/ | rel=null | hreflang=null | aria=Xem giải pháp codebase onboarding | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/solutions/problem-presentation.yaml | rel=null | hreflang=null | aria=Xem manifest problem presentation | ↗
/vi/guides/codex/#content-search-audit | rel=null | hreflang=null | aria=Cài Content search audit | ↗
https://github.com/nutlope/hallmark/tree/13ac0ec7e148655948100b6396439e481361d690/skills/hallmark | rel=null | hreflang=null | aria=hallmark source | ↗
https://github.com/claude-office-skills/skills/tree/9c4c7d5cd2813a8936bf2c9fdb174ea883b85a11/html-slides | rel=null | hreflang=null | aria=html-slides-reference source | ↗
https://github.com/tt-a1i/archify/tree/88d1ae4498b6a1df610badf690c5406882622d15/archify | rel=null | hreflang=null | aria=archify source | ↗
https://github.com/cathrynlavery/diagram-design/tree/550fd66edff058bc73056c3416b76d69cfe865ba/skills/diagram-design | rel=null | hreflang=null | aria=diagram-design source | ↗
https://github.com/nicobailon/visual-explainer/tree/5a1b3c4d6e86c6d0225c6d8ee0972f4d02108be2/plugins/visual-explainer | rel=null | hreflang=null | aria=visual-explainer source | ↗
https://github.com/anthropics/skills/tree/dbd4588f9e1033efb41dad4bef2f7947c8993d44/skills/frontend-design | rel=null | hreflang=null | aria=frontend-design source | ↗
https://github.com/coreyhaines31/marketingskills/tree/365b412152b9542499ca1439426f7fc3cc92bb65/skills/copywriting | rel=null | hreflang=null | aria=copywriting source | ↗
https://github.com/Leonxlnx/taste-skill/tree/12af471f627f866411b4bd785b19646d3672784c/skills/taste-skill | rel=null | hreflang=null | aria=design-taste-frontend source | ↗
https://github.com/pbakaus/impeccable/tree/b7a89176e4e87422b40f98adabceb051dbb5448b/.agents/skills/impeccable | rel=null | hreflang=null | aria=impeccable source | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/research/security-upstreams.md | rel=null | hreflang=null | aria=null | Đọc hồ sơ nguồn ↗
https://github.com/cloudflare/security-audit-skill/tree/c1c8a8c1471069fb0e188eeaff69b8e8db6564a8/skills/security-audit | rel=null | hreflang=null | aria=security-audit source | ↗
https://github.com/getsentry/skills/tree/0c464f411bdfb8d4c12314b36264d06cb2f60270/skills/security-review | rel=null | hreflang=null | aria=security-review source | ↗
https://github.com/addyosmani/agent-skills/tree/301b02b12bff98e4688e6984af6556802322bbde/skills/security-and-hardening | rel=null | hreflang=null | aria=security-and-hardening source | ↗
https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/security-best-practices | rel=null | hreflang=null | aria=security-best-practices source | ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/check-skills | rel=null | hreflang=null | aria=codex-security-check-skills source | ↗
https://github.com/openai/codex-security/tree/173483d7c658be7a512c93d9559bf01a05d5b196/plugins/codex-security/skills/security-scan | rel=null | hreflang=null | aria=codex-security-scan source | ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/catalog.yaml | rel=null | hreflang=null | aria=null | catalog.yaml ↗
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/product-model.md | rel=null | hreflang=null | aria=null | Đọc mô hình sản phẩm →
/vi/catalog/ | rel=null | hreflang=null | aria=null | Danh mục
/vi/catalog/#solutions | rel=null | hreflang=null | aria=null | Giải pháp
https://github.com/KhucHieuNghi/agents-skills | rel=null | hreflang=null | aria=null | GitHub
https://github.com/KhucHieuNghi/agents-skills/blob/main/docs/releases/1.1.0.md | rel=null | hreflang=null | aria=null | Bản phát hành
/licenses/README.txt | rel=null | hreflang=null | aria=null | Giấy phép font
/en/catalog/ | rel=null | hreflang=null | aria=null | English

## visible text by block (tags removed)
Đến nội dung chính
<div> NK Skills
<nav> Giải pháp Danh mục Dùng thử EN
<p> NKSKILLS / DANH MỤC
<h1> Những skill đứng sau workflow.
<p> Hai lớp tạo nên NKSkills: Solution Skill quy định kết quả và các bước thực hiện; Upstream Skill cung cấp năng lực đã được chọn, khóa phiên bản và ghi rõ nguồn.
<div> 03 Solution Skills 15 Upstream Skills 06 Nguồn bảo mật 01 Cách quản lý
<p> 01 / SOLUTION SKILLS
<h2> Workflow được đóng gói theo kết quả.
<p> Mỗi Solution Skill có phiên bản riêng, manifest thành phần và tiêu chuẩn kiểm tra. Trạng thái bên dưới phản ánh mức độ xác minh hiện tại.
<div> 01 / BẢN PHÁT HÀNH KỸ THUẬT
<h3> Codebase onboarding 1.1.0
<p> Dẫn kỹ sư qua hành trình sản phẩm, sơ đồ C1/C2 và dẫn chứng theo file trước khi sửa mã.
<div> Codex Claude Code 3 thành phần
</div> ↗
<div> 02 / ỨNG VIÊN ĐÁNH GIÁ
<h3> Problem presentation 0.1.0
<p> Tạo deck HTML và PDF ngoại tuyến để trình bày một vấn đề có dẫn chứng và quyết định cần đưa ra. Chưa qua cổng phát hành thương mại.
<div> Codex Claude Code Đang đánh giá
</div> ↗
<div> 03 / ỨNG VIÊN ĐÁNH GIÁ
<h3> Content search audit 0.1.32
<p> Một skill audit nội dung, SEO, AIO, AEO và GEO, với dẫn chứng, phạm vi đã kiểm tra và danh sách sửa ưu tiên. Kết quả cần được review trước khi áp dụng.
<div> Codex Claude Code 1 skill
</div> ↗
<p> 02 / UPSTREAM SKILLS
<h2> Nguồn công khai, phiên bản cụ thể.
<p> Danh mục này theo dõi nguồn, commit và giấy phép. Một số skill đang được dùng để biên soạn website; việc xuất hiện ở đây không có nghĩa là đã nằm trong Solution Skill phát hành.
<div> hallmark Nguồn theo dõi
<div> design documentation
<div> MIT
<code> 13ac0ec7e1
</div> ↗
<div> html-slides-reference Nguồn theo dõi
<div> presentation slides
<div> MIT
<code> 9c4c7d5cd2
</div> ↗
<div> archify Nguồn theo dõi
<div> diagrams architecture
<div> MIT
<code> 88d1ae4498
</div> ↗
<div> diagram-design Nguồn theo dõi
<div> diagrams design
<div> MIT
<code> 550fd66edf
</div> ↗
<div> visual-explainer Nguồn theo dõi
<div> presentation slides
<div> MIT
<code> 5a1b3c4d6e
</div> ↗
<div> frontend-design Công cụ biên soạn
<div> design frontend
<div> Apache-2.0
<code> dbd4588f9e
</div> ↗
<div> copywriting Công cụ biên soạn
<div> marketing copywriting
<div> MIT
<code> 365b412152
</div> ↗
<div> design-taste-frontend Công cụ biên soạn
<div> design frontend
<div> MIT
<code> 12af471f62
</div> ↗
<div> impeccable Đề xuất cùng Taste
<div> design frontend
<div> Apache-2.0
<code> b7a89176e4
</div> ↗
<p> CHỦ ĐỀ / BẢO MẬT
<h3> Nhiều nguồn, nhiều nhiệm vụ.
<p> Audit, review, hardening và hướng dẫn bảo mật được theo dõi riêng. Chưa có gói security Solution Skill; giấy phép, điều kiện chạy và khả năng đóng gói vẫn cần đánh giá. Đọc hồ sơ nguồn ↗
<div> security-audit Nguồn bảo mật đang theo dõi
<div> security audit
<div> MIT
<code> c1c8a8c147
</div> ↗
<div> security-review Nguồn bảo mật đang theo dõi
<div> security code-review
<div> Apache-2.0 with CC-BY-SA-4.0 reference material
<code> 0c464f411b
</div> ↗
<div> security-and-hardening Nguồn bảo mật đang theo dõi
<div> security hardening
<div> MIT
<code> 301b02b12b
</div> ↗
<div> security-best-practices Nguồn bảo mật đang theo dõi
<div> security best-practices
<div> Apache-2.0
<code> 49f948faa9
</div> ↗
<div> codex-security-check-skills Nguồn bảo mật đang theo dõi
<div> security skill-review
<div> Apache-2.0
<code> 173483d7c6
</div> ↗
<div> codex-security-scan Nguồn bảo mật đang theo dõi
<div> security audit
<div> Apache-2.0
<code> 173483d7c6
</div> ↗
<p> Nguồn dữ liệu: catalog.yaml trong repository. Commit đầy đủ, checksum, quy tắc ghi nguồn và thay đổi cục bộ nằm trong file này. catalog.yaml ↗
<p> 03 / QUẢN LÝ PHIÊN BẢN
<h2> Cập nhật có kiểm soát.
<p> Chúng tôi theo dõi commit mới của upstream. Khi có thay đổi, đó là một ứng viên để kiểm tra giấy phép, nội dung và tác động. Solution Skill chỉ thay đổi khi ra phiên bản riêng cùng manifest và bằng chứng kiểm tra mới.
</p> Đọc mô hình sản phẩm →
<div> NKSkills
<br> Skill workflow có phiên bản cho Codex và Claude Code.
<div> Danh mục Giải pháp GitHub Bản phát hành Giấy phép font English

## body-level attributes of interest (data-*, hidden, aria-hidden, lang= inside body)
<a class="language-link" href="/en/catalog/" lang="en" aria-label="Switch to English">
<a href="/en/catalog/" lang="en">
