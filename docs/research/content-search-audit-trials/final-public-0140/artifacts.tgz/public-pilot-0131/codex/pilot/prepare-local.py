import json, re, hashlib
from pathlib import Path
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin, urldefrag, urlsplit

root=Path('pilot')
part='parts/000001'
p=root/'collection'/part
read=lambda x:json.loads(x.read_text())
rows=lambda name:[json.loads(l) for l in (p/(name+'.jsonl')).read_text().splitlines()]
write=lambda name,x:(root/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
now=datetime.now(timezone.utc).isoformat(timespec='milliseconds')
reviewer='Codex public pilot reviewer'
items=rows('inventory')
evidence=rows('evidence')
checks=rows('checks')
idx=read(root/'index/index.json')

class Source(HTMLParser):
    def __init__(self,body):
        super().__init__(convert_charrefs=True)
        self.skip=[]
        self.text=[]
        self.tags=[]
        self.feed(body)

    def handle_starttag(self,tag,attrs):
        self.tags.append((tag,dict(attrs)))
        if tag in {'script','style','template'}:
            self.skip.append(tag)

    def handle_endtag(self,tag):
        if self.skip and self.skip[-1]==tag:
            self.skip.pop()

    def handle_data(self,data):
        if not self.skip and data.strip():
            self.text.append(data.strip())

data={}
for item in items:
    ident=item['itemId']
    records={x['kind']:x for x in evidence if x['itemId']==ident}
    content=records['content']
    raw=(p/content['artifact']).read_text()
    assert digest(raw)==content['snapshotHash']
    response=records['http-response']['value']
    path=urlsplit(item['uri']).path
    parsed=Source(raw) if response['headers']['content-type']=='text/html' else None
    data[path]=(item,records,raw,response,parsed)

audience='User task statement: NKSkills composes versioned skill workflows for Codex and Claude Code. The intended audiences read English and Vietnamese. AIO means AI search optimization. No audience research, analytics or Google AI Overviews measurements were supplied. Page-level tasks below are reviewer inferences from source.'
tasks={
 'home':'Orient readers to the three workflows, explain release status, and route readers to catalog, onboarding, host setup or the starter prompt.',
 'catalog':'Compare the three workflow statuses and the tracked upstream inventory, with source, revision and license pointers.',
 'solution':'Evaluate onboarding 1.1.0, its three components, prerequisites, C1/C2 output and verification limits.',
 'guide':'Build, install and invoke on the named host. The guide covers onboarding, the presentation trial and the content search audit candidate.',
 'notice':'Identify three font attributions and their full-notice filenames. The filenames are plain-text references.'
}
artifacts={}
added=[]
reviews=[]
maps=[]
for path,(item,records,raw,response,parsed) in data.items():
    ident=item['itemId']
    c=records['content']
    typ='notice' if parsed is None else 'guide' if '/guides/' in path else 'solution' if '/solutions/' in path else 'catalog' if '/catalog/' in path else 'home'
    title=re.search(r'<title>(.*?)</title>',raw)
    desc=next((d['content'] for t,d in parsed.tags if t=='meta' and d.get('name')=='description'),None) if parsed else None
    language=next(d['lang'] for t,d in parsed.tags if t=='html') if parsed else None
    links=[d for t,d in parsed.tags if t=='link'] if parsed else []
    canonical=next((d['href'] for d in links if d.get('rel')=='canonical'),None)
    alternates={d['hreflang']:d['href'] for d in links if 'hreflang' in d}
    graph=sorted({urljoin(response['url'],d['href']) for t,d in parsed.tags if t=='a' and 'href' in d}) if parsed else []
    mapping=dict(path=path,task=tasks[typ],language=language,finalUrl=response['url'],status=response['status'],
        title=title[1] if title else None,description=desc,canonical=canonical,alternates=alternates,staticLinks=graph)
    maps.append(mapping)
    def derive(kind,value,locator,sources=None):
        name=f'{kind}-{ident[:16]}'
        artifact=f'evidence/{name}.txt'
        artifacts[artifact]=value
        added.append(dict(itemId=ident,evidenceId=name,kind=kind,method='attributed-local-review',locator=locator,collectedAt=now,
            value=value,snapshotHash=digest(value),artifact=artifact,encoding='utf8',redaction='Public source or supplied context',
            sourceEvidenceIds=sources or [c['evidenceId']],limitations=['Static snapshot and attributed review. Browser behavior and measured visibility are unavailable.']))
        return name
    derive('extracted-text','\n'.join(parsed.text)+'\n' if parsed else raw,response['url']+' (local inert text extraction)')
    ctx=derive('audience-context',audience+'\nInferred page task. '+tasks[typ],'User task statement and '+response['url'])
    inv=derive('inventory-map',json.dumps({k:v for k,v in mapping.items() if k!='staticLinks'},ensure_ascii=False),response['url']+' (declared inventory role)')
    graph_e=derive('link-graph',json.dumps(graph,ensure_ascii=False),response['url']+' (static anchor hrefs)')
    def review(rule,status,reason,*deps):
        reviews.append(dict(itemId=ident,ruleId=rule,status=status,reason=reason,
            evidenceIds=[c['evidenceId'],*deps],reviewer=reviewer,reviewedAt=now))
    note={
       'home':'Composition, release labels, workflow diagram description, setup overview, starter prompt, source curation and native FAQ are present. Prompt selection and copy behavior require rendering.',
       'catalog':'The three workflow statuses, 15 tracked upstream entries and versioning explanation are available in source. Full provenance is linked out.',
       'solution':'Both locales describe the same three components, Quick mode deliverables, root index and review requirement.',
       'guide':'All three workflows have host-specific instructions. The initial source clone lacks a release checkout before building version-labelled packages.',
       'notice':'The three font attributions and notice filenames are plain text. Full notices were outside the discovered static-link inventory.'
    }[typ]
    review('quality-task-fit','unknown',tasks[typ]+' '+note,ctx)
    review('quality-claims','unknown',note+' Public source statements lack independent dated corroboration within the permitted origin.')
    review('quality-freshness','unknown','Release and revision labels are present where relevant. Current authoritative release and license records were not supplied.')
    review('quality-accessible-media','unknown',('The markup has decorative brand art and a text-described workflow diagram. Rendered behavior and a complete authored media inventory were not supplied.' if typ=='home' else 'Rendered accessibility and complete media inventory are unavailable.') if parsed else 'The captured resource is plain text with no media.',*([] if parsed else [records['http-response']['evidenceId']]))
    review('seo-index-controls','unknown','The anonymous snapshot is accessible. Publisher index and snippet intent, sitemap coverage and engine index observations are unavailable.',records['http-response']['evidenceId'])
    if parsed:
        base=urlsplit(response['url']).path
        peer_path=('/vi/' if base.startswith('/en/') else '/en/')+base[4:]
        peer=data[peer_path]
        peer_c=peer[1]['content']
        peer_alts={d['hreflang']:d['href'] for t,d in peer[4].tags if t=='link' and 'hreflang' in d}
        assert peer_alts==alternates and alternates[language]==response['url']
        assert canonical==response['url'] and alternates['x-default']==alternates['en']
        rel=derive('locale-map',json.dumps(dict(current=alternates,reciprocal=peer_alts,language=language),ensure_ascii=False),
                   response['url']+' and '+peer[3]['url']+' (HTML head)',[c['evidenceId'],peer_c['evidenceId']])
        canon=derive('canonical-targets',json.dumps(dict(canonical=canonical,status=response['status'],observedFinalUrl=response['url'],redirects=response['redirects'])),
                     response['url']+' (HTML canonical and final HTTP evidence)',[c['evidenceId'],records['http-response']['evidenceId']])
        review('seo-locales','pass','Captured EN/VI head annotations are reciprocal and self-reference with an English x-default. The locale and canonical signals agree on these captured variants.',rel)
        review('seo-canonical','pass','The HTML canonical matches the successful observed final target and the corresponding language variant. The root request redirects to the English canonical. Engine selection remains unknown.' if path=='/' else 'The captured HTML canonical is self-referential on the successful final URL and preserves the locale variant. Engine selection remains unknown.',canon)
        metadata='Title, description and H1 describe the principal page task and named host where relevant.'
        if typ in {'guide','home'}:
            metadata+=' The description names onboarding and presentation. The audit candidate appears in body content.'
        review('seo-metadata','pass',metadata,ctx)
        review('seo-structured-data','unknown','No JSON-LD was observed in the captured markup. Rendered markup and feature eligibility remain unverified.')
        review('seo-rendering','unknown','Source content was inspected. Rendered DOM, visibility and behavior are outside the pilot.')
    else:
        for rule,reason in {
            'seo-metadata':'The captured text/plain font notice has no HTML title, description or headings to assess.',
            'seo-rendering':'The captured text/plain notice is fully readable as text and contains no script or HTML interface.',
            'quality-accessible-media':'The complete captured text/plain notice consists of text and filenames without media.'}.items():
            reviews=[r for r in reviews if not (r['itemId']==ident and r['ruleId']==rule)]
            review(rule,'not-applicable',reason,records['http-response']['evidenceId'])
        review('seo-canonical','unknown','The successful text/plain response supplied no HTTP Link header. Intended canonical and variant policy for this notice are unknown.',records['http-response']['evidenceId'])
        review('seo-locales','unknown','The notice is a shared plain-text resource. Publisher locale intent and corresponding notice variants were not supplied.')
    review('seo-internal-links','unknown','Captured in-origin HTML anchors were checked against the declared static graph. Rendered, orphan and CMS reachability remain unknown. Plain-text notice filenames require another navigation adapter.',graph_e)
    review('aio-crawler-policy','unknown','Anonymous helper policy permitted this capture. Publisher intent per crawler and search or retrieval logs were not supplied.',records['crawler-policy']['evidenceId'])
    review('aio-entity-consistency','unknown',note+' An approved current entity record is needed for an item-wide verdict.')
    review('aio-retrievable-facts','unknown',note+' Anonymous source text supports local inspection. Surface-specific retrieval and all decision-critical facts remain unverified.',ctx)
    review('aeo-question-coverage','unknown','No observed audience question set was supplied. '+note)
    review('aeo-answer-context','unknown','No observed audience question set was supplied. '+note)
    review('aeo-answer-evidence','unknown','The page statements were reviewed in context. '+note+' Supporting external release or manifest records were not collected.')
    for rule in ['geo-observed-presence','geo-answer-accuracy','geo-cohort-validity']:
        review(rule,'unknown','No dated response-level observations or cohort were supplied for any engine or locale.')
    review('portfolio-task-gaps','unknown','Task inferred from this item: '+tasks[typ]+' No search, support or customer question set was supplied.',inv)
    review('portfolio-duplication','unknown','Paired locale versions serve different audiences. Host guides include distinct host targets and invocations. Root redirect alias is retained. Global comparison is recorded separately.',inv)
    review('portfolio-contradictions','unknown',note+' No authoritative entity record establishes the correctness of all material claims.',inv)
    review('portfolio-journey-links','unknown','Static anchors capture observed next steps. Rendered navigation is unavailable.',graph_e,ctx)

def finding(key,title,paths,rules,dims,remediation,verification):
    return dict(findingId=key,title=title,affectedItemIds=[data[x][0]['itemId'] for x in paths],
        ruleIds=rules,dimensions=dims,evidenceIds=[data[x][1]['content']['evidenceId'] for x in paths],
        severity='medium',confidence='high',classification='observed',remediation=remediation,
        verification=verification,ownerRole='NKSkills documentation maintainer',effort='small')
guide_paths=[x for x in data if '/guides/' in x]
for path in guide_paths:
    raw=data[path][2]
    assert 'git clone https://github.com/KhucHieuNghi/agents-skills.git' in raw
    assert 'git checkout' not in raw and 'git switch' not in raw
audit_entries=['/','/en/','/vi/','/en/catalog/','/vi/catalog/']
for path in audit_entries:
    assert re.search(r'href="/(?:en|vi)/guides/codex/#content-search-audit"',data[path][2])
    assert not re.search(r'href="/(?:en|vi)/guides/claude-code/#content-search-audit"',data[path][2])
findings=[
    finding('guide-source-ref','Version-labelled install guides build from an unspecified repository revision',guide_paths,['quality-task-fit'],['quality'],
            'In the source build blocks in both host guides and both languages, add the owner-verified immutable source ref for each documented release or candidate. Clarify when a digest verifies the locally built archive versus release identity.',
            'Review the revised source instructions against approved release refs and expected manifests. Verify that each documented build checks out its ref before building. No commands were executed in this pilot.'),
    finding('audit-host-route','Content search audit entry links lead only to the Codex instructions',audit_entries,['portfolio-journey-links'],['portfolio'],
            'Add explicit Codex and Claude Code audit links on both the homepage card and catalog entry in both languages. The captured Claude Code guides already contain the localized audit section.',
            'Inspect the revised static links from each localized entry and match the same-language host and content-search-audit fragment to both target guides. Verify the root alias still leads to the English page.')
]
# Include the observed Claude Code audit sections as cross-item finding evidence.
findings[1]['evidenceIds'] += [data[x][1]['content']['evidenceId'] for x in guide_paths if 'claude-code' in x]
write('page-map.json',maps)
write('local-review-bundle.json',dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],
    parts=[dict(path=part,sourceSnapshotHash=idx['partSnapshotHashes'][part],bundle=dict(reviews=reviews,evidence=added,artifacts=artifacts,findings=findings))]))
