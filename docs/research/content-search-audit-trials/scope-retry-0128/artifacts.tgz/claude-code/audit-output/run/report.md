# Synthetic scenarios — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:36:35\.445Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 6bbbf528\-280f\-4dca\-b229\-68def03523f1\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |
| f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 94cc4d5510f8052035d4ce74cb83ccd424b85ae98b08b233027fe4a30606af89 | 8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4 | local\-file | 2026\-11\-16T13:36:35\.423Z | 0 full elapsed days | [evidence/8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4\.txt](evidence/8bc9bf6ff95dc59219e94b8b0108a9fdeb62aaa85115c42f72d4c9b746c6a4d4.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| f80c51210a2de5fef35d552aeb6744532460f980afd336a572e5442fb023cd96 | 94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd | local\-file | 2026\-11\-16T13:36:35\.424Z | 0 full elapsed days | [evidence/94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd\.txt](evidence/94e004add2d7da130118b3fc8a83e2f31c08601cc61026309a057b62ca0019fd.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c577589e668d7955b04eb2f9346b0ef409d54ac2becc5bd0453cd0c5403a38ee | 9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d | local\-file | 2026\-11\-16T13:36:35\.425Z | 0 full elapsed days | [evidence/9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d\.txt](evidence/9def295293d589a262e6d08d48b14c2c2f11b8868dd1bc4003c52985a251b66d.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 06296c793f8a81ee75b6fa7894ba766b10e56ea804748469c587fb0d6800cf5a | f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b | local\-file | 2026\-11\-16T13:36:35\.426Z | 0 full elapsed days | [evidence/f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b\.txt](evidence/f48ace3de0ee9d180cd7155127ef62820dbc275f5ff0da2fa5d62bc579241b7b.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
