# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:37:37\.505Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 67ca58b4\-6960\-4cc9\-8038\-909bca711a2a\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | Fir SSO denial contradicts the supplied documentation | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Replace the denial with Enterprise SAML SSO and its 20\-paid\-seat minimum\. Leave other\-plan availability unspecified\. | Compare the revised statement with lines 12–14, including the seat minimum\. | Comparison editor | Small copy or reporting revision | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e, 803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008, dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf |
| F3 | October cost per conversion mixes reporting windows | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Remove the full\-month rate and retain the October 1–7 matched\-window result\. | Check date filters and completed\-conversion definition, then divide USD 700 by 35\. Require complete matched October input rows for a monthly result\. | Campaign reporting owner | Small copy or reporting revision | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f, 1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9 |
| F5 | South service page repeats North eligibility | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence, portfolio\-contradictions | quality, aio, aeo, portfolio | high | high | observed | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Replace South’s copied eligibility passage with South’s next\-business\-day\-only policy\. Retain both current pages and the labeled archive\. | Compare each region passage against the approved current policy and verify the archive label and links for new orders\. | Service policy owner | Small copy or reporting revision | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91, bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645, 0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd, 0379f199683f0f9123711324b829adcc9106ae1b896005e0e24381701bf5d765 |
| F6 | Onboarding guarantee exceeds the supplied study evidence | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Replace the guarantee with the 15\-minute median for the 20 observed onboarding sessions\. | Check the study population and median against the approved record and verify that the draft contains no universal deadline or guarantee\. | Product copy owner | Small copy or reporting revision | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d, 7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3 |
| F2 | Universal Cedar price advantage contradicts annual rates | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | medium | high | observed | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Present monthly billing and annual equivalents separately for the November 2026 US comparison\. | Recompute each per\-seat comparison against lines 3–10 and verify cadence, tax and optional service scope\. | Comparison editor | Small copy or reporting revision | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e, 803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008, dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf |
| F4 | Tracked AI referrals are extrapolated without support | quality\-claims | quality | medium | high | observed | d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | update | reviewer\-proposal | The supplied evidence supports a specific correction to the draft\. | Report 15 October sessions with an identified AI\-assistant referrer\. Leave total AI\-generated sessions unestimated\. | Reconcile the tracked count to attribution rows and require a scope\-matched validated tracking\-rate study before extrapolating\. | Referral reporting owner | Small copy or reporting revision | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f, 1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9 |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 4 | 8 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 1 | 15 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | pending | Snapshot review incomplete | 26 |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | pending | Snapshot review incomplete | 26 |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | pending | Snapshot review incomplete | 26 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | quality\-claims | quality | fail | F1 Fir SSO denial contradicts the supplied documentation\. F2 Universal Cedar price advantage contradicts annual rates\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008, b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 45077a7582e2dbad5e6ce48d6855b3e25b1d6dc027bbaaa2ca9b01497bee1766 |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aio\-entity\-consistency | aio | fail | F1 Fir SSO denial contradicts the supplied documentation\. F2 Universal Cedar price advantage contradicts annual rates\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e, dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | aeo\-answer\-evidence | aeo | fail | F1 Fir SSO denial contradicts the supplied documentation\. F2 Universal Cedar price advantage contradicts annual rates\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008, b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | quality\-claims | quality | fail | F6 Onboarding guarantee exceeds the supplied study evidence\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d, 7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3 |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | dfcd32fcf1c64e6c5c6df0baa9d0cccaca4c9bf4009115471655c5ee15a29dea |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | aeo\-answer\-evidence | aeo | fail | F6 Onboarding guarantee exceeds the supplied study evidence\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d, 7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3 |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | quality\-claims | quality | fail | F3 October cost per conversion mixes reporting windows\. F4 Tracked AI referrals are extrapolated without support\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f, 1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9 |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 2f6a182f1ffa5be486919442437f7f079e3adea13f51b337958f2d7acf7c9d27 |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | aeo\-answer\-evidence | aeo | fail | F3 October cost per conversion mixes reporting windows\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f, 1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9 |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | quality\-claims | quality | fail | F5 South service page repeats North eligibility\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91, bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 05d5ab4ee0b986580d5a162efaa16752cd9ccf2361e250cb20a7a201e8c0c9e2 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aio\-entity\-consistency | aio | fail | F5 South service page repeats North eligibility\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd, 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | aeo\-answer\-evidence | aeo | fail | F5 South service page repeats North eligibility\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91, bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | portfolio\-contradictions | portfolio | fail | F5 South service page repeats North eligibility\. See the scenario component findings\. Supported passages retain their bounded conclusions\. | 0379f199683f0f9123711324b829adcc9106ae1b896005e0e24381701bf5d765, 0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd, 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |
| f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| b41322b7fa85686859f22bee0f6adcf8dac757a766a629d814a0bcf22c5bcb0e | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | local\-file | 2026\-11\-16T13:36:47\.013Z | 0 full elapsed days | [evidence/18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6\.txt](evidence/18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 42ae6dac4be7f6de9acfdcddb767c272452464eb1ef61f6f2411f79a49ce1c1d | 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | local\-file | 2026\-11\-16T13:36:47\.014Z | 0 full elapsed days | [evidence/68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331\.txt](evidence/68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 10c93dd4d680ac41ac3b2fc6e34051d2799d285ab99bfc16a2a72373ef44212f | d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | local\-file | 2026\-11\-16T13:36:47\.015Z | 0 full elapsed days | [evidence/d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769\.txt](evidence/d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 943de157e173b01ae7ac03a74fa1b814ac07a0b825787ee98259ad201471ec91 | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | local\-file | 2026\-11\-16T13:36:47\.016Z | 0 full elapsed days | [evidence/f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2\.txt](evidence/f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 45077a7582e2dbad5e6ce48d6855b3e25b1d6dc027bbaaa2ca9b01497bee1766 | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/45077a7582e2dbad5e6ce48d6855b3e25b1d6dc027bbaaa2ca9b01497bee1766\.txt](evidence/45077a7582e2dbad5e6ce48d6855b3e25b1d6dc027bbaaa2ca9b01497bee1766.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008 | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008\.txt](evidence/803df3a9a892afb77c02dd8f94ca47a2f6c3931fe7ee405e45c879d6b7f4d008.txt) | 658452583dbf5ddd4076ccf73f235a54072ce859ff1e8d57e5ed46fc11102b5a | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf | 18e01a42f7c129b39d002dc38c7f48cdbb22142e01c2cd7db3bd1d90d793c3c6 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf\.txt](evidence/dfe501ef43a2933b4d6ada284bc4810331fbdbc927f5c90cc356ed5ecd1dcbaf.txt) | 658452583dbf5ddd4076ccf73f235a54072ce859ff1e8d57e5ed46fc11102b5a | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| dfcd32fcf1c64e6c5c6df0baa9d0cccaca4c9bf4009115471655c5ee15a29dea | 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/dfcd32fcf1c64e6c5c6df0baa9d0cccaca4c9bf4009115471655c5ee15a29dea\.txt](evidence/dfcd32fcf1c64e6c5c6df0baa9d0cccaca4c9bf4009115471655c5ee15a29dea.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3 | 68ba812ca5b662e2b332e8bf46ca082bfb05d65b9264a7f465cd5f1d310f7331 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3\.txt](evidence/7b870f62990ef1e64d2d28b2ad24572fdd3c2cfbd59e2016849fb0777a73d3b3.txt) | 61b379785bf8e0c23f6c8d18aa9098af5f27626f9eeda085ae35299958976ac3 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 2f6a182f1ffa5be486919442437f7f079e3adea13f51b337958f2d7acf7c9d27 | d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/2f6a182f1ffa5be486919442437f7f079e3adea13f51b337958f2d7acf7c9d27\.txt](evidence/2f6a182f1ffa5be486919442437f7f079e3adea13f51b337958f2d7acf7c9d27.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9 | d556d992fa06c39f23a10af449de04b5860f7f18738141d920f3555c42f19769 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9\.txt](evidence/1cfa39c7b6e3ad2c273aca8e77a2128b119d3d329027761a8ce381787b8aede9.txt) | 050857f05e973916380f026a4907cc675a60a8828666ec0af614ea163c282f7c | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 05d5ab4ee0b986580d5a162efaa16752cd9ccf2361e250cb20a7a201e8c0c9e2 | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | identity extraction of readable UTF\-8 Markdown | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/05d5ab4ee0b986580d5a162efaa16752cd9ccf2361e250cb20a7a201e8c0c9e2\.txt](evidence/05d5ab4ee0b986580d5a162efaa16752cd9ccf2361e250cb20a7a201e8c0c9e2.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645 | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645\.txt](evidence/bc5a841ee054236296f3940d73b84aacbd6c30a4ef3f57fd9c132f7926892645.txt) | 7a772e25520165a0f822f84e2009a1b078c625ef245d9bdb2000f841070ca40a | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd\.txt](evidence/0e7c56ae3e9294946094f6794a7ac9894c170f63f4c9cf6baaff973be17a95fd.txt) | ccf7ed57930a88171bce0fb2dc74301e68e7feeb92b3e27e734cbd42bc65b2c2 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |
| 0379f199683f0f9123711324b829adcc9106ae1b896005e0e24381701bf5d765 | f901f31b221851b013f7ef0186333854b56a804f1e239f570e84ef9e2a1784d2 | attributed excerpt of supplied synthetic dossier | 2026\-11\-16T13:37:37\.397Z | 0 full elapsed days | [evidence/0379f199683f0f9123711324b829adcc9106ae1b896005e0e24381701bf5d765\.txt](evidence/0379f199683f0f9123711324b829adcc9106ae1b896005e0e24381701bf5d765.txt) | 5ebbb25fb8a21bca16ba46e84eb9ecd295739f96f0ca6d2b945200c2f5055168 | Synthetic local dossier\. Owner\-supplied comparison evidence only\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
