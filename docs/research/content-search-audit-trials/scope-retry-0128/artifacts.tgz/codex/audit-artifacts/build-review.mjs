import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const hash = text => createHash('sha256').update(text).digest('hex');
const now = new Date().toISOString();
const sources = fs.readFileSync('audit-artifacts/initial/evidence.jsonl','utf8').trim().split('\n').map(JSON.parse);
const registry = JSON.parse(fs.readFileSync('.agents/skills/content-search-audit/rules/core.json')).rules;
const bundle = {reviews:[], evidence:[], artifacts:{}, findings:[]};
const definitions = [
  ['F1',1,'Fir SSO denial contradicts the supplied documentation','high','Comparison editor','Replace the denial with Enterprise SAML SSO and its 20-paid-seat minimum. Leave other-plan availability unspecified.','Compare the revised statement with lines 12–14, including the seat minimum.'],
  ['F2',1,'Universal Cedar price advantage contradicts annual rates','medium','Comparison editor','Present monthly billing and annual equivalents separately for the November 2026 US comparison.','Recompute each per-seat comparison against lines 3–10 and verify cadence, tax and optional service scope.'],
  ['F3',2,'October cost per conversion mixes reporting windows','high','Campaign reporting owner','Remove the full-month rate and retain the October 1–7 matched-window result.','Check date filters and completed-conversion definition, then divide USD 700 by 35. Require complete matched October input rows for a monthly result.'],
  ['F4',2,'Tracked AI referrals are extrapolated without support','medium','Referral reporting owner','Report 15 October sessions with an identified AI-assistant referrer. Leave total AI-generated sessions unestimated.','Reconcile the tracked count to attribution rows and require a scope-matched validated tracking-rate study before extrapolating.'],
  ['F5',3,'South service page repeats North eligibility','high','Service policy owner','Replace South’s copied eligibility passage with South’s next-business-day-only policy. Retain both current pages and the labeled archive.','Compare each region passage against the approved current policy and verify the archive label and links for new orders.'],
  ['F6',4,'Onboarding guarantee exceeds the supplied study evidence','high','Product copy owner','Replace the guarantee with the 15-minute median for the 20 observed onboarding sessions.','Check the study population and median against the approved record and verify that the draft contains no universal deadline or guarantee.']
];
const detail = {
  1:{claims:[3,14], entity:[3,14], rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence']},
  2:{claims:[3,21], rules:['quality-claims','aeo-answer-evidence']},
  3:{claims:[3,16], entity:[4,16], map:[3,20], rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence','portfolio-contradictions']},
  4:{claims:[3,13], rules:['quality-claims','aeo-answer-evidence']}
};
for (const source of sources) {
  const n = Number(path.basename(source.locator).slice(0,2));
  const cfg = detail[n];
  const ids = {content:source.evidenceId};
  function derive(kind,start,end) {
    const value = source.value.split('\n').slice(start-1,end).join('\n');
    const evidenceId = hash(source.itemId+kind);
    const artifact = 'evidence/'+evidenceId+'.txt';
    bundle.artifacts[artifact] = value;
    bundle.evidence.push({itemId:source.itemId,evidenceId,kind,value,artifact,encoding:'utf8',method:kind==='extracted-text'?'identity extraction of readable UTF-8 Markdown':'attributed excerpt of supplied synthetic dossier',collectedAt:now,locator:source.locator+':'+start+'-'+end,snapshotHash:hash(value),byteLength:Buffer.byteLength(value),redaction:'none',sourceEvidenceIds:[source.evidenceId],limitations:['Synthetic local dossier. Owner-supplied comparison evidence only.']});
    ids[kind]=evidenceId;
  }
  const lines = source.value.split('\n').length;
  derive('extracted-text',1,lines);
  derive('claim-sources',...cfg.claims);
  if (cfg.entity) derive('entity-record',...cfg.entity);
  if (cfg.map) derive('inventory-map',...cfg.map);
  const scenarios = definitions.filter(x=>x[1]===n);
  const failed = cfg.rules.map(ruleId=>registry.find(rule=>rule.ruleId===ruleId));
  for (const rule of failed) {
    const applicable = n===2 && rule.ruleId==='aeo-answer-evidence' ? scenarios.filter(x=>x[0]==='F3') : scenarios;
    const reason = applicable.map(([id,,title])=>id+' '+title).join('. ') + '. See the scenario component findings. Supported passages retain their bounded conclusions.';
    bundle.reviews.push({itemId:source.itemId,ruleId:rule.ruleId,status:'fail',reason,evidenceIds:rule.requiredEvidence.map(kind=>ids[kind]),reviewer:'Codex offline dossier review',reviewedAt:now});
  }
  for (const [findingId,,title,severity,ownerRole,remediation,verification] of scenarios) {
    const rules = findingId==='F4' ? failed.filter(rule=>rule.ruleId==='quality-claims') : failed;
    bundle.findings.push({findingId,title,severity,ownerRole,remediation,verification,effort:'Small copy or reporting revision',classification:'observed',confidence:'high',action:'update',actionReason:'The supplied evidence supports a specific correction to the draft.',affectedItemIds:[source.itemId],ruleIds:rules.map(rule=>rule.ruleId),dimensions:[...new Set(rules.map(rule=>rule.dimension))],evidenceIds:[...new Set(rules.flatMap(rule=>rule.requiredEvidence.map(kind=>ids[kind])))]});
  }
}
fs.writeFileSync('audit-artifacts/review.json',JSON.stringify(bundle,null,2));
