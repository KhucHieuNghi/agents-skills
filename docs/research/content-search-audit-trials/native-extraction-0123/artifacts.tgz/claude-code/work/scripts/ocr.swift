import PDFKit
import Vision
import AppKit
let d = PDFDocument(url: URL(fileURLWithPath: CommandLine.arguments[1]))!
let p = d.page(at: 0)!
let b = p.bounds(for: .mediaBox)
let img = p.thumbnail(of: CGSize(width: b.width*3, height: b.height*3), for: .mediaBox)
if let t = img.tiffRepresentation, let r = NSBitmapImageRep(data: t), let png = r.representation(using: .png, properties: [:]) { try! png.write(to: URL(fileURLWithPath: CommandLine.arguments[2])) }
var cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil)!
let req = VNRecognizeTextRequest()
req.recognitionLanguages = ["en-US","vi-VN"]
req.recognitionLevel = .accurate
try! VNImageRequestHandler(cgImage: cg).perform([req])
for o in req.results ?? [] { print(o.topCandidates(1)[0].string, o.topCandidates(1)[0].confidence) }
print("done")
