import fs from 'node:fs'; import crypto from 'node:crypto';
const P=process.argv[2]; const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const now=new Date().toISOString();
const ids={html:'c161d122473257fbc248e8963fed28567f504c92d1aff810ae09898a6070f4fc',doc:'51f598ed4e88027b1854e4c52df463b1a2ac86feb160e42cc50a07139cfca5db',img:'34fb175cc7707cca11ece4691336572b9caf747b9cbe83e61d0fb0cc5ffe8cb1'};
const htmlContentEv='1053a40933e5f185aa86871cd968121cc698f5263a555e16f7c6cecead5e531d';
const evidence=[], artifacts={}, recoveries=[];
function add(o){const v=typeof o.value==='string'?o.value:JSON.stringify(o.value);const enc=typeof o.value==='string'?'utf8':'json';
 artifacts[o.artifact]=v; evidence.push({redaction:'none; controlled authored fixture',collectedAt:now,encoding:enc,snapshotHash:sha(Buffer.from(v,'utf8')),byteLength:Buffer.byteLength(v),...o});}
// HTML rendered DOM
const dom=fs.readFileSync(P+'/work/extract/render.dom.html','utf8');
add({evidenceId:'ev-html-rendered-dom',itemId:ids.html,kind:'rendered-dom',method:'chrome-headless-dump-dom',locator:P+'/targets/render.html#rendered-dom after data-audit-ready=true',sourceEvidenceIds:[htmlContentEv],artifact:'evidence/html-rendered-dom.html.txt',value:dom,
 limitations:['Google Chrome 157.0.8103.51 headless, fresh isolated profile, --virtual-time-budget=3000 on file:// URL; single capture','dataset.auditReady===true observed in DOM serialization (data-audit-ready="true"); owner states this means rendering finished','Local export only: no public HTTP, index or search-engine rendering evidence']});
// PDFs
function pdf(key,file,jsonFile,extractor,method,lims,pagesOverride){
 const j=JSON.parse(fs.readFileSync(P+'/work/extract/'+jsonFile,'utf8')); const pages=(pagesOverride||j.pages).map((t,i)=>({page:i+1,text:t}));
 const bytes=fs.readFileSync(P+'/targets/'+file); const joined=pages.map(p=>p.text).join('\f');
 const m={schemaVersion:1,sourceSha256:sha(bytes),sourceByteLength:bytes.length,extractor,pageCount:pages.length,pages,coverage:'complete',limitations:lims};
 const mid=`ev-${key}-manifest`,cid=`ev-${key}-content`,tid=`ev-${key}-text`;
 const common={itemId:ids[key],method,locator:P+'/targets/'+file,limitations:lims};
 add({...common,evidenceId:mid,kind:'extraction-provenance',sourceEvidenceIds:[],artifact:`evidence/${key}-extraction-manifest.json`,value:JSON.stringify(m)});
 evidence[evidence.length-1].encoding='json'; evidence[evidence.length-1].value=m;
 add({...common,evidenceId:cid,kind:'content',sourceEvidenceIds:[mid],artifact:`evidence/${key}-content.txt`,value:joined});
 add({...common,evidenceId:tid,kind:'extracted-text',sourceEvidenceIds:[cid],artifact:`evidence/${key}-extracted-text.txt`,value:joined});
 recoveries.push({itemId:ids[key],manifestEvidenceId:mid,contentEvidenceId:cid,textEvidenceId:tid,reviewer:'Claude agent (Sonnet 5.5) acting for audit owner',reviewedAt:now,reason:`${pages.length} page(s) recovered via ${extractor.name}; ${lims.join(' ')}`});
}
pdf('doc','document.pdf','document.json',{name:'Apple PDFKit PDFPage.string (Swift)',version:'macOS 26.3'},'pdfkit-text-layer',['Text-layer extraction; reading order and fidelity were reviewed only by reading the 2 extracted pages.','Page 1 is English and page 2 is Vietnamese.']);
const ocr=JSON.parse(fs.readFileSync(P+'/work/extract/image-only.json','utf8'));
pdf('img','image-only.pdf','image-only.json',{name:'Apple Vision VNRecognizeTextRequest accurate (Swift), via PDFKit page render at 3x',version:'macOS 26.3'},'vision-ocr',['PDFKit text layer is empty (0 characters), so the text is OCR output, not a native text layer.','OCR output (one line, confidence 1.0) was checked by eye against a rendered image of page 1; other fonts, colours or hidden image content were not examined.'],['Image-only document: a separate OCR capability is needed.']);
const reviews=[{itemId:ids.html,ruleId:'seo-rendering',status:'fail',reason:'Raw source text of #task is "Open Billing. Select Disable renewal." but after the script runs (data-audit-ready=true) the rendered #task is "Open Billing." The second instruction sentence is absent from the rendered DOM.',evidenceIds:[htmlContentEv,'ev-html-rendered-dom'],reviewer:'Claude agent (Sonnet 5.5) acting for audit owner',reviewedAt:now}];
const findings=[{findingId:'F-001',title:'Rendered page drops the "Select Disable renewal." step present in the HTML source',affectedItemIds:[ids.html],ruleIds:['seo-rendering'],dimensions:['seo'],evidenceIds:[htmlContentEv,'ev-html-rendered-dom'],severity:'medium',confidence:'high',classification:'observed',
 remediation:'Owner to decide the intended text. The approved task is "Open Billing" then "Select Disable renewal", so remove or fix the script that overwrites #task with only "Open Billing." (render.html inline setTimeout), or confirm the shortened text is deliberate. No source change was made by this audit.',
 verification:'Re-run an isolated-profile Chrome dump of the page after dataset.auditReady==="true" and confirm #task contains both sentences; compare with raw source.',ownerRole:'Content/web engineer',effort:'low',action:'update',actionReason:'Observed raw-versus-rendered mismatch omits an approved task step.'}];
fs.writeFileSync(P+'/work/review-1.json',JSON.stringify({reviews,evidence,artifacts,findings,collectionRecoveries:recoveries},null,1));
console.log(evidence.length,'evidence');
