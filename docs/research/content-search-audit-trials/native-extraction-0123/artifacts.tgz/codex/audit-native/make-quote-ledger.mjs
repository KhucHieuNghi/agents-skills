import fs from 'node:fs';
import {createHash} from 'node:crypto';
const report='audit-native/audit-narrative.md';
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const reportLines=fs.readFileSync(report,'utf8').split('\n');
const quotes=[
  ['renewal','targets/render.html','render.html',1,1,'Open Billing. Select Disable renewal.'],
  ['policy-en','audit-native/reviewed/evidence/policy-content.txt','policy-content.txt',2,3,'A single export contains at most 5000 records. Applies to current VN plans.'],
  ['policy-vi','audit-native/reviewed/evidence/policy-content.txt','policy-content.txt',4,5,'Mỗi lần xuất tối đa 5000 bản ghi. Không cần thanh toán thêm.'],
].map(([quoteId,source,sourceLabel,startLine,endLine,quote])=>{
  const line=reportLines.findIndex(s=>s.includes(quote))+1;
  return {quoteId,source,sourceLabel,sourceHash:hash(source),startLine,endLine,reportStartLine:line,reportEndLine:line,normalization:'whitespace',quote};
});
fs.writeFileSync('audit-native/quote-ledger.json',JSON.stringify({root:fs.realpathSync('.'),report,reportHash:hash(report),quotes},null,2)+'\n');
