import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {basename} from 'node:path';
const root='audit-native/';
const read=(p)=>fs.readFileSync(p,'utf8');
const hash=(s)=>createHash('sha256').update(s).digest('hex');
const readJSON=(p)=>JSON.parse(read(root+p));
const records=(p)=>read(root+p).trim().split('\n').map(JSON.parse);
const inv=records('initial/inventory.jsonl');
const item=(name)=>inv.find(i=>basename(i.path)===name);
const html=item('render.html'), doc=item('document.pdf'), image=item('image-only.pdf');
const raw=records('initial/evidence.jsonl')[0].evidenceId;
const registry=JSON.parse(read('.agents/skills/content-search-audit/rules/core.json')).rules;
const now=new Date().toISOString(), reviewer='Codex local fixture audit';
const extraction={reviews:[],evidence:[],artifacts:{},collectionRecoveries:[]};
const semantic={reviews:[],evidence:[],artifacts:{},findings:[]};
function evidence(bundle,i,id,kind,value,method,deps=[],limits=[],locator=i.path,collectedAt=now){
  const encoding=typeof value==='string'?'utf8':'json';
  const artifact='evidence/'+id+(encoding==='json'?'.json':'.txt');
  const bytes=encoding==='json'?JSON.stringify(value,null,2)+'\n':value;
  bundle.artifacts[artifact]=bytes;
  bundle.evidence.push({evidenceId:id,itemId:i.itemId,kind,value,method,sourceEvidenceIds:deps,limitations:limits,locator,collectedAt,encoding,artifact,snapshotHash:hash(bytes),byteLength:Buffer.byteLength(bytes),redaction:'none; controlled local fixture or supplied context'});
  return id;
}
function recover(i,key,pages,extractor,limitations,deps=[]){
  const buf=fs.readFileSync(i.path);
  const m=evidence(extraction,i,key+'-manifest','extraction-provenance',{schemaVersion:1,sourceSha256:hash(buf),sourceByteLength:buf.length,extractor,pageCount:pages.length,pages,coverage:'complete',limitations},extractor.name,deps,limitations);
  const text=pages.map(p=>p.text).join('\f');
  const c=evidence(extraction,i,key+'-content','content',text,extractor.name,[m],limitations);
  const t=evidence(extraction,i,key+'-text','extracted-text',text,extractor.name,[c],limitations);
  extraction.collectionRecoveries.push({itemId:i.itemId,manifestEvidenceId:m,contentEvidenceId:c,textEvidenceId:t,reviewer,reviewedAt:now,reason:limitations.join(' ')});
  return c;
}
const d=readJSON('document-pdfkit.json'), im=readJSON('image-only-pdfkit.json');
const dc=recover(doc,'policy',d.pages,d.extractor,['PDFKit returned nonempty text for both pages in page order. This is text-layer recovery. Page geometry and accessibility tags were not verified.']);
const ocrText=read(root+'image-only-tesseract.txt').trimEnd();
if(ocrText!=='Image-only document: a separate OCR capability is needed.') throw Error('OCR and page image differ');
const nativeAttempt=evidence(extraction,image,'image-native-attempt','extraction-attempt',{...im,sourceSha256:hash(fs.readFileSync(image.path)),pageImageSha256:hash(fs.readFileSync(root+'image-only-page-1.png')),visionResult:'Failed with Foundation._GenericObjCError.nilError; no OCR output'},'Apple PDFKit; Apple Vision attempt',[],['An empty native extraction does not imply empty source content.']);
const ic=recover(image,'scan',[{page:1,text:ocrText}],{name:'Tesseract OCR over Apple PDFKit page raster',version:read(root+'tesseract-version.txt').split('\n')[0]+' / PDFKit '+im.extractor.version},['OCR matched the only visible sentence on the sole page in a manual comparison to the retained page raster. OCR recovers a transcript and does not add a selectable text layer to the source or establish PDF accessibility.'],[nativeAttempt]);
const replay=readJSON('fixture-replay.json');
const hr=evidence(extraction,html,'renewal-script-replay','script-replay',replay,'Node VM with minimal document and timer stubs',[raw],[replay.limitations],html.path+' inline script',replay.capturedAt);
const htxt=evidence(extraction,html,'renewal-source-task-text','extracted-text',replay.initial,'Exact text of source main#task',[raw],['Source text before script execution. Excludes script content and does not measure rendered output.'],html.path+' main#task');
const owner='Owner-supplied instructions in this audit request';
const renew=['Open Billing','Select Disable renewal'];
const aud=evidence(semantic,html,'renewal-audience','audience-context',{task:renew,readySignal:"document.documentElement.dataset.auditReady === 'true'",meaning:'Owner confirms content has finished rendering'},owner,[],[],owner);
const hq=evidence(semantic,html,'renewal-question','question-set',{question:'How do I disable renewal?',basis:'Owner-approved task',approvedSteps:renew},'Task wording derived from owner instructions',[aud]);
const approved={market:'VN',scope:'current plans',maximumRecordsPerExport:5000,extraCharge:false};
const claims=evidence(semantic,doc,'policy-approved','claim-sources',approved,owner,[],['Current at audit intake as stated by owner. No historical or other-market claims assessed.'],owner);
const pa=evidence(semantic,doc,'policy-audience','audience-context',{task:'Find the cap and charges for an export on a current VN plan',basis:'Owner-approved policy and document topic'},'Task interpretation',[claims,dc]);
const pq=evidence(semantic,doc,'policy-questions','question-set',{question:'What is the export limit for current VN plans, and is there an extra charge?',basis:'Owner-supplied policy and page text'},'Task wording derived from owner instructions',[pa]);
const ent=evidence(semantic,doc,'policy-entity','entity-record',approved,'Owner-approved export policy',[claims]);
const map=evidence(semantic,doc,'inventory-task-map','inventory-map',{items:[{file:'render.html',task:'Disable renewal',lang:'en'},{file:'document.pdf',task:'Understand export policy',lang:['en','vi']},{file:'image-only.pdf',task:'Illustrate an image-only source and need for OCR',lang:'en'}],localePolicy:'Different emphasis is permitted; no complete-translation requirement.'},'Review of three declared captures and owner locale instructions',[hr,dc,ic]);
const hmedia=evidence(semantic,html,'renewal-media','media-inventory',{informativeMedia:[],surface:'Raw fixture and inspected script'},'Source review',[raw]);
const ham=evidence(semantic,html,'renewal-local-schema','schema-extraction',{found:[],surface:'Raw source and inspected inline script'},'Local source inspection',[raw,hr],['No live feature eligibility evidence.']);
const media=evidence(semantic,image,'scan-text-equivalent','media-inventory',{informativeMedia:'One raster page with text',nativeText:'PDFKit returned empty text',externalEquivalent:'Local audit OCR transcript'},'Visual review, PDFKit and Tesseract',[nativeAttempt,ic],['PDF tags, reading order in assistive technology and any separately published accessible version were not verified.']);
function check(i,ruleId,status,reason,...evidenceIds){
  semantic.reviews.push({itemId:i.itemId,ruleId,status,reason,evidenceIds,reviewer,reviewedAt:now});
}
function finding(i,findingId,title,ruleIds,evidenceIds,remediation,verification,actionReason,severity='medium'){
  semantic.findings.push({findingId,title,ruleIds,dimensions:[...new Set(ruleIds.map(id=>registry.find(r=>r.ruleId===id).dimension))],affectedItemIds:[i.itemId],evidenceIds,classification:'observed',severity,confidence:'high',remediation,verification,ownerRole:'Fixture maintainer',effort:'Small',action:'update',actionReason});
}
const lost='The initial task includes both approved actions. The fixture callback overwrites the main text with only the Billing step immediately before setting auditReady. A bounded replay confirms this transition. Browser output was unavailable.';
const htmlFails=['quality-task-fit','aio-retrievable-facts','aeo-question-coverage','aeo-answer-context'];
for(const id of htmlFails) check(html,id,'fail',lost,raw,hr,aud,hq);
finding(html,'renewal-step-overwritten','Renewal script removes the action needed to disable renewal',htmlFails,[raw,hr,aud,hq],'Preserve both approved steps in main#task after the callback sets the ready signal.','Load the fixture in a fresh isolated local browser, wait for auditReady to be true and assert that visible task text gives both actions in order. Also repeat the script replay.','The missing second action prevents completion of the approved renewal task.');
check(html,'seo-rendering','unknown','Chrome produced no DOM and the WebKit attempt did not return a ready snapshot. Replay verifies the script mutation only.',raw,hr);
check(html,'quality-accessible-media','not-applicable','The fixture task is plain text with no informative media in the source or script.',raw,hmedia);
check(html,'seo-structured-data','not-applicable','This controlled local task fixture contains no structured markup requiring consistency review. Search feature eligibility remains unknown.',raw,ham);
check(html,'quality-claims','pass','The source task gives the two steps approved by the owner. The runtime mutation is recorded under task and answer checks.',raw,evidence(semantic,html,'renewal-approved-steps','claim-sources',{steps:renew},owner,[aud],[],owner));
const docGood='English page 1 states the 5000-record per-export cap and current VN scope. Vietnamese page 2 repeats the same cap and states there is no extra charge. Both agree with the owner policy. Different page emphasis is permitted.';
for(const id of ['quality-claims','quality-freshness','aeo-answer-evidence']) check(doc,id,'pass',docGood,dc,claims);
for(const id of ['quality-task-fit','aio-retrievable-facts']) check(doc,id,'pass',docGood+' This assessment covers the document as a whole.',dc,pa);
for(const id of ['aeo-question-coverage','aeo-answer-context']) check(doc,id,'pass',docGood+' Both pages together answer the scoped policy question.',dc,pq);
check(doc,'aio-entity-consistency','pass',docGood,dc,ent);
check(doc,'portfolio-duplication','pass','Both pages intentionally cover the same policy in different languages and emphasize complementary details. The three-item comparison also finds distinct renewal and OCR fixture purposes.',dc,map);
check(doc,'portfolio-contradictions','pass','The two policy pages agree on the cap and add compatible scope and fee details. The other two fixtures make no competing export claim.',dc,ent,map);
check(doc,'seo-rendering','not-applicable','The review surface is the supplied PDF with readable page text and no declared JavaScript page counterpart. Public viewer and search-engine behavior are unobserved.',dc);
check(image,'quality-accessible-media','unknown','An audit OCR transcript exists. PDFKit found no embedded selectable text and the raster contains substantive text. Accessible tags and assistive-technology behavior were not established.',ic,media);
check(image,'seo-rendering','not-applicable','The review surface is the supplied one-page raster PDF with no declared JavaScript page counterpart. Public delivery remains unobserved.',ic);
check(image,'quality-task-fit','pass','The visible sentence serves the local fixture purpose of demonstrating image-only content that requires separate extraction.',ic,evidence(semantic,image,'scan-purpose','audience-context',{task:'Demonstrate an image-only extraction case',basis:'Controlled fixture designation and visible page sentence'},'Inferred from supplied context and visual comparison',[ic]));
for(const i of [html,doc,image]){
  const ref=i===html?raw:i===doc?dc:ic;
  for(const r of registry) {
    if(semantic.reviews.some(x=>x.itemId===i.itemId&&x.ruleId===r.ruleId)||r.ruleId==='quality-readable-text') continue;
    let reason;
    if(r.dimension.toLowerCase()==='geo') reason='No AI response observations, claim adjudications or cohort evidence were supplied.';
    else if(['seo-response','seo-index-controls','seo-canonical','seo-internal-links','seo-locales','aio-crawler-policy','portfolio-journey-links'].includes(r.ruleId)) reason='The declared inventory is local. No public serving, publisher control, link graph or deployed relationship evidence was supplied for this check.';
    else if(r.ruleId==='portfolio-task-gaps') reason='The three local purposes were mapped. Available tasks and fixtures do not establish broader audience demand or a complete deployed journey.';
    else if(r.ruleId==='seo-structured-data') reason='The recovered PDF text is insufficient to verify machine metadata or feature eligibility.';
    else if(r.ruleId==='seo-metadata') reason='Local visible labels were reviewed in context. No intended public title or search metadata package was supplied.';
    else reason='The captured fixture and supplied context do not establish the additional evidence required by this rule.';
    check(i,r.ruleId,'unknown',reason,ref);
  }
}
fs.writeFileSync(root+'extraction-review.json',JSON.stringify(extraction,null,2)+'\n');
fs.writeFileSync(root+'semantic-review.json',JSON.stringify(semantic,null,2)+'\n');
