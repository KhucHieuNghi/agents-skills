import Cocoa
import WebKit
let app = NSApplication.shared
let config = WKWebViewConfiguration()
config.websiteDataStore = .nonPersistent()
let view = WKWebView(frame: NSRect(x: 0, y: 0, width: 1024, height: 768), configuration: config)
let url = URL(fileURLWithPath: CommandLine.arguments[1])
view.loadFileURL(url, allowingReadAccessTo: url)
let timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
    view.evaluateJavaScript("document.documentElement?.dataset.auditReady === 'true' && ({ready:document.documentElement.dataset.auditReady,text:document.querySelector('main').innerText,dom:document.documentElement.outerHTML})") { result, _ in
        if let result = result as? [String: Any] {
            var capture = result
            capture["capturedAt"] = ISO8601DateFormatter().string(from: Date())
            capture["url"] = view.url?.absoluteString
            let data = try! JSONSerialization.data(withJSONObject: capture, options: [.sortedKeys,.prettyPrinted])
            try! data.write(to: URL(fileURLWithPath: "audit-native/webkit-capture.json"))
            exit(0)
        }
    }
}
DispatchQueue.main.asyncAfter(deadline: .now() + 10) { exit(1) }
app.run()
