import Foundation
import PDFKit
import AppKit
for path in CommandLine.arguments.dropFirst() {
    let url = URL(fileURLWithPath: path)
    guard let doc = PDFDocument(url: url) else { fatalError("Cannot open PDF") }
    let pages: [[String: Any]] = (0..<doc.pageCount).map { i in
        let page = doc.page(at: i)!
        let text = page.string ?? ""
        if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let image = page.thumbnail(of: NSSize(width: 1200, height: 1200), for: .mediaBox)
            if let tiff = image.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff) {
                try? bitmap.representation(using: .png, properties: [:])?.write(to: URL(fileURLWithPath: "audit-native/\(url.deletingPathExtension().lastPathComponent)-page-\(i+1).png"))
            }
        }
        return ["page": i+1, "text": text]
    }
    let framework = Bundle(for: PDFDocument.self)
    let result: [String: Any] = ["pageCount": doc.pageCount, "pages": pages, "extractor": ["name": "Apple PDFKit", "version": framework.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ProcessInfo.processInfo.operatingSystemVersionString], "os": ProcessInfo.processInfo.operatingSystemVersionString]
    let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
    try data.write(to: URL(fileURLWithPath: "audit-native/\(url.deletingPathExtension().lastPathComponent)-pdfkit.json"))
}
