import Foundation
import Vision
let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.recognitionLanguages = ["en-US"]
try VNImageRequestHandler(url: URL(fileURLWithPath: CommandLine.arguments[1])).perform([request])
let result = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }
let output: [String: Any] = ["revision": request.revision, "lines": result, "os": ProcessInfo.processInfo.operatingSystemVersionString]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys]))
