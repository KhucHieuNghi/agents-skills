import {spawn} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const chrome = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', [
  '--headless', '--remote-debugging-pipe', '--user-data-dir='+resolve('audit-native/chrome-profile'),
  '--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run',
  '--no-default-browser-check','--disable-extensions','--no-proxy-server',
  '--host-resolver-rules=MAP * ~NOTFOUND','--disable-breakpad','--no-pings','about:blank'
], {stdio:['ignore','ignore','inherit','pipe','pipe']});
let buffer='', id=0;
const pending=new Map();
let session;
chrome.stdio[4].on('data', chunk=>{
  buffer += chunk.toString();
  while(buffer.includes('\0')){
    const i=buffer.indexOf('\0'), msg=JSON.parse(buffer.slice(0,i)); buffer=buffer.slice(i+1);
    if(msg.method==='Fetch.requestPaused') {
      const allowed=msg.params.request.url===url;
      send(allowed?'Fetch.continueRequest':'Fetch.failRequest',allowed?{requestId:msg.params.requestId}:{requestId:msg.params.requestId,errorReason:'BlockedByClient'},session).catch(()=>{});
    }
    const p=pending.get(msg.id);
    if(p){ pending.delete(msg.id); msg.error?p.reject(Error(JSON.stringify(msg.error))):p.resolve(msg.result); }
  }
});
function send(method,params={},sessionId){
  return new Promise((resolve,reject)=>{
    const n=++id; pending.set(n,{resolve,reject});
    chrome.stdio[3].write(JSON.stringify({id:n,method,params,sessionId})+'\0');
  });
}
const url=pathToFileURL(resolve('targets/render.html')).href;
const timeout=setTimeout(()=>{ chrome.kill(); console.error('Chrome capture timed out'); process.exit(1); },18000);
try {
  const version=await send('Browser.getVersion');
  const {targetId}=await send('Target.createTarget',{url:'about:blank'});
  session=(await send('Target.attachToTarget',{targetId,flatten:true})).sessionId;
  await send('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]},session);
  const nav=await send('Page.navigate',{url},session);
  if(nav.errorText) throw Error(nav.errorText);
  for(let i=0;i<100;i++){
    const {result}=await send('Runtime.evaluate',{expression:`document.documentElement?.dataset.auditReady === 'true' && ({url:location.href, ready:document.documentElement.dataset.auditReady, text:document.querySelector('main').innerText, dom:document.documentElement.outerHTML})`,returnByValue:true},session);
    if(result.value?.url===url){
      writeFileSync('audit-native/chrome-capture.json',JSON.stringify({version,capturedAt:new Date().toISOString(),...result.value},null,2)+'\n');
      break;
    }
    if(i===99) throw Error('Owner-designated readiness signal not reached');
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  await send('Browser.close');
} finally { clearTimeout(timeout); chrome.kill(); chrome.stdio[3].destroy(); chrome.stdio[4].destroy(); }
