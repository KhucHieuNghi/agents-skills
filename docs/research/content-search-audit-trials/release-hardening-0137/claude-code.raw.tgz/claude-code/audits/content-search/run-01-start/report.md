# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:37:17\.979Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 2faa8ef0\-a6d5\-4761\-9ea2\-dae9f75054a3\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |
| eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 9e6223d6ed247d2694de1f1741016057667ffa7095326ebb8b83184530fb17d5 | 019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229 | local\-file | 2026\-11\-18T05:37:17\.954Z | 0 full elapsed days | [evidence/019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229\.txt](evidence/019ec44747bb1157015cca401d9d2b4e25f6a4d9853b52626e07dfb92333c229.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 7fcd198b7a9fdde42427eaf7d5d648f5834a2425b5fd42b9e7ad7f8ab901adbb | 14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673 | local\-file | 2026\-11\-18T05:37:17\.956Z | 0 full elapsed days | [evidence/14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673\.txt](evidence/14791d906fa00a12c35489fdca1efff72bd8a0508f25898b68fb91f669f2c673.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 86299a24f0bef4ae027dc6927b13fece9e6bd7a83f73f2bb39bb4009e04fde00 | 5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a | local\-file | 2026\-11\-18T05:37:17\.956Z | 0 full elapsed days | [evidence/5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a\.txt](evidence/5245fb94270222d670a9f9e92263c7afc10abbc44fb631c638b9eb7753927c1a.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8987c946763f18cfc372043cd0858a4bab9f026042c0d65dda0811e821337a2b | 5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9 | local\-file | 2026\-11\-18T05:37:17\.957Z | 0 full elapsed days | [evidence/5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9\.txt](evidence/5f68e4055d29d6ea90a1903e0ce3947f41339d070d43b5c747912c2bd4351af9.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| ddda2a962f1983e8e05823b957d7e0bdd44346d36d866dbaf7723b694d731b17 | a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52 | local\-file | 2026\-11\-18T05:37:17\.958Z | 0 full elapsed days | [evidence/a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52\.txt](evidence/a67090709c261360a69bfde4a811408dd2c3eba1436bd4223c737453c9cacf52.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| b3bd05cf12f17abf1a0d43ffa4d78b1063331a794632e48e85c59408bd0fa48d | c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13 | local\-file | 2026\-11\-18T05:37:17\.958Z | 0 full elapsed days | [evidence/c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13\.txt](evidence/c53d2403f55785702a292041773d8567b828d8f975d42a9396c3f69ba956ca13.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 813257b89008c184ceb712ca046ec44b9ea3e5034c069a77446a60de60e3c9c5 | cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5 | local\-file | 2026\-11\-18T05:37:17\.959Z | 0 full elapsed days | [evidence/cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5\.txt](evidence/cbbad4642c028e7974d8ad5c14fbf5bb0da266423368aed1939123024513aff5.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d09ecbed7dc06dc89c454a294c621ed3540c950138c1f9b3a0d2f691ab783304 | ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c | local\-file | 2026\-11\-18T05:37:17\.959Z | 0 full elapsed days | [evidence/ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c\.txt](evidence/ce138e410147167cfabc9445ac851bbb554683dd08f179778c2642fa8034c68c.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 60b90a615689b8e79265bba017b59e0985876477b98726309e337f577e99e465 | eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604 | local\-file | 2026\-11\-18T05:37:17\.960Z | 0 full elapsed days | [evidence/eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604\.txt](evidence/eaad7578f8fb2f8c99d75365fe06942e326739e021d06b67c8c49102cbf3c604.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4dd85deba1eb3be8d805b29d77d18dfdf0cd0fb15cb0dc0f90aa9b586383a8db | eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb | local\-file | 2026\-11\-18T05:37:17\.961Z | 0 full elapsed days | [evidence/eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb\.txt](evidence/eeb6526328cacf0a59da515b50eb2ce0c1974634f9ee5dae140de3a377144ebb.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
