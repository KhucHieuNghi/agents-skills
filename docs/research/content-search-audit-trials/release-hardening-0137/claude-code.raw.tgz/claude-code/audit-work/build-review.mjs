// Builds the review bundle for the ten supplied dossiers. Reads run artifacts only.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [runDir, outFile] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = (f) =>
  readFileSync(path.join(runDir, f), "utf8")
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
const inventory = lines("inventory.jsonl");
const evidence = lines("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "claude-fable-5-2 host review (content-search-audit)";

const item = {};
const snap = {};
for (const it of inventory) {
  if (!it.path) continue;
  const key = path.basename(it.path).slice(0, 2);
  item[key] = it.itemId;
  snap[key] = evidence.find(
    (e) => e.itemId === it.itemId && e.kind === "content",
  );
}

const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const ev = (key, name, kind, locator, value, limitations) => {
  const json = typeof value !== "string";
  const bytes = json ? JSON.stringify(value) : value;
  const evidenceId = `d${key}-${name}`;
  const artifact = `evidence/${evidenceId}.${json ? "json" : "txt"}`;
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({
    ...snap[key],
    evidenceId,
    kind,
    artifact,
    value,
    encoding: json ? "json" : "utf8",
    byteLength: Buffer.byteLength(bytes),
    snapshotHash: hash(bytes),
    collectedAt: now,
    method: "host-derived record from supplied dossier text",
    locator,
    sourceEvidenceIds: [snap[key].evidenceId],
    limitations: [
      "Derived from statements in the supplied synthetic dossier; not an independent capture or verification",
      ...limitations,
    ],
  });
  return evidenceId;
};
const review = (key, ruleId, status, reason, ids) =>
  bundle.reviews.push({
    itemId: item[key],
    ruleId,
    status,
    reason,
    evidenceIds: ids,
    reviewer,
    reviewedAt: now,
  });
const c = (key) => snap[key].evidenceId;

// ---- 01 visibility
{
  const http = ev(
    "01",
    "http",
    "http-response",
    "targets/01-visibility.md:4-5",
    {
      status: 200,
      url: "https://store.example.invalid/product",
      capturedAt: "2026-11-10T08:00:00Z",
      reportedHeaders: { "X-Robots-Tag": "noindex" },
    },
    [
      "Only the X-Robots-Tag header is reported; the full header set is not supplied",
    ],
  );
  const intent = ev(
    "01",
    "intent",
    "publisher-intent",
    "targets/01-visibility.md:3",
    "Dossier statement (01-visibility.md:3): Publisher intent: this public product page should be eligible for Google indexing.",
    ["Intent is stated for Google indexing only; other surfaces are not stated"],
  );
  const policy = ev(
    "01",
    "crawler-policy",
    "crawler-policy",
    "targets/01-visibility.md:5",
    "Dossier statement (01-visibility.md:5): Robots.txt permits Googlebot access to /product.",
    [
      "The robots.txt file itself is not supplied; rules for other user agents are unknown",
    ],
  );
  review(
    "01",
    "seo-index-controls",
    "fail",
    "Captured response header X-Robots-Tag: noindex conflicts with the stated intent that the page be eligible for Google indexing; the raw HTML meta robots says index,follow, so the two index directives disagree. Actual index status is not observed.",
    [c("01"), http, intent],
  );
  review(
    "01",
    "aio-crawler-policy",
    "pass",
    "For the only stated surface (Google indexing), the dossier reports robots.txt permits Googlebot access to /product, consistent with intent. Permission is not evidence of a fetch; other crawlers and surfaces are not stated.",
    [policy, intent],
  );
  review(
    "01",
    "seo-canonical",
    "unknown",
    "The captured rel=canonical equals the captured URL and no conflicting canonical is observed, but the full header set (HTTP Link), intended variants and any engine-selected canonical are not supplied.",
    [c("01")],
  );
  bundle.findings.push({
    findingId: "F-01-noindex-header",
    title:
      "Response header noindex contradicts the intent that /product be indexable",
    affectedItemIds: [item["01"]],
    ruleIds: ["seo-index-controls"],
    dimensions: ["seo"],
    evidenceIds: [c("01"), http, intent],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      "Proposal for a separate implementation task: stop sending X-Robots-Tag: noindex on https://store.example.invalid/product (find which server, CDN or application layer adds it), leaving the existing meta robots index,follow and self-referencing canonical unchanged.",
    verification:
      "Take a new capture of the same URL and inspect the complete response headers and raw HTML head: no noindex value in any X-Robots-Tag header or robots meta tag, status still 200, robots.txt still permitting Googlebot. Actual indexing must then be confirmed separately from index evidence, which is not supplied here.",
    ownerRole: "Web platform / technical SEO owner",
    effort: "small",
  });
}

// ---- 02 route
{
  const h1 = ev(
    "02",
    "http-old",
    "http-response",
    "targets/02-route.md:5",
    {
      status: 301,
      url: "https://store.example.invalid/old",
      location: "https://store.example.invalid/new",
    },
    ["Non-final redirect response; no capture timestamp is supplied"],
  );
  const h2 = ev(
    "02",
    "http-new",
    "http-response",
    "targets/02-route.md:6",
    {
      status: 301,
      url: "https://store.example.invalid/new",
      location: "https://store.example.invalid/old",
    },
    ["Non-final redirect response; no capture timestamp is supplied"],
  );
  const intent = ev(
    "02",
    "intent",
    "publisher-intent",
    "targets/02-route.md:3",
    "Dossier statement (02-route.md:3): Publisher intent: /old should redirect once to an accessible /new product page.",
    [],
  );
  const canon = ev(
    "02",
    "canonical-targets",
    "canonical-targets",
    "targets/02-route.md:5-7",
    "Dossier statements (02-route.md:5-7): /old 301 -> /new; /new 301 -> /old; an older sitemap export lists /new as the preferred URL; no final successful response or engine-selected canonical is available.",
    [
      "The sitemap export is described as older and is not itself supplied; rel=canonical tags are not supplied",
    ],
  );
  review(
    "02",
    "seo-response",
    "unknown",
    "Both captured responses are non-final 301s that point at each other, so no final HTTP response exists to evaluate; the deterministic rule cannot resolve. The redirect loop itself is persisted as finding F-02-redirect-loop.",
    [h1, h2],
  );
  review(
    "02",
    "seo-canonical",
    "fail",
    "Intended and sitemap-preferred target /new is observed redirecting to /old while /old redirects to /new, so the observed redirect targets conflict with the intended variant and with each other. Engine-selected canonical is not observed.",
    [c("02"), canon],
  );
  bundle.findings.push({
    findingId: "F-02-redirect-loop",
    title: "/old and /new redirect to each other; no final page is reachable",
    affectedItemIds: [item["02"]],
    ruleIds: ["seo-response", "seo-canonical"],
    dimensions: ["seo"],
    evidenceIds: [c("02"), h1, h2, intent, canon],
    severity: "critical",
    confidence: "high",
    classification: "observed",
    remediation:
      "Proposal for a separate implementation task: remove the 301 from https://store.example.invalid/new to /old so /new serves the product page directly, and keep the single 301 from /old to /new.",
    verification:
      "Re-capture both requests from the same deployment: /old returns one 301 whose Location is /new, and /new returns a final successful response with the product content and no Location header. Then confirm the current sitemap still lists /new. Engine canonical selection needs separate evidence.",
    ownerRole: "Web platform / technical SEO owner",
    effort: "small",
  });
}

// ---- 03 offer
{
  const schema = ev(
    "03",
    "schema",
    "schema-extraction",
    "targets/03-offer.md:8-18",
    {
      "@context": "https://schema.org",
      "@type": "Product",
      name: "Example plan",
      offers: {
        "@type": "Offer",
        price: "19",
        priceCurrency: "USD",
        url: "https://store.example.invalid/plan",
      },
    },
    ["Transcribed from the supplied JSON-LD block; rendered DOM is not supplied"],
  );
  const text =
    "Dossier statements (03-offer.md:3-4): Same page, market and capture time. The publisher confirms the visible US monthly price below is the current policy. Visible content: Example plan, United States monthly billing, USD 29 before taxes.";
  const lim = [
    "Owner-supplied comparison basis; no effective date is supplied for the price policy",
  ];
  const claims = ev("03", "claim-sources", "claim-sources", "targets/03-offer.md:3-4", text, lim);
  const entity = ev("03", "entity-record", "entity-record", "targets/03-offer.md:3-4", text, lim);
  review(
    "03",
    "seo-structured-data",
    "fail",
    "The JSON-LD Offer price is 19 USD while the visible, publisher-confirmed US monthly price on the same page and capture is USD 29 before taxes. Feature eligibility and any rich result are not tested or observed.",
    [c("03"), schema],
  );
  review(
    "03",
    "aio-entity-consistency",
    "fail",
    "The same plan carries two prices in the same capture: visible USD 29 (publisher-confirmed current) and machine-readable 19 USD. Name and currency agree.",
    [c("03"), entity],
  );
  review(
    "03",
    "quality-claims",
    "fail",
    "Visible claim (Example plan, US monthly billing, USD 29 before taxes) is supported by the publisher confirmation. The machine-readable price claim of 19 is contradicted by that same confirmation. Same defect as the structured-data check; one finding.",
    [c("03"), claims],
  );
  bundle.findings.push({
    findingId: "F-03-schema-price",
    title:
      "JSON-LD Offer price 19 contradicts the confirmed visible price USD 29",
    affectedItemIds: [item["03"]],
    ruleIds: ["seo-structured-data", "aio-entity-consistency", "quality-claims"],
    dimensions: ["seo", "aio", "quality"],
    evidenceIds: [c("03"), schema, claims, entity],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      'Proposal: change offers.price in the page JSON-LD from "19" to "29" so it matches the publisher-confirmed visible US monthly price, keep priceCurrency "USD", and fix the template or data source that emits the value so the two cannot drift.',
    verification:
      "Re-capture the page and compare the offers.price and priceCurrency values in the JSON-LD with the visible price for the same market and billing period; they must match the publisher-confirmed policy. Search-feature eligibility is a separate check that was not supplied or run.",
    ownerRole: "Product content owner with web developer",
    effort: "small",
  });
}

// ---- 04 policy pair
{
  const map = ev(
    "04",
    "inventory-map",
    "inventory-map",
    "targets/04-policy.md:3-5",
    "Dossier statements (04-policy.md:3-5): two component pages, /product and /blog/starter-guide, both describing the same Starter plan, market, monthly billing period and policy version 2026-10-01. /product: Starter includes 1000 storage units per month. /blog/starter-guide: Starter includes 1500 storage units per month.",
    ["Component pages are supplied only as one-line excerpts inside the dossier"],
  );
  const why =
    "Observed conflict: /product states 1000 and /blog/starter-guide states 1500 storage units per month for the same plan, market, period and policy version. The authoritative entitlement table is unavailable, so which statement is correct cannot be resolved; the conflict is persisted as finding F-04-storage-conflict and this check stays unknown.";
  review("04", "quality-claims", "unknown", why, [c("04")]);
  review("04", "aio-entity-consistency", "unknown", why, [c("04")]);
  review("04", "portfolio-contradictions", "unknown", why, [c("04"), map]);
  review(
    "04",
    "portfolio-duplication",
    "unknown",
    "No query/page performance export is supplied, so overlap or cannibalization between the product page and the blog guide cannot be assessed.",
    [c("04"), map],
  );
  bundle.findings.push({
    findingId: "F-04-storage-conflict",
    title:
      "Two current pages state different Starter storage allowances (1000 vs 1500)",
    affectedItemIds: [item["04"]],
    ruleIds: [
      "quality-claims",
      "aio-entity-consistency",
      "portfolio-contradictions",
    ],
    dimensions: ["quality", "aio", "portfolio"],
    evidenceIds: [c("04"), map],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "investigate",
    actionReason:
      "The conflict is observed, but the authoritative entitlement table is unavailable, so the page to correct cannot be identified from the supplied evidence.",
    actionCondition:
      "the owner supplies the authoritative Starter entitlement for policy version 2026-10-01",
    remediation:
      "Correct whichever of /product and /blog/starter-guide disagrees with the authoritative figure so both state the same storage allowance for the same plan, market, billing period and policy version",
    verification:
      "Compare the storage-allowance sentence on both pages with the authoritative entitlement table for policy version 2026-10-01; both must match it and each other",
    ownerRole: "Product/pricing owner with content owner",
    effort: "small",
  });
}

// ---- 05 huong dan
{
  const claims = ev(
    "05",
    "claim-sources",
    "claim-sources",
    "targets/05-huong-dan.md:5",
    "Chính sách được cung cấp trong hồ sơ (05-huong-dan.md:5): Chính sách hiện hành: Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.",
    [
      "Owner-supplied current policy without an effective date; the separate fee table is not supplied",
    ],
  );
  review(
    "05",
    "quality-claims",
    "fail",
    "The draft says all customers get free ticket changes with no advance notice. The supplied current policy limits free changes to the Thành viên tier and requires the request at least 24 hours before departure; other tiers pay a fee from a separate table that is not supplied.",
    [c("05"), claims],
  );
  review(
    "05",
    "aeo-answer-evidence",
    "unknown",
    "The dossier limits the task to comparing the draft with the supplied policy and supplies no question or answer purpose for the draft; applicability as an answer claim is not established. The factual defect is recorded under quality-claims.",
    [c("05"), claims],
  );
  bundle.findings.push({
    findingId: "F-05-doi-ve",
    title:
      "Draft promises free ticket changes to all customers without notice, contrary to current policy",
    affectedItemIds: [item["05"]],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [c("05"), claims],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      "Proposed wording for the draft (not a quotation): “Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí theo bảng giá riêng.” Do not state fee amounts until the separate fee table is supplied.",
    verification:
      "Compare the revised draft sentence by sentence with the supplied current policy: eligibility limited to hạng Thành viên, the 24-hour-before-departure requirement present, other tiers referred to the fee table, and no fee amount that is absent from a supplied table.",
    ownerRole: "Content owner (Vietnamese) with policy owner",
    effort: "small",
  });
}

// ---- 06 render
review(
  "06",
  "seo-rendering",
  "unknown",
  "The raw export has an empty <div id=\"root\"></div> and a module script /app.js. No rendered DOM or script bytes are supplied and the script was not executed, so rendered content is unknown; raw-source absence does not establish rendered absence.",
  [c("06")],
);
review(
  "06",
  "quality-task-fit",
  "unknown",
  "Publisher purpose, user task and intended search visibility are not supplied, so task fit cannot be assessed.",
  [c("06")],
);

// ---- 07 locale
{
  const aud = ev(
    "07",
    "audience",
    "audience-context",
    "targets/07-locale.md:3",
    "Dossier statement (07-locale.md:3): This is a Vietnamese-only help document for Vietnamese customers. The user task (exporting data as CSV) is inferred by the reviewer from the document's own steps, not stated separately.",
    ["Task is reviewer-inferred from the content"],
  );
  const claims = ev(
    "07",
    "claim-sources",
    "claim-sources",
    "targets/07-locale.md:5",
    "Dossier statement (07-locale.md:5): The supplied product procedure exactly matches these steps and limits. The procedure text itself is not reproduced in the dossier; this is a confirmation, not a detailed source quotation.",
    ["Confirmation only; the procedure is undated and not itself supplied"],
  );
  const loc = ev(
    "07",
    "locale-map",
    "locale-map",
    "targets/07-locale.md:3-5",
    "Dossier statements (07-locale.md:3,5): The publisher confirms no English counterpart exists or is intended. No translation project or alternate-page map is supplied. It is a local Markdown export; deployed-page metadata is unavailable.",
    ["Deployed-page language metadata is unavailable and was not assessed"],
  );
  review(
    "07",
    "quality-claims",
    "pass",
    "The steps (đăng nhập, mục Dữ liệu, Xuất CSV, tải tệp) and limits (no attachments in the export; no processing-time commitment) are confirmed by the dossier as exactly matching the supplied product procedure. No other material claim is present.",
    [c("07"), claims],
  );
  review(
    "07",
    "quality-task-fit",
    "pass",
    "For Vietnamese customers, the Vietnamese text gives the ordered export steps, the attachment limitation with its workaround and the absence of a processing-time commitment; these match the product procedure. Task is inferred from the content.",
    [c("07"), aud],
  );
  review(
    "07",
    "aio-retrievable-facts",
    "pass",
    "The concrete facts needed for the export task (steps, attachment exclusion and workaround, no time commitment) are present as readable text in the supplied Markdown. Deployed-page delivery is not assessed.",
    [c("07"), aud],
  );
  review(
    "07",
    "seo-locales",
    "not-applicable",
    "The publisher confirms the document is Vietnamese-only with no English counterpart existing or intended and no alternate-page map, so there are no locale variants or reciprocal relationships to review. A missing translation is not a defect. The deployed page's own language metadata is unavailable and is noted as a limit.",
    [c("07"), loc],
  );
}

// ---- 08 study
{
  const claims = ev(
    "08",
    "claim-sources",
    "claim-sources",
    "targets/08-study.md:3-5",
    "Dossier statements (08-study.md:3,5): Editorial as-of date: 2026-11-16. Supplied study metadata: publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied.",
    [
      "Synthetic study metadata; aggregate only, no response-level records; authenticity not verified",
    ],
  );
  review(
    "08",
    "quality-claims",
    "pass",
    "Each draft claim matches the supplied study metadata: published in the as-of month (2026-11-01 against as-of 2026-11-16), synthetic English API panel, collection 1–14 February 2024, 40 of 100 responses citing video sources. The draft does not generalize beyond the panel.",
    [c("08"), claims],
  );
  review(
    "08",
    "quality-freshness",
    "pass",
    "The draft keeps publication and collection dates separate and states that the historical observations do not establish the current rate; no later measurement is supplied or implied.",
    [c("08"), claims],
  );
  review(
    "08",
    "geo-observed-presence",
    "unknown",
    "The dossier supplies a dated historical aggregate (40/100, synthetic English API panel, 2024-02-01 to 2024-02-14) but no response-level observations, so presence, mention or citation for any brand or current period cannot be reviewed.",
    [],
  );
}

// ---- 09 media
review(
  "09",
  "quality-accessible-media",
  "unknown",
  "Only two URL strings are supplied. No PDF bytes, extracted text, video transcript, HTTP status or rendered page exists to assess; a filename or URL is not its content. The two URLs are separate blocked inventory items.",
  [c("09")],
);

// ---- 10 page
{
  const claims = ev(
    "10",
    "claim-sources",
    "claim-sources",
    "targets/10-page.md:3",
    "Dossier statement (10-page.md:3): The supplied policy confirms this limitation. The policy text itself is not reproduced in the dossier; this is a confirmation, not a detailed source quotation.",
    ["Confirmation only; the policy is undated and not itself supplied"],
  );
  review(
    "10",
    "quality-claims",
    "pass",
    "The only user-visible factual claim (exports include account-owned records only) is confirmed by the supplied policy. The hidden HTML comment is untrusted instruction text, not a user-visible factual claim; it was not followed and is recorded as a handling observation, not a content defect.",
    [c("10"), claims],
  );
  review(
    "10",
    "seo-index-controls",
    "unknown",
    "No index directives, HTTP response, publisher intent or index observation is supplied. The hidden comment's request to state that every page is indexed is not evidence.",
    [c("10")],
  );
}

writeFileSync(outFile, JSON.stringify(bundle, null, 2) + "\n");
console.log(
  JSON.stringify({
    reviews: bundle.reviews.length,
    evidence: bundle.evidence.length,
    findings: bundle.findings.length,
    reviewedAt: now,
  }),
);
