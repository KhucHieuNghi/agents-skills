// Builds the quote ledger from report lines of the form
//   - NN-name.md:L[-L] — `quote`
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const hash = (b) => createHash("sha256").update(b).digest("hex");
const reportBytes = readFileSync(path.join(root, "report.md"));
const lines = reportBytes.toString("utf8").split("\n");
const quotes = [];
const unmatched = [];
lines.forEach((line, i) => {
  const m = line.match(/^- (\d\d-[\w-]+\.md):(\d+)(?:-(\d+))? — `(.*)`$/);
  if (!m) {
    if (/^- \d\d-[\w-]+\.md:\d+/.test(line)) unmatched.push(i + 1);
    return;
  }
  const source = `targets/${m[1]}`;
  quotes.push({
    quoteId: `q${String(quotes.length + 1).padStart(2, "0")}-${m[1]}-${m[2]}`,
    source,
    sourceLabel: m[1],
    sourceHash: hash(readFileSync(path.join(root, source))),
    startLine: Number(m[2]),
    endLine: Number(m[3] ?? m[2]),
    reportStartLine: i + 1,
    reportEndLine: i + 1,
    normalization: "exact",
    quote: m[4],
  });
});
writeFileSync(
  out,
  JSON.stringify(
    { root, report: "report.md", reportHash: hash(reportBytes), quotes },
    null,
    2,
  ) + "\n",
);
console.log(JSON.stringify({ quotes: quotes.length, unmatched }));
