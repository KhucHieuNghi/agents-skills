import pathlib as P,json as J,hashlib as H,datetime as D
def read(n): return [J.loads(l) for l in P.Path('audit-start',n+'.jsonl').read_text().splitlines()]
snap={int(P.Path(e['locator']).name[:2]):e for e in read('evidence') if e['kind']=='content'}
rules={r['ruleId']:r for r in J.loads(P.Path('.agents/skills/content-search-audit/rules/core.json').read_text())['rules']}
now=D.datetime.now(D.timezone.utc).isoformat()
b=dict(evidence=[],artifacts={},reviews=[],findings=[])
def ev(n,k,a,z=None, value=None):
 s=snap[n]; z=z or a
 raw='\n'.join(s['value'].splitlines()[a-1:z])
 v=raw if value is None else value
 data=v if isinstance(v,str) else J.dumps(v,ensure_ascii=False)
 id=f'dossier-{n:02}-{k}'
 art='evidence/'+id+'.txt'
 loc=P.Path(s['locator']).name+f':{a}'+(f'-{z}' if z!=a else '')
 b['artifacts'][art]=data
 b['evidence'].append(dict(evidenceId=id,itemId=s['itemId'],kind=k,method='attributed synthetic dossier excerpt or normalization',locator=loc,redaction='none',collectedAt=now,limitations=['Supplied synthetic evidence only.'],artifact=art,encoding='utf8' if isinstance(v,str) else 'json',value=v,snapshotHash=H.sha256(data.encode()).hexdigest(),sourceEvidenceIds=[s['evidenceId']]))
 return id
def review(n,r,status,reason,*ids):
 b['reviews'].append(dict(itemId=snap[n]['itemId'],ruleId=r,status=status,reason=reason,evidenceIds=[snap[n]['evidenceId'],*ids],reviewer='offline dossier audit',reviewedAt=now))
def finding(i,n,title,rr,action,test,*ids,severity='high'):
 b['findings'].append(dict(findingId=f'F{i}',affectedItemIds=[snap[n]['itemId']],title=title,ruleIds=rr,dimensions=list(dict.fromkeys(rules[r]['dimension'] for r in rr)),evidenceIds=[snap[n]['evidenceId'],*ids],severity=severity,confidence='high',classification='observed',ownerRole='Publisher',effort='Estimate after publisher review',remediation=action,verification=test))
for n,s in snap.items(): ev(n,'extracted-text',1,len(s['value'].splitlines()),s['value'])
a=ev(1,'publisher-intent',3)
h=ev(1,'http-response',4,5,dict(status=200,headers={'x-robots-tag':'noindex'},capturedAt='2026-11-10T08:00:00Z'))
review(1,'seo-index-controls','fail','Response noindex conflicts with stated public Google indexing intent and raw HTML robots declaration.',a,h)
finding(1,1,'Product response sends noindex despite Google indexing intent',['seo-index-controls'],'Remove the response-level noindex on /product for the intended public deployment.','Compare revised HTTP headers and raw HTML with Google indexing intent, then inspect index evidence separately if supplied.',a,h)
r=ev(2,'redirect-chain',4,6)
finding(2,2,'Old and new product routes redirect to each other',['seo-response'],'Serve /new successfully and retain one /old to /new redirect.','Inspect both revised responses and confirm a single redirect ends at a successful /new.',r)
sc=ev(3,'schema-extraction',8,18)
c=ev(3,'claim-sources',3,4)
review(3,'seo-structured-data','fail','Complete supplied Offer markup declares USD 19 against visible policy of USD 29 before tax.',sc,c)
finding(3,3,'Offer markup conflicts with the approved US monthly price',['seo-structured-data'],'Set Offer.price to 29 USD for the same US monthly offer.','Parse the revised JSON-LD and compare the matching offer with the displayed approved US monthly price.',sc,c)
e=ev(4,'entity-record',3,6)
m=ev(4,'inventory-map',3,6)
review(4,'aio-entity-consistency','fail','Both current pages for the same policy and plan give incompatible monthly storage quantities.',e)
review(4,'portfolio-contradictions','fail','The supplied pair directly contradicts itself under the same policy scope.',e,m)
finding(4,4,'Two current Starter pages disagree on monthly storage',['quality-claims','aio-entity-consistency','portfolio-contradictions'],'Obtain the authoritative entitlement table for policy 2026-10-01 and reconcile both pages to its applicable value.','Compare both revised statements with the table for the same market, version and period.',e,m)
p=ev(5,'claim-sources',5)
for r in ['quality-claims','aeo-answer-evidence']:
 review(5,r,'fail','The ticket-change answer overstates eligibility and omits the minimum 24-hour notice.',p)
finding(5,5,'Vietnamese ticket-change draft overstates free changes',['quality-claims','aeo-answer-evidence'],'State Thành viên eligibility and at least 24 hours before departure. Refer other tiers to the separate fee schedule.','Verify eligibility, deadline and fee reference against the supplied policy and check the fee schedule when available.',p)
for n,a,z,r,reason in [
 (7,5,5,'quality-claims','The supplied procedure matches every step and limitation in the Vietnamese help content.'),
 (8,3,5,'quality-freshness','Publication month and historical collection window are accurately distinguished as of 2026-11-16.'),
 (8,3,5,'quality-claims','The dated wording, scope, count and non-current qualification match supplied study metadata.'),
 (10,3,3,'quality-claims','The only supplied user-visible product claim matches supplied policy.')]:
 k=f'dossier-{n:02}-claim-sources'
 if k not in [x['evidenceId'] for x in b['evidence']]: ev(n,'claim-sources',a,z)
 review(n,r,'pass',reason,k)
a=ev(7,'audience-context',3,4)
review(7,'quality-task-fit','pass','Vietnamese instructions cover the CSV export and separately explain attachment retrieval for Vietnamese customers.',a)
review(7,'aio-retrievable-facts','pass','Supplied text directly states CSV steps, attachment exclusion and handling, and the timing limitation.',a)
l=ev(7,'locale-map',3,5)
review(7,'seo-locales','unknown','No English counterpart is intended. Deployed language metadata is unavailable.',l)
p=P.Path('targets/08-study.md'); s=p.read_text()
study=dict(sourceId='historical-video-panel',kind='historical-study',locator=p.name,sourceText=s,sourceHash=H.sha256(p.read_bytes()).hexdigest(),synthetic=True,scope='English synthetic API panel, collected 2024-02-01 through 2024-02-14, published 2026-11-01. 40 of 100 responses cited video sources.',limitations=['No later measurement or individual response exports. No inference about current rates or brand performance.'],passages=[dict(startLine=4,endLine=5,quote='\n'.join(s.splitlines()[3:5]))])
P.Path('audit-study-options.json').write_text(J.dumps(dict(studySources=[study])))
P.Path('audit-review.json').write_text(J.dumps(b,ensure_ascii=False))
