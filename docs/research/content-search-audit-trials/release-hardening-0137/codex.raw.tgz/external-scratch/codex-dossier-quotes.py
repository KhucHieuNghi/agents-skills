import re,json,hashlib
from pathlib import Path
def hash(p): return hashlib.sha256(p.read_bytes()).hexdigest()
root=Path.cwd()
lines=[]
ledger=[]
for line in Path('/tmp/dossier-report.txt').read_text().splitlines():
 m=re.fullmatch(r'@(\d+):(\d+)(?:-(\d+))?',line)
 if not m:
  lines.append(line)
  continue
 n,a,z=m.groups()
 a,z=int(a),int(z or a)
 p=next(Path('targets').glob(n+'-*.md'))
 quote='\n'.join(p.read_text().splitlines()[a-1:z])
 lines.append('Evidence ('+p.name+f':{a}'+(f'-{z}' if a!=z else '')+').')
 lines.append('')
 lines.append('~~~text')
 start=len(lines)+1
 lines.extend(quote.splitlines())
 lines.extend(['~~~',''])
 ledger.append(dict(quoteId=f'{n}-{a}',source=str(p),sourceLabel=p.name,sourceHash=hash(p),startLine=a,endLine=z,reportStartLine=start-3,reportEndLine=start+z-a,quote=quote))
r=Path('report.md')
r.write_text('\n'.join(lines)+'\n')
Path('audit-quotes.json').write_text(json.dumps(dict(root=str(root),report=str(r),reportHash=hash(r),quotes=ledger),ensure_ascii=False))
