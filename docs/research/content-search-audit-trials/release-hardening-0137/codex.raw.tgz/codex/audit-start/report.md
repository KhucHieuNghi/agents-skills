# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T05:32:59\.961Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run ed0877ea\-fd33\-4992\-87af\-ac02d56614dd\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1e3940fb8a716eed6d849010bbe8fc79b389b04e450d24fae0d324415a990c6b | 0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be | local\-file | 2026\-11\-18T05:32:59\.510Z | 0 full elapsed days | [evidence/0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be\.txt](evidence/0b87837483398f56fed0062da5e8c4f241555472ed638c5cbf9e4dcf361072be.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c0ad2dc2fb1e460116648a7f31265be8786e2959f60ba4371022d4184b8dec02 | 0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9 | local\-file | 2026\-11\-18T05:32:59\.512Z | 0 full elapsed days | [evidence/0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9\.txt](evidence/0eb8012abae8f89cd9c31c48418357e941bc3cfb6f2f6b7e4580c60375ca5ff9.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 28a7f45429b08e34bcc696027cb84617d5c36e60eb483206781922ee917ca4c8 | 1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea | local\-file | 2026\-11\-18T05:32:59\.518Z | 0 full elapsed days | [evidence/1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea\.txt](evidence/1fe05dbd07ab625f780d5a9f86515e07831e6de0035dfa9f7b948be21a0d7cea.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| bdd021f571f68fffcc0debfdf8d83d21789332a78e61d07769971d26d630c508 | 8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b | local\-file | 2026\-11\-18T05:32:59\.530Z | 0 full elapsed days | [evidence/8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b\.txt](evidence/8debf2209b7c0279d8db0449cf2f4ccfcfa1764a983c97500ded0eb6e842be2b.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e09e0685938197f6fe391442706c0b6caed3f1195dcabe29acdab20496e91a48 | a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353 | local\-file | 2026\-11\-18T05:32:59\.539Z | 0 full elapsed days | [evidence/a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353\.txt](evidence/a3fb82854c96bd45ae47974026130fcb26f26aa9f56cb655087c0d99f12fa353.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 99917786ee53c4b4747c8b9fddbd0167a0cc07089797e8b3656c6a49fea65c04 | a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c | local\-file | 2026\-11\-18T05:32:59\.557Z | 0 full elapsed days | [evidence/a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c\.txt](evidence/a9c87aa659634a4ac3e8fa770b6d57b585d064814c82324d12ecf11843e94d7c.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 536ccebc5367c369d5b645946afa4ba99eaf3d6b70df8b6905c63125f27b5fba | ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b | local\-file | 2026\-11\-18T05:32:59\.601Z | 0 full elapsed days | [evidence/ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b\.txt](evidence/ad71c299621321c84f16c978269fb9c7ef6a93a355aa285a704b906dfea5f62b.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5aaa28ab9ec4a73e7339cd9bec0002a860a480d9ff897b432eec298289bba54e | afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692 | local\-file | 2026\-11\-18T05:32:59\.621Z | 0 full elapsed days | [evidence/afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692\.txt](evidence/afa74411efa3fc3ec9ab6d267ea84a24099b1b568d79a65a50e8a2e576d1f692.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4f66f6b7f9a71ea482bf180b036648b9ce7c1974734f64f5f30b6d91c69324ab | e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926 | local\-file | 2026\-11\-18T05:32:59\.651Z | 0 full elapsed days | [evidence/e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926\.txt](evidence/e0d107b407e90fc00ed425cb4daf3e21ef29d1ec687ca7eea4339968639e0926.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 2f0bb0922d8aa8174175272679d9004c587b13a505945ddc65e3c801a853d260 | e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9 | local\-file | 2026\-11\-18T05:32:59\.675Z | 0 full elapsed days | [evidence/e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9\.txt](evidence/e19dcd17a18f6aea08f9bd4c4da9b53cfcda9fbe9c8066c04ef0e7e0e9881aa9.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
