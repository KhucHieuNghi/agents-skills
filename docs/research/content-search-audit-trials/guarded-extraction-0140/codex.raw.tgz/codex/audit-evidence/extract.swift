import Foundation
import PDFKit
import CryptoKit

for path in CommandLine.arguments.dropFirst() {
    let url = URL(fileURLWithPath: path)
    let bytes = try Data(contentsOf: url)
    guard let pdf = PDFDocument(data: bytes) else { fatalError("Could not open \(path)") }
    let pages = (0..<pdf.pageCount).map { index in
        ["page": index + 1, "text": pdf.page(at: index)?.string ?? ""] as [String: Any]
    }
    let version = Bundle(for: PDFDocument.self).object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ProcessInfo.processInfo.operatingSystemVersionString
    let result: [String: Any] = [
        "path": path, "schemaVersion": 1, "sourceByteLength": bytes.count,
        "sourceSha256": SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined(),
        "extractor": ["name": "macOS PDFKit", "version": version],
        "pageCount": pdf.pageCount, "pages": pages,
        "coverage": pdf.pageCount > 0 && pages.allSatisfy { !($0["text"] as! String).trimmingCharacters(in: .whitespacesAndNewlines).isEmpty } ? "complete" : "unsupported",
        "limitations": ["Text layer only. Visual layout, reading order, tagging and image content require separate inspection."]
    ]
    print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), as: UTF8.self))
}
