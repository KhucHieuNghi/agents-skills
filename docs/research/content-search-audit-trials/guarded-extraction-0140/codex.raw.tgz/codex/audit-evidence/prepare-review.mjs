import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { basename } from 'node:path';

const read = (path) => readFileSync(path, 'utf8');
const lines = (path) => read(path).trim().split('\n').map(JSON.parse);
const write = (name, value) => writeFileSync('audit-evidence/' + name + '.json', JSON.stringify(value, null, 2) + '\n');
const item = Object.fromEntries(lines('audit-initial/inventory.jsonl').map(row => [basename(row.path), row.itemId]));
const html = item['render.html'];
const pdf = item['document.pdf'];
const image = item['image-only.pdf'];
const original = lines('audit-initial/evidence.jsonl')[0].evidenceId;
const [docExtract, imageExtract] = lines('audit-evidence/pdfkit.jsonl');
const now = new Date().toISOString();
const reviewer = 'Codex audit reviewer';
const bundle = () => ({ evidence: [], artifacts: {}, reviews: [] });
function add(b, evidenceId, itemId, kind, input, locator, method, limitations, sourceEvidenceIds = []) {
  const value = typeof input === 'string' ? input : JSON.stringify(input, null, 2);
  const artifact = 'evidence/' + evidenceId + (typeof input === 'string' ? '.txt' : '.json');
  b.artifacts[artifact] = value;
  b.evidence.push({
    evidenceId, itemId, kind, value: input, locator, method, limitations,
    sourceEvidenceIds, artifact, encoding: typeof input === 'string' ? 'utf8' : 'json', redaction: 'none',
    collectedAt: now, byteLength: Buffer.byteLength(value),
    snapshotHash: createHash('sha256').update(value).digest('hex')
  });
  return evidenceId;
}
const recovery = bundle();
const { path, ...manifest } = docExtract;
const pages = manifest.pages.map(page => page.text).join('\f');
const extractMethod = 'Swift with macOS PDFKit ' + manifest.extractor.version;
add(recovery, 'pdf-manifest', pdf, 'extraction-provenance', manifest, path + ' pp. 1–2', extractMethod, manifest.limitations);
add(recovery, 'pdf-content', pdf, 'content', pages, path + ' pp. 1–2', extractMethod, manifest.limitations, ['pdf-manifest']);
add(recovery, 'pdf-text', pdf, 'extracted-text', pages, path + ' pp. 1–2', extractMethod, manifest.limitations, ['pdf-content']);
add(recovery, 'image-text-attempt', image, 'collection-diagnostic', JSON.stringify(imageExtract, null, 2), 'targets/image-only.pdf p. 1', extractMethod, ['PDFKit returned an empty text-layer value. Source-page content is unresolved by this extraction.']);
recovery.collectionRecoveries = [{
  itemId: pdf, manifestEvidenceId: 'pdf-manifest', contentEvidenceId: 'pdf-content',
  textEvidenceId: 'pdf-text', reviewer, reviewedAt: now,
  reason: 'PDFKit returned nonempty text on both pages in page order. Recovery covers both text layers, with visual layout, tagging and image content outside this extraction.'
}];
write('recovery', recovery);

const review = bundle();
const owner = 'User task statement for this controlled local audit';
const approvedTask = 'Approved renewal task requires opening Billing and selecting Disable renewal.';
const approvedPolicy = 'Approved export policy: current VN plans support at most 5000 records per export, with no extra charge. English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.';
const ownerLimits = ['Owner-approved comparison basis for the controlled fixtures. Independent product verification was outside this audit.'];
add(review, 'renewal-task', html, 'audience-context', approvedTask, owner, 'owner-supplied context', ownerLimits);
add(review, 'export-policy', pdf, 'claim-sources', approvedPolicy, owner, 'owner-supplied context', ownerLimits);
add(review, 'export-entity', pdf, 'entity-record', approvedPolicy, owner, 'owner-supplied context', ownerLimits);
add(review, 'chrome-attempt', html, 'collection-diagnostic', read('audit-evidence/chrome.stderr'), 'audit-evidence/chrome.stderr', 'fresh-profile local headless Chrome attempt', ['Signal 6; stdout contained no DOM and readiness could not be observed. The termination cause was unconfirmed.'], [original]);
add(review, 'ready-contract', html, 'collection-context', "The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering.", owner, 'owner-supplied context', ['Defines the fixture readiness condition; no browser observation was captured.']);
function assess(itemId, ruleId, status, reason, evidenceIds) {
  review.reviews.push({ itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
}
const renewalEvidence = [original, 'renewal-task', 'ready-contract', 'chrome-attempt'];
const renewalReason = 'The initial main text includes both approved steps. The source callback replaces the entire main text with the first step and then marks the fixture ready. The finding concerns the scripted task instructions. Browser execution was unobserved.';
assess(html, 'quality-task-fit', 'fail', renewalReason, renewalEvidence);
assess(html, 'seo-rendering', 'unknown', 'Chrome terminated before the ready DOM could be captured. Static source establishes a replacement of task text in the callback. Browser and engine rendering remain unobserved.', renewalEvidence);
assess(html, 'aio-retrievable-facts', 'unknown', 'Raw main text contains the approved steps and the ready callback removes the second. A readable post-ready snapshot was unavailable.', renewalEvidence);
assess(html, 'quality-accessible-media', 'not-applicable', 'The whole HTML fixture contains task text and an inline script, with no informative media.', [original]);
assess(pdf, 'quality-claims', 'pass', 'Page 1 gives the per-export limit and current VN-plan scope. Page 2 repeats the same limit and states there is no extra charge. Both agree with owner policy. The PDF contains no other decision-relevant assertions in the recovered text.', ['pdf-content', 'export-policy']);
assess(pdf, 'quality-freshness', 'pass', 'The current VN-plan qualification and localized limit and fee claims agree with owner-approved current policy for this document. The task permits differing editorial emphasis across the two pages.', ['pdf-content', 'export-policy']);
assess(pdf, 'aeo-answer-evidence', 'pass', 'The export-limit and fee statements directly answer material product questions. All such statements in the recovered document agree with approved policy, including scope and quantity.', ['pdf-content', 'export-policy']);
assess(pdf, 'aio-entity-consistency', 'pass', 'Both language pages give the same per-export cap. The English scope and Vietnamese fee statement are compatible with each other and the supplied VN-plan policy.', ['pdf-content', 'export-entity']);
add(review, "image-visual", image, "collection-diagnostic", "Visual inspection of page 1 shows a single rasterized line explaining that OCR is needed. The retained raster is audit-evidence/image-only-page-1.png. Vision produced no transcript on either attempt.", "targets/image-only.pdf p. 1", "PDFKit rasterization and visual review", ["The visual observation scopes the visible page only. Native text, alternate descriptions and assistive-technology presentation remain unverified."], ["image-text-attempt"]);
assess(image, 'quality-readable-text', 'unknown', 'PDFKit found one page and returned no text. The empty diagnostic cannot establish source readability or satisfy attributed collection recovery.', ["image-text-attempt", "image-visual"]);
review.findings = [{
  findingId: 'renewal-step-removed',
  title: 'The readiness callback removes the required Disable renewal step',
  affectedItemIds: [html], ruleIds: ['quality-task-fit', 'seo-rendering'], dimensions: ['quality', 'seo'],
  evidenceIds: renewalEvidence, severity: 'high', confidence: 'high', classification: 'observed',
  remediation: 'In targets/render.html, preserve the complete Billing and Disable renewal instructions when the callback updates the task text before setting the ready marker.',
  verification: 'In a fresh authorized local browser profile, wait until the root auditReady dataset value equals the string true. Then verify that the visible main instructions contain both steps in order. Browser verification remains pending.',
  ownerRole: 'Frontend owner', effort: 'small'
}];
write('semantic', review);
