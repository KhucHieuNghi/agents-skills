import Foundation
import PDFKit
import Vision
import AppKit

let source = URL(fileURLWithPath: "targets/image-only.pdf")
guard let page = PDFDocument(url: source)?.page(at: 0) else { fatalError("Missing page") }
let thumbnail = page.thumbnail(of: NSSize(width: 1600, height: 1600), for: .mediaBox)
var bounds = CGRect(origin: .zero, size: thumbnail.size)
guard let bitmap = thumbnail.cgImage(forProposedRect: &bounds, context: nil, hints: nil) else { fatalError("No bitmap") }
let png = NSBitmapImageRep(cgImage: bitmap).representation(using: .png, properties: [:])!
try png.write(to: URL(fileURLWithPath: "audit-evidence/image-only-page-1.png"))
let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
try VNImageRequestHandler(cgImage: bitmap, options: [:]).perform([request])
let result = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }
print(String(decoding: try JSONSerialization.data(withJSONObject: result), as: UTF8.self))
