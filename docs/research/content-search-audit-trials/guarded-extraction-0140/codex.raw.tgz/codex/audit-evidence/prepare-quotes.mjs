import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const hash = (path) => createHash('sha256').update(readFileSync(path)).digest('hex');
const manifest = JSON.parse(readFileSync('audit-reviewed/evidence/pdf-manifest.json', 'utf8'));
for (const page of manifest.pages) {
  writeFileSync('audit-evidence/document-page-' + page.page + '.txt', page.text);
}
const report = 'audit-evidence/audit-narrative.md';
const reportLines = readFileSync(report, 'utf8').split('\n');
const quote = (quoteId, source, sourceLabel, startLine, endLine, text, normalization) => {
  const reportLine = reportLines.findIndex(line => line.includes(text)) + 1;
  if (!reportLine) throw new Error('Missing narrative text for ' + quoteId);
  return { quoteId, source, sourceLabel, sourceHash: hash(source), startLine, endLine,
    reportStartLine: reportLine, reportEndLine: reportLine, normalization, quote: text };
};
const quotes = [
  quote('renewal-main', 'targets/render.html', 'render.html', 1, 1,
    'Open Billing. Select Disable renewal.', 'exact'),
  quote('vn-export-english', 'audit-evidence/document-page-1.txt', 'document-page-1.txt', 2, 3,
    'A single export contains at most 5000 records. Applies to current VN plans.', 'whitespace')
];
writeFileSync('audit-evidence/quote-ledger.json', JSON.stringify({
  root: process.cwd(), report, reportHash: hash(report), quotes
}, null, 2) + '\n');
