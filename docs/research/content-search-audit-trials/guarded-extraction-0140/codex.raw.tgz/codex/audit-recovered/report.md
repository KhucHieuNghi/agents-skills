# Content audit — Content Search Audit

## Delivery summary

Partial\. 3 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:36:12\.061Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 6ae04338\-16f5\-4bc0\-ae65\-d22c79117e36\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 1 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 1 | 14 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | pending | Snapshot review incomplete | 26 |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | pdf\-text |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | pdf\-content |
| a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | pdf\-content |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| f37b167f36c5eeebfbdb495a0da29fba5a3bc5b69eb6608e373a8e34707a3da0 | 4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905 | local\-file | 2026\-11\-18T08:33:23\.526Z | 0 full elapsed days | [evidence/4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905\.txt](evidence/4e9f00bb34cdaba60461799aae3ed14faa5ffa570bb683bccc449eb407606905.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| pdf\-manifest | a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | Swift with macOS PDFKit 1451\.3\.3 | 2026\-11\-18T08:36:11\.983Z | 0 full elapsed days | [evidence/pdf\-manifest\.json](evidence/pdf-manifest.json) | a2c1b2cb30071ee11bcbd88f118aa402ab2bb4085a5926e5fb700f1601a93c54 | Text layer only\. Visual layout, reading order, tagging and image content require separate inspection\. |
| pdf\-content | a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | Swift with macOS PDFKit 1451\.3\.3 | 2026\-11\-18T08:36:11\.983Z | 0 full elapsed days | [evidence/pdf\-content\.txt](evidence/pdf-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Text layer only\. Visual layout, reading order, tagging and image content require separate inspection\. |
| pdf\-text | a0669ad48ec316b0b241f474b8656bb1c9a6bcb959bb7d63885d6eb4dace68a8 | Swift with macOS PDFKit 1451\.3\.3 | 2026\-11\-18T08:36:11\.983Z | 0 full elapsed days | [evidence/pdf\-text\.txt](evidence/pdf-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Text layer only\. Visual layout, reading order, tagging and image content require separate inspection\. |
| image\-text\-attempt | cbeb70a880557bbba14fa36a91909d562f467ec590aea28a7ae0c6e6be77c2c9 | Swift with macOS PDFKit 1451\.3\.3 | 2026\-11\-18T08:36:11\.983Z | 0 full elapsed days | [evidence/image\-text\-attempt\.txt](evidence/image-text-attempt.txt) | f2fd5b19a675c96d14d031578e8f83d2d8e36a0c304bbed8f32ba431c7b0a94d | PDFKit returned an empty text\-layer value\. Source\-page content is unresolved by this extraction\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
