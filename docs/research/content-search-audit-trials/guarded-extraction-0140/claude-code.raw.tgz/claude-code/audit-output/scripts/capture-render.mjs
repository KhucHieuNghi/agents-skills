// Loads targets/render.html in installed Google Chrome (headless) with a fresh,
// throwaway profile. Sandbox is left at Chrome defaults (no sandbox flags).
// Waits for document.documentElement.dataset.auditReady === 'true', then captures the DOM.
// DNS is mapped to NOTFOUND so the browser cannot reach external hosts.
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, existsSync, rmSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const project = path.resolve(here, "..", "..");
const outDir = path.join(project, "audit-output", "captures");
mkdirSync(outDir, { recursive: true });
const workDir = path.join(project, "audit-output", "work");
mkdirSync(workDir, { recursive: true });
const sha = (b) => createHash("sha256").update(b).digest("hex");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const target = path.join(project, "targets", "render.html");
const chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const result = {
  startedAt: new Date().toISOString(),
  target,
  targetUrl: pathToFileURL(target).href,
  sourceSha256Before: sha(readFileSync(target)),
  browserPath: chrome,
  readySignal: "document.documentElement.dataset.auditReady === 'true'",
  nodeVersion: process.version,
};
let child;
let profile;
try {
  if (!existsSync(chrome)) throw new Error("Google Chrome not found at expected path");
  if (typeof WebSocket !== "function") throw new Error("Node global WebSocket unavailable");
  profile = mkdtempSync(path.join(workDir, "chrome-profile-"));
  result.profile = "fresh temporary profile under audit-output/work (removed after capture)";
  const args = [
    "--headless=new",
    `--user-data-dir=${profile}`,
    "--remote-debugging-port=0",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions",
    "--disable-sync",
    "--disable-background-networking",
    "--disable-component-update",
    "--host-resolver-rules=MAP * ~NOTFOUND",
    "about:blank",
  ];
  result.browserArgs = args.map((a) => (a.startsWith("--user-data-dir=") ? "--user-data-dir=<fresh profile>" : a));
  child = spawn(chrome, args, { stdio: ["ignore", "ignore", "pipe"] });
  let stderr = "";
  child.stderr.on("data", (d) => (stderr += d));
  let exited = null;
  child.on("exit", (code, signal) => (exited = { code, signal }));
  const portFile = path.join(profile, "DevToolsActivePort");
  let port = null;
  for (let i = 0; i < 150 && !exited; i++) {
    if (existsSync(portFile)) {
      const lines = readFileSync(portFile, "utf8").split("\n");
      if (/^\d+$/.test(lines[0] ?? "")) {
        port = Number(lines[0]);
        break;
      }
    }
    await sleep(100);
  }
  if (!port) throw new Error(`Chrome did not expose a DevTools port; exit=${JSON.stringify(exited)}; stderr=${stderr.slice(0, 1500)}`);
  const base = `http://127.0.0.1:${port}`;
  result.browserVersion = await (await fetch(`${base}/json/version`)).json();
  delete result.browserVersion.webSocketDebuggerUrl;
  const targets = await (await fetch(`${base}/json/list`)).json();
  const page = targets.find((t) => t.type === "page");
  if (!page) throw new Error("No page target");
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => {
    ws.addEventListener("open", res, { once: true });
    ws.addEventListener("error", () => rej(new Error("WebSocket error")), { once: true });
  });
  let seq = 0;
  const pending = new Map();
  const events = [];
  ws.addEventListener("message", (m) => {
    const msg = JSON.parse(m.data);
    if (msg.id && pending.has(msg.id)) {
      const { res, rej } = pending.get(msg.id);
      pending.delete(msg.id);
      msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
    } else if (msg.method) events.push(msg);
  });
  const send = (method, params = {}) =>
    new Promise((res, rej) => {
      const id = ++seq;
      pending.set(id, { res, rej });
      ws.send(JSON.stringify({ id, method, params }));
    });
  const evaluate = async (expression) => {
    const r = await send("Runtime.evaluate", { expression, returnByValue: true });
    if (r.exceptionDetails) throw new Error(`Evaluate exception: ${JSON.stringify(r.exceptionDetails).slice(0, 500)}`);
    return r.result.value;
  };
  await send("Page.enable");
  await send("Runtime.enable");
  await send("Network.enable");
  await send("Log.enable");
  const nav = await send("Page.navigate", { url: result.targetUrl });
  if (nav.errorText) throw new Error(`Navigation error: ${nav.errorText}`);
  result.navigatedAt = new Date().toISOString();
  const deadline = Date.now() + 15000;
  let ready = false;
  let polls = 0;
  while (Date.now() < deadline) {
    polls++;
    ready = await evaluate("location.href.startsWith('file:') && document.documentElement.dataset.auditReady === 'true'");
    if (ready) break;
    await sleep(25);
  }
  result.readyObserved = ready;
  result.readyPolls = polls;
  result.capturedAt = new Date().toISOString();
  result.capture = await evaluate(`(() => ({
    href: location.href,
    readyState: document.readyState,
    auditReadyValue: document.documentElement.dataset.auditReady ?? null,
    auditReadyType: typeof document.documentElement.dataset.auditReady,
    title: document.title,
    lang: document.documentElement.lang,
    mainTextContent: document.getElementById('task') ? document.getElementById('task').textContent : null,
    bodyInnerText: document.body ? document.body.innerText : null,
    outerHTML: '<!doctype html>' + document.documentElement.outerHTML,
  }))()`);
  result.requests = events
    .filter((e) => e.method === "Network.requestWillBeSent")
    .map((e) => e.params.request.url);
  result.consoleAndLog = events
    .filter((e) => ["Runtime.consoleAPICalled", "Runtime.exceptionThrown", "Log.entryAdded"].includes(e.method))
    .map((e) => JSON.stringify(e.params).slice(0, 600));
  try {
    await send("Browser.close");
  } catch {}
  ws.close();
  result.ok = ready === true;
  if (!ready) result.failure = "Ready signal not observed within 15s; rendered state must stay unknown";
} catch (e) {
  result.ok = false;
  result.failure = String(e?.stack ?? e);
} finally {
  if (child && child.exitCode === null) {
    await sleep(1500);
    if (child.exitCode === null) child.kill("SIGTERM");
    await sleep(500);
  }
  if (profile && profile.startsWith(workDir + path.sep)) {
    try {
      rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 300 });
      result.profileRemoved = !existsSync(profile);
    } catch (e) {
      result.profileRemoved = false;
      result.profileRemovalError = String(e.message);
    }
  }
  result.sourceSha256After = sha(readFileSync(target));
  result.sourceUnchanged = result.sourceSha256After === result.sourceSha256Before;
  result.finishedAt = new Date().toISOString();
  const name = `render-capture-${result.startedAt.replace(/[:.]/g, "-")}.json`;
  writeFileSync(path.join(outDir, name), JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
  result.savedAs = `audit-output/captures/${name}`;
  console.log(JSON.stringify(result, null, 2));
}
