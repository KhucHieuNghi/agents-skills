// Builds the two review bundles from saved captures. Does not run target code.
// Usage: node build-bundles.mjs evidence|semantic
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, readdirSync, mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const project = path.resolve(here, "..", "..");
const out = path.join(project, "audit-output");
const sha = (v) => createHash("sha256").update(v).digest("hex");
const mode = process.argv[2];
const now = new Date().toISOString();
const reviewer = "Claude (AI audit agent; host review for content-search-audit)";

const inventory = readFileSync(path.join(out, "run-01-initial", "inventory.jsonl"), "utf8")
  .split("\n").filter(Boolean).map((l) => JSON.parse(l));
const byName = (n) => inventory.find((i) => path.basename(i.path) === n);
const R = byName("render.html");
const D = byName("document.pdf");
const I = byName("image-only.pdf");
const snapshot = readFileSync(path.join(out, "run-01-initial", "evidence.jsonl"), "utf8")
  .split("\n").filter(Boolean).map((l) => JSON.parse(l))
  .find((e) => e.itemId === R.itemId && e.kind === "content");

const ids = {
  rDom: "render-rendered-dom",
  rReceipt: "render-capture-receipt",
  rText: "render-rendered-extracted-text",
  rMedia: "render-media-inventory",
  rSchema: "render-schema-extraction",
  rAudience: "render-owner-renewal-task-audience-context",
  rClaims: "render-owner-renewal-task-claim-source",
  dManifest: "document-pdf-extraction-manifest",
  dContent: "document-pdf-content",
  dText: "document-pdf-extracted-text",
  dMedia: "document-pdf-media-inventory",
  dClaims: "document-owner-export-policy-claim-source",
  dEntity: "document-owner-export-policy-entity-record",
  iAttempt: "image-only-pdf-extraction-attempt",
};

mkdirSync(path.join(out, "reviews"), { recursive: true });

if (mode === "evidence") {
  const capDir = path.join(out, "captures");
  const capName = readdirSync(capDir).filter((f) => f.startsWith("render-capture-")).sort().at(-1);
  const cap = JSON.parse(readFileSync(path.join(capDir, capName), "utf8"));
  const pdf = JSON.parse(readFileSync(path.join(capDir, "pdf-extraction.json"), "utf8"));
  if (!cap.ok || cap.readyObserved !== true || !cap.sourceUnchanged) throw new Error("Render capture not usable");
  const artifacts = {};
  const evidence = [];
  const add = ({ id, itemId, kind, value, encoding, method, collectedAt, locator, limitations, sources }) => {
    const text = encoding === "json" ? JSON.stringify(value, null, 2) + "\n" : value;
    const artifact = `evidence/${id}.${encoding === "json" ? "json" : "txt"}`;
    artifacts[artifact] = text;
    evidence.push({
      evidenceId: id, itemId, method, collectedAt, locator,
      snapshotHash: sha(text), byteLength: Buffer.byteLength(text),
      redaction: "none; authorized source content retained locally",
      limitations, kind, value, artifact, encoding, sourceEvidenceIds: sources,
    });
  };
  const ownerNote = "Owner/task statement supplied in the audit request; an approved comparison basis for this audit, not independently verified platform behaviour or a public source";
  const count = (s, re) => (s.match(re) ?? []).length;

  // ---- render.html ----
  const dom = cap.capture.outerHTML;
  const chromeMethod = `Local headless Google Chrome (${cap.browserVersion.Browser}) via DevTools protocol; fresh temporary profile; default browser sandbox; DNS mapped to NOTFOUND; captured after ready signal ${cap.readySignal}`;
  add({
    id: ids.rDom, itemId: R.itemId, kind: "rendered-dom", encoding: "utf8", value: dom,
    method: chromeMethod, collectedAt: cap.capturedAt,
    locator: `${R.path} (rendered DOM serialisation, document.documentElement.outerHTML with doctype prefix, at ready signal)`,
    limitations: [
      "Local headless Chrome rendering of a file: URL; not search-engine or AI-crawler rendering",
      "Single capture at the owner-confirmed ready signal; earlier transient states were not captured",
      "The '<!doctype html>' prefix was prepended by the capture script; the remainder is the browser's serialisation",
    ],
    sources: [snapshot.evidenceId],
  });
  add({
    id: ids.rReceipt, itemId: R.itemId, kind: "render-capture", encoding: "json",
    value: {
      captureFile: `audit-output/captures/${capName}`,
      browser: cap.browserVersion, browserArgs: cap.browserArgs, profile: cap.profile, profileRemoved: cap.profileRemoved,
      navigatedAt: cap.navigatedAt, capturedAt: cap.capturedAt,
      readySignal: cap.readySignal, readyObserved: cap.readyObserved, readyPolls: cap.readyPolls,
      auditReadyValue: cap.capture.auditReadyValue, auditReadyType: cap.capture.auditReadyType,
      readyState: cap.capture.readyState, title: cap.capture.title, lang: cap.capture.lang,
      mainTextContent: cap.capture.mainTextContent, bodyInnerText: cap.capture.bodyInnerText,
      requests: cap.requests, consoleAndLog: cap.consoleAndLog,
      sourceSha256Before: cap.sourceSha256Before, sourceSha256After: cap.sourceSha256After, sourceUnchanged: cap.sourceUnchanged,
    },
    method: chromeMethod, collectedAt: cap.capturedAt, locator: `${R.path} (capture receipt)`,
    limitations: ["Receipt authored by the audit capture script; not an independent attestation"],
    sources: [snapshot.evidenceId],
  });
  add({
    id: ids.rText, itemId: R.itemId, kind: "extracted-text", encoding: "utf8", value: cap.capture.bodyInnerText,
    method: `${chromeMethod}; document.body.innerText`, collectedAt: cap.capturedAt,
    locator: `${R.path} (visible body text of rendered DOM at ready signal)`,
    limitations: [
      "Visible text of the rendered state only; the raw source text differs and is retained separately as content evidence",
      "Nonempty text does not establish completeness or quality",
    ],
    sources: [ids.rDom],
  });
  const mediaRe = /<(img|picture|video|audio|svg|canvas|object|embed|iframe|source|track)\b/gi;
  add({
    id: ids.rMedia, itemId: R.itemId, kind: "media-inventory", encoding: "json",
    value: {
      method: "Tag scan of raw source text and of rendered DOM serialisation (img, picture, video, audio, svg, canvas, object, embed, iframe, source, track); style scan for url(",
      rawSource: { mediaElements: count(snapshot.value, mediaRe), cssUrlReferences: count(snapshot.value, /url\(/gi) },
      renderedDom: { mediaElements: count(dom, mediaRe), cssUrlReferences: count(dom, /url\(/gi) },
    },
    method: "Static text scan by audit script; no target code executed", collectedAt: now,
    locator: `${R.path} (raw source and rendered DOM)`,
    limitations: ["Covers the raw source and the single rendered capture only"],
    sources: [snapshot.evidenceId, ids.rDom],
  });
  const schemaScan = (s) => ({
    jsonLdScripts: count(s, /<script[^>]+type\s*=\s*["']?application\/ld\+json/gi),
    microdataAttributes: count(s, /\sitem(scope|type|prop)\b/gi),
    rdfaAttributes: count(s, /\s(typeof|vocab|property)\s*=/gi),
  });
  add({
    id: ids.rSchema, itemId: R.itemId, kind: "schema-extraction", encoding: "json",
    value: {
      method: "Scan for JSON-LD script blocks, microdata attributes and RDFa attributes",
      rawSource: schemaScan(snapshot.value), renderedDom: schemaScan(dom),
    },
    method: "Static text scan by audit script; no target code executed", collectedAt: now,
    locator: `${R.path} (raw source and rendered DOM)`,
    limitations: ["Absence of structured data is an observation, not a defect; no feature-eligibility evidence was supplied"],
    sources: [snapshot.evidenceId, ids.rDom],
  });
  const renewal =
    "Owner/task statement supplied in the audit request (received 2026-11-18): \"Approved renewal task requires opening Billing and selecting Disable renewal.\" " +
    "Related owner statement: \"The render-ready signal is document.documentElement.dataset.auditReady === 'true'; the owner confirms it means the content has finished rendering.\" " +
    "No audience segment, market, plan version or effective date was supplied for this task.";
  add({
    id: ids.rAudience, itemId: R.itemId, kind: "audience-context", encoding: "utf8", value: renewal,
    method: "User/task statement preserved by host", collectedAt: now, locator: "Audit request text, 2026-11-18 (user statement)",
    limitations: [ownerNote, "Establishes the intended task only; audience identity, market and search-facing intent were not supplied"],
    sources: [snapshot.evidenceId],
  });
  add({
    id: ids.rClaims, itemId: R.itemId, kind: "claim-sources", encoding: "utf8", value: renewal,
    method: "User/task statement preserved by host", collectedAt: now, locator: "Audit request text, 2026-11-18 (user statement)",
    limitations: [ownerNote, "No effective date or version accompanies the approved task"],
    sources: [snapshot.evidenceId],
  });

  // ---- document.pdf ----
  const d = pdf.files["document.pdf"];
  if (!d.extraction || !d.sourceUnchanged) throw new Error("document.pdf extraction unavailable");
  const pages = d.extraction.pages.map((p) => ({ page: p.page, text: p.text }));
  const joined = pages.map((p) => p.text).join("\f");
  const extractor = {
    name: "Apple PDFKit (PDFDocument / PDFPage.string text layer) via Swift script audit-output/scripts/pdf-extract.swift",
    version: `macOS ${d.extraction.operatingSystem}; ${pdf.swiftVersion.stdout.split("\n")[0]}`,
  };
  const pdfMethod = `${extractor.name}; ${extractor.version}`;
  const pdfLimits = [
    "Native text-layer extraction; reading order as returned by PDFKit, not independently certified",
    "No OCR performed; text embedded only in images would not appear",
    "Fonts, layout, heading structure, metadata and HTTP headers are not represented in the text",
  ];
  add({
    id: ids.dManifest, itemId: D.itemId, kind: "extraction-provenance", encoding: "json",
    value: {
      schemaVersion: 1, sourceSha256: d.sourceSha256, sourceByteLength: d.sourceByteLength,
      extractor, pageCount: d.extraction.pageCount, pages, coverage: "complete", limitations: pdfLimits,
    },
    method: pdfMethod, collectedAt: d.completedAt, locator: `${D.path} (pages 1-${d.extraction.pageCount})`,
    limitations: pdfLimits, sources: [],
  });
  add({
    id: ids.dContent, itemId: D.itemId, kind: "content", encoding: "utf8", value: joined,
    method: pdfMethod, collectedAt: d.completedAt, locator: `${D.path} (pages 1-${d.extraction.pageCount}, joined with form feed)`,
    limitations: pdfLimits, sources: [ids.dManifest],
  });
  add({
    id: ids.dText, itemId: D.itemId, kind: "extracted-text", encoding: "utf8", value: joined,
    method: pdfMethod, collectedAt: d.completedAt, locator: `${D.path} (pages 1-${d.extraction.pageCount}, joined with form feed)`,
    limitations: pdfLimits, sources: [ids.dContent],
  });
  add({
    id: ids.dMedia, itemId: D.itemId, kind: "media-inventory", encoding: "json",
    value: {
      method: "Raw-byte scan of the PDF for image XObjects and PDFKit per-page annotation counts; plus reviewer's visual inspection of both pages through the host file reader",
      imageXObjects: d.rawHints.imageXObjects, fontObjects: d.rawHints.fontObjects,
      annotationsPerPage: d.extraction.pages.map((p) => ({ page: p.page, annotationCount: p.annotationCount })),
      reviewerVisualObservation: "Both pages show a heading and two short text lines; no image, diagram, chart or media was visible",
    },
    method: "Static byte scan by audit script and attributed reviewer visual inspection", collectedAt: now,
    locator: `${D.path} (pages 1-${d.extraction.pageCount})`,
    limitations: ["Vector drawing operators inside compressed content streams were not decoded; the visual observation is the reviewer's, not a tool measurement"],
    sources: [ids.dManifest],
  });
  const policy =
    "Owner/task statement supplied in the audit request (received 2026-11-18): \"Approved export policy: current VN plans support at most 5000 records per export, with no extra charge.\" " +
    "Related owner statement: \"English/Vietnamese pages may emphasize different aspects; completeness of translation is not a requirement.\" " +
    "No effective date was supplied beyond the word \"current\".";
  add({
    id: ids.dClaims, itemId: D.itemId, kind: "claim-sources", encoding: "utf8", value: policy,
    method: "User/task statement preserved by host", collectedAt: now, locator: "Audit request text, 2026-11-18 (user statement)",
    limitations: [ownerNote], sources: [ids.dContent],
  });
  add({
    id: ids.dEntity, itemId: D.itemId, kind: "entity-record", encoding: "utf8", value: policy,
    method: "User/task statement preserved by host", collectedAt: now, locator: "Audit request text, 2026-11-18 (user statement)",
    limitations: [ownerNote, "Covers the export limit, plan/market scope and charge only; no product or company identity record was supplied"],
    sources: [ids.dContent],
  });

  // ---- image-only.pdf (attempt record only; NOT submitted as extracted text) ----
  const im = pdf.files["image-only.pdf"];
  add({
    id: ids.iAttempt, itemId: I.itemId, kind: "extraction-attempt", encoding: "json",
    value: {
      sourceSha256: im.sourceSha256, sourceByteLength: im.sourceByteLength, sourceUnchanged: im.sourceUnchanged,
      extractor, attemptedAt: im.attemptedAt, completedAt: im.completedAt,
      pageCount: im.extraction?.pageCount ?? null,
      pages: (im.extraction?.pages ?? []).map((p) => ({ page: p.page, pdfKitStringIsNil: p.stringIsNil, numberOfCharacters: p.numberOfCharacters, annotationCount: p.annotationCount })),
      rawStructureHints: im.rawHints,
      outcome: "PDFKit opened the file and returned no text layer for its only page. The helper's recovery contract requires nonempty extracted text for every page, so the item stays unsupported.",
      ocr: "No OCR was run in this audit. The page is not shown to be blank: the raw structure contains image XObjects and no font objects.",
      extractionFailureDetail: im.failure ?? null,
    },
    method: pdfMethod, collectedAt: im.completedAt, locator: `${I.path} (page 1)`,
    limitations: [
      "Records an extraction attempt, not content; an empty text layer is not evidence of empty source content",
      "Raw structure hints are byte-pattern counts, not a decoded content inventory",
    ],
    sources: [],
  });

  const bundle = {
    reviews: [],
    evidence,
    artifacts,
    collectionRecoveries: [{
      itemId: D.itemId, manifestEvidenceId: ids.dManifest, contentEvidenceId: ids.dContent, textEvidenceId: ids.dText,
      reviewer, reviewedAt: now,
      reason: `PDFKit reported ${d.extraction.pageCount} pages and returned nonempty text-layer strings for both (page 1 English, page 2 Vietnamese); source SHA-256 and length were bound at extraction and the file was unchanged afterwards. Reviewer's visual reading of both pages matches the extracted lines. Text-layer only: no OCR, reading order not certified.`,
    }],
  };
  writeFileSync(path.join(out, "reviews", "review-02-evidence-and-recovery.json"), JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
  console.log(JSON.stringify({ written: "audit-output/reviews/review-02-evidence-and-recovery.json", evidence: evidence.map((e) => [e.evidenceId, e.kind]), builtAt: now }, null, 2));
} else if (mode === "semantic") {
  const rv = (itemId, ruleId, status, reason, evidenceIds) => ({ itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
  const C = snapshot.evidenceId;
  const basis = "Support is the owner-approved statement supplied in the audit request, not independent verification.";
  const reviews = [
    // render.html
    rv(R.itemId, "seo-rendering", "fail",
      "Raw source main#task reads 'Open Billing. Select Disable renewal.'; the rendered DOM captured in local headless Chrome after the owner-confirmed ready signal (dataset.auditReady === 'true') reads 'Open Billing.' only. The inline script replaces the text and removes the 'Select Disable renewal.' step. This is a local Chrome observation; no search-engine or AI-crawler rendering evidence was supplied.",
      [C, ids.rDom, ids.rReceipt]),
    rv(R.itemId, "quality-task-fit", "fail",
      "The approved renewal task requires opening Billing and selecting Disable renewal. The finished rendered page shows only 'Open Billing.', so a reader of the rendered page lacks the step needed to complete the task. The raw source contains both steps. Audience segment and market were not supplied; the verdict rests on the supplied task only.",
      [C, ids.rAudience, ids.rDom]),
    rv(R.itemId, "quality-claims", "pass",
      `Material instruction claims: raw source 'Open Billing. Select Disable renewal.' and rendered 'Open Billing.'. Each stated step agrees with the approved renewal task; no stated claim contradicts it. The rendered omission of the second step is an incompleteness recorded under quality-task-fit and seo-rendering, not a false claim. ${basis}`,
      [C, ids.rClaims, ids.rDom]),
    rv(R.itemId, "aeo-answer-evidence", "pass",
      `The page's procedural answer for the supplied renewal task consists of the steps above; each stated step is supported by the approved task in both surfaces. Completeness of the rendered answer is not covered by this rule and is recorded in the rendering finding; question coverage and answer context remain unknown without a question set. ${basis}`,
      [C, ids.rClaims, ids.rDom]),
    rv(R.itemId, "quality-accessible-media", "not-applicable",
      "The media inventory found zero media elements and zero CSS url() references in both the raw source and the rendered DOM; the item is text only, so there is no informative media needing a text alternative.",
      [C, ids.rMedia, ids.rDom]),
    rv(R.itemId, "seo-structured-data", "not-applicable",
      "No JSON-LD, microdata or RDFa is present in the raw source or in the rendered DOM, so there is no structured data to compare with visible claims. Absence is not treated as a defect; no feature-eligibility evidence was supplied.",
      [C, ids.rSchema, ids.rDom]),
    rv(R.itemId, "quality-freshness", "unknown",
      "Neither the page nor the supplied approved task states a version, market or effective date, so date/version applicability cannot be checked. The stated steps agree with the task as supplied on 2026-11-18.",
      [C, ids.rClaims]),
    rv(R.itemId, "seo-metadata", "unknown",
      "Observed: title 'Controlled render fixture', no meta description, no headings, in both surfaces. Whether this controlled fixture is meant to be search-facing and for which audience was not supplied, so metadata fit is not judged; recorded as an observation, not a finding.",
      [C, ids.rAudience, ids.rDom]),
    rv(R.itemId, "aio-retrievable-facts", "unknown",
      "The two surfaces disagree: the raw source contains both task steps, the rendered state only the first. Which surface a given retrieval system reads was not supplied or observed, and no target AI surface was named, so retrievability is unresolved rather than failed.",
      [C, ids.rAudience, ids.rDom]),
    // document.pdf
    rv(D.itemId, "quality-claims", "pass",
      `All material claims in the recovered text agree with the approved export policy: page 1 'A single export contains at most 5000 records.' and 'Applies to current VN plans.'; page 2 'Mỗi lần xuất tối đa 5000 bản ghi.' (at most 5000 records per export) and 'Không cần thanh toán thêm.' (no additional payment needed). The English page omits the charge and the Vietnamese page omits the plan scope; the owner states translation completeness is not required, so this is not a defect. ${basis} Text is a PDFKit text-layer extraction.`,
      [ids.dContent, ids.dClaims]),
    rv(D.itemId, "quality-freshness", "pass",
      `The only version/market qualifier in the content, 'Applies to current VN plans.', matches the scope of the approved policy ('current VN plans'), and the limit and charge statements match that current policy. Neither side gives an effective date; currency rests on the owner statement supplied 2026-11-18. ${basis}`,
      [ids.dContent, ids.dClaims]),
    rv(D.itemId, "aio-entity-consistency", "pass",
      `The export limit (5000 records per export), plan/market scope (current VN plans) and charge (none extra) stated across the English and Vietnamese pages are mutually consistent and consistent with the supplied approved record. No product or company identity record was supplied; the verdict covers the facts the record contains. ${basis}`,
      [ids.dContent, ids.dEntity]),
    rv(D.itemId, "aeo-answer-evidence", "pass",
      `The material answer claims present (maximum records per export, plan scope, no additional payment) are each supported by the approved export policy. Question coverage and answer context remain unknown without a question set. ${basis}`,
      [ids.dContent, ids.dClaims]),
    rv(D.itemId, "quality-accessible-media", "not-applicable",
      "The media inventory found no image XObjects and no annotations, and the reviewer's visual inspection of both pages showed text only, so there is no informative media needing a text alternative. Vector drawing operators were not decoded.",
      [ids.dContent, ids.dMedia]),
    rv(D.itemId, "portfolio-contradictions", "unknown",
      "Within this item the English and Vietnamese pages do not contradict each other or the approved policy. The cross-inventory comparison cannot be completed: image-only.pdf has no extracted content and no inventory map was built.",
      [ids.dContent, ids.dEntity]),
    rv(D.itemId, "seo-rendering", "unknown",
      "A PDF has no DOM capture in this audit; whether the file carries scripts or renders differently in a search or AI pipeline was not examined.",
      [ids.dContent]),
    // image-only.pdf
    rv(I.itemId, "quality-readable-text", "unknown",
      "PDFKit returned no text layer for the single page. That result was deliberately not submitted as extracted text: an empty extraction reflects the extractor's limits (no OCR) and is not proof that the page has no readable content. The raw structure contains image XObjects.",
      [ids.iAttempt]),
    rv(I.itemId, "quality-accessible-media", "unknown",
      "Raw structure hints indicate image XObjects and no font objects, so the page content is probably image-based, but no content or media inventory could be extracted. Whether the image carries informative text and whether a text alternative exists is unresolved.",
      [ids.iAttempt]),
  ];
  const findings = [{
    findingId: "render-drops-disable-renewal-step",
    title: "Rendered page drops the 'Select Disable renewal.' step that the source and the approved task contain",
    affectedItemIds: [R.itemId],
    ruleIds: ["seo-rendering", "quality-task-fit"],
    dimensions: ["seo", "quality"],
    evidenceIds: [C, ids.rDom, ids.rReceipt, ids.rAudience],
    severity: "high",
    confidence: "high",
    classification: "observed",
    action: "update",
    actionReason: "The page's inline script overwrites the complete instruction with a shorter one; the owner-approved task needs both steps. Proposal only; the audit does not change the target.",
    remediation: "In targets/render.html, change the inline script (or remove its text replacement) so that main#task still contains both steps, 'Open Billing.' and 'Select Disable renewal.', when the ready signal is set.",
    verification: "Load the revised page in a browser, wait until document.documentElement.dataset.auditReady === 'true' (string comparison), then confirm the text of main#task includes both 'Open Billing.' and 'Select Disable renewal.'. This confirms local rendering only, not how a search engine renders or indexes the page.",
    ownerRole: "Content owner with front-end developer",
    effort: "small",
  }];
  const bundle = { reviews, findings };
  writeFileSync(path.join(out, "reviews", "review-03-semantic.json"), JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
  console.log(JSON.stringify({ written: "audit-output/reviews/review-03-semantic.json", reviews: reviews.length, findings: findings.length, builtAt: now }, null, 2));
} else {
  throw new Error("mode must be evidence or semantic");
}
