// Read-only PDFKit text-layer extraction. Prints JSON to stdout. No OCR, no writes.
import Foundation
import PDFKit

let args = CommandLine.arguments
guard args.count == 2 else {
  FileHandle.standardError.write("usage: pdf-extract.swift FILE.pdf\n".data(using: .utf8)!)
  exit(2)
}
let url = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: url) else {
  FileHandle.standardError.write("PDFDocument could not open file\n".data(using: .utf8)!)
  exit(3)
}
var pages: [[String: Any]] = []
for i in 0..<doc.pageCount {
  var entry: [String: Any] = ["page": i + 1]
  if let page = doc.page(at: i) {
    let s = page.string
    entry["stringIsNil"] = (s == nil)
    entry["text"] = s ?? ""
    entry["numberOfCharacters"] = page.numberOfCharacters
    entry["annotationCount"] = page.annotations.count
    let box = page.bounds(for: .mediaBox)
    entry["mediaBox"] = [box.origin.x, box.origin.y, box.size.width, box.size.height]
  } else {
    entry["pageUnavailable"] = true
    entry["text"] = ""
  }
  pages.append(entry)
}
var attrs: [String: String] = [:]
if let a = doc.documentAttributes {
  for (k, v) in a { attrs["\(k)"] = "\(v)" }
}
let os = ProcessInfo.processInfo.operatingSystemVersionString
let out: [String: Any] = [
  "pageCount": doc.pageCount,
  "isEncrypted": doc.isEncrypted,
  "isLocked": doc.isLocked,
  "allowsCopying": doc.allowsCopying,
  "documentAttributes": attrs,
  "operatingSystem": os,
  "pages": pages,
]
let data = try JSONSerialization.data(withJSONObject: out, options: [.sortedKeys])
FileHandle.standardOutput.write(data)
