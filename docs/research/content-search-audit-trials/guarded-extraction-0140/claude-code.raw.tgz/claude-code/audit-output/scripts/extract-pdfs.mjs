// Runs the read-only PDFKit extractor on each declared PDF and saves raw results.
// Failures are recorded, not hidden. Source files are only read.
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const project = path.resolve(here, "..", "..");
const outDir = path.join(project, "audit-output", "captures");
mkdirSync(outDir, { recursive: true });
const sha = (b) => createHash("sha256").update(b).digest("hex");
const tool = (cmd, args) => {
  try {
    return { ok: true, stdout: execFileSync(cmd, args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 240000 }) };
  } catch (e) {
    return { ok: false, error: String(e.message), stderr: String(e.stderr ?? ""), status: e.status ?? null };
  }
};
const swiftVersion = tool("/usr/bin/swift", ["--version"]);
const swVers = tool("/usr/bin/sw_vers", []);
const results = { startedAt: new Date().toISOString(), swiftVersion, swVers, files: {} };
for (const name of ["document.pdf", "image-only.pdf"]) {
  const file = path.join(project, "targets", name);
  const before = readFileSync(file);
  const entry = {
    path: file,
    sourceSha256: sha(before),
    sourceByteLength: before.length,
    mtimeMsBefore: statSync(file).mtimeMs,
    attemptedAt: new Date().toISOString(),
    command: ["/usr/bin/swift", path.join(here, "pdf-extract.swift"), file],
  };
  const run = tool("/usr/bin/swift", [path.join(here, "pdf-extract.swift"), file]);
  entry.completedAt = new Date().toISOString();
  if (run.ok) {
    try {
      entry.extraction = JSON.parse(run.stdout);
    } catch (e) {
      entry.failure = { parse: String(e.message), stdout: run.stdout.slice(0, 2000) };
    }
  } else entry.failure = run;
  const after = readFileSync(file);
  entry.sourceUnchanged = sha(after) === entry.sourceSha256 && statSync(file).mtimeMs === entry.mtimeMsBefore;
  // Structural hints read from raw bytes only (latin1 view); not content evidence.
  const raw = before.toString("latin1");
  entry.rawHints = {
    header: raw.slice(0, 8),
    imageXObjects: (raw.match(/\/Subtype\s*\/Image/g) ?? []).length,
    fontObjects: (raw.match(/\/Type\s*\/Font\b/g) ?? []).length,
    textOperatorsUncompressed: (raw.match(/\bBT\b/g) ?? []).length,
    flateStreams: (raw.match(/\/FlateDecode/g) ?? []).length,
  };
  results.files[name] = entry;
}
results.finishedAt = new Date().toISOString();
writeFileSync(path.join(outDir, "pdf-extraction.json"), JSON.stringify(results, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(results, null, 2));
