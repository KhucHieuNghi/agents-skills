// Builds the quote ledger for audit-narrative.md from its "Verified quotations" table.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const project = path.resolve(here, "..", "..");
const sha = (b) => createHash("sha256").update(b).digest("hex");
const reportRel = "audit-output/audit-narrative.md";
const reportBytes = readFileSync(path.join(project, reportRel));
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const sources = {
  "render.html": "targets/render.html",
  "render-rendered-dom.txt": "audit-output/run-03-reviewed/evidence/render-rendered-dom.txt",
  "document-pdf-content.txt": "audit-output/run-03-reviewed/evidence/document-pdf-content.txt",
};
const quotes = [];
lines.forEach((line, index) => {
  const m = /^\| (Q\d+) \| ([^ |]+):(\d+) \| `(.*)` \|$/.exec(line);
  if (!m) return;
  const [, quoteId, label, lineNo, quote] = m;
  const source = sources[label];
  if (!source) throw new Error(`Unknown source label ${label}`);
  quotes.push({
    quoteId, source, sourceLabel: label,
    sourceHash: sha(readFileSync(path.join(project, source))),
    startLine: Number(lineNo), endLine: Number(lineNo),
    reportStartLine: index + 1, reportEndLine: index + 1,
    normalization: "exact", quote,
  });
});
if (quotes.length !== 7) throw new Error(`Expected 7 ledger rows, found ${quotes.length}`);
const bundle = { root: project, report: reportRel, reportHash: sha(reportBytes), quotes };
writeFileSync(path.join(project, "audit-output", "quotes.json"), JSON.stringify(bundle, null, 2) + "\n");
console.log(JSON.stringify({ written: "audit-output/quotes.json", quotes: quotes.map((q) => [q.quoteId, q.sourceLabel, q.startLine, q.reportStartLine]) }));
