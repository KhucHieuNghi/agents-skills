# Content audit — Content Search Audit

## Delivery summary

Partial\. 3 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:38:51\.415Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 4c98ffce\-f89d\-4744\-ad72\-ea7b79eaf27d\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 1 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 1 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 2 | 13 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | pending | Snapshot review incomplete | 26 |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | pending | Snapshot review incomplete | 26 |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | quality\-task\-fit | quality | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-audience\-context |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | quality\-claims | quality | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-claim\-source |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-claim\-source |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | quality\-accessible\-media | quality | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-media\-inventory |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | render\-rendered\-extracted\-text |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-metadata | seo | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-audience\-context |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-structured\-data | seo | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-schema\-extraction |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | seo\-rendering | seo | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-rendered\-dom |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aio\-retrievable\-facts | aio | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-audience\-context |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-claim\-source |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | render\-owner\-renewal\-task\-claim\-source |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 |
| 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph | 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867, render\-owner\-renewal\-task\-audience\-context |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | quality\-claims | quality | unknown | Semantic review and applicability assessment required | document\-owner\-export\-policy\-claim\-source, document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | quality\-freshness | quality | unknown | Semantic review and applicability assessment required | document\-owner\-export\-policy\-claim\-source, document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | quality\-accessible\-media | quality | unknown | Semantic review and applicability assessment required | document\-pdf\-content, document\-pdf\-media\-inventory |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | document\-pdf\-extracted\-text |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aio\-entity\-consistency | aio | unknown | Semantic review and applicability assessment required | document\-owner\-export\-policy\-entity\-record, document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | aeo\-answer\-evidence | aeo | unknown | Semantic review and applicability assessment required | document\-owner\-export\-policy\-claim\-source, document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations | document\-owner\-export\-policy\-claim\-source |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: inventory\-map | document\-owner\-export\-policy\-entity\-record, document\-pdf\-content |
| 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | document\-pdf\-content |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 19c3b57ecd1649b4fd7d882a57878c2bb7b7950a839db35af897f5608d3ea867 | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | local\-file | 2026\-11\-18T08:33:26\.142Z | 0 full elapsed days | [evidence/345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a\.txt](evidence/345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a.txt) | 675cf630d1f5de088d11ec9107b8be47eb07ec672f17c993913a44f2886f0d8c | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| render\-rendered\-dom | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | Local headless Google Chrome \(Chrome/157\.0\.8103\.79\) via DevTools protocol; fresh temporary profile; default browser sandbox; DNS mapped to NOTFOUND; captured after ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39; | 2026\-11\-18T08:35:12\.954Z | 0 full elapsed days | [evidence/render\-rendered\-dom\.txt](evidence/render-rendered-dom.txt) | da34baa0b65efbd8438c706acc72975ec92f20e2ab48aefde24fc7d6757c21b3 | Local headless Chrome rendering of a file: URL; not search\-engine or AI\-crawler rendering; Single capture at the owner\-confirmed ready signal; earlier transient states were not captured; The &\#39;&lt;\!doctype html&gt;&\#39; prefix was prepended by the capture script; the remainder is the browser&\#39;s serialisation |
| render\-capture\-receipt | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | Local headless Google Chrome \(Chrome/157\.0\.8103\.79\) via DevTools protocol; fresh temporary profile; default browser sandbox; DNS mapped to NOTFOUND; captured after ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39; | 2026\-11\-18T08:35:12\.954Z | 0 full elapsed days | [evidence/render\-capture\-receipt\.json](evidence/render-capture-receipt.json) | fdca5b9dcff9813fd479b31efbaa0d5508de35890d9e23aad624952cb28eae65 | Receipt authored by the audit capture script; not an independent attestation |
| render\-rendered\-extracted\-text | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | Local headless Google Chrome \(Chrome/157\.0\.8103\.79\) via DevTools protocol; fresh temporary profile; default browser sandbox; DNS mapped to NOTFOUND; captured after ready signal document\.documentElement\.dataset\.auditReady === &\#39;true&\#39;; document\.body\.innerText | 2026\-11\-18T08:35:12\.954Z | 0 full elapsed days | [evidence/render\-rendered\-extracted\-text\.txt](evidence/render-rendered-extracted-text.txt) | ca117db5ad1267b66ca8341827787ff0684718487e677baea400a3e2239e6d7d | Visible text of the rendered state only; the raw source text differs and is retained separately as content evidence; Nonempty text does not establish completeness or quality |
| render\-media\-inventory | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | Static text scan by audit script; no target code executed | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/render\-media\-inventory\.json](evidence/render-media-inventory.json) | c5ecb187035d00cf1c72f91698daaac525567d4bd867c72e9477b95d539622d4 | Covers the raw source and the single rendered capture only |
| render\-schema\-extraction | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | Static text scan by audit script; no target code executed | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/render\-schema\-extraction\.json](evidence/render-schema-extraction.json) | 057cdbfcee9f50e4d131842f2ce70e318fb4d9065dfc03bc6b9f12227da71f0f | Absence of structured data is an observation, not a defect; no feature\-eligibility evidence was supplied |
| render\-owner\-renewal\-task\-audience\-context | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | User/task statement preserved by host | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/render\-owner\-renewal\-task\-audience\-context\.txt](evidence/render-owner-renewal-task-audience-context.txt) | 0fcbc88ead7f79b3f2497234c190a92527e0bcadccb2d9b8262d118fa97d4a91 | Owner/task statement supplied in the audit request; an approved comparison basis for this audit, not independently verified platform behaviour or a public source; Establishes the intended task only; audience identity, market and search\-facing intent were not supplied |
| render\-owner\-renewal\-task\-claim\-source | 345187015bbf9b892c65e39c3cb49fe57c7f35b2cd83d474740980df887f988a | User/task statement preserved by host | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/render\-owner\-renewal\-task\-claim\-source\.txt](evidence/render-owner-renewal-task-claim-source.txt) | 0fcbc88ead7f79b3f2497234c190a92527e0bcadccb2d9b8262d118fa97d4a91 | Owner/task statement supplied in the audit request; an approved comparison basis for this audit, not independently verified platform behaviour or a public source; No effective date or version accompanies the approved task |
| document\-pdf\-extraction\-manifest | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | Apple PDFKit \(PDFDocument / PDFPage\.string text layer\) via Swift script audit\-output/scripts/pdf\-extract\.swift; macOS Version 26\.3 \(Build 25D125\); Apple Swift version 6\.2 \(swiftlang\-6\.2\.0\.19\.9 clang\-1700\.3\.19\.1\) | 2026\-11\-18T08:35:10\.414Z | 0 full elapsed days | [evidence/document\-pdf\-extraction\-manifest\.json](evidence/document-pdf-extraction-manifest.json) | 4562d3d22bb5b86be81a5f5f723bf4f2eee0b9269707e8b8fe30d6185b50466a | Native text\-layer extraction; reading order as returned by PDFKit, not independently certified; No OCR performed; text embedded only in images would not appear; Fonts, layout, heading structure, metadata and HTTP headers are not represented in the text |
| document\-pdf\-content | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | Apple PDFKit \(PDFDocument / PDFPage\.string text layer\) via Swift script audit\-output/scripts/pdf\-extract\.swift; macOS Version 26\.3 \(Build 25D125\); Apple Swift version 6\.2 \(swiftlang\-6\.2\.0\.19\.9 clang\-1700\.3\.19\.1\) | 2026\-11\-18T08:35:10\.414Z | 0 full elapsed days | [evidence/document\-pdf\-content\.txt](evidence/document-pdf-content.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native text\-layer extraction; reading order as returned by PDFKit, not independently certified; No OCR performed; text embedded only in images would not appear; Fonts, layout, heading structure, metadata and HTTP headers are not represented in the text |
| document\-pdf\-extracted\-text | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | Apple PDFKit \(PDFDocument / PDFPage\.string text layer\) via Swift script audit\-output/scripts/pdf\-extract\.swift; macOS Version 26\.3 \(Build 25D125\); Apple Swift version 6\.2 \(swiftlang\-6\.2\.0\.19\.9 clang\-1700\.3\.19\.1\) | 2026\-11\-18T08:35:10\.414Z | 0 full elapsed days | [evidence/document\-pdf\-extracted\-text\.txt](evidence/document-pdf-extracted-text.txt) | 462a86501dfdbe5aef72a590c8f7c9dd2d2532650d59488020f6a5df11ab4e09 | Native text\-layer extraction; reading order as returned by PDFKit, not independently certified; No OCR performed; text embedded only in images would not appear; Fonts, layout, heading structure, metadata and HTTP headers are not represented in the text |
| document\-pdf\-media\-inventory | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | Static byte scan by audit script and attributed reviewer visual inspection | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/document\-pdf\-media\-inventory\.json](evidence/document-pdf-media-inventory.json) | 3025501cd51c3e2f92f07874e2042a6fd07a99b146170043f2b9204bbd679b8e | Vector drawing operators inside compressed content streams were not decoded; the visual observation is the reviewer&\#39;s, not a tool measurement |
| document\-owner\-export\-policy\-claim\-source | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | User/task statement preserved by host | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/document\-owner\-export\-policy\-claim\-source\.txt](evidence/document-owner-export-policy-claim-source.txt) | 894a826adf1ff28ba6ad722dc7e8ceb5c1151d3c6536e9c376be247752c4cde9 | Owner/task statement supplied in the audit request; an approved comparison basis for this audit, not independently verified platform behaviour or a public source |
| document\-owner\-export\-policy\-entity\-record | 8902ce16ac2e0580ff7e887d5d32eaee360e9defea42b42027bf297f277893b3 | User/task statement preserved by host | 2026\-11\-18T08:38:42\.320Z | 0 full elapsed days | [evidence/document\-owner\-export\-policy\-entity\-record\.txt](evidence/document-owner-export-policy-entity-record.txt) | 894a826adf1ff28ba6ad722dc7e8ceb5c1151d3c6536e9c376be247752c4cde9 | Owner/task statement supplied in the audit request; an approved comparison basis for this audit, not independently verified platform behaviour or a public source; Covers the export limit, plan/market scope and charge only; no product or company identity record was supplied |
| image\-only\-pdf\-extraction\-attempt | 8cf6a905bc7fef532f88fe4564444d2edcf337f548edc400e7dde33461104a36 | Apple PDFKit \(PDFDocument / PDFPage\.string text layer\) via Swift script audit\-output/scripts/pdf\-extract\.swift; macOS Version 26\.3 \(Build 25D125\); Apple Swift version 6\.2 \(swiftlang\-6\.2\.0\.19\.9 clang\-1700\.3\.19\.1\) | 2026\-11\-18T08:35:10\.759Z | 0 full elapsed days | [evidence/image\-only\-pdf\-extraction\-attempt\.json](evidence/image-only-pdf-extraction-attempt.json) | e29f9da577d85d438fc364df2777e88e8aeae8d81bc1c09f3cd78bc980e67d5a | Records an extraction attempt, not content; an empty text layer is not evidence of empty source content; Raw structure hints are byte\-pattern counts, not a decoded content inventory |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
