# Content search audit narrative

Audit date: 2026-11-18. Final validated revision: `run-03-reviewed` (run 5acb8274-49a9-47e0-9e1d-cdd92822b782).
This narrative supplements the helper-generated reports; counts below are copied from the validator receipt `validate-run-03-reviewed.json`.

## Summary

**The audit is partial: 3 declared items, 0 fully audited, 2 pending, 1 unsupported, 0 failed, 0 blocked, 0 excluded.** The validator reports `valid: true` and `completionAllowed: false`.

- **One actual defect.** `render.html` loses its second instruction when rendered. The source says to open Billing and select Disable renewal; the finished rendered page says only to open Billing. The approved renewal task needs both steps.
- **One clean item on the checks that could be assessed.** `document.pdf` states the export limit, plan scope and charge consistently with the approved export policy, in English and Vietnamese.
- **One item not assessed.** `image-only.pdf` has no text layer that PDFKit can extract. Its content is unknown, not empty.
- **13 of 78 planned checks are resolved; 65 remain unknown**, mostly because no HTTP, index, crawler, question-set, analytics or AI-observation evidence was supplied.

No search-engine rendering, indexing, analytics, AI observation or feature-eligibility evidence was supplied, so nothing here measures search or AI visibility.

## Scope and coverage

The declared inventory in `config.json` is complete (`inventoryComplete: true`) and has three local files. All three are in every revision.

| Item | File | State in final revision | Checks resolved | Checks unknown |
| --- | --- | --- | --- | --- |
| 345187015bbf… | `targets/render.html` | pending | 7 of 26 | 19 |
| 8902ce16ac2e… | `targets/document.pdf` | pending (recovered from unsupported) | 6 of 26 | 20 |
| 8cf6a905bc7f… | `targets/image-only.pdf` | unsupported | 0 of 26 | 26 |

An item counts as fully audited only when all 26 required checks resolve. None does, so "audited" is 0 even though two files were read, extracted and reviewed.

Revisions, each preserved unchanged:

| Revision | What it holds | Validated coverage |
| --- | --- | --- |
| `run-01-initial` | Helper `start`: raw HTML snapshot, both PDFs unsupported, no verdicts | 0 audited, 1 pending, 2 unsupported |
| `run-02-evidence-recovery` | Rendered DOM, PDF recovery for `document.pdf`, owner context, extraction attempt record | 0 audited, 2 pending, 1 unsupported |
| `run-03-reviewed` | Semantic verdicts and the one finding | 0 audited, 2 pending, 1 unsupported |

## Verified quotations

Each row is checked by the helper's quote verifier against the cited file and line (`quote-receipt.json`).

| # | Locator | Quotation |
| --- | --- | --- |
| Q1 | render.html:1 | `<main id="task">Open Billing. Select Disable renewal.</main>` |
| Q2 | render.html:1 | `document.getElementById('task').textContent = 'Open Billing.';` |
| Q3 | render-rendered-dom.txt:1 | `<main id="task">Open Billing.</main>` |
| Q4 | document-pdf-content.txt:2 | `A single export contains at most 5000 records.` |
| Q5 | document-pdf-content.txt:3 | `Applies to current VN plans.` |
| Q6 | document-pdf-content.txt:4 | `Mỗi lần xuất tối đa 5000 bản ghi.` |
| Q7 | document-pdf-content.txt:5 | `Không cần thanh toán thêm.` |

`render.html` is `targets/render.html`. The other two files are in `run-03-reviewed/evidence/`. `render-rendered-dom.txt` is the browser's serialised DOM, not the source file. `document-pdf-content.txt` is the PDFKit text-layer extraction; line 3 also carries the page break and the Vietnamese heading, because pages are joined with a form feed rather than a newline.

## Actual defect

### Finding `render-drops-disable-renewal-step` (high severity, high confidence, observed)

Affected item: `targets/render.html`. Failed checks: `seo-rendering`, `quality-task-fit`.

- **Observation.** The source contains both steps (Q1). An inline script then replaces that text (Q2) and sets the ready signal. The DOM captured after the ready signal contains only the first step (Q3). The captured visible body text was "Open Billing." and `dataset.auditReady` was the string "true".
- **Why it is a defect.** The owner's approved renewal task requires opening Billing and selecting Disable renewal. The owner confirms the ready signal means rendering has finished, so the shortened text is the final state, not a transient one. A reader of the rendered page is not told to select Disable renewal.
- **Limits.** This is one capture in local headless Chrome 157 from a `file:` URL. It does not show how any search engine or AI crawler renders or indexes the page. A system that reads raw HTML would see both steps; one that renders would see one. Which applies is unknown, so `aio-retrievable-facts` stays unknown rather than failed.
- **Proposed change (not made).** Change or remove the script's text replacement so `main#task` still contains both steps when the ready signal is set.
- **Verification.** Load the revised page in a browser, wait until `document.documentElement.dataset.auditReady === 'true'` (a string comparison), then confirm `main#task` contains both steps.

Severity is my judgment: the page's only task instruction is cut in half. It is not a ranking or traffic estimate.

## Clean checks

### `targets/document.pdf`

Recovered text: two pages, English then Vietnamese. Compared with the approved export policy (current VN plans support at most 5000 records per export, with no extra charge):

| Claim | Locator | Verdict against approved policy |
| --- | --- | --- |
| Maximum of 5000 records per export, English | Q4 | Supported |
| Scope is current VN plans, English | Q5 | Supported |
| Maximum of 5000 records per export, Vietnamese | Q6 | Supported |
| No additional payment needed, Vietnamese | Q7 | Supported |

- `quality-claims`, `quality-freshness`, `aio-entity-consistency` and `aeo-answer-evidence` pass. `quality-readable-text` passes deterministically (nonempty extraction). `quality-accessible-media` is not applicable: no images or annotations were found.
- The English page does not mention the charge and the Vietnamese page does not mention the plan scope. The owner states the two languages may emphasise different aspects and translation completeness is not required, so this is **not a defect** and no finding was raised.
- The two pages do not contradict each other. The inventory-wide contradiction check stays unknown because `image-only.pdf` could not be read.
- These passes rest on the owner-approved policy supplied in the audit request. That is an approved comparison basis, not independent verification, and it carries no effective date beyond "current".

### `targets/render.html`

- `quality-claims` and `aeo-answer-evidence` pass: every step the page states, in source and rendered form, agrees with the approved task. The missing step is an omission, recorded once in the finding above, not a false claim.
- `quality-readable-text` passes deterministically: the rendered visible text is nonempty. That says nothing about completeness.
- `quality-accessible-media` and `seo-structured-data` are not applicable: neither the source nor the rendered DOM contains media or structured data. Absence of structured data is not a defect.

## Unknown checks and unavailable evidence

| Evidence not supplied or not obtainable | Checks left unknown | Items |
| --- | --- | --- |
| HTTP responses, publisher intent, canonical targets | `seo-response`, `seo-index-controls`, `seo-canonical` | all 3 |
| Crawler policy | `aio-crawler-policy` | all 3 |
| Question set | `aeo-question-coverage`, `aeo-answer-context`, `portfolio-task-gaps` | all 3 |
| AI response observations | `geo-observed-presence`, `geo-answer-accuracy`, `geo-cohort-validity` | all 3 |
| Link graph, locale map, inventory map | `seo-internal-links`, `seo-locales`, `portfolio-duplication`, `portfolio-contradictions`, `portfolio-journey-links` | all 3 |
| Audience and search-facing intent | `seo-metadata`, `aio-retrievable-facts` (both PDFs also `quality-task-fit`) | see note |
| Version or effective date for the renewal task | `quality-freshness` | `render.html` |
| Entity record for the renewal task | `aio-entity-consistency` | `render.html` |
| DOM or script evidence for a PDF | `seo-rendering` | both PDFs |
| Any extracted content | all 26 checks | `image-only.pdf` |

Notes:

- `seo-metadata` on `render.html`: the title is "Controlled render fixture" and there is no description or heading. Whether this fixture is meant to be search-facing was not supplied, so this is an observation, not a finding.
- No audience or task was supplied for the export policy, so `quality-task-fit` on `document.pdf` stays unknown.
- Search Console, GA4, Bing, server-log and AI-observation measurements are unavailable. They are unknown, not zero.

## Extraction and recovery record

| Step | Capability | Outcome |
| --- | --- | --- |
| Rendered DOM of `render.html` | Installed Google Chrome 157.0.8103.79, headless, fresh temporary profile, default sandbox, DNS mapped to NOTFOUND | Succeeded. Ready signal observed; only the fixture's own `file:` URL was requested; profile removed afterwards |
| Text of `document.pdf` | macOS 26.3 PDFKit text layer through a Swift script | Succeeded. 2 pages, both nonempty. Recovered through the helper with a byte-bound manifest |
| Text of `image-only.pdf` | Same PDFKit script | Opened; 1 page; no text layer returned. Recovery not permitted |

- All three target files had the same SHA-256 before and after capture. Nothing in `targets/` or the installed skill was modified. No external URL was fetched and no tool was installed.
- No target script was run outside the authorised browser.
- **`image-only.pdf` detail.** PDFKit returned no string for its only page. A byte scan shows 2 image objects and no font objects, so the page is not shown to be blank. I did not submit the empty result as extracted text, because the helper would then record a deterministic "empty text" failure that the evidence does not support. I did not run OCR; that was my choice of scope, not a missing capability I tested for. Viewed through the host file reader, the page shows one line of rendered text; I have not transcribed it as evidence.
- The `document.pdf` extraction is text-layer only. Reading order is as PDFKit returned it; my visual reading of both pages matched the extracted lines, including Vietnamese diacritics.

## Recovery steps to reach fuller coverage

1. **`image-only.pdf`.** Supply an owner transcript, or authorise an OCR extractor. Then submit a new recovery with nonempty text for the page, labelled as OCR or transcript, and review its 26 checks. Re-run the inventory-wide portfolio checks afterwards.
2. **`render.html`.** After the owner fixes the script, start a fresh run or resume, re-capture the rendered DOM and re-review `seo-rendering` and `quality-task-fit`.
3. **Context for unknown checks.** Supply the intended audience and question set, publisher intent on indexing, and, if the items are published, their URLs with HTTP responses, canonical and locale declarations and crawler policy.
4. **Measurement.** Supply Search Console, analytics or AI response observations if visibility is to be assessed. None can be inferred from this audit.

## Files

- Helper reports, final revision: `run-03-reviewed/report.html`, `run-03-reviewed/report.md`, `run-03-reviewed/content-actions.csv`, `run-03-reviewed/coverage.json`, `run-03-reviewed/delivery-summary.md`
- Earlier revisions: `run-01-initial/`, `run-02-evidence-recovery/`
- Validator receipts: `validate-run-01-initial.json`, `validate-run-03-reviewed.json`
- Review bundles: `reviews/review-02-evidence-and-recovery.json`, `reviews/review-03-semantic.json`
- Raw captures: `captures/pdf-extraction.json`, `captures/render-capture-2026-11-18T08-35-11-771Z.json`
- Scripts used: `scripts/`
- Quote ledger and receipt: `quotes.json`, `quote-receipt.json`
