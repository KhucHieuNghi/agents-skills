from pathlib import Path
import sys,json,hashlib,tarfile
b=Path(__file__).resolve().parent
r=Path((b/'workspace.txt').read_text())
h=sys.argv[1]
c=r/'native-extraction-0131'
d=Path('docs/research/content-search-audit-trials/guarded-extraction-0140')
d.mkdir(parents=True,exist_ok=True)
files={}; excluded={}
for f in (c/h).rglob('*'):
 if not f.is_file(): continue
 n=str(f.relative_to(c))
 if 'swift-cache' in f.parts or 'chrome-profile' in f.parts:
  excluded[n]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()};continue
 files[n]=f
for f in c.glob(h+'.*'):
 if f.is_file():files[f.name]=f
for f in r.glob(h+'-*'):
 if f.is_file():files[f.name]=f
for f in r.glob(h+'*.settings.json'):files[f.name]=f
for f in b.iterdir():
 if f.is_file() and (not f.name.startswith(('codex.','claude-code.')) or f.name.startswith(h+'.')):files['author/'+f.name]=f
archive=d/(h+'.raw.tgz')
if archive.exists():raise ValueError('Refusing archive overwrite')
with tarfile.open(archive,'w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n)
m={'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(f.read_bytes()).hexdigest() for n,f in files.items()},'excludedReproducibleCacheFiles':excluded}
with tarfile.open(archive) as t:
 for x in t:
  if x.isfile():assert hashlib.sha256(t.extractfile(x).read()).hexdigest()==m['files'][x.name]
(d/(h+'.manifest.json')).write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'host':h,'members':len(files),'excludedCacheFiles':len(excluded),'bytes':archive.stat().st_size}))
