# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:19:25\.363Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run f2af37f7\-a23a\-4a66\-8d66\-16c973948803\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-locales | seo | unknown | Missing required evidence: locale\-map | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-locales | seo | unknown | Missing required evidence: locale\-map | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |
| eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2540b11873c2da3cc201186084f67143d55e33206e66661e1b3b526c7373194d | 15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652 | local\-file | 2026\-11\-16T17:19:25\.339Z | 0 full elapsed days | [evidence/15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652\.txt](evidence/15504dcc5ab98daa558a8ec6636066145bbcf4232475578af452b2d4b6f72652.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c010b61531ac328c01c59ec71869f282bdec2bae9b9bdb9eb4886e53e6fd3bf9 | 1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa | local\-file | 2026\-11\-16T17:19:25\.340Z | 0 full elapsed days | [evidence/1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa\.txt](evidence/1f7ad0cf5a81afc3c85c8ae0ceff84750ae28b70e9de3da2aea45abe44951eaa.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| daca08195ca68c3e1466be4f3d919d9b2b8c6d9e27726c35d09737c1a68f1c5d | 25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca | local\-file | 2026\-11\-16T17:19:25\.341Z | 0 full elapsed days | [evidence/25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca\.txt](evidence/25da4d417f7540ce9ac3bad21a94b072069a7cd9034d16252534023ecde96dca.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c9e30865b5cb2afd0ad903f7fe144ff229ab69473256f54cb810d192deb21168 | 2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd | local\-file | 2026\-11\-16T17:19:25\.341Z | 0 full elapsed days | [evidence/2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd\.txt](evidence/2affd3f3ab972f79e950d1ab5e969c07b7a5e4bfe7f9bdcb417861f62e36b2bd.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 5bd055800d9d811ce337175477d7f184eb58f1f08d388d481a2d5bf51d666e79 | 5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0 | local\-file | 2026\-11\-16T17:19:25\.342Z | 0 full elapsed days | [evidence/5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0\.txt](evidence/5454b32ab92926422fa2c4a0806d328fb31a598f8019681906ade59dd3406fc0.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 0540e782b6bccbdf232cb7b6df787ca5eca52c49776ee9ecb32b154b2fd270f6 | 9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745 | local\-file | 2026\-11\-16T17:19:25\.343Z | 0 full elapsed days | [evidence/9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745\.txt](evidence/9488fb4ab036c0edfb10dfe2d3329ceffcd0d1f6019742a8171fae0b0deea745.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| cf5837e718a494c18b1949e4509e52f0bc02fb57a0def594aa7f77ce42ea3d5d | 9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0 | local\-file | 2026\-11\-16T17:19:25\.343Z | 0 full elapsed days | [evidence/9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0\.txt](evidence/9688c6e43457816db80061553dc6288f63252adc0375470540c2b42e2b712ac0.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| da7cdebcaeffdd0fb44e20442600feb524cac6cca7e274327fa3132660d9103c | ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e | local\-file | 2026\-11\-16T17:19:25\.344Z | 0 full elapsed days | [evidence/ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e\.txt](evidence/ce8dc1b3fd023057faa041757ee7dbff9a3ab11e511abd0ca2d25963a6b2514e.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 214d8205f12270ef75a488d21640d3b9804a23cf0181907c2ca8ac775cd8e275 | d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1 | local\-file | 2026\-11\-16T17:19:25\.344Z | 0 full elapsed days | [evidence/d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1\.txt](evidence/d9ef83a0f75d2104314e89c91e42148999a9c69735dfa63a0a87dcc1c56c42e1.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 8012d0709a2036913573718625938211f9584fbf9c7d662965378445f87ababe | eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249 | local\-file | 2026\-11\-16T17:19:25\.345Z | 0 full elapsed days | [evidence/eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249\.txt](evidence/eade1f2dc4ca2b2c5645ef8f03573af301322a68ba758189928ecc80b4cd1249.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
