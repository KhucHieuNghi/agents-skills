import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const [R] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = readFileSync(R + "/report.md");
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const quotes = [];
const unmatched = [];
// Every report line that starts a bullet with a `file.md:N` locator is a quotation line.
const re = /^- `(\d\d-[a-z-]+\.md):(\d+)` — (?:"(.*)"|`(.*)`)$/u;
lines.forEach((line, i) => {
  if (!/^- `\d\d-[a-z-]+\.md:\d+`/.test(line) && !/`\d\d-[a-z-]+\.md:\d+` — /.test(line)) return;
  let m = re.exec(line);
  if (!m) { const m2 = /`(\d\d-[a-z-]+\.md):(\d+)` — (?:"([^"]*)"|`([^`]*)`)/u.exec(line); if (!m2) { unmatched.push(i + 1); return; } m = m2; }
  const src = "targets/" + m[1];
  quotes.push({ quoteId: `q${quotes.length + 1}-${m[1]}-${m[2]}`, source: src, sourceLabel: m[1], sourceHash: hash(readFileSync(R + "/" + src)),
    startLine: +m[2], endLine: +m[2], reportStartLine: i + 1, reportEndLine: i + 1, normalization: "exact", quote: m[3] ?? m[4] });
});
writeFileSync(R + "/audits/content-search/work/quotes.json", JSON.stringify({ root: R, report: "report.md", reportHash: hash(reportBytes), quotes }, null, 2) + "\n");
console.log("quotes", quotes.length, "unmatched lines", unmatched);
// all locator mentions in report, for manual reconciliation
const all = lines.flatMap((l, i) => [...l.matchAll(/\d\d-[a-z-]+\.md:\d+/g)].map((x) => (i + 1) + ":" + x[0]));
console.log("locator mentions", all.length);
