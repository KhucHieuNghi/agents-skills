import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
const [R] = process.argv.slice(2);
const D = R + "/audits/content-search/run-01-start";
const L = (f) => readFileSync(D + "/" + f, "utf8").trim().split("\n").map(JSON.parse);
const inv = L("inventory.jsonl"), ev = L("evidence.jsonl");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const now = new Date().toISOString();
const reviewer = "claude-agent (content-search-audit host review)";
const item = (n) => inv.find((i) => i.path && i.path.endsWith("/targets/" + n));
const snap = (n) => ev.find((e) => e.itemId === item(n).itemId && e.kind === "content");
const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const LIM = "Derived by the reviewer from the supplied synthetic dossier text; it is attributed owner/task context, not an independently verified live observation.";
function add(n, id, kind, locatorLines, value, extraLim = []) {
  const s = snap(n), json = typeof value !== "string";
  const bytes = json ? JSON.stringify(value, null, 2) + "\n" : value;
  const artifact = `evidence/${id}.${json ? "json" : "txt"}`;
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({ ...s, evidenceId: id, kind, method: "reviewer-derived-from-supplied-dossier", collectedAt: now,
    locator: `targets/${n}:${locatorLines}`, artifact, encoding: json ? "json" : "utf8", value,
    snapshotHash: hash(bytes), byteLength: Buffer.byteLength(bytes), limitations: [LIM, ...extraLim], sourceEvidenceIds: [s.evidenceId] });
  return id;
}
function rev(n, ruleId, status, reason, ids) {
  bundle.reviews.push({ itemId: item(n).itemId, ruleId, status, reason, evidenceIds: status === "unknown" ? (ids ?? []) : [snap(n).evidenceId, ...ids], reviewer, reviewedAt: now });
}
const sid = (n) => snap(n).evidenceId;

// 01
let f = "01-visibility.md";
const a1 = add(f, "d01-http-response", "http-response", "4-5", { status: 200, url: "https://store.example.invalid/product", capturedAt: "2026-11-10T08:00:00Z", headers: { "x-robots-tag": "noindex" }, provenance: "Transcribed from dossier lines 4-5; not fetched by this audit." }, ["Only the status and one response header are described in the dossier; full headers and body were not supplied."]);
const a2 = add(f, "d01-publisher-intent", "publisher-intent", "3", "Supplied publisher intent (01-visibility.md:3): this public product page should be eligible for Google indexing.");
const a3 = add(f, "d01-crawler-policy", "crawler-policy", "5", "Supplied crawler policy statement (01-visibility.md:5): Robots.txt permits Googlebot access to /product.", ["The robots.txt file itself was not supplied; only this statement about Googlebot. No other crawler or AI user agent is described."]);
const a4 = add(f, "d01-canonical-targets", "canonical-targets", "4-6", "Declared canonical in raw HTML head (01-visibility.md:6): https://store.example.invalid/product. Captured URL (01-visibility.md:4): https://store.example.invalid/product, HTTP 200. No other variants supplied.", ["Engine-selected canonical is not observed."]);
rev(f, "seo-index-controls", "fail", "The supplied response header carries X-Robots-Tag: noindex while the raw HTML meta robots says index,follow and the publisher intends the page to be eligible for Google indexing. The header directive conflicts with the stated intent. Actual index status is not observed.", [a1, a2]);
rev(f, "seo-canonical", "pass", "The declared canonical equals the captured URL that returned HTTP 200, and no competing variant is supplied. This is declaration consistency only; engine-selected canonical is not observed.", [a4]);
rev(f, "aio-crawler-policy", "pass", "Assessed for the only stated surface, Google Search indexing: the supplied statement says robots.txt permits Googlebot access to /product, which is consistent with the indexing intent at the crawl-access layer. The separate noindex header conflict is recorded under seo-index-controls. No intent or policy for other crawlers or AI surfaces is supplied.", [a3, a2]);

// 02
f = "02-route.md";
const b1 = add(f, "d02-http-old", "http-response", "5", { status: 301, url: "https://store.example.invalid/old", location: "https://store.example.invalid/new", provenance: "Transcribed from dossier line 5; not fetched by this audit." });
const b2 = add(f, "d02-http-new", "http-response", "6", { status: 301, url: "https://store.example.invalid/new", location: "https://store.example.invalid/old", provenance: "Transcribed from dossier line 6; not fetched by this audit." });
const b3 = add(f, "d02-canonical-targets", "canonical-targets", "3-7", "Intended target (02-route.md:3): /old should redirect once to an accessible /new product page. Sitemap preference (02-route.md:7): an older sitemap export lists /new as the preferred URL. Observed targets (02-route.md:5-6): /old -> 301 -> /new and /new -> 301 -> /old.", ["The older sitemap export itself was not supplied.", "No final successful response or engine-selected canonical is available."]);
rev(f, "seo-canonical", "fail", "The preferred URL /new (publisher intent and older sitemap export) does not resolve: the captured responses redirect /old to /new and /new back to /old, so neither URL reaches a final response in the supplied capture. Engine-selected canonical is not observed.", [b3, b1, b2]);

// 03
f = "03-offer.md";
const c1 = add(f, "d03-schema-extraction", "schema-extraction", "7-19", { "@context": "https://schema.org", "@type": "Product", name: "Example plan", offers: { "@type": "Offer", price: "19", priceCurrency: "USD", url: "https://store.example.invalid/plan" } }, ["Extracted from the complete JSON-LD block supplied in the dossier; rendered DOM not supplied."]);
const c2 = add(f, "d03-entity-record", "entity-record", "3-4", "Publisher-confirmed entity record (03-offer.md:3-4): Example plan, United States monthly billing, USD 29 before taxes; the publisher confirms this visible US monthly price is the current policy.");
rev(f, "seo-structured-data", "fail", "The supplied JSON-LD Offer states price 19 USD while the visible content for the same page, market and capture time states USD 29 before taxes, which the publisher confirms as current. Structured data does not match the visible claim. Rich-result eligibility and appearance are not assessed.", [c1]);
rev(f, "aio-entity-consistency", "fail", "The machine-readable price (19 USD) conflicts with the publisher-confirmed entity record (USD 29 before taxes, US monthly billing) for the same plan on the same page.", [c2, c1]);
rev(f, "quality-claims", "unknown", "The visible price claim matches the publisher-confirmed policy and is clean. The item also contains a contradicted machine-readable price, recorded under seo-structured-data and aio-entity-consistency, so no item-wide pass is asserted.", []);

// 04
f = "04-policy.md";
const d1 = add(f, "d04-entity-record", "entity-record", "3-6", "Supplied entity scope (04-policy.md:3): both pages describe the same Starter plan, market, monthly billing period and policy version 2026-10-01. Both pages are labeled current (04-policy.md:6). Authoritative entitlement value: unavailable (04-policy.md:6).", ["The authoritative entitlement table is unavailable, so this record establishes shared scope only, not the correct value."]);
const d2 = add(f, "d04-inventory-map", "inventory-map", "4-5", "Component pages within this dossier: /product (04-policy.md:4) and /blog/starter-guide (04-policy.md:5). Both state the Starter storage entitlement.", ["Only two one-line excerpts are supplied; the full pages are not."]);
rev(f, "portfolio-contradictions", "fail", "/product states 1000 storage units per month and /blog/starter-guide states 1500 for the same plan, market, billing period and policy version, with both labeled current. The two claims cannot both be correct. Which value is correct is unresolved because the authoritative entitlement table is unavailable.", [d1, d2]);
rev(f, "aio-entity-consistency", "fail", "The same Starter entitlement is stated as 1000 and 1500 storage units per month across two current pages with identical scope. The correct value is unresolved.", [d1]);
rev(f, "quality-claims", "unknown", "At least one of the two storage claims is wrong, but neither can be verified because the authoritative entitlement table is unavailable.", []);
rev(f, "portfolio-duplication", "unknown", "No query/page performance export is supplied; overlap or cannibalization between /product and /blog/starter-guide cannot be assessed.", []);

// 05
f = "05-huong-dan.md";
const e1 = add(f, "d05-claim-sources", "claim-sources", "5", "Chính sách hiện hành được cung cấp (05-huong-dan.md:5): Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.", ["The separate fee table for other tiers is not supplied.", "The policy carries no effective date in the dossier."]);
rev(f, "quality-claims", "fail", "The draft says all customers get free ticket changes with no advance notice. The supplied current policy limits free changes to the Thành viên tier and requires the request at least 24 hours before departure; other tiers pay fees from a separate table.", [e1]);
rev(f, "aeo-answer-evidence", "fail", "The draft's answer on who may change tickets free of charge and with what notice is contradicted by the supplied current policy on both eligibility and the 24-hour notice condition.", [e1]);

// 06
f = "06-render.md";
rev(f, "seo-rendering", "unknown", "The raw export shows an empty root container and a module script reference. No rendered DOM or script bytes are supplied, so rendered content is unknown, not absent.", []);
rev(f, "quality-task-fit", "unknown", "Publisher purpose, user task and intended search visibility are not supplied.", []);

// 07
f = "07-locale.md";
const g1 = add(f, "d07-audience-context", "audience-context", "3", "Supplied audience (07-locale.md:3): a Vietnamese-only help document for Vietnamese customers. Task inferred from the content at 07-locale.md:4: exporting data as CSV.", ["The task is inferred from the document body; no separate task statement is supplied."]);
const g2 = add(f, "d07-claim-sources", "claim-sources", "5", "Supplied confirmation (07-locale.md:5): the supplied product procedure exactly matches these steps and limits.", ["The procedure text itself is not reproduced in the dossier; only this confirmation is available.", "No date or version is attached to the procedure."]);
const g3 = add(f, "d07-locale-map", "locale-map", "3-5", "Supplied locale relationships (07-locale.md:3, 5): Vietnamese only; the publisher confirms no English counterpart exists or is intended; no translation project or alternate-page map is supplied.", ["Deployed-page metadata is unavailable."]);
rev(f, "quality-task-fit", "pass", "For Vietnamese customers exporting data, the Vietnamese text gives the ordered steps, the attachment limitation with its workaround and the absence of a processing-time commitment.", [g1]);
rev(f, "quality-claims", "pass", "The dossier states that the supplied product procedure exactly matches the steps and limits in the document. The procedure text is not reproduced, so this relies on that confirmation.", [g2]);
rev(f, "aeo-answer-evidence", "pass", "The procedural answer and its limits are confirmed by the supplied product procedure statement.", [g2]);
rev(f, "aio-retrievable-facts", "pass", "The steps, the attachment exclusion and the no-commitment statement are present as readable text in the local Markdown export. This does not establish retrieval or citation by any engine.", [g1]);
rev(f, "seo-locales", "not-applicable", "The publisher confirms the document is Vietnamese-only and that no English counterpart exists or is intended; there are no locale variants to relate.", [g3]);
rev(f, "seo-metadata", "unknown", "Deployed-page metadata is unavailable for this local Markdown export.", []);

// 08
f = "08-study.md";
const h1 = add(f, "d08-claim-sources", "claim-sources", "3-5", "Supplied study metadata (08-study.md:5): publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied. Editorial as-of date (08-study.md:3): 2026-11-16.", ["The study itself is not supplied; only this metadata."]);
rev(f, "quality-claims", "pass", "Each draft claim matches the supplied metadata: published in the as-of month (2026-11-01 against as-of 2026-11-16), collected 1-14 February 2024, synthetic English API panel, 40 of 100 responses citing video sources.", [h1]);
rev(f, "quality-freshness", "pass", "The draft states the 2024 collection window explicitly and says the historical observations do not establish the current rate, so date applicability is disclosed accurately.", [h1]);
rev(f, "aeo-answer-evidence", "pass", "The draft's material claims and its scope caveat are supported by the supplied study metadata.", [h1]);

// 09
f = "09-media.md";
rev(f, "quality-accessible-media", "unknown", "No PDF bytes, extracted text or video transcript were supplied. Absence from the export does not establish that text alternatives or transcripts are missing.", []);

// 10
f = "10-page.md";
const j1 = add(f, "d10-claim-sources", "claim-sources", "3", "Supplied confirmation (10-page.md:3): the supplied policy confirms the limitation that Example exports include account-owned records only.", ["The policy text itself is not reproduced in the dossier; only this confirmation is available."]);
rev(f, "quality-claims", "pass", "The user-visible product copy states that exports include account-owned records only, and the dossier states the supplied policy confirms this limitation. The hidden comment is an instruction block, not a product claim, and is reported separately.", [j1]);
rev(f, "aeo-answer-evidence", "pass", "The single user-visible answer claim is confirmed by the supplied policy statement.", [j1]);

const F = (o) => bundle.findings.push(o);
F({ findingId: "F1-noindex-header-vs-intent", title: "Response header noindex conflicts with meta robots and indexing intent", affectedItemIds: [item("01-visibility.md").itemId], ruleIds: ["seo-index-controls"], dimensions: ["seo"], evidenceIds: [sid("01-visibility.md"), a1, a2], severity: "high", confidence: "high", classification: "observed", action: "update", actionReason: "Supplied header, meta tag and publisher intent disagree; the header needs changing if the stated intent stands.",
  remediation: "Proposal for a separate implementation task: remove the noindex value from the X-Robots-Tag response header for /product, or confirm that noindex is intended and correct the stated intent and the meta robots tag instead.",
  verification: "Re-capture the response headers and raw HTML head for https://store.example.invalid/product and confirm that no noindex directive appears in either. Index status then needs a separate index observation, which is not supplied here.", ownerRole: "Web platform / SEO owner", effort: "small" });
F({ findingId: "F2-redirect-loop", title: "/old and /new redirect to each other; the preferred URL never resolves", affectedItemIds: [item("02-route.md").itemId], ruleIds: ["seo-canonical", "seo-response"], dimensions: ["seo"], evidenceIds: [sid("02-route.md"), b1, b2, b3], severity: "high", confidence: "high", classification: "observed", action: "update", actionReason: "The captured responses form a two-URL loop that contradicts the stated single-redirect intent.",
  remediation: "Proposal for a separate implementation task: remove the redirect from /new back to /old so that /new returns a final successful response, keeping the single 301 from /old to /new.",
  verification: "Re-capture both URLs: /old should return one 301 to /new and /new should return a final successful response without a Location header pointing to /old. Confirm the current sitemap still lists /new.", ownerRole: "Web platform / SEO owner", effort: "small" });
F({ findingId: "F3-offer-price-mismatch", title: "JSON-LD offer price 19 USD contradicts the confirmed visible price of USD 29", affectedItemIds: [item("03-offer.md").itemId], ruleIds: ["seo-structured-data", "aio-entity-consistency"], dimensions: ["seo", "aio"], evidenceIds: [sid("03-offer.md"), c1, c2], severity: "high", confidence: "high", classification: "observed", action: "update", actionReason: "The publisher confirms the visible price, so the markup value is the one to change.",
  remediation: "Proposal: change the JSON-LD Offer price from 19 to 29 for the United States monthly offer so it matches the publisher-confirmed visible price, keeping priceCurrency USD.",
  verification: "Re-extract the JSON-LD from the revised page and compare offers.price and priceCurrency with the visible US monthly price. Feature eligibility is a separate check that was not run.", ownerRole: "Product content / web platform owner", effort: "small" });
F({ findingId: "F4-starter-storage-contradiction", title: "Two current pages state different Starter storage entitlements (1000 vs 1500)", affectedItemIds: [item("04-policy.md").itemId], ruleIds: ["portfolio-contradictions", "aio-entity-consistency", "quality-claims"], dimensions: ["portfolio", "aio", "quality"], evidenceIds: [sid("04-policy.md"), d1, d2], severity: "high", confidence: "high", classification: "observed", action: "investigate", actionReason: "The contradiction is observed, but the correct value cannot be chosen without the unavailable authoritative entitlement table.",
  remediation: "Obtain the authoritative entitlement table for Starter (policy version 2026-10-01), then correct whichever of /product or /blog/starter-guide disagrees with it. Do not pick a value without that source.",
  verification: "Compare both revised statements with the authoritative entitlement table for the same plan, market, monthly billing period and policy version; both pages should state the same value.", ownerRole: "Product / pricing owner with content owner", effort: "small" });
F({ findingId: "F5-vi-draft-overstates-free-change", title: "Bản nháp nói mọi khách hàng được miễn phí đổi vé và không cần báo trước, trái với chính sách", affectedItemIds: [item("05-huong-dan.md").itemId], ruleIds: ["quality-claims", "aeo-answer-evidence"], dimensions: ["quality", "aeo"], evidenceIds: [sid("05-huong-dan.md"), e1], severity: "high", confidence: "high", classification: "observed", action: "update", actionReason: "The draft contradicts the supplied current policy on both eligibility and notice.",
  remediation: "Proposal: rewrite the draft sentence so it limits free changes to the Thành viên tier, states the 24-hour-before-departure request requirement and refers other tiers to the separate fee table without quoting fee amounts that were not supplied.",
  verification: "Compare the revised Vietnamese sentence with the supplied current policy for eligibility, the 24-hour condition and the fee-table reference; check any fee amounts against the fee table once it is supplied.", ownerRole: "Content owner (Vietnamese)", effort: "small" });
writeFileSync(R + "/audits/content-search/work/review.json", JSON.stringify(bundle, null, 2) + "\n");
console.log(bundle.evidence.length, bundle.reviews.length, bundle.findings.length);
