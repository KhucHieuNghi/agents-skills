# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:19:14\.489Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 608a50ea\-52b8\-448e\-8e32\-cf4ab182559f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |
| fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| d9f807edb0283d716329695b3d4917774b0237c3e863b68e788d8699a228dd22 | 0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580 | local\-file | 2026\-11\-16T17:19:14\.464Z | 0 full elapsed days | [evidence/0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580\.txt](evidence/0484edf9f3072052f598712106fd41017c32035251fccc870f508fd5d13eb580.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 632f4a531c45ffa8c0d5e689deb094d3553192dbfb35a75e7a31b0106efaee11 | 1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040 | local\-file | 2026\-11\-16T17:19:14\.465Z | 0 full elapsed days | [evidence/1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040\.txt](evidence/1b3eba0f6d9c1eb31948cc0ffbd4468d08f08159ad8d0e2afa09edc64a87c040.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 9eef4d045cd5b33e1d32155b6196e5f9b1f561940778a07e3fa55ac7eb7c48af | 3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea | local\-file | 2026\-11\-16T17:19:14\.466Z | 0 full elapsed days | [evidence/3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea\.txt](evidence/3163b45cf232b82eb3585fe89ad382cea0660d94fe5b6715d5cf98c4d31052ea.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6964dcfec5c685fb73484e07b7312f55139c7575f3617bc3378a768f24b4020e | 32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf | local\-file | 2026\-11\-16T17:19:14\.466Z | 0 full elapsed days | [evidence/32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf\.txt](evidence/32127a18e59f9451690254e0a229ca07d039188b8fe4e3b725251b1528ce6dbf.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| e8e6d3fc9e57d0fdceaaae06c9c626d80026fb0dad234bb7d977243c561cf8a8 | 6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0 | local\-file | 2026\-11\-16T17:19:14\.467Z | 0 full elapsed days | [evidence/6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0\.txt](evidence/6f45b1a4dd768fcd0c3fb09529f2348698fc72127919b48688c0321f3a164fe0.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dc39a77956980a48be71c6d752f5d1836b22419218903ec87931aaac51612e33 | a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9 | local\-file | 2026\-11\-16T17:19:14\.467Z | 0 full elapsed days | [evidence/a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9\.txt](evidence/a089fda783f0020ec8db88694597d09471f3cb40bba502431b9630d2524919a9.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 3c0c67a7c9eb8909a8c652ebf05fa4d885eee91bc5b2f3c4427d1045be75ea72 | c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc | local\-file | 2026\-11\-16T17:19:14\.468Z | 0 full elapsed days | [evidence/c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc\.txt](evidence/c05b0877fe50edd5396041b753ef8c3dfb95c217bf789a9571eaf4b4e7a75abc.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 6a7d10d825a6155d3f1a38cd8f15737441f650b8745de22db1118e3fac0623c4 | c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950 | local\-file | 2026\-11\-16T17:19:14\.468Z | 0 full elapsed days | [evidence/c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950\.txt](evidence/c51ddeba1a848dd0735ed187bf132d91c59a3ff6878a8c5ad6bf0932c13c4950.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 86d8a6617914fe8bc3fbc224916679e32aa380d74b186571069623586a633516 | fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa | local\-file | 2026\-11\-16T17:19:14\.469Z | 0 full elapsed days | [evidence/fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa\.txt](evidence/fc856c4cea2804d6a613aa118cbef696c1a1487dcfff2433a938085af68aa4fa.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a6ba0c5bbcc01783ab5124e819bc2c931bf9b334547ca60bb0200bf44b335de5 | fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c | local\-file | 2026\-11\-16T17:19:14\.469Z | 0 full elapsed days | [evidence/fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c\.txt](evidence/fe3e95702a74c95b24ddef06475654e3fc953c4bd2e361c1922e66cecedfd57c.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
