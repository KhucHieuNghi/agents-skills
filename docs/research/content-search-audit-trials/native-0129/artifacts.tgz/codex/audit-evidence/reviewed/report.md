# Offline synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T14:02:17\.282Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 78255e8b\-a4f2\-48be\-9587\-aa6b8bc572bb\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1 | Fir SSO denial contradicts its supplied documentation | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | update | reviewer\-proposal | The pricing table’s silence does not support a blanket denial\. The documentation establishes SAML SSO on Enterprise with at least 20 paid seats\. Other Fir plans remain unverified\. An evaluator could wrongly rule out Fir\. | Replace the blanket denial with the documented Enterprise SAML SSO entitlement and 20\-paid\-seat minimum\. Preserve the November 2026 US scope and leave other plans unspecified\. | Compare the revised assertion with the supplied Fir SSO documentation at lines 12–14\. Check the protocol, plan, minimum and any language about other plans\. | Comparison page owner | small | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202, 01\-claim\-sources, 01\-entity\-record |
| F2 | The all\-billing price comparison reverses on annual plans | quality\-claims, aio\-entity\-consistency, aeo\-answer\-evidence | quality, aio, aeo | high | high | observed | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | update | reviewer\-proposal | Cedar is USD 3 less per seat per month on monthly billing\. Its annual equivalent is USD 1 more per seat per month\. The separate caption correctly scopes the monthly difference\. A universal price claim can mislead an annual buyer\. | Show matched monthly and annual rows with billing cadence, per\-seat units and November 2026 US pre\-tax scope\. Preserve the Cedar monthly no\-minimum fact and the accurate monthly caption\. Limit the comparison to the supplied prices\. | Recompute 15 − 12 and 10 − 9, then compare each revised row with the applicable source\. Confirm that annual values are monthly equivalents billed annually and that no total\-cost or feature\-equivalence claim was added\. | Comparison page owner | small | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202, 01\-claim\-sources, 01\-entity\-record |
| F3 | The October cost per conversion uses mismatched windows | quality\-claims | quality | high | high | observed | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | update | reviewer\-proposal | USD 85\.71 is the rounded quotient of full\-month USD 3,000 spend and 35 completed conversions from October 1–7 only\. Full\-month cost per completed conversion is unmeasured\. The aligned October 1–7 calculation gives USD 20 per completed conversion\. | Use the existing October 1–7 caption and mark the full\-month result unavailable\. If late\-window conversions become available, recompute for October 1–31 with matching definitions\. | Match campaign, currency, conversion definition and date window on both inputs\. Recalculate USD 700 ÷ 35\. Require a complete October 1–31 denominator before reporting a monthly rate\. | Campaign reporting owner | small | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d, 02\-claim\-sources |
| F5 | The South delivery page repeats North’s current policy | quality\-claims, quality\-task\-fit, aio\-entity\-consistency, aio\-retrievable\-facts, aeo\-answer\-evidence, portfolio\-contradictions | quality, aio, aeo, portfolio | high | high | observed | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | update | reviewer\-proposal | South customers could plan on same\-day fulfillment that current South policy does not offer\. The complete North passage matches current North policy and includes the outside\-window caveat\. The dated archive serves old orders and accurately reflects the 2024 contract\. | Set the South passage to next\-business\-day delivery only and remove copied North cutoff and delivery\-window language from South\. Preserve the separate North and South pages and the labeled archive\. | Compare each region’s complete revised passage with current approved policy\. Check that North still preserves weekdays, cutoff, local time and the later\-date caveat\. Check the archive’s 2024 label and links to both current pages using supplied page evidence\. | Delivery content owner | small | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb, 03\-claim\-sources, 03\-audience\-context, 03\-entity\-record, 03\-inventory\-map |
| F6 | The setup guarantee exceeds the onboarding study | quality\-claims | quality | high | high | observed | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | update | reviewer\-proposal | The reported median is 15 minutes across 20 observed sessions, above the draft’s 10\-minute promise\. It supplies no individual maximum, time guarantee, refund terms, distribution or wider population estimate\. It does not establish that any session exceeded 15 minutes\. | Replace the universal guarantee with the supplied study’s descriptive result, preserving the median, observed\-session count and onboarding scope\. | Check the revised text against the approved study record for statistic, units and sample size\. Confirm that the wording avoids guarantees, refund terms, unreported tails and population claims\. | Onboarding page owner | small | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64, 04\-claim\-sources |
| F4 | The AI referral count is extrapolated without a tracking model | quality\-claims | quality | medium | high | observed | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | update | reviewer\-proposal | The only supplied measure is 15 October sessions with an identified AI\-assistant referrer\. The assumed one\-in\-ten tracking rate has no evidence\. Total AI referrals, AI influence, incrementality and conversion impact remain unknown\. | Report the 15 identified\-referrer sessions as an attribution observation\. Remove the multiplier and causal claim\. Keep this referral report independent of the campaign counts\. | Reconcile the 15 sessions against the supplied referrer evidence\. Require a validated coverage model for extrapolation, a suitable causal design for incrementality and actual linkage for conversion attribution\. | Referral reporting owner | small | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d, 02\-claim\-sources |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 4 | 8 | 0 |
| aio | 12 | 3 | 9 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 2 | 14 | 0 |
| quality | 20 | 9 | 11 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | pending | Snapshot review incomplete | 26 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | pending | Snapshot review incomplete | 26 |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | pending | Snapshot review incomplete | 26 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-task\-fit | quality | fail | The current South passage gives the wrong answer for planning South delivery\. | 03\-audience\-context, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-claims | quality | fail | South contradicts current policy; North and the 2024 archive agree with their stated versions\. | 03\-claim\-sources, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 03\-extracted\-text |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-entity\-consistency | aio | fail | The current South regional entitlement conflicts with the approved entity record\. | 03\-entity\-record, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-retrievable\-facts | aio | fail | A South customer extracting the supplied passage receives North timing under the South label\. | 03\-audience\-context, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-answer\-evidence | aeo | fail | The complete South policy answer is contradicted by the approved policy\. | 03\-claim\-sources, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-duplication | portfolio | pass | The complete supplied set serves three distinct scope\-bound tasks: current North, current South and the 2024 contract\. Shared layout and generic wording do not duplicate these tasks\. | 03\-inventory\-map, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-contradictions | portfolio | fail | North and South are separate regional variants, but the South passage misstates policy; the historical archive is scoped correctly\. | 03\-entity\-record, 03\-inventory\-map, 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-claims | quality | fail | The setup guarantee exceeds the study\. The complete permissions FAQ matches approved policy and the technical table is owner\-confirmed for its task\. | 04\-claim\-sources, dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 04\-extracted\-text |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-question\-coverage | aeo | pass | The only explicitly supplied question asks which role can delete the workspace\. The full FAQ answers it directly\. The landing\-page setup guarantee is a factual claim and the technical table serves a separate task; neither is part of this question set\. | 04\-question\-set, dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-answer\-context | aeo | pass | For the supplied permissions question, the answer stands alone with the editor restriction and owner permission\. Owner context confirms there are no extra prerequisites for identifying the permitted role\. Setup timing and the technical reference are separate from this question\. | 04\-question\-set, dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-answer\-evidence | aeo | unknown | The supplied permissions answer is supported; the technical reference and onboarding copy are separate components without a complete answer inventory for this broader check\. | 04\-claim\-sources, dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-claims | quality | fail | Draft A uses unmatched dates and Draft B invents tracking coverage; the aligned caption and identified\-referrer count are supported\. | 02\-claim\-sources, 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 02\-extracted\-text |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-claims | quality | fail | Both comparison assertions fail; the scoped monthly caption is supported\. | 01\-claim\-sources, edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | 01\-extracted\-text |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-entity\-consistency | aio | fail | Fir SSO and billing facts are misrepresented in the comparison\. | 01\-entity\-record, edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-answer\-evidence | aeo | fail | The plan\-comparison answers on SSO and relative prices conflict with owner\-supplied evidence; the monthly caption is supported\. | 01\-claim\-sources, edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T13:59:58\.212Z | 0 full elapsed days | [evidence/8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b\.txt](evidence/8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | local\-file | 2026\-11\-16T13:59:58\.213Z | 0 full elapsed days | [evidence/96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f\.txt](evidence/96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | local\-file | 2026\-11\-16T13:59:58\.214Z | 0 full elapsed days | [evidence/cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98\.txt](evidence/cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | local\-file | 2026\-11\-16T13:59:58\.214Z | 0 full elapsed days | [evidence/e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0\.txt](evidence/e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 03\-extracted\-text | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/03\-extracted\-text\.txt](evidence/03-extracted-text.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Verbatim UTF\-8 Markdown text read from the linked local capture, with headings and markup preserved\. No rendered\-page extraction\. |
| 04\-extracted\-text | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/04\-extracted\-text\.txt](evidence/04-extracted-text.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Verbatim UTF\-8 Markdown text read from the linked local capture, with headings and markup preserved\. No rendered\-page extraction\. |
| 02\-extracted\-text | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/02\-extracted\-text\.txt](evidence/02-extracted-text.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Verbatim UTF\-8 Markdown text read from the linked local capture, with headings and markup preserved\. No rendered\-page extraction\. |
| 01\-extracted\-text | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/01\-extracted\-text\.txt](evidence/01-extracted-text.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Verbatim UTF\-8 Markdown text read from the linked local capture, with headings and markup preserved\. No rendered\-page extraction\. |
| 01\-claim\-sources | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/01\-claim\-sources\.txt](evidence/01-claim-sources.txt) | 0639bc2d4aec1bf47a43c2c3dbc4c47cc11f166c97f9d256312574969d5234d6 | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 01\-entity\-record | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/01\-entity\-record\.txt](evidence/01-entity-record.txt) | 922c1047ff2fde67121b694ffb970a8850a9d7c68a067e0be692753e4bc74381 | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 02\-claim\-sources | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/02\-claim\-sources\.txt](evidence/02-claim-sources.txt) | 809076435e90e72b2b5cc869881a395058ef533e16d41d5f4d069c64c6f4a452 | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 03\-claim\-sources | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/03\-claim\-sources\.txt](evidence/03-claim-sources.txt) | 038de08f42e7ac262413bbe239df1221e0dcb9a1ab6002c3e928852adf82996c | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 03\-entity\-record | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/03\-entity\-record\.txt](evidence/03-entity-record.txt) | 04ed36295dd976dd4a59f0f2394008d253e7342487db8e00eb77198b22f3ec9c | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 03\-inventory\-map | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/03\-inventory\-map\.txt](evidence/03-inventory-map.txt) | e2c0b14e80b01a2911196bbf021ce9ba4fd5733473b1fadabda8cc433c7ef425 | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 03\-audience\-context | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/03\-audience\-context\.txt](evidence/03-audience-context.txt) | 58ee15d8958238a599d07b9800cdf8860226c3bca3c2348a7a21261fb602baee | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 04\-claim\-sources | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/04\-claim\-sources\.txt](evidence/04-claim-sources.txt) | c198386e36bb6d70e51bfe5e74e1dabf25ad77ed9118d8ea74c27623c698283e | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |
| 04\-question\-set | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | local\-file | 2026\-11\-16T14:02:17\.177Z | 0 full elapsed days | [evidence/04\-question\-set\.txt](evidence/04-question-set.txt) | e3f7e9b7975c3e5dc3cc398a82fb65fdcfa3095083a975a98dae78432acc1ae3 | Derived from the attributed local synthetic dossier\. Live behavior and independent provenance are unverified\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
