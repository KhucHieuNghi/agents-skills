import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

const base = 'audit-evidence';
const read = f => fs.readFileSync(f, 'utf8');
const write = (f, value) => fs.writeFileSync(f, JSON.stringify(value, null, 2) + '\n');
const hash = text => createHash('sha256').update(text).digest('hex');
const records = file => read(base + '/collection/' + file + '.jsonl').trim().split('\n').map(JSON.parse);
const inventory = records('inventory');
const snapshots = records('evidence');
const registry = JSON.parse(read('.agents/skills/content-search-audit/rules/core.json')).rules;
const now = new Date().toISOString();
const bundle = {artifacts:{}, evidence:[], reviews:[], findings:[]};

const names = ['Content quality', 'SEO', 'AIO', 'AEO', 'GEO', 'Portfolio'];
const sources = new Map(inventory.map(item => {
  const name = path.basename(item.path);
  const raw = read(item.path);
  const snapshot = snapshots.find(s => s.itemId === item.itemId && s.kind === 'content');
  assert.equal(hash(raw), snapshot.snapshotHash);
  return [name.slice(0,2), {item, name, raw, snapshot}];
}));
function excerpt(id, start, end = start) {
  return sources.get(id).raw.split('\n').slice(start-1, end).join(' ').replace(/\s+/g,' ').trim();
}
function label(id, start, end = start) {
  return `${sources.get(id).name}:${start}${end === start ? '' : '-' + end}`;
}
function context(id, kind, ranges, summary) {
  const {snapshot} = sources.get(id);
  const value = summary + '\n' + ranges.map(([start,end]) => label(id,start,end) + ' — ' + excerpt(id,start,end)).join('\n') + '\n';
  const evidenceId = id + '-' + kind;
  const artifact = 'evidence/' + evidenceId + '.txt';
  bundle.artifacts[artifact] = value;
  bundle.evidence.push({...snapshot, evidenceId, kind, artifact, value, byteLength: Buffer.byteLength(value),
    snapshotHash:hash(value), collectedAt:now, locator:ranges.map(([a,b]) => label(id,a,b)).join(', '),
    limitations:['Derived from the attributed local synthetic dossier. Live behavior and independent provenance are unverified.'],
    sourceEvidenceIds:[snapshot.evidenceId]});
  return evidenceId;
}
for (const [id,{snapshot}] of sources) {
  const evidenceId = id + '-extracted-text';
  const artifact = 'evidence/' + evidenceId + '.txt';
  bundle.artifacts[artifact] = snapshot.value;
  bundle.evidence.push({...snapshot, evidenceId, kind:'extracted-text', artifact, collectedAt:now,
    method:'local-file', limitations:['Verbatim UTF-8 Markdown text read from the linked local capture, with headings and markup preserved. No rendered-page extraction.'],
    sourceEvidenceIds:[snapshot.evidenceId]});
}
context('01','claim-sources',[[3,14],[20,24]],'Owner-supplied synthetic pricing, Fir documentation and comparison scope.');
context('01','entity-record',[[3,14]],'Owner-supplied synthetic US plan, billing and SSO entity facts.');
context('02','claim-sources',[[3,8],[11,16],[20,21]],'Synthetic reporting rows and independent referral count with owner-supplied limits.');
context('03','claim-sources',[[3,6],[13,16]],'Owner-approved current policy and 2024 archive account.');
context('03','entity-record',[[3,6],[13,16]],'Owner-approved synthetic regional service schedules by version.');
context('03','inventory-map',[[3,6],[8,16],[18,20]],'Complete declared three-page inventory and owner retention scope.');
context('03','audience-context',[[3,6],[13,19]],'Current regional delivery timing and prior contract lookup serve different customer tasks.');
context('04','claim-sources',[[3,5],[8,18]],'Owner-supplied synthetic study, permissions policy and reference-page assessment.');
context('04','question-set',[[8,13]],'Supplied permissions question concerns the permitted role. Setup timing remains a separate claim.');

const findings = [
  {key:'F1', id:'01', title:'Fir SSO denial contradicts its supplied documentation', target:'/compare, assertion A', quotes:[[17],[12,14]],
    rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence'], severity:'high',
    why:'The pricing table’s silence does not support a blanket denial. The documentation establishes SAML SSO on Enterprise with at least 20 paid seats. Other Fir plans remain unverified. An evaluator could wrongly rule out Fir.',
    action:'Replace the blanket denial with the documented Enterprise SAML SSO entitlement and 20-paid-seat minimum. Preserve the November 2026 US scope and leave other plans unspecified.',
    verify:'Compare the revised assertion with the supplied Fir SSO documentation at lines 12–14. Check the protocol, plan, minimum and any language about other plans.', owner:'Comparison page owner'},
  {key:'F2', id:'01', title:'The all-billing price comparison reverses on annual plans', target:'/compare, assertion B', quotes:[[18],[3,10],[20,24]],
    rules:['quality-claims','aio-entity-consistency','aeo-answer-evidence'], severity:'high',
    why:'Cedar is USD 3 less per seat per month on monthly billing. Its annual equivalent is USD 1 more per seat per month. The separate caption correctly scopes the monthly difference. A universal price claim can mislead an annual buyer.',
    action:'Show matched monthly and annual rows with billing cadence, per-seat units and November 2026 US pre-tax scope. Preserve the Cedar monthly no-minimum fact and the accurate monthly caption. Limit the comparison to the supplied prices.',
    verify:'Recompute 15 − 12 and 10 − 9, then compare each revised row with the applicable source. Confirm that annual values are monthly equivalents billed annually and that no total-cost or feature-equivalence claim was added.', owner:'Comparison page owner'},
  {key:'F3', id:'02', title:'The October cost per conversion uses mismatched windows', target:'campaign report, Draft A', quotes:[[10],[3,8],[11,12]],
    rules:['quality-claims'], severity:'high',
    why:'USD 85.71 is the rounded quotient of full-month USD 3,000 spend and 35 completed conversions from October 1–7 only. Full-month cost per completed conversion is unmeasured. The aligned October 1–7 calculation gives USD 20 per completed conversion.',
    action:'Use the existing October 1–7 caption and mark the full-month result unavailable. If late-window conversions become available, recompute for October 1–31 with matching definitions.',
    verify:'Match campaign, currency, conversion definition and date window on both inputs. Recalculate USD 700 ÷ 35. Require a complete October 1–31 denominator before reporting a monthly rate.', owner:'Campaign reporting owner'},
  {key:'F4', id:'02', title:'The AI referral count is extrapolated without a tracking model', target:'independent referral report, Draft B', quotes:[[17,18],[14,16],[20,21]],
    rules:['quality-claims'], severity:'medium',
    why:'The only supplied measure is 15 October sessions with an identified AI-assistant referrer. The assumed one-in-ten tracking rate has no evidence. Total AI referrals, AI influence, incrementality and conversion impact remain unknown.',
    action:'Report the 15 identified-referrer sessions as an attribution observation. Remove the multiplier and causal claim. Keep this referral report independent of the campaign counts.',
    verify:'Reconcile the 15 sessions against the supplied referrer evidence. Require a validated coverage model for extrapolation, a suitable causal design for incrementality and actual linkage for conversion attribution.', owner:'Referral reporting owner'},
  {key:'F5', id:'03', title:'The South delivery page repeats North’s current policy', target:'/south-delivery, with /north-delivery and /terms-v1 as comparison context', quotes:[[4,5],[8,9],[10,11],[13,16]],
    rules:['quality-claims','quality-task-fit','aio-entity-consistency','aio-retrievable-facts','aeo-answer-evidence','portfolio-contradictions'], severity:'high',
    why:'South customers could plan on same-day fulfillment that current South policy does not offer. The complete North passage matches current North policy and includes the outside-window caveat. The dated archive serves old orders and accurately reflects the 2024 contract.',
    action:'Set the South passage to next-business-day delivery only and remove copied North cutoff and delivery-window language from South. Preserve the separate North and South pages and the labeled archive.',
    verify:'Compare each region’s complete revised passage with current approved policy. Check that North still preserves weekdays, cutoff, local time and the later-date caveat. Check the archive’s 2024 label and links to both current pages using supplied page evidence.', owner:'Delivery content owner'},
  {key:'F6', id:'04', title:'The setup guarantee exceeds the onboarding study', target:'onboarding landing page', quotes:[[6],[3,5]],
    rules:['quality-claims'], severity:'high',
    why:'The reported median is 15 minutes across 20 observed sessions, above the draft’s 10-minute promise. It supplies no individual maximum, time guarantee, refund terms, distribution or wider population estimate. It does not establish that any session exceeded 15 minutes.',
    action:'Replace the universal guarantee with the supplied study’s descriptive result, preserving the median, observed-session count and onboarding scope.',
    verify:'Check the revised text against the approved study record for statistic, units and sample size. Confirm that the wording avoids guarantees, refund terms, unreported tails and population claims.', owner:'Onboarding page owner'}
];

const statuses = {
  '01':{'quality-claims':'Both comparison assertions fail; the scoped monthly caption is supported.', 'aio-entity-consistency':'Fir SSO and billing facts are misrepresented in the comparison.', 'aeo-answer-evidence':'The plan-comparison answers on SSO and relative prices conflict with owner-supplied evidence; the monthly caption is supported.'},
  '02':{'quality-claims':'Draft A uses unmatched dates and Draft B invents tracking coverage; the aligned caption and identified-referrer count are supported.'},
  '03':{'quality-claims':'South contradicts current policy; North and the 2024 archive agree with their stated versions.', 'quality-task-fit':'The current South passage gives the wrong answer for planning South delivery.', 'aio-entity-consistency':'The current South regional entitlement conflicts with the approved entity record.', 'aio-retrievable-facts':'A South customer extracting the supplied passage receives North timing under the South label.', 'aeo-answer-evidence':'The complete South policy answer is contradicted by the approved policy.', 'portfolio-contradictions':'North and South are separate regional variants, but the South passage misstates policy; the historical archive is scoped correctly.'},
  '04':{'quality-claims':'The setup guarantee exceeds the study. The complete permissions FAQ matches approved policy and the technical table is owner-confirmed for its task.'}
};
const dimensions = rules => [...new Set(rules.map(id => registry.find(r => r.ruleId === id).dimension))];
function evidenceIds(id, rules) {
  const required = new Set(rules.flatMap(rule => registry.find(r => r.ruleId === rule).requiredEvidence));
  return [sources.get(id).snapshot.evidenceId, ...[...required].filter(k=>k!=='content').map(kind=>id+'-'+kind)];
}
function review(id, ruleId, status, reason, ids=evidenceIds(id,[ruleId])) {
  bundle.reviews.push({itemId:sources.get(id).item.itemId,ruleId,status,reason,evidenceIds:ids,reviewer:'Codex',reviewedAt:now});
}
for (const [id, rules] of Object.entries(statuses))
  for (const [rule, reason] of Object.entries(rules)) review(id,rule,'fail',reason);
review('03','portfolio-duplication','pass','The complete supplied set serves three distinct scope-bound tasks: current North, current South and the 2024 contract. Shared layout and generic wording do not duplicate these tasks.');
review('04','aeo-question-coverage','pass','The only explicitly supplied question asks which role can delete the workspace. The full FAQ answers it directly. The landing-page setup guarantee is a factual claim and the technical table serves a separate task; neither is part of this question set.');
review('04','aeo-answer-context','pass','For the supplied permissions question, the answer stands alone with the editor restriction and owner permission. Owner context confirms there are no extra prerequisites for identifying the permitted role. Setup timing and the technical reference are separate from this question.');
review('04','aeo-answer-evidence','unknown','The supplied permissions answer is supported; the technical reference and onboarding copy are separate components without a complete answer inventory for this broader check.');
for (const f of findings) {
  bundle.findings.push({findingId:f.key,title:f.title,affectedItemIds:[sources.get(f.id).item.itemId],ruleIds:f.rules,
    dimensions:dimensions(f.rules),evidenceIds:evidenceIds(f.id,f.rules),severity:f.severity,confidence:'high',classification:'observed',
    remediation:f.action,verification:f.verify,ownerRole:f.owner,effort:'small',action:'update',actionReason:f.why});
}
const contextRaw = read('targets/context.md');
if (process.argv[2] !== 'report') {
  fs.writeFileSync(base+'/scope-context.md', contextRaw);
  write(base+'/review.json',bundle);
}
assert.equal(15-12,3);
assert.equal(10-9,1);
assert.equal((3000/35).toFixed(2),'85.71');
assert.equal(700/35,20);

if (process.argv[2] !== 'report') process.exit(0);
const validation = JSON.parse(read(base+'/validation.json'));
const c = validation.coverage;
assert(validation.valid && !validation.completionAllowed);
const report = [];
const quotes = [];
const add = (...lines) => report.push(...lines);
add('# Offline content and search audit','',
    '**Partial audit.** All four supplied synthetic dossiers were inspected. The validated inventory contains '+c.total+' declared and '+c.inScope+' in-scope items. '+c.audited+' fully audited, '+c.states.pending+' pending, '+c.states.excluded+' excluded, '+c.states.blocked+' blocked, '+c.states.failed+' failed collection and '+c.states.unsupported+' unsupported. Six material findings.','',
    'The inventory is complete for the four supplied dossier files. [context.md](targets/context.md) supplies the scope, and the page and report components below are nested in their own dossier. Scenario 03 alone declares a complete three-page portfolio. Owner-approved records are synthetic comparison evidence within each scenario. File paths that appear to be URLs are supplied page labels.','',
    '## Material findings','',
    'Severity reflects plausible decision impact inside the scenario. Confidence is high for each evidence discrepancy. Each entry proposes a small editorial change subject to owner approval.','');
for (const f of findings) {
  add(`### ${f.key}. ${f.title}`,'',
    `**Affected** · Scenario ${f.id}, ${f.target}. **Severity** · ${f.severity}. **Dimensions** · ${dimensions(f.rules).map(d=>names[['quality','seo','aio','aeo','geo','portfolio'].indexOf(d)]).join(', ')}.${f.key==='F4' ? ' The issue also limits GEO outcome interpretation.' : ''}`,'');
  for (const [start,end=start] of f.quotes) {
    const quote = excerpt(f.id,start,end);
    const source = sources.get(f.id);
    add(`> ${quote}`,'',label(f.id,start,end),'');
    quotes.push({quoteId:f.key+'-'+start,source:'targets/'+source.name,sourceLabel:source.name,sourceHash:hash(source.raw),
      startLine:start,endLine:end,reportStartLine:report.length-3,reportEndLine:report.length-1,normalization:'whitespace',quote});
  }
  add('**Assessment.** '+f.why,'','**Proposed action.** '+f.action+' Owner · '+f.owner+'.','',
    '**Verification.** '+f.verify,'');
}
add('## Dossier accounting and limits by dimension','',
    'AIO refers to AI search readiness, AEO to answer quality and GEO to measured generative visibility. Technical SEO and GEO evidence gaps apply to every scenario.','',
    '| Dossier and inspected components | Content quality | SEO | AIO | AEO | GEO | Portfolio |',
    '|---|---|---|---|---|---|---|',
    '| [01](targets/01-competitor-claims.md) · pricing and SSO sources, comparison draft, monthly caption | F1–F2. The monthly caption is supported within its stated scope. | Only comparison copy and labels supplied. | Product and billing representations need correction. Retrieval unmeasured. | The two comparison claims are inaccurate. The monthly answer retains billing scope. | No responses, citations or conversion observations. | The broad comparison and scoped monthly caption serve distinguishable evaluation tasks. No full page set or query evidence for consolidation. |',
    '| [02](targets/02-measurement-windows.md) · October campaign rows, Draft A, verified caption, independent referral report and Draft B | F3–F4. The aligned caption and identified-referrer count are supported. | Reporting drafts supply no page implementation evidence. | The verified caption makes its scope explicit. Raw reports give no retrieval evidence or publisher intent. | The caption answers the measured-window reporting question. Full-month cost and total AI referrals remain unknown. Search question coverage is unmeasured. | Identified referrals are a scoped traffic observation. No capture or citation evidence and no conversion linkage. | Campaign efficiency and referral attribution are separate tasks and datasets. |',
    '| [03](targets/03-template-service-area.md) · complete three-page inventory with complete current policy passages and attributed archive account | F5. North and the archive are clean within their stated date and region. | Archive links are owner-reported. Link destinations, canonicals, indexing and query overlap are unverified. | South’s extracted policy misstates regional availability. North’s conditions are explicit. | North’s whole policy passage serves its timing task. South gives the wrong timing. | No response observations or search-engine selection data. | Keep both regional variants and the labeled archive. Shared layout and repeated contact wording are intentional. No evidence of cannibalization. |',
    '| [04](targets/04-editorial-proof.md) · study and draft guarantee, complete permissions FAQ and policy, status-code reference account | F6. FAQ is supported. Owner confirms the table’s accuracy and completeness for its technical task. Terse style, punctuation and lack of purchase CTA are appropriate within that scope. Authorship remains unknown. | Source gives no page metadata, indexing or performance evidence. | Permission roles are explicit in the supplied answer. The unsupported timing promise weakens factual readiness. | The FAQ fully answers who can delete a workspace. Deletion instructions are outside that stated task. The underlying reference table was described by the owner and cannot be independently inspected here. | No captured answers, citations or attributable outcomes. | Onboarding evaluation, permission lookup and status-code reference serve distinct tasks. No evidenced CTA, merge or expansion requirement. |',
    '',
    '## Missing evidence and follow-up measurement','',
    '- **Technical SEO and AIO access.** Require authorized local exports or captures for HTTP responses and redirects, index and snippet directives, intended canonicals and observed targets, actual titles and headings, complete links, structured data, locale relationships, rendered content, media and publisher crawler policies. Use supplied engine index and query/page data to assess selection, ranking, keyword demand or cannibalization. Page labels and policy excerpts cannot establish these outcomes.',
    '- **GEO and outcomes.** Search Console, GA4, Bing, normalized server logs and AI response exports were unavailable. The October counts are synthetic owner records with the windows and attribution limits quoted above. Mentions, citations, answer accuracy, ranking, conversion lift and causal impact are unavailable. In a separate authorized measurement period, collect versioned prompts from evidenced user tasks and record repeated observations by engine, surface, model when exposed, search mode, locale, market and timestamp. Preserve responses and citation URLs, and adjudicate material claims against dated evidence. Report mention, citation and accuracy numerators and eligible denominators separately, with capture errors and unknowns. Compare only compatible cohorts.',
    '- **Editorial and portfolio evidence.** To resolve remaining checks, obtain complete page captures and task or question evidence for incomplete dossiers, actual metadata and links, and dated sources for unresolved factual assertions. For scenario 02 seek the missing October 8–31 conversion record only if a full-month measure is needed. For scenario 04 retain the observed study statistic and require study-level evidence for any broader claim.',
    '',
    '## Validated coverage','',
    '| Dimension | Planned | Completed | Unknown | Not applicable |','|---|---:|---:|---:|---:|');
for (const [i,v] of Object.values(c.dimensions).entries()) add(`| ${names[i]} | ${v.total} | ${v.completed} | ${v.unknown} | ${v.notApplicable} |`);
add('','All four local Markdown snapshots were collected and checked for readable text. The validator found '+c.missingChecks.length+' missing planned check records and '+c.pendingQueueCount+' queued discovery entries. Required checks remain unresolved, so validation allows partial delivery only. The [validated run](audit-evidence/reviewed/report.md), [coverage data](audit-evidence/reviewed/coverage.json), [action CSV](audit-evidence/reviewed/content-actions.csv) and [quotation receipt](audit-evidence/quote-receipt.json) accompany this report.','');
const body = report.join('\n');
fs.writeFileSync('report.md',body);
write(base+'/quotes.json',{root:process.cwd(),report:'report.md',reportHash:hash(body),quotes});
