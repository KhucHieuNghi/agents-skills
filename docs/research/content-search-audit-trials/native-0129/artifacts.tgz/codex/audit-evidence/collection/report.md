# Offline synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T13:59:58\.227Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 94693550\-43b6\-4231\-bebe\-e7d48636dc5f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-locales | seo | unknown | Missing required evidence: locale\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |
| e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 9e42f751215b560b7a5d440ca0dc617b88bac7ab226eddcaf6781fc2a6d72fbb | 8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b | local\-file | 2026\-11\-16T13:59:58\.212Z | 0 full elapsed days | [evidence/8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b\.txt](evidence/8bf5e87eba2c9bd87f9a3701201f5e735943a84220a446bf168f49dc190c181b.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dba758ef03fc69fd3ccdd102c15790aa167f9c11b42095160616a83f956ffb64 | 96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f | local\-file | 2026\-11\-16T13:59:58\.213Z | 0 full elapsed days | [evidence/96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f\.txt](evidence/96e4c7d07da491ea35f4cacf6c62903ecf4e33bb52d397ca52da360a4639306f.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 52374baf3505a75fe6e2e6fa766a807768afe7ce699f24748d66402821ba488d | cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98 | local\-file | 2026\-11\-16T13:59:58\.214Z | 0 full elapsed days | [evidence/cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98\.txt](evidence/cddf0c73da471bb9664c15b1532df030eb8e3935493542073f13d5f6f4cb8e98.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| edbabe0b9b9837620c0f3b3f80a892551eb428750cd32e006360cab1ac561202 | e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0 | local\-file | 2026\-11\-16T13:59:58\.214Z | 0 full elapsed days | [evidence/e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0\.txt](evidence/e694df482ce5b2ca472e1bb707ae2178e6b803fa05b5cb7d64d588c4ead5ecd0.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
