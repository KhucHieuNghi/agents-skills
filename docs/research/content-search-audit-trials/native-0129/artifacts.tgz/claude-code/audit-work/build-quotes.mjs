import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const root = process.argv[2];
const sha = (p) => createHash("sha256").update(readFileSync(p)).digest("hex");
const F = { 1: "01-competitor-claims.md", 2: "02-measurement-windows.md", 3: "03-template-service-area.md", 4: "04-editorial-proof.md" };
const Q = [
 [1,17,17,'A. "Fir has no SSO, as its pricing table proves."'],
 [1,12,14,'Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: "SAML SSO is available on Enterprise, with a minimum of 20 paid seats." No SSO statement is supplied for Fir\'s other plans.'],
 [1,18,18,'B. "Cedar is cheaper per seat than Fir on every billing option."'],
 [1,6,9,'Our Cedar plan: USD 12 per seat per month, billed monthly, no seat minimum. Our annual option: USD 10 per seat per month equivalent, billed annually. Competitor Fir monthly option: USD 15 per seat per month, billed monthly. Fir annual option: USD 9 per seat per month equivalent, billed annually.'],
 [1,3,3,'All records concern current November 2026 US plans, USD before tax.'],
 [2,10,10,'Draft A: "October cost per conversion was USD 85.71, from 3000 divided by 35."'],
 [2,5,8,'Spend is complete for October 1–31: USD 3000. Conversion export covers only October 1–7: 35 completed conversions. No conversion data exists for October 8–31. The same spend export gives October 1–7 spend of USD 700.'],
 [2,17,18,'Draft B: "These 15 tracked sessions prove AI assistants generated 150 sessions in total, because only one in ten AI referrals can be tracked."'],
 [2,14,16,'Independent referral report: 15 October sessions have an identified AI-assistant referrer. Other sessions have unknown origin. No model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.'],
 [2,20,21,'Do not combine the campaign conversion counts with the independent referral report.'],
 [3,10,11,'/south-delivery: "South: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."'],
 [3,4,5,'Current approved policy: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.'],
 [4,6,6,'Draft landing-page claim: "Every team is guaranteed to finish setup in 10 minutes."'],
 [4,3,5,'Approved product record: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes. The owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate.'],
 [1,21,21,'"On the supplied monthly plans, Cedar is USD 3 less per seat per month before tax."'],
 [2,11,12,'Separate verified-window caption: "For October 1–7, observed cost per completed conversion was USD 20 (700 divided by 35). The rest of the month is unmeasured."'],
 [3,8,9,'/north-delivery: "North: same-day delivery Monday–Friday for orders before 10:00 local time. Orders outside that window require a later delivery date."'],
 [3,13,16,'Owner confirms /terms-v1 is a clearly labeled 2024 archive kept for old orders. It accurately describes the 2024 service contract, when South had same-day service. It links to the two current pages for new orders. No mixed-version customer task or misleading current-policy label is present.'],
 [3,18,20,'The two current pages serve different regions and the owner wants both retained. Shared layout and repeated generic contact wording are intentional. No ranking, query/page overlap, backlink, conversion or search-engine selection data exists.'],
 [4,9,9,'"Can editors delete the workspace? No. Only workspace owners can delete it."'],
 [4,10,13,'The approved permissions policy states exactly that editors cannot delete a workspace and owners can. There are no additional conditions needed to answer this permission question. The task is to identify the permitted role, not perform the deletion procedure.'],
 [4,15,19,'Separate reference page /status-codes has a complete, accurate table for its declared technical task. Its terse language, punctuation and lack of a purchase CTA are approved by the documentation owner. No authorship evidence, readability failure, acquisition objective or user task failure was supplied for this page. Do not infer authorship from style. No content change is authorized by this audit.'],
];
const lines = readFileSync(`${root}/report.md`, "utf8").split("\n");
const quotes = Q.map(([f, s, e, quote], i) => {
  const loc = `${F[f]}:${s === e ? s : `${s}-${e}`}`;
  const hits = lines.map((l, n) => (l.includes(quote) && l.includes("`" + loc + "`") ? n + 1 : 0)).filter(Boolean);
  if (hits.length !== 1) throw new Error(`quote ${i + 1} ${loc}: ${hits.length} report lines`);
  return { quoteId: `Q${i + 1}`, source: `targets/${F[f]}`, sourceLabel: F[f], sourceHash: sha(`${root}/targets/${F[f]}`), startLine: s, endLine: e, reportStartLine: hits[0], reportEndLine: hits[0], normalization: "whitespace", quote };
});
writeFileSync(`${root}/audit-work/quotes.json`, JSON.stringify({ root, report: "report.md", reportHash: sha(`${root}/report.md`), quotes }, null, 2) + "\n");
console.log(quotes.length);
