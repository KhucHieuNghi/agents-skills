# Synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T14:00:37\.863Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run c3c237b7\-b3d6\-43f9\-bf60\-f5f08ec83bf4\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 0 | 12 | 0 |
| aio | 12 | 0 | 12 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 0 | 16 | 0 |
| quality | 20 | 0 | 20 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | pending | Collected; semantic review and applicable evidence remain pending | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | local\-file | 2026\-11\-16T14:00:37\.846Z | 0 full elapsed days | [evidence/2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff\.txt](evidence/2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | local\-file | 2026\-11\-16T14:00:37\.847Z | 0 full elapsed days | [evidence/799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9\.txt](evidence/799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 | 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | local\-file | 2026\-11\-16T14:00:37\.848Z | 0 full elapsed days | [evidence/914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966\.txt](evidence/914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | local\-file | 2026\-11\-16T14:00:37\.849Z | 0 full elapsed days | [evidence/f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018\.txt](evidence/f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
