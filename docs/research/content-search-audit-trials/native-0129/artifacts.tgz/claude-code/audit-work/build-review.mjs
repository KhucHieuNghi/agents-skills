import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
const [runDir, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const inv = readFileSync(path.join(runDir, "inventory.jsonl"), "utf8").trim().split("\n").map(JSON.parse);
const ev = readFileSync(path.join(runDir, "evidence.jsonl"), "utf8").trim().split("\n").map(JSON.parse);
const now = new Date().toISOString();
const item = (n) => inv.find((i) => path.basename(i.path).startsWith(n));
const snap = (it) => ev.find((e) => e.itemId === it.itemId && e.kind === "content");
const artifacts = {}, evidence = [], reviews = [], findings = [];
const LIM = "Synthetic owner-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior.";
function add(it, n, kind, slug, locator, value) {
  const s = snap(it);
  const id = `ctx-${n}-${slug}`;
  const artifact = `evidence/${id}.txt`;
  artifacts[artifact] = value;
  evidence.push({ ...s, evidenceId: id, kind, artifact, value, snapshotHash: hash(value), byteLength: Buffer.byteLength(value), collectedAt: now, locator, method: "owner-context-from-task", limitations: [LIM], sourceEvidenceIds: [s.evidenceId] });
  return id;
}
function review(it, ruleId, status, reason, evidenceIds) {
  reviews.push({ itemId: it.itemId, ruleId, status, reason, evidenceIds, reviewer: "claude-agent-host-review", reviewedAt: now });
}
// extracted text (deterministic recompute; no host verdict)
for (const n of ["01", "02", "03", "04"]) {
  const it = item(n), s = snap(it);
  const id = `text-${n}`; const artifact = `evidence/${id}.txt`;
  artifacts[artifact] = s.value;
  evidence.push({ ...s, evidenceId: id, kind: "extracted-text", artifact, value: s.value, snapshotHash: hash(s.value), collectedAt: now, method: "identity-extraction-of-plain-markdown", limitations: ["Plain Markdown source text copied unchanged; not rendered output"], sourceEvidenceIds: [s.evidenceId] });
}
// 01
{
  const it = item("01"), c = snap(it).evidenceId;
  const cs = add(it, "01", "claim-sources", "pricing-sso", "01-competitor-claims.md:3-14",
    "Owner-supplied records, 01-competitor-claims.md:3-14 (current November 2026 US plans, USD before tax): Cedar USD 12 per seat per month billed monthly, no seat minimum; Cedar annual USD 10 per seat per month equivalent billed annually; Fir monthly USD 15 per seat per month billed monthly; Fir annual USD 9 per seat per month equivalent billed annually; figures exclude optional services. Fir pricing-table excerpt does not mention SSO. Supplied current Fir SSO docs: \"SAML SSO is available on Enterprise, with a minimum of 20 paid seats.\" No SSO statement is supplied for Fir's other plans.");
  const er = add(it, "01", "entity-record", "fir-entity", "01-competitor-claims.md:12-14",
    "Owner-supplied Fir product record, 01-competitor-claims.md:12-14: supplied current Fir SSO docs state \"SAML SSO is available on Enterprise, with a minimum of 20 paid seats.\" No SSO statement is supplied for Fir's other plans.");
  const r1 = "Component review. /compare assertion A (line 17) says Fir has no SSO and cites the pricing table as proof; supplied Fir SSO docs (line 13) state SAML SSO is available on Enterprise with a 20-paid-seat minimum, and an excerpt's silence is not proof. /compare assertion B (line 18) claims Cedar is cheaper on every billing option; supplied annual figures are Cedar USD 10 vs Fir USD 9 (lines 7, 9). /monthly-comparison caption (line 21) is supported: 15 - 12 = 3 on monthly billing. Item fails because of A and B; the caption is clean.";
  review(it, "quality-claims", "fail", r1, [c, cs]);
  review(it, "aeo-answer-evidence", "fail", "Comparison answers A and B on draft /compare (lines 17-18) are contradicted by the supplied pricing and SSO records (lines 6-14); the monthly caption (line 21) is supported.", [c, cs]);
  review(it, "aio-entity-consistency", "fail", "Assertion A (line 17) states a Fir entity fact (no SSO) that conflicts with the supplied Fir SSO documentation (line 13). Only this supplied record was compared; no other source or live surface was inspected.", [c, er]);
  findings.push({ findingId: "F1-fir-sso", title: "Draft /compare says Fir has no SSO, contradicting the supplied Fir SSO documentation", affectedItemIds: [it.itemId], ruleIds: ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency"], dimensions: ["quality", "aeo", "aio"], evidenceIds: [c, cs, er], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal only: remove assertion A or replace it with the supplied fact, e.g. that Fir's supplied SSO documentation says SAML SSO is available on Enterprise with a minimum of 20 paid seats, and that no SSO statement was supplied for Fir's other plans. Do not cite the pricing table as proof of absence.",
    verification: "Re-read the revised assertion against 01-competitor-claims.md:12-14; confirm it keeps the Enterprise and 20-paid-seat qualifiers, the November 2026 US scope, and makes no claim about Fir's other plans.", ownerRole: "Content owner (comparison page)", effort: "small", action: "update", actionReason: "Supplied documentation directly contradicts the draft assertion." });
  findings.push({ findingId: "F2-every-billing-option", title: "Draft /compare claims Cedar is cheaper on every billing option; supplied annual prices show Fir lower", affectedItemIds: [it.itemId], ruleIds: ["quality-claims", "aeo-answer-evidence"], dimensions: ["quality", "aeo"], evidenceIds: [c, cs], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal only: limit assertion B to monthly billing (Cedar USD 12 vs Fir USD 15 per seat per month) and state the annual figures as supplied (Cedar USD 10 vs Fir USD 9 per seat per month equivalent), or reuse the already-supported /monthly-comparison caption.",
    verification: "Recompute each billing option from 01-competitor-claims.md:6-9 and confirm the revised wording keeps November 2026, US, USD-before-tax and billing-period scope.", ownerRole: "Content owner (comparison page)", effort: "small", action: "update", actionReason: "Supplied annual prices contradict the universal claim." });
}
// 02
{
  const it = item("02"), c = snap(it).evidenceId;
  const cs = add(it, "02", "claim-sources", "rows", "02-measurement-windows.md:3-16",
    "Owner-supplied synthetic rows, 02-measurement-windows.md:3-16 (one campaign, USD, October 2026): spend complete for October 1–31: USD 3000; conversion export covers only October 1–7: 35 completed conversions; no conversion data exists for October 8–31; October 1–7 spend USD 700. Independent referral report: 15 October sessions have an identified AI-assistant referrer; other sessions have unknown origin; no model estimating untracked AI influence, incrementality test, complete session count or conversion linkage exists.");
  review(it, "quality-claims", "fail", "Component review. Draft A (line 10) labels 3000/35 as October cost per conversion, dividing full-month spend (Oct 1–31) by a conversion count covering only Oct 1–7; the month-level figure is unsupported. Draft B (lines 17-18) asserts 15 tracked sessions prove 150 total AI sessions using a one-in-ten tracking ratio that no supplied record supports (lines 15-16). The verified-window caption (lines 11-12) is supported: 700/35 = 20 for Oct 1–7 with the remainder declared unmeasured. Item fails because of Drafts A and B; the caption is clean.", [c, cs]);
  findings.push({ findingId: "F3-october-cpa-window", title: "Draft A reports an October cost per conversion from full-month spend and a seven-day conversion count", affectedItemIds: [it.itemId], ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c, cs], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal only: withdraw Draft A and use the verified-window caption (October 1–7: USD 20 per completed conversion, 700 divided by 35, rest of month unmeasured). Report full-October cost per conversion as unavailable until a conversion export for October 8–31 is supplied; do not treat the missing days as zero conversions.",
    verification: "Confirm numerator and denominator of any published ratio cover the same dates in the same export, and recompute it; confirm no October-wide ratio appears while conversions for October 8–31 are unmeasured.", ownerRole: "Analytics/reporting owner", effort: "small", action: "update", actionReason: "Numerator and denominator windows do not match." });
  findings.push({ findingId: "F4-ai-sessions-extrapolation", title: "Draft B extrapolates 15 identified AI-referrer sessions to 150 as proven, with no supplied tracking-rate basis", affectedItemIds: [it.itemId], ruleIds: ["quality-claims"], dimensions: ["quality"], evidenceIds: [c, cs], severity: "medium", confidence: "high", classification: "observed",
    remediation: "Proposal only: replace Draft B with the observed count (15 October sessions with an identified AI-assistant referrer; other sessions of unknown origin) and remove the 150 total, the one-in-ten ratio and the word prove. Keep it separate from the campaign conversion counts.",
    verification: "Confirm the revised sentence states only the identified-referrer count and its October window, makes no total or causal claim, and is not combined with campaign conversions.", ownerRole: "Analytics/reporting owner", effort: "small", action: "update", actionReason: "The multiplier and total have no supplied evidence." });
}
// 03
{
  const it = item("03"), c = snap(it).evidenceId;
  const cs = add(it, "03", "claim-sources", "policy", "03-template-service-area.md:4-5",
    "Owner-approved current policy, 03-template-service-area.md:4-5: North serves same-day delivery, Monday–Friday, orders placed before 10:00 local time. South serves next-business-day delivery only.");
  const er = add(it, "03", "entity-record", "service-record", "03-template-service-area.md:4-5,13-16",
    "Owner-approved service record, 03-template-service-area.md:4-5: North same-day delivery Monday–Friday for orders placed before 10:00 local time; South next-business-day delivery only. Lines 13-16: /terms-v1 is a clearly labeled 2024 archive kept for old orders, accurately describing the 2024 service contract when South had same-day service; it links to the two current pages for new orders; no mixed-version customer task or misleading current-policy label is present.");
  const im = add(it, "03", "inventory-map", "inventory", "03-template-service-area.md:3,18-20",
    "Owner-declared inventory, 03-template-service-area.md:3: complete inventory is /north-delivery, /south-delivery, /terms-v1. Lines 18-20: the two current pages serve different regions and the owner wants both retained; shared layout and repeated generic contact wording are intentional; no ranking, query/page overlap, backlink, conversion or search-engine selection data exists. Only the quoted policy passages were supplied, not the full pages.");
  const f = "The current /south-delivery policy passage (lines 10-11) states same-day delivery Monday–Friday before 10:00, while the approved current policy (line 5) is next-business-day delivery only for South.";
  review(it, "quality-claims", "fail", `Component review. ${f} /north-delivery (lines 8-9) matches the approved North policy (lines 4-5). /terms-v1 is an owner-confirmed labeled 2024 archive that is accurate for its period (lines 13-16). Item fails because of /south-delivery only.`, [c, cs]);
  review(it, "aeo-answer-evidence", "fail", `${f} The page's answer to what delivery South receives is contradicted by the approved policy; North's answer is supported.`, [c, cs]);
  review(it, "aio-entity-consistency", "fail", `${f} The South service fact is inconsistent with the approved service record; North and the dated archive are consistent with it.`, [c, er]);
  review(it, "portfolio-contradictions", "fail", `${f} Within the declared three-page inventory the current South page contradicts the approved record. The 2024 archive's same-day South statement is not a contradiction because it is labeled and period-scoped (lines 13-16).`, [c, er, im]);
  findings.push({ findingId: "F5-south-same-day", title: "Current /south-delivery promises same-day delivery; approved policy is next-business-day only", affectedItemIds: [it.itemId], ruleIds: ["quality-claims", "aeo-answer-evidence", "aio-entity-consistency", "portfolio-contradictions"], dimensions: ["quality", "aeo", "aio", "portfolio"], evidenceIds: [c, cs, er, im], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal only: rewrite the /south-delivery policy passage to state next-business-day delivery only, per the approved policy. The owner must supply any South cut-off or day conditions before they are stated; none is in the record. Keep /north-delivery, /terms-v1 and both regional pages as they are.",
    verification: "Compare the revised /south-delivery passage word for word with 03-template-service-area.md:4-5; confirm no same-day, Monday–Friday or 10:00 wording remains for South unless the owner supplies it, and that /north-delivery and /terms-v1 are unchanged.", ownerRole: "Content owner (service pages)", effort: "small", action: "update", actionReason: "Current page contradicts the approved current policy." });
}
// 04
{
  const it = item("04"), c = snap(it).evidenceId;
  const cs = add(it, "04", "claim-sources", "product-record", "04-editorial-proof.md:3-5,10-13,15-18",
    "Owner-approved records, 04-editorial-proof.md:3-5: for 20 observed onboarding sessions in a supplied study, the median completion time was 15 minutes; the owner supplies no maximum time, guarantee, refund policy, percentile distribution or wider population estimate. Lines 10-13: the approved permissions policy states exactly that editors cannot delete a workspace and owners can; no additional conditions are needed to answer this permission question. Lines 15-18: /status-codes has a complete, accurate table for its declared technical task; its terse language, punctuation and lack of a purchase CTA are approved by the documentation owner. The table itself was not supplied.");
  review(it, "quality-claims", "fail", "Component review. The draft landing-page claim (line 6) guarantees every team finishes setup in 10 minutes; the approved record (lines 3-5) is a 15-minute median over 20 observed sessions with no guarantee, maximum or population estimate supplied. The permissions FAQ (line 9) matches the approved permissions policy (lines 10-11). /status-codes is owner-stated complete and accurate (lines 15-17); its table was not supplied for independent inspection. Item fails because of the landing-page claim only.", [c, cs]);
  review(it, "aeo-answer-evidence", "fail", "The landing-page answer to how long setup takes (line 6) is unsupported by and inconsistent with the approved record (lines 3-5). The permissions FAQ answer (line 9) is supported by the approved policy (lines 10-11).", [c, cs]);
  findings.push({ findingId: "F6-setup-guarantee", title: "Draft landing page guarantees 10-minute setup for every team; the record is a 15-minute median with no guarantee", affectedItemIds: [it.itemId], ruleIds: ["quality-claims", "aeo-answer-evidence"], dimensions: ["quality", "aeo"], evidenceIds: [c, cs], severity: "high", confidence: "high", classification: "observed",
    remediation: "Proposal only: remove the guarantee, the word every and the 10-minute figure. If a time is stated, use the supplied statistic with its scope: in a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes. Do not add a maximum, typical range or population claim.",
    verification: "Compare the revised claim with 04-editorial-proof.md:3-5; confirm statistic (median), value (15 minutes), sample (20 observed sessions) and absence of guarantee language.", ownerRole: "Content owner (landing page) with product/legal review of any guarantee", effort: "small", action: "update", actionReason: "Guarantee and figure exceed the approved record." });
}
writeFileSync(out, JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log(now, reviews.length, findings.length, evidence.length);
