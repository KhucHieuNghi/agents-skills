# Synthetic dossiers — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T14:01:43\.614Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 0a9b55cf\-ab95\-4dc8\-a8a8\-77fe04aab41b\. 6 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 4 |
| In scope | 4 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 4 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F1\-fir\-sso | Draft /compare says Fir has no SSO, contradicting the supplied Fir SSO documentation | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency | quality, aeo, aio | high | high | observed | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | update | reviewer\-proposal | Supplied documentation directly contradicts the draft assertion\. | Proposal only: remove assertion A or replace it with the supplied fact, e\.g\. that Fir&\#39;s supplied SSO documentation says SAML SSO is available on Enterprise with a minimum of 20 paid seats, and that no SSO statement was supplied for Fir&\#39;s other plans\. Do not cite the pricing table as proof of absence\. | Re\-read the revised assertion against 01\-competitor\-claims\.md:12\-14; confirm it keeps the Enterprise and 20\-paid\-seat qualifiers, the November 2026 US scope, and makes no claim about Fir&\#39;s other plans\. | Content owner \(comparison page\) | small | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1, ctx\-01\-pricing\-sso, ctx\-01\-fir\-entity |
| F2\-every\-billing\-option | Draft /compare claims Cedar is cheaper on every billing option; supplied annual prices show Fir lower | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | update | reviewer\-proposal | Supplied annual prices contradict the universal claim\. | Proposal only: limit assertion B to monthly billing \(Cedar USD 12 vs Fir USD 15 per seat per month\) and state the annual figures as supplied \(Cedar USD 10 vs Fir USD 9 per seat per month equivalent\), or reuse the already\-supported /monthly\-comparison caption\. | Recompute each billing option from 01\-competitor\-claims\.md:6\-9 and confirm the revised wording keeps November 2026, US, USD\-before\-tax and billing\-period scope\. | Content owner \(comparison page\) | small | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1, ctx\-01\-pricing\-sso |
| F3\-october\-cpa\-window | Draft A reports an October cost per conversion from full\-month spend and a seven\-day conversion count | quality\-claims | quality | high | high | observed | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | update | reviewer\-proposal | Numerator and denominator windows do not match\. | Proposal only: withdraw Draft A and use the verified\-window caption \(October 1–7: USD 20 per completed conversion, 700 divided by 35, rest of month unmeasured\)\. Report full\-October cost per conversion as unavailable until a conversion export for October 8–31 is supplied; do not treat the missing days as zero conversions\. | Confirm numerator and denominator of any published ratio cover the same dates in the same export, and recompute it; confirm no October\-wide ratio appears while conversions for October 8–31 are unmeasured\. | Analytics/reporting owner | small | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e, ctx\-02\-rows |
| F5\-south\-same\-day | Current /south\-delivery promises same\-day delivery; approved policy is next\-business\-day only | quality\-claims, aeo\-answer\-evidence, aio\-entity\-consistency, portfolio\-contradictions | quality, aeo, aio, portfolio | high | high | observed | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | update | reviewer\-proposal | Current page contradicts the approved current policy\. | Proposal only: rewrite the /south\-delivery policy passage to state next\-business\-day delivery only, per the approved policy\. The owner must supply any South cut\-off or day conditions before they are stated; none is in the record\. Keep /north\-delivery, /terms\-v1 and both regional pages as they are\. | Compare the revised /south\-delivery passage word for word with 03\-template\-service\-area\.md:4\-5; confirm no same\-day, Monday–Friday or 10:00 wording remains for South unless the owner supplies it, and that /north\-delivery and /terms\-v1 are unchanged\. | Content owner \(service pages\) | small | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06, ctx\-03\-policy, ctx\-03\-service\-record, ctx\-03\-inventory |
| F6\-setup\-guarantee | Draft landing page guarantees 10\-minute setup for every team; the record is a 15\-minute median with no guarantee | quality\-claims, aeo\-answer\-evidence | quality, aeo | high | high | observed | 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | update | reviewer\-proposal | Guarantee and figure exceed the approved record\. | Proposal only: remove the guarantee, the word every and the 10\-minute figure\. If a time is stated, use the supplied statistic with its scope: in a supplied study of 20 observed onboarding sessions, the median completion time was 15 minutes\. Do not add a maximum, typical range or population claim\. | Compare the revised claim with 04\-editorial\-proof\.md:3\-5; confirm statistic \(median\), value \(15 minutes\), sample \(20 observed sessions\) and absence of guarantee language\. | Content owner \(landing page\) with product/legal review of any guarantee | small | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030, ctx\-04\-product\-record |
| F4\-ai\-sessions\-extrapolation | Draft B extrapolates 15 identified AI\-referrer sessions to 150 as proven, with no supplied tracking\-rate basis | quality\-claims | quality | medium | high | observed | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | update | reviewer\-proposal | The multiplier and total have no supplied evidence\. | Proposal only: replace Draft B with the observed count \(15 October sessions with an identified AI\-assistant referrer; other sessions of unknown origin\) and remove the 150 total, the one\-in\-ten ratio and the word prove\. Keep it separate from the campaign conversion counts\. | Confirm the revised sentence states only the identified\-referrer count and its October window, makes no total or causal claim, and is not combined with campaign conversions\. | Analytics/reporting owner | small | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e, ctx\-02\-rows |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 12 | 3 | 9 | 0 |
| aio | 12 | 2 | 10 | 0 |
| geo | 12 | 0 | 12 | 0 |
| portfolio | 16 | 1 | 15 | 0 |
| quality | 20 | 8 | 12 | 0 |
| seo | 32 | 0 | 32 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | pending | Snapshot review incomplete | 26 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | pending | Snapshot review incomplete | 26 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | pending | Snapshot review incomplete | 26 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-claims | quality | fail | Component review\. Draft A \(line 10\) labels 3000/35 as October cost per conversion, dividing full\-month spend \(Oct 1–31\) by a conversion count covering only Oct 1–7; the month\-level figure is unsupported\. Draft B \(lines 17\-18\) asserts 15 tracked sessions prove 150 total AI sessions using a one\-in\-ten tracking ratio that no supplied record supports \(lines 15\-16\)\. The verified\-window caption \(lines 11\-12\) is supported: 700/35 = 20 for Oct 1–7 with the remainder declared unmeasured\. Item fails because of Drafts A and B; the caption is clean\. | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e, ctx\-02\-rows |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-02 |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-claims | quality | fail | Component review\. /compare assertion A \(line 17\) says Fir has no SSO and cites the pricing table as proof; supplied Fir SSO docs \(line 13\) state SAML SSO is available on Enterprise with a 20\-paid\-seat minimum, and an excerpt&\#39;s silence is not proof\. /compare assertion B \(line 18\) claims Cedar is cheaper on every billing option; supplied annual figures are Cedar USD 10 vs Fir USD 9 \(lines 7, 9\)\. /monthly\-comparison caption \(line 21\) is supported: 15 \- 12 = 3 on monthly billing\. Item fails because of A and B; the caption is clean\. | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1, ctx\-01\-pricing\-sso |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-01 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-entity\-consistency | aio | fail | Assertion A \(line 17\) states a Fir entity fact \(no SSO\) that conflicts with the supplied Fir SSO documentation \(line 13\)\. Only this supplied record was compared; no other source or live surface was inspected\. | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1, ctx\-01\-fir\-entity |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | aeo\-answer\-evidence | aeo | fail | Comparison answers A and B on draft /compare \(lines 17\-18\) are contradicted by the supplied pricing and SSO records \(lines 6\-14\); the monthly caption \(line 21\) is supported\. | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1, ctx\-01\-pricing\-sso |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-claims | quality | fail | Component review\. The draft landing\-page claim \(line 6\) guarantees every team finishes setup in 10 minutes; the approved record \(lines 3\-5\) is a 15\-minute median over 20 observed sessions with no guarantee, maximum or population estimate supplied\. The permissions FAQ \(line 9\) matches the approved permissions policy \(lines 10\-11\)\. /status\-codes is owner\-stated complete and accurate \(lines 15\-17\); its table was not supplied for independent inspection\. Item fails because of the landing\-page claim only\. | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030, ctx\-04\-product\-record |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-04 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | aeo\-answer\-evidence | aeo | fail | The landing\-page answer to how long setup takes \(line 6\) is unsupported by and inconsistent with the approved record \(lines 3\-5\)\. The permissions FAQ answer \(line 9\) is supported by the approved policy \(lines 10\-11\)\. | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030, ctx\-04\-product\-record |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-claims | quality | fail | Component review\. The current /south\-delivery policy passage \(lines 10\-11\) states same\-day delivery Monday–Friday before 10:00, while the approved current policy \(line 5\) is next\-business\-day delivery only for South\. /north\-delivery \(lines 8\-9\) matches the approved North policy \(lines 4\-5\)\. /terms\-v1 is an owner\-confirmed labeled 2024 archive that is accurate for its period \(lines 13\-16\)\. Item fails because of /south\-delivery only\. | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06, ctx\-03\-policy |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | text\-03 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-entity\-consistency | aio | fail | The current /south\-delivery policy passage \(lines 10\-11\) states same\-day delivery Monday–Friday before 10:00, while the approved current policy \(line 5\) is next\-business\-day delivery only for South\. The South service fact is inconsistent with the approved service record; North and the dated archive are consistent with it\. | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06, ctx\-03\-service\-record |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | aeo\-answer\-evidence | aeo | fail | The current /south\-delivery policy passage \(lines 10\-11\) states same\-day delivery Monday–Friday before 10:00, while the approved current policy \(line 5\) is next\-business\-day delivery only for South\. The page&\#39;s answer to what delivery South receives is contradicted by the approved policy; North&\#39;s answer is supported\. | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06, ctx\-03\-policy |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-contradictions | portfolio | fail | The current /south\-delivery policy passage \(lines 10\-11\) states same\-day delivery Monday–Friday before 10:00, while the approved current policy \(line 5\) is next\-business\-day delivery only for South\. Within the declared three\-page inventory the current South page contradicts the approved record\. The 2024 archive&\#39;s same\-day South statement is not a contradiction because it is labeled and period\-scoped \(lines 13\-16\)\. | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06, ctx\-03\-inventory, ctx\-03\-service\-record |
| f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 8f4f01ee69b5771cd62da3843c2198167f3ebbd06dd3713df4ab789a014ebf8e | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | local\-file | 2026\-11\-16T14:00:37\.846Z | 0 full elapsed days | [evidence/2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff\.txt](evidence/2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| aca5ebf7b629e6b0fd571a2072ebbd51542ad0a19bc3f5a951bc4810d812cea1 | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | local\-file | 2026\-11\-16T14:00:37\.847Z | 0 full elapsed days | [evidence/799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9\.txt](evidence/799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a7fe12fa9058a19f5c4e73495a70661f2f210bb1f5fa586df92e40a2a9503030 | 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | local\-file | 2026\-11\-16T14:00:37\.848Z | 0 full elapsed days | [evidence/914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966\.txt](evidence/914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 07c45db9e5316f6c38aa4fc4d49b7a18e17abd9ce8c86f05c30c1ec9b824ab06 | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | local\-file | 2026\-11\-16T14:00:37\.849Z | 0 full elapsed days | [evidence/f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018\.txt](evidence/f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| text\-01 | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | identity\-extraction\-of\-plain\-markdown | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/text\-01\.txt](evidence/text-01.txt) | 78ae98b9ff3173c3eb6a2607f5ca808a869fb2260588b85142ef263524b2ca08 | Plain Markdown source text copied unchanged; not rendered output |
| text\-02 | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | identity\-extraction\-of\-plain\-markdown | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/text\-02\.txt](evidence/text-02.txt) | c7bf7c1cbaab988ecd467d39cbb700d7af443f0684bc1316a46af03e5c95c975 | Plain Markdown source text copied unchanged; not rendered output |
| text\-03 | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | identity\-extraction\-of\-plain\-markdown | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/text\-03\.txt](evidence/text-03.txt) | 7215e6edd3d998e0e51cde50c39136389bf37349a0351825db23560ea62ff65f | Plain Markdown source text copied unchanged; not rendered output |
| text\-04 | 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | identity\-extraction\-of\-plain\-markdown | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/text\-04\.txt](evidence/text-04.txt) | 0dd28fa3b7a1b1c1c144df34a31431fa083c76415f95541479516a5000bc5791 | Plain Markdown source text copied unchanged; not rendered output |
| ctx\-01\-pricing\-sso | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-01\-pricing\-sso\.txt](evidence/ctx-01-pricing-sso.txt) | 1b51e546ed066f18229fe32e21289c380ae621d43e5b679604493db343af5c14 | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-01\-fir\-entity | 799f055dd8f6702ddc257f1091ecfbd351456e0c1f14b4166ba56958d3be26b9 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-01\-fir\-entity\.txt](evidence/ctx-01-fir-entity.txt) | 46b27e257a0ffe0b0635d2994773c230c56defc9a254916cb29f399b73d65f5d | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-02\-rows | 2e331ae7fc27f0f0df4848edf6aadabd9ae63377170b9ca238feeb15a9ab05ff | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-02\-rows\.txt](evidence/ctx-02-rows.txt) | f7a06816cba1a4e3d7e9d073c37cbeb0706103b9faf38e06d354a2a61032ffd2 | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-03\-policy | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-03\-policy\.txt](evidence/ctx-03-policy.txt) | fca24d646829e0c028ca8715c3524d7fbe8c02e448297e18471e0ffae55d53df | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-03\-service\-record | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-03\-service\-record\.txt](evidence/ctx-03-service-record.txt) | deaf407634480227b6dc6f2e058c9b5d69b2fcef533d0c2cf16d0a698110d286 | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-03\-inventory | f690a976fc37c486766d4d067dad11f3900f4083f20fcd4eeab00bd444468018 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-03\-inventory\.txt](evidence/ctx-03-inventory.txt) | 63f1a058b2b39528856c57ec2904f1bb0a41dca994797c5794987f58895e3952 | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |
| ctx\-04\-product\-record | 914216d1c18ad6240d7d754f2be2357439e5bc5f961350f35ab2abb1264d7966 | owner\-context\-from\-task | 2026\-11\-16T14:01:43\.504Z | 0 full elapsed days | [evidence/ctx\-04\-product\-record\.txt](evidence/ctx-04-product-record.txt) | aac5bef2038542bdbd256a30cb5735f16cee884c8269b78eec676fe9f9ea5260 | Synthetic owner\-supplied comparison record stated inside the dossier; approved comparison basis for this scenario only, not independently verified live behavior\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
