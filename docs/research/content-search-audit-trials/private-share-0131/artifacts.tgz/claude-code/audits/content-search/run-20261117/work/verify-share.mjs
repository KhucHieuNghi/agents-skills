import { readFileSync, readdirSync, lstatSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
const [share, policyFile, inputPolicy] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const values = [...JSON.parse(readFileSync(policyFile, "utf8")).values, ...JSON.parse(readFileSync(inputPolicy, "utf8")).values];
const fragments = ["reviewer-only", "example.test", "SYNTHETIC-CASE", "7391", "nlo2o987", "nks-private-share", "/var/folders", "/private/", "/Users/", "snbf5txj", "file://", "quokkapps"];
const files = readdirSync(share);
const out = { files: files.length, leaks: [], fragmentHits: [], nonRegular: [], hashMismatch: [], unlisted: [], brokenLinks: [], redactedMarkers: 0 };
const manifest = JSON.parse(readFileSync(path.join(share, "redaction-manifest.json"), "utf8"));
const listed = new Map([...manifest.records, ...manifest.documents].map((r) => [r.artifact, r.snapshotHash]));
for (const f of files) {
  const full = path.join(share, f);
  if (!lstatSync(full).isFile()) { out.nonRegular.push(f); continue; }
  const buf = readFileSync(full); const text = buf.toString("utf8"); const lower = text.toLowerCase();
  for (const v of values) if (lower.includes(v.toLowerCase())) out.leaks.push(f);
  let decoded = text; try { decoded = decodeURIComponent(text); } catch {}
  for (const v of values) if (decoded.includes(v)) out.leaks.push(f + " (decoded)");
  for (const fr of fragments) if (lower.includes(fr.toLowerCase())) out.fragmentHits.push(`${f}: ${fr}`);
  if (/[A-Za-z0-9+/=]{40,}/.test(text) && Buffer.from(values[0]).toString("base64").length && text.includes(Buffer.from(values[0]).toString("base64"))) out.leaks.push(f + " (b64)");
  out.redactedMarkers += (text.match(/\[REDACTED\]/g) || []).length;
  if (f !== "redaction-manifest.json") { if (!listed.has(f)) out.unlisted.push(f); else if (listed.get(f) !== hash(buf)) out.hashMismatch.push(f); }
  if (/\.(md|html)$/.test(f)) for (const m of text.matchAll(/(?:\]\(|href=")([^)"#]+)/g)) { const t = decodeURIComponent(m[1]); if (/^[a-z]+:/i.test(t) ) { if (!/^https?:/.test(t)) out.brokenLinks.push(`${f}: ${t}`); continue; } if (path.isAbsolute(t) || t.includes("..") || !files.includes(t)) out.brokenLinks.push(`${f}: ${t}`); }
}
for (const a of listed.keys()) if (!files.includes(a)) out.unlisted.push("missing:" + a);
out.manifestKind = manifest.kind; out.records = manifest.records.length; out.replacements = manifest.records.reduce((n, r) => n + r.replacements, 0);
console.log(JSON.stringify(out, null, 1));
