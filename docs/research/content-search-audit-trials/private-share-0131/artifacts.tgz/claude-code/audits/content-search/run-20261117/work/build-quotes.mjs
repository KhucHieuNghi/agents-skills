import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [root, reportRel, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const report = readFileSync(path.join(root, reportRel));
const rl = report.toString("utf8").split("\n");
const quotes = [];
for (const [i, line] of rl.entries()) {
  const m = line.match(/^- (0[12]-[a-z]+\.md):(\d+) — "(.*)"$/);
  if (!m) continue;
  const src = "targets/" + m[1];
  quotes.push({ quoteId: `q-${m[1]}-${m[2]}`, source: src, sourceLabel: m[1], sourceHash: hash(readFileSync(path.join(root, src))), startLine: +m[2], endLine: +m[2], reportStartLine: i + 1, reportEndLine: i + 1, normalization: "exact", quote: m[3] });
}
writeFileSync(out, JSON.stringify({ root, report: reportRel, reportHash: hash(report), quotes }, null, 2) + "\n");
console.log(quotes.length, (report.toString().match(/"[^"]{20,}"/g) || []).length);
