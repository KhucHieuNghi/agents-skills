// Host-authored review bundle builder for this audit run (not target content).
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [runDir, out] = process.argv.slice(2);
const hash = (v) => createHash("sha256").update(v).digest("hex");
const lines = (f) => readFileSync(path.join(runDir, f), "utf8").trim().split("\n").map((l) => JSON.parse(l));
const inventory = lines("inventory.jsonl");
const evidenceAll = lines("evidence.jsonl");
const S = inventory.find((i) => i.path.endsWith("01-service.md"));
const P = inventory.find((i) => i.path.endsWith("02-procedure.md"));
const snap = (item) => evidenceAll.find((e) => e.itemId === item.itemId && e.kind === "content");
const sS = snap(S), sP = snap(P);
const L = (s, n) => s.value.split("\n")[n - 1];
if (L(sP, 4).replace("Complete approved procedure: ", "") !== L(sP, 5).replace("Draft help answer: ", "")) throw new Error("procedure texts differ");
const now = new Date().toISOString();
const artifacts = {}, evidence = [];
const reviewer = "content-search-audit host reviewer (Claude agent)";
function add(item, key, kind, value, locator, sources, limitations) {
  const evidenceId = `${key}`;
  const artifact = `evidence/${key}.txt`;
  artifacts[artifact] = value;
  evidence.push({
    evidenceId, itemId: item.itemId, kind, method: "host-derived-from-supplied-document",
    collectedAt: now, locator, snapshotHash: hash(value), byteLength: Buffer.byteLength(value),
    redaction: "none; derived from authorized source content retained locally",
    limitations, value, artifact, encoding: "utf8", sourceEvidenceIds: sources,
  });
  return evidenceId;
}
const ownerLimit = "Owner-supplied synthetic fixture context taken from the supplied document; an approved comparison basis for this audit, not independently verified policy, live behavior or public source.";
const e = {};
// Service item
e.sAud = add(S, "service-audience-context", "audience-context",
  `Audience and task stated in 01-service.md:4 — "${L(sS, 4)}"`, "01-service.md:4", [sS.evidenceId], [ownerLimit]);
e.sClaim = add(S, "service-approved-policy", "claim-sources",
  `Approved record stated in 01-service.md:5 — "${L(sS, 5)}" No effective date, market or version is supplied.`, "01-service.md:5", [sS.evidenceId], [ownerLimit, "Undated; currency rests on the document's own label."]);
e.sEnt = add(S, "service-entity-record", "entity-record",
  `Entity record for the Standard plan support commitment, from 01-service.md:5 — "${L(sS, 5)}" Entity: Standard plan (support). Attribute: reply time. Value: two business days.`, "01-service.md:5", [sS.evidenceId], [ownerLimit, "Single attribute only; no other entity facts are supplied."]);
e.sQ = add(S, "service-question-set", "question-set",
  `Task-derived question: "What is the support response time for the Standard plan?" Derived from the audience task stated in 01-service.md:4 — "${L(sS, 4)}" This is the information need the stated task entails; it is not an observed search query, support ticket or AI prompt.`, "01-service.md:4", [sS.evidenceId], [ownerLimit, "Task-derived, not observed demand; no query volume or phrasing evidence."]);
e.sMedia = add(S, "service-media-inventory", "media-inventory",
  "Media inventory of the captured Markdown source 01-service.md (lines 1-11): 0 images, 0 video, 0 audio, 0 embeds, 0 links. The only markup is one level-1 heading and one HTML comment.", "01-service.md:1-11", [sS.evidenceId], ["Covers the supplied source text only; a rendered or published page was not supplied."]);
e.sText = add(S, "service-extracted-text", "extracted-text", sS.value, "01-service.md:1-11", [sS.evidenceId], ["Identity extraction: the supplied source is plain UTF-8 Markdown, reproduced unchanged."]);
// Procedure item
e.pAud = add(P, "procedure-audience-context", "audience-context",
  `Audience and task stated in 02-procedure.md:3 — "${L(sP, 3)}"`, "02-procedure.md:3", [sP.evidenceId], [ownerLimit]);
e.pClaim = add(P, "procedure-approved-record", "claim-sources",
  `Approved record stated in 02-procedure.md:4 — "${L(sP, 4)}" Currency and scope statement in 02-procedure.md:6 — "${L(sP, 6)}" No effective date is supplied.`, "02-procedure.md:4-6", [sP.evidenceId], [ownerLimit, "Undated; currency rests on the document's own statement."]);
e.pEnt = add(P, "procedure-entity-record", "entity-record",
  `Entity record for the Standard customer support-ticket procedure, from 02-procedure.md:4 — "${L(sP, 4)}" Scope statement from 02-procedure.md:6 — "${L(sP, 6)}"`, "02-procedure.md:4-6", [sP.evidenceId], [ownerLimit]);
e.pQ = add(P, "procedure-question-set", "question-set",
  `Task-derived question: "How do I open a support ticket as a Standard customer?" Derived from the audience task stated in 02-procedure.md:3 — "${L(sP, 3)}" and the document's own label "Draft help answer" (02-procedure.md:5). Not an observed search query, support ticket or AI prompt.`, "02-procedure.md:3-5", [sP.evidenceId], [ownerLimit, "Task-derived, not observed demand; no query volume or phrasing evidence."]);
e.pMedia = add(P, "procedure-media-inventory", "media-inventory",
  "Media inventory of the captured Markdown source 02-procedure.md (lines 1-7): 0 images, 0 video, 0 audio, 0 embeds, 0 links. The only markup is one level-1 heading.", "02-procedure.md:1-7", [sP.evidenceId], ["Covers the supplied source text only; a rendered or published page was not supplied."]);
e.pText = add(P, "procedure-extracted-text", "extracted-text", sP.value, "02-procedure.md:1-7", [sP.evidenceId], ["Identity extraction: the supplied source is plain UTF-8 Markdown, reproduced unchanged."]);
// Cross-item inventory map (one scoped record per item, citing both snapshots)
const map = `Inventory map of the full declared inventory (2 items). Item 01-service.md — audience/task: "${L(sS, 4)}" (01-service.md:4); purpose: state the Standard plan support response time. Item 02-procedure.md — audience/task: "${L(sP, 3)}" (02-procedure.md:3); purpose: explain how to open a support ticket. Relationship statement in 02-procedure.md:6 — "${L(sP, 6)}" Neither source contains a link to the other.`;
const mapLimit = ["Host-derived cross-item map of the two declared documents only; it does not describe an unseen live site.", ownerLimit];
e.sMap = add(S, "service-inventory-map", "inventory-map", map, "01-service.md:4; 02-procedure.md:3-6", [sS.evidenceId, sP.evidenceId], mapLimit);
e.pMap = add(P, "procedure-inventory-map", "inventory-map", map, "01-service.md:4; 02-procedure.md:3-6", [sS.evidenceId, sP.evidenceId], mapLimit);

const reviews = [];
const r = (item, ruleId, status, reason, evidenceIds) => reviews.push({ itemId: item.itemId, ruleId, status, reason, evidenceIds, reviewer, reviewedAt: now });
const conflict = "The draft page statement (01-service.md:6) promises every Standard customer a guaranteed reply within one hour, while the supplied current approved policy (01-service.md:5) is a reply within two business days.";
// --- Service
r(S, "quality-task-fit", "fail", `The stated audience is checking the Standard plan support response time (01-service.md:4). ${conflict} The only response time the draft gives is not the approved one, so the draft does not let the audience complete the task accurately.`, [sS.evidenceId, e.sAud]);
r(S, "quality-claims", "fail", `${conflict} Both statements concern the same plan and the same commitment; the draft's one-hour figure, its guarantee and its every-customer scope are all unsupported by the approved record. This is the item's only material factual claim.`, [sS.evidenceId, e.sClaim]);
r(S, "quality-freshness", "unknown", "The approved policy is labelled current but carries no date, version or market, and nothing supplied shows whether the draft's one-hour figure is an outdated value or was never approved. The mismatch itself is recorded under quality-claims; its cause in time is unresolved. Needed: effective date or revision history of the support policy.", [sS.evidenceId, e.sClaim]);
r(S, "quality-accessible-media", "not-applicable", "The complete captured source (lines 1-11) contains no image, video, audio or embed, so there is no informative media requiring a text alternative or transcript anywhere in the item.", [sS.evidenceId, e.sMedia]);
r(S, "seo-metadata", "unknown", "The supplied document is a labelled fixture record containing one draft sentence; the draft page's own title, description and headings are not supplied. The level-1 heading labels the fixture, not the page. Needed: the draft page source including its title, meta description and headings.", [sS.evidenceId, e.sAud]);
r(S, "aio-entity-consistency", "fail", `Entity fact conflict for the Standard plan support reply time. ${conflict} This is a source-consistency defect; it is not evidence of how any AI system represents the plan.`, [sS.evidenceId, e.sEnt]);
r(S, "aio-retrievable-facts", "fail", `The concrete fact the audience needs is the approved reply time. ${conflict} The draft page statement therefore exposes a retrievable but unapproved figure and omits the approved one. Readable facts do not establish retrieval or citation by any engine.`, [sS.evidenceId, e.sAud]);
r(S, "aeo-question-coverage", "fail", `For the task-derived question about Standard plan support response time, the draft gives a direct answer, but not a supported one. ${conflict} No supported answer to the question exists in the draft page statement.`, [sS.evidenceId, e.sQ]);
r(S, "aeo-answer-context", "fail", `Read on its own, the draft answer (01-service.md:6) is an unconditional guarantee to every Standard customer measured in clock hours. The approved commitment (01-service.md:5) is measured in business days and is not expressed as a guarantee. The draft answer drops the business-day condition and adds an absolute scope the record does not contain.`, [sS.evidenceId, e.sQ]);
r(S, "aeo-answer-evidence", "fail", `${conflict} The material answer claim is contradicted by the only supplied source for it.`, [sS.evidenceId, e.sClaim]);
r(S, "portfolio-task-gaps", "pass", "The task stated for this item (checking Standard plan support response time) is mapped to this item, and the only other evidenced task (opening a support ticket) is mapped to 02-procedure.md. No evidenced audience task in the declared two-item inventory lacks an item. The accuracy defect of this item's answer is recorded under quality, AIO and AEO rules, not as a coverage gap. Scope: tasks stated in the supplied documents only; no demand data was supplied.", [sS.evidenceId, e.sMap, e.sQ]);
r(S, "portfolio-duplication", "pass", "This item addresses response time; 02-procedure.md addresses how to open a ticket and states that it makes no response-time promise (02-procedure.md:6). The two declared items do not overlap in task or claims.", [sS.evidenceId, e.sMap]);
r(S, "portfolio-contradictions", "pass", "Cross-item scope: 02-procedure.md makes no response-time promise (02-procedure.md:6) and this item makes no ticket-procedure claim, so no material claim in one declared item conflicts with the other. The conflict between this item's draft statement and its approved policy is internal to this item and is recorded as a failure under quality-claims, aio-entity-consistency and the AEO rules.", [sS.evidenceId, e.sEnt, e.sMap]);
// --- Procedure
r(P, "quality-task-fit", "pass", "The stated audience is Standard customers opening a support ticket (02-procedure.md:3). The draft help answer (02-procedure.md:5) gives the four ordered actions of the procedure labelled complete and approved (02-procedure.md:4). No other customer-facing component is present in the item.", [sP.evidenceId, e.pAud]);
r(P, "quality-claims", "pass", "The draft help answer (02-procedure.md:5) is word-for-word the same procedure as the supplied complete approved procedure (02-procedure.md:4), verified by direct string comparison. The item makes no other material customer-facing claim and states that it makes no response-time promise (02-procedure.md:6).", [sP.evidenceId, e.pClaim]);
r(P, "quality-freshness", "pass", "The document states that the pages are current (02-procedure.md:6) and the draft matches the procedure labelled approved (02-procedure.md:4) for the same Standard-customer audience. Basis is the owner's undated statement; no effective date was supplied and none is contradicted.", [sP.evidenceId, e.pClaim]);
r(P, "quality-accessible-media", "not-applicable", "The complete captured source (lines 1-7) contains no image, video, audio or embed, so there is no informative media requiring a text alternative or transcript anywhere in the item.", [sP.evidenceId, e.pMedia]);
r(P, "seo-metadata", "unknown", "The supplied document is a labelled fixture record containing one draft answer; the help page's own title, description and headings are not supplied. The level-1 heading labels the fixture, not the page. Needed: the draft page source including its title, meta description and headings.", [sP.evidenceId, e.pAud]);
r(P, "aio-entity-consistency", "pass", "The draft help answer (02-procedure.md:5) states the same procedure, for the same Standard-customer scope, as the approved record (02-procedure.md:4). No conflicting name, product, version or limitation appears in the item. This does not show how any AI system represents the procedure.", [sP.evidenceId, e.pEnt]);
r(P, "aio-retrievable-facts", "pass", "The facts the audience needs — where to start (Help), what to select (New ticket), what to provide (a description of the problem) and how to finish (submit) — are all present as plain readable text in the draft help answer (02-procedure.md:5). Readable facts do not establish retrieval or citation by any engine.", [sP.evidenceId, e.pAud]);
r(P, "aeo-question-coverage", "pass", "The task-derived question (how a Standard customer opens a support ticket) is answered directly by the draft help answer (02-procedure.md:5), which matches the complete approved procedure (02-procedure.md:4). It is the item's only answer passage.", [sP.evidenceId, e.pQ]);
r(P, "aeo-answer-context", "pass", "The draft help answer (02-procedure.md:5) stands alone as an ordered procedure and omits nothing from the procedure the owner labels complete (02-procedure.md:4); that record lists no further prerequisite or limitation to retain.", [sP.evidenceId, e.pQ]);
r(P, "aeo-answer-evidence", "pass", "The only material answer claim, the ticket procedure (02-procedure.md:5), is supported verbatim by the supplied complete approved procedure (02-procedure.md:4).", [sP.evidenceId, e.pClaim]);
r(P, "portfolio-task-gaps", "pass", "The task stated for this item (opening a support ticket) is mapped to this item, and the only other evidenced task (checking response time) is mapped to 01-service.md. No evidenced audience task in the declared two-item inventory lacks an item. Scope: tasks stated in the supplied documents only; no demand data was supplied.", [sP.evidenceId, e.pMap, e.pQ]);
r(P, "portfolio-duplication", "pass", "This item addresses how to open a ticket and states that it makes no response-time promise and that the two pages serve distinct tasks (02-procedure.md:6); 01-service.md addresses response time only. The two declared items do not overlap in task or claims.", [sP.evidenceId, e.pMap]);
r(P, "portfolio-contradictions", "pass", "This item makes no response-time promise (02-procedure.md:6) and 01-service.md makes no ticket-procedure claim, so no material claim in this item conflicts with the other declared item. The draft answer agrees with its own approved record.", [sP.evidenceId, e.pEnt, e.pMap]);

const findings = [{
  findingId: "F-001-response-time-promise",
  title: "Draft promises a guaranteed one-hour reply; approved Standard support policy is two business days",
  affectedItemIds: [S.itemId],
  ruleIds: ["quality-task-fit", "quality-claims", "aio-entity-consistency", "aio-retrievable-facts", "aeo-question-coverage", "aeo-answer-context", "aeo-answer-evidence"],
  dimensions: ["quality", "aio", "aeo"],
  evidenceIds: [sS.evidenceId, e.sAud, e.sClaim, e.sEnt, e.sQ],
  severity: "high",
  confidence: "high",
  classification: "observed",
  remediation: "Proposed change to 01-service.md line 6 (draft page statement): replace the guaranteed one-hour, every-customer promise with wording that matches the approved policy on line 5, i.e. that Standard support replies within two business days. Do not keep the words guaranteed, every or one hour unless the policy owner approves a new commitment first. Expected benefit: customers checking the Standard response time get the commitment the business actually makes. Dependency: confirmation from the policy owner that the line 5 policy is the current one. This audit does not change the source.",
  verification: "Re-read the revised draft statement in full and compare it with the approved policy line: same plan (Standard), same quantity and unit (two business days), no added guarantee or broader scope. Then re-run this review on the new snapshot so the seven failed checks are reassessed.",
  ownerRole: "Content owner with support policy approver",
  effort: "small",
  action: "update",
  actionReason: "A customer-facing commitment in the draft is contradicted by the owner's current approved policy in the same document; the correction is a one-sentence wording change.",
}];
writeFileSync(out, JSON.stringify({ artifacts, evidence, reviews, findings }, null, 2) + "\n");
console.log(JSON.stringify({ evidence: evidence.length, reviews: reviews.length, findings: findings.length, now }));
