// Derives a private redaction policy from the input policy plus local path forms. Input policy is read-only.
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
const [input, project, out] = process.argv.slice(2);
const base = JSON.parse(readFileSync(input, "utf8")).values;
const set = new Set();
const variants = (v) => { for (const x of [v, encodeURIComponent(v), encodeURI(v), v.toLowerCase(), v.toUpperCase(), v.replace(/@/g, "&#64;"), v.replace(/\//g, "\\/")]) if (x) set.add(x); };
base.forEach(variants);
const parent = path.dirname(project);
for (const p of [project, parent]) { variants(p); variants(p.replace(/^\/private/, "")); variants("file://" + p); }
variants(path.basename(parent));
writeFileSync(out, JSON.stringify({ values: [...set] }, null, 2) + "\n", { mode: 0o600, flag: "wx" });
console.log(JSON.stringify({ inputValues: base.length, derivedValues: set.size }));
