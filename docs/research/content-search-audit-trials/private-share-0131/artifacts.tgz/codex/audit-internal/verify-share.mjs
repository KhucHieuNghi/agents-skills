import fs from 'node:fs';
import a from 'node:assert/strict';
import {createHash} from 'node:crypto';
const bytes=p=>fs.readFileSync(p), str=p=>bytes(p).toString('utf8'), json=p=>JSON.parse(str(p)), h=x=>createHash('sha256').update(x).digest('hex');
const manifest=json('share/redaction-manifest.json'), artifacts=[...manifest.records,...manifest.documents];
const expected=new Set([...artifacts.map(x=>x.artifact),'redaction-manifest.json','summary.md']);
const entries=fs.readdirSync('share',{withFileTypes:true});
a.equal(entries.length,expected.size);
const policy=json('redaction-policy.json').values, derived=json('audit-internal/share-policy.json').values;
for(const literal of [...policy,process.cwd()])a(derived.includes(literal));
const prohibited=new Set(derived.flatMap(s=>[s,s.replaceAll('/','\\/'),s.replace(/[-_.]/g,c=>'\\'+c),s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))]));
for(const e of entries){
 a(e.isFile()&&expected.has(e.name),'Unexpected share entry');
 const body=str('share/'+e.name);
 for(const val of prohibited)a(!e.name.includes(val)&&!body.includes(val),'Protected material in share output');
 a(!body.includes('file://')&&!body.includes('audit-internal/'),'Private evidence locator in share output');
}
for(const r of artifacts)a.equal(h(bytes('share/'+r.artifact)),r.snapshotHash);
const reviewed=str('audit-internal/reviewed/evidence.jsonl').trim().split('\n').map(JSON.parse);
for(const r of manifest.records){
 const original=reviewed.find(e=>h(e.evidenceId)===r.sourceEvidenceIdHash);
 a(original,'Unbound evidence derivative');
 a.equal(r.sourceSnapshotHash,original.snapshotHash);
 a.equal(h(bytes('audit-internal/reviewed/'+original.artifact)),original.snapshotHash);
 if(original.kind==='content'){
  const file=original.locator.split('/').pop();
  a.equal(h(bytes('targets/'+file)),original.snapshotHash);
  a.equal(h(bytes('audit-internal/initial/'+original.artifact)),original.snapshotHash);
 }
}
const allowed=new Set([...manifest.records.map(r=>r.artifact),'report.md']);
for(const file of ['report.md','report.html','summary.md']){
 const body=str('share/'+file);
 const re=file.endsWith('.html')?/href="([^"]+)"/g:/\]\(([^)]+)\)/g;
 const links=[...body.matchAll(re)].map(m=>decodeURIComponent(m[1]));
 a(links.some(l=>l.startsWith('evidence-')),'No derivative links');
 for(const l of links)a(allowed.has(l)||l.startsWith('#'),'Unexpected report link');
}
const validation=json('audit-internal/validation.json');
a.deepEqual(json('share/coverage.json'),validation.coverage);
const quotes=json('audit-internal/quote-receipt.json');a(quotes.valid);a.equal(quotes.quotes.length,4);
console.log(JSON.stringify({verifiedShareFiles:entries.length,verifiedDerivatives:manifest.records.length,verifiedInternalQuotes:quotes.quotes.length,summarySha256:h(bytes('share/summary.md')),valid:validation.valid,completionAllowed:validation.completionAllowed}));
