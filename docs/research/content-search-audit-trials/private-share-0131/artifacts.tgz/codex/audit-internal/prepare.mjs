import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root='audit-internal', initial=root+'/initial';
const read=(f)=>fs.readFileSync(f,'utf8');
const jsonl=(f)=>read(initial+'/'+f+'.jsonl').trim().split('\n').map(JSON.parse);
const write=(n,x)=>fs.writeFileSync(root+'/'+n,JSON.stringify(x,null,2)+'\n',{mode:0o600,flag:'wx'});
const hash=(s)=>createHash('sha256').update(s).digest('hex');
const items=jsonl('inventory'), raw=jsonl('evidence');
const registry=JSON.parse(read('.agents/skills/content-search-audit/rules/core.json')).rules;
const now=new Date().toISOString();
const bundle={reviews:[],evidence:[],artifacts:{},findings:[]};
for(const [i,item] of items.entries()){
 const service=i===0, snap=raw.find(r=>r.itemId===item.itemId);
 const original=read(initial+'/'+snap.artifact);
 const base=path.basename(item.path), ids={content:snap.evidenceId};
 const add=(kind,value,locator,deps=[snap.evidenceId])=>{
  const evidenceId=(service?'service':'procedure')+'-'+kind, artifact='evidence/'+evidenceId+'.txt';
  bundle.evidence.push({...snap,evidenceId,artifact,kind,value,locator,byteLength:Buffer.byteLength(value),snapshotHash:hash(value),collectedAt:now,method:'derived-local-review',sourceEvidenceIds:deps,limitations:['Attributed to supplied synthetic text; no independent policy or live verification.']});
  bundle.artifacts[artifact]=value;
  ids[kind]=evidenceId;
 };
 add('audience-context',service?'The supplied dossier identifies Standard customers checking support response times.':'The supplied dossier identifies Standard customers trying to open a support ticket.',base+':'+(service?4:3));
 add('claim-sources',service?'Fixture-approved comparator: Standard support replies within two business days. Labeled current by the dossier; no effective date, market, or live verification.':'Fixture-approved complete procedure: Open Help, select New ticket, describe the problem and submit. The dossier identifies both pages as current; no effective date, market, or live verification.',base+(service?':5':':4-6'));
 add('entity-record',service?'Standard support: the supplied approved reply window and the draft guarantee disagree. Compare service lines 5–6. The ticket procedure does not assert a response time.':'Standard support: the draft ticket steps match the approved procedure and deliberately make no response-time promise. The service dossier covers a separate question.','01-service.md:4-6; 02-procedure.md:3-6',raw.map(x=>x.evidenceId));
 add('inventory-map','Entire declared scope: the English service draft addresses when Standard support replies; the English procedure draft addresses how Standard customers open a ticket. These are distinct support tasks.','01-service.md:4-6; 02-procedure.md:3-6',raw.map(x=>x.evidenceId));
 add('question-set',service?'Task-derived evaluation question: When will Standard support reply? From the explicit scenario audience statement; no observed user query, volume, or demand is inferred.':'Task-derived evaluation question: How do I open a Standard support ticket? From the explicit scenario audience statement; no observed user query, volume, or demand is inferred.',base+':'+(service?4:3));
 add('extracted-text',original.replace(/<!--[\s\S]*?-->/g,s=>s.replace(/[^\r\n]/g,'')).replace(/^# /gm,''),base+' (plain text extraction; headings stripped and HTML comments omitted without execution)');
 const verdicts={
  'quality-task-fit':[service?'fail':'pass',service?'The draft gives the intended audience an incorrect expectation for the only stated task.':'The draft supplies all four approved actions in order for the stated task.'],
  'quality-claims':[service?'fail':'pass',service?'The one-hour guarantee contradicts the approved two-business-day Standard support window.':'All four material procedural instructions match the complete approved procedure, and the draft adds no reply-time claim.'],
  'quality-freshness':['unknown','The fixture labels the content or policy current, but applicability dates, market and independent freshness evidence were not supplied.'],
  'quality-accessible-media':['not-applicable','The whole supplied Markdown dossier is text only and contains no informative media or transcript component to assess.'],
  'seo-metadata':['unknown','The source heading identifies the dossier topic; actual page title, description and heading hierarchy in the publishing surface are unavailable.'],
  'aio-entity-consistency':[service?'fail':'pass',service?'The same Standard support entity receives incompatible reply commitments in the approved comparator and the draft.':'The draft preserves the approved Standard ticket procedure and adds no inconsistent commitment.'],
  'aio-retrievable-facts':[service?'fail':'pass',service?'The relevant plan and timing are legible, but the draft answer exposes a contradicted guarantee; only the accompanying comparator gives the approved timing.':'The supplied draft contains all required steps in readable text, with the Standard audience identified by its dossier. This says nothing about live retrieval.'],
  'aeo-question-coverage':[service?'fail':'pass',service?'The sole documented task has a direct draft answer, but that answer is contradicted by the supplied approved comparator.':'The draft answers the documented ticket-opening task with every approved step.'],
  'aeo-answer-context':['pass',service?'The sole draft promise states the Standard plan, scope, event and timing. Factual accuracy is assessed separately.':'The sole draft answer preserves the sequence of actions and omits no supplied prerequisite.'],
  'aeo-answer-evidence':[service?'fail':'pass',service?'The approved comparator contradicts the guarantee in the sole draft answer.':'The complete approved procedure supports every step of the sole draft answer.'],
  'portfolio-task-gaps':[service?'fail':'pass',service?'The declared inventory contains no accurate draft answer to the documented response-time task; the procedure intentionally omits timing. This is a correction to an existing draft, not a new-page gap.':'The ticket-opening task is covered in full by the procedure draft; no further demand evidence was supplied.'],
  'portfolio-duplication':['pass','The complete declared pair serves different support tasks for the same plan; shared audience does not duplicate task coverage.'],
  'portfolio-contradictions':['pass','There is no contradiction between the two drafts. The service policy discrepancy is within its dossier, and the procedure expressly abstains from making a timing claim.'],
  'portfolio-journey-links':['unknown','The Markdown has no links, but a live navigation graph and intended handoff between these distinct tasks were not supplied. No broken-link or orphan conclusion is supported.']
 };
 for(const r of registry){
  if(r.ruleId==='quality-readable-text')continue;
  const [status,reason]=verdicts[r.ruleId]??['unknown','Required evidence is unavailable for this offline dossier: '+r.requiredEvidence.filter(k=>!ids[k]).join(', ')+'.'];
  bundle.reviews.push({itemId:item.itemId,ruleId:r.ruleId,status,reason,evidenceIds:[...new Set([ids.content,...r.requiredEvidence.map(k=>ids[k]).filter(Boolean)])],reviewer:'Local audit reviewer',reviewedAt:now});
 }
 if(service){
 const failed=bundle.reviews.filter(r=>r.itemId===item.itemId&&r.status==='fail');
 bundle.findings.push({findingId:'standard-support-promise',title:'Standard support draft overpromises response time',affectedItemIds:[item.itemId],ruleIds:failed.map(r=>r.ruleId),dimensions:['quality','aio','aeo','portfolio'],evidenceIds:[...new Set(failed.flatMap(r=>r.evidenceIds))],severity:'high',confidence:'high',classification:'observed',remediation:'Replace the one-hour guarantee with the approved reply window of two business days for Standard support. Keep the ticket procedure as a separate answer.',verification:'Compare the revision with the supplied approved wording for the Standard plan and verify it makes no stronger guarantee. Recheck that the separate ticket answer retains all four approved steps and promises no reply time.',ownerRole:'Support content owner',effort:'small',action:'update',actionReason:'The stated response time can create false expectations; the approved comparator already supplies the correction.'});
 }
}
write('review.json',bundle);
const dir=process.cwd(), u=new URL('file://'+dir).href;
const vals=JSON.parse(read('redaction-policy.json')).values;
const service=read('targets/01-service.md').split('\n');
const protect=[...vals,dir,fs.realpathSync(dir),dir.replace(/^\/private(?=\/var)/,''),service[9],service[10]].filter(Boolean);
write('share-policy.json',{values:[...new Set(protect.flatMap(v=>[v,encodeURI(v),encodeURIComponent(v),JSON.stringify(v).slice(1,-1)]).concat(u))]});
