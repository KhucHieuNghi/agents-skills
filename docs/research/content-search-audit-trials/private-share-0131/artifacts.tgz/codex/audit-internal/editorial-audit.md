# Internal editorial audit

Partial audit of the complete declared set of two synthetic Markdown documents. Both were collected, extracted, and reviewed across all six dimensions where evidence permitted. Validated item states: 2 declared, 0 fully audited, 2 pending, 0 excluded, 0 blocked, 0 failed, and 0 unsupported. All checks were planned; 28 remain unknown. No live or measured surfaces were supplied.

| Dimension | Assessed | Unknown | N/A | Evidence and limits |
| --- | ---: | ---: | ---: | --- |
| Content quality | 6 | 2 | 2 | The response-time draft conflicts with approved policy; the ticket procedure matches its approved steps. |
| Technical SEO | 0 | 16 | 0 | The Markdown headings identify the dossier topics. Published metadata, HTTP behavior, indexing controls, canonicals, links, schema, locale mappings and rendering are unverified. |
| AI search readiness (AIO) | 4 | 2 | 0 | The reply-time conflict makes the draft unreliable as a source; the ticket steps are readable and consistent. Crawler access and actual retrieval remain unverified. |
| Answer quality (AEO) | 6 | 0 | 0 | Both task answers carry enough context to stand alone; only the ticket answer matches its approved comparator. |
| Generative visibility (GEO) | 0 | 6 | 0 | No response observations were supplied; mentions, citations, answer accuracy and cohort validity are unavailable. |
| Content portfolio | 6 | 2 | 0 | The two drafts serve separate Standard support tasks. Correct the response-time answer and retain the ticket procedure; live journeys and broader demand are unverified. |

For a future authorized review, supply the published page captures, response headers, crawler controls and publisher intent, canonical and locale targets, navigation graph, and both source and rendered content. For visibility, repeat the two task prompts in a fixed, versioned cohort per chosen search-enabled AI surface and locale. Record timestamps, responses, citations, missing captures and denominators; compare the factual answers against the applicable approved records. Keep search traffic, analytics and AI response observations separate. No such measurements were made here.

The service draft's commitment contradicts the fixture-approved policy. Replace it with the approved reply window; verify the revised wording preserves plan and timing. Keep the procedure separate: its draft matches all approved steps and adds no timing commitment. The fixture is the comparison basis and does not establish real-world policy.

## Source quotations

01-service.md:5 — Current approved policy: Standard support replies within two business days.
01-service.md:6 — Draft page: Every Standard customer receives a guaranteed reply within one hour.
02-procedure.md:4 — Complete approved procedure: Open Help, select New ticket, describe the problem and submit.
02-procedure.md:5 — Draft help answer: Open Help, select New ticket, describe the problem and submit.
