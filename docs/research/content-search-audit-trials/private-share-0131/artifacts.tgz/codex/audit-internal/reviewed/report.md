# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T17:41:44\.086Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 42cde87a\-2d1f\-4278\-9445\-97d579b26f95\. 1 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 2 |
| In scope | 2 |
| Audited | 0 |
| Accounted | 0 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 2 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

| ID | Finding | Rules | Dimensions | Severity | Confidence | Classification | Items | Action | Action origin | Action reason | Recommendation | Verification | Owner | Effort | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| standard\-support\-promise | Standard support draft overpromises response time | quality\-task\-fit, quality\-claims, aio\-entity\-consistency, aio\-retrievable\-facts, aeo\-question\-coverage, aeo\-answer\-evidence, portfolio\-task\-gaps | quality, aio, aeo, portfolio | high | high | observed | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | update | reviewer\-proposal | The stated response time can create false expectations; the approved comparator already supplies the correction\. | Replace the one\-hour guarantee with the approved reply window of two business days for Standard support\. Keep the ticket procedure as a separate answer\. | Compare the revision with the supplied approved wording for the Standard plan and verify it makes no stronger guarantee\. Recheck that the separate ticket answer retains all four approved steps and promises no reply time\. | Support content owner | small | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-audience\-context, service\-claim\-sources, service\-entity\-record, service\-question\-set, service\-inventory\-map |

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 6 | 6 | 0 | 0 |
| aio | 6 | 4 | 2 | 0 |
| geo | 6 | 0 | 6 | 0 |
| portfolio | 8 | 6 | 2 | 0 |
| quality | 10 | 6 | 2 | 2 |
| seo | 16 | 0 | 16 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | pending | Snapshot review incomplete | 26 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | pending | Snapshot review incomplete | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | quality\-task\-fit | quality | fail | The draft gives the intended audience an incorrect expectation for the only stated task\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-audience\-context |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | quality\-claims | quality | fail | The one\-hour guarantee contradicts the approved two\-business\-day Standard support window\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-claim\-sources |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | quality\-freshness | quality | unknown | The fixture labels the content or policy current, but applicability dates, market and independent freshness evidence were not supplied\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-claim\-sources |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | quality\-accessible\-media | quality | not\-applicable | The whole supplied Markdown dossier is text only and contains no informative media or transcript component to assess\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | service\-extracted\-text |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-response | seo | unknown | Required evidence is unavailable for this offline dossier: http\-response\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-index\-controls | seo | unknown | Required evidence is unavailable for this offline dossier: http\-response, publisher\-intent\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-canonical | seo | unknown | Required evidence is unavailable for this offline dossier: canonical\-targets\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-metadata | seo | unknown | The source heading identifies the dossier topic; actual page title, description and heading hierarchy in the publishing surface are unavailable\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-audience\-context |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-internal\-links | seo | unknown | Required evidence is unavailable for this offline dossier: link\-graph\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-structured\-data | seo | unknown | Required evidence is unavailable for this offline dossier: schema\-extraction\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-locales | seo | unknown | Required evidence is unavailable for this offline dossier: locale\-map\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | seo\-rendering | seo | unknown | Required evidence is unavailable for this offline dossier: rendered\-dom\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aio\-crawler\-policy | aio | unknown | Required evidence is unavailable for this offline dossier: crawler\-policy, publisher\-intent\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aio\-entity\-consistency | aio | fail | The same Standard support entity receives incompatible reply commitments in the approved comparator and the draft\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-entity\-record |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aio\-retrievable\-facts | aio | fail | The relevant plan and timing are legible, but the draft answer exposes a contradicted guarantee; only the accompanying comparator gives the approved timing\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-audience\-context |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aeo\-question\-coverage | aeo | fail | The sole documented task has a direct draft answer, but that answer is contradicted by the supplied approved comparator\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-question\-set |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aeo\-answer\-context | aeo | pass | The sole draft promise states the Standard plan, scope, event and timing\. Factual accuracy is assessed separately\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-question\-set |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | aeo\-answer\-evidence | aeo | fail | The approved comparator contradicts the guarantee in the sole draft answer\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-claim\-sources |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | geo\-observed\-presence | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | geo\-answer\-accuracy | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-claim\-sources |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | geo\-cohort\-validity | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-question\-set |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | portfolio\-task\-gaps | portfolio | fail | The declared inventory contains no accurate draft answer to the documented response\-time task; the procedure intentionally omits timing\. This is a correction to an existing draft, not a new\-page gap\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-inventory\-map, service\-question\-set |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | portfolio\-duplication | portfolio | pass | The complete declared pair serves different support tasks for the same plan; shared audience does not duplicate task coverage\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-inventory\-map |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | portfolio\-contradictions | portfolio | pass | There is no contradiction between the two drafts\. The service policy discrepancy is within its dossier, and the procedure expressly abstains from making a timing claim\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-entity\-record, service\-inventory\-map |
| 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | portfolio\-journey\-links | portfolio | unknown | The Markdown has no links, but a live navigation graph and intended handoff between these distinct tasks were not supplied\. No broken\-link or orphan conclusion is supported\. | 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568, service\-audience\-context |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | quality\-task\-fit | quality | pass | The draft supplies all four approved actions in order for the stated task\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-audience\-context |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | quality\-claims | quality | pass | All four material procedural instructions match the complete approved procedure, and the draft adds no reply\-time claim\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-claim\-sources |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | quality\-freshness | quality | unknown | The fixture labels the content or policy current, but applicability dates, market and independent freshness evidence were not supplied\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-claim\-sources |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | quality\-accessible\-media | quality | not\-applicable | The whole supplied Markdown dossier is text only and contains no informative media or transcript component to assess\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | quality\-readable\-text | quality | pass | Supplied text extraction is nonempty; content quality remains separately assessed | procedure\-extracted\-text |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-response | seo | unknown | Required evidence is unavailable for this offline dossier: http\-response\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-index\-controls | seo | unknown | Required evidence is unavailable for this offline dossier: http\-response, publisher\-intent\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-canonical | seo | unknown | Required evidence is unavailable for this offline dossier: canonical\-targets\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-metadata | seo | unknown | The source heading identifies the dossier topic; actual page title, description and heading hierarchy in the publishing surface are unavailable\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-audience\-context |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-internal\-links | seo | unknown | Required evidence is unavailable for this offline dossier: link\-graph\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-structured\-data | seo | unknown | Required evidence is unavailable for this offline dossier: schema\-extraction\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-locales | seo | unknown | Required evidence is unavailable for this offline dossier: locale\-map\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | seo\-rendering | seo | unknown | Required evidence is unavailable for this offline dossier: rendered\-dom\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aio\-crawler\-policy | aio | unknown | Required evidence is unavailable for this offline dossier: crawler\-policy, publisher\-intent\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aio\-entity\-consistency | aio | pass | The draft preserves the approved Standard ticket procedure and adds no inconsistent commitment\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-entity\-record |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aio\-retrievable\-facts | aio | pass | The supplied draft contains all required steps in readable text, with the Standard audience identified by its dossier\. This says nothing about live retrieval\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-audience\-context |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aeo\-question\-coverage | aeo | pass | The draft answers the documented ticket\-opening task with every approved step\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-question\-set |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aeo\-answer\-context | aeo | pass | The sole draft answer preserves the sequence of actions and omits no supplied prerequisite\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-question\-set |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | aeo\-answer\-evidence | aeo | pass | The complete approved procedure supports every step of the sole draft answer\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-claim\-sources |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | geo\-observed\-presence | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | geo\-answer\-accuracy | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-claim\-sources |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | geo\-cohort\-validity | geo | unknown | Required evidence is unavailable for this offline dossier: ai\-observations\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-question\-set |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | portfolio\-task\-gaps | portfolio | pass | The ticket\-opening task is covered in full by the procedure draft; no further demand evidence was supplied\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-inventory\-map, procedure\-question\-set |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | portfolio\-duplication | portfolio | pass | The complete declared pair serves different support tasks for the same plan; shared audience does not duplicate task coverage\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-inventory\-map |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | portfolio\-contradictions | portfolio | pass | There is no contradiction between the two drafts\. The service policy discrepancy is within its dossier, and the procedure expressly abstains from making a timing claim\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-entity\-record, procedure\-inventory\-map |
| d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | portfolio\-journey\-links | portfolio | unknown | The Markdown has no links, but a live navigation graph and intended handoff between these distinct tasks were not supplied\. No broken\-link or orphan conclusion is supported\. | 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3, procedure\-audience\-context |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 83e755e18b2f344bcf22edebb50f7ca17810b55b7657f8375277ed55c69e7568 | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | local\-file | 2026\-11\-16T17:40:35\.462Z | 0 full elapsed days | [evidence/2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de\.txt](evidence/2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de.txt) | 43a5d824c7834783a78815e00b6ea8f3b94d950b281286140a3b596648485133 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 4965703663b98f4070b4e2504b34c5d8c8fc538cad64bba23b55b98da26d9da3 | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | local\-file | 2026\-11\-16T17:40:35\.464Z | 0 full elapsed days | [evidence/d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643\.txt](evidence/d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643.txt) | 8e9098f62da0ef4329d151ae6975bea150027a4c46e2413e2d129ca9470fb968 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| service\-audience\-context | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-audience\-context\.txt](evidence/service-audience-context.txt) | 66e25796204d68f3fb9b59b013edbac9e1d9a043bb65c52c90355f815f2db455 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| service\-claim\-sources | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-claim\-sources\.txt](evidence/service-claim-sources.txt) | fcca4d067d695723463b62eb3616ae73d990443898c08e636a138ce37e7aa4f8 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| service\-entity\-record | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-entity\-record\.txt](evidence/service-entity-record.txt) | 6a1c06e3ac03d598de336b4792f3c478ded2253e7e958e02709f3201335c0f82 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| service\-inventory\-map | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-inventory\-map\.txt](evidence/service-inventory-map.txt) | ba41c3f3c788aa99d3b9e9d6fdafbab41160aa44032a3dae5904ce72d08c1bf4 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| service\-question\-set | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-question\-set\.txt](evidence/service-question-set.txt) | 6c59199b0c220d91eba0bc5921e28ab02cc55f838c32c83eba0c001f80ea6f8c | Attributed to supplied synthetic text; no independent policy or live verification\. |
| service\-extracted\-text | 2a1831ae38121dcdfdebb77b18ff555ad6f1f897ee32119bbac81f3407e728de | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/service\-extracted\-text\.txt](evidence/service-extracted-text.txt) | 90e20fc31be61fe4826cd00c077d8d9fe4475e1a6c99e7874cfa4eb18863468b | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-audience\-context | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-audience\-context\.txt](evidence/procedure-audience-context.txt) | d254ef2e4d8b5b1f2ef024c5c2f3702ac4aae2debdbf841499c3f2b2786300a4 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-claim\-sources | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-claim\-sources\.txt](evidence/procedure-claim-sources.txt) | c5cad40e4657289d14a6c5f88014386a55dc4d82ca4b6e3732978e711cc98abe | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-entity\-record | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-entity\-record\.txt](evidence/procedure-entity-record.txt) | 80fa9a567ff38b5ddc21086d435439c3c4413dc9621b79b966ad379c220cc006 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-inventory\-map | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-inventory\-map\.txt](evidence/procedure-inventory-map.txt) | ba41c3f3c788aa99d3b9e9d6fdafbab41160aa44032a3dae5904ce72d08c1bf4 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-question\-set | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-question\-set\.txt](evidence/procedure-question-set.txt) | 9d364c32fa10f848554bb5c530f6e868029d47732d9b3d4d8e6e0b271d3e4df5 | Attributed to supplied synthetic text; no independent policy or live verification\. |
| procedure\-extracted\-text | d03f19ed85845683b0d6bd3e191c37b0c53c67efc0e90fc55c03d32974922643 | derived\-local\-review | 2026\-11\-16T17:41:43\.946Z | 0 full elapsed days | [evidence/procedure\-extracted\-text\.txt](evidence/procedure-extracted-text.txt) | 8d40702e473be76c54eb63838a7cf2adc65320216b5aa6b2f87f72288f00793b | Attributed to supplied synthetic text; no independent policy or live verification\. |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
