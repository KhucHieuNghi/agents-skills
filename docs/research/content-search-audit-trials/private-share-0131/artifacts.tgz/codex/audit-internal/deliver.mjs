import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(s).digest('hex');
const read=f=>fs.readFileSync(f,'utf8');
const json=f=>JSON.parse(read(f));
const privateDir='audit-internal';
const validation=json(privateDir+'/validation.json'), c=validation.coverage;
assert(validation.valid&&!validation.completionAllowed);
const manifest=json('share/redaction-manifest.json');
const raw=read(privateDir+'/reviewed/evidence.jsonl').trim().split('\n').map(JSON.parse);
const sourceFor=file=>raw.find(r=>r.kind==='content'&&r.locator.endsWith('/'+file));
const link=id=>{
 const m=manifest.records.find(r=>r.sourceEvidenceIdHash===sha(id));
 assert(m);return m.artifact;
};
const service='01-service.md',procedure='02-procedure.md';
const coverage=`Partial audit of the complete declared set of two synthetic Markdown documents. Both were collected, extracted, and reviewed across all six dimensions where evidence permitted. Validated item states: ${c.total} declared, ${c.audited} fully audited, ${c.states.pending} pending, ${c.states.excluded} excluded, ${c.states.blocked} blocked, ${c.states.failed} failed, and ${c.states.unsupported} unsupported. All checks were planned; ${Object.values(c.dimensions).reduce((a,d)=>a+d.unknown,0)} remain unknown. No live or measured surfaces were supplied.`;
const next='For a future authorized review, supply the published page captures, response headers, crawler controls and publisher intent, canonical and locale targets, navigation graph, and both source and rendered content. For visibility, repeat the two task prompts in a fixed, versioned cohort per chosen search-enabled AI surface and locale. Record timestamps, responses, citations, missing captures and denominators; compare the factual answers against the applicable approved records. Keep search traffic, analytics and AI response observations separate. No such measurements were made here.';
const names={quality:'Content quality',seo:'Technical SEO',aio:'AI search readiness (AIO)',aeo:'Answer quality (AEO)',geo:'Generative visibility (GEO)',portfolio:'Content portfolio'};
const observations={quality:'The response-time draft conflicts with approved policy; the ticket procedure matches its approved steps.',seo:'The Markdown headings identify the dossier topics. Published metadata, HTTP behavior, indexing controls, canonicals, links, schema, locale mappings and rendering are unverified.',aio:'The reply-time conflict makes the draft unreliable as a source; the ticket steps are readable and consistent. Crawler access and actual retrieval remain unverified.',aeo:'Both task answers carry enough context to stand alone; only the ticket answer matches its approved comparator.',geo:'No response observations were supplied; mentions, citations, answer accuracy and cohort validity are unavailable.',portfolio:'The two drafts serve separate Standard support tasks. Correct the response-time answer and retain the ticket procedure; live journeys and broader demand are unverified.'};
const dimensions='| Dimension | Assessed | Unknown | N/A | Evidence and limits |\n| --- | ---: | ---: | ---: | --- |\n'+Object.entries(c.dimensions).map(([k,d])=>`| ${names[k]} | ${d.completed} | ${d.unknown} | ${d.notApplicable} | ${observations[k]} |`).join('\n');
const summary=`# Synthetic support content audit\n\n${coverage}\n\n## Priority finding\n\nThe Standard support draft guarantees a reply within one hour; the supplied approved policy allows two business days. Replace the guarantee with the approved timeframe and verify that the revised answer still applies to Standard support. See the [redacted service dossier, lines 5–6](${link(sourceFor(service).evidenceId)}) and the [derived policy comparison](${link('service-claim-sources')}).\n\nRetain the separate ticket procedure. Its draft includes all four approved steps in order and makes no reply-time promise. See the [redacted procedure dossier, lines 3–6](${link(sourceFor(procedure).evidenceId)}).\n\n## Six-dimension coverage\n\n${dimensions}\n\n## Evidence needed to complete the audit\n\n${next}\n\n[Full validated-check presentation and evidence index](report.md). This summary paraphrases source passages; the linked text artifacts are redacted derivatives.\n`;
const reportPath=privateDir+'/editorial-audit.md';
const targets=[[service,5],[service,6],[procedure,4],[procedure,5]];
const intro=`# Internal editorial audit\n\n${coverage}\n\n${dimensions}\n\n${next}\n\nThe service draft's commitment contradicts the fixture-approved policy. Replace it with the approved reply window; verify the revised wording preserves plan and timing. Keep the procedure separate: its draft matches all approved steps and adds no timing commitment. The fixture is the comparison basis and does not establish real-world policy.\n\n## Source quotations\n\n`;
const lines=intro.split('\n').length;
const quotes=targets.map(([sourceLabel,startLine],i)=>{
 const rawSource=sourceFor(sourceLabel), source=privateDir+'/reviewed/'+rawSource.artifact, content=read(source);
 assert.equal(content,read('targets/'+sourceLabel));
 return {quoteId:'source-'+(i+1),source,sourceLabel,sourceHash:sha(content),startLine,endLine:startLine,reportStartLine:lines+i,reportEndLine:lines+i,quote:content.split('\n')[startLine-1]};
});
// The verifier allows the source label only as a relative path or basename, so bind to original inputs after proving byte identity with their snapshots.
for(const q of quotes)q.source='targets/'+q.sourceLabel;
const report=intro+quotes.map(q=>q.sourceLabel+':'+q.startLine+' — '+q.quote).join('\n')+'\n';
fs.writeFileSync(reportPath,report,{flag:'wx',mode:0o600});
fs.writeFileSync(privateDir+'/quote-ledger.json',JSON.stringify({root:process.cwd(),report:reportPath,reportHash:sha(report),quotes},null,2),{flag:'wx',mode:0o600});
fs.writeFileSync('share/summary.md',summary,{flag:'wx',mode:0o600});
