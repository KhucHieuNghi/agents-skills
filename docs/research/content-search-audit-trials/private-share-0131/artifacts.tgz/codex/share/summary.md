# Synthetic support content audit

Partial audit of the complete declared set of two synthetic Markdown documents. Both were collected, extracted, and reviewed across all six dimensions where evidence permitted. Validated item states: 2 declared, 0 fully audited, 2 pending, 0 excluded, 0 blocked, 0 failed, and 0 unsupported. All checks were planned; 28 remain unknown. No live or measured surfaces were supplied.

## Priority finding

The Standard support draft guarantees a reply within one hour; the supplied approved policy allows two business days. Replace the guarantee with the approved timeframe and verify that the revised answer still applies to Standard support. See the [redacted service dossier, lines 5–6](evidence-41de8a8f0d60da408d1ebb595618e30713d686fc100142dfd7f1d7203da764ed.txt) and the [derived policy comparison](evidence-c3f8c821188f6e533aa4697048bcb32080c92ba1ecd3d99b50c03c9d28230ded.txt).

Retain the separate ticket procedure. Its draft includes all four approved steps in order and makes no reply-time promise. See the [redacted procedure dossier, lines 3–6](evidence-178fbf09821ec4a103f1d1a41844f7639718903e3056e4350f2de7a09cbe46cd.txt).

## Six-dimension coverage

| Dimension | Assessed | Unknown | N/A | Evidence and limits |
| --- | ---: | ---: | ---: | --- |
| Content quality | 6 | 2 | 2 | The response-time draft conflicts with approved policy; the ticket procedure matches its approved steps. |
| Technical SEO | 0 | 16 | 0 | The Markdown headings identify the dossier topics. Published metadata, HTTP behavior, indexing controls, canonicals, links, schema, locale mappings and rendering are unverified. |
| AI search readiness (AIO) | 4 | 2 | 0 | The reply-time conflict makes the draft unreliable as a source; the ticket steps are readable and consistent. Crawler access and actual retrieval remain unverified. |
| Answer quality (AEO) | 6 | 0 | 0 | Both task answers carry enough context to stand alone; only the ticket answer matches its approved comparator. |
| Generative visibility (GEO) | 0 | 6 | 0 | No response observations were supplied; mentions, citations, answer accuracy and cohort validity are unavailable. |
| Content portfolio | 6 | 2 | 0 | The two drafts serve separate Standard support tasks. Correct the response-time answer and retain the ticket procedure; live journeys and broader demand are unverified. |

## Evidence needed to complete the audit

For a future authorized review, supply the published page captures, response headers, crawler controls and publisher intent, canonical and locale targets, navigation graph, and both source and rendered content. For visibility, repeat the two task prompts in a fixed, versioned cohort per chosen search-enabled AI surface and locale. Record timestamps, responses, citations, missing captures and denominators; compare the factual answers against the applicable approved records. Keep search traffic, analytics and AI response observations separate. No such measurements were made here.

[Full validated-check presentation and evidence index](report.md). This summary paraphrases source passages; the linked text artifacts are redacted derivatives.
