from pathlib import Path
import json,hashlib,re,html
from urllib.parse import unquote,quote,urlsplit
root=Path(__file__).resolve().parent
results={}
for host in ['codex','claude-code']:
 project=root/host;share=project/'share'
 protected=json.loads((project/'redaction-policy.json').read_text())['values']+[str(project),str(project.resolve()),'/private'+str(project)]
 variants=set()
 for value in protected:
  variants.update([value,html.escape(value),quote(value,safe=''),json.dumps(value)[1:-1]])
 leaks=[];files=[p for p in share.rglob('*') if p.is_file()]
 for p in files+[root/(host+'.response.txt')]:
  data=p.read_text()
  for i,value in enumerate(sorted(variants)):
   if value in data:leaks.append({'file':str(p.relative_to(root)),'protectedVariantIndex':i})
 manifest=json.loads((share/'redaction-manifest.json').read_text())
 hashes=[]
 for record in manifest['records']+manifest.get('documents',[]):
  p=share/record['artifact'];hashes.append({'artifact':record['artifact'],'matches':p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==record['snapshotHash']})
 links=[]
 for p in files:
  if p.suffix not in ['.md','.html']:continue
  text=p.read_text()
  refs=re.findall(r'\]\(([^)]+)\)',text) if p.suffix=='.md' else re.findall(r'(?:href|src)=[\"\']([^\"\']+)',text)
  for ref in refs:
   ref=html.unescape(ref);parsed=urlsplit(ref)
   if not parsed.path and not parsed.scheme:continue
   target=(p.parent/unquote(parsed.path)).resolve()
   local=not parsed.scheme and not parsed.netloc and target.is_relative_to(share.resolve())
   links.append({'document':p.name,'reference':ref,'localAndExists':local and target.exists()})
 coverage=json.loads((share/'coverage.json').read_text())
 results[host]={'shareFiles':len(files),'protectedValueLeaks':leaks,'hashRecords':hashes,'links':links,'coverage':coverage,'forbiddenCopies':[p.name for p in files if p.name in ['config.json','redaction-policy.json','evidence.jsonl','run.json']],'unmanifestedShareFiles':[str(p.relative_to(share)) for p in files if str(p.relative_to(share)) not in {x['artifact'] for x in manifest['records']+manifest.get('documents',[])} and p.name!='redaction-manifest.json']}
(root/'share-validation.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({host:{'files':v['shareFiles'],'leaks':len(v['protectedValueLeaks']),'hashesValid':all(x['matches'] for x in v['hashRecords']),'linksValid':all(x['localAndExists'] for x in v['links']),'forbiddenCopies':v['forbiddenCopies'],'unmanifested':v['unmanifestedShareFiles']} for host,v in results.items()}))
