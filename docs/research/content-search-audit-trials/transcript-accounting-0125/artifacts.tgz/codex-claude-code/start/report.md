# Content audit — Content Search Audit

## Source age reference

Age reference: 2026\-11\-16T05:15:20\.361Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run d8fa5c1c\-a609\-4dc9\-8536\-89a71e39a49f\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 3 |
| In scope | 3 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 0 |
| Failed | 1 |
| Unsupported | 1 |
| Pending | 1 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 9 | 0 | 9 | 0 |
| aio | 9 | 0 | 9 | 0 |
| geo | 9 | 0 | 9 | 0 |
| portfolio | 12 | 0 | 12 | 0 |
| quality | 15 | 0 | 15 | 0 |
| seo | 24 | 0 | 24 | 0 |

## Visibility measurements unavailable

No AI response observations supplied\. Readiness is not measured mentions, citations or factual accuracy; missing observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | failed | Local collection failed \(ENOENT\) | 26 |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | unsupported | Content requires an explicitly supplied extraction adapter or text transcript | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-locales | seo | unknown | Missing required evidence: locale\-map | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 525d17593addb9eb753564060a3b53bf961784deaa3d8c8e4049e08fc0c23b00 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 9c7b8b1c15ff0843e371b0dca368e59de537f2e10442cd2feb67f0542ee5d5e1 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| aa90700e209748ad34e96e1d479fc8daa3b9f4a6539895b85ba599439f6789e8 | 3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d | local\-file | 2026\-11\-16T05:15:20\.337Z | 0 full elapsed days | [evidence/3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d\.txt](evidence/3b365a7de359099da8c65677f7ff04d5472344f8d3c87226c4e876430379fc7d.txt) | 437b0726e364221e46a9baa551ec20b5270cd4bb4827424b18045ded9ea8f2a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 0 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
