# Content Search Audit: two synthetic dossiers

## Scope and coverage
- Declared: 2 dossiers, kept as separate scopes. Audited 2; excluded 0, blocked 0, failed 0, unsupported 0, pending 0.
- Scope 1 is `targets/02-media.md`: 4 media items (I1, I2, I3, V1). Scope 2 is `targets/11-periods.md`: 3 supplied observation groups (A/B, D, draft conclusion).
- Totals: **3 material findings, 2 clean controls, 1 uncertain case.**
- This is offline text review of owner descriptions only. I did not inspect pixels, audio or video, fetch URLs, or observe any live page or AI surface. The audit is **partial**, not full site coverage. There are no pages, markup, rendered DOM, robots/sitemap data or analytics.

## Scope 1: 02-media.md

### F1 (high): I1 download link has a non-functional accessible name
- Dimensions: content quality/accessibility, SEO (link text), AIO/AEO (link purpose extraction).
- Evidence, `02-media.md:7-8`: "Image I1 is a functional download link, destination /annual-report.pdf." and `alt="Company logo"`. Line 8 adds "No adjacent label or aria-label exists."
- Interpretation: the link's only name describes the image, not the action or destination. Users of assistive technology, crawlers and answer extractors get no signal that this is an annual report PDF.
- Action: change the alt text to state the purpose, e.g. `alt="Download annual report (PDF)"`. Keep the logo wording only if the logo is also meaningful.
- Verification: inspect the accessibility tree or computed name of the link and confirm it reads as the report download. Confirm the source anchor text is crawlable.

### F2 (high): V1 required instruction exists only visually
- Dimensions: content quality/accessibility, AEO, AIO (transcript is the machine-readable text).
- Evidence, `02-media.md:15,17,18`: "The required highlighted row is visually labeled "Region West"; the audio never". Line 17 gives the transcript "Choose the highlighted row." Line 18 says "There is no other descriptive". The transcript is complete for audio only.
- Interpretation: a blind user, or any text-only consumer of the transcript, cannot learn which region to select. The text equivalent fails the product task.
- Action: add a descriptive transcript or audio description, e.g. "Choose the highlighted row, Region West." Alternatively change the narration.
- Verification: a reviewer using only the transcript can name the correct region. Check for a captions/description track in the real player, which was not supplied.

### Clean controls
- **I2** (`02-media.md:9`): "purely decorative separator with alt=""". Empty alt is correct for a decorative image with no link or text.
- **I3** (`02-media.md:10-12`): `alt="Quarterly revenue; data in the following table"`. The owner states the adjacent table is equivalent and the chart has no extra information. This passes on the supplied statement. The table itself was not supplied, so its completeness is owner-asserted.

## Scope 2: 11-periods.md

### F3 (high): draft conclusion makes invalid cross-cohort and causal claims
- Dimensions: GEO measurement validity, content quality (claim accuracy), AEO.
- Evidence, `11-periods.md:13-14`: "Comparing A with D" and "proves our content edits caused brand visibility to quadruple across the market."
- A, `11-periods.md:4-5`: "same engine, search-enabled API, model label m1, locale vi-VN, market VN". D, `11-periods.md:10-11`: "consumer UI, model unknown, locale en-US, market US" and "different 20 prompts".
- Arithmetic: A = 2/10 = 20%, D = 16/20 = 80%, ratio 4. The number is correct, but the comparison is not valid. Surface, model, locale, market, cohort version and prompts all differ.
- Causality: `11-periods.md:7-8` says "No randomization, intervention record or platform-change evidence is available." `11-periods.md:15` says "No citation annotations, conversions, causal control or wider population sample exist." So "proves ... caused" and "across the market" are unsupported.
- Action: delete the A-vs-D comparison and the causal and "market" wording. Report D separately as an exploratory, synthetic, US consumer-UI observation.
- Verification: the revised text names engine, surface, model, locale, market, cohort version, denominators and the synthetic label for every rate. It contains no cross-cohort ratio and no causal verb.

## Uncertain case
- **U1: "B improved over A in this fixed API cohort"** (`11-periods.md:13`). A and B are compatible (`11-periods.md:4-6`: same prompts, once per period, reviewed annotations), so a descriptive comparison is allowed: A 2/10 = 20%, B 4/10 = 40%. "Improved" is uncertain. The 2-response difference comes from n=10, one repetition per prompt, non-overlapping days, with no intervention or platform-change record (`11-periods.md:7-8`). Suggested wording: "B showed 4 of 10 mentions versus 2 of 10 for A; the difference is not shown to be reliable or attributable." Resolve it with repeated captures, a variance estimate and an intervention log.

## Missing measurements and limits
- Not supplied: Search Console, GA4, Bing, server logs, citation annotations (`11-periods.md:15`), conversions, ranking or position data.
- Missing is unavailable, not zero. No SEO/GEO score or uplift forecast is given.
- Not assessable: real alt/DOM markup, a captions track, the I3 table, indexability, structured data, or the prompts and responses behind A, B and D.
- All counts are synthetic and reviewer-supplied (`11-periods.md:3`: "Every count below is synthetic and supplied by a reviewer, not live measurement."). The 02-media descriptions are owner-supplied.
- Recommendations are proposals only. No targets or skills were modified.
