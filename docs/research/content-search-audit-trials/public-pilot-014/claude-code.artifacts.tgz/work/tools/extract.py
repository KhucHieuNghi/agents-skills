import json,re,sys,html
from html.parser import HTMLParser
P='campaign-r1/parts/000001/'
inv=[json.loads(l) for l in open(P+'inventory.jsonl')]
ev=[json.loads(l) for l in open(P+'evidence.jsonl')]
class H(HTMLParser):
    def __init__(s):
        super().__init__();s.meta=[];s.links=[];s.a=[];s.h=[];s.img=[];s.text=[];s.skip=0;s.cur=None;s.title='';s.intitle=False;s.ld=0;s.scripts=0;s.lang=None;s.buf=''
    def handle_starttag(s,t,a):
        a=dict(a)
        if t=='html':s.lang=a.get('lang')
        if t=='meta':s.meta.append(a)
        if t=='link':s.links.append(a)
        if t=='a':s.a.append(a.get('href'))
        if t=='img':s.img.append(a)
        if t in('script','style'):
            s.skip+=1
            if t=='script':
                s.scripts+=1
                if a.get('type')=='application/ld+json':s.ld+=1
        if t=='title':s.intitle=True
        if t in('h1','h2','h3'):s.cur=t;s.buf=''
    def handle_endtag(s,t):
        if t in('script','style'):s.skip-=1
        if t=='title':s.intitle=False
        if t==s.cur:s.h.append((t,s.buf.strip()));s.cur=None
    def handle_data(s,d):
        if s.intitle:s.title+=d
        if s.skip:return
        if s.cur:s.buf+=d
        s.text.append(d)
def load(i):
    e=[e for e in ev if e['itemId']==i['itemId'] and e['kind']=='content'][0]
    raw=open(P+e['artifact'],encoding='utf-8').read()
    h=H();h.feed(raw);return e,raw,h
if __name__=='__main__':
    for n,i in enumerate(inv):
        e,raw,h=load(i)
        print('=====',n,i['uri'],e['evidenceId'][:8],'lang',h.lang)
        print('title:',h.title)
        for m in h.meta:
            if m.get('name') in('description','robots') or m.get('property') in('og:title','og:description'):print(' meta',m)
        for l in h.links:
            if l.get('rel') in('canonical','alternate'):print(' link',l.get('rel'),l.get('hreflang'),l.get('href'))
        print(' headings',h.h);print(' ld+json',h.ld,'scripts',h.scripts,'img',[(x.get('src'),x.get('alt')) for x in h.img])
        print(' a',sorted(set(h.a)))
