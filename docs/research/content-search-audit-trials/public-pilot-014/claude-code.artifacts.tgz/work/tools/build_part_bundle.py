import sys,json,re,hashlib,datetime
sys.path.insert(0,'work/tools')
import extract as X
from urllib.parse import urljoin,urldefrag
G='https://nkskills.getgroove.me'
now=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
idx=json.load(open('campaign-r1-index/index.json'))
snap=idx['partSnapshotHashes']['parts/000001']
mode=sys.argv[1]  # probe | full
REV='content-search-audit host reviewer (Claude Sonnet 5.5), static snapshot review'
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
inv=X.inv
contentEv={i['itemId']:X.load(i)[0]['evidenceId'] for i in inv}
raws={i['uri']:X.load(i)[1] for i in inv}
parsed={i['uri']:X.load(i)[2] for i in inv}
ids={u:set(re.findall(r'\sid="([^"]+)"',r)) for u,r in raws.items()}
evidence=[];artifacts={};reviews=[]
def add(item,kind,value,method,locator,lim):
    v=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,sort_keys=True)
    h=sha(v);eid=h  # content-addressed id
    eid=sha(item['itemId']+kind+h)
    art=f'evidence/{eid}.txt'
    evidence.append(dict(evidenceId=eid,itemId=item['itemId'],kind=kind,method=method,collectedAt=now,locator=locator,snapshotHash=h,redaction='No credentials or personal data; derived from public snapshot or task brief',limitations=lim,sourceEvidenceIds=[contentEv[item['itemId']]],artifact=art,encoding='utf8',value=v))
    artifacts[art]=v;return eid
def rv(item,rule,status,reason,eids):
    reviews.append(dict(itemId=item['itemId'],ruleId=rule,status=status,reason=reason,evidenceIds=sorted(eids),reviewer=REV,reviewedAt=now))
if mode=='probe':
    i=inv[0];e=add(i,'extracted-text',re.sub(r'\s+',' ',' '.join(parsed[i['uri']].text)).strip(),'html-text-extraction-python-htmlparser',i['uri'],['Visible text from raw HTML; scripts/styles skipped; no rendering'])
    rv(i,'quality-readable-text','pass','probe',[e])
    bundle=dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],parts=[dict(path='parts/000001',sourceSnapshotHash=snap,bundle=dict(reviews=reviews,evidence=evidence,artifacts=artifacts))])
    json.dump(bundle,open('work/probe-bundle.json','w'),ensure_ascii=False);sys.exit()
BRIEF=("NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences. AIO means AI search optimization; no Google AI Overviews measurements are supplied. "
 "(Source: user task brief for this pilot, supplied 2026-11-15; not customer research or analytics.)")
html=[i for i in inv if i['uri']!=G+'/licenses/README.txt']
readme=[i for i in inv if i['uri']==G+'/licenses/README.txt'][0]
pairs={}
for i in html:
    u=i['uri']
    if u==G+'/':u=G+'/en/'
    pairs[i['uri']]=u
aliasing={G+'/':'308 redirect to /en/; body byte-identical to /en/ snapshot'}
ev={}
for i in inv:
    u=i['uri'];h=parsed[u];ev[u]={}
    ev[u]['aud']=add(i,'audience-context',BRIEF,'user-supplied-context','user-request:nkskills-public-pilot',['Task-brief statement only; no analytics, query or customer research data'])
    # link graph
    outs=[];broken=[]
    for a in sorted(set(x for x in h.a if x)):
        if a.startswith('http') and 'nkskills.getgroove.me' not in a: outs.append(('external',a));continue
        t=urljoin(u,a);b,f=urldefrag(t)
        ok=b in raws or b==G+'/'
        fr=(f in ids.get(b,set())) if f and b in raws else None
        outs.append(('internal',a,b,'captured-200' if ok else 'not-captured',fr))
        if not ok or fr is False: broken.append(a)
    inbound=sorted(x['uri'] for x in inv if x['uri']!=u and any(urldefrag(urljoin(x['uri'],a))[0]==u for a in set(y for y in parsed[x['uri']].a if y)))
    lg=dict(source=u,method='static href extraction from captured raw HTML (a elements); no JS executed',internalTargets=len([o for o in outs if o[0]=='internal']),externalTargetsNotFetched=len([o for o in outs if o[0]=='external']),unresolvedOrMissingFragment=broken,inboundFromCapturedPages=inbound,links=outs)
    ev[u]['lg']=add(i,'link-graph',lg,'derived-link-graph','campaign-r1/parts/000001 content snapshot',['Graph limited to 12 captured pages; script/rendered navigation not inspected; external targets not fetched','Absence of inbound links elsewhere on the site cannot be established'])
    if u==readme['uri']:
        ev[u]['can']=add(i,'canonical-targets',dict(note='text/plain asset; no HTML head, canonical/hreflang not applicable'),'derived','HTTP content-type text/plain',['Representation is plain text'])
        continue
    can=[l['href'] for l in h.links if l.get('rel')=='canonical']
    alt=[(l['hreflang'],l['href']) for l in h.links if l.get('rel')=='alternate' and l.get('hreflang')]
    self_u=pairs[u]
    ev[u]['can']=add(i,'canonical-targets',dict(url=u,declaredCanonical=can,selfReferential=(can==[self_u]),canonicalTargetCaptured200=(can[0] in raws if can else False),note=aliasing.get(u,'')),'derived-from-html-head',u,['Declared canonical only; engine-selected canonical unknown'])
    # locale reciprocal
    other=None
    recip=True;detail=[]
    for lang,href in alt:
        if href in raws or href==G+'/':
            ph=parsed[href] if href in parsed else None
            back=[(l['hreflang'],l['href']) for l in ph.links if l.get('rel')=='alternate' and l.get('hreflang')] if ph else []
            ok=(('en',pairs.get(G+'/en/',G+'/en/')) is not None) and any(h2==self_u for _,h2 in back)
            detail.append(dict(hreflang=lang,href=href,captured=True,reciprocalToSelf=ok,pageLang=ph.lang if ph else None))
            recip&=ok
        else:detail.append(dict(hreflang=lang,href=href,captured=False));recip=False
    ev[u]['loc']=add(i,'locale-map',dict(url=u,htmlLang=h.lang,alternates=detail,allReciprocalAndCaptured=recip),'derived-from-html-head',u,['Only captured en/vi pair relationships checked; engine treatment unknown'])
    ev[u]['recip']=recip
    assert can==[self_u],(u,can)
    assert recip,(u,detail)
    # metadata
    title=h.title;desc=[m['content'] for m in h.meta if m.get('name')=='description']
    assert title and len(desc)==1
for i in html:
    u=i['uri'];e=ev[u]
    rv(i,'seo-canonical','pass',f"Declared rel=canonical equals the page's own final URL ({pairs[u]}) and that target is a captured HTTP 200 snapshot. Declared canonical only; engine-selected canonical unknown."+(" Request '/' returned 308 to /en/ and its body is byte-identical to the /en/ snapshot, so the alias is consistent with its canonical." if u==G+'/' else ''),[contentEv[i['itemId']],e['can']])
    rv(i,'seo-locales','pass',"Captured en/vi pair: hreflang en, vi and x-default alternates are present, resolve to captured pages, and the counterpart lists this page in return (reciprocal). Applies to this pair only; search-engine treatment unknown.",[contentEv[i['itemId']],e['loc']])
    rv(i,'seo-metadata','pass',"Page has a non-empty title and one meta description consistent with its H1/body task (checked against the task brief: versioned skill workflows for Codex and Claude Code, en/vi). Title/description are unique per canonical URL within the 12 captured pages. No length rule applied. Search appearance unknown.",[contentEv[i['itemId']],e['aud']])
for i in inv:
    u=i['uri'];e=ev[u]
    rv(i,'seo-internal-links','pass',"Every internal href on this page (and fragment target, where present) resolves to a page in the 12-page captured set. No broken internal targets found within the captured graph. Does not establish site-wide orphan status or rendered navigation.",[contentEv[i['itemId']],e['lg']])
rv(readme,'seo-canonical','not-applicable','Plain-text asset (content-type text/plain): no HTML head, so rel=canonical is not applicable.',[contentEv[readme['itemId']],ev[readme['uri']]['can']])
rv(readme,'seo-locales','not-applicable','Plain-text asset with no locale alternates; HTML hreflang not applicable.',[contentEv[readme['itemId']],ev[readme['uri']]['can']])
rv(readme,'seo-metadata','not-applicable','Plain-text asset: HTML title/description not applicable.',[contentEv[readme['itemId']],ev[readme['uri']]['aud']])
# findings
guides=[i for i in inv if '/guides/' in i['uri']]
bt=[];comma=[]
for i in guides:
    r=raws[i['uri']]
    assert '`codegraph status`' in r
    bt.append(i)
    if 'open Codex, at that project and invoke' in r or 'open Claude Code, at that project and invoke' in r:comma.append(i)
assert len(bt)==4 and len(comma)==2
for i in guides:
    rv(i,'quality-task-fit','fail',"Instruction text contains literal Markdown backticks (e.g. '(`codegraph status`)', '`codegraph --version`, `rtk --version`') outside any code element"+("; and the English sentence reads 'open Codex, at that project and invoke the skill' with a stray comma" if i in comma else "")+". Minor copy defect in setup steps; the task remains followable, so severity is low. Wider task-fit not assessed.",[contentEv[i['itemId']],ev[i['uri']]['aud']])
findings=[
 dict(findingId='F-GUIDES-BACKTICKS',title='Literal Markdown backticks appear in visible setup text on all four install guides (en/vi Codex and Claude Code)',remediation='Render the backticked commands as code elements (or remove the backticks) in the guide source so commands display as code, in both languages.',verification='Re-capture the four guide URLs and confirm no backtick characters remain in visible text outside <code>/<pre> elements.',ownerRole='Content/web engineer',effort='Low',affectedItemIds=[i['itemId'] for i in guides],ruleIds=['quality-task-fit'],dimensions=['quality'],evidenceIds=[contentEv[i['itemId']] for i in guides],severity='low',confidence='high',classification='observed'),
 dict(findingId='F-GUIDES-EN-COMMA',title="English guides contain a stray comma: 'open Codex, at that project and invoke the skill' / 'open Claude Code, at that project and invoke the skill'",remediation="Reword to e.g. 'open Codex at that project and invoke the skill' (and the Claude Code equivalent); the Vietnamese pages read correctly ('mở Codex, tại project đó, rồi gọi skill').",verification='Re-capture /en/guides/codex/ and /en/guides/claude-code/ and confirm the sentence text.',ownerRole='Content editor',effort='Low',affectedItemIds=[i['itemId'] for i in comma],ruleIds=['quality-task-fit'],dimensions=['quality'],evidenceIds=[contentEv[i['itemId']] for i in comma],severity='low',confidence='high',classification='observed')]
for i in comma: pass
bundle=dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],parts=[dict(path='parts/000001',sourceSnapshotHash=snap,bundle=dict(reviews=reviews,evidence=evidence,artifacts=artifacts,findings=findings))])
json.dump(bundle,open('work/part-review-bundle.json','w'),ensure_ascii=False,indent=1)
print(now,len(reviews),len(evidence))
