import json,hashlib,datetime
now=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
R='campaign-r2-index/';idx=json.load(open(R+'index.json'))
P='campaign-r2/parts/000001/'
inv=[json.loads(l) for l in open(P+'inventory.jsonl')]
ev=[json.loads(l) for l in open(P+'evidence.jsonl')]
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
content={e['itemId']:e['evidenceId'] for e in ev if e['kind']=='content'}
lg={e['itemId']:e['evidenceId'] for e in ev if e['kind']=='link-graph'}
aud={e['itemId']:e['evidenceId'] for e in ev if e['kind']=='audience-context'}
ref=lambda i:dict(part='parts/000001',evidenceId=i)
G='https://nkskills.getgroove.me'
rows=[]
def role(u):
    p=u[len(G):]
    loc='vi' if p.startswith('/vi/') else 'en' if p.startswith('/en/') or p=='/' else 'n/a'
    kind='font-license notice (text)' if 'licenses' in p else 'home' if p in('/','/en/','/vi/') else 'catalog' if 'catalog' in p else 'solution detail' if 'solutions' in p else 'host install guide'
    return f"{u} | locale={loc} | type={kind}"+(' | alias: 308 redirect to /en/, body identical to /en/' if p=='/' else '')
invmap="Reviewer-derived inventory map (NOT a CMS export; derived from the 12 captured snapshots and the discovery graph):\n"+"\n".join(role(i['uri']) for i in inv)
entity=("Reviewer-derived entity record (NOT an authoritative registry; compiled from visible text of captured snapshots, en and vi compared):\n"
"- Brand/product: NKSkills — versioned skill workflows for Codex and Claude Code (en home title; vi home title 'AI skill workflow có phiên bản cho Codex và Claude Code').\n"
"- Solution Skill codebase-onboarding: version 1.1.0, 'technical release' (en) / 'Bản kỹ thuật 1.1.0' (vi); components: codebase-onboarding-c4, html-docs-standard, Hallmark.\n"
"- Solution Skill problem-presentation: version 0.1.0, evaluation candidate; commercial release gate open (en home/catalog; vi equivalents).\n"
"- No direct-download archive published; setup starts from GitHub source (en/vi solution + guides).\n"
"- Catalog counts in en and vi: 02 Solution Skills, 15 Upstream Skills, 06 Security sources, 01 Versioning model.\n"
"- Numeric tokens compared between each en/vi page pair by deterministic token multiset: no differences for 5 pairs.")
audctx="Task brief (user-supplied, 2026-11-15): NKSkills composes versioned skill workflows for Codex and Claude Code; English and Vietnamese audiences; AIO = AI search optimization; no Google AI Overviews measurements supplied; no analytics, CMS or question set supplied."
def ctx(eid,kind,value,loc,refs):
    return dict(evidenceId=eid,kind=kind,value=value,snapshotHash=sha(value),locator=loc,collectedAt=now,sourceReferences=refs)
allcontent=[ref(v) for v in content.values()]
alllg=[ref(v) for v in lg.values()]
allaud=[ref(v) for v in aud.values()]
ctxs=[ctx('ctx-inventory-map','inventory-map',invmap,'reviewer-derived:campaign-r2 inventory.jsonl + resumed-discovery/graph.jsonl',allcontent),
 ctx('ctx-entity-record','entity-record',entity,'reviewer-derived:visible text of campaign-r2 content snapshots',allcontent),
 ctx('ctx-audience','audience-context',audctx,'user-request:nkskills-public-pilot',allaud)]
REV='content-search-audit host reviewer (Claude Sonnet 5.5), cross-page static snapshot review'
ids=[i['itemId'] for i in inv]
def rev(rule,status,reason,items,refs,cids):
    return dict(ruleId=rule,status=status,reason=reason,reviewer=REV,reviewedAt=now,itemIds=items,evidenceReferences=refs,contextEvidenceIds=cids)
reviews=[
 rev('portfolio-duplication','pass',"Compared the 12 snapshots for overlapping task coverage. The only exact duplicate is '/', a 308 alias whose body is byte-identical to /en/ and whose canonical is /en/. en/vi pairs are intentional locale variants with reciprocal hreflang; codex and claude-code guides differ in host-specific invocation, target flag and token ($ vs /). No unjustified duplication found within the captured set; consolidation not proposed. Query-level cannibalization is unknown (no search data).",ids,allcontent,['ctx-inventory-map']),
 rev('portfolio-contradictions','pass',"Compared versions, release status, component names, prerequisites, distribution status and catalog counts across the 12 snapshots and between en/vi pairs: no conflicting material claims found; numeric tokens match for all 5 en/vi pairs. Judged against the reviewer-derived entity record from the pages themselves; authoritative external records (GitHub catalog.yaml, release notes) are outside the authorized origin and were NOT compared.",ids,allcontent,['ctx-inventory-map','ctx-entity-record']),
 rev('portfolio-journey-links','pass',"Static internal links: every HTML page links to its locale home, catalog and a locale switch to the counterpart page; homes link to solution, catalog and both host guides; solution pages link to both guides; guides link back to home install/try-it anchors. All internal targets and fragments resolve within the captured set. Judged against the task brief audience only; rendered navigation, in-page scripts (starter-prompt selector on home) and external GitHub steps were not inspected.",ids,alllg+allcontent,['ctx-audience']),
 rev('portfolio-task-gaps','unknown',"No question set, query export, support themes or analytics supplied, so served-vs-missing user tasks cannot be judged; gaps are unknown, not absent.",[],allcontent[:1],[]),
]
b=dict(schemaVersion=1,campaignId=idx['campaignId'],sourceManifestHash=idx['sourceManifestHash'],partSnapshotHashes=idx['partSnapshotHashes'],contextEvidence=ctxs,reviews=reviews,findings=[])
json.dump(b,open('work/global-review-bundle.json','w'),ensure_ascii=False,indent=1);print(now)
