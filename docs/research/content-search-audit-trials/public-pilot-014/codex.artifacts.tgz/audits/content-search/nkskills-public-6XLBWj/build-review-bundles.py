import hashlib, html, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, urljoin
from html.parser import HTMLParser

root=Path(sys.argv[1])
mode=sys.argv[2]
source=root/("campaign" if mode=="local" else "reviewed-campaign")
index=root/("collection-index" if mode=="local" else "reviewed-index")
binding=json.loads((index/"index.json").read_text())
part="parts/000001"
assert set(binding["partSnapshotHashes"])=={part}
p=source/part
def rows(path): return list(map(json.loads,path.read_text().splitlines()))
def save(path,data):
    with (root/path).open("x") as f: json.dump(data,f,ensure_ascii=False,indent=2)
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
items={urlsplit(i["uri"]).path:i["itemId"] for i in rows(p/"inventory.jsonl")}
ev=rows(p/"evidence.jsonl")
records={(e["itemId"],e["kind"]):e for e in ev}
def src(path,kind="content"): return records[items[path],kind]
def read(path):
    e=src(path)
    b=(p/e["artifact"]).read_bytes()
    assert hashlib.sha256(b).hexdigest()==e["snapshotHash"]
    return b.decode()
docs={path:read(path) for path in items}
origin="https://nkskills.getgroove.me"
at=datetime.now(timezone.utc).isoformat(timespec="milliseconds")
reviewer="Codex — NKSkills public pilot"
base={k:binding[k] for k in ("campaignId","sourceManifestHash")}
base["schemaVersion"]=1
notes={
    "home":("Discovery","Explain the versioned workflow model, distinguish technical release from evaluation candidate, and direct readers to host setup.","The introduction identifies both hosts, the composition model and pinned inputs. The workflow cards distinguish onboarding 1.1.0 from presentation 0.1.0 and the FAQ reiterates the release gate."),
    "catalog":("Evaluation","Choose a workflow and inspect release labels, provenance and tracked capability.","The two workflow cards, upstream entries and versioning section distinguish shipped technical status, evaluation status and tracked source metadata. The cited manifest and external license claims were unverified."),
    "solutions":("Decision","Determine the purpose, prerequisites and deliverables of codebase onboarding.","The composition and limits sections identify three components, a valid CodeGraph index, codegraph and rtk, Quick mode C1/C2 and file evidence, source distribution and human review."),
    "guides":("Implementation","Build and install for the named host, then invoke and verify results.","The numbered workflow covers prerequisites, digest-based install, host-specific invocation and human review. The candidate has a distinct digest and test-project instructions."),
    "licenses":("Reference","Identify the site's fonts and the named full license notices.","The plain-text notice names Fraunces, Source Sans 3, IBM Plex Mono and SIL Open Font License 1.1. The referenced full license filenames were outside HTML link discovery and their files were not collected.")
}
def group(path):
    parts=path.strip("/").split("/")
    return parts[1] if len(parts)>1 and parts[0] in ("en","vi") else ("licenses" if path.startswith("/licenses/") else "home")
def target(path): return "/en/" if path=="/" else path
def pair(path):
    q=target(path)
    return ("/vi/"+q[4:]) if q.startswith("/en/") else ("/en/"+q[4:])
def ids(paths): return list(dict.fromkeys(src(q)["evidenceId"] for q in paths))
class Tags(HTMLParser):
    def __init__(self,s):
        super().__init__(); self.tags=[]; self.feed(s)
    def handle_starttag(self,tag,attrs): self.tags.append((tag,dict(attrs)))
    def select(self,tag): return [attrs for name,attrs in self.tags if name==tag]
parsed={q:Tags(s) for q,s in docs.items()}
guides=[q for q in items if group(q)=="guides"]
html_paths=[q for q in items if group(q)!="licenses"]
for q in guides:
    block=re.findall(r"<pre><code>(.*?)</code></pre>",docs[q],re.S)[0]
    assert "git clone https://github.com/KhucHieuNghi/agents-skills.git\ncd agents-skills\nnpm ci" in block
    assert "build/codebase-onboarding-1.1.0" in block
    assert not re.search(r"\bgit (?:checkout|switch)\b|git clone .*(?:--branch| -b )",docs[q])
    assert ("--target codex" if q.endswith("/codex/") else "--target claude-code") in html.unescape(docs[q])
    assert ("$codebase-onboarding-c4" if q.endswith("/codex/") else "/codebase-onboarding-c4") in docs[q]
assert src("/")["snapshotHash"]==src("/en/")["snapshotHash"]
for q in html_paths:
    t=target(q)
    links=parsed[q].select("link")
    assert [a["href"] for a in links if a.get("rel")=="canonical"]==[origin+t]
    assert {a["hreflang"]:a["href"] for a in links if "hreflang" in a}=={
       "en":origin+(t if t.startswith("/en/") else pair(t)),
       "vi":origin+(t if t.startswith("/vi/") else pair(t)),
       "x-default":origin+(t if t.startswith("/en/") else pair(t))}
    assert parsed[q].select("html")[0]["lang"]==t[1:3]
    assert any(a.get("class")=="language-link" and a.get("href")==pair(q) for a in parsed[q].select("a"))
    assert src(q,"http-response")["value"]["status"]==200
def destinations(q):
    return sorted({urlsplit(urljoin(origin+target(q),a["href"])).path
        for a in parsed[q].select("a") if "href" in a and urlsplit(urljoin(origin+target(q),a["href"])).netloc==urlsplit(origin).netloc})
dest={q:destinations(q) for q in items}
assert all(t in items for targets in dest.values() for t in targets)
for q in html_paths:
    for a in parsed[q].select("a"):
        if "href" not in a: continue
        url=urlsplit(urljoin(origin+target(q),a["href"]))
        if url.netloc==urlsplit(origin).netloc and url.fragment:
            assert any(v.get("id")==url.fragment for _,v in parsed[url.path].tags)
missing_revision="The first build block clones the repository default branch and proceeds to npm ci without selecting a release tag or commit. The versioned output directory and digest from that build do not identify the source revision of the referenced technical release."
fix="In all four host guides, name the maintainer-verified immutable source revision for onboarding 1.1.0 and show how to select it before dependency installation. For the candidate, state the source revision to use and keep its digest instructions separate."
verify="Compare the revised snippets with publisher release records, then have the publisher rebuild from fresh clones for both hosts and confirm the source revision, manifest version and digest."
scope="Source-only judgment for the authorized static-link inventory. Publisher records, rendered behavior, indexing, performance and external destinations were outside this evidence."
inventory="\n".join(f"{q} | {notes[group(q)][0]} | {notes[group(q)][1]}" for q in sorted(items))
graph="\n".join(f"{q} -> {', '.join(dest[q]) or '(plain text, no HTML anchors)'}" for q in sorted(items))
entity="Across both locales: onboarding is a 1.1.0 technical release, presentation is a 0.1.0 evaluation candidate; guides preserve host-specific install targets and invocation, and solution pages require codegraph, rtk and a valid repository-root index. The root is a 308 alias of the English homepage, not a separate editorial page. The font notice is scoped to site fonts. Release verification claims are publisher statements without independently reviewed release records."
questions="Page-derived questions, with demand unverified: What is NKSkills? Which workflows are available and at what release status? What does onboarding produce and need? How do I install on the chosen host? Which fonts have notices? No customer, query or support corpus supplied."
if mode=="local":
    reviews=[]; evidence=[]; artifacts={}; findings=[]
    def derived(q,kind,value,sources):
        eid=sha(items[q]+":"+kind+":"+value)
        artifact=f"evidence/review-{eid}.txt"
        artifacts[artifact]=value
        evidence.append(dict(evidenceId=eid,itemId=items[q],kind=kind,value=value,
            collectedAt=at,method="attributed-static-snapshot-review",locator=origin+q+" [source snapshot review: "+kind+"]",
            snapshotHash=sha(value),redaction="none",limitations=[scope],sourceEvidenceIds=list(dict.fromkeys(sources)),
            artifact=artifact,encoding="utf8"))
        return eid
    for q in items:
        eid=src(q)["evidenceId"]
        h=group(q)!="licenses"
        stage,task,assessment=notes[group(q)]
        cross=ids([q]+([target(q),pair(q)] if h else []))
        context=derived(q,"audience-context","User-supplied business context: versioned skill workflows for Codex and Claude Code, English and Vietnamese audiences. Inferred task: "+task+" "+assessment,[eid])
        qset=derived(q,"question-set",questions+" This item's task: "+task,[eid])
        imap=derived(q,"inventory-map",inventory,ids(items))
        ent=derived(q,"entity-record",entity,ids(items))
        links=derived(q,"link-graph",graph,ids(items))
        def review(rule,status,reason,refs=(eid,)):
            reviews.append(dict(itemId=items[q],ruleId=rule,status=status,reason=reason,evidenceIds=list(refs),reviewer=reviewer,reviewedAt=at))
        review("quality-task-fit","fail" if q in guides else "pass",assessment+(" "+missing_revision if q in guides else " Captured text serves the stated narrow author-intended task."),(eid,context))
        if q in guides:
            findings.append(dict(findingId="source-revision-"+q.strip("/").replace("/","-"),title="The "+q.strip("/")+" build recipe leaves the source revision unspecified",
                affectedItemIds=[items[q]],ruleIds=["quality-task-fit"],dimensions=["quality"],evidenceIds=[eid,context],classification="observed",severity="medium",confidence="high",remediation=fix,verification=verify,ownerRole="Release documentation maintainer",effort="Small documentation change after release revision verification"))
        for rule,reason in {
            "quality-claims":"Material "+group(q)+" claims were read. Independent release, compatibility, upstream or license evidence was unavailable for their full verification.",
            "quality-freshness":"Captured copy was available. Current applicability of versions, tooling and referenced records was not verified.",
            "seo-index-controls":"Observed response plus source are available. URL-specific publisher intent and indexing observations were unavailable.",
            "aio-crawler-policy":"The helper's captured robots body contained User-agent: * and Allow: /. Publisher intent for the individual search, training and user-fetch surfaces is unconfirmed.",
            "aeo-question-coverage":"Page-derived questions were used for editorial review. Customer question evidence was not supplied.",
            "aeo-answer-context":assessment+(" "+missing_revision if q in guides else "")+" Real question coverage and all changing prerequisites lack corroboration.",
            "aeo-answer-evidence":"Source copy supports a description of the intended answer. No independent claim sources were supplied.",
            "geo-observed-presence":"No dated AI response observations. Mentions and citations are unknown.",
            "geo-answer-accuracy":"No AI responses or external claim adjudication were supplied.",
            "geo-cohort-validity":"No AI platform, prompt cohort, market or repeated observations were supplied.",
            "portfolio-task-gaps":"The task is mapped to the static inventory. Missing demand, CMS and rendered evidence leave portfolio-wide gaps unresolved.",
            "portfolio-contradictions":"Compared bilingual launch status, host mappings and onboarding prerequisites. Immutable release and manifest corroboration was unavailable.",
        }.items():
            kinds={"aio-crawler-policy":"crawler-policy","seo-index-controls":"http-response"}
            refs=[eid]
            if rule in kinds: refs.append(src(q,kinds[rule])["evidenceId"])
            if rule.startswith("aeo-"): refs.append(qset)
            if rule=="portfolio-task-gaps": refs += [imap,qset]
            if rule=="portfolio-contradictions": refs += [imap,ent]
            review(rule,"unknown",reason,refs)
        review("aio-retrievable-facts","pass",assessment+" This is a raw-response fact-location judgment.",(eid,context))
        review("aio-entity-consistency","unknown",entity+" Full authoritative verification remains unknown.",(eid,ent))
        review("portfolio-duplication","pass","In the declared inventory the root duplicates English home via its redirect, five EN/VI pairs serve language variants, and both hosts have distinct installation targets. The font notice is separate.",(eid,imap))
        review("portfolio-journey-links","unknown","Static next steps were mapped, including the guide-to-starter anchor. Prompt behavior, external handoffs and notice filenames were unverified.",(eid,links,context))
        if h:
            canon=derived(q,"canonical-targets",f"Declared canonical {origin+target(q)}. Captured destination returned final HTTP 200 and self-declares this canonical. This does not establish engine selection.",ids([q,target(q)])+[src(target(q),"http-response")["evidenceId"]])
            loc=derived(q,"locale-map",f"{target(q)} and {pair(q)} declare reciprocal en/vi alternates and matching html lang. Each self-canonicalizes and links to its translated counterpart. x-default points to the English member.",cross)
            t=re.search(r"<title>(.*?)</title>",docs[q]).group(1)
            d=next(a["content"] for a in parsed[q].select("meta") if a.get("name")=="description")
            review("seo-metadata","pass",f"Title ({html.unescape(t)}) and description ({html.unescape(d)}) identify the page's task and language. Main heading and copy support the same intent.",(eid,context))
            review("seo-canonical","pass","Captured canonical points to the same language document. The root follows its observed 308 redirect to English.",(eid,canon))
            review("seo-locales","pass","Source metadata and language switch anchors agree across the captured EN/VI pair.",(eid,loc))
            review("seo-internal-links","pass","The inventory contains the same-origin anchor destinations for this reviewed source and captured targets succeeded. Same-origin fragment IDs exist in captured HTML. Rendered navigation and external links are outside this judgment.",(eid,links))
            review("quality-accessible-media","unknown","The captured logo uses empty alt alongside a brand label. Full equivalence of visual content and accessibility behavior remains unverified.")
            review("seo-structured-data","unknown","No JSON-LD blocks observed in raw source. Rendered structured data and feature applicability remain unverified.")
            review("seo-rendering","unknown","The helper flagged script or inert surfaces. Homepage starter templates are present as source. Actual DOM, prompt switching and copying were not observed.")
        else:
            for rule in ["seo-metadata","seo-canonical","seo-locales","seo-structured-data","seo-rendering","quality-accessible-media"]:
                review(rule,"not-applicable","This captured text/plain font notice contains prose and filenames, with no HTML document, embedded media, or alternate locale declaration to evaluate.")
            review("seo-internal-links","unknown","HTML navigation extraction does not apply to this representation. The three mentioned notice filenames remain visible and have no tested destination.",(eid,links))
    save("part-review-bundle.json",{**base,"parts":[dict(path=part,sourceSnapshotHash=binding["partSnapshotHashes"][part],bundle=dict(reviews=reviews,evidence=evidence,artifacts=artifacts,findings=findings))]})
else:
    contentrefs=[dict(part=part,evidenceId=x) for x in ids(items)]
    ctx=[]
    def context(kind,value,paths):
        eid=sha(kind+value)
        ctx.append(dict(evidenceId=eid,kind=kind,value=value,snapshotHash=sha(value),locator="NKSkills public pilot — "+kind,
            collectedAt=at,sourceReferences=[dict(part=part,evidenceId=x) for x in ids(paths)]))
        return eid
    imap=context("inventory-map",inventory,items)
    ent=context("entity-record",entity,items)
    links=context("link-graph",graph,items)
    audience=context("audience-context","Pilot request: NKSkills composes versioned skill workflows for Codex and Claude Code, English and Vietnamese audiences. Static navigation only. No supplied measurements.",items)
    qs=context("question-set",questions,items)
    reviews=[]
    for rule,status,reason,ctxids in [
        ("portfolio-task-gaps","unknown","Every declared identity is mapped to a task. Real customer demand and availability of CMS, orphan and rendered pages are unknown. The notes are informed hypotheses.",[imap,qs]),
        ("portfolio-duplication","pass","The observed 308 root redirect and matching English response bytes account for the duplicate. Five paired page roles legitimately serve EN and VI, and both guide pairs differ by target and invocation syntax. The notice has a separate purpose.",[imap]),
        ("portfolio-contradictions","unknown",entity+" Checked alignment of these first-party statements. Release records and manifests were external to scope.",[ent,imap]),
        ("portfolio-journey-links","unknown","Both homes and solution pages lead to host guides, and guides link back to their locale's starter anchor. Candidate evaluation and technical source record destinations are external. Prompt controls need rendered verification, and plain-text notice filenames remain unverified.",[links,audience]),
    ]:
        reviews.append(dict(ruleId=rule,status=status,reason=reason,reviewer=reviewer,reviewedAt=at,itemIds=list(items.values()),evidenceReferences=contentrefs,contextEvidenceIds=ctxids))
    save("global-review-bundle.json",{**base,"partSnapshotHashes":binding["partSnapshotHashes"],"contextEvidence":ctx,"reviews":reviews,"findings":[]})

