# Content audit — Content Search Audit

## Delivery summary

Partial\. 12 declared items; 0 fully audited\. Audit coverage is separate from content quality and measured performance\. Historical study sources attached: 0; historical results are not current brand performance\. Response\-level AI observations: not attached\. Search Console exports: not attached\. GA4 exports: not attached\. Bing exports: not attached\. Server\-log exports: not attached\. Attachment status describes this report only, not all evidence available to the customer\. Consult the detailed evidence for dates, scope, synthetic labels, observations and limitations\. Missing measurements remain unknown, not zero\. Structural validation does not establish semantic accuracy\.

## Source age reference

Age reference: 2026\-11\-18T08:12:01\.937Z\. Timestamp ages count complete 24\-hour intervals; date\-only reviews use UTC calendar\-day differences without inventing a time\. Capture/export age is not the age of underlying facts or measurement windows\. Rule review age is not a new source verification\. Missing or future dates remain unavailable; no stale\-content verdict follows from age alone\.

## Audit status

Partial\. Run 1362db48\-a76e\-49f2\-a293\-596b91adf9af\. 0 findings\. Coverage is separate from whether content checks pass\. Structural validation does not establish semantic truth or search performance\.

## Coverage

| Metric | Count |
| --- | --- |
| Declared items | 12 |
| In scope | 12 |
| Audited | 0 |
| Accounted | 2 |
| Excluded | 0 |
| Blocked | 2 |
| Failed | 0 |
| Unsupported | 0 |
| Pending | 10 |
| Missing checks | 0 |
| Remaining queue | 0 |

## Coverage denominator

All declared inventory items; exclusions remain counted and explained\. Dimension totals count supplied checks, not missing checks\.

## Scope limitations

Required item checks remain unresolved

## Priority backlog

No records.

## Finding interpretation

No findings were recorded\. This does not resolve unknown checks or demonstrate measured search visibility\.

## Dimension coverage

| Dimension | Supplied checks | Pass/fail assessed | Unknown | Not applicable |
| --- | --- | --- | --- | --- |
| aeo | 36 | 0 | 36 | 0 |
| aio | 36 | 0 | 36 | 0 |
| geo | 36 | 0 | 36 | 0 |
| portfolio | 48 | 0 | 48 | 0 |
| quality | 60 | 0 | 60 | 0 |
| seo | 96 | 0 | 96 | 0 |

## Visibility measurements unavailable

No response\-level AI observations attached to this report\. Supplied documents may contain historical aggregates; retain those separately\. Readiness is not measured mentions, citations or factual accuracy; missing response\-level observations remain unknown\.

## Search Console measurements unavailable

No Search Console export supplied\. Missing measurements are unknown, not zero\. Audit completion does not imply measured search performance\.

## Analytics measurements unavailable

No GA4 export supplied\. Missing analytics is unknown, not zero; content readiness does not establish traffic or revenue\.

## Bing measurements unavailable

No Bing traffic or AI dashboard export supplied\. Missing observations are unknown, not zero\.

## Server-log measurements unavailable

No normalized server\-log export supplied\. Crawl/access observations remain unavailable\.

## Inventory appendix

| Item | State | Reason | Required checks |
| --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | pending | Collected; semantic review and applicable evidence remain pending | 26 |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | blocked | Network collection requires the authorized network collector; local mode does not fetch URLs | 26 |

## Checks appendix

| Item | Rule | Dimension | Status | Reason | Evidence |
| --- | --- | --- | --- | --- | --- |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| 0439a52bf2cd1152e22fc1744c5c2a3a4fb3031cfa4103da21eb51acb030f8cf | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-locales | seo | unknown | Missing required evidence: locale\-map | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | quality\-task\-fit | quality | unknown | Missing required evidence: audience\-context | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | quality\-claims | quality | unknown | Missing required evidence: claim\-sources | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | quality\-freshness | quality | unknown | Missing required evidence: claim\-sources | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | quality\-accessible\-media | quality | unknown | Missing required evidence: media\-inventory | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-index\-controls | seo | unknown | Missing required evidence: http\-response, publisher\-intent | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-canonical | seo | unknown | Missing required evidence: canonical\-targets | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-metadata | seo | unknown | Missing required evidence: audience\-context | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-internal\-links | seo | unknown | Missing required evidence: link\-graph | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-structured\-data | seo | unknown | Missing required evidence: schema\-extraction | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-locales | seo | unknown | Missing required evidence: locale\-map | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | seo\-rendering | seo | unknown | Missing required evidence: rendered\-dom | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aio\-entity\-consistency | aio | unknown | Missing required evidence: entity\-record | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: audience\-context | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: question\-set | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aeo\-answer\-context | aeo | unknown | Missing required evidence: question\-set | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: claim\-sources | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: inventory\-map, question\-set | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | portfolio\-duplication | portfolio | unknown | Missing required evidence: inventory\-map | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: entity\-record, inventory\-map | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: link\-graph, audience\-context | 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-task\-fit | quality | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-claims | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-freshness | quality | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-accessible\-media | quality | unknown | Missing required evidence: content, media\-inventory |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | quality\-readable\-text | quality | unknown | Missing required evidence: extracted\-text |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-response | seo | unknown | Missing required evidence: http\-response |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-index\-controls | seo | unknown | Missing required evidence: content, http\-response, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-canonical | seo | unknown | Missing required evidence: content, canonical\-targets |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-metadata | seo | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-internal\-links | seo | unknown | Missing required evidence: content, link\-graph |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-structured\-data | seo | unknown | Missing required evidence: content, schema\-extraction |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-locales | seo | unknown | Missing required evidence: content, locale\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | seo\-rendering | seo | unknown | Missing required evidence: content, rendered\-dom |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-crawler\-policy | aio | unknown | Missing required evidence: crawler\-policy, publisher\-intent |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-entity\-consistency | aio | unknown | Missing required evidence: content, entity\-record |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aio\-retrievable\-facts | aio | unknown | Missing required evidence: content, audience\-context |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-question\-coverage | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-context | aeo | unknown | Missing required evidence: content, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | aeo\-answer\-evidence | aeo | unknown | Missing required evidence: content, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-observed\-presence | geo | unknown | Missing required evidence: ai\-observations |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-answer\-accuracy | geo | unknown | Missing required evidence: ai\-observations, claim\-sources |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | geo\-cohort\-validity | geo | unknown | Missing required evidence: ai\-observations, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-task\-gaps | portfolio | unknown | Missing required evidence: content, inventory\-map, question\-set |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-duplication | portfolio | unknown | Missing required evidence: content, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-contradictions | portfolio | unknown | Missing required evidence: content, entity\-record, inventory\-map |  |
| ea3ef9f75e1ab9cd6962e44f99296529ecba5ac7fcb87e103faa8858cebf5748 | portfolio\-journey\-links | portfolio | unknown | Missing required evidence: content, link\-graph, audience\-context |  |

## Missing checks

No records.

## Evidence appendix

| Evidence | Item | Method | Collected | Age at report time | Artifact | Hash | Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| bc13f5bfc2d786bf719bdd88d38dd606a64b5f7788f2d74bceed82352c4a993c | 05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a | local\-file | 2026\-11\-18T08:12:01\.912Z | 0 full elapsed days | [evidence/05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a\.txt](evidence/05c640fa6831780a88afb1ed540748ce58184574275913b11742cf3e5860d22a.txt) | 4cea9fc5d49f8296b41b9963eecf70c44be3c32caa410373af4b8d2f73f25cbd | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dab9d138c7a379112e539e91f00ed0cc71aefb25beffb70dd831e01c8fdd69ed | 1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3 | local\-file | 2026\-11\-18T08:12:01\.913Z | 0 full elapsed days | [evidence/1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3\.txt](evidence/1d3073b064dd974d4ff4d05b5306d8e1ee27c7563882e844aeeafe602e06c6c3.txt) | b36a42cc0dd966501bfa26550b0af85453b05a176e74079139ef4463322b2315 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 49a93e7ae99cd45c74ddc5c82ea84bec68076e0436dadc15e99902edcaf7bcf2 | 513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059 | local\-file | 2026\-11\-18T08:12:01\.913Z | 0 full elapsed days | [evidence/513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059\.txt](evidence/513cc07ba89393baa0662c459d02b3091faec649e9d9db4bc8a1662150c64059.txt) | a497f2f61e70f56ee8616b90cfe9d54dff452794defa4391ab89f1a633fd4180 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c9930949d12368e4a88963038524d139eb50c7050622d7d62f9bbc8b5f354a1b | 533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785 | local\-file | 2026\-11\-18T08:12:01\.914Z | 0 full elapsed days | [evidence/533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785\.txt](evidence/533b7be1fe4dc5c768195690feb66d176272d7d130703879836306fc31889785.txt) | 2362f5682ade2e95748a9dbca782b8a812c1b0c11b06ff22569c0bb3739d146d | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| a26276dffcc183740ab6dbf7543d597f83b760cec5f3ecb76aec0be8b92ca0cf | 5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311 | local\-file | 2026\-11\-18T08:12:01\.915Z | 0 full elapsed days | [evidence/5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311\.txt](evidence/5a97d639930aea98e003bd93ffbdc025a9e44311c258db6ef9d06125c649c311.txt) | 3477bb8cdc6c6d8ee9210fa85da2984f21ebc1802294f753525a111cac7c8201 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| eb6c4ac1d3422f472884b317fb20e169ad4123b8313344ff1916a68d6b1d6b11 | 72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025 | local\-file | 2026\-11\-18T08:12:01\.916Z | 0 full elapsed days | [evidence/72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025\.txt](evidence/72a50e1ab12abf32acee788e85932e1e9ba7f00aef35ff91d268f3614df0e025.txt) | ef3621e52fa3c895d9a6d8a1b220e1ba55d9a7ad6c86c1645a7e082f2c2741a3 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| d1db31db010dd27a9eee9862ef6aef332f35fe5bd325bee359d4f0c977ee7422 | 79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26 | local\-file | 2026\-11\-18T08:12:01\.916Z | 0 full elapsed days | [evidence/79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26\.txt](evidence/79d3bc5d8778a963262dad18d464b8cb40c8d6dec79080290061abfc0d342c26.txt) | dee455ea7676afa9a065d68a6450c9b02b795efc27afb4ee5a56684b9154b77f | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| c2ecb20b9b9fcf380d1be918441f9391594ef350fdd20c7a014f3a5eea5488c3 | 9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796 | local\-file | 2026\-11\-18T08:12:01\.917Z | 0 full elapsed days | [evidence/9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796\.txt](evidence/9c353df576cf4f14e10d7245ec62f5df1dbafa081fcd3839d6e3ace68bd14796.txt) | e78906e8f0dff77645544b90eeb7b662ea73d118bf5b3c879129d864d2ff35a8 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| dd307305f643d4b60d7075eb7af3695c8fa5d233aae401e2545448a6fdd3a18d | a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707 | local\-file | 2026\-11\-18T08:12:01\.917Z | 0 full elapsed days | [evidence/a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707\.txt](evidence/a1d6f6d478661354686d9ad9212922348975f2b7a93938f504e9a4093ff74707.txt) | 8c163118433437521e167f0c16a3b0eca70d2e9c0e23734798b68edf6a8440d1 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |
| 91370486d2421e668ffe1f1fe73cd36d050effacad7f3ae6219e22cc2108a6cb | b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0 | local\-file | 2026\-11\-18T08:12:01\.918Z | 0 full elapsed days | [evidence/b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0\.txt](evidence/b4fc3ad6483b851523502d94d30d17cd35599a233b6f073773a5e982caad35a0.txt) | 241d41ef7b9ff4d3c0f5dd6f4905071101ebda49743f1d6c5428f2216142ca11 | Local export does not establish public reachability, index status or freshness of the live site; HTML is source text, not rendered DOM; target scripts were not executed |

## Rule provenance

| Rule | Reviewed | Age at report time | Sources | Limitations |
| --- | --- | --- | --- | --- |
| quality\-task\-fit | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Unknown audience context prevents a confident fit judgment\. |
| quality\-claims | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No external corroboration is not proof of falsehood\. |
| quality\-freshness | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Publication dates alone do not establish factual freshness\. |
| quality\-accessible\-media | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://www\.w3\.org/WAI/tutorials/images/decision\-tree/; https://www\.w3\.org/WAI/media/av/transcripts/ | Decorative imagery may have empty alt; missing extraction remains unknown\. |
| quality\-readable\-text | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | A nonempty extraction does not establish quality or completeness\. |
| seo\-response | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/crawling/docs/troubleshooting/http\-status\-codes | This checks transport only, not index status, robots policy or rendered completeness\. |
| seo\-index\-controls | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/block\-indexing; https://developers\.google\.com/search/docs/crawling\-indexing/robots\-meta\-tag | Raw source may not show rendered directives; access and indexing are separate\. |
| seo\-canonical | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/consolidate\-duplicate\-urls | A declared canonical does not establish engine\-selected canonical\. Non\-HTML resources can declare canonicals through HTTP Link headers; media type alone does not justify not\-applicable\. |
| seo\-metadata | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/title\-link; https://developers\.google\.com/search/docs/appearance/snippet | No fixed character count, keyword position or H1 count is a universal failure\. |
| seo\-internal\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/links\-crawlable | Incomplete discovery cannot prove a page is orphaned\. |
| seo\-structured\-data | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/structured\-data/sd\-policies | Raw absence does not establish rendered absence; valid syntax is not guaranteed eligibility\. |
| seo\-locales | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/specialty/international/localized\-versions | A faulty relationship must not be generalized to every locale\. |
| seo\-rendering | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/crawling\-indexing/javascript/javascript\-seo\-basics | An unavailable renderer produces unknown, not absent content\. |
| aio\-crawler\-policy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.openai\.com/api/docs/bots; https://developers\.google\.com/search/docs/appearance/ai\-features | Training, search discovery and user\-triggered retrieval are different purposes\. |
| aio\-entity\-consistency | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6/profound/aeo\-operator\-2026 | Ambiguous entity identity is not proof of actual model confusion\. Crawler documentation supports access policy, not entity consistency or a citation benefit\. |
| aio\-retrievable\-facts | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/appearance/ai\-features | Readable facts do not prove retrieval or citation by an engine\. |
| aeo\-question\-coverage | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Hypothetical questions must remain labeled as hypotheses\. |
| aeo\-answer\-context | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | No universal answer word count is enforced\. |
| aeo\-answer\-evidence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://developers\.google\.com/search/docs/fundamentals/creating\-helpful\-content | Clear formatting does not establish factual accuracy\. |
| geo\-observed\-presence | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | Missing observations remain unknown; readiness cannot substitute for measurement\. |
| geo\-answer\-accuracy | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | A negative but accurate statement is not an error\. |
| geo\-cohort\-validity | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/retieedra\-profound/skills\-marketing\-library/tree/80293f156c27d3f90aedebfb3c27309769b2eec6 | One response does not establish a persistent visibility trend\. |
| portfolio\-task\-gaps | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Competitor coverage alone does not establish customer demand\. |
| portfolio\-duplication | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Keyword overlap alone is not cannibalization; consolidation is a proposal\. |
| portfolio\-contradictions | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Preserve date and market differences before calling claims contradictory\. |
| portfolio\-journey\-links | 2026\-11\-16 | 2 UTC calendar days \(date only\) | https://github\.com/coreyhaines31/marketingskills/blob/1f837447b20bb6f0e72d87b80ece1c221c362c7d/skills/content\-strategy/SKILL\.md | Navigation preferences do not establish search ranking impact\. |

## Next steps

Resolve the listed scope, item and check gaps, refresh changed evidence, re\-run validation and regenerate reports\. Do not describe this run as a full audit until the completion gate passes\.
