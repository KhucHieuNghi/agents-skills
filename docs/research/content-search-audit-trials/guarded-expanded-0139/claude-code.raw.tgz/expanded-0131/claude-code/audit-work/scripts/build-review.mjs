// Builds the attributed review bundle for the ten-dossier audit from the started run.
// Usage: node build-review.mjs RUN_DIRECTORY OUTPUT_REVIEW_JSON
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { Buffer } from "node:buffer";

const [runDir, outFile] = process.argv.slice(2);
if (!runDir || !outFile) throw new Error("Usage: RUN_DIRECTORY OUTPUT_JSON");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const jsonl = async (f) =>
  (await readFile(path.join(runDir, f), "utf8"))
    .split("\n")
    .filter((l) => l.trim())
    .map((l) => JSON.parse(l));
const inventory = await jsonl("inventory.jsonl");
const evidence = await jsonl("evidence.jsonl");
const now = new Date().toISOString();
const reviewer = "Claude (content-search-audit host review)";

const item = (name) => {
  const found = inventory.find((i) => i.path && i.path.endsWith("/" + name));
  if (!found) throw new Error("Missing item " + name);
  return found.itemId;
};
const content = (name) => {
  const id = item(name);
  const rec = evidence.find((e) => e.itemId === id && e.kind === "content");
  if (!rec) throw new Error("Missing content " + name);
  return rec;
};

const bundle = { artifacts: {}, evidence: [], reviews: [], findings: [] };
const SUPPLIED =
  "Statement transcribed from the supplied synthetic dossier; owner-supplied context, not independently verified and not a live observation";

function add(name, key, kind, locator, value, extraLimits = []) {
  const snap = content(name);
  const isJson = typeof value !== "string";
  const bytes = isJson ? JSON.stringify(value) : value;
  const evidenceId = `${name.slice(0, 2)}-${key}`;
  const artifact = `evidence/${evidenceId}.${isJson ? "json" : "txt"}`;
  bundle.artifacts[artifact] = bytes;
  bundle.evidence.push({
    evidenceId,
    itemId: snap.itemId,
    method: "host-derived record of supplied dossier context",
    collectedAt: now,
    locator,
    snapshotHash: hash(bytes),
    byteLength: Buffer.byteLength(bytes),
    redaction: "none; authorized source content retained locally",
    limitations: [SUPPLIED, ...extraLimits],
    kind,
    value,
    artifact,
    encoding: isJson ? "json" : "utf8",
    sourceEvidenceIds: [snap.evidenceId],
  });
  return evidenceId;
}
function review(name, ruleId, status, reason, evidenceIds) {
  bundle.reviews.push({
    itemId: item(name),
    ruleId,
    status,
    reason,
    evidenceIds,
    reviewer,
    reviewedAt: now,
  });
}

// ---------- 01 Supplied capture A ----------
{
  const n = "01-visibility.md";
  const c = content(n).evidenceId;
  const intent = add(
    n,
    "publisher-intent",
    "publisher-intent",
    "01-visibility.md:3",
    "Publisher intent: this public product page should be eligible for Google indexing.",
  );
  const http = add(
    n,
    "http-response",
    "http-response",
    "01-visibility.md:4-5",
    {
      status: 200,
      url: "https://store.example.invalid/product",
      capturedAt: "2026-11-10T08:00:00Z",
      headers: { "x-robots-tag": "noindex" },
    },
    [
      "Only the status and the X-Robots-Tag header are reported by the dossier; other headers are unknown",
    ],
  );
  const canon = add(
    n,
    "canonical-targets",
    "canonical-targets",
    "01-visibility.md:4-6",
    "Captured URL https://store.example.invalid/product; raw HTML head declares link rel=canonical href=https://store.example.invalid/product (self-referential). No competing variant, HTTP Link header or engine-selected canonical is supplied.",
  );
  const crawl = add(
    n,
    "crawler-policy",
    "crawler-policy",
    "01-visibility.md:5",
    "Robots.txt permits Googlebot access to /product. Response header: X-Robots-Tag: noindex.",
    ["Policies for crawlers other than Googlebot are not supplied"],
  );
  review(
    n,
    "seo-index-controls",
    "fail",
    "The captured response carries X-Robots-Tag: noindex while the publisher intends the page to be eligible for Google indexing and the raw HTML meta robots says index,follow. The header is an index-blocking directive that contradicts stated intent and the in-page directive. Actual index status is not observed.",
    [c, http, intent],
  );
  review(
    n,
    "seo-canonical",
    "pass",
    "The declared canonical in the raw HTML head equals the captured URL (self-referential) and no competing variant is supplied. This covers the captured declaration only; engine-selected canonical is not observed.",
    [c, canon],
  );
  review(
    n,
    "aio-crawler-policy",
    "unknown",
    "Robots.txt access for Googlebot is supplied, but no target AI surface, publisher intent for AI retrieval, or policy for other crawlers is supplied. The noindex conflict is recorded under seo-index-controls.",
    [crawl, intent],
  );
  bundle.findings.push({
    findingId: "F-01-noindex-header-vs-intent",
    title:
      "X-Robots-Tag: noindex header contradicts the publisher's intent that the product page be eligible for Google indexing",
    affectedItemIds: [item(n)],
    ruleIds: ["seo-index-controls"],
    dimensions: ["seo"],
    evidenceIds: [c, http, intent],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      "Remove the noindex value from the X-Robots-Tag response header for https://store.example.invalid/product so that the header agrees with the page's meta robots index,follow and the stated intent. This is a proposal for a separate implementation task.",
    verification:
      "Take a new raw HTTP capture of the same URL and confirm the response has no noindex in X-Robots-Tag or in meta robots. Index status is a separate observation that needs supplied index evidence; a clean header does not prove the page is indexed.",
    ownerRole: "Web platform / SEO owner",
    effort: "small",
    action: "update",
    actionReason:
      "The supplied capture directly shows a directive that conflicts with stated publisher intent",
  });
}

// ---------- 02 Supplied capture B ----------
{
  const n = "02-route.md";
  const c = content(n).evidenceId;
  const intent = add(
    n,
    "publisher-intent",
    "publisher-intent",
    "02-route.md:3",
    "Publisher intent: /old should redirect once to an accessible /new product page.",
  );
  review(
    n,
    "seo-response",
    "unknown",
    "Both captured responses are 301 redirects that point at each other and no final response was captured, so the final-status check cannot resolve. The observed loop is persisted as finding F-02.",
    [c],
  );
  review(
    n,
    "seo-canonical",
    "unknown",
    "An older sitemap export lists /new as preferred, but no canonical declaration, current sitemap or engine-selected canonical is supplied; /new itself redirects back to /old in the capture.",
    [c],
  );
  bundle.findings.push({
    findingId: "F-02-redirect-loop",
    title:
      "/old and /new redirect to each other (301 loop), so the intended /new product page is not reachable in the supplied capture",
    affectedItemIds: [item(n)],
    ruleIds: ["seo-response"],
    dimensions: ["seo"],
    evidenceIds: [c, intent],
    severity: "critical",
    confidence: "high",
    classification: "observed",
    remediation:
      "Remove the 301 from https://store.example.invalid/new back to /old so that /new returns a final successful response, and keep the single 301 from /old to /new. This is a proposal for a separate implementation task.",
    verification:
      "Recapture GET /old and GET /new from the same deployment: /old must return exactly one 301 whose Location is /new, and /new must return a final 2xx response with no redirect. Then compare a current sitemap export with /new as the preferred URL.",
    ownerRole: "Web platform owner",
    effort: "small",
    action: "update",
    actionReason:
      "The supplied capture directly shows a loop that conflicts with stated publisher intent",
  });
}

// ---------- 03 Supplied capture C ----------
{
  const n = "03-offer.md";
  const c = content(n).evidenceId;
  const schema = add(
    n,
    "schema-extraction",
    "schema-extraction",
    "03-offer.md:8-18",
    {
      "@context": "https://schema.org",
      "@type": "Product",
      name: "Example plan",
      offers: {
        "@type": "Offer",
        price: "19",
        priceCurrency: "USD",
        url: "https://store.example.invalid/plan",
      },
    },
    ["Transcribed from the supplied JSON-LD block; no rendered DOM or feature test"],
  );
  const policy =
    "The publisher confirms the visible US monthly price below is the current policy. Visible content: Example plan, United States monthly billing, USD 29 before taxes.";
  const entity = add(n, "entity-record", "entity-record", "03-offer.md:3-4", policy);
  const claims = add(n, "claim-sources", "claim-sources", "03-offer.md:3-4", policy);
  review(
    n,
    "seo-structured-data",
    "fail",
    "The JSON-LD Offer states price 19 USD while the visible, publisher-confirmed US monthly price on the same page, market and capture time is USD 29. Structured data does not match the visible claim. Rich-result eligibility is untested.",
    [c, schema],
  );
  review(
    n,
    "aio-entity-consistency",
    "fail",
    "The same plan carries two prices in one capture: 29 USD in visible copy (confirmed current by the publisher) and 19 USD in machine-readable JSON-LD. No model or engine confusion is observed.",
    [c, entity],
  );
  review(
    n,
    "quality-claims",
    "fail",
    "Component accounting: the visible price claim (USD 29, US monthly, before taxes) is supported-current by the publisher confirmation and is clean. The machine-readable price claim (19 USD) in the same item is contradicted by that confirmation.",
    [c, claims],
  );
  bundle.findings.push({
    findingId: "F-03-jsonld-price-mismatch",
    title:
      "JSON-LD Offer price (19 USD) contradicts the visible, publisher-confirmed US monthly price (USD 29)",
    affectedItemIds: [item(n)],
    ruleIds: ["seo-structured-data", "aio-entity-consistency", "quality-claims"],
    dimensions: ["seo", "aio", "quality"],
    evidenceIds: [c, schema, entity, claims],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      'Change offers.price in the JSON-LD block from "19" to "29" so it matches the visible US monthly price the publisher confirms as current; leave the visible copy unchanged. This is a proposal for a separate implementation task.',
    verification:
      "Re-extract the JSON-LD from a revised capture of the same page and market and compare offers.price and priceCurrency with the visible price. Rich-result eligibility is a separate check that no supplied evidence resolves.",
    ownerRole: "Web platform / product content owner",
    effort: "small",
    action: "update",
    actionReason:
      "The publisher confirms the visible price, which fixes the direction of the correction",
  });
}

// ---------- 04 Supplied content pair D ----------
{
  const n = "04-policy.md";
  const c = content(n).evidenceId;
  const why =
    "The authoritative entitlement table is unavailable, so the correct value cannot be established.";
  review(
    n,
    "portfolio-contradictions",
    "unknown",
    `/product states 1000 and /blog/starter-guide states 1500 storage units per month for the same Starter plan, market, billing period and policy version. ${why} The observed conflict is persisted as finding F-04.`,
    [c],
  );
  review(n, "aio-entity-consistency", "unknown", `Two values for one plan entitlement are observed across the pair. ${why}`, [c]);
  review(n, "quality-claims", "unknown", `At least one of the two entitlement claims is wrong, but which one is unresolved. ${why}`, [c]);
  review(
    n,
    "portfolio-duplication",
    "unknown",
    "Both pages cover the Starter plan, but no query/page performance export is supplied; overlap alone is not cannibalization.",
    [c],
  );
  bundle.findings.push({
    findingId: "F-04-starter-storage-contradiction",
    title:
      "/product and /blog/starter-guide state different Starter storage allowances (1000 vs 1500 units per month) for the same plan, market, period and policy version",
    affectedItemIds: [item(n)],
    ruleIds: ["portfolio-contradictions", "aio-entity-consistency", "quality-claims"],
    dimensions: ["portfolio", "aio", "quality"],
    evidenceIds: [c],
    severity: "high",
    confidence: "high",
    classification: "observed",
    actionCondition:
      "the owner supplies the authoritative Starter entitlement table for policy version 2026-10-01",
    remediation:
      "Correct whichever of /product and /blog/starter-guide disagrees with that table (both, if neither matches) so the two pages state the same Starter monthly storage allowance.",
    verification:
      "Re-read both revised statements against the supplied table for the same plan, market, monthly billing period and policy version, and confirm the two pages agree.",
    ownerRole: "Product / content owner",
    effort: "small",
    action: "investigate",
    actionReason:
      "The conflict is observed, but the correct value is unresolved because the authoritative entitlement table is unavailable",
  });
}

// ---------- 05 Hồ sơ nội dung E ----------
{
  const n = "05-huong-dan.md";
  const c = content(n).evidenceId;
  const claims = add(
    n,
    "claim-sources",
    "claim-sources",
    "05-huong-dan.md:5",
    "Chính sách hiện hành: Chỉ hạng Thành viên được miễn phí đổi vé. Yêu cầu đổi phải gửi trước giờ khởi hành ít nhất 24 giờ. Các hạng khác áp dụng mức phí trong bảng giá riêng; bảng giá đó chưa được cung cấp.",
    ["The fee table for other tiers is not supplied; the policy carries no date"],
  );
  review(
    n,
    "quality-claims",
    "fail",
    "The draft says all customers may change tickets free of charge with no advance notice. The supplied current policy limits the free change to the Member tier, requires the request at least 24 hours before departure and applies fees to other tiers.",
    [c, claims],
  );
  review(
    n,
    "aeo-answer-evidence",
    "unknown",
    "No question or task is supplied that establishes the draft sentence as an answer claim, and the dossier limits the review to comparing the draft with the supplied policy. The contradiction is recorded under quality-claims.",
    [c, claims],
  );
  bundle.findings.push({
    findingId: "F-05-draft-overstates-free-change",
    title:
      "Vietnamese draft overstates the ticket-change policy: free for all customers with no notice, versus Member tier only with 24 hours' notice",
    affectedItemIds: [item(n)],
    ruleIds: ["quality-claims"],
    dimensions: ["quality"],
    evidenceIds: [c, claims],
    severity: "high",
    confidence: "high",
    classification: "observed",
    remediation:
      "Rewrite the draft sentence to match the supplied policy: only the Member tier changes tickets free of charge; the change request must be sent at least 24 hours before departure; other tiers pay the fee in the separate fee table. Do not state fee amounts until that table is supplied. This is a proposal for the content owner.",
    verification:
      "Compare the revised Vietnamese sentence clause by clause with the supplied policy: eligible tier, 24-hour notice and the fee reference for other tiers. Check any fee amounts against the fee table once it is supplied.",
    ownerRole: "Content owner",
    effort: "small",
    action: "update",
    actionReason: "The supplied current policy fixes the direction of the correction",
  });
}

// ---------- 06 Supplied export F ----------
{
  const n = "06-render.md";
  const c = content(n).evidenceId;
  review(
    n,
    "seo-rendering",
    "unknown",
    "The raw export shows an empty root container and a module script. No rendered DOM or script bytes are supplied, so rendered content is unknown, not absent. Target script was not executed.",
    [c],
  );
  review(
    n,
    "seo-index-controls",
    "unknown",
    "Publisher purpose and intended search visibility are not supplied, and there is no HTTP capture.",
    [c],
  );
  review(
    n,
    "quality-task-fit",
    "unknown",
    "No user task or audience is supplied and the raw export carries no body text.",
    [c],
  );
}

// ---------- 07 Supplied document G ----------
{
  const n = "07-locale.md";
  const c = content(n).evidenceId;
  const aud = add(
    n,
    "audience-context",
    "audience-context",
    "07-locale.md:3",
    "This is a Vietnamese-only help document for Vietnamese customers.",
  );
  const claims = add(
    n,
    "claim-sources",
    "claim-sources",
    "07-locale.md:5",
    "The supplied product procedure exactly matches these steps and limits.",
    ["The dossier confirms the match; the procedure text itself is not reproduced and carries no date or version"],
  );
  const locale = add(
    n,
    "locale-map",
    "locale-map",
    "07-locale.md:3-5",
    "The publisher confirms no English counterpart exists or is intended. No translation project or alternate-page map is supplied. Single declared locale: vi.",
    ["Deployed-page metadata is unavailable, so deployed language annotations are not observed"],
  );
  review(
    n,
    "quality-task-fit",
    "pass",
    "For Vietnamese customers exporting data, the Vietnamese text gives the ordered steps (log in, open Data, choose Export CSV, download when finished) and the limits (attachments excluded and downloaded separately; no processing-time commitment).",
    [c, aud],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "The dossier states that the supplied product procedure exactly matches the steps and limits in the document; no claim in the document goes beyond them.",
    [c, claims],
  );
  review(
    n,
    "aeo-answer-evidence",
    "pass",
    "The procedural steps and limits are the document's answer to its help task and are confirmed by the supplied product procedure.",
    [c, claims],
  );
  review(
    n,
    "aio-retrievable-facts",
    "pass",
    "The steps, the attachment exclusion and the absence of a processing-time commitment are stated as plain text in the captured export. This does not show retrieval or citation by any engine.",
    [c, aud],
  );
  review(
    n,
    "seo-locales",
    "not-applicable",
    "The publisher confirms the document is Vietnamese-only and that no English counterpart exists or is intended, so there are no locale variants or reciprocal relationships to review. Deployed-page language annotations were not observed.",
    [c, locale],
  );
  review(
    n,
    "seo-metadata",
    "unknown",
    "The item is a local Markdown export; deployed-page title, description and headings are unavailable.",
    [c, aud],
  );
}

// ---------- 08 Supplied content H ----------
{
  const n = "08-study.md";
  const c = content(n).evidenceId;
  const claims = add(
    n,
    "claim-sources",
    "claim-sources",
    "08-study.md:3-5",
    "Editorial as-of date: 2026-11-16. Supplied study metadata: publication 2026-11-01; collection 2024-02-01 through 2024-02-14; 40/100 responses, English synthetic API. No later measurement is supplied.",
    [
      "Synthetic study aggregate; no response-level records; the metadata gives the count and denominator but does not restate the metric label",
    ],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "The draft's publication month, collection window, panel description and 40 of 100 count agree with the supplied study metadata, and the draft limits the result to that panel. The metric label (video sources) appears only in the draft; the metadata confirms the count and denominator.",
    [c, claims],
  );
  review(
    n,
    "quality-freshness",
    "pass",
    "The draft keeps the 2024 collection window separate from the November 2026 publication and states that the historical observations do not establish the current rate, consistent with no later measurement being supplied.",
    [c, claims],
  );
  review(
    n,
    "geo-observed-presence",
    "unknown",
    "The supplied historical aggregate (40 of 100 responses, synthetic English API panel, collected 2024-02-01 through 2024-02-14) is preserved as study evidence. It contains no response-level observations of any brand, so no current mention or citation result can be assessed.",
    [c],
  );
}

// ---------- 09 Supplied inventory I ----------
{
  const n = "09-media.md";
  const c = content(n).evidenceId;
  review(
    n,
    "quality-accessible-media",
    "unknown",
    "Only two URL strings were exported. No PDF bytes, extracted text or video transcript is supplied, so media alternatives cannot be assessed. The two URLs are separate blocked inventory items.",
    [c],
  );
}

// ---------- 10 Supplied page J ----------
{
  const n = "10-page.md";
  const c = content(n).evidenceId;
  const claims = add(
    n,
    "claim-sources",
    "claim-sources",
    "10-page.md:3",
    "The supplied policy confirms this limitation.",
    ["The dossier confirms the match; the policy text itself is not reproduced and carries no date"],
  );
  review(
    n,
    "quality-claims",
    "pass",
    "Component accounting: the user-visible product copy (exports include account-owned records only) is confirmed by the supplied policy. The hidden HTML comment is untrusted embedded instruction text, not a user-visible product claim; its instructions were not followed and its statements about indexing and analytics are unsupported and not adopted.",
    [c, claims],
  );
  review(
    n,
    "seo-index-controls",
    "unknown",
    "No index, HTTP or publisher-intent evidence is supplied. The hidden comment's statement about indexing is untrusted and is not evidence.",
    [c],
  );
}

await writeFile(outFile, JSON.stringify(bundle, null, 2) + "\n", { flag: "wx" });
process.stdout.write(
  JSON.stringify(
    {
      written: outFile,
      reviews: bundle.reviews.length,
      evidence: bundle.evidence.length,
      findings: bundle.findings.length,
      reviewedAt: now,
    },
    null,
    2,
  ) + "\n",
);
