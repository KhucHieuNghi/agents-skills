// Renders the validated reviewed run again with the supplied historical study source
// attached, into a NEW separate directory (the run's own reports are not replaced).
// Usage: node study-supplement.mjs SKILL_DIR RUN_DIR STUDY_FILE NEW_OUTPUT_DIR
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";

const [skill, runDir, studyFile, outDir] = process.argv.slice(2);
if (!skill || !runDir || !studyFile || !outDir) throw new Error("Usage error");
const lib = (name) => import(pathToFileURL(path.join(skill, "scripts/lib", name)));
const { loadAuditData, validateAuditData } = await lib("validate.mjs");
const { buildReportDocuments } = await lib("report.mjs");
const registry = JSON.parse(
  await readFile(path.join(skill, "rules/core.json"), "utf8"),
);
const audit = await loadAuditData(runDir);
const validation = validateAuditData(audit, registry);
if (!validation.valid) throw new Error(validation.errors.join("; "));
const sourceText = await readFile(studyFile, "utf8");
const lines = sourceText.split(/\r?\n/);
const studySources = [
  {
    sourceId: "dossier-08-synthetic-api-panel",
    kind: "historical-study",
    locator: "targets/08-study.md",
    sourceText,
    sourceHash: createHash("sha256").update(sourceText).digest("hex"),
    synthetic: true,
    scope:
      "Synthetic English API panel; 100 responses; collected 2024-02-01 through 2024-02-14; study published 2026-11-01; editorial as-of date 2026-11-16. Engine, model, prompts and brand scope are not supplied.",
    limitations: [
      "Synthetic fixture aggregate; not live or current performance",
      "No response-level records, prompts or citations are supplied",
      "No later measurement is supplied; the historical count does not establish a current rate",
      "API panel output is not consumer-UI evidence",
    ],
    passages: [{ startLine: 3, endLine: 5, quote: lines.slice(2, 5).join("\n") }],
  },
];
const documents = buildReportDocuments(audit, registry, { studySources });
await mkdir(outDir);
for (const [name, value] of Object.entries(documents))
  await writeFile(path.join(outDir, name), value, { flag: "wx" });
process.stdout.write(
  JSON.stringify({ outDir, files: Object.keys(documents) }, null, 2) + "\n",
);
