// Builds the quote ledger from the final report and prints per-item check tallies.
// Usage: node build-quotes.mjs PROJECT_ROOT RUN_DIR OUTPUT_QUOTES_JSON
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const [root, runDir, outFile] = process.argv.slice(2);
if (!root || !runDir || !outFile) throw new Error("Usage error");
const hash = (v) => createHash("sha256").update(v).digest("hex");
const reportBytes = await readFile(path.join(root, "report.md"));
const lines = reportBytes.toString("utf8").split(/\r?\n/);
const pattern = /^- `([^`:]+\.md):(\d+)(?:-(\d+))?` — `(.*)`$/u;
const sources = new Map();
const quotes = [];
const problems = [];
for (const [index, line] of lines.entries()) {
  const m = pattern.exec(line);
  if (!m) {
    if (/^- `[^`]+\.md:\d/.test(line)) problems.push(`Unparsed quote line ${index + 1}`);
    continue;
  }
  const [, label, start, end, quote] = m;
  const source = `targets/${label}`;
  if (!sources.has(source)) {
    const bytes = await readFile(path.join(root, source));
    sources.set(source, { hash: hash(bytes), lines: bytes.toString("utf8").split(/\r?\n/) });
  }
  const s = sources.get(source);
  const startLine = Number(start);
  const endLine = Number(end ?? start);
  const normalization = endLine > startLine ? "whitespace" : "exact";
  const span = s.lines.slice(startLine - 1, endLine).join("\n");
  const norm = (v) => (normalization === "whitespace" ? v.replace(/\s+/gu, " ").trim() : v);
  if (!norm(span).includes(norm(quote)))
    problems.push(`Quote not in ${label}:${start}${end ? "-" + end : ""} (report line ${index + 1})`);
  quotes.push({
    quoteId: `q${String(quotes.length + 1).padStart(2, "0")}-${label}-${startLine}`,
    source,
    sourceLabel: label,
    sourceHash: s.hash,
    startLine,
    endLine,
    reportStartLine: index + 1,
    reportEndLine: index + 1,
    normalization,
    quote,
  });
}
const checks = (await readFile(path.join(runDir, "checks.jsonl"), "utf8"))
  .split("\n")
  .filter((l) => l.trim())
  .map((l) => JSON.parse(l));
const inventory = (await readFile(path.join(runDir, "inventory.jsonl"), "utf8"))
  .split("\n")
  .filter((l) => l.trim())
  .map((l) => JSON.parse(l));
const tally = inventory.map((item) => {
  const mine = checks.filter((c) => c.itemId === item.itemId);
  const count = (s) => mine.filter((c) => c.status === s).length;
  return {
    item: item.path ? path.basename(item.path) : item.uri,
    state: item.state,
    total: mine.length,
    pass: count("pass"),
    fail: count("fail"),
    notApplicable: count("not-applicable"),
    unknown: count("unknown"),
  };
});
const sum = (k) => tally.reduce((a, t) => a + t[k], 0);
const findings = JSON.parse(await readFile(path.join(runDir, "findings.json"), "utf8"));
if (problems.length) {
  process.stdout.write(JSON.stringify({ problems }, null, 2) + "\n");
  process.exit(1);
}
await writeFile(
  outFile,
  JSON.stringify({ root, report: "report.md", reportHash: hash(reportBytes), quotes }, null, 2) + "\n",
);
process.stdout.write(
  JSON.stringify(
    {
      quotes: quotes.length,
      totals: {
        checks: sum("total"),
        pass: sum("pass"),
        fail: sum("fail"),
        notApplicable: sum("notApplicable"),
        unknown: sum("unknown"),
      },
      findings: findings.map((f) => `${f.findingId} (${f.severity})`),
      tally,
    },
    null,
    2,
  ) + "\n",
);
